import React, { useEffect, useSyncExternalStore } from 'react';

const listeners = new Set<() => void>();
const here = () => location.pathname + location.search + location.hash;
let current = here();
/** Страницы с якорями (#comment-14) слушают это событие, чтобы прокрутить к элементу после перехода. */
export const HASH_EVENT = 'cn:hash';
const notify = () => {
  current = here();
  listeners.forEach((l) => l());
  window.dispatchEvent(new Event(HASH_EVENT));
};
addEventListener('popstate', notify);
addEventListener('hashchange', notify);

export function navigate(to: string, opts: { replace?: boolean } = {}) {
  if (to === here()) return void window.dispatchEvent(new Event(HASH_EVENT));
  const base = to.split('#')[0];
  const samePage = base === location.pathname + location.search || base.split('?')[0] === location.pathname;
  const hasHash = to.includes('#');
  history[opts.replace ? 'replaceState' : 'pushState'](null, '', to);
  notify();
  if (!samePage && !hasHash) window.scrollTo(0, 0);
}

/** Внутренний путь: ровно один ведущий «/», без «//host», «/\\host», управляющих символов (защита от open redirect). */
export const isInternalPath = (p?: string | null): p is string => !!p && /^\/(?![\/\\])[^\u0000-\u001f\s]*$/.test(p);

/** Куда вернуться после входа: только внутренний путь (с query и #hash), иначе «/». Сам /login не годится. */
export function safeNext(n?: string | null): string {
  if (!isInternalPath(n)) return '/';
  try {
    const u = new URL(n, location.origin);
    if (u.origin !== location.origin || u.pathname === '/login') return '/';
  } catch { return '/'; }
  return n;
}

/** Открыть ссылку из уведомления/баннера/тоста: внутренняя — переход без перезагрузки, http(s) — новая вкладка. */
export function openLink(link?: string | null) {
  if (!link) return;
  if (isInternalPath(link)) navigate(link);
  else if (/^https?:\/\//i.test(link)) window.open(link, '_blank', 'noopener,noreferrer');
}

export function useLocation() {
  const cur = useSyncExternalStore((cb) => (listeners.add(cb), () => listeners.delete(cb)), () => current);
  const h = cur.indexOf('#');
  const hash = h < 0 ? '' : cur.slice(h);
  const rest = h < 0 ? cur : cur.slice(0, h);
  const i = rest.indexOf('?');
  return { path: i < 0 ? rest : rest.slice(0, i), search: i < 0 ? '' : rest.slice(i), hash, full: rest };
}

export function useSearchParams(): [URLSearchParams, (patch: Record<string, string | number | null | undefined>, replace?: boolean) => void] {
  const { path, search } = useLocation();
  const params = new URLSearchParams(search);
  const set = (patch: Record<string, any>, replace = true) => {
    const p = new URLSearchParams(location.search);
    for (const [k, v] of Object.entries(patch)) (v === null || v === undefined || v === '' ? p.delete(k) : p.set(k, String(v)));
    const q = p.toString();
    navigate(location.pathname + (q ? '?' + q : ''), { replace });
  };
  return [params, set];
}

/** Ссылка на ту же страницу с другим ?page= (остальные параметры сохраняются); страница 1 — без параметра. */
export function pageHref(p: number): string {
  const u = new URLSearchParams(location.search);
  if (p > 1) u.set('page', String(p)); else u.delete('page');
  const q = u.toString();
  return location.pathname + (q ? '?' + q : '');
}

export function matchPath(pattern: string, path: string): Record<string, string> | null {
  const a = pattern.split('/').filter(Boolean), b = path.split('/').filter(Boolean);
  if (pattern.endsWith('/*')) {
    if (b.length < a.length - 1) return null;
    a.pop();
  } else if (a.length !== b.length) return null;
  const out: Record<string, string> = {};
  for (let i = 0; i < a.length; i++) {
    if (a[i].startsWith(':')) { try { out[a[i].slice(1)] = decodeURIComponent(b[i]); } catch { return null; } }
    else if (a[i] !== b[i]) return null;
  }
  return out;
}

export function Link({ to, children, className, onClick, replace, title, ...rest }: React.AnchorHTMLAttributes<HTMLAnchorElement> & { to: string; replace?: boolean }) {
  return (
    <a
      href={to}
      className={className}
      title={title}
      onClick={(e) => {
        onClick?.(e);
        if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || rest.target === '_blank') return;
        e.preventDefault();
        navigate(to, { replace });
      }}
      {...rest}
    >
      {children}
    </a>
  );
}

export function useTitle(t: string) {
  useEffect(() => {
    document.title = t ? `${t} · CorpNet` : 'CorpNet — корпоративный портал';
  }, [t]);
}
