// A tiny stale-while-revalidate cache: dedupes requests, shares data between
// components and lets realtime events invalidate by key prefix.
import { useCallback, useEffect, useRef, useSyncExternalStore } from 'react';

interface Entry {
  data?: any;
  error?: any;
  loading: boolean;
  ts: number;
}
const entries = new Map<string, Entry>();
const subs = new Map<string, Set<() => void>>();
const inflight = new Map<string, Promise<void>>();
const fetchers = new Map<string, () => Promise<any>>();
const EMPTY: Entry = { loading: false, ts: 0 };

const notify = (k: string) => subs.get(k)?.forEach((f) => f());
const set = (k: string, e: Entry) => {
  entries.set(k, e);
  notify(k);
};

function run(key: string, fetcher: () => Promise<any>): Promise<void> {
  fetchers.set(key, fetcher);
  const cur = inflight.get(key);
  if (cur) return cur;
  const prev = entries.get(key) || EMPTY;
  set(key, { ...prev, loading: true });
  const p = fetcher()
    .then((data) => set(key, { data, loading: false, ts: Date.now() }))
    .catch((error) => set(key, { ...(entries.get(key) || EMPTY), error, loading: false, ts: Date.now() }))
    .finally(() => inflight.delete(key));
  inflight.set(key, p);
  return p;
}

/** Mark matching keys stale and refetch the ones currently on screen. */
export function invalidate(match: string | ((k: string) => boolean)) {
  const test = typeof match === 'string' ? (k: string) => k.startsWith(match) : match;
  for (const [k, e] of entries) {
    if (!test(k)) continue;
    entries.set(k, { ...e, ts: 0 });
    if ((subs.get(k)?.size || 0) > 0 && fetchers.has(k)) run(k, fetchers.get(k)!);
  }
}

export function setQueryData<T = any>(key: string, updater: (old: T | undefined) => T) {
  const e = entries.get(key) || EMPTY;
  set(key, { ...e, data: updater(e.data), error: undefined });
}

export function updateQueries<T = any>(prefix: string, updater: (old: T) => T) {
  for (const [k, e] of entries) if (k.startsWith(prefix) && e.data !== undefined) set(k, { ...e, data: updater(e.data) });
}

export function prefetch(key: string, fetcher: () => Promise<any>) {
  const e = entries.get(key);
  if (!e || Date.now() - e.ts > 15000) run(key, fetcher);
}

export function clearQueries() {
  entries.clear();
  fetchers.clear();
}

export interface Query<T> {
  data: T | undefined;
  error: any;
  loading: boolean;
  refetch: () => Promise<void>;
  mutate: (updater: (old: T | undefined) => T) => void;
}

export function useQuery<T = any>(key: string | null, fetcher: () => Promise<T>, opts: { stale?: number; keepPrevious?: boolean } = {}): Query<T> {
  const stale = opts.stale ?? 30000;
  const fRef = useRef(fetcher);
  fRef.current = fetcher;
  const prev = useRef<T | undefined>();

  const subscribe = useCallback(
    (cb: () => void) => {
      if (!key) return () => {};
      let s = subs.get(key);
      if (!s) subs.set(key, (s = new Set()));
      s.add(cb);
      return () => {
        s!.delete(cb);
      };
    },
    [key]
  );
  const snap = useSyncExternalStore(subscribe, () => (key ? entries.get(key) || EMPTY : EMPTY));

  useEffect(() => {
    if (!key) return;
    const e = entries.get(key);
    if (!e || e.ts === 0 || Date.now() - e.ts > stale) run(key, () => fRef.current());
  }, [key, stale]);

  if (snap.data !== undefined) prev.current = snap.data;
  const data = snap.data !== undefined ? snap.data : opts.keepPrevious ? prev.current : undefined;
  return {
    data,
    error: snap.error,
    loading: !!key && (snap.loading || (snap.data === undefined && !snap.error)),
    refetch: () => (key ? run(key, () => fRef.current()) : Promise.resolve()),
    mutate: (u) => key && setQueryData(key, u as any),
  };
}
