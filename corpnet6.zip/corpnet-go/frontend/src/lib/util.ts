import { useEffect, useState } from 'react';
import { toast } from './store';

export const cx = (...a: any[]) => a.filter(Boolean).join(' ');

export function initials(name = ''): string {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0]).join('').toUpperCase();
}

export function hue(s = ''): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h % 360;
}

const rtf = new Intl.DateTimeFormat('ru', { day: 'numeric', month: 'long' });
const rtfY = new Intl.DateTimeFormat('ru', { day: 'numeric', month: 'long', year: 'numeric' });
const hm = new Intl.DateTimeFormat('ru', { hour: '2-digit', minute: '2-digit' });
const dmy = new Intl.DateTimeFormat('ru', { day: '2-digit', month: '2-digit', year: 'numeric' });

export const sameDay = (a: Date, b: Date) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();

export function fmtTime(iso?: string | Date | null): string {
  return iso ? hm.format(new Date(iso)) : '';
}

export function fmtDate(iso?: string | Date | null): string {
  if (!iso) return '';
  const d = new Date(iso), now = new Date();
  if (sameDay(d, now)) return 'Сегодня, ' + hm.format(d);
  const y = new Date(now.getTime() - 864e5);
  if (sameDay(d, y)) return 'Вчера, ' + hm.format(d);
  return (d.getFullYear() === now.getFullYear() ? rtf : rtfY).format(d) + ', ' + hm.format(d);
}

export function fmtDay(iso?: string | Date | null): string {
  if (!iso) return '';
  const d = new Date(iso), now = new Date();
  if (sameDay(d, now)) return 'Сегодня';
  if (sameDay(d, new Date(now.getTime() - 864e5))) return 'Вчера';
  return (d.getFullYear() === now.getFullYear() ? rtf : rtfY).format(d);
}

export const fmtShort = (iso?: string | Date | null) => (iso ? dmy.format(new Date(iso)) : '');

/** Chat-list style time: today → 12:40, otherwise 12.09 */
export function fmtChatTime(iso?: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  return sameDay(d, new Date()) ? hm.format(d) : new Intl.DateTimeFormat('ru', { day: '2-digit', month: '2-digit' }).format(d);
}

export function fmtSize(b = 0): string {
  if (b < 1024) return b + ' Б';
  if (b < 1048576) return (b / 1024).toFixed(0) + ' КБ';
  if (b < 1073741824) return (b / 1048576).toFixed(1).replace('.0', '') + ' МБ';
  return (b / 1073741824).toFixed(1) + ' ГБ';
}

export function plural(n: number, forms: [string, string, string]): string {
  const m = Math.abs(n) % 100, d = m % 10;
  const f = m > 10 && m < 20 ? forms[2] : d === 1 ? forms[0] : d >= 2 && d <= 4 ? forms[1] : forms[2];
  return `${n} ${f}`;
}

// У каждой загруженной картинки три варианта: оригинал, просмотр (≤1728px) и превью (320px).
//   публичные:   /media/<имя>.<ext>  →  .v.jpg (просмотр), .t.jpg (превью)
//   защищённые:  /files/<id>         →  ?v=1 (просмотр), ?t=1 (превью), ?dl=1 (скачивание)
const MEDIA_IMG = /^\/media\/[^/?#]+\.(jpe?g|png|gif)$/i;
const FILES_ID = /^\/files\/\d+$/;

/** Превью (списки, карточки, миниатюры, аватары). Внешние и неизвестные URL возвращаются как есть. */
export function thumb(url?: string): string {
  if (!url) return '';
  if (MEDIA_IMG.test(url) && !/\.[tv]\.jpg$/i.test(url)) return url + '.t.jpg';
  if (FILES_ID.test(url)) return url + '?t=1';
  return url;
}

/** Вариант для просмотра в браузере (лайтбокс, страница новости, картинки в тексте). */
export function view(url?: string): string {
  if (!url) return '';
  if (MEDIA_IMG.test(url) && !/\.[tv]\.jpg$/i.test(url)) return url + '.v.jpg';
  if (FILES_ID.test(url)) return url + '?v=1';
  return url;
}

/** Оригинал по URL варианта (превью/просмотр → исходный файл). */
export function original(url?: string): string {
  if (!url) return '';
  return url.replace(/(\/media\/[^/?#]+)\.[tv]\.jpg$/i, '$1').replace(/^(\/files\/\d+)\?[tv]=1$/, '$1');
}

/** Ссылка на скачивание оригинала. */
export function download(url?: string): string {
  const o = original(url);
  return FILES_ID.test(o) ? o + '?dl=1' : o;
}

/** onError для <img>: у старых файлов вариантов может не быть — один раз пробуем оригинал. */
export function imgFallback(e: { currentTarget: HTMLImageElement }) {
  const el = e.currentTarget;
  const cur = el.getAttribute('src') || '';
  const o = original(cur);
  if (o && o !== cur && !el.dataset.fb) { el.dataset.fb = '1'; el.src = o; }
}

export function useDebounced<T>(value: T, ms = 250): T {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);
  return v;
}

export function fileKind(name = '', mime = ''): 'image' | 'video' | 'pdf' | 'sheet' | 'slides' | 'zip' | 'text' | 'file' {
  const e = name.split('.').pop()?.toLowerCase() || '';
  if (mime.startsWith('image/')) return 'image';
  if (mime.startsWith('video/')) return 'video';
  if (e === 'pdf') return 'pdf';
  if (['xls', 'xlsx', 'csv', 'ods'].includes(e)) return 'sheet';
  if (['ppt', 'pptx', 'odp', 'key'].includes(e)) return 'slides';
  if (['zip', 'rar', '7z', 'tar', 'gz'].includes(e)) return 'zip';
  if (['doc', 'docx', 'txt', 'md', 'rtf', 'odt'].includes(e)) return 'text';
  return 'file';
}

export const extLabel = (name = '') => (name.includes('.') ? name.split('.').pop()!.toUpperCase().slice(0, 5) : 'FILE');

export const toLocalInput = (d: Date) => {
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
};

export function copyText(t: string) {
  if (navigator.clipboard) return navigator.clipboard.writeText(t);
  const ta = document.createElement('textarea');
  ta.value = t;
  document.body.appendChild(ta);
  ta.select();
  document.execCommand('copy');
  ta.remove();
  return Promise.resolve();
}

/** Копирует абсолютную ссылку на внутренний путь (/news/5?x=1#comment-3) и показывает уведомление. */
export function copyLink(path: string) {
  return copyText(location.origin + path).then(() => toast({ title: 'Ссылка скопирована', kind: 'success' }, 2000));
}

/** Номер для ссылки call://makecall$<номер>: оставляем цифры и + * # -, всё прочее (пробелы, скобки, буквы) убираем. */
export const cleanDial = (v?: string | null): string => String(v ?? '').replace(/[^\d+\-() #*]/g, '').trim();
/** href видеотелефона. Схема call:// пользовательская, `$` — литерал; роутер такие клики не перехватывает. */
export const callHref = (v?: string | null): string => 'call://makecall$' + cleanDial(v);
