// Реестр тем: единственный источник списка (меню профиля, настройки, store.ts).
// Цвета самих тем — в src/themes.css (`:root[data-theme="<id>"]`); id здесь = значение data-theme.
// Скрипт в index.html применяет сохранённую тему до первой отрисовки и проверяет id по шаблону /^[a-z]+$/;
// неизвестный id приложение заменит на светлую при старте (см. normalizeTheme).
export interface ThemeDef {
  id: string;
  label: string;
  scheme: 'light' | 'dark';
  /** Кружок-превью: [фон страницы, акцент] и цвет <meta name="theme-color"> (шапка браузера). */
  swatch: [string, string];
  meta: string;
}

export const THEMES: ThemeDef[] = [
  { id: 'light', label: 'Светлая', scheme: 'light', swatch: ['#e3e9f1', '#1d62a3'], meta: '#ffffff' },
  { id: 'dark', label: 'Тёмная', scheme: 'dark', swatch: ['#19232f', '#5aa9e6'], meta: '#19232f' },
  { id: 'green', label: 'Зелёная', scheme: 'light', swatch: ['#dcebe0', '#126f3b'], meta: '#ffffff' },
  { id: 'orange', label: 'Оранжевая', scheme: 'light', swatch: ['#f4e6d6', '#b43908'], meta: '#ffffff' },
  { id: 'cyber', label: 'Киберпанк', scheme: 'dark', swatch: ['#130b24', '#19e3ff'], meta: '#130b24' },
];
export const SYSTEM_THEME = { id: 'system', label: 'Как в системе' } as const;

export type ThemeId = (typeof THEMES)[number]['id'];
export type ThemeChoice = string; // id из THEMES или 'system'

export const themeById = (id: string): ThemeDef | undefined => THEMES.find((t) => t.id === id);
export const isThemeChoice = (v: unknown): v is ThemeChoice => v === 'system' || (typeof v === 'string' && !!themeById(v));
/** Неизвестное значение (например, из localStorage старой версии) → 'system'. */
export const normalizeTheme = (v: unknown): ThemeChoice => (isThemeChoice(v) ? v : 'system');
