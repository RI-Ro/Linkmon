// Локальное состояние интерфейса, сохраняемое отдельно для каждого пользователя (localStorage, переживает перезагрузку).
// Ключ: cn:<id пользователя>:<ключ>. Значения — любой JSON. Между вкладками синхронизируется событием storage.
import { useCallback, useEffect, useState } from 'react';
import { getState } from './store';

const pref = () => `cn:${getState().me?.id ?? 0}:`;

export function readPersist<T>(key: string, def: T): T {
  try {
    const v = localStorage.getItem(pref() + key);
    return v == null ? def : (JSON.parse(v) as T);
  } catch {
    return def;
  }
}

export function writePersist(key: string, v: unknown) {
  try {
    localStorage.setItem(pref() + key, JSON.stringify(v));
  } catch {}
}

/** Как useState, но значение хранится в localStorage для текущего пользователя. */
export function usePersist<T>(key: string, def: T): [T, (v: T | ((o: T) => T)) => void] {
  const [val, setVal] = useState<T>(() => readPersist(key, def));
  const set = useCallback(
    (v: T | ((o: T) => T)) => {
      setVal((old) => {
        const n = typeof v === 'function' ? (v as (o: T) => T)(old) : v;
        writePersist(key, n);
        return n;
      });
    },
    [key]
  );
  useEffect(() => {
    const on = (e: StorageEvent) => {
      if (e.key === pref() + key) setVal(e.newValue == null ? def : JSON.parse(e.newValue));
    };
    addEventListener('storage', on);
    return () => removeEventListener('storage', on);
  }, [key]);
  return [val, set];
}

/** Набор id (раскрытые узлы дерева и т.п.) с сохранением. */
export function usePersistSet(key: string): [Set<number>, (fn: (s: Set<number>) => Set<number>) => void] {
  const [arr, setArr] = usePersist<number[]>(key, []);
  const set = (fn: (s: Set<number>) => Set<number>) => setArr((old) => [...fn(new Set(old))]);
  return [new Set(arr), set];
}
