// Реакции: общая шина событий. Изменения приходят двумя путями — от сервера через WebSocket (другие пользователи и вкладки)
// и локально после собственного запроса; все компоненты Reactions подписаны на одну шину и фильтруют по (тип, id).
import { api } from './api';
import { getState } from './store';
import { realtime } from './ws';

export interface Rx { e: string; n: number; m?: boolean }
export interface RxEvent { entity_type: string; entity_id: number; reactions: Rx[]; actor?: number; emoji?: string; on?: boolean; full?: boolean }

const subs = new Set<(d: RxEvent) => void>();
export function onReaction(cb: (d: RxEvent) => void) { subs.add(cb); return () => { subs.delete(cb); }; }
function publish(d: RxEvent) { subs.forEach((f) => { try { f(d); } catch (e) { console.error(e); } }); }
realtime.on('reaction', (d: RxEvent) => publish(d));

/** Применить событие к списку: серверное событие не знает «моих» реакций — берём их из текущего состояния. */
export function applyEvent(prev: Rx[], d: RxEvent): Rx[] {
  if (d.full) return d.reactions;
  const mine = new Set(prev.filter((x) => x.m).map((x) => x.e));
  if (d.actor === getState().me?.id && d.emoji) { if (d.on) mine.add(d.emoji); else mine.delete(d.emoji); }
  return d.reactions.map((r) => ({ e: r.e, n: r.n, m: mine.has(r.e) || undefined }));
}

/** Оптимистичное изменение списка. */
export function optimistic(prev: Rx[], emoji: string, on: boolean): Rx[] {
  const has = prev.find((x) => x.e === emoji);
  if (on) return has ? prev.map((x) => (x.e === emoji ? { ...x, n: x.n + (x.m ? 0 : 1), m: true } : x)) : [...prev, { e: emoji, n: 1, m: true }];
  return prev.flatMap((x) => (x.e !== emoji ? [x] : x.n <= 1 ? [] : [{ ...x, n: x.n - 1, m: undefined }]));
}

/** Поставить/снять (on) или переключить (on не задан) реакцию. Возвращает актуальный список объекта. */
export async function sendReaction(type: string, id: number, emoji: string, on?: boolean): Promise<Rx[]> {
  const r = await api.post<{ on: boolean; reactions: Rx[] }>('/api/reactions', { entity_type: type, entity_id: id, emoji, on });
  publish({ entity_type: type, entity_id: id, reactions: r.reactions, actor: getState().me?.id, emoji, on: r.on, full: true });
  return r.reactions;
}
