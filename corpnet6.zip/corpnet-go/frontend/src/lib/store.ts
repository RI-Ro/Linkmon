import { useSyncExternalStore } from 'react';
import { THEMES, isThemeChoice, normalizeTheme, themeById, type ThemeChoice } from './themes';

export interface Me {
  id: number; login: string; name: string; first_name: string; last_name: string; middle_name: string; email: string; job_title: string;
  extra_info: string; department_id: number | null; department: string | null; role: 'admin' | 'editor' | 'user'; avatar: string;
  phone: string; phone2: string; phone3: string; phone4: string; birthday: string | null; is_head: boolean;
  can_vacations: boolean; company_news: boolean; learning_manager?: boolean; ldap: boolean; settings: any;
}
export interface Toast { id: number; title: string; body?: string; link?: string; kind?: 'info' | 'success' | 'error' | 'news' | 'message' }
export interface State {
  booted: boolean;
  me: Me | null;
  company: any;
  categories: { id: number; name: string; color: string }[];
  unreadNotifications: number;
  unreadChats: number;
  online: ReadonlySet<number>;
  theme: ThemeChoice;
  toasts: Toast[];
  instance: string;
  wsOnline: boolean;
}

/** Последняя известная тема: у запомненного пользователя (cn_last_uid → cn:<id>:theme), иначе общий cn_theme. Совпадает со скриптом в index.html. */
function initialTheme(): ThemeChoice {
  try {
    const uid = localStorage.getItem('cn_last_uid');
    if (uid) {
      const v = JSON.parse(localStorage.getItem(`cn:${uid}:theme`) || 'null');
      if (isThemeChoice(v)) return v;
    }
    return normalizeTheme(localStorage.getItem('cn_theme'));
  } catch { return 'system'; }
}

let state: State = {
  booted: false, me: null, company: null, categories: [], unreadNotifications: 0, unreadChats: 0,
  online: new Set(), theme: initialTheme(), toasts: [], instance: '', wsOnline: false,
};
const listeners = new Set<() => void>();

export const getState = () => state;
export function setState(patch: Partial<State> | ((s: State) => Partial<State>)) {
  state = { ...state, ...(typeof patch === 'function' ? patch(state) : patch) };
  listeners.forEach((l) => l());
}
export function useStore<T>(sel: (s: State) => T): T {
  return useSyncExternalStore(
    (cb) => (listeners.add(cb), () => listeners.delete(cb)),
    () => sel(state)
  );
}

// ---- theme
const mq = matchMedia('(prefers-color-scheme: dark)');
export function applyTheme(t: ThemeChoice) {
  const id = t === 'system' ? (mq.matches ? 'dark' : 'light') : themeById(t) ? t : 'light';
  document.documentElement.dataset.theme = id;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', themeById(id)?.meta || '#ffffff');
}
/** Тема вошедшего пользователя хранится по ключу cn:<id>:theme; 'cn_theme' — запасной вариант для экрана входа, cn_last_uid — чьё значение читать до загрузки. */
export function setTheme(t: ThemeChoice) {
  if (!isThemeChoice(t)) t = 'system';
  try {
    localStorage.setItem('cn_theme', t);
    if (state.me) { localStorage.setItem(`cn:${state.me.id}:theme`, JSON.stringify(t)); localStorage.setItem('cn_last_uid', String(state.me.id)); }
  } catch {}
  setState({ theme: t });
  applyTheme(t);
}
/** После входа: применить сохранённую тему этого пользователя (если есть). */
export function loadUserTheme(id: number) {
  try {
    localStorage.setItem('cn_last_uid', String(id));
    const v = JSON.parse(localStorage.getItem(`cn:${id}:theme`) || 'null');
    if (isThemeChoice(v)) { if (v !== state.theme) setState({ theme: v }); applyTheme(v); localStorage.setItem('cn_theme', v); }
    else localStorage.setItem(`cn:${id}:theme`, JSON.stringify(state.theme));
  } catch {}
}
mq.addEventListener?.('change', () => state.theme === 'system' && applyTheme('system'));
export { THEMES };

// ---- toasts
let tid = 1;
export function toast(t: Omit<Toast, 'id'>, ms = 5000) {
  const id = tid++;
  setState((s) => ({ toasts: [...s.toasts.slice(-3), { ...t, id }] }));
  setTimeout(() => dismissToast(id), ms);
}
export const dismissToast = (id: number) => setState((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) }));

export const isEditor = (me: Me | null) => !!me && (me.role === 'admin' || me.role === 'editor');
export const isAdmin = (me: Me | null) => !!me && me.role === 'admin';
