// Realtime connection with automatic reconnect. Server events look like {t, d}.
import { useEffect, useRef } from 'react';
import { setState } from './store';

type Handler = (d: any) => void;
const handlers = new Map<string, Set<Handler>>();
const topics = new Set<string>();
let ws: WebSocket | null = null;
let timer: any = null;
let backoff = 1000;
let wanted = false;
let opened = 0;

function emit(t: string, d?: any) {
  handlers.get(t)?.forEach((h) => { try { h(d); } catch (e) { console.error(e); } });
}

function connect() {
  if (!wanted || ws) return;
  const url = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/api/ws';
  const s = (ws = new WebSocket(url));
  s.onopen = () => {
    backoff = 1000;
    setState({ wsOnline: true });
    topics.forEach((t) => s.send(JSON.stringify({ t: 'sub', topic: t })));
    emit(opened++ ? 'reconnected' : 'connected');
  };
  s.onmessage = (e) => {
    try {
      const m = JSON.parse(e.data);
      if (m.t === 'hello') setState({ instance: m.d?.instance || '' });
      emit(m.t, m.d);
    } catch {}
  };
  s.onclose = () => {
    ws = null;
    setState({ wsOnline: false });
    if (wanted) {
      timer = setTimeout(connect, backoff + Math.random() * 500);
      backoff = Math.min(backoff * 2, 15000);
    }
  };
  s.onerror = () => s.close();
}

export const realtime = {
  start() { wanted = true; connect(); },
  stop() {
    wanted = false;
    clearTimeout(timer);
    ws?.close();
    ws = null;
    topics.clear();
    opened = 0;
  },
  send(o: any) { if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify(o)); },
  sub(topic: string) { topics.add(topic); this.send({ t: 'sub', topic }); },
  unsub(topic: string) { topics.delete(topic); this.send({ t: 'unsub', topic }); },
  on(type: string, h: Handler) {
    let s = handlers.get(type);
    if (!s) handlers.set(type, (s = new Set()));
    s.add(h);
    return () => { s!.delete(h); };
  },
};

/** Subscribe to a server event for the lifetime of a component. */
export function useRealtime(type: string, handler: Handler, deps: any[] = []) {
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => realtime.on(type, (d) => ref.current(d)), [type, ...deps]);
}

/** Subscribe to a topic (e.g. live comments of the open article). */
export function useTopic(topic: string | null) {
  useEffect(() => {
    if (!topic) return;
    realtime.sub(topic);
    return () => realtime.unsub(topic);
  }, [topic]);
}
