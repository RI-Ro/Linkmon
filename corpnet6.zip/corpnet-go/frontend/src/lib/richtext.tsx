// Отрисовка пользовательского текста: ссылки, @упоминания, анимированные стикеры :имя:. Никакого innerHTML — только React-узлы.
// Юникод-эмодзи выводятся как есть. Стикер, отправленный в одиночку, рисуется крупнее; сообщение из 1–3 эмодзи — увеличенным шрифтом.
import React, { useEffect, useState } from 'react';
import { api } from './api';
import { Link } from './router';
import { useStore } from './store';
import { cx } from './util';
import { STICKER_BY_NAME, Sticker } from '../ui/stickers';

export const BIG_STICKER = 120;
const INLINE_STICKER = 30;

// ---- @логин → ссылка на профиль (пакетная подгрузка, кэш на вкладку)
interface MUser { id: number; name: string }
const cache = new Map<string, MUser | null>();
const waiters = new Map<string, Set<(u: MUser | null) => void>>();
let timer: any = null;
function resolveLogin(login: string, cb: (u: MUser | null) => void) {
  let s = waiters.get(login);
  if (!s) waiters.set(login, (s = new Set()));
  s.add(cb);
  if (!timer) timer = setTimeout(flush, 30);
}
async function flush() {
  timer = null;
  const batch = [...waiters.keys()].slice(0, 40);
  const cbs = batch.map((l) => [l, waiters.get(l)!] as const);
  batch.forEach((l) => waiters.delete(l));
  let res: Record<string, MUser> = {};
  try { res = await api.get('/api/mentions/resolve?logins=' + encodeURIComponent(batch.join(','))); } catch { /* оставим как обычный текст */ }
  for (const [l, s] of cbs) { const u = res[l] || null; cache.set(l, u); s.forEach((f) => f(u)); }
  if (waiters.size) timer = setTimeout(flush, 30);
}

export function Mention({ login }: { login: string }) {
  const l = login.toLowerCase();
  const me = useStore((s) => s.me);
  const [u, setU] = useState<MUser | null | undefined>(cache.get(l));
  useEffect(() => {
    if (cache.has(l)) { setU(cache.get(l)); return; }
    let live = true;
    resolveLogin(l, (x) => live && setU(x));
    return () => { live = false; };
  }, [l]);
  if (u === null) return <>@{login}</>; // такого сотрудника нет — обычный текст
  const mine = !!me && me.login?.toLowerCase() === l;
  return u ? <Link to={`/people/${u.id}`} className={cx('mention', mine && 'me')} title={u.name}>@{login}</Link> : <span className={cx('mention', mine && 'me')}>@{login}</span>;
}

// 1: ссылка, 2: имя стикера, 3+4: упоминание (с предшествующим символом-границей)
const TOKEN = /(https?:\/\/[^\s<]+)|:([a-z0-9_]{1,40}):|(^|[^\p{L}\p{N}_@.+%:/-])@([\p{L}\p{N}_][\p{L}\p{N}_.-]{0,62})/gu;

export interface RenderOpts { links?: boolean; mentions?: boolean; stickers?: boolean; stickerSize?: number }

/** Разбирает строку на текст, ссылки, упоминания и стикеры. key — префикс React-ключей. */
export function renderSpecial(text: string, key = '', o: RenderOpts = {}): React.ReactNode[] {
  const { links = true, mentions = true, stickers = true, stickerSize = INLINE_STICKER } = o;
  const out: React.ReactNode[] = [];
  let last = 0, i = 0;
  TOKEN.lastIndex = 0;
  let m: RegExpExecArray | null;
  const push = (s: string) => { if (s) out.push(s); };
  while ((m = TOKEN.exec(text))) {
    const k = key + 's' + i++;
    if (m[1]) {
      if (!links) continue;
      push(text.slice(last, m.index));
      let url = m[1];
      const tail = /[.,;:!?)\]»]+$/.exec(url); // знаки препинания после ссылки — не часть адреса
      if (tail) { url = url.slice(0, -tail[0].length); TOKEN.lastIndex = m.index + url.length; }
      out.push(<a key={k} href={url} target="_blank" rel="noopener noreferrer">{url}</a>);
      last = m.index + url.length;
    } else if (m[2]) {
      if (!stickers || !STICKER_BY_NAME[m[2]]) { TOKEN.lastIndex = m.index + 1; continue; } // неизвестный шорткод остаётся текстом
      push(text.slice(last, m.index));
      out.push(<Sticker key={k} name={m[2]} size={stickerSize} className="inl" />);
      last = m.index + m[0].length;
    } else if (m[4]) {
      if (!mentions) continue;
      const login = m[4].replace(/[.-]+$/, '');
      if (!login) continue;
      const start = m.index + m[3].length;
      push(text.slice(last, start));
      out.push(<Mention key={k} login={login} />);
      last = start + 1 + login.length;
      TOKEN.lastIndex = last;
    }
  }
  push(text.slice(last));
  return out;
}

/** Текст из одного стикера (и только)? Возвращает имя. */
export function loneSticker(text: string): string | null {
  const m = /^\s*:([a-z0-9_]{1,40}):\s*$/.exec(text || '');
  return m && STICKER_BY_NAME[m[1]] ? m[1] : null;
}

const EMOJI_ONLY = /^(?:\p{Extended_Pictographic}|\p{Emoji_Modifier}|‍|️|⃣|\s){1,24}$/u;
/** 1–3 эмодзи без текста → «крупные». */
export function bigEmoji(text: string): boolean {
  const t = (text || '').trim();
  if (!t || !EMOJI_ONLY.test(t)) return false;
  return (t.match(/\p{Extended_Pictographic}/gu) || []).length <= 3;
}

/** Обычный текст (комментарии, сообщения, публикации): переносы строк сохраняет контейнер (white-space: pre-wrap). */
export function RichText({ text, className, ...o }: { text: string; className?: string } & RenderOpts) {
  const s = loneSticker(text);
  if (s) return <span className={cx('stkAlone', className)}><Sticker name={s} size={BIG_STICKER} /></span>;
  return <span className={cx(bigEmoji(text) && 'bigEmoji', className)}>{renderSpecial(text, '', o)}</span>;
}

/** Поле содержит только стикер (для оформления «пузыря» сообщения без фона). */
export const isStickerOnly = (text: string) => !!loneSticker(text);

/** Текст для превью (список чатов, цитата ответа): шорткод стикера заменяется его названием. */
export const previewText = (text: string) => (text || '').replace(/:([a-z0-9_]{1,40}):/g, (m, n) => (STICKER_BY_NAME[n] ? `[${STICKER_BY_NAME[n].ru}]` : m));
