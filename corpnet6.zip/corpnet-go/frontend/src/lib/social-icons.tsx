// Иконки блока «смайлы / реакции / закладки / упоминания» (стиль Lucide, ISC).
import React from 'react';
import type { IconProps } from './icons';

const mk = (inner: string, fill = false) => (p: IconProps) => (
  <svg viewBox="0 0 24 24" width={p.size ?? 18} height={p.size ?? 18} fill={fill ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={p.sw ?? 2}
    strokeLinecap="round" strokeLinejoin="round" className={p.className} style={p.style} aria-hidden="true" dangerouslySetInnerHTML={{ __html: inner }} />
);

export const Smile = mk('<circle cx="12" cy="12" r="10"></circle><path d="M8 14s1.5 2 4 2 4-2 4-2"></path><line x1="9" x2="9.01" y1="9" y2="9"></line><line x1="15" x2="15.01" y1="9" y2="9"></line>');
export const SmilePlus = mk('<path d="M22 11v1a10 10 0 1 1-9-10"></path><path d="M8 14s1.5 2 4 2 4-2 4-2"></path><line x1="9" x2="9.01" y1="9" y2="9"></line><line x1="15" x2="15.01" y1="9" y2="9"></line><path d="M16 5h6"></path><path d="M19 2v6"></path>');
export const Bookmark = mk('<path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"></path>');
export const BookmarkFill = mk('<path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"></path>', true);
export const AtSign = mk('<circle cx="12" cy="12" r="4"></circle><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-4 8"></path>');
export const Sparkles = mk('<path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"></path>');
