// Safe, tiny markdown subset renderer (no innerHTML):
//   # крупный заголовок, ## заголовок, ### подзаголовок, - списки, 1. списки, > цитата,
//   **жирный**, *курсив*, `код`, [текст](url), автоссылки,
//   ![подпись](url){w=60%}  /  ![подпись](url){w=320}  — картинка в тексте (ширина в % или px, но не больше 100% блока).
import React from 'react';
import { imgFallback, view } from './util';
import { navigate } from './router';
import { renderSpecial } from './richtext';

const safeUrl = (u: string) => (/^(https?:\/\/|mailto:|\/(?!\/))/i.test(u) ? u : '#');

/** Parses the `{w=60%}` / `{w=320}` size suffix → CSS width (never wider than the container: see max-width in CSS). */
export function imgWidth(spec?: string): string | undefined {
  if (!spec) return undefined;
  const m = /^(\d{1,4})(%|px)?$/.exec(spec.trim());
  if (!m) return undefined;
  const n = +m[1];
  if (m[2] === '%') return Math.min(Math.max(n, 1), 100) + '%';
  return Math.max(n, 16) + 'px';
}

const RE = /(!\[[^\]]*\]\([^)\s]+\)(?:\{w=[^}]*\})?|\*\*[^*]+\*\*|\*[^*\s][^*]*\*|`[^`]+`|\[[^\]]+\]\([^)\s]+\)|https?:\/\/[^\s<]+)/g;

export function inline(text: string, key = ''): React.ReactNode[] {
  const out: React.ReactNode[] = [];
  let last = 0, m: RegExpExecArray | null, i = 0;
  RE.lastIndex = 0;
  while ((m = RE.exec(text))) {
    if (m.index > last) out.push(...renderSpecial(text.slice(last, m.index), key + 'p' + i + '-', { links: false }));
    const t = m[0], k = key + i++;
    if (t.startsWith('![')) {
      const mm = /^!\[([^\]]*)\]\(([^)\s]+)\)(?:\{w=([^}]*)\})?$/.exec(t)!;
      const w = imgWidth(mm[3]);
      out.push(
        <a key={k} href={safeUrl(mm[2])} target="_blank" rel="noopener noreferrer" className="mdImgA" style={w ? { width: w } : undefined}>
          <img className="mdImg" src={view(safeUrl(mm[2]))} alt={mm[1]} loading="lazy" decoding="async" onError={imgFallback} />
        </a>
      );
    } else if (t.startsWith('**')) out.push(<strong key={k}>{t.slice(2, -2)}</strong>);
    else if (t.startsWith('*')) out.push(<em key={k}>{t.slice(1, -1)}</em>);
    else if (t.startsWith('`')) out.push(<code key={k}>{t.slice(1, -1)}</code>);
    else if (t.startsWith('[')) {
      const mm = /\[([^\]]+)\]\(([^)\s]+)\)/.exec(t)!;
      // ссылки между страницами баз знаний (/learning/wiki/…) открываются в этой же вкладке; несуществующие страницы — красным
      if (mm[2].startsWith('/learning/wiki/')) out.push(<a key={k} href={mm[2]} className={mm[2].includes('missing=1') ? 'wkRed' : 'wkLink'} title={mm[2].includes('missing=1') ? 'Страницы ещё нет' : undefined} onClick={(e) => { if (e.button === 0 && !e.metaKey && !e.ctrlKey && !e.shiftKey) { e.preventDefault(); navigate(mm[2]); } }}>{mm[1]}</a>);
      else out.push(<a key={k} href={safeUrl(mm[2])} target="_blank" rel="noopener noreferrer">{mm[1]}</a>);
    } else out.push(<a key={k} href={safeUrl(t)} target="_blank" rel="noopener noreferrer">{t}</a>);
    last = m.index + t.length;
  }
  if (last < text.length) out.push(...renderSpecial(text.slice(last), key + 'pe-', { links: false }));
  return out;
}

export function Markdown({ text, className = 'prose' }: { text: string; className?: string }) {
  const blocks = (text || '').replace(/\r/g, '').split(/\n{2,}/);
  return (
    <div className={className}>
      {blocks.map((b, i) => {
        const lines = b.split('\n');
        let h: RegExpExecArray | null;
        if ((h = /^(#{1,3})\s+(.*)$/s.exec(b))) {
          const Tag = (['h2', 'h3', 'h4'] as const)[h[1].length - 1];
          return <Tag key={i} className={'mdH' + h[1].length}>{inline(h[2])}</Tag>;
        }
        if (lines.every((l) => /^\s*[-•]\s+/.test(l)))
          return <ul key={i}>{lines.map((l, j) => <li key={j}>{inline(l.replace(/^\s*[-•]\s+/, ''), j + ':')}</li>)}</ul>;
        if (lines.every((l) => /^\s*\d+[.)]\s+/.test(l)))
          return <ol key={i}>{lines.map((l, j) => <li key={j}>{inline(l.replace(/^\s*\d+[.)]\s+/, ''), j + ':')}</li>)}</ol>;
        if (lines.every((l) => /^>\s?/.test(l)))
          return <blockquote key={i}>{lines.map((l, j) => <React.Fragment key={j}>{j > 0 && <br />}{inline(l.replace(/^>\s?/, ''), j + ':')}</React.Fragment>)}</blockquote>;
        return (
          <p key={i}>
            {lines.map((l, j) => (
              <React.Fragment key={j}>{j > 0 && <br />}{inline(l, j + ':')}</React.Fragment>
            ))}
          </p>
        );
      })}
    </div>
  );
}

/** Plain-text excerpt (used for previews). */
export const stripMd = (s = '') => s.replace(/!\[[^\]]*\]\([^)]*\)(\{[^}]*\})?/g, '').replace(/[#*`>]/g, '').replace(/\[([^\]]+)\]\([^)]+\)/g, '$1').replace(/\s+/g, ' ').trim();
