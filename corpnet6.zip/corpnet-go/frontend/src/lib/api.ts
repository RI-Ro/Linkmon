export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

let onUnauthorized: () => void = () => {};
export const setUnauthorizedHandler = (fn: () => void) => (onUnauthorized = fn);

async function request<T>(method: string, url: string, body?: any): Promise<T> {
  const init: RequestInit = { method, credentials: 'same-origin', headers: {} };
  if (body !== undefined) {
    (init.headers as any)['Content-Type'] = 'application/json';
    init.body = JSON.stringify(body);
  }
  let res: Response;
  try {
    res = await fetch(url, init);
  } catch {
    throw new ApiError(0, 'Нет соединения с сервером');
  }
  const ct = res.headers.get('content-type') || '';
  const data = ct.includes('json') ? await res.json().catch(() => null) : null;
  if (!res.ok) {
    if (res.status === 401 && !url.startsWith('/api/auth/login')) onUnauthorized();
    throw new ApiError(res.status, data?.error || res.statusText || 'Ошибка запроса');
  }
  return data as T;
}

export const api = {
  get: <T = any>(url: string) => request<T>('GET', url),
  post: <T = any>(url: string, body: any = {}) => request<T>('POST', url, body),
  put: <T = any>(url: string, body: any) => request<T>('PUT', url, body),
  del: <T = any>(url: string) => request<T>('DELETE', url),
  /** multipart upload with progress (fetch cannot report upload progress) */
  upload<T = any>(url: string, files: File[] | File, onProgress?: (p: number) => void): Promise<T> {
    return new Promise((resolve, reject) => {
      const fd = new FormData();
      for (const f of Array.isArray(files) ? files : [files]) fd.append('file', f, f.name);
      const x = new XMLHttpRequest();
      x.open('POST', url);
      x.responseType = 'json';
      x.upload.onprogress = (e) => e.lengthComputable && onProgress?.(e.loaded / e.total);
      x.onload = () => {
        if (x.status >= 200 && x.status < 300) return resolve(x.response as T);
        if (x.status === 401) onUnauthorized();
        reject(new ApiError(x.status, x.response?.error || 'Не удалось загрузить файл'));
      };
      x.onerror = () => reject(new ApiError(0, 'Нет соединения с сервером'));
      x.send(fd);
    });
  },
};

export const errMsg = (e: any) => (e instanceof ApiError ? e.message : e?.message || 'Что-то пошло не так');
