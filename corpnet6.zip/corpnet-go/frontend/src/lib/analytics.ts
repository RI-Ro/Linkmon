// Сбор аналитики: sendBeacon не блокирует навигацию и переживает закрытие страницы. Ошибки игнорируются.
let lastPath = '';

function beacon(url: string, body: unknown) {
  try {
    const s = JSON.stringify(body);
    if (navigator.sendBeacon && navigator.sendBeacon(url, new Blob([s], { type: 'application/json' }))) return;
    fetch(url, { method: 'POST', body: s, headers: { 'Content-Type': 'application/json' }, keepalive: true, credentials: 'same-origin' }).catch(() => {});
  } catch {}
}

/** Просмотр страницы (раздел определяет сервер по префиксу маршрута; id и query не отправляются). Один раз на смену path. */
export function trackPageview(path: string) {
  if (path === lastPath) return;
  lastPath = path;
  beacon('/api/analytics/pv', { p: path });
}
export function resetPageview() { lastPath = ''; }

/** Переход по результату поиска: запрос, раздел и объект (например news:12). */
export function trackSearchClick(q: string, scope: string, entity: string) {
  if (q.trim().length < 2) return;
  beacon('/api/analytics/search-click', { q, scope, entity });
}
