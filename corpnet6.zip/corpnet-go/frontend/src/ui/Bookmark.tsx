// Кнопка «в закладки» для любой сущности (news, idea, file, post, event, message, learn_item, wiki_page, …).
// Состояние приходит вместе со списком (initial) либо подгружается пакетом на страницу (/api/bookmarks/state).
import React, { useEffect, useState } from 'react';
import { api, errMsg } from '../lib/api';
import * as X from '../lib/social-icons';
import { toast } from '../lib/store';
import { cx } from '../lib/util';
import './social.css';

const known = new Map<string, boolean>();
const subs = new Map<string, Set<(v: boolean) => void>>();
const key = (t: string, id: number) => t + ':' + id;
function setKnown(t: string, id: number, v: boolean) {
  known.set(key(t, id), v);
  subs.get(key(t, id))?.forEach((f) => f(v));
}

// пакетная подгрузка состояния: все кнопки одного типа на странице — одним запросом
const queue = new Map<string, Map<number, ((v: boolean) => void)[]>>();
let timer: any = null;
function load(t: string, id: number, cb: (v: boolean) => void) {
  let q = queue.get(t);
  if (!q) queue.set(t, (q = new Map()));
  q.set(id, [...(q.get(id) || []), cb]);
  if (!timer) timer = setTimeout(flush, 40);
}
async function flush() {
  timer = null;
  const jobs = [...queue.entries()];
  queue.clear();
  for (const [t, ids] of jobs) {
    const all = [...ids.keys()];
    for (let i = 0; i < all.length; i += 150) {
      const part = all.slice(i, i + 150);
      let on = new Set<number>();
      try { on = new Set((await api.get<{ ids: number[] }>(`/api/bookmarks/state?type=${t}&ids=${part.join(',')}`)).ids); } catch {}
      part.forEach((id) => { known.set(key(t, id), on.has(id)); ids.get(id)!.forEach((f) => f(on.has(id))); });
    }
  }
}

export function useBookmark(type: string, id: number, initial?: boolean) {
  const [on, setOn] = useState<boolean | undefined>(initial ?? known.get(key(type, id)));
  useEffect(() => {
    if (initial !== undefined) { known.set(key(type, id), initial); setOn(initial); }
  }, [initial, type, id]);
  useEffect(() => {
    const k = key(type, id);
    const f = (v: boolean) => setOn(v);
    let s = subs.get(k);
    if (!s) subs.set(k, (s = new Set()));
    s.add(f);
    if (initial === undefined) {
      if (known.has(k)) setOn(known.get(k)); else load(type, id, f);
    }
    return () => { s!.delete(f); };
  }, [type, id]);
  const [busy, setBusy] = useState(false);
  async function toggle() {
    if (busy) return;
    const want = !on;
    setBusy(true); setKnown(type, id, want);
    try {
      const r = await api.post<{ bookmarked: boolean }>('/api/bookmarks', { entity_type: type, entity_id: id, on: want });
      setKnown(type, id, r.bookmarked);
      toast({ title: r.bookmarked ? 'Добавлено в закладки' : 'Убрано из закладок', link: r.bookmarked ? '/bookmarks' : undefined, kind: 'success' }, 2500);
    } catch (e) { setKnown(type, id, !want); toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  return { on: !!on, ready: on !== undefined, toggle, busy };
}

export function BookmarkButton({ type, id, initial, size = 17, label, className, title }: { type: string; id: number; initial?: boolean; size?: number; label?: boolean; className?: string; title?: string }) {
  const b = useBookmark(type, id, initial);
  const t = title || (b.on ? 'Убрать из закладок' : 'В закладки');
  return (
    <button type="button" className={cx('bmBtn', b.on && 'on', label && 'withLabel', className)} title={t} aria-label={t} aria-pressed={b.on} disabled={b.busy}
      onClick={(e) => { e.preventDefault(); e.stopPropagation(); b.toggle(); }}>
      {b.on ? <X.BookmarkFill size={size} /> : <X.Bookmark size={size} />}{label && <span>{b.on ? 'В закладках' : 'В закладки'}</span>}
    </button>
  );
}
