import React, { useEffect, useState } from 'react';
import * as I from '../lib/icons';
import { api } from '../lib/api';
import { useQuery } from '../lib/query';
import { Link } from '../lib/router';
import { cx, thumb } from '../lib/util';
import { Img } from './index';

export interface Banner { id: number; title: string; text: string; image: string; video_url: string; link: string; link_label: string }

const AUTO_MS = 7000;
/** До этого числа баннеры показываются списком, дальше — компактным слайдером. */
const LIST_MAX = 3;
const internal = (l: string) => l.startsWith('/') && !l.startsWith('//');

/** Ссылка баннера: внутренний путь — обычный переход, внешний адрес — новая вкладка с rel=noopener. */
function A({ href, className, children, label }: { href: string; className?: string; children: React.ReactNode; label?: string }) {
  return internal(href)
    ? <Link to={href} className={className} aria-label={label}>{children}</Link>
    : <a href={href} className={className} aria-label={label} target="_blank" rel="noopener noreferrer">{children}</a>;
}

function Item({ b }: { b: Banner }) {
  const target = b.video_url || b.link;
  const img = b.image ? <Img src={thumb(b.image)} alt="" /> : <div className="bnPh" />;
  return (
    <div className="bnItem">
      <div className="bnMedia">
        {img}
        {b.video_url && <A href={b.video_url} className="bnPlay" label={'Смотреть видео: ' + b.title}><I.Play size={16} /></A>}
      </div>
      <div className="bnBody">
        {target ? <A href={b.link || b.video_url} className="bnT clamp2">{b.title}</A> : <div className="bnT clamp2">{b.title}</div>}
        {b.text && <div className="bnX clamp2">{b.text}</div>}
        {b.link && (
          <A href={b.link} className="bnGo">
            {b.link_label || 'Подробнее'}{internal(b.link) ? <I.ChevronRight size={14} /> : <I.External size={13} />}
          </A>
        )}
      </div>
    </div>
  );
}

/**
 * Баннеры: самый верхний блок правой колонки (стиль «Важного»). До 3 баннеров — списком, больше — слайдер с точками
 * и автопрокруткой раз в 7 с (пауза при наведении и фокусе). `strip` — компактная строка над лентой на узких экранах (всегда слайдер).
 * Без баннеров ничего не рисует.
 */
export function Banners({ strip }: { strip?: boolean }) {
  const { data } = useQuery<Banner[]>('banners', () => api.get('/api/banners'), { stale: 60000 });
  const list = data || [];
  const n = list.length;
  const slider = n > 1 && (strip || n > LIST_MAX);
  const [i, setI] = useState(0);
  const [hold, setHold] = useState(false);
  const cur = n ? Math.min(i, n - 1) : 0;
  const reduce = typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches;
  useEffect(() => {
    if (!slider || hold || reduce) return;
    const t = setTimeout(() => setI((x) => (x + 1) % n), AUTO_MS);
    return () => clearTimeout(t);
  }, [cur, n, hold, reduce, slider]);
  if (!n) return null;
  return (
    <section className={cx('card railC bnCard')} aria-label="Баннеры"
      onMouseEnter={() => setHold(true)} onMouseLeave={() => setHold(false)} onFocus={() => setHold(true)} onBlur={() => setHold(false)}>
      {!strip && <h4><I.Image size={17} style={{ color: 'var(--accent)' }} /> Баннеры</h4>}
      {slider ? (
        <>
          <div className="bnList" aria-live="off" style={strip ? undefined : { paddingBottom: 6 }}><Item key={list[cur].id} b={list[cur]} /></div>
          <div className="bnDots" role="tablist">
            {list.map((b, k) => <button type="button" key={b.id} role="tab" aria-selected={k === cur} aria-label={`Баннер ${k + 1}`} className={cx(k === cur && 'on')} onClick={() => setI(k)} />)}
          </div>
        </>
      ) : (
        <div className="bnList">{list.map((b) => <Item key={b.id} b={b} />)}</div>
      )}
    </section>
  );
}
