// Смайлы и стикеры: пикер (вкладки-группы, поиск, «недавние», клавиатура), кнопка для любого поля ввода (EmojiButton),
// обёртки EmojiInput/EmojiTextarea и автодополнение «:сло…» и «@имя» (TextAssist).
//
// Подключение в новом поле — две строки:
//   const ref = useRef<HTMLTextAreaElement>(null);
//   <textarea ref={ref} value={v} onChange={…} />   <EmojiButton target={ref} value={v} onChange={setV} />   <TextAssist target={ref} value={v} onChange={setV} scope="chat" id={chatId} />
// или целиком: <EmojiTextarea value={v} onChange={setV} />.
// В тексте простые смайлы — обычные юникод-символы, анимированные — шорткод :имя: (отрисовывает RichText / Markdown).
import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { api } from '../lib/api';
import { usePersist } from '../lib/persist';
import { cx, useDebounced } from '../lib/util';
import * as X from '../lib/social-icons';
import { Avatar } from './index';
import { EMOJIS, EMOJI_GROUPS, searchEmoji, type Emoji } from './emoji-data';
import { STICKERS, STICKER_BY_NAME, Sticker, searchStickers } from './stickers';
import './social.css';

type El = HTMLInputElement | HTMLTextAreaElement;
const isCode = (s: string) => /^:[a-z0-9_]{1,40}:$/.test(s);

/** Универсальный глиф реакции/смайла: юникод как есть, :имя: — анимированный стикер. */
export function Glyph({ e, size = 20, still }: { e: string; size?: number; still?: boolean }) {
  if (isCode(e) && STICKER_BY_NAME[e.slice(1, -1)]) return <Sticker name={e.slice(1, -1)} size={size + 8} still={still} />;
  return <span className="emjG" style={{ fontSize: size }}>{e}</span>;
}

// ---------------------------------------------------------------- позиционирование
interface Pos { left: number; width: number; top?: number; bottom?: number; max: number }
function place(anchor: DOMRect, w: number, h: number, align: 'start' | 'end' = 'start'): Pos {
  const vw = innerWidth, vh = innerHeight, M = 8;
  const width = Math.min(w, vw - 2 * M);
  let left = align === 'end' ? anchor.right - width : anchor.left;
  left = Math.max(M, Math.min(left, vw - width - M));
  const below = vh - anchor.bottom - M, above = anchor.top - M;
  if (above >= Math.min(h, 300) || above > below) return { left, width, bottom: vh - anchor.top + 6, max: Math.min(h, above - 6) };
  return { left, width, top: anchor.bottom + 6, max: Math.min(h, below - 6) };
}
function useAnchored(anchor: () => HTMLElement | null, open: boolean, w: number, h: number, align: 'start' | 'end' = 'start') {
  const [pos, setPos] = useState<Pos | null>(null);
  const upd = useCallback(() => { const a = anchor(); if (a) setPos(place(a.getBoundingClientRect(), w, h, align)); }, [w, h, align]);
  useLayoutEffect(() => {
    if (!open) return;
    upd();
    addEventListener('resize', upd);
    addEventListener('scroll', upd, true);
    return () => { removeEventListener('resize', upd); removeEventListener('scroll', upd, true); };
  }, [open, upd]);
  return pos;
}

/** Закрытие по клику снаружи и Esc (Esc не доходит до окна — модалка под пикером не закроется). */
function useDismiss(open: boolean, close: () => void, inside: (t: Node) => boolean) {
  useEffect(() => {
    if (!open) return;
    const d = (e: MouseEvent) => { if (!inside(e.target as Node)) close(); };
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
    document.addEventListener('mousedown', d, true);
    document.addEventListener('keydown', k, true);
    return () => { document.removeEventListener('mousedown', d, true); document.removeEventListener('keydown', k, true); };
  }, [open, close]);
}

// ---------------------------------------------------------------- пикер
const TAB_RECENT = 'recent', TAB_STICKERS = 'stickers';
type Tab = string;

export function EmojiPicker({ onPick, style, stickers = true, onClose, className }: { onPick: (v: string, keep: boolean) => void; style?: React.CSSProperties; stickers?: boolean; onClose?: () => void; className?: string }) {
  const [recent, setRecent] = usePersist<string[]>('emoji.recent', []);
  const [tab, setTab] = useState<Tab>(recent.length ? TAB_RECENT : stickers ? TAB_STICKERS : 'smile');
  const [q, setQ] = useState('');
  const dq = useDebounced(q.trim(), 120);
  const [hint, setHint] = useState('');
  const root = useRef<HTMLDivElement>(null);
  const search = useRef<HTMLInputElement>(null);
  useEffect(() => { search.current?.focus({ preventScroll: true }); }, []);

  const found = useMemo(() => (dq ? { st: stickers ? searchStickers(dq) : [], em: searchEmoji(dq) } : null), [dq, stickers]);
  const emojiOf = (g: string) => EMOJIS.filter((x) => x.g === g);

  function pick(v: string, keep: boolean) {
    setRecent((old) => [v, ...old.filter((x) => x !== v)].slice(0, 24));
    onPick(v, keep);
  }
  const cells = () => Array.from(root.current?.querySelectorAll<HTMLElement>('.emjBody [data-cell]') || []);
  function nav(e: React.KeyboardEvent) {
    const k = e.key;
    if (k === 'Escape') { onClose?.(); return; }
    const list = cells();
    const cur = list.indexOf(document.activeElement as HTMLElement);
    if (document.activeElement === search.current) {
      if (k === 'ArrowDown' && list.length) { e.preventDefault(); list[0].focus(); }
      if (k === 'Enter' && list.length) { e.preventDefault(); list[0].click(); }
      return;
    }
    if (cur < 0) return;
    const grid = list[cur].parentElement!;
    const cols = Math.max(1, getComputedStyle(grid).gridTemplateColumns.split(' ').length);
    let next = cur;
    if (k === 'ArrowRight') next = cur + 1;
    else if (k === 'ArrowLeft') next = cur - 1;
    else if (k === 'ArrowDown') next = cur + cols;
    else if (k === 'ArrowUp') next = cur - cols;
    else return;
    e.preventDefault();
    if (next < 0 || (k === 'ArrowUp' && cur < cols)) { search.current?.focus(); return; }
    if (next >= list.length) next = list.length - 1;
    list[next]?.focus();
  }

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    ...(recent.length ? [{ id: TAB_RECENT, label: 'Недавние', icon: '🕘' }] : []),
    ...(stickers ? [{ id: TAB_STICKERS, label: 'Анимированные стикеры', icon: <X.Sparkles size={17} /> }] : []),
    ...EMOJI_GROUPS.map((g) => ({ id: g.id, label: g.label, icon: g.icon })),
  ];

  const eCell = (x: { e: string; n: string }, key?: string) => (
    <button type="button" key={key || x.e} data-cell className="emjCell" title={x.n} aria-label={x.n}
      onMouseEnter={() => setHint(x.n)} onFocus={() => setHint(x.n)} onClick={(ev) => pick(x.e, ev.shiftKey || ev.ctrlKey)}>{x.e}</button>
  );
  const sCell = (s: { name: string; ru: string }) => (
    <button type="button" key={s.name} data-cell className="emjStk" title={s.ru} aria-label={'Стикер: ' + s.ru}
      onMouseEnter={() => setHint(s.ru + ' · :' + s.name + ':')} onFocus={() => setHint(s.ru + ' · :' + s.name + ':')} onClick={(ev) => pick(`:${s.name}:`, ev.shiftKey || ev.ctrlKey)}>
      <Sticker name={s.name} size={64} />
    </button>
  );
  const recentItems = recent.map((v) => (isCode(v) ? STICKER_BY_NAME[v.slice(1, -1)] && { kind: 's' as const, s: STICKER_BY_NAME[v.slice(1, -1)] } : { kind: 'e' as const, x: EMOJIS.find((y) => y.e === v) || { e: v, n: v } })).filter(Boolean) as any[];

  let body: React.ReactNode;
  if (found) {
    body = (found.st.length + found.em.length === 0) ? <div className="emjEmpty">Ничего не найдено по запросу «{dq}»</div> : (
      <>
        {found.st.length > 0 && <><div className="emjH">Стикеры</div><div className="emjGrid stk">{found.st.map(sCell)}</div></>}
        {found.em.length > 0 && <><div className="emjH">Смайлы</div><div className="emjGrid">{found.em.map((x) => eCell(x))}</div></>}
      </>
    );
  } else if (tab === TAB_RECENT) {
    const es = recentItems.filter((r) => r.kind === 'e'), ss = recentItems.filter((r) => r.kind === 's');
    body = (
      <>
        {ss.length > 0 && <div className="emjGrid stk">{ss.map((r) => sCell(r.s))}</div>}
        {es.length > 0 && <div className="emjGrid">{es.map((r) => eCell(r.x))}</div>}
        {recentItems.length > 0 && <button type="button" className="emjClear" onClick={() => { setRecent([]); setTab(stickers ? TAB_STICKERS : 'smile'); }}>Очистить недавние</button>}
      </>
    );
  } else if (tab === TAB_STICKERS) {
    body = <div className="emjGrid stk">{STICKERS.map(sCell)}</div>;
  } else {
    body = <div className="emjGrid">{emojiOf(tab).map((x, i) => eCell(x, x.e + i))}</div>;
  }

  return (
    <div ref={root} className={cx('emj', className)} style={style} role="dialog" aria-label="Смайлы и стикеры" onKeyDown={nav} onMouseDown={(e) => { if ((e.target as HTMLElement).tagName !== 'INPUT') e.preventDefault(); }}>
      <div className="emjSearch">
        <X.Smile size={16} />
        <input ref={search} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск: спасибо, ок, дедлайн, созвон…" aria-label="Поиск смайлов" maxLength={40} />
        {q && <button type="button" className="emjX" aria-label="Очистить поиск" onClick={() => { setQ(''); search.current?.focus(); }}>×</button>}
      </div>
      {!found && (
        <div className="emjTabs" role="tablist">
          {tabs.map((t) => <button key={t.id} type="button" role="tab" aria-selected={tab === t.id} aria-label={t.label} title={t.label} className={cx(tab === t.id && 'on')} onClick={() => setTab(t.id)}>{t.icon}</button>)}
        </div>
      )}
      <div className="emjBody" role="tabpanel">{!found && <div className="emjH">{tabs.find((t) => t.id === tab)?.label}</div>}{body}</div>
      <div className="emjFoot">{hint || 'Shift — не закрывать после выбора'}</div>
    </div>
  );
}

// ---------------------------------------------------------------- вставка в позицию курсора
export function insertAt(el: El, value: string, tok: string, onChange: (v: string) => void) {
  const a = el.selectionStart ?? value.length, b = el.selectionEnd ?? a;
  let ins = tok;
  if (isCode(tok)) { // шорткод отделяем пробелами, чтобы он не слипался со словами
    if (a > 0 && !/\s/.test(value[a - 1])) ins = ' ' + ins;
    if (!/^\s/.test(value.slice(b))) ins += ' ';
  }
  const nv = value.slice(0, a) + ins + value.slice(b);
  if (el.maxLength > 0 && nv.length > el.maxLength) return;
  onChange(nv);
  const pos = a + ins.length;
  requestAnimationFrame(() => { el.focus({ preventScroll: true }); try { el.setSelectionRange(pos, pos); } catch {} });
}

export function EmojiButton({ target, value, onChange, onPick, title = 'Смайлы и стикеры', stickers = true, className, size = 18, align = 'start', disabled, kind = 'ghost' }: {
  target?: React.RefObject<El | null>; value?: string; onChange?: (v: string) => void; onPick?: (v: string) => void; title?: string; stickers?: boolean; className?: string; size?: number; align?: 'start' | 'end'; disabled?: boolean; kind?: 'ghost' | 'plain';
}) {
  const [open, setOpen] = useState(false);
  const btn = useRef<HTMLButtonElement>(null);
  const pop = useRef<HTMLDivElement>(null);
  const pos = useAnchored(() => btn.current, open, 360, 400, align);
  const close = useCallback(() => { setOpen(false); target?.current?.focus({ preventScroll: true }); }, [target]);
  useDismiss(open, () => setOpen(false), (t) => !!(btn.current?.contains(t) || pop.current?.contains(t)));
  function pick(v: string, keep: boolean) {
    if (onPick) onPick(v);
    else if (target?.current && onChange) insertAt(target.current, value ?? target.current.value, v, onChange);
    if (!keep) close();
  }
  return (
    <>
      <button ref={btn} type="button" className={cx(kind === 'ghost' ? 'btn ghost icon' : 'emjPlain', 'emjBtn', open && 'on', className)} title={title} aria-label={title} aria-haspopup="dialog" aria-expanded={open}
        disabled={disabled} onMouseDown={(e) => e.preventDefault()} onClick={() => setOpen((o) => !o)}><X.Smile size={size} /></button>
      {open && pos && createPortal(
        <div ref={pop} className="emjLayer" style={{ left: pos.left, width: pos.width, top: pos.top, bottom: pos.bottom, maxHeight: pos.max }}>
          <EmojiPicker onPick={pick} stickers={stickers} onClose={close} />
        </div>, document.body)}
    </>
  );
}

// ---------------------------------------------------------------- обёртки полей
type InputProps = Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'value'> & { value: string; onChange: (v: string) => void; stickers?: boolean };
/** Однострочное поле со смайлами (кнопка справа внутри поля). */
export const EmojiInput = React.forwardRef<HTMLInputElement, InputProps>(({ value, onChange, stickers = false, className, style, ...p }, fwd) => {
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => { if (typeof fwd === 'function') fwd(ref.current); else if (fwd) fwd.current = ref.current; });
  return (
    <div className="emjField" style={style}>
      <input ref={ref} className={cx('inp', className)} value={value} onChange={(e) => onChange(e.target.value)} {...p} style={{ paddingRight: 38 }} />
      <EmojiButton target={ref} value={value} onChange={onChange} stickers={stickers} kind="plain" align="end" />
    </div>
  );
});

type TaProps = Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, 'onChange' | 'value'> & { value: string; onChange: (v: string) => void; scope?: string; id?: number; mentions?: boolean };
/** Многострочное поле со смайлами и (необязательно) @-упоминаниями. */
export const EmojiTextarea = React.forwardRef<HTMLTextAreaElement, TaProps>(({ value, onChange, scope, id, mentions, className, ...p }, fwd) => {
  const ref = useRef<HTMLTextAreaElement>(null);
  useEffect(() => { if (typeof fwd === 'function') fwd(ref.current); else if (fwd) fwd.current = ref.current; });
  return (
    <div className="emjField ta">
      <textarea ref={ref} className={cx('txt', className)} value={value} onChange={(e) => onChange(e.target.value)} {...p} />
      <EmojiButton target={ref} value={value} onChange={onChange} kind="plain" align="end" />
      <TextAssist target={ref} value={value} onChange={onChange} scope={scope} id={id} mentions={mentions} />
    </div>
  );
});

// ---------------------------------------------------------------- автодополнение «:сло…» и «@имя»
interface Sug { key: string; kind: 'user' | 'sticker' | 'emoji'; label: string; sub: string; ins: string; user?: { name: string; avatar: string }; glyph?: string; sticker?: string }
const MENTION_RE = /(^|[^\p{L}\p{N}_@.+%-])@([\p{L}\p{N}_.-]{0,30})$/u;
const CODE_RE = /(^|\s):([\p{L}\p{N}_]{2,24})$/u;

export function TextAssist({ target, value, onChange, scope, id, mentions = true, codes = true }: {
  target: React.RefObject<El | null>; value: string; onChange: (v: string) => void; scope?: string; id?: number; mentions?: boolean; codes?: boolean;
}) {
  const [st, setSt] = useState<{ kind: 'mention' | 'code'; start: number; end: number; q: string } | null>(null);
  const [users, setUsers] = useState<Sug[]>([]);
  const [sel, setSel] = useState(0);
  const items: Sug[] = useMemo(() => {
    if (!st) return [];
    if (st.kind === 'mention') return users;
    const out: Sug[] = [];
    const q = st.q.toLowerCase().replace(/ё/g, 'е');
    for (const s of searchStickers(q).slice(0, 5)) out.push({ key: 's' + s.name, kind: 'sticker', label: s.ru, sub: ':' + s.name + ':', ins: ':' + s.name + ':', sticker: s.name });
    for (const x of searchEmoji(q).slice(0, 8 - out.length)) out.push({ key: 'e' + x.e, kind: 'emoji', label: x.n, sub: x.e, ins: x.e, glyph: x.e });
    return out;
  }, [st, users]);
  const R = useRef({ st, items, sel, value, onChange });
  R.current = { st, items, sel, value, onChange };
  const dq = useDebounced(st?.kind === 'mention' ? st.q : null, 130);

  // подсказки людей с сервера
  useEffect(() => {
    if (!mentions || dq == null) { setUsers([]); return; }
    let dead = false;
    api.get<any[]>(`/api/mentions/suggest?q=${encodeURIComponent(dq)}${scope ? `&scope=${scope}&id=${id || 0}` : ''}`).then((r) => {
      if (dead) return;
      setUsers(r.map((u) => ({ key: 'u' + u.id, kind: 'user', label: u.name, sub: '@' + u.login + (u.job_title ? ' · ' + u.job_title : ''), ins: '@' + u.login, user: { name: u.name, avatar: u.avatar } })));
      setSel(0);
    }).catch(() => !dead && setUsers([]));
    return () => { dead = true; };
  }, [dq, scope, id, mentions]);

  const detect = useCallback(() => {
    const el = target.current;
    if (!el || document.activeElement !== el || el.selectionStart !== el.selectionEnd) { setSt(null); return; }
    const caret = el.selectionStart ?? 0;
    const before = el.value.slice(0, caret);
    let m: RegExpExecArray | null;
    if (mentions && (m = MENTION_RE.exec(before))) {
      setSt((o) => (o && o.kind === 'mention' && o.q === m![2] && o.start === caret - m![2].length - 1 ? o : { kind: 'mention', start: caret - m![2].length - 1, end: caret, q: m![2] }));
    } else if (codes && (m = CODE_RE.exec(before))) {
      setSt((o) => { if (!(o && o.kind === 'code' && o.q === m![2])) setSel(0); return { kind: 'code', start: caret - m![2].length - 1, end: caret, q: m![2] }; });
    } else setSt(null);
  }, [target, mentions, codes]);

  const choose = useCallback((i: number) => {
    const { st, items, value, onChange } = R.current;
    const it = items[i];
    const el = target.current;
    if (!st || !it || !el) return;
    const rep = it.ins + (it.kind === 'emoji' ? '' : ' ');
    const nv = value.slice(0, st.start) + rep + value.slice(st.end);
    if (el.maxLength > 0 && nv.length > el.maxLength) return;
    onChange(nv);
    setSt(null); setUsers([]);
    const pos = st.start + rep.length;
    requestAnimationFrame(() => { el.focus({ preventScroll: true }); try { el.setSelectionRange(pos, pos); } catch {} });
  }, [target]);

  useEffect(() => {
    const el = target.current;
    if (!el) return;
    const kd = (e: KeyboardEvent) => {
      const { st, items, sel } = R.current;
      if (!st || !items.length || e.isComposing) return;
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); e.stopPropagation(); setSel((sel + (e.key === 'ArrowDown' ? 1 : items.length - 1)) % items.length); }
      else if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); e.stopPropagation(); choose(sel); }
      else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); setSt(null); }
    };
    const ku = (e: KeyboardEvent) => { if (!['ArrowDown', 'ArrowUp', 'Enter', 'Tab', 'Escape'].includes(e.key)) detect(); else if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') detect(); };
    const off = () => setSt(null);
    el.addEventListener('keydown', kd, true);
    el.addEventListener('keyup', ku);
    el.addEventListener('input', detect);
    el.addEventListener('click', detect);
    el.addEventListener('blur', off);
    return () => { el.removeEventListener('keydown', kd, true); el.removeEventListener('keyup', ku); el.removeEventListener('input', detect); el.removeEventListener('click', detect); el.removeEventListener('blur', off); };
  }, [target, detect, choose]);

  const open = !!st && items.length > 0;
  const pos = useAnchored(() => target.current, open, 320, 280);
  if (!open || !pos) return null;
  return createPortal(
    <div className="sgst" role="listbox" aria-label={st!.kind === 'mention' ? 'Упомянуть' : 'Смайлы'} style={{ left: pos.left, width: Math.min(pos.width, 320), top: pos.top, bottom: pos.bottom, maxHeight: pos.max }}
      onMouseDown={(e) => e.preventDefault()}>
      {items.map((it, i) => (
        <button type="button" key={it.key} role="option" aria-selected={i === sel} className={cx('sgRow', i === sel && 'on')} onMouseEnter={() => setSel(i)} onClick={() => choose(i)}>
          {it.user ? <Avatar name={it.user.name} src={it.user.avatar} size={28} /> : it.sticker ? <Sticker name={it.sticker} size={32} still /> : <span className="sgE">{it.glyph}</span>}
          <span className="sgT"><b>{it.label}</b><i>{it.sub}</i></span>
        </button>
      ))}
    </div>, document.body);
}

export type { Emoji };
