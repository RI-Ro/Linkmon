// Анимированные стикеры портала: лёгкие inline-SVG, без внешних файлов. Цвет круга — переменные темы (--accent, --ok, --warn, --danger),
// поэтому стикеры одинаково выглядят во всех темах. Анимируются только transform/opacity; анимация включается лишь у стикеров на экране
// (общий IntersectionObserver) и отключается при prefers-reduced-motion (см. social.css).
// В тексте хранятся как шорткод :имя: (латиница a-z0-9_).
import React, { useEffect, useRef } from 'react';

export type Tone = 'accent' | 'accent2' | 'ok' | 'warn' | 'danger';
export interface StickerDef { name: string; ru: string; label: string; kw: string; tone: Tone; art: () => React.ReactNode }

const W = '#fff';
const Y = '#ffd43b';
const S = { fill: 'none', stroke: W, strokeWidth: 5, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const SOFT = { fill: W, fillOpacity: 0.55 } as const;
const TONE: React.CSSProperties = { fill: 'var(--stk)' };
const TONE_S: React.CSSProperties = { stroke: 'var(--stk)', fill: 'none' };
const HEART = 'M24 43C8 31 4 23 4 15A10 10 0 0 1 24 12A10 10 0 0 1 44 15C44 23 40 31 24 43Z';
const STAR = 'M24 3l6.2 13.4 14.6 1.7-10.9 9.9 3 14.5L24 34.7 11.1 42.5l3-14.5L3.2 18.1l14.6-1.7z';

const sparkle = (x: number, y: number, s = 1, cls = 'a-twinkle', fill = W) => (
  <path className={cls} transform={`translate(${x} ${y}) scale(${s})`} d="M0 -6 L1.6 -1.6 L6 0 L1.6 1.6 L0 6 L-1.6 1.6 L-6 0 L-1.6 -1.6Z" fill={fill} />
);

/** Стикеры. Порядок = порядок в пикере. ru — название для поиска и подсказки, label — надпись на ленте. */
export const STICKERS: StickerDef[] = [
  { name: 'thanks', ru: 'Спасибо', label: 'СПАСИБО', kw: 'спасибо благодарю благодарность thanks', tone: 'accent', art: () => (<>
    <g transform="translate(13 -1) scale(.55)"><path className="a-beat" d={HEART} fill={W} /></g>
    <path d="M3 29C9 40 17 44 24 40 31 44 39 40 45 29" {...S} /><path d="M10 38l-5 6M38 38l5 6" {...S} strokeWidth={3.5} />
  </>) },
  { name: 'ok', ru: 'Ок', label: 'ОК', kw: 'ок окей okay хорошо принято понял договорились', tone: 'ok', art: () => (<>
    <circle cx="24" cy="24" r="20" {...S} strokeWidth={4} /><text className="a-pop" x="24" y="32" textAnchor="middle" fontSize="23" fontWeight="900" fill={W} style={{ fontFamily: 'var(--font)' }}>OK</text>
  </>) },
  { name: 'bravo', ru: 'Молодец', label: 'МОЛОДЕЦ', kw: 'молодец отлично класс супер хорошая работа так держать лайк', tone: 'accent', art: () => (<g className="a-wobble">
    <rect x="3" y="21" width="9" height="22" rx="2.5" fill={W} /><path d="M16 22L25 5c4-1 8 2 7 6l-2 7h11a4 4 0 0 1 4 5l-3 15a5 5 0 0 1-5 4H16Z" fill={W} />
  </g>) },
  { name: 'working', ru: 'В работе', label: 'В РАБОТЕ', kw: 'в работе делаю процесс занят шестерёнка настройка', tone: 'accent', art: () => (<>
    <g className="a-spin"><circle cx="24" cy="24" r="17" fill="none" stroke={W} strokeWidth={7} strokeDasharray="6.7 6.65" /><circle cx="24" cy="24" r="14" fill={W} /><circle cx="24" cy="24" r="6" style={TONE} /></g>
  </>) },
  { name: 'done', ru: 'Готово', label: 'ГОТОВО', kw: 'готово выполнено сделано завершено закрыто галочка done', tone: 'ok', art: () => (<>
    <circle cx="24" cy="24" r="20" fill={W} fillOpacity={0.25} /><path className="a-pop" d="M10 25l9 10 19-21" {...S} strokeWidth={7} />
  </>) },
  { name: 'urgent', ru: 'Срочно', label: 'СРОЧНО', kw: 'срочно сирена важно внимание горит тревога', tone: 'danger', art: () => (<>
    <rect x="7" y="35" width="34" height="8" rx="3" fill={W} /><path className="a-blink" d="M11 35V27a13 13 0 0 1 26 0v8Z" fill={W} /><path d="M17 31v-4a7 7 0 0 1 5-6.5" style={TONE_S} strokeWidth={3} strokeLinecap="round" />
    <path className="a-blink d2" d="M24 2v6M8 7l4 4M40 7l-4 4" {...S} strokeWidth={3.5} />
  </>) },
  { name: 'call', ru: 'Созвон', label: 'СОЗВОН', kw: 'созвон звонок позвонить телефон трубка связь', tone: 'accent', art: () => (<>
    <path className="a-shake" d="M12 8c-3 0-6 3-5 8 3 14 14 24 26 26 5 1 8-2 8-5l-1-5-9-2-3 4c-5-2-9-6-11-11l4-3-2-9Z" fill={W} />
    <path className="a-twinkle" d="M28 6a14 14 0 0 1 14 14M28 14a6 6 0 0 1 6 6" {...S} strokeWidth={3.5} />
  </>) },
  { name: 'video', ru: 'Видеозвонок', label: 'ВИДЕОСВЯЗЬ', kw: 'видеозвонок видео камера конференция встреча онлайн', tone: 'accent2', art: () => (<>
    <rect x="3" y="11" width="29" height="26" rx="6" fill={W} /><path d="M35 20l10-6v20l-10-6Z" fill={W} /><circle className="a-blink" cx="10" cy="18" r="2.6" style={{ fill: 'var(--danger)' }} />
  </>) },
  { name: 'idea', ru: 'Идея', label: 'ИДЕЯ', kw: 'идея лампочка придумал решение мысль озарение', tone: 'warn', art: () => (<>
    <path className="a-glow" d="M24 4a14 14 0 0 1 8 25v4H16v-4A14 14 0 0 1 24 4Z" fill={Y} /><path d="M18 38h12M20 43h8" {...S} strokeWidth={4} />
    <path className="a-twinkle" d="M24 -3v0M5 8l3 3M43 8l-3 3M1 22h4M43 22h4" {...S} strokeWidth={3} />
  </>) },
  { name: 'congrats', ru: 'Поздравляю', label: 'ПОЗДРАВЛЯЮ', kw: 'поздравляю поздравление праздник хлопушка конфетти с днём рождения', tone: 'danger', art: () => (<>
    <path d="M4 44L14 16l18 18Z" fill={W} /><path d="M10 30l8 8M7 38l5 5" style={TONE_S} strokeWidth={2.5} />
    <rect className="a-conf" x="26" y="6" width="5" height="9" rx="1.5" fill={Y} /><circle className="a-conf d2" cx="38" cy="14" r="3" fill={W} /><rect className="a-conf d3" x="20" y="4" width="4" height="7" rx="1.5" fill={W} fillOpacity={0.7} />
    <circle className="a-conf d4" cx="42" cy="28" r="2.6" fill={Y} /><rect className="a-conf d5" x="34" y="24" width="4" height="7" rx="1.5" fill={W} />
  </>) },
  { name: 'coffee', ru: 'Кофе-брейк', label: 'КОФЕ-БРЕЙК', kw: 'кофе брейк перерыв чай пауза перекур отдых', tone: 'warn', art: () => (<>
    <path d="M7 19h27v9a11 11 0 0 1-11 11h-5A11 11 0 0 1 7 28Z" fill={W} /><path d="M34 22h3a5 5 0 0 1 0 10h-4" {...S} strokeWidth={4} /><path d="M5 44h31" {...S} strokeWidth={4} />
    <path className="a-rise" d="M14 14q-3-4 0-8" {...S} strokeWidth={3} /><path className="a-rise d2" d="M21 14q-3-4 0-8" {...S} strokeWidth={3} /><path className="a-rise d3" d="M28 14q-3-4 0-8" {...S} strokeWidth={3} />
  </>) },
  { name: 'rocket', ru: 'Ракета', label: 'РАКЕТА', kw: 'ракета запуск старт релиз выпустили полетели', tone: 'accent', art: () => (<g className="a-float">
    <path d="M24 2c9 6 12 17 9 30H15C12 19 15 8 24 2Z" fill={W} /><circle cx="24" cy="17" r="4.5" style={TONE} /><path d="M15 25L6 38l10-3ZM33 25l9 13-10-3Z" fill={W} fillOpacity={0.8} />
    <path className="a-flame" d="M19 35h10l-5 12Z" fill={Y} />
  </g>) },
  { name: 'goal', ru: 'Цель', label: 'ЦЕЛЬ', kw: 'цель мишень попали план достигли задача target', tone: 'danger', art: () => (<>
    <circle className="a-ring" cx="22" cy="26" r="18" {...S} strokeWidth={4} /><circle className="a-ring d2" cx="22" cy="26" r="10" {...S} strokeWidth={4} /><circle cx="22" cy="26" r="3.5" fill={W} />
    <path className="a-pop" d="M22 26L43 5M43 5l-1 8m1-8l-8 1" {...S} strokeWidth={3.5} />
  </>) },
  { name: 'applause', ru: 'Аплодисменты', label: 'БРАВО', kw: 'аплодисменты хлопаю браво овации ура молодцы', tone: 'warn', art: () => (<>
    <g className="a-clapL"><rect x="6" y="14" width="13" height="28" rx="6.5" fill={W} transform="rotate(-16 12 28)" /></g>
    <g className="a-clapR"><rect x="29" y="14" width="13" height="28" rx="6.5" fill={W} transform="rotate(16 36 28)" /></g>
    <path className="a-twinkle" d="M24 2v7M13 5l2 4M35 5l-2 4" {...S} strokeWidth={3} />
  </>) },
  { name: 'heart', ru: 'Сердце', label: 'ЛЮБЛЮ', kw: 'сердце сердечко люблю любовь нравится лайк', tone: 'danger', art: () => (<path className="a-beat" d={HEART} fill={W} />) },
  { name: 'fire', ru: 'Огонь', label: 'ОГОНЬ', kw: 'огонь пламя горячо хит круто топ жарко', tone: 'warn', art: () => (<g className="a-flame">
    <path d="M24 2c2 10 14 14 14 28a14 14 0 0 1-28 0c0-6 3-9 5-12 1 4 3 5 5 5-2-8 0-14 4-21Z" fill={W} /><path d="M24 44a8 8 0 0 1-8-8c0-4 3-6 5-9 1 2 2 3 4 3 4-1 1-6 3-9 4 5 4 9 4 15a8 8 0 0 1-8 8Z" fill={Y} />
  </g>) },
  { name: 'thinking', ru: 'Думаю', label: 'ДУМАЮ', kw: 'думаю размышляю мысль облако подумаю вопрос', tone: 'accent2', art: () => (<>
    <path d="M12 38a9 9 0 0 1-1-17 11 11 0 0 1 20-4 9 9 0 0 1 12 8 8 8 0 0 1-7 13Z" fill={W} />
    <circle className="a-dot" cx="17" cy="27" r="3" style={TONE} /><circle className="a-dot d2" cx="25" cy="27" r="3" style={TONE} /><circle className="a-dot d3" cx="33" cy="27" r="3" style={TONE} />
    <circle cx="9" cy="44" r="3" fill={W} fillOpacity={0.7} /><circle cx="14" cy="41" r="2" fill={W} fillOpacity={0.7} />
  </>) },
  { name: 'hooray', ru: 'Ура', label: 'УРА!', kw: 'ура победа успех получилось праздник салют', tone: 'danger', art: () => (<>
    <path className="a-pop" d={STAR} fill={Y} transform="translate(0 3)" />{sparkle(5, 8, 1, 'a-twinkle')}{sparkle(43, 12, 0.8, 'a-twinkle d2')}{sparkle(40, 42, 0.9, 'a-twinkle d3')}{sparkle(8, 40, 0.7, 'a-twinkle d4')}
  </>) },
  { name: 'deadline', ru: 'Дедлайн', label: 'ДЕДЛАЙН', kw: 'дедлайн срок время песочные часы горят сроки', tone: 'danger', art: () => (<>
    <g className="a-flip"><path d="M10 4h28M10 44h28" {...S} strokeWidth={4.5} /><path d="M13 5c0 13 11 14 11 19 0 5-11 6-11 19M35 5c0 13-11 14-11 19 0 5 11 6 11 19" {...S} strokeWidth={3.5} /><path d="M18 40c3-4 9-4 12 0Z" fill={W} /></g>
  </>) },
  { name: 'approved', ru: 'Одобрено', label: 'ОДОБРЕНО', kw: 'одобрено согласовано утверждено печать штамп approved', tone: 'ok', art: () => (<>
    <rect x="6" y="3" width="29" height="39" rx="4" fill={W} fillOpacity={0.9} /><path d="M12 12h17M12 19h17M12 26h10" style={TONE_S} strokeWidth={3} strokeLinecap="round" />
    <g className="a-stamp"><circle cx="34" cy="33" r="13" style={{ fill: 'var(--stk)', stroke: W }} strokeWidth={3.5} /><path d="M28 33l5 5 8-10" {...S} strokeWidth={4} /></g>
  </>) },
  { name: 'review', ru: 'На согласовании', label: 'СОГЛАСОВАНИЕ', kw: 'на согласовании согласование проверка ждёт ожидание рассматривается', tone: 'warn', art: () => (<>
    <rect x="6" y="3" width="29" height="39" rx="4" fill={W} fillOpacity={0.9} /><path d="M12 12h17M12 19h17M12 26h10" style={TONE_S} strokeWidth={3} strokeLinecap="round" />
    <circle cx="34" cy="33" r="13" style={{ fill: 'var(--stk)', stroke: W }} strokeWidth={3.5} /><path className="a-spin" d="M34 25v8l5 3" {...S} strokeWidth={3.5} />
  </>) },
  { name: 'vacation', ru: 'Отпуск', label: 'ОТПУСК', kw: 'отпуск пальма море пляж отдых каникулы солнце', tone: 'warn', art: () => (<>
    <g className="a-spin slow"><circle cx="38" cy="10" r="6" fill={Y} /><path d="M38 0v2M38 18v2M28 10h2M46 10h2M31 3l1.5 1.5M43.5 15.5L45 17M31 17l1.5-1.5M43.5 4.5L45 3" {...S} stroke={Y} strokeWidth={2.2} /></g>
    <path d="M22 44c0-12 1-20 4-27" {...S} strokeWidth={4} /><g className="a-sway"><path d="M26 17c-6-8-14-6-19-2 8-2 12 0 19 2ZM26 17c5-9 13-9 18-6-8 0-13 3-18 6ZM26 17c-2-7 1-13 5-15-1 6-2 10-5 15ZM26 17c-8-1-12 3-14 8 5-4 9-6 14-8Z" fill={W} /></g>
    <path d="M4 44q5-4 10 0t10 0 10 0 10 0" {...S} strokeWidth={3} />
  </>) },
  { name: 'hello', ru: 'Привет', label: 'ПРИВЕТ', kw: 'привет здравствуйте добрый день приветствие рука машу', tone: 'accent', art: () => (<g className="a-wave">
    <rect x="9" y="17" width="6" height="19" rx="3" fill={W} /><rect x="17" y="8" width="6" height="25" rx="3" fill={W} /><rect x="25" y="9" width="6" height="25" rx="3" fill={W} /><rect x="33" y="14" width="6" height="21" rx="3" fill={W} />
    <path d="M9 30c-3 0-5 3-4 6l4 7c3 4 8 5 14 5 8 0 15-5 15-14v-4h-6l-2 7H20Z" fill={W} />
  </g>) },
  { name: 'agreed', ru: 'Договорились', label: 'ДОГОВОРИЛИСЬ', kw: 'договорились рукопожатие сделка согласен партнёры договор', tone: 'ok', art: () => (<>
    <path className="a-shakeS" d="M2 20l9-6 10 3 8-3 8 5 8-3v14l-8 3-8-1-9 8-9-8-7-3Z" fill={W} fillOpacity={0.9} /><path d="M18 30l5 5M24 27l6 6" style={TONE_S} strokeWidth={2.6} strokeLinecap="round" />
  </>) },
  { name: 'plusone', ru: 'Плюс один', label: 'ПЛЮС ОДИН', kw: 'плюс один +1 поддерживаю согласен тоже за', tone: 'ok', art: () => (<>
    <text className="a-pop" x="24" y="35" textAnchor="middle" fontSize="30" fontWeight="900" fill={W} style={{ fontFamily: 'var(--font)' }}>+1</text>
  </>) },
  { name: 'star', ru: 'Звезда', label: 'ЗВЕЗДА', kw: 'звезда лучший избранное оценка пять звёзд', tone: 'warn', art: () => (<><path className="a-spinPop" d={STAR} fill={Y} />{sparkle(40, 6, 0.8)}{sparkle(7, 38, 0.7, 'a-twinkle d3')}</>) },
  { name: 'trophy', ru: 'Победа', label: 'ПОБЕДА', kw: 'победа кубок победитель чемпион первое место трофей', tone: 'warn', art: () => (<g className="a-bounce">
    <path d="M12 4h24v14a12 12 0 0 1-24 0Z" fill={Y} /><path d="M12 8H5c0 8 3 12 8 13M36 8h7c0 8-3 12-8 13" {...S} stroke={Y} strokeWidth={3.5} /><path d="M24 30v8M15 44h18l-2-6H17Z" fill={Y} stroke={Y} strokeWidth={2} strokeLinejoin="round" />
  </g>) },
  { name: 'lightning', ru: 'Быстро', label: 'БЫСТРО', kw: 'быстро молния скорость мгновенно оперативно энергия', tone: 'warn', art: () => (<path className="a-flicker" d="M28 2L9 27h12l-4 19 22-27H26Z" fill={Y} />) },
  { name: 'super', ru: 'Супер', label: 'СУПЕР', kw: 'супер блеск отлично вау великолепно искры', tone: 'accent2', art: () => (<>{sparkle(21, 25, 3.4, 'a-pop')}{sparkle(39, 10, 1.3, 'a-twinkle d2')}{sparkle(38, 38, 1.1, 'a-twinkle d3')}{sparkle(8, 8, 0.9, 'a-twinkle d4')}</>) },
  { name: 'crown', ru: 'Лучший', label: 'ЛУЧШИЙ', kw: 'лучший корона король первый топ сотрудник месяца', tone: 'warn', art: () => (<g className="a-bounce">
    <path d="M4 36L7 12l12 12 5-16 5 16 12-12 3 24Z" fill={Y} /><rect x="4" y="38" width="40" height="6" rx="2.5" fill={Y} /><circle cx="7" cy="11" r="3" fill={W} /><circle cx="24" cy="7" r="3" fill={W} /><circle cx="41" cy="11" r="3" fill={W} />
  </g>) },
  { name: 'medal', ru: 'Награда', label: 'НАГРАДА', kw: 'награда медаль достижение премия заслуга', tone: 'accent', art: () => (<>
    <path d="M12 2l8 18M36 2l-8 18" {...S} strokeWidth={5} /><g className="a-swingS"><circle cx="24" cy="31" r="13" fill={Y} /><circle cx="24" cy="31" r="8.5" fill="none" stroke="var(--stk)" strokeWidth={2} strokeOpacity={0.5} /><path d={STAR} fill={W} transform="translate(14 21) scale(.42)" /></g>
  </>) },
  { name: 'gift', ru: 'Подарок', label: 'ПОДАРОК', kw: 'подарок бонус презент сюрприз премия', tone: 'danger', art: () => (<g className="a-bounce">
    <rect x="5" y="19" width="38" height="25" rx="3" fill={W} /><rect x="3" y="12" width="42" height="9" rx="3" fill={W} fillOpacity={0.85} /><path d="M24 12v32" style={TONE_S} strokeWidth={5} /><path d="M24 12c-8-2-12-9-7-10 5-1 7 5 7 10ZM24 12c8-2 12-9 7-10-5-1-7 5-7 10Z" fill={W} />
  </g>) },
  { name: 'attention', ru: 'Внимание', label: 'ВНИМАНИЕ', kw: 'внимание колокольчик напоминание уведомление звонок', tone: 'warn', art: () => (<g className="a-swing">
    <path d="M24 3a3 3 0 0 1 3 3v1a13 13 0 0 1 10 12v9l5 6H5l5-6v-9A13 13 0 0 1 21 7V6a3 3 0 0 1 3-3Z" fill={W} /><path d="M19 41a5 5 0 0 0 10 0" {...S} strokeWidth={4} />
  </g>) },
  { name: 'mail', ru: 'Письмо', label: 'ПИСЬМО', kw: 'письмо почта сообщение email конверт входящее', tone: 'accent', art: () => (<>
    <rect x="3" y="10" width="42" height="30" rx="5" fill={W} /><path className="a-pop" d="M5 14l19 15 19-15" style={TONE_S} strokeWidth={3.5} strokeLinejoin="round" strokeLinecap="round" />
  </>) },
  { name: 'sent', ru: 'Отправлено', label: 'ОТПРАВЛЕНО', kw: 'отправлено отправил самолётик письмо отправка', tone: 'ok', art: () => (<g className="a-fly">
    <path d="M3 22L45 4 33 44 22 30Z" fill={W} /><path d="M22 30l23-26L13 25" style={TONE_S} strokeWidth={2.5} strokeLinejoin="round" />
  </g>) },
  { name: 'meeting', ru: 'Встреча', label: 'ВСТРЕЧА', kw: 'встреча совещание планёрка собрание митинг переговорка', tone: 'accent', art: () => (<>
    <circle className="a-bob" cx="24" cy="12" r="7" fill={W} /><path d="M10 38a14 11 0 0 1 28 0Z" fill={W} /><circle className="a-bob d2" cx="8" cy="19" r="5" fill={W} fillOpacity={0.7} /><circle className="a-bob d3" cx="40" cy="19" r="5" fill={W} fillOpacity={0.7} />
    <path d="M0 38a8 7 0 0 1 12-6M48 38a8 7 0 0 0-12-6" fill="none" stroke={W} strokeOpacity={0.7} strokeWidth={4} strokeLinecap="round" />
  </>) },
  { name: 'today', ru: 'Сегодня', label: 'СЕГОДНЯ', kw: 'сегодня календарь дата день расписание план', tone: 'danger', art: () => (<>
    <rect x="4" y="7" width="40" height="37" rx="5" fill={W} /><path d="M4 18v-6a5 5 0 0 1 5-5h30a5 5 0 0 1 5 5v6Z" fill={W} fillOpacity={0.75} style={{ fill: 'var(--stk)' }} /><path d="M14 3v8M34 3v8" {...S} strokeWidth={4} />
    <rect className="a-pop" x="17" y="23" width="14" height="14" rx="3" style={TONE} />
  </>) },
  { name: 'talk', ru: 'Доклад', label: 'ДОКЛАД', kw: 'доклад выступление микрофон презентация спикер вебинар', tone: 'accent2', art: () => (<g className="a-wobble">
    <rect x="16" y="2" width="16" height="26" rx="8" fill={W} /><path d="M9 22a15 15 0 0 0 30 0M24 37v7M16 44h16" {...S} strokeWidth={4} />
  </g>) },
  { name: 'learn', ru: 'Обучение', label: 'ОБУЧЕНИЕ', kw: 'обучение книга учёба знания курс материал читаю', tone: 'accent', art: () => (<>
    <path className="a-page" d="M24 12C17 7 9 7 3 9v31c6-2 14-2 21 3Z" fill={W} /><path d="M24 12c7-5 15-5 21-3v31c-6-2-14-2-21 3Z" fill={W} fillOpacity={0.8} />
  </>) },
  { name: 'diploma', ru: 'Диплом', label: 'ДИПЛОМ', kw: 'диплом выпускник сертификат обучение окончил шапочка', tone: 'accent2', art: () => (<g className="a-bob">
    <path d="M24 5L2 16l22 11 22-11Z" fill={W} /><path d="M11 22v10c0 5 26 5 26 0V22l-13 6Z" fill={W} fillOpacity={0.8} /><path d="M43 18v14" {...S} strokeWidth={3} /><circle cx="43" cy="35" r="3" fill={Y} />
  </g>) },
  { name: 'growth', ru: 'Рост', label: 'РОСТ', kw: 'рост прибыль график вверх показатели увеличение успех', tone: 'ok', art: () => (<>
    <rect className="a-bar" x="5" y="30" width="9" height="14" rx="2" fill={W} fillOpacity={0.75} /><rect className="a-bar d2" x="19" y="22" width="9" height="22" rx="2" fill={W} fillOpacity={0.85} /><rect className="a-bar d3" x="33" y="12" width="9" height="32" rx="2" fill={W} />
    <path className="a-pop" d="M5 20L18 9l8 6 16-12M34 3h8v8" {...S} strokeWidth={3.5} />
  </>) },
  { name: 'bonus', ru: 'Бонус', label: 'БОНУС', kw: 'бонус деньги премия рубль монета зарплата выплата', tone: 'warn', art: () => (<g className="a-coin">
    <circle cx="24" cy="24" r="20" fill={Y} /><circle cx="24" cy="24" r="15" fill="none" stroke="var(--stk)" strokeOpacity={0.45} strokeWidth={2} /><text x="24" y="33" textAnchor="middle" fontSize="24" fontWeight="900" style={{ fontFamily: 'var(--font)', fill: 'var(--stk)' }}>₽</text>
  </g>) },
  { name: 'milestone', ru: 'Веха', label: 'ВЕХА', kw: 'веха этап флаг достижение рубеж milestone финиш', tone: 'ok', art: () => (<>
    <path d="M10 3v42" {...S} strokeWidth={4.5} /><path className="a-flag" d="M10 6h30l-7 10 7 10H10Z" fill={W} />
  </>) },
  { name: 'important', ru: 'Важно', label: 'ВАЖНО', kw: 'важно закреплено кнопка метка заметка не забыть', tone: 'danger', art: () => (<g className="a-wobble">
    <path d="M14 3h20l-3 4v12l7 8H10l7-8V7Z" fill={W} /><path d="M24 27v18" {...S} strokeWidth={4} />
  </g>) },
  { name: 'watching', ru: 'Смотрю', label: 'СМОТРЮ', kw: 'смотрю изучаю глаза читаю проверяю слежу', tone: 'accent', art: () => (<>
    <ellipse cx="13" cy="24" rx="11" ry="14" fill={W} /><ellipse cx="35" cy="24" rx="11" ry="14" fill={W} />
    <circle className="a-look" cx="16" cy="26" r="5.5" style={TONE} /><circle className="a-look" cx="38" cy="26" r="5.5" style={TONE} />
  </>) },
  { name: 'checking', ru: 'Проверяю', label: 'ПРОВЕРЯЮ', kw: 'проверяю поиск лупа анализ изучаю искать смотрю', tone: 'accent2', art: () => (<g className="a-scan">
    <circle cx="20" cy="20" r="14" fill={W} fillOpacity={0.25} stroke={W} strokeWidth={5} /><path d="M31 31l13 13" {...S} strokeWidth={6} /><path d="M13 18a8 8 0 0 1 6-6" {...S} strokeWidth={3} strokeOpacity={0.8} />
  </g>) },
  { name: 'secure', ru: 'Защищено', label: 'ЗАЩИТА', kw: 'защищено безопасность щит проверено безопасно доступ', tone: 'ok', art: () => (<>
    <path d="M24 2l19 7v14c0 11-8 19-19 23C13 42 5 34 5 23V9Z" fill={W} /><path className="a-pop" d="M14 24l8 8 13-15" style={TONE_S} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round" />
  </>) },
  { name: 'lunch', ru: 'Обед', label: 'ОБЕД', kw: 'обед еда столовая перекус кушать ланч', tone: 'warn', art: () => (<>
    <circle cx="26" cy="26" r="16" fill={W} /><circle cx="26" cy="26" r="10" fill="none" style={{ stroke: 'var(--stk)' }} strokeOpacity={0.4} strokeWidth={2} />
    <path d="M4 6v13a4 4 0 0 0 4 4v21M4 6v10M8 6v10M12 6v10" {...S} strokeWidth={3} /><path className="a-rise" d="M20 12q-2-3 0-6M27 12q-2-3 0-6M34 12q-2-3 0-6" {...S} strokeWidth={2.4} />
  </>) },
  { name: 'cheers', ru: 'Пятница', label: 'ПЯТНИЦА', kw: 'пятница тост кружки пиво корпоратив отмечаем cheers ура выходные', tone: 'warn', art: () => (<>
    <g className="a-cheerL"><path d="M5 12h16l-2 28a3 3 0 0 1-3 3H10a3 3 0 0 1-3-3Z" fill={W} /><rect x="7" y="12" width="12" height="7" fill={Y} fillOpacity={0.9} /></g>
    <g className="a-cheerR"><path d="M27 12h16l-2 28a3 3 0 0 1-3 3H32a3 3 0 0 1-3-3Z" fill={W} /><rect x="29" y="12" width="12" height="7" fill={Y} fillOpacity={0.9} /></g>
    {sparkle(24, 6, 1, 'a-twinkle')}
  </>) },
  { name: 'bug', ru: 'Баг', label: 'БАГ', kw: 'баг ошибка дефект жук глюк сбой неисправность', tone: 'danger', art: () => (<g className="a-wobble">
    <ellipse cx="24" cy="29" rx="12" ry="15" fill={W} /><circle cx="24" cy="11" r="7" fill={W} /><path d="M24 17v26" style={TONE_S} strokeWidth={2.5} /><path d="M18 5l-5-3M30 5l5-3M12 24H3M12 33H3M36 24h9M36 33h9M13 42l-6 4M35 42l6 4" {...S} strokeWidth={3} />
  </g>) },
  { name: 'fixed', ru: 'Починил', label: 'ИСПРАВЛЕНО', kw: 'починил исправил исправлено фикс ремонт ключ готово баг', tone: 'ok', art: () => (<g className="a-wobble">
    <path d="M36 3a11 11 0 0 0-11 15L4 38a5 5 0 0 0 7 7l21-21A11 11 0 0 0 45 13l-7 5-6-2-1-6Z" fill={W} /><circle cx="9" cy="40" r="2" style={TONE} />
  </g>) },
  { name: 'checklist', ru: 'Чек-лист', label: 'ЧЕК-ЛИСТ', kw: 'чек-лист список задачи план пункты todo', tone: 'accent', art: () => (<>
    <rect x="6" y="5" width="36" height="40" rx="5" fill={W} /><rect x="16" y="1" width="16" height="9" rx="3" fill={W} stroke="var(--stk)" strokeWidth={2} />
    <g className="a-seq"><path d="M12 20l3 3 5-6" style={TONE_S} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" /></g><path d="M25 21h11" style={TONE_S} strokeWidth={2.6} strokeLinecap="round" />
    <g className="a-seq d2"><path d="M12 31l3 3 5-6" style={TONE_S} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" /></g><path d="M25 32h11" style={TONE_S} strokeWidth={2.6} strokeLinecap="round" />
  </>) },
  { name: 'smile', ru: 'Улыбка', label: 'УЛЫБКА', kw: 'улыбка смайл позитив радость хорошее настроение весело', tone: 'warn', art: () => (<g className="a-bounce">
    <circle cx="24" cy="24" r="20" fill={Y} /><circle cx="17" cy="19" r="2.8" style={{ fill: 'var(--stk)' }} /><circle cx="31" cy="19" r="2.8" style={{ fill: 'var(--stk)' }} /><path d="M13 28c3 8 19 8 22 0" style={{ stroke: 'var(--stk)' }} fill="none" strokeWidth={3.5} strokeLinecap="round" />
  </g>) },
  { name: 'oops', ru: 'Упс', label: 'УПС', kw: 'упс ошибся неловко извините опечатка промах', tone: 'warn', art: () => (<>
    <circle cx="22" cy="26" r="19" fill={Y} /><circle cx="15" cy="22" r="2.6" style={{ fill: 'var(--stk)' }} /><circle cx="29" cy="22" r="2.6" style={{ fill: 'var(--stk)' }} /><path d="M14 35q4-4 8 0t8 0" style={{ stroke: 'var(--stk)' }} fill="none" strokeWidth={3} strokeLinecap="round" />
    <path className="a-drip" d="M40 6c3 5 5 8 5 11a5 5 0 0 1-10 0c0-3 2-6 5-11Z" fill={W} />
  </>) },
  { name: 'help', ru: 'Нужна помощь', label: 'ПОМОЩЬ', kw: 'помощь помогите sos спасите нужна помощь поддержка буй', tone: 'danger', art: () => (<g className="a-spin slow">
    <circle cx="24" cy="24" r="17" fill="none" stroke={W} strokeWidth={10} strokeDasharray="13.35 13.35" /><circle cx="24" cy="24" r="17" fill="none" stroke={W} strokeOpacity={0.45} strokeWidth={10} strokeDasharray="13.35 13.35" strokeDashoffset="13.35" />
  </g>) },
  { name: 'online', ru: 'На связи', label: 'НА СВЯЗИ', kw: 'на связи онлайн доступен в сети рядом отвечаю', tone: 'ok', art: () => (<>
    <circle className="a-ripple" cx="24" cy="24" r="18" fill="none" stroke={W} strokeWidth={3} /><circle className="a-ripple d2" cx="24" cy="24" r="18" fill="none" stroke={W} strokeWidth={3} /><circle cx="24" cy="24" r="9" fill={W} />
  </>) },
  { name: 'break', ru: 'Перерыв', label: 'ПЕРЕРЫВ', kw: 'перерыв отдых пауза сплю zzz устал отошёл спать', tone: 'accent2', art: () => (<>
    <path className="a-rise" d="M6 18h13l-13 15h13" {...S} strokeWidth={4.5} /><path className="a-rise d2" d="M24 10h10l-10 12h10" {...S} strokeWidth={3.6} /><path className="a-rise d3" d="M38 3h7l-7 8h7" {...S} strokeWidth={2.8} />
    <path d="M6 44a22 6 0 0 1 36 0Z" fill={W} fillOpacity={0.6} />
  </>) },
  { name: 'trip', ru: 'В пути', label: 'В ПУТИ', kw: 'в пути командировка самолёт поездка дорога рейс вылет', tone: 'accent', art: () => (<g className="a-fly">
    <path d="M44 6c2 2-1 6-4 9L31 24l5 18-5 3-9-14-8 8 1 6-4 3-4-8-8-4 3-4 6 1 8-8L2 17l3-5 18 5 9-9c3-3 8-5 12-2Z" fill={W} />
  </g>) },
  { name: 'saved', ru: 'Сохранено', label: 'СОХРАНЕНО', kw: 'сохранено облако сохранил загружено синхронизация backup', tone: 'ok', art: () => (<>
    <path d="M12 38a10 10 0 0 1-1-20 13 13 0 0 1 25-3 11 11 0 0 1 2 23Z" fill={W} /><path className="a-pop" d="M16 26l6 6 11-12" style={TONE_S} strokeWidth={4.5} strokeLinecap="round" strokeLinejoin="round" />
  </>) },
  { name: 'team', ru: 'Команда', label: 'КОМАНДА', kw: 'команда коллеги люди группа вместе отдел', tone: 'accent2', art: () => (<>
    <g className="a-bob"><circle cx="24" cy="12" r="7.5" fill={W} /><path d="M11 36a13 12 0 0 1 26 0Z" fill={W} /></g>
    <g className="a-bob d2"><circle cx="8" cy="22" r="5.5" fill={W} fillOpacity={0.75} /><path d="M0 40a9 9 0 0 1 16-5v5Z" fill={W} fillOpacity={0.75} /></g>
    <g className="a-bob d3"><circle cx="40" cy="22" r="5.5" fill={W} fillOpacity={0.75} /><path d="M48 40a9 9 0 0 0-16-5v5Z" fill={W} fillOpacity={0.75} /></g>
  </>) },
  { name: 'question', ru: 'Вопрос', label: 'ВОПРОС', kw: 'вопрос непонятно подскажите как почему что нужен ответ', tone: 'accent', art: () => (<>
    <text className="a-bounce" x="24" y="40" textAnchor="middle" fontSize="48" fontWeight="900" fill={W} style={{ fontFamily: 'var(--font)' }}>?</text>
  </>) },
  { name: 'reject', ru: 'Отказ', label: 'ОТКАЗ', kw: 'отказ нет отклонено запрещено против не согласен нельзя', tone: 'danger', art: () => (<>
    <circle cx="24" cy="24" r="20" fill="none" stroke={W} strokeWidth={5} /><path className="a-pop" d="M10 38L38 10" {...S} strokeWidth={5.5} />
  </>) },
  { name: 'waiting', ru: 'Ждём', label: 'ЖДЁМ', kw: 'ждём ожидание подождите загрузка в ожидании пауза', tone: 'accent', art: () => (<>
    <circle className="a-dot" cx="9" cy="26" r="5" fill={W} /><circle className="a-dot d2" cx="24" cy="26" r="5" fill={W} /><circle className="a-dot d3" cx="39" cy="26" r="5" fill={W} />
  </>) },
  { name: 'new', ru: 'Новое', label: 'НОВОЕ', kw: 'новое новинка новость свежее анонс релиз', tone: 'danger', art: () => (<>
    <path className="a-pulse" d="M24 2l5 6 8-1 1 8 7 4-4 7 2 8-8 2-3 7-7-3-7 3-3-7-8-2 2-8-4-7 7-4 1-8 8 1Z" fill={W} transform="translate(0 2) scale(.96)" /><text x="24" y="29" textAnchor="middle" fontSize="12.5" fontWeight="900" style={{ fontFamily: 'var(--font)', fill: 'var(--stk)' }}>NEW</text>
  </>) },
  { name: 'gears', ru: 'Доработка', label: 'ДОРАБОТКА', kw: 'доработка настройка шестерёнки техработы обслуживание обновление', tone: 'warn', art: () => (<>
    <g className="a-spin"><circle cx="17" cy="29" r="12" fill="none" stroke={W} strokeWidth={6} strokeDasharray="6.3 6.3" /><circle cx="17" cy="29" r="9.5" fill={W} /><circle cx="17" cy="29" r="4" style={TONE} /></g>
    <g className="a-spin rev"><circle cx="35" cy="13" r="9" fill="none" stroke={W} strokeOpacity={0.85} strokeWidth={5} strokeDasharray="5.1 4.7" /><circle cx="35" cy="13" r="7" fill={W} fillOpacity={0.85} /><circle cx="35" cy="13" r="3" style={TONE} /></g>
  </>) },
  { name: 'pin', ru: 'Здесь', label: 'ЗДЕСЬ', kw: 'здесь место адрес локация метка офис геолокация', tone: 'danger', art: () => (<g className="a-bounce">
    <path d="M24 2a15 15 0 0 1 15 15c0 11-15 27-15 27S9 28 9 17A15 15 0 0 1 24 2Z" fill={W} /><circle cx="24" cy="17" r="6" style={TONE} />
  </g>) },
  { name: 'cloudy', ru: 'Пасмурно', label: 'ПОГОДА', kw: 'погода дождь облако пасмурно зонт непогода', tone: 'accent2', art: () => (<>
    <path d="M12 28a9 9 0 0 1-1-17 12 12 0 0 1 22-2 10 10 0 0 1 3 19Z" fill={W} /><path className="a-rain" d="M14 34l-3 8M24 34l-3 8M34 34l-3 8" {...S} strokeWidth={3.5} /><path className="a-rain d2" d="M19 36l-2 6M29 36l-2 6" {...S} strokeWidth={3} strokeOpacity={0.7} />
  </>) },
];

export const STICKER_BY_NAME: Record<string, StickerDef> = Object.fromEntries(STICKERS.map((s) => [s.name, s]));
export const STICKER_RE = /:([a-z0-9_]{1,40}):/g;

const norm = (s: string) => s.toLowerCase().replace(/ё/g, 'е');
const STICK_SEARCH = STICKERS.map((s) => ({ s, t: norm(`${s.ru} ${s.label} ${s.kw} ${s.name}`) }));
export function searchStickers(q: string): StickerDef[] {
  const w = norm(q).replace(/^:|:$/g, '').split(/\s+/).filter(Boolean);
  if (!w.length) return [];
  return STICK_SEARCH.filter(({ t }) => w.every((x) => t.includes(x))).map(({ s }) => s);
}

// ---- анимация только у видимых стикеров
let io: IntersectionObserver | null = null;
function observer() {
  if (!io && typeof IntersectionObserver !== 'undefined') {
    io = new IntersectionObserver((es) => es.forEach((e) => e.target.classList.toggle('on', e.isIntersecting)), { rootMargin: '60px' });
  }
  return io;
}

const cache = new Map<string, React.ReactElement>();
function svgOf(def: StickerDef) {
  let v = cache.get(def.name);
  if (!v) {
    const t = def.label.length;
    const fs = t <= 6 ? 12 : t <= 8 ? 11 : t <= 10 ? 9.6 : 8.4;
    v = (
      <svg viewBox="0 0 100 100" focusable="false" aria-hidden="true">
        <circle cx="50" cy="50" r="47" style={{ fill: 'var(--stk)' }} />
        <path d="M50 3a47 47 0 0 1 0 94Z" fill="#000" fillOpacity={0.09} />
        <ellipse cx="34" cy="20" rx="17" ry="8" fill="#fff" fillOpacity={0.16} transform="rotate(-28 34 20)" />
        <g transform="translate(26 11) scale(.99)">{def.art()}</g>
        <g>
          <rect x="12" y="69" width="76" height="20" rx="10" style={{ fill: 'var(--surface)', stroke: 'var(--stk)' }} strokeWidth="2.2" />
          <text x="50" y="79.2" textAnchor="middle" dominantBaseline="middle" fontSize={fs} fontWeight="800" style={{ fill: 'var(--text)', fontFamily: 'var(--font)', letterSpacing: '.02em' }}>{def.label}</text>
        </g>
      </svg>
    );
    cache.set(def.name, v);
  }
  return v;
}

/** Анимированный стикер. size — сторона в px. still — без анимации (например, в списке «кто поставил»). */
export function Sticker({ name, size = 64, still, className }: { name: string; size?: number; still?: boolean; className?: string }) {
  const def = STICKER_BY_NAME[name];
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el || still) return;
    const o = observer();
    if (!o) { el.classList.add('on'); return; }
    o.observe(el);
    return () => o.unobserve(el);
  }, [still, name]);
  if (!def) return <span>{`:${name}:`}</span>;
  const tone = def.tone === 'accent' ? 'var(--accent)' : def.tone === 'accent2' ? 'var(--accent2)' : `var(--${def.tone})`;
  return (
    <span ref={ref} className={'stk' + (className ? ' ' + className : '')} role="img" aria-label={def.ru} title={`${def.ru} — :${def.name}:`}
      style={{ width: size, height: size, ['--stk' as any]: tone }}>
      {svgOf(def)}
    </span>
  );
}
