import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useRealtime, useTopic } from '../lib/ws';
import { useStore, isAdmin } from '../lib/store';
import { fmtDate, cx, fmtSize, imgFallback, copyLink } from '../lib/util';
import { Avatar, Btn, FileLink, Loading, Spinner, useConfirm } from './index';
import { Lightbox } from './Lightbox';
import { Link, HASH_EVENT } from '../lib/router';
import { EmojiButton, TextAssist } from './EmojiPicker';
import { Reactions, type Rx } from './Reactions';
import { RichText } from '../lib/richtext';

export interface CFile { id: number; name: string; mime: string; size?: number; width?: number; height?: number; has_thumb?: boolean }
export interface C {
  id: number; parent_id: number | null; root_id: number | null; depth: number; user_id: number; author: string; author_avatar: string; author_title: string;
  body: string; created_at: string; deleted: boolean; files?: CFile[]; reactions?: Rx[];
}
interface Page { items: C[]; has_more: boolean; next: number }
type Ent = 'news' | 'post' | 'idea';

export const MAX_DEPTH = 5;
const PER = 30;
/** Ветки глубже этого уровня свёрнуты по умолчанию («Показать ответы (N)»). */
const OPEN_DEPTH = 2;

const hashId = () => {
  const m = /^#comment-(\d+)$/.exec(location.hash);
  return m ? +m[1] : 0;
};
const add = (list: C[], c: C) => (list.some((x) => x.id === c.id) ? list : [...list, c]);

/** Вложения комментария: картинки — миниатюрами с просмотром, остальное — карточками файлов. */
function Files({ files }: { files: CFile[] }) {
  const [light, setLight] = useState<number | null>(null);
  const imgs = files.filter((f) => f.mime?.startsWith('image/'));
  const rest = files.filter((f) => !f.mime?.startsWith('image/'));
  return (
    <div className="cmtFiles">
      {imgs.length > 0 && (
        <div className="cmtImgs">
          {imgs.map((f, i) => (
            <button type="button" key={f.id} className="cmtImg" onClick={() => setLight(i)} aria-label={f.name}>
              <img src={`/files/${f.id}?t=1`} alt={f.name} loading="lazy" decoding="async" onError={imgFallback} />
            </button>
          ))}
        </div>
      )}
      {rest.map((f) => <FileLink key={f.id} f={f} />)}
      {light !== null && <Lightbox items={imgs.map((f) => ({ src: `/files/${f.id}?v=1`, full: `/files/${f.id}`, name: f.name }))} start={light} onClose={() => setLight(null)} />}
    </div>
  );
}

interface Pending { key: number; name: string; p: number; file?: CFile; err?: string }

/** Форма комментария: текст + вложения (загружаются сразу, привязываются при отправке). */
function Composer({ type, id, parent, onSent, onCancel, autoFocus, compact }: { type: Ent; id: number; parent: C | null; onSent: (c: C) => void; onCancel?: () => void; autoFocus?: boolean; compact?: boolean }) {
  const me = useStore((s) => s.me)!;
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [files, setFiles] = useState<Pending[]>([]);
  const inp = useRef<HTMLInputElement>(null);
  const ta = useRef<HTMLTextAreaElement>(null);
  useEffect(() => { if (autoFocus) ta.current?.focus(); }, [autoFocus]);
  const uploading = files.some((f) => !f.file && !f.err);
  const ready = files.filter((f) => f.file);

  async function pick(list: FileList | File[] | null) {
    if (!list) return;
    const arr = Array.from(list).slice(0, Math.max(0, 10 - files.length));
    for (const f of arr) {
      const key = Date.now() + Math.random();
      setFiles((x) => [...x, { key, name: f.name, p: 0 }]);
      try {
        const r = await api.upload<CFile>('/api/comments/files', f, (p) => setFiles((x) => x.map((y) => (y.key === key ? { ...y, p } : y))));
        setFiles((x) => x.map((y) => (y.key === key ? { ...y, p: 1, file: r } : y)));
      } catch (e) { setFiles((x) => x.map((y) => (y.key === key ? { ...y, err: errMsg(e) } : y))); }
    }
  }
  async function send() {
    const body = text.trim();
    if ((!body && !ready.length) || busy || uploading) return;
    setBusy(true); setErr('');
    try {
      const c = await api.post<C>('/api/comments', { entity_type: type, entity_id: id, body, parent_id: parent?.id ?? null, files: ready.map((f) => f.file!.id) });
      setText(''); setFiles([]);
      if (ta.current) ta.current.style.height = '';
      onSent(c);
    } catch (e) { setErr(errMsg(e)); }
    setBusy(false);
  }
  return (
    <div className={cx('stackS', compact && 'cmtInline')}>
      <div className="cmtForm">
        {!compact && <Avatar name={me.name} src={me.avatar} size={40} />}
        <div className="cmtBox">
          <textarea ref={ta} className="txt" rows={1} maxLength={4000} value={text} aria-label={parent ? 'Ответ на комментарий' : 'Комментарий'}
            placeholder={parent ? `Ответить: ${parent.author}…` : 'Написать комментарий…'}
            onChange={(e) => { setText(e.target.value); e.target.style.height = '44px'; e.target.style.height = Math.min(e.target.scrollHeight, 160) + 'px'; }}
            onKeyDown={(e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) send(); if (e.key === 'Escape' && onCancel) onCancel(); }}
            onPaste={(e) => { const fs = Array.from(e.clipboardData.files); if (fs.length) { e.preventDefault(); pick(fs); } }} />
        </div>
        <EmojiButton target={ta} value={text} onChange={setText} align="end" />
        <Btn icon type="button" aria-label="Прикрепить файл" title="Прикрепить файл" disabled={files.length >= 10} onClick={() => inp.current?.click()}><I.Paperclip size={18} /></Btn>
        <Btn kind="pri" busy={busy} disabled={(!text.trim() && !ready.length) || uploading} onClick={send} icon aria-label="Отправить"><I.Send size={18} /></Btn>
        {onCancel && <Btn kind="ghost" icon type="button" onClick={onCancel} aria-label="Отмена"><I.X size={18} /></Btn>}
        <input ref={inp} type="file" multiple hidden onChange={(e) => { pick(e.target.files); e.target.value = ''; }} />
        <TextAssist target={ta} value={text} onChange={setText} scope={type} id={id} />
      </div>
      {files.length > 0 && (
        <div className="cmtPend">
          {files.map((f) => (
            <span key={f.key} className={cx('cmtPendItem', f.err && 'bad')} title={f.err}>
              {f.file ? <I.Paperclip size={14} /> : f.err ? <I.Alert size={14} /> : <Spinner />}
              <span className="clip">{f.name}</span>
              {f.file?.size ? <span className="faint tiny">{fmtSize(f.file.size)}</span> : !f.file && !f.err ? <span className="faint tiny">{Math.round(f.p * 100)}%</span> : null}
              <button type="button" aria-label="Убрать" onClick={() => setFiles((x) => x.filter((y) => y.key !== f.key))}><I.X size={13} /></button>
            </span>
          ))}
        </div>
      )}
      {err && <div className="err">{err}</div>}
    </div>
  );
}

/** Ветка комментариев (до 5 уровней). Живые обновления приходят по WebSocket, корневые комментарии подгружаются страницами. */
export function Comments({ type, id, live, onCount }: { type: Ent; id: number; live?: boolean; onCount?: (n: number) => void }) {
  const me = useStore((s) => s.me)!;
  const [list, setList] = useState<C[]>([]);
  const [hasMore, setHasMore] = useState(false);
  const [next, setNext] = useState(0);
  const [loading, setLoading] = useState(true);
  const [moreBusy, setMoreBusy] = useState(false);
  const [error, setError] = useState('');
  const [replyTo, setReplyTo] = useState<number | null>(null);
  const [fresh, setFresh] = useState<number[]>([]);
  const [open, setOpen] = useState<Set<number>>(new Set());
  const [target, setTarget] = useState(hashId());
  const [hl, setHl] = useState(0);
  const [confirm, node] = useConfirm();
  const seq = useRef(0);
  const timers = useRef<any[]>([]);
  const state = useRef({ hasMore, next });
  state.current = { hasMore, next };

  const load = useCallback(async (after: number, reset: boolean) => {
    const my = reset ? ++seq.current : seq.current;
    try {
      const r = await api.get<Page>(`/api/comments?type=${type}&id=${id}&per=${PER}${after ? '&after=' + after : ''}`);
      if (my !== seq.current) return;
      setList((old) => (reset ? r.items : r.items.reduce(add, old)));
      setHasMore(r.has_more); setNext(r.next); setError('');
    } catch (e) { if (my === seq.current) setError(errMsg(e)); }
  }, [type, id]);

  useEffect(() => {
    setList([]); setHasMore(false); setNext(0); setLoading(true); setReplyTo(null);
    load(0, true).then(() => setLoading(false));
  }, [load]);

  async function more() {
    if (moreBusy || !state.current.hasMore) return;
    setMoreBusy(true);
    await load(state.current.next, false);
    setMoreBusy(false);
  }

  // ---- realtime
  useTopic(live && (type === 'news' || type === 'idea') ? `${type}:${id}` : null);
  useRealtime('comment', (c: C & { entity_id: number; entity_type: string }) => {
    if (c.entity_type !== type || c.entity_id !== id) return;
    setList((old) => {
      if (old.some((x) => x.id === c.id)) return old;
      // ответ на ещё не загруженный комментарий или корень за пределами загруженных страниц подтянется при «Показать ещё»
      if (c.parent_id ? !old.some((x) => x.id === c.parent_id) : state.current.hasMore && c.user_id !== me.id) return old;
      return [...old, c];
    });
    setFresh((f) => [...f, c.id]);
  }, [type, id]);
  useRealtime('comment.delete', (d: { id: number }) => setList((old) => old.map((x) => (x.id === d.id ? { ...x, deleted: true, body: '', files: [] } : x))), [type, id]);

  // ---- структура
  const { roots, kids, live: alive } = useMemo(() => {
    const kids = new Map<number, C[]>();
    const roots: C[] = [];
    const byId = new Map(list.map((c) => [c.id, c]));
    const sorted = [...list].sort((a, b) => a.id - b.id);
    for (const c of sorted) {
      if (c.parent_id && byId.has(c.parent_id)) (kids.get(c.parent_id) || kids.set(c.parent_id, []).get(c.parent_id)!).push(c);
      else if (!c.parent_id) roots.push(c);
    }
    // удалённый комментарий без живых потомков не показываем
    const live = new Map<number, boolean>();
    const calc = (c: C): boolean => {
      const sub = (kids.get(c.id) || []).map(calc).some(Boolean); // map, а не some: нужно посчитать всех потомков, а не остановиться на первом живом
      const v = !c.deleted || sub;
      live.set(c.id, v);
      return v;
    };
    roots.forEach(calc);
    return { roots, kids, live };
  }, [list]);
  const total = useMemo(() => list.filter((c) => !c.deleted).length, [list]);
  useEffect(() => { if (!hasMore && !loading) onCount?.(total); }, [total, hasMore, loading]);

  // ---- якорь #comment-<id>
  useEffect(() => {
    const h = () => { const t = hashId(); if (t) { setTarget(t); setHl(0); } };
    window.addEventListener(HASH_EVENT, h);
    return () => window.removeEventListener(HASH_EVENT, h);
  }, []);
  useEffect(() => {
    if (!target || loading) return;
    const c = list.find((x) => x.id === target);
    if (!c) {
      if (hasMore && !moreBusy) more();
      else if (!hasMore) setTarget(0);
      return;
    }
    // раскрыть всех предков
    const anc: number[] = [];
    for (let p = c.parent_id; p; ) { anc.push(p); p = list.find((x) => x.id === p)?.parent_id ?? null; }
    if (anc.some((a) => !isOpen(a))) { setOpen((o) => new Set([...o, ...anc])); return; }
    const go = () => document.getElementById('comment-' + target)?.scrollIntoView({ block: 'center', behavior: 'smooth' });
    timers.current.push(setTimeout(go, 60), setTimeout(go, 700)); // после догрузки картинок раскладка могла сдвинуться
    setHl(target);
    timers.current.push(setTimeout(() => setHl(0), 3500));
    setTarget(0);
  }, [target, list, loading, hasMore, moreBusy, open]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);
  const isOpen = (cid: number) => open.has(cid);
  const shown = (c: C) => c.depth < OPEN_DEPTH || open.has(c.id);

  async function del(c: C) {
    if (!(await confirm('Удалить комментарий?', { ok: 'Удалить' }))) return;
    try {
      await api.del('/api/comments/' + c.id);
      setList((old) => old.map((x) => (x.id === c.id ? { ...x, deleted: true, body: '', files: [] } : x)));
    } catch (e) { setError(errMsg(e)); }
  }
  const sent = (c: C) => { setList((old) => add(old, c)); setReplyTo(null); if (c.parent_id) setOpen((o) => new Set([...o, c.parent_id!])); setFresh((f) => [...f, c.id]); };

  const one = (c: C): React.ReactNode => {
    if (!alive.get(c.id)) return null;
    const ch = (kids.get(c.id) || []).filter((k) => alive.get(k.id));
    const expanded = shown(c);
    return (
      <div key={c.id} className="cmtNode" data-depth={c.depth}>
        <div id={'comment-' + c.id} className={cx('cmt', fresh.includes(c.id) && 'fresh', hl === c.id && 'target')}>
          <Link to={`/people/${c.user_id}`}><Avatar name={c.author} src={c.author_avatar} size={c.depth ? 32 : 40} userId={c.user_id} /></Link>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div className="bubble">
              <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
                <Link to={`/people/${c.user_id}`} className="bold small">{c.author}</Link>
                <span className="tiny faint">{c.author_title}</span>
              </div>
              {c.deleted ? <div className="body faint"><i>Комментарий удалён</i></div> : (
                <>
                  {c.body && <div className="body"><RichText text={c.body} /></div>}
                  {c.files && c.files.length > 0 && <Files files={c.files} />}
                </>
              )}
            </div>
            <div className="row tiny faint cmtAct">
              <a href={'#comment-' + c.id} className="faint" title="Ссылка на комментарий">{fmtDate(c.created_at)}</a>
              {!c.deleted && c.depth < MAX_DEPTH && <button type="button" className="btn ghost sm" onClick={() => setReplyTo(replyTo === c.id ? null : c.id)}><I.Reply size={14} /> Ответить</button>}
              {!c.deleted && <Reactions type="comment" id={c.id} initial={c.reactions} compact />}
              {!c.deleted && <button type="button" className="btn ghost sm" title="Скопировать ссылку на комментарий" onClick={() => copyLink(location.pathname + location.search + '#comment-' + c.id)}><I.Share size={13} /> Ссылка</button>}
              {!c.deleted && (c.user_id === me.id || isAdmin(me)) && <button type="button" className="btn ghost sm" onClick={() => del(c)}>Удалить</button>}
            </div>
            {replyTo === c.id && <Composer type={type} id={id} parent={c} compact autoFocus onSent={sent} onCancel={() => setReplyTo(null)} />}
          </div>
        </div>
        {ch.length > 0 && (expanded ? (
          <div className={cx('cmtReplies', 'lv' + Math.min(c.depth + 1, MAX_DEPTH))}>{ch.map(one)}</div>
        ) : (
          <button type="button" className="btn ghost sm cmtExpand" onClick={() => setOpen((o) => new Set([...o, c.id]))}><I.ChevronDown size={15} /> Показать ответы ({ch.length}{ch.some((k) => (kids.get(k.id) || []).length) ? '+' : ''})</button>
        ))}
      </div>
    );
  };

  const visibleRoots = roots.filter((c) => alive.get(c.id));
  return (
    <div className="stack">
      {loading ? <Loading /> : error && !list.length ? (
        <div className="err">{error} <button className="btn ghost sm" onClick={() => { setLoading(true); load(0, true).then(() => setLoading(false)); }}>Повторить</button></div>
      ) : visibleRoots.length === 0 && !hasMore ? <div className="muted small">Комментариев пока нет — будьте первым.</div> : <div className="stack cmtList">{visibleRoots.map(one)}</div>}
      {hasMore && <div className="loadMore" style={{ padding: 0 }}><Btn busy={moreBusy} onClick={more}>Показать ещё комментарии</Btn></div>}
      {error && list.length > 0 && <div className="err">{error}</div>}
      <Composer type={type} id={id} parent={null} onSent={sent} />
      {node}
    </div>
  );
}
