import React, { useMemo, useState } from 'react';
import * as I from '../lib/icons';
import { api } from '../lib/api';
import { useQuery } from '../lib/query';
import { cx } from '../lib/util';
import { usePopover } from './index';
import { flattenDepts, type Dept } from './DeptSelect';

export function useDirections() {
  return useQuery<Dept[]>('directions', () => api.get('/api/directions'), { stale: 120000 });
}

/** Иерархический выбор направления деятельности. `onlyManageable` — недоступные (не can_manage) показываются приглушёнными. */
export function DirSelect({ value, onChange, onlyManageable, emptyLabel = 'Не выбрано' }: { value: number | null; onChange: (id: number | null) => void; onlyManageable?: boolean; emptyLabel?: string }) {
  const { data } = useDirections();
  const { open, setOpen, ref } = usePopover();
  const [collapsed, setCollapsed] = useState<Set<number>>(new Set());
  const rows = useMemo(() => flattenDepts(data || []), [data]);
  const byId = useMemo(() => new Map((data || []).map((d) => [d.id, d])), [data]);
  const hidden = useMemo(() => {
    const h = new Set<number>();
    for (const r of rows) if (r.parent_id != null && (collapsed.has(r.parent_id) || h.has(r.parent_id))) h.add(r.id);
    return h;
  }, [rows, collapsed]);
  const label = value != null ? byId.get(value)?.name || '…' : emptyLabel;
  return (
    <div style={{ position: 'relative' }} ref={ref}>
      <button type="button" className="sel" style={{ textAlign: 'left', width: '100%' }} aria-expanded={open} onClick={() => setOpen(!open)}>{label}</button>
      {open && (
        <div className="treeSel" style={{ position: 'absolute', zIndex: 30, left: 0, right: 0, top: 'calc(100% + 4px)', boxShadow: 'var(--shadow)' }}>
          <div className={cx('treeRow', value == null && 'on')} onClick={() => { onChange(null); setOpen(false); }}>{emptyLabel}</div>
          {rows.filter((r) => !hidden.has(r.id)).map((r) => {
            const disabled = onlyManageable && !r.can_manage;
            return (
              <div key={r.id} className={cx('treeRow', value === r.id && 'on')} style={{ paddingLeft: 8 + r.depth * 18, opacity: disabled ? 0.5 : 1, cursor: disabled ? 'default' : 'pointer' }}
                onClick={() => { if (disabled) return; onChange(r.id); setOpen(false); }}>
                {r.hasKids ? (
                  <span onClick={(e) => { e.stopPropagation(); setCollapsed((c) => { const n = new Set(c); n.has(r.id) ? n.delete(r.id) : n.add(r.id); return n; }); }} style={{ display: 'inline-flex' }}>
                    {collapsed.has(r.id) ? <I.ChevronRight size={15} /> : <I.ChevronDown size={15} />}
                  </span>
                ) : <span style={{ width: 15 }} />}
                {r.name}
              </div>
            );
          })}
          {!rows.length && <div className="small muted" style={{ padding: 12 }}>Направлений пока нет</div>}
        </div>
      )}
    </div>
  );
}
