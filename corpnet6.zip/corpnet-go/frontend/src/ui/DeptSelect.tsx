import React, { useMemo, useState } from 'react';
import * as I from '../lib/icons';
import { api } from '../lib/api';
import { useQuery } from '../lib/query';
import { cx } from '../lib/util';
import { usePopover } from './index';

export interface Dept { id: number; parent_id: number | null; name: string; sort?: number; can_manage?: boolean; employees?: number }

/** Flat list (parent_id) → depth-first rows in the server's order. */
export function flattenDepts(list: Dept[]): (Dept & { depth: number; hasKids: boolean })[] {
  const kids = new Map<number | null, Dept[]>();
  const ids = new Set(list.map((d) => d.id));
  for (const d of list) {
    const p = d.parent_id != null && ids.has(d.parent_id) ? d.parent_id : null;
    if (!kids.has(p)) kids.set(p, []);
    kids.get(p)!.push(d);
  }
  const out: (Dept & { depth: number; hasKids: boolean })[] = [];
  const walk = (p: number | null, depth: number) => {
    for (const d of kids.get(p) || []) {
      out.push({ ...d, depth, hasKids: kids.has(d.id) });
      walk(d.id, depth + 1);
    }
  };
  walk(null, 0);
  return out;
}

export function useDepartments() {
  return useQuery<Dept[]>('departments', () => api.get('/api/departments'), { stale: 120000 });
}

/** Hierarchical dropdown of departments. `onlyManageable` hides nodes the user cannot manage (still shows ancestors, disabled). */
export function DeptSelect({ value, onChange, allowEmpty = true, emptyLabel = 'Вся компания', onlyManageable, exclude }: { value: number | null; onChange: (id: number | null) => void; allowEmpty?: boolean; emptyLabel?: string; onlyManageable?: boolean; exclude?: number }) {
  const { data } = useDepartments();
  const { open, setOpen, ref } = usePopover();
  const [collapsed, setCollapsed] = useState<Set<number>>(new Set());
  const rows = useMemo(() => flattenDepts(data || []), [data]);
  const byId = useMemo(() => new Map((data || []).map((d) => [d.id, d])), [data]);
  const hidden = useMemo(() => {
    const h = new Set<number>();
    for (const r of rows) {
      const p = r.parent_id;
      if (p != null && (collapsed.has(p) || h.has(p))) h.add(r.id);
    }
    return h;
  }, [rows, collapsed]);
  const label = value != null ? byId.get(value)?.name || '…' : allowEmpty ? emptyLabel : 'Выберите подразделение';
  return (
    <div style={{ position: 'relative' }} ref={ref}>
      <button type="button" className="sel" style={{ textAlign: 'left', width: '100%' }} onClick={() => setOpen(!open)}>{label}</button>
      {open && (
        <div className="treeSel" style={{ position: 'absolute', zIndex: 30, left: 0, right: 0, top: 'calc(100% + 4px)', boxShadow: 'var(--shadow)' }}>
          {allowEmpty && <div className={cx('treeRow', value == null && 'on')} onClick={() => { onChange(null); setOpen(false); }}>{emptyLabel}</div>}
          {rows.filter((r) => !hidden.has(r.id) && r.id !== exclude).map((r) => {
            const disabled = onlyManageable && !r.can_manage;
            return (
              <div key={r.id} className={cx('treeRow', value === r.id && 'on')} style={{ paddingLeft: 8 + r.depth * 18, opacity: disabled ? 0.5 : 1, cursor: disabled ? 'default' : 'pointer' }}
                onClick={() => { if (disabled) return; onChange(r.id); setOpen(false); }}>
                {r.hasKids ? (
                  <span onClick={(e) => { e.stopPropagation(); setCollapsed((c) => { const n = new Set(c); n.has(r.id) ? n.delete(r.id) : n.add(r.id); return n; }); }} style={{ display: 'inline-flex' }}>
                    {collapsed.has(r.id) ? <I.ChevronRight size={15} /> : <I.ChevronDown size={15} />}
                  </span>
                ) : <span style={{ width: 15 }} />}
                {r.name}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
