import React, { useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { Link } from '../lib/router';
import { plural, imgFallback } from '../lib/util';
import { Lightbox } from './Lightbox';

export interface GalleryFile { id: number; name: string; mime: string; width?: number; height?: number; external_url?: string }
export interface NewsGallery { id: number; folder_id: number; title: string; kind: 'photos' | 'videos'; folder_name: string; total: number; items: GalleryFile[] }

const src = (f: GalleryFile) => f.external_url || `/files/${f.id}`;
const isVideo = (f: GalleryFile) => f.mime?.startsWith('video/');

/** Ссылка на папку фото/видео внутри новости: заголовок, сетка миниатюр и просмотр (как в разделах «Фотогалерея» и «Видео»). */
export function GalleryPreview({ g }: { g: NewsGallery }) {
  const [items, setItems] = useState<GalleryFile[]>(g.items || []);
  const [light, setLight] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const videos = g.kind === 'videos';
  const rest = Math.max(0, g.total - items.length);
  const media = items.filter((f) => f.mime?.startsWith('image/') || isVideo(f));

  async function all() {
    setBusy(true); setErr('');
    try {
      const r = await api.get<{ files: GalleryFile[] }>(`/api/folders?kind=${g.kind}&parent_id=${g.folder_id}&per=200`);
      setItems(r.files || []);
    } catch (e) { setErr(errMsg(e)); }
    setBusy(false);
  }
  return (
    <section className="gal">
      <div className="galH">
        {videos ? <I.Video size={18} /> : <I.Image size={18} />}
        <Link to={`/${g.kind}?folder=${g.folder_id}`} className="bold sp clip">{g.title || g.folder_name}</Link>
        <span className="small muted">{plural(g.total, videos ? ['видео', 'видео', 'видео'] : ['фото', 'фото', 'фото'])}</span>
        <Link to={`/${g.kind}?folder=${g.folder_id}`} className="small galOpen">Открыть папку <I.ChevronRight size={14} /></Link>
      </div>
      {items.length === 0 ? <div className="small muted">В папке пока ничего нет</div> : (
        <div className={videos ? 'galGrid vid' : 'galGrid'}>
          {items.map((f) => {
            const mi = media.findIndex((x) => x.id === f.id);
            return (
              <button type="button" key={f.id} className="photo" style={videos ? { aspectRatio: '16/9' } : undefined} disabled={mi < 0} onClick={() => setLight(mi)} aria-label={f.name}>
                {f.mime?.startsWith('image/') ? <img src={f.external_url || `/files/${f.id}?t=1`} alt={f.name} loading="lazy" decoding="async" onError={imgFallback} />
                  : isVideo(f) && !f.external_url ? <video src={`${src(f)}#t=0.5`} preload="metadata" muted playsInline tabIndex={-1} />
                  : <div className="galPh" />}
                {isVideo(f) && <span className="pl"><I.Play size={36} /></span>}
              </button>
            );
          })}
          {rest > 0 && (
            <button type="button" className="photo galMore" onClick={all} disabled={busy} style={videos ? { aspectRatio: '16/9' } : undefined}>
              <b>{busy ? '…' : '+' + rest}</b><span>показать все</span>
            </button>
          )}
        </div>
      )}
      {err && <div className="err">{err}</div>}
      {light !== null && media[light] && <Lightbox items={media.map((f) => ({ src: isVideo(f) ? src(f) : f.external_url || `/files/${f.id}?v=1`, full: src(f), name: f.name, video: isVideo(f) }))} start={light} onClose={() => setLight(null)} />}
    </section>
  );
}
