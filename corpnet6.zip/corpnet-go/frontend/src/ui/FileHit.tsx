import React, { useState } from 'react';
import * as I from '../lib/icons';
import { api } from '../lib/api';
import { useQuery } from '../lib/query';
import { Link, navigate } from '../lib/router';
import { fmtSize } from '../lib/util';
import { trackSearchClick } from '../lib/analytics';
import { FileIcon } from './index';
import { usePdfPreview } from './PdfViewer';
import './filehit.css';

/** Результат поиска по содержимому файла (GET /api/search → file_content, /api/search/files). */
export interface FileHit { id: number; name: string; mime: string; size: number; created_at: string; source: string; origin: string; link: string; snippet: string }

const HL_START = '', HL_STOP = '';

/** Фрагмент текста с подсветкой: сервер расставляет маркеры U+E000/U+E001, HTML не используется — подсветка рисуется элементами <mark>. */
export function Snippet({ text }: { text: string }) {
  const parts: React.ReactNode[] = [];
  let i = 0, k = 0;
  while (i < text.length) {
    const a = text.indexOf(HL_START, i);
    if (a < 0) { parts.push(text.slice(i)); break; }
    if (a > i) parts.push(text.slice(i, a));
    const b = text.indexOf(HL_STOP, a + 1);
    const end = b < 0 ? text.length : b;
    parts.push(<mark key={k++}>{text.slice(a + 1, end)}</mark>);
    i = b < 0 ? text.length : b + 1;
  }
  return <span className="fhSnip">{parts}</span>;
}

/** Строка результата: клик — открыть файл (PDF во встроенном просмотре, остальное — переход к источнику), справа — ссылка на источник. */
export function FileHitRow({ h, q, onNavigate, compact, pdf: ext }: { h: FileHit; q: string; onNavigate?: () => void; compact?: boolean; pdf?: ReturnType<typeof usePdfPreview> }) {
  const own = usePdfPreview();
  const pdf = ext || own; // во всплывающем списке просмотр держит родитель: список закрывается, а модальное окно должно жить
  const open = (e: React.MouseEvent) => {
    trackSearchClick(q, 'files', 'file:' + h.id);
    if (pdf.onLinkClick(e, h)) return;
    e.preventDefault();
    onNavigate?.();
    navigate(h.link || `/files/${h.id}`);
  };
  return (
    <div className={'fhit' + (compact ? ' compact' : '')}>
      <a className="fhMain" href={h.link || `/files/${h.id}`} onClick={open}>
        <FileIcon name={h.name} mime={h.mime} />
        <span className="fhBody">
          <span className="bold clip">{h.name}</span>
          {h.snippet && <span className="fhText small"><Snippet text={h.snippet} /></span>}
          <span className="tiny muted clip">{h.origin || 'Файл'} · {fmtSize(h.size)}</span>
        </span>
      </a>
      {!compact && h.link && <Link to={h.link} className="fhSrc small" title="Перейти к источнику"><I.External size={15} /> Источник</Link>}
      {!ext && pdf.node}
    </div>
  );
}

/** Секция «Найдено в содержимом файлов» на странице поиска; по кнопке подгружает расширенный список. */
export function FileHitsSection({ q, initial, limit }: { q: string; initial: FileHit[]; limit: number }) {
  const [more, setMore] = useState(false);
  const { data } = useQuery<FileHit[]>(more ? 'search:files:' + q : null, () => api.get('/api/search/files?limit=40&q=' + encodeURIComponent(q)), { stale: 30000 });
  const list = more && data ? data : initial;
  if (!list.length) return null;
  return (
    <section className="stackS sGroup">
      <h3>В содержимом файлов</h3>
      <div className="card">
        {list.map((h) => <FileHitRow key={h.id} h={h} q={q} />)}
        {!more && initial.length >= limit && <div className="sMore"><button type="button" className="linkBtn" onClick={() => setMore(true)}>Показать больше совпадений →</button></div>}
      </div>
    </section>
  );
}
