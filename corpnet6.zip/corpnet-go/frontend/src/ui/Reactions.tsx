// Реакции на любой объект (новость, идея, комментарий, сообщение чата, публикация группы): чипы со счётчиками, подсветка своей,
// всплывающий список «кто поставил», быстрые реакции + любой смайл или анимированный стикер. Обновляется в реальном времени.
//
//   <Reactions type="comment" id={c.id} initial={c.reactions} />          — полоса чипов (+ кнопка «добавить»)
//   <ReactionAddButton type="message" id={m.id} />                        — только кнопка (например, в меню действий сообщения)
//   <ReactionSummary items={n.reactions} />                              — компактная сводка для карточек списков (только чтение)
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { api, errMsg } from '../lib/api';
import { Link } from '../lib/router';
import { applyEvent, onReaction, optimistic, sendReaction, type Rx } from '../lib/reactions';
import * as X from '../lib/social-icons';
import { toast } from '../lib/store';
import { cx } from '../lib/util';
import { Avatar, Btn, Loading, Modal } from './index';
import { EmojiPicker, Glyph } from './EmojiPicker';
import { QUICK_REACTIONS } from './emoji-data';
import './social.css';

export type { Rx };
const LIKE = '👍';

export function useReactions(type: string, id: number, initial?: Rx[]) {
  const [items, setItems] = useState<Rx[]>(initial || []);
  const sig = JSON.stringify(initial || []);
  useEffect(() => { setItems(initial || []); }, [sig, type, id]);
  useEffect(() => onReaction((d) => { if (d.entity_type === type && d.entity_id === id) setItems((p) => applyEvent(p, d)); }), [type, id]);
  const toggle = useCallback(async (emoji: string) => {
    const was = items.find((x) => x.e === emoji)?.m;
    setItems((p) => optimistic(p, emoji, !was));
    try { await sendReaction(type, id, emoji, !was); } catch (e) {
      setItems((p) => optimistic(p, emoji, !!was));
      toast({ title: errMsg(e), kind: 'error' });
    }
  }, [type, id, items]);
  return { items, toggle };
}

// ---------------------------------------------------------------- палитра
function Palette({ anchor, onPick, onClose, mine }: { anchor: HTMLElement; onPick: (e: string) => void; onClose: () => void; mine?: Set<string> }) {
  const [full, setFull] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<React.CSSProperties>({});
  useEffect(() => {
    const upd = () => {
      const r = anchor.getBoundingClientRect(), w = full ? Math.min(360, innerWidth - 16) : 330;
      const left = Math.max(8, Math.min(r.left, innerWidth - w - 8));
      const h = full ? 400 : 52;
      setPos(r.top > h + 14 ? { left, bottom: innerHeight - r.top + 6, width: w, maxHeight: r.top - 14 } : { left, top: r.bottom + 6, width: w, maxHeight: innerHeight - r.bottom - 14 });
    };
    upd();
    addEventListener('resize', upd); addEventListener('scroll', upd, true);
    const d = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node) && !anchor.contains(e.target as Node)) onClose(); };
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') { e.stopPropagation(); onClose(); } };
    document.addEventListener('mousedown', d, true); document.addEventListener('keydown', k, true);
    return () => { removeEventListener('resize', upd); removeEventListener('scroll', upd, true); document.removeEventListener('mousedown', d, true); document.removeEventListener('keydown', k, true); };
  }, [anchor, full, onClose]);
  return createPortal(
    <div ref={ref} className="emjLayer" style={pos}>
      {full ? <EmojiPicker onPick={(v) => { onPick(v); onClose(); }} onClose={onClose} /> : (
        <div className="rxQuick" role="menu" aria-label="Быстрые реакции">
          {QUICK_REACTIONS.map((e) => <button key={e} type="button" role="menuitem" className={cx(mine?.has(e) && 'on')} aria-label={e} onClick={() => { onPick(e); onClose(); }}>{e}</button>)}
          <button type="button" className="more" aria-label="Другие смайлы и стикеры" title="Все смайлы и стикеры" onClick={() => setFull(true)}><X.SmilePlus size={20} /></button>
        </div>
      )}
    </div>, document.body);
}

/** Кнопка «добавить реакцию»; без onPick сама отправляет запрос (переключает реакцию). */
export function ReactionAddButton({ type, id, onPick, className, size = 16, title = 'Добавить реакцию', mine }: { type?: string; id?: number; onPick?: (e: string) => void; className?: string; size?: number; title?: string; mine?: Set<string> }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLButtonElement>(null);
  const close = useCallback(() => setOpen(false), []);
  async function pick(e: string) {
    if (onPick) return onPick(e);
    try { await sendReaction(type!, id!, e); } catch (er) { toast({ title: errMsg(er), kind: 'error' }); }
  }
  return (
    <>
      <button ref={ref} type="button" className={cx('rxAdd', open && 'on', className)} title={title} aria-label={title} aria-haspopup="menu" aria-expanded={open} onClick={() => setOpen((o) => !o)}><X.SmilePlus size={size} /></button>
      {open && ref.current && <Palette anchor={ref.current} onPick={pick} onClose={close} mine={mine} />}
    </>
  );
}

// ---------------------------------------------------------------- «кто поставил»
interface Who { user_id: number; name: string; avatar: string; emoji: string; at: string }
interface WhoPage { items: Who[]; has_more: boolean; reactions: Rx[] }
const whoUrl = (type: string, id: number, emoji: string, page: number, per: number) =>
  `/api/reactions/users?entity_type=${type}&entity_id=${id}&emoji=${encodeURIComponent(emoji)}&page=${page}&per=${per}`;

function WhoModal({ type, id, start, onClose }: { type: string; id: number; start: string; onClose: () => void }) {
  const [emoji, setEmoji] = useState(start);
  const [list, setList] = useState<Who[]>([]);
  const [tabs, setTabs] = useState<Rx[]>([]);
  const [more, setMore] = useState(false);
  const [page, setPage] = useState(1);
  const [busy, setBusy] = useState(true);
  const [err, setErr] = useState('');
  useEffect(() => {
    let dead = false;
    setBusy(true);
    api.get<WhoPage>(whoUrl(type, id, emoji, page, 30)).then((r) => {
      if (dead) return;
      setList((o) => (page === 1 ? r.items : [...o, ...r.items])); setMore(r.has_more); setTabs(r.reactions); setBusy(false);
    }).catch((e) => { if (!dead) { setErr(errMsg(e)); setBusy(false); } });
    return () => { dead = true; };
  }, [type, id, emoji, page]);
  const total = tabs.reduce((a, b) => a + b.n, 0);
  return (
    <Modal title="Кто поставил реакции" onClose={onClose} size="sm">
      <div className="rxTabs" role="tablist">
        <button type="button" role="tab" aria-selected={emoji === ''} className={cx(emoji === '' && 'on')} onClick={() => { setEmoji(''); setPage(1); }}>Все · {total}</button>
        {tabs.map((t) => <button key={t.e} type="button" role="tab" aria-selected={emoji === t.e} className={cx(emoji === t.e && 'on')} onClick={() => { setEmoji(t.e); setPage(1); }}><Glyph e={t.e} size={16} still /> {t.n}</button>)}
      </div>
      {err && <div className="err">{err}</div>}
      <div className="rxWhoList">
        {list.map((w, i) => (
          <Link key={w.user_id + w.emoji + i} to={`/people/${w.user_id}`} className="rxWho" onClick={onClose}>
            <Avatar name={w.name} src={w.avatar} size={34} userId={w.user_id} /><span className="sp clip">{w.name}</span><Glyph e={w.emoji} size={18} still />
          </Link>
        ))}
        {busy && <Loading />}
      </div>
      {more && !busy && <Btn onClick={() => setPage((p) => p + 1)}>Показать ещё</Btn>}
    </Modal>
  );
}

function WhoPop({ anchor, type, id, emoji, onModal }: { anchor: HTMLElement; type: string; id: number; emoji: string; onModal: () => void }) {
  const [d, setD] = useState<WhoPage | null>(null);
  useEffect(() => { let dead = false; api.get<WhoPage>(whoUrl(type, id, emoji, 1, 8)).then((r) => !dead && setD(r)).catch(() => {}); return () => { dead = true; }; }, [type, id, emoji]);
  const r = anchor.getBoundingClientRect();
  const left = Math.max(8, Math.min(r.left, innerWidth - 228));
  const below = r.top < 190;
  const st: React.CSSProperties = below ? { left, top: r.bottom + 4 } : { left, bottom: innerHeight - r.top + 4 };
  const total = d?.reactions.find((x) => x.e === emoji)?.n ?? 0;
  return createPortal(
    <div className="rxPop" style={st} role="tooltip">
      <div className="rxPopH"><Glyph e={emoji} size={16} still /> <b>{total || ''}</b></div>
      {!d ? <div className="tiny faint">Загрузка…</div> : d.items.map((w) => <div key={w.user_id} className="rxPopU"><Avatar name={w.name} src={w.avatar} size={20} userId={w.user_id} /><span className="clip">{w.name}</span></div>)}
      {d && total > d.items.length && <button type="button" className="rxMore" onClick={onModal}>и ещё {total - d.items.length}…</button>}
    </div>, document.body);
}

function Chip({ r, type, id, toggle, showLabel }: { r: Rx; type: string; id: number; toggle: (e: string) => void; showLabel?: boolean }) {
  const ref = useRef<HTMLButtonElement>(null);
  const [pop, setPop] = useState(false);
  const [modal, setModal] = useState(false);
  const t1 = useRef<any>(null), t2 = useRef<any>(null);
  const enter = () => { clearTimeout(t1.current); if (r.n > 0) t1.current = setTimeout(() => setPop(true), 450); };
  const leave = () => { clearTimeout(t1.current); setPop(false); };
  useEffect(() => () => { clearTimeout(t1.current); clearTimeout(t2.current); }, []);
  return (
    <>
      <button ref={ref} type="button" className={cx('rx', r.m && 'on')} aria-pressed={!!r.m} aria-label={`${r.e} ${r.n}`}
        onClick={(e) => { e.preventDefault(); leave(); toggle(r.e); }} onMouseEnter={enter} onMouseLeave={leave} onFocus={enter} onBlur={leave}
        onContextMenu={(e) => { if (r.n > 0) { e.preventDefault(); leave(); setModal(true); } }}
        onTouchStart={() => { clearTimeout(t2.current); t2.current = setTimeout(() => { if (r.n > 0) setModal(true); }, 550); }} onTouchEnd={() => clearTimeout(t2.current)} onTouchMove={() => clearTimeout(t2.current)}>
        <Glyph e={r.e} size={16} />{r.n > 0 ? <span className="n">{r.n}</span> : showLabel ? <span className="lbl">Нравится</span> : null}
      </button>
      {pop && ref.current && <WhoPop anchor={ref.current} type={type} id={id} emoji={r.e} onModal={() => { setPop(false); setModal(true); }} />}
      {modal && <WhoModal type={type} id={id} start={r.e} onClose={() => setModal(false)} />}
    </>
  );
}

/** Полоса реакций. pinLike — всегда показывать 👍 «Нравится» (новости, идеи, публикации). noAdd — без кнопки добавления (она выведена отдельно). */
export function Reactions({ type, id, initial, pinLike, noAdd, className, compact }: { type: string; id: number; initial?: Rx[]; pinLike?: boolean; noAdd?: boolean; className?: string; compact?: boolean }) {
  const { items, toggle } = useReactions(type, id, initial);
  const list = pinLike && !items.some((x) => x.e === LIKE) ? [{ e: LIKE, n: 0 } as Rx, ...items] : items;
  if (!list.length && noAdd) return null;
  const mine = new Set(items.filter((x) => x.m).map((x) => x.e));
  return (
    <div className={cx('rxRow', compact && 'compact', className)} role="group" aria-label="Реакции">
      {list.map((r) => <Chip key={r.e} r={r} type={type} id={id} toggle={toggle} showLabel={pinLike && r.e === LIKE && !compact} />)}
      {!noAdd && <ReactionAddButton mine={mine} onPick={toggle} />}
    </div>
  );
}

/** Сводка для карточек списка: до трёх самых частых реакций и общее число. */
export function ReactionSummary({ items, fallback = 0, className }: { items?: Rx[]; fallback?: number; className?: string }) {
  const list = items || [];
  const total = list.reduce((a, b) => a + b.n, 0) || fallback;
  if (!total) return <span className={cx('rxSum', className)} title="Реакции"><X.Smile size={15} />0</span>;
  return (
    <span className={cx('rxSum', className)} title="Реакции">
      {list.slice(0, 3).map((r) => <span key={r.e} className="g"><Glyph e={r.e} size={14} still /></span>)}{!list.length && <X.Smile size={15} />}{total}
    </span>
  );
}
