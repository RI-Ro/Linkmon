import React, { useRef, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { Btn, Textarea } from './index';
import { EmojiButton, TextAssist } from './EmojiPicker';

/** Markdown textarea with a toolbar. Images are uploaded and inserted as `![имя](url){w=50%}` (any number, any size ≤100%). */
export function MdEditor({ value, onChange, rows = 12, images = true, placeholder, onImageUpload }: { value: string; onChange: (v: string) => void; rows?: number; images?: boolean; placeholder?: string; onImageUpload?: (f: File) => Promise<string> }) {
  const ta = useRef<HTMLTextAreaElement>(null);
  const file = useRef<HTMLInputElement>(null);
  const [width, setWidth] = useState('50%');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  function edit(fn: (sel: string) => { text: string; select?: [number, number] }) {
    const el = ta.current!;
    const a = el.selectionStart, b = el.selectionEnd;
    const r = fn(value.slice(a, b));
    onChange(value.slice(0, a) + r.text + value.slice(b));
    requestAnimationFrame(() => { el.focus(); const s = r.select || [a + r.text.length, a + r.text.length]; el.setSelectionRange(a + s[0], a + s[1]); });
  }
  const wrap = (l: string, r = l, ph = 'текст') => edit((s) => ({ text: l + (s || ph) + r, select: [l.length, l.length + (s || ph).length] }));
  const prefix = (p: string) => edit((s) => ({ text: (s || 'текст').split('\n').map((x, i) => p.replace('#', String(i + 1)) + x).join('\n') }));
  const heading = (p: string) => edit((s) => ({ text: '\n\n' + p + (s || 'Заголовок') + '\n\n' }));

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true); setErr('');
    let out = '';
    try {
      for (const f of Array.from(files)) {
        const r = { url: onImageUpload ? await onImageUpload(f) : (await api.upload<{ url: string }>('/api/uploads/public', f)).url }; // onImageUpload — защищённое хранилище (Wiki)
        const w = /^\d+$/.test(width) ? width : width;
        out += `\n\n![${f.name.replace(/\.[^.]+$/, '').replace(/[\[\]()]/g, '')}](${r.url}){w=${w}}\n\n`;
      }
      edit(() => ({ text: out }));
    } catch (e) { setErr(errMsg(e)); }
    setBusy(false);
  }
  const T = (title: string, f: () => void, children: React.ReactNode) => <button type="button" className="btn ghost" title={title} onClick={f}>{children}</button>;
  return (
    <div>
      <div className="mdTools">
        {T('Крупный заголовок', () => heading('# '), <b>H1</b>)}
        {T('Заголовок', () => heading('## '), <b>H2</b>)}
        {T('Подзаголовок', () => heading('### '), <b>H3</b>)}
        {T('Жирный', () => wrap('**'), <b>Ж</b>)}
        {T('Курсив', () => wrap('*'), <i>К</i>)}
        {T('Маркированный список', () => prefix('- '), <I.List size={16} />)}
        {T('Нумерованный список', () => prefix('#. '), '1.')}
        {T('Цитата', () => prefix('> '), '❝')}
        <EmojiButton target={ta} value={value} onChange={onChange} size={16} />
        {T('Ссылка', () => edit((s) => ({ text: `[${s || 'текст'}](https://)`, select: [1, 1 + (s || 'текст').length] })), <I.Link size={16} />)}
        {images && (
          <>
            <span style={{ flex: 1 }} />
            <select className="sel" style={{ width: 118, minHeight: 30, fontSize: 13 }} value={width} onChange={(e) => setWidth(e.target.value)} title="Ширина вставляемых картинок">
              {['25%', '33%', '50%', '66%', '75%', '100%', '200', '320', '480', '640'].map((w) => <option key={w} value={w}>{w.endsWith('%') ? w + ' ширины' : w + ' px'}</option>)}
            </select>
            <Btn size="sm" type="button" busy={busy} onClick={() => file.current?.click()}><I.Image size={15} /> Фото</Btn>
            <input ref={file} type="file" accept="image/*" multiple hidden onChange={(e) => { upload(e.target.files); e.target.value = ''; }} />
          </>
        )}
      </div>
      <Textarea ref={ta} rows={rows} value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)}
        onPaste={(e) => { const fs = Array.from(e.clipboardData.files).filter((f) => f.type.startsWith('image/')); if (images && fs.length) { e.preventDefault(); const dt = new DataTransfer(); fs.forEach((f) => dt.items.add(f)); upload(dt.files); } }} />
      <TextAssist target={ta} value={value} onChange={onChange} />
      {images && <div className="hint tiny muted" style={{ marginTop: 4 }}>Размер картинки: <code>![подпись](адрес){'{w=50%}'}</code> — в процентах или px, но не шире блока новости.</div>}
      {err && <div className="err">{err}</div>}
    </div>
  );
}
