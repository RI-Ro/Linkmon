import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import * as I from '../lib/icons';
import { readPersist, usePersist, writePersist } from '../lib/persist';
import { ensureMapPolyfill } from '../lib/polyfill-map';
import './pdfviewer.css';

/**
 * Просмотр PDF без скачивания всего файла (pdf.js).
 *  - библиотека грузится лениво (отдельный chunk при первом открытии PDF), воркер — тот же origin (/assets/pdf.worker-*.js);
 *  - данные читаются HTTP Range-запросами (rangeChunkSize 256 КБ, disableAutoFetch): скачиваются только нужные страницы;
 *  - виртуализация: отрисовываются только видимые страницы ±1 (canvas с учётом devicePixelRatio, отмена при прокрутке);
 *  - панель: страница/всего, масштаб (+/−, по ширине, по странице), поворот, поиск по тексту, полный экран, «Скачать»;
 *  - клавиши: PgUp/PgDn/Home/End, ←/→, +/−/0, R, Ctrl+F, Ctrl+колесо; на сенсорных экранах — pinch;
 *  - масштаб и последняя страница файла запоминаются для пользователя (lib/persist).
 * Экспорт: PdfViewer (встраиваемый), PdfModal (на весь экран), usePdfPreview (хук для блоков), isPdfFile.
 */

declare const __PDF_WORKER__: string;

export interface PdfFile { id?: number; url?: string; name: string; mime?: string; size?: number }

export const isPdfFile = (f: { mime?: string; name?: string }) => f.mime === 'application/pdf' || /\.pdf$/i.test(f.name || '');
const srcOf = (f: PdfFile) => f.url || `/files/${f.id}`;
const dlOf = (f: PdfFile) => (f.url ? f.url : `/files/${f.id}?dl=1`);

// ---------------------------------------------------------------- загрузка библиотеки

let pdfjsP: Promise<any> | null = null;
function loadPdfjs(): Promise<any> {
  if (!pdfjsP) {
    ensureMapPolyfill();
    pdfjsP = import('pdfjs-dist').then((m: any) => {
      m.GlobalWorkerOptions.workerSrc = __PDF_WORKER__;
      return m;
    });
    pdfjsP.catch(() => { pdfjsP = null; });
  }
  return pdfjsP;
}

// ---------------------------------------------------------------- вспомогательное

type Zoom = 'width' | 'page' | number;
const STEPS = [0.25, 0.33, 0.5, 0.67, 0.8, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2, 2.5, 3, 4, 5];
const MIN_Z = 0.2, MAX_Z = 6;
const PAD = 12, GAP = 12;
const MAX_PIXELS = 16_000_000; // потолок размера canvas (память на телефонах)
const clamp = (v: number, a: number, b: number) => Math.min(Math.max(v, a), b);

const Icon = ({ d, size = 18 }: { d: React.ReactNode; size?: number }) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{d}</svg>
);
const IMinus = () => <Icon d={<path d="M5 12h14" />} />;
const IRotate = () => <Icon d={<><path d="M21 12a9 9 0 1 1-3-6.7L21 8" /><path d="M21 3v5h-5" /></>} />;
const IFitW = () => <Icon d={<><path d="M3 5v14M21 5v14" /><path d="M7 12h10M10 9l-3 3 3 3M14 9l3 3-3 3" /></>} />;
const IFitP = () => <Icon d={<><rect x="6" y="3" width="12" height="18" rx="1" /><path d="M9 8l3-3 3 3M9 16l3 3 3-3" /></>} />;

function lastPages(): Record<string, number> { return readPersist<Record<string, number>>('pdf.last', {}); }
function rememberPage(key: string, page: number) {
  const m = lastPages();
  delete m[key];
  m[key] = page;
  const keys = Object.keys(m);
  if (keys.length > 200) for (const k of keys.slice(0, keys.length - 200)) delete m[k];
  writePersist('pdf.last', m);
}

// ---------------------------------------------------------------- страница

interface PageViewProps {
  doc: any; pdfjs: any; n: number; scale: number; rot: number; w: number; h: number; hl: string;
  onSize: (n: number, s: [number, number]) => void;
}

/** Одна страница: canvas + текстовый слой. Рендер стартует с задержкой (быстрая прокрутка не нагружает) и отменяется при уходе/смене масштаба. */
const PageView = React.memo(function PageView({ doc, pdfjs, n, scale, rot, w, h, hl, onSize }: PageViewProps) {
  const host = useRef<HTMLDivElement>(null);
  const textHost = useRef<HTMLDivElement>(null);
  const textDivs = useRef<HTMLElement[]>([]);
  const [busy, setBusy] = useState(true);

  useEffect(() => {
    let dead = false;
    let task: any = null, tl: any = null, page: any = null;
    setBusy(true);
    const timer = setTimeout(async () => {
      try {
        page = await doc.getPage(n);
        if (dead) return;
        const v1 = page.getViewport({ scale: 1, rotation: 0 });
        onSize(n, [v1.width, v1.height]);
        const vp = page.getViewport({ scale, rotation: rot });
        let ratio = Math.min(window.devicePixelRatio || 1, 3);
        const px = vp.width * vp.height * ratio * ratio;
        if (px > MAX_PIXELS) ratio *= Math.sqrt(MAX_PIXELS / px);
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.floor(vp.width * ratio));
        canvas.height = Math.max(1, Math.floor(vp.height * ratio));
        canvas.style.width = '100%';
        canvas.style.height = '100%';
        task = page.render({ canvas, viewport: vp, transform: ratio !== 1 ? [ratio, 0, 0, ratio, 0, 0] : undefined, background: '#ffffff' });
        await task.promise;
        if (dead) return;
        host.current?.replaceChildren(canvas); // новый canvas заменяет старый только после готовности — без мерцания
        setBusy(false);
        // текстовый слой (выделение и подсветка поиска)
        const th = textHost.current;
        if (th) {
          th.replaceChildren();
          th.style.setProperty('--total-scale-factor', String(scale));
          th.style.setProperty('--scale-round-x', '1px');
          th.style.setProperty('--scale-round-y', '1px');
          tl = new pdfjs.TextLayer({ textContentSource: page.streamTextContent(), container: th, viewport: vp });
          await tl.render();
          if (dead) return;
          textDivs.current = tl.textDivs;
          markHits(textDivs.current, hlRef.current);
        }
      } catch (e: any) {
        if (e?.name !== 'RenderingCancelledException' && e?.name !== 'AbortException' && !dead) { console.warn('pdf page render', n, e); setBusy(false); }
      }
    }, 70);
    return () => {
      dead = true;
      clearTimeout(timer);
      try { task?.cancel(); } catch {}
      try { tl?.cancel(); } catch {}
      try { page?.cleanup?.(); } catch {}
    };
  }, [doc, n, scale, rot]);

  const hlRef = useRef(hl);
  hlRef.current = hl;
  useEffect(() => { markHits(textDivs.current, hl); }, [hl]);

  return (
    <div className="pdfPage" style={{ width: w, height: h }} data-page={n}>
      <div className="pdfCanvasHost" ref={host} />
      <div className="pdfTextLayer textLayer" ref={textHost} />
      {busy && <div className="pdfPageBusy"><i /></div>}
    </div>
  );
});

function markHits(divs: HTMLElement[], q: string) {
  const s = q.trim().toLowerCase();
  for (const d of divs) d.classList.toggle('hit', !!s && (d.textContent || '').toLowerCase().includes(s));
}

// ---------------------------------------------------------------- просмотрщик

export interface PdfViewerProps {
  src: string;
  name?: string;
  downloadHref?: string;
  /** ключ для запоминания последней страницы (по умолчанию — src) */
  fileKey?: string | number;
  onClose?: () => void;
  className?: string;
  style?: React.CSSProperties;
  autoFocus?: boolean;
}

export function PdfViewer({ src, name, downloadHref, fileKey, onClose, className, style, autoFocus = true }: PdfViewerProps) {
  const key = String(fileKey ?? src);
  const root = useRef<HTMLDivElement>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const inner = useRef<HTMLDivElement>(null);
  const [lib, setLib] = useState<any>(null);
  const [doc, setDoc] = useState<any>(null);
  const [err, setErr] = useState('');
  const [fb, setFb] = useState<{ id: string; pages: number } | null>(null); // серверный рендер страниц (pdftoppm), если pdf.js не справился
  const [prog, setProg] = useState(0);
  const [pages, setPages] = useState(0);
  const [base, setBase] = useState<[number, number] | null>(null);
  const [sizes, setSizes] = useState<Record<number, [number, number]>>({});
  const [box, setBox] = useState({ w: 0, h: 0 });
  const [zoom, setZoom] = usePersist<Zoom>('pdf.zoom', 'width');
  const [rot, setRot] = useState(0);
  const [cur, setCur] = useState(1);
  const [win, setWin] = useState<[number, number]>([1, 2]);
  const [pageInput, setPageInput] = useState('1');
  const [full, setFull] = useState(false);
  const [sOpen, setSOpen] = useState(false);
  const [sq, setSq] = useState('');
  const [sRes, setSRes] = useState<{ q: string; pages: number[]; total: number } | null>(null);
  const [sBusy, setSBusy] = useState('');
  const [sPos, setSPos] = useState(0);
  const anchor = useRef<{ page: number; frac: number } | null>(null);
  const restore = useRef(lastPages()[key] || 1);
  const searchTok = useRef(0);
  const textCache = useRef<Map<number, string>>(new Map());

  // ---- загрузка документа
  useEffect(() => {
    let dead = false;
    let task: any = null;
    setDoc(null); setErr(''); setFb(null); setProg(0); setPages(0); setBase(null); setSizes({}); setRot(0); setSRes(null); textCache.current = new Map();
    (async () => {
      try {
        const m = await loadPdfjs();
        if (dead) return;
        setLib(m);
        const o = location.origin;
        task = m.getDocument({
          url: new URL(src, o).href,
          withCredentials: true,
          rangeChunkSize: 256 * 1024, // страницы подгружаются кусками по 256 КБ (HTTP Range)
          disableAutoFetch: true,     // не докачивать остальной файл «в фоне»
          disableStream: false,
          isEvalSupported: false,
          cMapUrl: o + '/pdfjs/cmaps/', cMapPacked: true,
          standardFontDataUrl: o + '/pdfjs/standard_fonts/',
          wasmUrl: o + '/pdfjs/wasm/',
          iccUrl: o + '/pdfjs/iccs/',
        });
        task.onProgress = (p: { loaded: number; total: number }) => !dead && p.total && setProg(p.loaded / p.total);
        task.onPassword = () => { if (!dead) setErr('Файл защищён паролем — откройте его после скачивания.'); task.destroy(); };
        const d = await task.promise;
        if (dead) { d.destroy(); return; }
        const p1 = await d.getPage(1);
        const v = p1.getViewport({ scale: 1, rotation: 0 });
        if (dead) return;
        setBase([v.width, v.height]);
        setPages(d.numPages);
        const start = clamp(restore.current, 1, d.numPages);
        anchor.current = { page: start, frac: 0 };
        setCur(start);
        setDoc(d);
      } catch (e: any) {
        if (dead) return;
        const st = e?.status;
        const fid = /^\/files\/(\d+)/.exec(src)?.[1];
        if (fid && st !== 403 && st !== 404 && e?.name !== 'PasswordException') {
          try {
            const r = await fetch(`/api/files/${fid}/pdf/info`, { credentials: 'same-origin' });
            const j = r.ok ? await r.json() : null;
            if (!dead && j?.pages > 0) { setFb({ id: fid, pages: j.pages }); return; }
          } catch {}
          if (dead) return;
        }
        setErr(st === 403 ? 'Нет доступа к файлу.' : st === 404 ? 'Файл не найден.' : e?.name === 'PasswordException' ? 'Файл защищён паролем — откройте его после скачивания.'
          : e?.name === 'InvalidPDFException' ? 'Не удалось прочитать PDF: файл повреждён.' : 'Не удалось открыть PDF. Попробуйте скачать файл.');
      }
    })();
    return () => { dead = true; try { task?.destroy(); } catch {} };
  }, [src]);

  // ---- размеры контейнера
  useLayoutEffect(() => {
    const el = scroller.current;
    if (!el) return;
    const upd = () => setBox((b) => (b.w === el.clientWidth && b.h === el.clientHeight ? b : { w: el.clientWidth, h: el.clientHeight }));
    upd();
    const ro = new ResizeObserver(upd);
    ro.observe(el);
    return () => ro.disconnect();
  }, [!!doc, !!err]);

  // ---- раскладка
  const rotated = rot % 180 !== 0;
  const dim = useCallback((n: number): [number, number] => {
    const s = sizes[n] || base || [612, 792];
    return rotated ? [s[1], s[0]] : s;
  }, [sizes, base, rotated]);
  const scale = useMemo(() => {
    if (!base) return 1;
    const [w, h] = rotated ? [base[1], base[0]] : base;
    const aw = Math.max(box.w - 2 * PAD, 60), ah = Math.max(box.h - 2 * PAD, 60);
    if (zoom === 'width') return clamp(aw / w, MIN_Z, 3);
    if (zoom === 'page') return clamp(Math.min(aw / w, ah / h), MIN_Z, MAX_Z);
    return clamp(zoom, MIN_Z, MAX_Z);
  }, [base, rotated, box, zoom]);
  const layout = useMemo(() => {
    const tops: number[] = [], hs: number[] = [];
    let y = PAD, maxW = 0;
    for (let n = 1; n <= pages; n++) {
      const [w, h] = dim(n);
      tops.push(y); hs.push(h * scale);
      y += h * scale + GAP;
      maxW = Math.max(maxW, w * scale);
    }
    return { tops, hs, total: pages ? y - GAP + PAD : 0, width: Math.max(box.w, maxW + 2 * PAD) };
  }, [pages, dim, scale, box.w]);
  const L = useRef(layout);
  L.current = layout;

  // ---- прокрутка: текущая страница и окно отрисовки (видимые ±1)
  const compute = useCallback(() => {
    const el = scroller.current, { tops, hs } = L.current;
    if (!el || !tops.length) return;
    const st = el.scrollTop, H = el.clientHeight;
    const find = (y: number) => { let a = 0, b = tops.length - 1; while (a < b) { const m = (a + b + 1) >> 1; if (tops[m] <= y) a = m; else b = m - 1; } return a; };
    const c = find(st + H * 0.4);
    anchor.current = { page: c + 1, frac: clamp((st - tops[c]) / Math.max(hs[c], 1), -1, 2) };
    setCur((o) => (o === c + 1 ? o : c + 1));
    const f = Math.min(find(st - H * 0.5), c), l = Math.max(find(st + H * 1.5), c);
    const a = Math.max(0, Math.min(f, c - 1)), b = Math.min(tops.length - 1, Math.max(l, c + 1));
    setWin((o) => (o[0] === a + 1 && o[1] === b + 1 ? o : [a + 1, b + 1]));
  }, []);
  const raf = useRef(0);
  const onScroll = useCallback(() => {
    if (raf.current) return;
    raf.current = requestAnimationFrame(() => { raf.current = 0; compute(); });
  }, [compute]);
  useEffect(() => () => cancelAnimationFrame(raf.current), []);

  // при смене масштаба/поворота/размеров остаёмся на той же странице (якорь), затем пересчитываем окно
  useLayoutEffect(() => {
    const el = scroller.current;
    if (!el || !pages) return;
    const a = anchor.current;
    if (a && layout.tops[a.page - 1] != null) el.scrollTop = layout.tops[a.page - 1] + a.frac * layout.hs[a.page - 1];
    compute();
  }, [layout.total, layout.width, pages]);

  useEffect(() => { setPageInput(String(cur)); if (doc) { const t = setTimeout(() => rememberPage(key, cur), 400); return () => clearTimeout(t); } }, [cur, doc]);

  const goPage = useCallback((n: number) => {
    const el = scroller.current;
    if (!el || !pages) return;
    const p = clamp(Math.round(n) || 1, 1, pages);
    anchor.current = { page: p, frac: 0 };
    el.scrollTop = L.current.tops[p - 1] - PAD / 2;
    compute();
  }, [pages, compute]);

  const setZ = useCallback((z: Zoom) => setZoom(z), [setZoom]);
  const stepZoom = useCallback((dir: 1 | -1) => {
    const s = scaleRef.current;
    const next = dir > 0 ? STEPS.find((x) => x > s * 1.01) ?? MAX_Z : [...STEPS].reverse().find((x) => x < s / 1.01) ?? MIN_Z;
    setZoom(next);
  }, [setZoom]);
  const scaleRef = useRef(scale);
  scaleRef.current = scale;

  // ---- Ctrl+колесо и pinch (нужен не-passive listener)
  useEffect(() => {
    const el = scroller.current;
    if (!el || !doc) return;
    const wheel = (e: WheelEvent) => {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();
      setZoom(clamp(scaleRef.current * Math.exp(-e.deltaY * (e.deltaMode ? 0.05 : 0.0025)), MIN_Z, MAX_Z));
    };
    let pinch: { d0: number; s0: number; ratio: number } | null = null;
    const dist = (t: TouchList) => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
    const ts = (e: TouchEvent) => { if (e.touches.length === 2) pinch = { d0: dist(e.touches), s0: scaleRef.current, ratio: 1 }; };
    const tm = (e: TouchEvent) => {
      if (!pinch || e.touches.length !== 2) return;
      e.preventDefault();
      pinch.ratio = clamp((dist(e.touches) / pinch.d0) * pinch.s0, MIN_Z, MAX_Z) / pinch.s0;
      if (inner.current) {
        const r = el.getBoundingClientRect();
        const cx = (e.touches[0].clientX + e.touches[1].clientX) / 2 - r.left + el.scrollLeft;
        const cy = (e.touches[0].clientY + e.touches[1].clientY) / 2 - r.top + el.scrollTop;
        inner.current.style.transformOrigin = `${cx}px ${cy}px`;
        inner.current.style.transform = `scale(${pinch.ratio})`;
      }
    };
    const te = () => {
      if (!pinch) return;
      const p = pinch; pinch = null;
      if (inner.current) { inner.current.style.transform = ''; inner.current.style.transformOrigin = ''; }
      if (Math.abs(p.ratio - 1) > 0.02) setZoom(clamp(p.s0 * p.ratio, MIN_Z, MAX_Z));
    };
    el.addEventListener('wheel', wheel, { passive: false });
    el.addEventListener('touchstart', ts, { passive: true });
    el.addEventListener('touchmove', tm, { passive: false });
    el.addEventListener('touchend', te);
    el.addEventListener('touchcancel', te);
    return () => {
      el.removeEventListener('wheel', wheel); el.removeEventListener('touchstart', ts); el.removeEventListener('touchmove', tm);
      el.removeEventListener('touchend', te); el.removeEventListener('touchcancel', te);
    };
  }, [doc, setZoom]);

  // ---- полный экран
  useEffect(() => {
    const f = () => setFull(document.fullscreenElement === root.current);
    document.addEventListener('fullscreenchange', f);
    return () => document.removeEventListener('fullscreenchange', f);
  }, []);
  const toggleFull = () => {
    if (document.fullscreenElement) document.exitFullscreen?.();
    else root.current?.requestFullscreen?.().catch(() => {});
  };

  // ---- поиск по тексту (страницы читаются по мере необходимости и кэшируются)
  const runSearch = useCallback(async (qRaw: string) => {
    const q = qRaw.trim().toLowerCase();
    const tok = ++searchTok.current;
    if (!q || !doc) { setSRes(null); setSBusy(''); return; }
    const found: number[] = [];
    let total = 0;
    for (let n = 1; n <= doc.numPages; n++) {
      if (tok !== searchTok.current) return;
      let t = textCache.current.get(n);
      if (t == null) {
        setSBusy(`${n} / ${doc.numPages}`);
        try {
          const pg = await doc.getPage(n);
          const c = await pg.getTextContent();
          t = c.items.map((i: any) => i.str).join(' ').toLowerCase();
          pg.cleanup?.();
        } catch { t = ''; }
        textCache.current.set(n, t);
      }
      let i = -1, cnt = 0;
      while ((i = t.indexOf(q, i + 1)) >= 0) cnt++;
      if (cnt) { found.push(n); total += cnt; }
    }
    if (tok !== searchTok.current) return;
    setSBusy('');
    setSRes({ q: qRaw.trim(), pages: found, total });
    if (found.length) {
      const idx = Math.max(0, found.findIndex((p) => p >= cur));
      setSPos(idx);
      goPage(found[idx]);
    }
  }, [doc, cur, goPage]);
  const stepHit = (d: number) => {
    if (!sRes?.pages.length) return;
    const i = (sPos + d + sRes.pages.length) % sRes.pages.length;
    setSPos(i); goPage(sRes.pages[i]);
  };

  // ---- клавиши
  const onKey = (e: React.KeyboardEvent) => {
    const t = e.target as HTMLElement;
    if (t.tagName === 'INPUT' || t.tagName === 'SELECT') return;
    const el = scroller.current;
    if (!el) return;
    const ctrl = e.ctrlKey || e.metaKey;
    let h = true;
    if (ctrl && e.key.toLowerCase() === 'f') { setSOpen(true); setTimeout(() => root.current?.querySelector<HTMLInputElement>('.pdfSearch input')?.select(), 0); }
    else if (ctrl && (e.key === '+' || e.key === '=')) stepZoom(1);
    else if (ctrl && e.key === '-') stepZoom(-1);
    else if (ctrl) h = false;
    else if (e.key === 'PageDown' || (e.key === ' ' && !e.shiftKey)) el.scrollBy({ top: el.clientHeight * 0.9 });
    else if (e.key === 'PageUp' || (e.key === ' ' && e.shiftKey)) el.scrollBy({ top: -el.clientHeight * 0.9 });
    else if (e.key === 'Home') goPage(1);
    else if (e.key === 'End') goPage(pages);
    else if (e.key === 'ArrowRight' || (e.key === 'ArrowDown' && zoom === 'page')) goPage(cur + 1);
    else if (e.key === 'ArrowLeft' || (e.key === 'ArrowUp' && zoom === 'page')) goPage(cur - 1);
    else if (e.key === 'ArrowDown') el.scrollBy({ top: 60 });
    else if (e.key === 'ArrowUp') el.scrollBy({ top: -60 });
    else if (e.key === '+' || e.key === '=') stepZoom(1);
    else if (e.key === '-') stepZoom(-1);
    else if (e.key === '0') setZ('width');
    else if (e.key.toLowerCase() === 'r') setRot((r) => (r + 90) % 360);
    else h = false;
    if (h) e.preventDefault();
  };

  useEffect(() => { if (autoFocus && doc) scroller.current?.focus({ preventScroll: true }); }, [doc]);

  const onSize = useCallback((n: number, s: [number, number]) => {
    setSizes((o) => (o[n] && o[n][0] === s[0] && o[n][1] === s[1] ? o : { ...o, [n]: s }));
  }, []);

  const pct = Math.round(scale * 100);
  const zoomVal = typeof zoom === 'number' ? String(zoom) : zoom;
  const dl = downloadHref || src;
  const hl = sRes?.q || '';

  return (
    <div ref={root} className={'pdfv' + (full ? ' full' : '') + (className ? ' ' + className : '')} style={style} onKeyDown={onKey}>
      <div className="pdfBar" role="toolbar" aria-label="Просмотр PDF">
        {name && <div className="pdfName clip" title={name}>{name}</div>}
        <div className="pdfGrp">
          <input className="pdfPageIn" inputMode="numeric" aria-label="Номер страницы" value={pageInput} disabled={!doc}
            onChange={(e) => setPageInput(e.target.value.replace(/\D/g, ''))}
            onKeyDown={(e) => { if (e.key === 'Enter') { goPage(+pageInput); scroller.current?.focus(); } e.stopPropagation(); }}
            onBlur={() => setPageInput(String(cur))} />
          <span className="pdfOf">/ {pages || '–'}</span>
        </div>
        <div className="pdfGrp">
          <button type="button" className="pdfBtn" onClick={() => stepZoom(-1)} disabled={!doc} title="Уменьшить (−)" aria-label="Уменьшить"><IMinus /></button>
          <select className="pdfSel" value={zoomVal} onChange={(e) => { const v = e.target.value; setZ(v === 'width' || v === 'page' ? v : +v); }} disabled={!doc} aria-label="Масштаб">
            {typeof zoom === 'number' && !STEPS.includes(zoom) && <option value={zoom}>{Math.round(zoom * 100)}%</option>}
            <option value="width">По ширине · {zoom === 'width' ? pct + '%' : ''}</option>
            <option value="page">По странице</option>
            {STEPS.filter((s) => s >= 0.5 && s <= 4).map((s) => <option key={s} value={s}>{Math.round(s * 100)}%</option>)}
          </select>
          <button type="button" className="pdfBtn" onClick={() => stepZoom(1)} disabled={!doc} title="Увеличить (+)" aria-label="Увеличить"><I.Plus size={18} /></button>
          <button type="button" className={'pdfBtn pdfHideS' + (zoom === 'width' ? ' on' : '')} onClick={() => setZ('width')} disabled={!doc} title="По ширине (0)" aria-label="По ширине"><IFitW /></button>
          <button type="button" className={'pdfBtn pdfHideS' + (zoom === 'page' ? ' on' : '')} onClick={() => setZ('page')} disabled={!doc} title="По странице" aria-label="По странице"><IFitP /></button>
        </div>
        <div className="pdfGrp">
          <button type="button" className="pdfBtn" onClick={() => setRot((r) => (r + 90) % 360)} disabled={!doc} title="Повернуть (R)" aria-label="Повернуть"><IRotate /></button>
          <button type="button" className={'pdfBtn' + (sOpen ? ' on' : '')} onClick={() => { setSOpen((o) => !o); }} disabled={!doc} title="Поиск по тексту (Ctrl+F)" aria-label="Поиск по тексту"><I.Search size={18} /></button>
          <button type="button" className="pdfBtn" onClick={toggleFull} title="Во весь экран" aria-label="Во весь экран"><I.Maximize size={18} /></button>
          <a className="pdfBtn" href={dl} download={name || ''} title="Скачать" aria-label="Скачать"><I.Download size={18} /></a>
          {onClose && <button type="button" className="pdfBtn" onClick={onClose} title="Закрыть (Esc)" aria-label="Закрыть"><I.X size={19} /></button>}
        </div>
        {sOpen && (
          <form className="pdfSearch" onSubmit={(e) => { e.preventDefault(); if (sRes && sRes.q === sq.trim() && !sBusy) stepHit(1); else runSearch(sq); }}>
            <input autoFocus value={sq} placeholder="Найти в документе…" aria-label="Поиск в документе"
              onChange={(e) => { setSq(e.target.value); if (!e.target.value) { searchTok.current++; setSRes(null); setSBusy(''); } }}
              onKeyDown={(e) => { if (e.key === 'Escape') { e.stopPropagation(); setSOpen(false); scroller.current?.focus(); } }} />
            <span className="pdfSInfo">{sBusy ? `Поиск ${sBusy}` : sRes ? (sRes.pages.length ? `${sPos + 1} из ${sRes.pages.length} стр. · ${sRes.total}` : 'Не найдено') : ''}</span>
            <button type="button" className="pdfBtn" onClick={() => stepHit(-1)} disabled={!sRes?.pages.length} aria-label="Предыдущее"><I.ChevronUp size={18} /></button>
            <button type="button" className="pdfBtn" onClick={() => stepHit(1)} disabled={!sRes?.pages.length} aria-label="Следующее"><I.ChevronDown size={18} /></button>
          </form>
        )}
      </div>
      <div className="pdfScroll" ref={scroller} tabIndex={0} onScroll={onScroll} aria-label={name || 'Документ PDF'}>
        {fb ? (
          <div className="pdfFb">
            {Array.from({ length: Math.min(fb.pages, 500) }, (_, i) => (
              <img key={i} loading="lazy" decoding="async" alt={`Страница ${i + 1}`} src={`/api/files/${fb.id}/pdf/page/${i + 1}?w=1000`} />
            ))}
          </div>
        ) : err ? (
          <div className="pdfMsg"><I.Alert size={28} /><div>{err}</div><a className="btn pri" href={dl} download={name || ''}><I.Download size={16} /> Скачать</a></div>
        ) : !doc ? (
          <div className="pdfMsg"><div className="pdfSpin" /><div className="small">Открываем документ{prog > 0 && prog < 1 ? ` · ${Math.round(prog * 100)}%` : '…'}</div></div>
        ) : (
          <div className="pdfInner" ref={inner} style={{ width: layout.width, height: layout.total }}>
            {Array.from({ length: Math.max(0, win[1] - win[0] + 1) }, (_, k) => win[0] + k).filter((n) => n <= pages).map((n) => {
              const [w, h] = dim(n);
              return (
                <div key={n} className="pdfSlot" style={{ top: layout.tops[n - 1], left: (layout.width - w * scale) / 2 }}>
                  <PageView doc={doc} pdfjs={lib} n={n} scale={scale} rot={rot} w={w * scale} h={h * scale} hl={hl} onSize={onSize} />
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- модальный просмотр + хук

export function PdfModal({ file, onClose }: { file: PdfFile; onClose: () => void }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape' || document.fullscreenElement) return;
      const t = e.target as HTMLElement;
      if (t?.tagName === 'INPUT') return; // Esc в поле поиска/страницы обрабатывает сам просмотрщик
      onClose();
    };
    addEventListener('keydown', onKey);
    const ov = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { removeEventListener('keydown', onKey); document.body.style.overflow = ov; };
  }, [onClose]);
  return createPortal(
    <div className="pdfModal" role="dialog" aria-modal="true" aria-label={file.name} onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <PdfViewer src={srcOf(file)} name={file.name} fileKey={file.id ?? file.url} downloadHref={dlOf(file)} onClose={onClose} className="inModal" />
    </div>,
    document.body,
  );
}

/**
 * Хук для любых блоков: `const pdf = usePdfPreview();` → в обработчике клика по ссылке на файл `pdf.onLinkClick(e, file)`
 * (для PDF открывает просмотр и отменяет переход, для остальных файлов возвращает false), а `{pdf.node}` выводится один раз в разметке.
 */
export function usePdfPreview() {
  const [file, setFile] = useState<PdfFile | null>(null);
  const open = useCallback((f: PdfFile) => setFile(f), []);
  const close = useCallback(() => setFile(null), []);
  const onLinkClick = useCallback((e: React.MouseEvent, f: PdfFile): boolean => {
    if (!isPdfFile(f) || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return false;
    e.preventDefault();
    setFile(f);
    return true;
  }, []);
  const node = file ? <PdfModal file={file} onClose={close} /> : null;
  return { open, close, onLinkClick, node, file };
}
