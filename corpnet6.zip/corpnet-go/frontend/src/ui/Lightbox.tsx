import React, { useCallback, useEffect, useState } from 'react';
import * as I from '../lib/icons';
import { download, imgFallback } from '../lib/util';

/** src — вариант для просмотра (view); full — оригинал для кнопки «Скачать оригинал» (по умолчанию выводится из src). */
export interface LightboxItem { src: string; name?: string; video?: boolean; full?: string }

/** Полноэкранный просмотр картинок и видео: стрелки, Esc, закрытие кликом по фону. */
export function Lightbox({ items, start = 0, onClose }: { items: LightboxItem[]; start?: number; onClose: () => void }) {
  const [idx, setIdx] = useState(Math.min(Math.max(start, 0), Math.max(items.length - 1, 0)));
  const go = useCallback((d: number) => setIdx((i) => (i + d + items.length) % items.length), [items.length]);
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') go(1);
      if (e.key === 'ArrowLeft') go(-1);
    };
    addEventListener('keydown', k);
    const ov = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { removeEventListener('keydown', k); document.body.style.overflow = ov; };
  }, [go, onClose]);
  const f = items[idx];
  if (!f) return null;
  return (
    <div className="lightbox" role="dialog" aria-modal="true" onClick={(e) => e.target === e.currentTarget && onClose()}>
      {f.video ? <video key={f.src} src={f.src} controls autoPlay /> : <img key={f.src} src={f.src} alt={f.name || ''} onError={imgFallback} />}
      <button className="x" onClick={onClose} aria-label="Закрыть"><I.X size={22} /></button>
      {items.length > 1 && (
        <>
          <button className="pv" onClick={() => go(-1)} aria-label="Назад"><I.ChevronLeft size={24} /></button>
          <button className="nx" onClick={() => go(1)} aria-label="Вперёд"><I.ChevronRight size={24} /></button>
        </>
      )}
      <div className="cap">
        {f.name}{items.length > 1 ? ` · ${idx + 1} / ${items.length}` : ''}
        {!f.video && f.src.startsWith('/') && <a className="capDl" href={download(f.full || f.src)} download={f.name || ''} target="_blank" rel="noopener noreferrer"><I.Download size={14} /> Скачать оригинал</a>}
      </div>
    </div>
  );
}
