// Просмотр PDF во вложениях и в тексте страницы: тонкая обёртка над ui/PdfViewer (pdf.js, постраничная загрузка).
import React, { useState } from 'react';
import * as I from '../../lib/icons';
import { PdfModal as BasePdfModal, PdfViewer } from '../../ui/PdfViewer';

export function WikiPdf({ id, name, collapsed }: { id: number; name: string; collapsed?: boolean }) {
  const [open, setOpen] = useState(!collapsed);
  return (
    <div className="wkPdf">
      <div className="wkPdfBar">
        <I.FileText size={18} /><span className="sp clip bold">{name}</span>
        <a className="btn sm" href={`/files/${id}?dl=1`} download={name}><I.Download size={15} /> Скачать</a>
        <button type="button" className="btn sm" onClick={() => setOpen(!open)}>{open ? 'Скрыть' : 'Показать'}</button>
      </div>
      {open && <PdfViewer src={`/files/${id}`} name={name} fileKey={id} downloadHref={`/files/${id}?dl=1`} autoFocus={false} className="wkPdfV" style={{ height: 560 }} />}
    </div>
  );
}

export const WikiPdfModal = ({ id, name, onClose }: { id: number; name: string; onClose: () => void }) => <BasePdfModal file={{ id, name, mime: 'application/pdf' }} onClose={onClose} />;
