import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { setQueryData } from '../../lib/query';
import { navigate } from '../../lib/router';
import { toast } from '../../lib/store';
import { cx, fmtSize } from '../../lib/util';
import { usePersist } from '../../lib/persist';
import { Btn, Check, Field, FileIcon, Input, Modal, UserPicker } from '../../ui';
import { MdEditor } from '../../ui/MdEditor';
import { ConflictModal } from './dialogs';
import { pagePath, refreshWiki, TEMPLATES, W, WSpace, WTree } from './lib';
import { WikiMarkdown } from './render';
import type { WFile, WPage } from './page';

interface PageData { page: WPage; files: WFile[]; crumbs: any[]; prev: any; next: any; children: any[]; space: WSpace }

/** PUT с доступом к телу ответа при 409 (api.put отбрасывает его). */
async function putPage(id: number, body: any): Promise<{ status: number; data: any }> {
  const res = await fetch(`${W}/pages/${id}`, { method: 'PUT', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const data = await res.json().catch(() => null);
  return { status: res.status, data };
}

const addDays = (n: number) => { const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };

interface Draft { title: string; body: string; v: number; tags: string; review: string }

export function PageEditor({ data, tree, space, onClose }: { data: PageData; tree: WTree; space: WSpace; onClose: () => void }) {
  const p = data.page;
  const [draft, setDraft] = usePersist<Draft | null>(`wiki:draft:${p.id}`, null);
  const restored = !!draft && draft.v === p.version && (draft.title !== p.title || draft.body !== p.body);
  const [title, setTitle] = useState(restored ? draft!.title : p.title);
  const [body, setBody] = useState(restored ? draft!.body : p.body);
  const [tags, setTags] = useState(restored ? draft!.tags : p.tags.join(', '));
  const [review, setReview] = useState(restored ? draft!.review : p.review_until || '');
  const [resp, setResp] = useState<{ id: number; name: string }[]>(p.responsible_id ? [{ id: p.responsible_id, name: p.responsible || '' }] : []);
  const [comment, setComment] = useState('');
  const [files, setFiles] = useState<WFile[]>(data.files);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [view, setView] = usePersist<'edit' | 'split' | 'preview'>('wiki:editview', 'edit');
  const [props, setProps] = useState(false);
  const [conflict, setConflict] = useState<any>(null);
  const [linkPick, setLinkPick] = useState(false);
  const [upl, setUpl] = useState<{ key: number; name: string; p: number; err?: string }[]>([]);
  const baseVer = useRef(p.version);
  const baseBody = useRef(p.body);
  const wrap = useRef<HTMLDivElement>(null);
  const inp = useRef<HTMLInputElement>(null);
  const [showRestored, setShowRestored] = useState(restored);
  const dirty = title !== p.title || body !== p.body || tags !== p.tags.join(', ') || review !== (p.review_until || '') || (resp[0]?.id ?? null) !== p.responsible_id;

  // черновик сохраняется локально, чтобы правки не терялись при закрытии вкладки
  useEffect(() => {
    if (!dirty) return;
    const t = setTimeout(() => setDraft({ title, body, v: baseVer.current, tags, review }), 600);
    return () => clearTimeout(t);
  }, [title, body, tags, review]);
  useEffect(() => {
    if (!dirty) return;
    const on = (e: BeforeUnloadEvent) => { e.preventDefault(); e.returnValue = ''; };
    addEventListener('beforeunload', on);
    return () => removeEventListener('beforeunload', on);
  }, [dirty]);

  const ta = () => wrap.current?.querySelector('textarea') as HTMLTextAreaElement | null;
  const insert = useCallback((text: string, selectFrom = 0, selectTo = 0) => {
    const el = ta();
    const a = el ? el.selectionStart : body.length, b = el ? el.selectionEnd : body.length;
    setBody((cur) => cur.slice(0, a) + text + cur.slice(b));
    requestAnimationFrame(() => { const e2 = ta(); if (e2) { e2.focus(); e2.setSelectionRange(a + (selectTo ? selectFrom : text.length), a + (selectTo || text.length)); } });
  }, [body.length]);

  async function uploadFiles(list: File[], inlineImages = false) {
    const jobs = list.map((f, i) => ({ f, key: Date.now() + i }));
    setUpl((u) => [...u, ...jobs.map((j) => ({ key: j.key, name: j.f.name, p: 0 }))]);
    for (const j of jobs) {
      try {
        const r = await api.upload<WFile[]>(`${W}/pages/${p.id}/files`, j.f, (pr) => setUpl((u) => u.map((x) => (x.key === j.key ? { ...x, p: pr } : x))));
        setFiles((fs) => [...fs, ...r]);
        setUpl((u) => u.filter((x) => x.key !== j.key));
        if (inlineImages && r[0]?.mime.startsWith('image/')) insert(`\n\n![${r[0].name.replace(/\.[^.]+$/, '').replace(/[\[\]()]/g, '')}](/files/${r[0].id}){w=60%}\n\n`);
      } catch (e) { setUpl((u) => u.map((x) => (x.key === j.key ? { ...x, err: errMsg(e) } : x))); }
    }
  }
  /** загрузка картинки из панели MdEditor: файл становится вложением страницы, в текст вставляется защищённая ссылка */
  const onImage = useCallback(async (f: File) => {
    const r = await api.upload<WFile[]>(`${W}/pages/${p.id}/files`, f);
    setFiles((fs) => [...fs, ...r]);
    return `/files/${r[0].id}`;
  }, [p.id]);
  async function delFile(f: WFile) {
    if (!confirm(`Удалить вложение «${f.name}»?`)) return;
    try { await api.del(`${W}/pages/${p.id}/files/${f.id}`); setFiles((fs) => fs.filter((x) => x.id !== f.id)); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }

  async function save(over?: { base_version: number }) {
    if (!title.trim()) return setErr('Введите название страницы');
    setBusy(true); setErr('');
    const tagList = tags.split(',').map((t) => t.trim()).filter(Boolean);
    const payload: any = { title, body, base_version: over?.base_version ?? baseVer.current, comment, tags: tagList, review_until: review };
    if (resp[0]) payload.responsible_id = resp[0].id; else payload.clear_responsible = true;
    try {
      const { status, data: r } = await putPage(p.id, payload);
      if (status === 409 && r?.conflict) { setConflict(r.current); setBusy(false); return; }
      if (status === 401) { setErr('Сессия истекла. Войдите снова'); setBusy(false); return; }
      if (status < 200 || status >= 300) throw new Error(r?.error || 'Не удалось сохранить');
      setDraft(null);
      refreshWiki();
      onClose();
      if (title.trim() !== p.title) navigate(pagePath(space.id, p.id, title.trim()), { replace: true });
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  function cancel() {
    if (dirty && !confirm('Отменить правки? Несохранённые изменения будут потеряны.')) return;
    setDraft(null);
    onClose();
  }
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); if (!busy) save(); } };
    addEventListener('keydown', k);
    return () => removeEventListener('keydown', k);
  });

  const tools: [string, string, () => void][] = [
    ['[[ ]]', 'Ссылка на страницу базы ([[Название]])', () => setLinkPick(true)],
    ['Таблица', 'Вставить таблицу', () => insert('\n\n| Колонка 1 | Колонка 2 |\n|---|---|\n| Ячейка | Ячейка |\n\n')],
    ['</>', 'Блок кода', () => insert('\n\n```\nкод\n```\n\n', 5, 8)],
    ['☑', 'Чек-лист', () => insert('\n- [ ] Пункт 1\n- [ ] Пункт 2\n')],
    ['💡', 'Выноска (info, tip, warn, danger)', () => insert('\n\n> [!tip] Текст выноски\n\n', 10, 20)],
    ['―', 'Разделитель', () => insert('\n\n---\n\n')],
  ];

  const preview = <div className="wkPrev"><WikiMarkdown text={body} space={space.id} tree={tree} pdfs={new Map(files.filter((f) => f.mime === 'application/pdf').map((f) => [f.id, f.name]))} /></div>;
  return (
    <div className="wkMain">
      <div className="card wkEditor"
        onDragOver={(e) => { if (e.dataTransfer.types.includes('Files')) e.preventDefault(); }}
        onDrop={(e) => { if (e.dataTransfer.files.length) { e.preventDefault(); uploadFiles(Array.from(e.dataTransfer.files), true); } }}>
        <div className="wkEdBar">
          <input className="wkTitleIn" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} placeholder="Название страницы" aria-label="Название" />
          <div className="viewSw" role="group" aria-label="Режим">
            <button className={cx(view === 'edit' && 'on')} onClick={() => setView('edit')} title="Редактор" aria-label="Редактор"><I.Edit size={16} /></button>
            <button className={cx(view === 'split' && 'on')} onClick={() => setView('split')} title="Редактор и предпросмотр" aria-label="Рядом"><I.Layers size={16} /></button>
            <button className={cx(view === 'preview' && 'on')} onClick={() => setView('preview')} title="Предпросмотр" aria-label="Предпросмотр"><I.Eye size={16} /></button>
          </div>
        </div>
        {showRestored && (
          <div className="wkStale"><I.Info size={18} /><div className="sp">Восстановлен несохранённый черновик.</div>
            <Btn size="sm" onClick={() => { setTitle(p.title); setBody(p.body); setTags(p.tags.join(', ')); setReview(p.review_until || ''); setDraft(null); setShowRestored(false); }}>Отбросить черновик</Btn></div>
        )}
        <div className={cx('wkEdBody', view)}>
          {view !== 'preview' && (
            <div ref={wrap} className="wkEdPane">
              <div className="wkTools">
                {tools.map(([l, t, f]) => <button type="button" key={l} className="btn ghost sm" title={t} onClick={f}>{l}</button>)}
                {body.trim() === '' && (
                  <select className="sel" style={{ width: 'auto', minHeight: 30, fontSize: 13, marginLeft: 'auto' }} value="" onChange={(e) => { const t = TEMPLATES.find((x) => x.key === e.target.value); if (t) setBody(t.body); }} aria-label="Шаблон">
                    <option value="">Вставить шаблон…</option>
                    {TEMPLATES.filter((t) => t.body).map((t) => <option key={t.key} value={t.key}>{t.icon} {t.name}</option>)}
                  </select>
                )}
              </div>
              <MdEditor value={body} onChange={setBody} rows={view === 'split' ? 26 : 22} onImageUpload={onImage} placeholder="Текст страницы в markdown. Ссылка на другую страницу: [[Название]]" />
            </div>
          )}
          {view !== 'edit' && preview}
        </div>

        <div className="wkAtt">
          <div className="row"><b className="small"><I.Paperclip size={14} /> Вложения{files.length ? ` · ${files.length}` : ''}</b><span className="sp" />
            <Btn size="sm" onClick={() => inp.current?.click()}><I.Upload size={15} /> Прикрепить</Btn>
            <input ref={inp} type="file" multiple hidden onChange={(e) => { uploadFiles(Array.from(e.target.files || [])); e.target.value = ''; }} /></div>
          {files.map((f) => (
            <div key={f.id} className="wkFile">
              {f.mime.startsWith('image/') ? <span className="th"><img src={`/files/${f.id}?t=1`} alt="" /></span> : <FileIcon name={f.name} mime={f.mime} />}
              <div className="sp" style={{ minWidth: 0 }}><div className="small bold clip">{f.name}</div><div className="tiny muted">{fmtSize(f.size)}</div></div>
              <button type="button" className="btn sm" onClick={() => insert(f.mime.startsWith('image/') ? `\n\n![${f.name.replace(/\.[^.]+$/, '').replace(/[\[\]()]/g, '')}](/files/${f.id}){w=60%}\n\n` : `\n\n[${f.name.replace(/[\[\]]/g, '')}](/files/${f.id})\n\n`)}>В текст</button>
              <button type="button" className="btn ghost icon sm" onClick={() => delFile(f)} aria-label="Удалить вложение"><I.Trash size={15} /></button>
            </div>
          ))}
          {upl.map((u) => (
            <div key={u.key} className="stackS"><div className="row small"><span className="sp clip">{u.name}</span>{u.err ? <span style={{ color: 'var(--danger)' }}>{u.err}</span> : <span>{Math.round(u.p * 100)}%</span>}</div>{!u.err && <div className="prog"><i style={{ width: u.p * 100 + '%' }} /></div>}</div>
          ))}
          {!files.length && !upl.length && <div className="tiny muted">Перетащите файлы на редактор или нажмите «Прикрепить». Картинки можно вставлять из буфера.</div>}
        </div>

        <details className="wkProps" open={props} onToggle={(e) => setProps((e.target as HTMLDetailsElement).open)}>
          <summary>Свойства страницы: теги, ответственный, срок актуальности</summary>
          <div className="wkPropsGrid">
            <Field label="Теги (через запятую)"><Input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="отпуск, регламент" /></Field>
            <Field label="Ответственный за актуальность"><UserPicker single value={resp.map((r) => ({ id: r.id, name: r.name }))} onChange={(v) => setResp(v.map((x) => ({ id: x.id, name: x.name })))} /></Field>
            <Field label="Проверить до" hint="После этой даты страница получит пометку «устарело», а ответственный увидит её в списке на обновление.">
              <div className="rowW">
                <Input type="date" value={review} onChange={(e) => setReview(e.target.value)} style={{ width: 170 }} />
                {[['3 мес.', 90], ['6 мес.', 180], ['Год', 365]].map(([l, d]) => <button type="button" key={l as string} className="chip sm" onClick={() => setReview(addDays(d as number))}>{l}</button>)}
                {review && <button type="button" className="chip sm" onClick={() => setReview('')}>Снять</button>}
              </div>
            </Field>
          </div>
        </details>

        <div className="wkEdFoot">
          <Input className="sp" value={comment} onChange={(e) => setComment(e.target.value)} maxLength={300} placeholder="Что изменили (необязательно) — попадёт в историю" aria-label="Комментарий к правке" />
          <Btn onClick={cancel}>Отмена</Btn>
          <Btn kind="pri" busy={busy} onClick={() => save()}><I.Check size={16} /> Сохранить</Btn>
        </div>
        {err && <div className="err" style={{ margin: '0 18px 14px' }}>{err}</div>}
        <div className="tiny muted" style={{ padding: '0 18px 12px' }}>Ctrl+S — сохранить. Версия страницы: {baseVer.current}. Если коллега сохранит страницу раньше, вы увидите различия и сможете объединить правки.</div>
      </div>
      {conflict && (
        <ConflictModal base={baseBody.current} mine={body} theirs={conflict} onClose={() => setConflict(null)}
          onTake={(mode, text) => {
            baseVer.current = conflict.version;
            baseBody.current = conflict.body;
            if (mode !== 'mine') setBody(text);
            if (mode === 'theirs') setTitle(conflict.title);
            setConflict(null);
            if (mode === 'mine') setTimeout(() => save({ base_version: conflict.version }), 0);
            else toast({ title: mode === 'merged' ? 'Текст объединён — проверьте и сохраните' : 'Взята версия коллеги', kind: 'info' });
          }} />
      )}
      {linkPick && <LinkPicker tree={tree} onClose={() => setLinkPick(false)} onPick={(t) => { setLinkPick(false); insert(`[[${t}]]`); }} />}
    </div>
  );
}

function LinkPicker({ tree, onPick, onClose }: { tree: WTree; onPick: (title: string) => void; onClose: () => void }) {
  const [q, setQ] = useState('');
  const items = useMemo(() => {
    const t = q.trim().toLowerCase();
    const out = [];
    for (const n of tree.byId.values()) { if (!t || n.title.toLowerCase().includes(t)) out.push(n); if (out.length >= 30) break; }
    return out;
  }, [q, tree]);
  return (
    <Modal title="Ссылка на страницу" size="sm" onClose={onClose} footer={q.trim() && !tree.byTitle.has(q.trim().toLowerCase()) ? <Btn onClick={() => onPick(q.trim())}>Ссылка на новую страницу «{q.trim()}»</Btn> : undefined}>
      <div className="stackS">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Название страницы…" autoFocus onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); if (items[0]) onPick(items[0].title); else if (q.trim()) onPick(q.trim()); } }} />
        <div className="wkPickList">
          {items.map((n) => <button type="button" key={n.id} className="wkPickItem" onClick={() => onPick(n.title)}><I.FileText size={15} /> <span className="clip">{n.title}</span></button>)}
          {!items.length && <div className="small muted" style={{ padding: 8 }}>Такой страницы пока нет — её можно создать по красной ссылке.</div>}
        </div>
      </div>
    </Modal>
  );
}
