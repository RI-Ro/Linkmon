// Базы знаний (Wiki) в разделе «Обучение → Материалы».
//   /learning/wiki/:space            — главная базы знаний (:space = «id» или «id-slug»)
//   /learning/wiki/:space/:page      — страница («id» или «id-slug»); ?edit=1 — редактор; page = new?title=… — создание по красной ссылке
import React, { useState } from 'react';
import * as I from '../../lib/icons';
import { api } from '../../lib/api';
import { useQuery } from '../../lib/query';
import { Link, matchPath } from '../../lib/router';
import { cx } from '../../lib/util';
import { Btn } from '../../ui';
import { SpaceModal } from './dialogs';
import { W, WSpace, spacePath } from './lib';
import { WikiScreen } from './space';
import './wiki.css';

export { WikiSnippet } from './render';

/** Маршрут: возвращает экран базы знаний, если путь /learning/wiki/…, иначе null. */
export function wikiRoute(path: string): React.ReactNode | null {
  let m = matchPath('/learning/wiki/:space/:page', path);
  if (m) return <WikiScreen key={m.space} spaceSeg={m.space} pageSeg={m.page} />;
  m = matchPath('/learning/wiki/:space', path);
  if (m) return <WikiScreen key={m.space} spaceSeg={m.space} />;
  return null;
}
export const isWikiPath = (path: string) => path.startsWith('/learning/wiki');

/** Базы знаний в папке вкладки «Материалы» (рядом с папками и материалами, единое дерево). folder = 0 — корень. */
export function WikiShelf({ folder }: { folder: number }) {
  const { data } = useQuery<WSpace[]>(`wiki:shelf:${folder}`, () => api.get(`${W}/shelf?folder=${folder}`), { stale: 15000 });
  if (!data?.length) return null;
  return (
    <section className="wkShelf" aria-label="Базы знаний">
      <div className="lnFolders">
        {data.map((s) => (
          <Link key={s.id} to={spacePath(s.id)} className={cx('wkShelfCard card', /^c\d$/.test(s.cover) ? s.cover : 'c1')}>
            <span className="ic">{s.icon || '📘'}</span>
            <span className="sp" style={{ minWidth: 0 }}>
              <span className="bold clip" style={{ display: 'block' }}>{s.title}</span>
              <span className="tiny muted clamp2" style={{ display: 'block' }}>{s.description || 'База знаний'}</span>
            </span>
            {s.visibility === 'restricted' && <I.Lock size={14} className="faint" />}
          </Link>
        ))}
      </div>
    </section>
  );
}

/** Кнопка «База знаний» в панели папки материалов. */
export function WikiNewSpace({ folder, canCreate }: { folder: number; canCreate: boolean }) {
  const [open, setOpen] = useState(false);
  if (!canCreate) return null;
  return (
    <>
      <Btn onClick={() => setOpen(true)}><I.Book size={16} /> База знаний</Btn>
      {open && <SpaceModal folder={folder || null} onClose={() => setOpen(false)} />}
    </>
  );
}
