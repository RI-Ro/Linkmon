import React, { useEffect, useMemo, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { useQuery } from '../../lib/query';
import { Link, navigate, useSearchParams, useTitle } from '../../lib/router';
import { toast, useStore } from '../../lib/store';
import { usePersistSet } from '../../lib/persist';
import { cx, plural } from '../../lib/util';
import { Badge, Btn, Empty, Skel, usePopover, useConfirm } from '../../ui';
import { dRu, dtRu, idOf, pagePath, refreshWiki, spacePath, useWikiTree, W, WNode, WSpace, WTree } from './lib';
import { ImportModal, NewPageModal, Switcher, SpaceModal, WikiAcl } from './dialogs';
import { PageToc, PageView, prefetchPage } from './page';
import { useTree } from '../learning/common';
import { WikiSnippet } from './render';

// ---------------------------------------------------------------- дерево страниц (слева)

const KIDS_CAP = 200;

function TreeNav({ tree, space, selected }: { tree: WTree; space: WSpace; selected: number }) {
  const [open, setOpen] = usePersistSet(`wiki:exp:${space.id}`);
  const [more, setMore] = useState<Record<number, number>>({});
  const [drag, setDrag] = useState(0);
  const [over, setOver] = useState<{ id: number; pos: 'before' | 'into' | 'after' } | null>(null);
  const bad = useMemo(() => (drag ? tree.subtree(drag) : null), [drag, tree]);

  // раскрываем путь к открытой странице
  useEffect(() => {
    if (!selected || !tree.count) return;
    const anc = tree.path(selected).slice(0, -1).map((n) => n.id);
    if (anc.some((id) => !open.has(id))) setOpen((s) => { anc.forEach((id) => s.add(id)); return s; });
  }, [selected, tree.count]);

  async function drop(target: WNode, pos: 'before' | 'into' | 'after') {
    const id = drag;
    setDrag(0); setOver(null);
    if (!id || id === target.id || bad?.has(target.id)) return;
    let parent: number | null, before = 0;
    if (pos === 'into') parent = target.id;
    else {
      parent = target.pid || null;
      const sib = (parent ? tree.byId.get(parent)!.kids : tree.roots).filter((x) => x.id !== id);
      const i = sib.findIndex((x) => x.id === target.id);
      before = pos === 'before' ? target.id : sib[i + 1]?.id ?? 0;
    }
    try {
      await api.post(`${W}/pages/${id}/move`, { parent_id: parent, before_id: before });
      if (pos === 'into') setOpen((s) => s.add(target.id));
      refreshWiki();
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }

  const node = (n: WNode, depth: number): React.ReactNode => {
    const isOpen = open.has(n.id);
    const cap = more[n.id] || KIDS_CAP;
    const canDrag = n.level >= 3;
    return (
      <div key={n.id}>
        <div
          className={cx('wkNode', selected === n.id && 'on', over?.id === n.id && 'ov-' + over.pos, drag === n.id && 'dragging')}
          style={{ paddingLeft: 4 + depth * 14 }}
          draggable={canDrag}
          onDragStart={(e) => { e.dataTransfer.setData('text/x-wiki-page', String(n.id)); e.dataTransfer.effectAllowed = 'move'; setDrag(n.id); }}
          onDragEnd={() => { setDrag(0); setOver(null); }}
          onDragOver={(e) => {
            if (!drag || bad?.has(n.id) || n.level < 3) return;
            e.preventDefault();
            const r = e.currentTarget.getBoundingClientRect();
            const y = (e.clientY - r.top) / r.height;
            const pos = y < 0.28 ? 'before' : y > 0.72 ? 'after' : 'into';
            if (over?.id !== n.id || over.pos !== pos) setOver({ id: n.id, pos });
          }}
          onDragLeave={(e) => { if (e.currentTarget === e.target) setOver(null); }}
          onDrop={(e) => { if (drag && over) { e.preventDefault(); drop(n, over.pos); } }}
        >
          <button className={cx('wkTog', !n.kids.length && 'none', isOpen && 'open')} aria-label={isOpen ? 'Свернуть' : 'Развернуть'}
            onClick={() => setOpen((s) => { s.has(n.id) ? s.delete(n.id) : s.add(n.id); return s; })}><I.ChevronRight size={14} /></button>
          <Link to={pagePath(space.id, n.id, n.title)} className="wkLnk" onMouseEnter={() => prefetchPage(n.id)} title={n.title}>
            <span className="clip sp">{n.title}</span>
            {n.restricted && <I.Lock size={11} className="faint" />}
            {n.overdue && <span className="wkDot" title="Требует проверки" />}
          </Link>
        </div>
        {isOpen && n.kids.slice(0, cap).map((k) => node(k, depth + 1))}
        {isOpen && n.kids.length > cap && (
          <button className="wkMore" style={{ marginLeft: 22 + depth * 14 }} onClick={() => setMore({ ...more, [n.id]: cap + 200 })}>Показать ещё {Math.min(200, n.kids.length - cap)} из {n.kids.length - cap}</button>
        )}
      </div>
    );
  };
  const roots = tree.roots;
  const cap = more[0] || KIDS_CAP;
  return (
    <nav className="wkTree" aria-label="Страницы базы знаний">
      {roots.slice(0, cap).map((n) => node(n, 0))}
      {roots.length > cap && <button className="wkMore" onClick={() => setMore({ ...more, 0: cap + 200 })}>Показать ещё {Math.min(200, roots.length - cap)} из {roots.length - cap}</button>}
      {!roots.length && <div className="small muted" style={{ padding: '10px 12px' }}>Страниц пока нет</div>}
      {drag > 0 && (
        <div className={cx('wkRootDrop', over?.id === -1 && 'ov')}
          onDragOver={(e) => { e.preventDefault(); if (over?.id !== -1) setOver({ id: -1, pos: 'into' }); }}
          onDragLeave={() => setOver(null)}
          onDrop={async (e) => {
            e.preventDefault();
            const id = drag; setDrag(0); setOver(null);
            try { await api.post(`${W}/pages/${id}/move`, { parent_id: null, before_id: 0 }); refreshWiki(); } catch (er) { toast({ title: errMsg(er), kind: 'error' }); }
          }}>Перетащите сюда, чтобы вынести в корень</div>
      )}
    </nav>
  );
}

// ---------------------------------------------------------------- экран базы знаний

export function WikiScreen({ spaceSeg, pageSeg: pseg }: { spaceSeg: string; pageSeg?: string }) {
  const me = useStore((s) => s.me)!;
  const spaceId = idOf(spaceSeg);
  const pageId = pseg && pseg !== 'new' ? idOf(pseg) : 0;
  const { tree, space, error, loading, refetch } = useWikiTree(spaceId);
  const [sp] = useSearchParams();
  const [showTree, setShowTree] = useState(false);
  const [sw, setSw] = useState(false);
  const [newPage, setNewPage] = useState<null | { parent: number | null; title?: string }>(null);
  useTitle(space ? space.title : 'База знаний');

  // Ctrl+K — быстрый переход по страницам базы
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k' && !e.shiftKey) { e.preventDefault(); setSw(true); } };
    addEventListener('keydown', k);
    return () => removeEventListener('keydown', k);
  }, []);
  // красная ссылка: /learning/wiki/:space/new?title=…
  useEffect(() => {
    if (pseg === 'new' && space && space.level >= 3) setNewPage({ parent: null, title: sp.get('title') || '' });
  }, [pseg, space?.id]);
  useEffect(() => { setShowTree(false); }, [pageId]);

  if (!spaceId) return <div className="card"><Empty icon={I.Search} title="База знаний не найдена"><Link to="/learning/materials">В материалы</Link></Empty></div>;
  if (error && !space) {
    const gone = (error as any).status === 404 || (error as any).status === 403;
    return <div className="card"><Empty icon={gone ? I.Lock : I.Alert} title={gone ? 'База знаний не найдена или недоступна' : 'Не удалось загрузить базу знаний'}>
      {gone ? 'Возможно, у вас нет доступа или она была удалена.' : <Btn onClick={refetch}>Повторить</Btn>}<Link to="/learning/materials" className="btn" style={{ marginTop: 10 }}>В материалы</Link></Empty></div>;
  }
  if (!space) return (
    <div className="wkWrap"><aside className="wkSide card"><div className="stackS" style={{ padding: 12 }}>{[0, 1, 2, 3, 4, 5].map((i) => <Skel key={i} h={26} />)}</div></aside><div className="card padL stack"><Skel h={34} w="50%" /><Skel h={16} /><Skel h={16} w="80%" /></div></div>
  );
  const cur = pageId ? tree.byId.get(pageId) : undefined;
  const canEdit = space.level >= 3;
  return (
    <div className="wkWrap">
      <aside className={cx('wkSide', showTree && 'open')}>
        <button className="btn wkSideBtn block" onClick={() => setShowTree(!showTree)}><span>{space.icon || '📘'}</span><span className="sp clip" style={{ textAlign: 'left' }}>{cur ? cur.title : space.title}</span><I.ChevronDown size={16} /></button>
        <div className="wkSideBody card">
          <div className="wkSideHead">
            <Link to={spacePath(space.id)} className={cx('wkSpaceLnk', !pageId && 'on')}><span className="ic">{space.icon || '📘'}</span><span className="sp clip">{space.title}</span></Link>
            <button className="btn ghost icon sm" onClick={() => setSw(true)} title="Быстрый переход (Ctrl+K)" aria-label="Поиск по базе"><I.Search size={16} /></button>
            {canEdit && <button className="btn ghost icon sm" onClick={() => setNewPage({ parent: cur ? cur.id : null })} title="Новая страница" aria-label="Новая страница"><I.Plus size={16} /></button>}
          </div>
          <TreeNav tree={tree} space={space} selected={pageId} />
        </div>
      </aside>
      <div className="wkCenter">
        {pageId ? <PageView key={pageId} id={pageId} space={space} tree={tree} /> : <SpaceHome space={space} tree={tree} onNew={() => setNewPage({ parent: null })} onSwitch={() => setSw(true)} />}
      </div>
      <aside className="wkToc">{pageId ? <PageToc id={pageId} /> : null}</aside>
      {sw && <Switcher space={space} tree={tree} onClose={() => setSw(false)} />}
      {newPage && <NewPageModal space={space} parent={newPage.parent} tree={tree} title={newPage.title} onClose={() => { setNewPage(null); if (pseg === 'new') navigate(spacePath(space.id), { replace: true }); }} />}
    </div>
  );
}

// ---------------------------------------------------------------- главная базы знаний

interface RecentRow { id: number; title: string; slug: string; icon: string; updated_at: string; updated_by_name: string | null; version: number }
interface ReviewRow { id: number; title: string; review_until: string; days_over: number; responsible: string | null }

function SpaceHome({ space, tree, onNew, onSwitch }: { space: WSpace; tree: WTree; onNew: () => void; onSwitch: () => void }) {
  const me = useStore((s) => s.me)!;
  const [sp, setSp] = useSearchParams();
  const tag = sp.get('tag') || '';
  const mats = useTree('materials');
  const [modal, setModal] = useState<null | 'edit' | 'acl' | 'import'>(null);
  const [confirm, confirmNode] = useConfirm();
  const menu = usePopover();
  const canEdit = space.level >= 3, canManage = space.level >= 4;
  const recent = useQuery<RecentRow[]>(`wiki:recent:${space.id}`, () => api.get(`${W}/spaces/${space.id}/recent?limit=12`), { stale: 15000 });
  const [allReview, setAllReview] = useState(false);
  const review = useQuery<ReviewRow[]>(`wiki:review:${space.id}:${allReview ? 1 : 0}`, () => api.get(`${W}/spaces/${space.id}/review${allReview ? '?all=1' : ''}`), { stale: 15000 });
  const byTag = useQuery<any[]>(tag ? `wiki:tag:${space.id}:${tag}` : null, () => api.get(`${W}/search?q=${encodeURIComponent(tag)}&space=${space.id}&limit=50`), { stale: 15000 });
  const folderPath = space.folder_id ? mats.tree.path(space.folder_id) : [];

  async function remove() {
    if (!(await confirm(`Удалить базу знаний «${space.title}»?`, { text: `Будут удалены все страницы (${tree.count}), версии и вложения. Действие необратимо.`, ok: 'Удалить' }))) return;
    try { await api.del(`${W}/spaces/${space.id}`); refreshWiki(); toast({ title: 'База знаний удалена', kind: 'success' }); navigate(space.folder_id ? `/learning/materials?folder=${space.folder_id}` : '/learning/materials'); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  return (
    <div className="wkMain">
      <div className="wkCrumbs crumbs">
        <Link to="/learning/materials">Материалы</Link>
        {folderPath.map((f) => <React.Fragment key={f.id}><I.ChevronRight size={14} /><Link to={`/learning/materials?folder=${f.id}`}>{f.name}</Link></React.Fragment>)}
        <I.ChevronRight size={14} /><span style={{ color: 'var(--text)', fontWeight: 600 }}>{space.title}</span>
      </div>
      <div className={cx('wkHero', 'card', /^c\d$/.test(space.cover) ? space.cover : 'c1')} style={/^c\d$/.test(space.cover) || !space.cover ? undefined : { backgroundImage: `linear-gradient(rgba(0,0,0,.45), rgba(0,0,0,.55)), url(${space.cover})` }}>
        <div className="sp" style={{ minWidth: 0 }}>
          <div className="wkHeroIc">{space.icon || '📘'}</div>
          <h1>{space.title}{space.visibility === 'restricted' && <I.Lock size={18} style={{ marginLeft: 10, opacity: .8 }} />}</h1>
          {space.description && <p>{space.description}</p>}
        </div>
        <div className="rowW" style={{ flex: 'none', alignSelf: 'flex-start' }}>
          <Btn onClick={onSwitch}><I.Search size={16} /> Найти <kbd>Ctrl K</kbd></Btn>
          {canEdit && <Btn kind="pri" onClick={onNew}><I.Plus size={16} /> Страница</Btn>}
          <div style={{ position: 'relative' }} ref={menu.ref}>
            <Btn icon onClick={() => menu.setOpen(!menu.open)} aria-label="Действия с базой"><I.More size={18} /></Btn>
            {menu.open && (
              <div className="menu" onClick={() => menu.setOpen(false)}>
                <a href={`${W}/spaces/${space.id}/export.zip`} download><I.Download size={16} /> Экспорт всей базы (zip)</a>
                {canEdit && <button onClick={() => setModal('import')}><I.Upload size={16} /> Импорт из markdown</button>}
                {canManage && <><hr /><button onClick={() => setModal('edit')}><I.Edit size={16} /> Настройки</button><button onClick={() => setModal('acl')}><I.Lock size={16} /> Права доступа</button><button style={{ color: 'var(--danger)' }} onClick={remove}><I.Trash size={16} /> Удалить базу</button></>}
              </div>
            )}
          </div>
        </div>
      </div>

      {tag ? (
        <section className="card padL stack">
          <div className="row"><h3 className="lnH3 sp"><I.Tag size={15} /> Тег «{tag}»</h3><button className="btn ghost sm" onClick={() => setSp({ tag: null })}>Сбросить</button></div>
          {byTag.loading && !byTag.data ? <Skel h={40} /> : (byTag.data || []).length === 0 ? <div className="muted small">Страниц с таким тегом нет</div> : (
            <div className="wkList">{(byTag.data || []).map((r: any) => <Link key={r.id} to={pagePath(space.id, r.id, r.title)} className="wkListRow"><I.FileText size={16} /><span className="sp"><b className="clip">{r.title}</b><span className="tiny muted clamp2"><WikiSnippet text={r.snippet} /></span></span></Link>)}</div>
          )}
        </section>
      ) : (
        <>
          <section className="stack">
            <h3 className="lnH3">Разделы</h3>
            {tree.roots.length === 0 ? (
              <div className="card"><Empty icon={I.Book} title="В этой базе знаний пока нет страниц">{canEdit ? <Btn kind="pri" onClick={onNew}><I.Plus size={16} /> Создать первую страницу</Btn> : 'Страницы появятся здесь, когда их добавят'}</Empty></div>
            ) : (
              <div className="wkKidGrid big">
                {tree.roots.map((n) => (
                  <Link key={n.id} to={pagePath(space.id, n.id, n.title)} className="wkKid card" onMouseEnter={() => prefetchPage(n.id)}>
                    <span className="ic"><I.FileText size={20} /></span>
                    <span className="sp" style={{ minWidth: 0 }}><b className="clip" style={{ display: 'block' }}>{n.title}</b>
                      <span className="tiny muted">{n.kids.length ? plural(n.kids.length, ['подстраница', 'подстраницы', 'подстраниц']) : 'страница'}</span></span>
                    {n.restricted && <I.Lock size={13} className="faint" />}
                  </Link>
                ))}
              </div>
            )}
          </section>

          <div className="wkCols">
            <section className="card padL stack">
              <h3 className="lnH3"><I.Clock size={15} /> Последние изменения</h3>
              {recent.loading && !recent.data ? <Skel h={80} /> : (recent.data || []).length === 0 ? <div className="muted small">Изменений пока нет</div> : (
                <div className="wkList">{(recent.data || []).map((r) => (
                  <Link key={r.id} to={pagePath(space.id, r.id, r.title)} className="wkListRow" onMouseEnter={() => prefetchPage(r.id)}>
                    <I.FileText size={16} /><span className="sp"><b className="clip">{r.title}</b><span className="tiny muted">{dtRu(r.updated_at)}{r.updated_by_name ? ' · ' + r.updated_by_name : ''}</span></span>{r.version > 1 && <span className="tiny faint">v{r.version}</span>}
                  </Link>))}
                </div>
              )}
            </section>
            <section className="card padL stack">
              <div className="row"><h3 className="lnH3 sp"><I.Alert size={15} /> Требуют обновления</h3>
                {canEdit && <label className="chk tiny"><input type="checkbox" checked={allReview} onChange={(e) => setAllReview(e.target.checked)} /> все страницы базы</label>}</div>
              {review.loading && !review.data ? <Skel h={80} /> : (review.data || []).length === 0 ? <div className="muted small">{allReview ? 'Устаревших страниц нет' : 'У вас нет страниц с истёкшим сроком проверки'}</div> : (
                <div className="wkList">{(review.data || []).map((r) => (
                  <Link key={r.id} to={pagePath(space.id, r.id, r.title)} className="wkListRow">
                    <I.Alert size={16} style={{ color: 'var(--warn)' }} /><span className="sp"><b className="clip">{r.title}</b><span className="tiny muted">срок {dRu(r.review_until)} · просрочено {plural(r.days_over, ['день', 'дня', 'дней'])}{r.responsible ? ' · ' + r.responsible : ''}</span></span>
                  </Link>))}
                </div>
              )}
            </section>
          </div>
        </>
      )}
      {modal === 'edit' && <SpaceModal edit={space} onClose={() => setModal(null)} />}
      {modal === 'acl' && <WikiAcl target={{ kind: 'space', id: space.id }} onClose={() => setModal(null)} />}
      {modal === 'import' && <ImportModal spaceId={space.id} parent={null} onClose={() => setModal(null)} />}
      {confirmNode}
    </div>
  );
}
