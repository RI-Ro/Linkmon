import React, { useEffect, useMemo, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { setQueryData, useQuery } from '../../lib/query';
import { Link, navigate, useSearchParams, useTitle } from '../../lib/router';
import { toast, useStore } from '../../lib/store';
import { copyLink, cx, fmtSize, plural } from '../../lib/util';
import { Avatar, Badge, Btn, Empty, ErrorBox, FileIcon, Loading, Skel, usePopover, useConfirm } from '../../ui';
import { dRu, dtRu, pagePath, refreshWiki, spacePath, W, WNode, WSpace, WTree } from './lib';
import { Toc, WikiMarkdown, wikiHeadings } from './render';
import { WikiPdf, WikiPdfModal } from './pdf';
import { PageEditor } from './edit';
import { CopyModal, MoveModal, NewPageModal, VersionsModal, WikiAcl, ImportModal } from './dialogs';
import { useTree } from '../learning/common';

export interface WFile { id: number; name: string; mime: string; size: number; width?: number; height?: number; has_thumb?: boolean }
export interface WPage {
  id: number; space_id: number; parent_id: number | null; title: string; slug: string; icon: string; body: string; tags: string[]; version: number; views_count: number;
  restricted: boolean; owner_id: number | null; owner: string | null; responsible_id: number | null; responsible: string | null; review_until: string | null; overdue: boolean;
  created_at: string; updated_at: string; updated_by: number | null; updated_by_name: string | null; comments_count: number; level: number;
}
interface Kid { id: number; title: string; slug: string; icon: string; restricted: boolean }
interface PageData { page: WPage; files: WFile[]; crumbs: { id: number; title: string; slug: string }[]; prev: Kid | null; next: Kid | null; children: Kid[]; space: WSpace }

export const pageFetcher = (id: number) => () => api.get<PageData>(`${W}/pages/${id}`);

function scrollToHash() {
  const id = decodeURIComponent(location.hash.slice(1));
  if (!id) return;
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ block: 'start' });
}

export function PageView({ id, space, tree }: { id: number; space: WSpace; tree: WTree }) {
  const me = useStore((s) => s.me)!;
  const [sp, setSp] = useSearchParams();
  const editing = sp.get('edit') === '1';
  const { data, error, refetch, loading } = useQuery<PageData>(`wiki:page:${id}`, pageFetcher(id), { stale: 15000 });
  const mats = useTree('materials');
  const [confirm, confirmNode] = useConfirm();
  const [modal, setModal] = useState<null | 'new' | 'move' | 'copy' | 'acl' | 'versions' | 'import'>(null);
  const [pdf, setPdf] = useState<WFile | null>(null);
  const menu = usePopover();
  const p = data?.page;
  useTitle(p ? `${p.title} · ${space.title}` : space.title);

  // страница переехала в другую базу — каноническая ссылка
  useEffect(() => { if (data && data.space.id !== space.id) navigate(`/learning/wiki/${data.space.id}/${id}`, { replace: true }); }, [data?.space.id]);
  // после загрузки прокручиваем к якорю из ссылки (#раздел)
  useEffect(() => { if (data && !editing) setTimeout(scrollToHash, 30); }, [data?.page.id, editing]);
  useEffect(() => { window.scrollTo(0, 0); }, [id]);

  const headings = useMemo(() => (p ? wikiHeadings(p.body) : []), [p?.body]);
  const pdfs = useMemo(() => new Map((data?.files || []).filter((f) => f.mime === 'application/pdf').map((f) => [f.id, f.name])), [data?.files]);
  const node = tree.byId.get(id);

  if (error && !data) {
    const nf = (error as any).status === 404 || (error as any).status === 403;
    return <div className="card"><Empty icon={nf ? I.Lock : I.Alert} title={nf ? 'Страница не найдена или недоступна' : 'Не удалось загрузить страницу'}>
      {nf ? 'Возможно, у вас нет доступа к этой странице или она была удалена.' : <Btn onClick={refetch}>Повторить</Btn>}
      <Link to={spacePath(space.id)} className="btn" style={{ marginTop: 10 }}>В начало базы знаний</Link></Empty></div>;
  }
  if (!data || !p) return <div className="card padL stack"><Skel h={34} w="60%" /><Skel h={14} w="30%" /><Skel h={16} /><Skel h={16} w="90%" /><Skel h={16} w="75%" /><Skel h={16} w="85%" /></div>;

  const canEdit = p.level >= 3;
  const canManage = p.level >= 4 || (p.owner_id === me.id && canEdit);
  const siblings = node ? (node.pid ? tree.byId.get(node.pid)?.kids : tree.roots) || [] : [];
  const sIdx = siblings.findIndex((x) => x.id === id);
  async function moveRel(dir: -1 | 1) {
    if (!node) return;
    const t = siblings[sIdx + dir];
    if (!t) return;
    const before = dir < 0 ? t.id : (siblings[sIdx + 2]?.id ?? 0);
    try { await api.post(`${W}/pages/${id}/move`, { parent_id: node.pid || null, before_id: before }); refreshWiki(); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function remove() {
    const kids = node ? tree.subtree(id).size - 1 : 0;
    if (!(await confirm(`Удалить страницу «${p!.title}»?`, { text: kids ? `Будут удалены и все подстраницы (${kids}). Действие необратимо.` : 'Страница и её история будут удалены. Действие необратимо.', ok: 'Удалить' }))) return;
    try {
      await api.del(`${W}/pages/${id}`);
      refreshWiki(); toast({ title: 'Страница удалена', kind: 'success' });
      navigate(node?.pid ? pagePath(space.id, node.pid, tree.byId.get(node.pid)!.title) : spacePath(space.id));
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function markReviewed(days: number) {
    try {
      const r = await api.post(`${W}/pages/${id}/reviewed`, { days });
      setQueryData<PageData>(`wiki:page:${id}`, (d) => d && { ...d, page: { ...d.page, review_until: r.review_until, overdue: false } });
      refreshWiki(); toast({ title: 'Отмечено как актуальное', kind: 'success' });
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }

  if (editing) {
    return <PageEditor key={p.id} data={data} tree={tree} space={space} onClose={() => setSp({ edit: null })} />;
  }

  const folderPath = space.folder_id ? mats.tree.path(space.folder_id) : [];
  const exportHref = `${W}/spaces/${space.id}/export.zip?page=${id}`;
  return (
    <div className="wkMain">
      <div className="wkCrumbs crumbs">
        <Link to="/learning/materials">Материалы</Link>
        {folderPath.map((f) => <React.Fragment key={f.id}><I.ChevronRight size={14} /><Link to={`/learning/materials?folder=${f.id}`}>{f.name}</Link></React.Fragment>)}
        <I.ChevronRight size={14} /><Link to={spacePath(space.id)}>{space.icon} {space.title}</Link>
        {data.crumbs.slice(0, -1).map((c) => <React.Fragment key={c.id}><I.ChevronRight size={14} /><Link to={pagePath(space.id, c.id, c.title)}>{c.title}</Link></React.Fragment>)}
      </div>

      <article className="card wkArticle">
        <header className="wkHead">
          <div className="sp" style={{ minWidth: 0 }}>
            <h1 className="wkTitle">{p.icon && <span className="wkIcon">{p.icon}</span>}{p.title}{p.restricted && <span title="Ограниченный доступ" className="wkLock"><I.Lock size={18} /></span>}</h1>
            <div className="wkMeta">
              <span title={dtRu(p.updated_at)}><I.Clock size={13} /> {dtRu(p.updated_at)}</span>
              {p.updated_by_name && <span><I.Edit size={13} /> {p.updated_by_name}</span>}
              <span>версия {p.version}</span>
              <span><I.Eye size={13} /> {p.views_count}</span>
              {p.responsible && <span title="Ответственный за актуальность"><I.UserCheck size={13} /> {p.responsible}</span>}
              {p.review_until && !p.overdue && <span title="Проверить до"><I.Calendar size={13} /> проверить до {dRu(p.review_until)}</span>}
            </div>
            {p.tags.length > 0 && <div className="wkTags">{p.tags.map((t) => <Link key={t} to={`/learning/wiki/${space.id}?tag=${encodeURIComponent(t)}`} className="badge accent"><I.Tag size={11} /> {t}</Link>)}</div>}
          </div>
          <div className="rowW" style={{ flex: 'none' }}>
            {canEdit && <Btn kind="pri" onClick={() => setSp({ edit: 1 })}><I.Edit size={16} /> Править</Btn>}
            <div style={{ position: 'relative' }} ref={menu.ref}>
              <Btn kind="ghost" icon onClick={() => menu.setOpen(!menu.open)} aria-label="Действия со страницей"><I.More size={18} /></Btn>
              {menu.open && (
                <div className="menu" onClick={() => menu.setOpen(false)}>
                  {canEdit && <button onClick={() => setModal('new')}><I.Plus size={16} /> Новая страница</button>}
                  <button onClick={() => { copyLink(location.origin + pagePath(space.id, id, p.title)); toast({ title: 'Ссылка скопирована', kind: 'success' }); }}><I.Link size={16} /> Копировать ссылку</button>
                  {canEdit && <button onClick={() => setModal('versions')}><I.Clock size={16} /> История изменений</button>}
                  {canManage && <button onClick={() => setModal('acl')}><I.Lock size={16} /> Права доступа</button>}
                  {canEdit && <hr />}
                  {canEdit && sIdx > 0 && <button onClick={() => moveRel(-1)}><I.ChevronUp size={16} /> Выше</button>}
                  {canEdit && sIdx >= 0 && sIdx < siblings.length - 1 && <button onClick={() => moveRel(1)}><I.ChevronDown size={16} /> Ниже</button>}
                  {canEdit && <button onClick={() => setModal('move')}><I.Folder size={16} /> Переместить в…</button>}
                  <button onClick={() => setModal('copy')}><I.Copy size={16} /> Копировать в…</button>
                  <hr />
                  <a href={exportHref} download><I.Download size={16} /> Экспорт в markdown (zip)</a>
                  {canEdit && <button onClick={() => setModal('import')}><I.Upload size={16} /> Импорт внутрь…</button>}
                  {canManage && <><hr /><button style={{ color: 'var(--danger)' }} onClick={remove}><I.Trash size={16} /> Удалить</button></>}
                </div>
              )}
            </div>
          </div>
        </header>

        {p.overdue && (
          <div className="wkStale">
            <I.Alert size={18} />
            <div className="sp"><b>Материал мог устареть.</b> Срок проверки истёк {dRu(p.review_until)}{p.responsible ? ` · ответственный: ${p.responsible}` : ''}.</div>
            {canEdit && <div className="rowW">
              <Btn size="sm" onClick={() => markReviewed(90)}>Актуально ещё 3 мес.</Btn>
              <Btn size="sm" onClick={() => markReviewed(180)}>6 мес.</Btn>
              <Btn size="sm" onClick={() => markReviewed(365)}>год</Btn>
              <Btn size="sm" kind="pri" onClick={() => setSp({ edit: 1 })}>Обновить</Btn>
            </div>}
          </div>
        )}

        {headings.length > 2 && <details className="wkTocM"><summary>Содержание</summary><Toc headings={headings} /></details>}
        {p.body.trim() ? <WikiMarkdown text={p.body} space={space.id} tree={tree} pdfs={pdfs} />
          : <div className="muted" style={{ padding: '24px 0' }}>Страница пока пустая.{canEdit && <> <button type="button" className="linkBtn" onClick={() => setSp({ edit: 1 })}>Написать</button></>}</div>}

        <Attachments files={data.files} body={p.body} onPdf={setPdf} />

        {data.children.length > 0 && (
          <section className="wkKids">
            <h3 className="lnH3">Дочерние страницы</h3>
            <div className="wkKidGrid">
              {data.children.map((k) => (
                <Link key={k.id} to={pagePath(space.id, k.id, k.title)} className="wkKid" onMouseEnter={() => prefetchPage(k.id)}>
                  <span className="ic">{k.icon || <I.FileText size={18} />}</span><span className="sp clip bold">{k.title}</span>{k.restricted && <I.Lock size={12} className="faint" />}
                </Link>
              ))}
            </div>
          </section>
        )}

        {(data.prev || data.next) && (
          <nav className="wkPN" aria-label="Соседние страницы">
            {data.prev ? <Link to={pagePath(space.id, data.prev.id, data.prev.title)} onMouseEnter={() => prefetchPage(data.prev!.id)}><small><I.ChevronLeft size={13} /> Предыдущая</small><b className="clip">{data.prev.title}</b></Link> : <span />}
            {data.next ? <Link to={pagePath(space.id, data.next.id, data.next.title)} className="r" onMouseEnter={() => prefetchPage(data.next!.id)}><small>Следующая <I.ChevronRight size={13} /></small><b className="clip">{data.next.title}</b></Link> : <span />}
          </nav>
        )}
      </article>

      <Comments pageId={id} count={p.comments_count} canDeleteAll={canEdit} />

      {modal === 'new' && <NewPageModal space={space} parent={id} tree={tree} onClose={() => setModal(null)} />}
      {modal === 'move' && node && <MoveModal page={node} tree={tree} spaceId={space.id} onClose={() => setModal(null)} />}
      {modal === 'copy' && node && <CopyModal page={node} spaceId={space.id} onClose={() => setModal(null)} />}
      {modal === 'acl' && <WikiAcl target={{ kind: 'page', id }} title={`Права на «${p.title}»`} onClose={() => setModal(null)} />}
      {modal === 'versions' && <VersionsModal pageId={id} current={{ title: p.title, body: p.body }} curVersion={p.version} canRestore={canEdit} onClose={() => setModal(null)} onRestored={refreshWiki} />}
      {modal === 'import' && <ImportModal spaceId={space.id} parent={id} onClose={() => setModal(null)} />}
      {pdf && <WikiPdfModal id={pdf.id} name={pdf.name} onClose={() => setPdf(null)} />}
      {confirmNode}
    </div>
  );
}

export function prefetchPage(id: number) {
  import('../../lib/query').then((q) => q.prefetch(`wiki:page:${id}`, pageFetcher(id)));
}

export function PageToc({ id }: { id: number }) {
  const { data } = useQuery<PageData>(`wiki:page:${id}`, pageFetcher(id), { stale: 15000 });
  const headings = useMemo(() => (data ? wikiHeadings(data.page.body) : []), [data?.page.body]);
  if (headings.length < 2) return null;
  return <Toc headings={headings} />;
}

// ---------------------------------------------------------------- вложения

function Attachments({ files, body, onPdf }: { files: WFile[]; body: string; onPdf: (f: WFile) => void }) {
  if (!files.length) return null;
  const inBody = (f: WFile) => body.includes(`/files/${f.id}`);
  const list = files.filter((f) => !(f.mime.startsWith('image/') && inBody(f)));
  if (!list.length) return null;
  return (
    <section className="wkFiles">
      <h3 className="lnH3"><I.Paperclip size={16} /> Вложения · {list.length}</h3>
      <div className="wkFileGrid">
        {list.map((f) => {
          const isPdf = f.mime === 'application/pdf';
          const isImg = f.mime.startsWith('image/');
          return (
            <div key={f.id} className="wkFile">
              {isImg ? <a href={`/files/${f.id}`} target="_blank" rel="noopener noreferrer" className="th"><img src={`/files/${f.id}?t=1`} alt={f.name} loading="lazy" /></a> : <FileIcon name={f.name} mime={f.mime} />}
              <div className="sp" style={{ minWidth: 0 }}>
                <div className="bold clip small">{f.name}</div>
                <div className="tiny muted">{fmtSize(f.size)}</div>
              </div>
              {isPdf && <button type="button" className="btn sm" onClick={() => onPdf(f)}>Просмотр</button>}
              <a className="btn ghost icon sm" href={`/files/${f.id}?dl=1`} download={f.name} aria-label="Скачать"><I.Download size={16} /></a>
            </div>
          );
        })}
      </div>
    </section>
  );
}

// ---------------------------------------------------------------- комментарии

interface Cm { id: number; user_id: number | null; body: string; created_at: string; author: string | null; author_avatar: string | null }

function Comments({ pageId, count, canDeleteAll }: { pageId: number; count: number; canDeleteAll: boolean }) {
  const me = useStore((s) => s.me)!;
  const [open, setOpen] = useState(false);
  const { data, mutate, loading } = useQuery<Cm[]>(open ? `wiki:cm:${pageId}` : null, () => api.get(`${W}/pages/${pageId}/comments`), { stale: 10000 });
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const total = data ? data.length : count;
  useEffect(() => { setOpen(false); setText(''); }, [pageId]);
  async function send() {
    if (!text.trim()) return;
    setBusy(true);
    try {
      const c = await api.post<Cm>(`${W}/pages/${pageId}/comments`, { body: text });
      mutate((d) => [...(d || []), c]);
      setText('');
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  async function del(c: Cm) {
    try { await api.del(`${W}/comments/${c.id}`); mutate((d) => (d || []).filter((x) => x.id !== c.id)); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  return (
    <section className="card wkComments">
      <button type="button" className="wkCmHead" onClick={() => setOpen(!open)} aria-expanded={open}>
        <I.Comment size={18} /><b>Комментарии{total > 0 ? ` · ${total}` : ''}</b><span className="sp" /><I.ChevronDown size={16} style={{ transform: open ? 'rotate(180deg)' : undefined }} />
      </button>
      {open && (
        <div className="stack" style={{ padding: '0 18px 18px' }}>
          {loading && !data ? <Loading /> : (data || []).map((c) => (
            <div key={c.id} className="wkCm">
              <Avatar name={c.author || '?'} src={c.author_avatar || undefined} size={32} />
              <div className="sp" style={{ minWidth: 0 }}>
                <div className="small"><b>{c.author || 'Удалён'}</b> <span className="muted tiny">{dtRu(c.created_at)}</span></div>
                <div className="wkCmBody">{c.body}</div>
              </div>
              {(c.user_id === me.id || canDeleteAll) && <button type="button" className="btn ghost icon sm" onClick={() => del(c)} aria-label="Удалить комментарий"><I.Trash size={15} /></button>}
            </div>
          ))}
          {data && !data.length && <div className="small muted">Комментариев пока нет</div>}
          <div className="stackS">
            <textarea className="txt" rows={2} value={text} maxLength={4000} placeholder="Написать комментарий…" onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') send(); }} />
            <div><Btn kind="pri" size="sm" busy={busy} disabled={!text.trim()} onClick={send}>Отправить</Btn></div>
          </div>
        </div>
      )}
    </section>
  );
}
