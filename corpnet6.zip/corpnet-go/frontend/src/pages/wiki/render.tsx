// Рендер markdown страниц Wiki (без innerHTML): заголовки с якорями, оглавление, таблицы, блоки кода, вложенные списки,
// чек-листы, выноски (> [!info]), wiki-ссылки [[Страница]] / [[Страница|текст]] / [[Страница#Раздел]] и красные ссылки.
import React, { useEffect, useMemo, useState } from 'react';
import * as I from '../../lib/icons';
import { inline } from '../../lib/markdown';
import { cx } from '../../lib/util';
import { WikiPdf } from './pdf';
import { headSlug, pageSeg, WTree } from './lib';

export interface Heading { id: string; level: number; text: string }

const enc = (s: string) => encodeURIComponent(s).replace(/[()!*']/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());
const mdPlain = (s: string) => s.replace(/!\[[^\]]*\]\([^)]*\)(\{[^}]*\})?/g, '').replace(/\[([^\]]+)\]\([^)]*\)/g, '$1').replace(/[*_`]/g, '').trim();

const WIKI_LINK = /\[\[([^\[\]|#]+?)(?:#([^\[\]|]+))?(?:\|([^\[\]]+))?\]\]/g;

/** [[Название]] → обычная markdown-ссылка (существующая страница) или «красная» ссылка на создание. Код не затрагивается. */
export function expandWikiLinks(text: string, space: number, tree: WTree | null): string {
  if (!text.includes('[[')) return text;
  let fence = false;
  return text.split('\n').map((ln) => {
    if (/^\s*```/.test(ln)) { fence = !fence; return ln; }
    if (fence || !ln.includes('[[')) return ln;
    return ln.split(/(`[^`]*`)/).map((seg, i) => (i % 2 ? seg : seg.replace(WIKI_LINK, (_m, t: string, h: string | undefined, label: string | undefined) => {
      const title = t.trim();
      const shown = (label || (h ? `${title} › ${h.trim()}` : title)).replace(/[\[\]]/g, '').trim() || title;
      const node = tree?.byTitle.get(title.toLowerCase());
      if (node) return `[${shown}](/learning/wiki/${space}/${pageSeg(node.id, node.title)}${h ? '#' + enc(headSlug(h)) : ''})`;
      return `[${shown}](/learning/wiki/${space}/new?title=${enc(title)}&missing=1)`;
    }))).join('');
  }).join('\n');
}

interface Block { kind: string; [k: string]: any }

const isFence = (l: string) => /^\s{0,3}```/.test(l);
const isHeading = (l: string) => /^#{1,4}\s+\S/.test(l);
const isHr = (l: string) => /^\s*([-*_])(\s*\1){2,}\s*$/.test(l);
const isQuote = (l: string) => /^\s{0,3}>/.test(l);
const listRe = /^(\s*)([-*•]|\d+[.)])\s+(.*)$/;
const sepRe = /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/;
const isTableStart = (l: string, n?: string) => l.includes('|') && n !== undefined && sepRe.test(n) && n.includes('-') && (n.includes('|') || l.trim().startsWith('|'));

function splitRow(l: string): string[] {
  let s = l.trim();
  if (s.startsWith('|')) s = s.slice(1);
  if (s.endsWith('|') && !s.endsWith('\\|')) s = s.slice(0, -1);
  return s.split(/(?<!\\)\|/).map((c) => c.trim().replace(/\\\|/g, '|'));
}

function parse(text: string): { blocks: Block[]; headings: Heading[] } {
  const lines = text.replace(/\r/g, '').split('\n');
  const blocks: Block[] = [];
  const headings: Heading[] = [];
  const used = new Map<string, number>();
  const uniq = (base: string) => { const n = used.get(base) || 0; used.set(base, n + 1); return n ? `${base}-${n}` : base; };
  let i = 0;
  while (i < lines.length) {
    const ln = lines[i];
    if (!ln.trim()) { i++; continue; }
    if (isFence(ln)) {
      const lang = ln.replace(/^\s*```/, '').trim();
      const buf: string[] = [];
      i++;
      while (i < lines.length && !isFence(lines[i])) buf.push(lines[i++]);
      i++;
      blocks.push({ kind: 'code', lang, text: buf.join('\n') });
      continue;
    }
    if (isHeading(ln)) {
      const m = /^(#{1,4})\s+(.*?)\s*#*\s*$/.exec(ln)!;
      const level = m[1].length + 1; // # → h2 (как в остальном портале)
      const plain = mdPlain(m[2]);
      const id = uniq(headSlug(plain));
      headings.push({ id, level, text: plain });
      blocks.push({ kind: 'h', level, id, text: m[2] });
      i++;
      continue;
    }
    if (isHr(ln)) { blocks.push({ kind: 'hr' }); i++; continue; }
    if (isTableStart(ln, lines[i + 1])) {
      const head = splitRow(ln);
      const al = splitRow(lines[i + 1]).map((c) => (c.startsWith(':') && c.endsWith(':') ? 'center' : c.endsWith(':') ? 'right' : undefined));
      i += 2;
      const rows: string[][] = [];
      while (i < lines.length && lines[i].trim() && lines[i].includes('|')) rows.push(splitRow(lines[i++]));
      blocks.push({ kind: 'table', head, al, rows });
      continue;
    }
    if (isQuote(ln)) {
      const buf: string[] = [];
      while (i < lines.length && isQuote(lines[i])) buf.push(lines[i++].replace(/^\s{0,3}>\s?/, ''));
      const m = /^\[!(info|tip|warn|warning|danger|note)\]\s*(.*)$/i.exec(buf[0]);
      if (m) blocks.push({ kind: 'callout', type: m[1].toLowerCase().replace('warning', 'warn').replace('note', 'info'), lines: [m[2], ...buf.slice(1)].filter((x, k) => k > 0 || x) });
      else blocks.push({ kind: 'quote', lines: buf });
      continue;
    }
    if (listRe.test(ln)) {
      const items: { indent: number; ordered: boolean; text: string; task?: boolean; checked?: boolean }[] = [];
      while (i < lines.length) {
        const l = lines[i];
        const m = listRe.exec(l);
        if (m && !isHr(l)) {
          let t = m[3];
          let task: boolean | undefined, checked: boolean | undefined;
          const tm = /^\[( |x|X)\]\s+(.*)$/.exec(t);
          if (tm) { task = true; checked = tm[1] !== ' '; t = tm[2]; }
          items.push({ indent: m[1].replace(/\t/g, '    ').length, ordered: /\d/.test(m[2]), text: t, task, checked });
          i++;
        } else if (l.trim() && /^\s+\S/.test(l) && items.length && !isFence(l)) {
          items[items.length - 1].text += '\n' + l.trim();
          i++;
        } else break;
      }
      blocks.push({ kind: 'list', items });
      continue;
    }
    const buf: string[] = [];
    while (i < lines.length && lines[i].trim() && !isFence(lines[i]) && !isHeading(lines[i]) && !isQuote(lines[i]) && !isHr(lines[i])) {
      if (buf.length && listRe.test(lines[i])) break;
      if (buf.length && isTableStart(lines[i], lines[i + 1])) break;
      buf.push(lines[i++]);
    }
    if (!buf.length) { buf.push(lines[i++]); }
    blocks.push({ kind: 'p', lines: buf });
  }
  return { blocks, headings };
}

export function wikiHeadings(text: string): Heading[] {
  return parse(text).headings;
}

function Lines({ lines, k }: { lines: string[]; k: string }) {
  return <>{lines.map((l, j) => <React.Fragment key={j}>{j > 0 && <br />}{inline(l, k + j + ':')}</React.Fragment>)}</>;
}

function Code({ text, lang }: { text: string; lang: string }) {
  const [ok, setOk] = useState(false);
  return (
    <div className="wkCodeWrap">
      <button type="button" className="wkCopy" onClick={() => { navigator.clipboard?.writeText(text).then(() => { setOk(true); setTimeout(() => setOk(false), 1500); }).catch(() => {}); }} aria-label="Копировать код">
        {ok ? <I.Check size={14} /> : <I.Copy size={14} />}{ok ? 'Скопировано' : lang || 'Копировать'}
      </button>
      <pre className="wkCode"><code>{text}</code></pre>
    </div>
  );
}

const CALLOUT = { info: ['Информация', I.Info], tip: ['Совет', I.Lightbulb], warn: ['Внимание', I.Alert], danger: ['Важно', I.Ban] } as const;

type Item = { indent: number; ordered: boolean; text: string; task?: boolean; checked?: boolean };
function buildList(items: Item[], pos: { i: number }, indent: number, key: string): React.ReactNode {
  const ordered = items[pos.i].ordered;
  const lis: React.ReactNode[] = [];
  while (pos.i < items.length && items[pos.i].indent >= indent) {
    const it = items[pos.i];
    pos.i++;
    let sub: React.ReactNode = null;
    if (pos.i < items.length && items[pos.i].indent > it.indent) sub = buildList(items, pos, items[pos.i].indent, key + lis.length + '.');
    lis.push(
      <li key={lis.length} className={it.task ? 'wkTask' : undefined}>
        {it.task && <input type="checkbox" checked={!!it.checked} readOnly disabled aria-label={it.checked ? 'Выполнено' : 'Не выполнено'} />}
        <Lines lines={it.text.split('\n')} k={key + lis.length + ':'} />
        {sub}
      </li>
    );
  }
  return ordered ? <ol>{lis}</ol> : <ul>{lis}</ul>;
}

export function WikiMarkdown({ text, space, tree, pdfs }: { text: string; space: number; tree: WTree | null; pdfs?: Map<number, string> }) {
  const expanded = useMemo(() => expandWikiLinks(text || '', space, tree), [text, space, tree]);
  const { blocks } = useMemo(() => parse(expanded), [expanded]);
  return (
    <div className="prose wkBody">
      {blocks.map((b, i) => {
        switch (b.kind) {
          case 'h': {
            const Tag = ('h' + b.level) as 'h2' | 'h3' | 'h4' | 'h5';
            return <Tag key={i} id={b.id} className={'wkH wkH' + b.level}>{inline(b.text, i + ':')}<a href={'#' + b.id} className="wkAnchor" aria-label="Ссылка на раздел"
              onClick={(e) => { e.preventDefault(); history.replaceState(null, '', '#' + b.id); document.getElementById(b.id)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }}>#</a></Tag>;
          }
          case 'hr': return <hr key={i} className="wkHr" />;
          case 'code': return <Code key={i} text={b.text} lang={b.lang} />;
          case 'table':
            return (
              <div key={i} className="wkTblWrap">
                <table className="wkTbl">
                  <thead><tr>{b.head.map((c: string, j: number) => <th key={j} style={{ textAlign: b.al[j] }}>{inline(c, i + ':h' + j)}</th>)}</tr></thead>
                  <tbody>{b.rows.map((r: string[], ri: number) => <tr key={ri}>{b.head.map((_: string, j: number) => <td key={j} style={{ textAlign: b.al[j] }}>{inline(r[j] || '', i + ':' + ri + ':' + j)}</td>)}</tr>)}</tbody>
                </table>
              </div>
            );
          case 'quote': return <blockquote key={i}><Lines lines={b.lines} k={i + ':'} /></blockquote>;
          case 'callout': {
            const [label, Ic] = CALLOUT[b.type as keyof typeof CALLOUT] || CALLOUT.info;
            return <div key={i} className={cx('wkCallout', b.type)}><Ic size={18} /><div><b>{label}</b>{b.lines.length > 0 && <div><Lines lines={b.lines} k={i + ':'} /></div>}</div></div>;
          }
          case 'list': return <React.Fragment key={i}>{buildList(b.items, { i: 0 }, b.items[0].indent, i + '.')}</React.Fragment>;
          default: {
            // абзац из одной ссылки на PDF-вложение страницы — встроенный просмотр
            if (b.lines.length === 1 && pdfs) {
              const m = /^\[([^\]]+)\]\(\/files\/(\d+)\)$/.exec(b.lines[0].trim());
              if (m && pdfs.has(+m[2])) return <WikiPdf key={i} id={+m[2]} name={m[1]} collapsed />;
            }
            return <p key={i}><Lines lines={b.lines} k={i + ':'} /></p>;
          }
        }
      })}
    </div>
  );
}

/** Оглавление: список заголовков с подсветкой текущего раздела при прокрутке. */
export function Toc({ headings, onGo }: { headings: Heading[]; onGo?: () => void }) {
  const [cur, setCur] = useState('');
  useEffect(() => {
    if (!headings.length) return;
    const els = headings.map((h) => document.getElementById(h.id)).filter(Boolean) as HTMLElement[];
    const onScroll = () => {
      let active = els[0]?.id || '';
      for (const el of els) if (el.getBoundingClientRect().top < 120) active = el.id;
      setCur(active);
    };
    onScroll();
    addEventListener('scroll', onScroll, { passive: true });
    return () => removeEventListener('scroll', onScroll);
  }, [headings]);
  if (!headings.length) return null;
  const min = Math.min(...headings.map((h) => h.level));
  return (
    <nav className="wkToc" aria-label="Оглавление">
      <div className="wkTocH">Содержание</div>
      {headings.map((h, i) => (
        <a key={h.id + i} href={'#' + h.id} className={cx(cur === h.id && 'on')} style={{ paddingLeft: 8 + (h.level - min) * 12 }}
          onClick={(e) => { e.preventDefault(); history.replaceState(null, '', '#' + h.id); document.getElementById(h.id)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); onGo?.(); }}>{h.text}</a>
      ))}
    </nav>
  );
}

/** Фрагмент поиска с подсветкой: сервер помечает совпадения как «<<…>>»; разметка строится без innerHTML. */
export function WikiSnippet({ text }: { text?: string }) {
  if (!text) return null;
  const parts = text.split(/<<|>>/);
  return <>{parts.map((p, i) => (i % 2 ? <mark key={i}>{p}</mark> : <React.Fragment key={i}>{p}</React.Fragment>))}</>;
}
