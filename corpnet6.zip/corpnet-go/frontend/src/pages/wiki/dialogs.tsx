import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { invalidate, useQuery } from '../../lib/query';
import { navigate } from '../../lib/router';
import { toast, useStore } from '../../lib/store';
import { cx, plural, useDebounced } from '../../lib/util';
import { Badge, Btn, Field, Input, Loading, Modal, Select, Textarea, UserPicker } from '../../ui';
import { flattenDepts, useDepartments } from '../../ui/DeptSelect';
import { diffLines, diffStat, DiffOp, merge3, splitLines } from './diff';
import { WikiSnippet } from './render';
import { buildWikiTree, dtRu, pagePath, pageSeg, refreshWiki, ROLE_LABEL, spacePath, TEMPLATES, W, WNode, WSpace, WTree } from './lib';

// ---------------------------------------------------------------- права

interface AclEntry { subject_type: 'user' | 'department' | 'group' | 'role' | 'all'; subject_id: number; subject_key: string; level: number; name?: string }
const LEVELS = [{ v: 1, l: 'Чтение' }, { v: 3, l: 'Редактирование' }, { v: 4, l: 'Управление' }];
const ICON: Record<string, any> = { user: I.UserCheck, department: I.Building, group: I.Users, role: I.Shield, all: I.Globe };

export function WikiAcl({ target, title, onClose }: { target: { kind: 'space' | 'page'; id: number }; title?: string; onClose: () => void }) {
  const url = target.kind === 'space' ? `${W}/spaces/${target.id}/acl` : `${W}/pages/${target.id}/acl`;
  const { data, error } = useQuery<{ resource: any; entries: AclEntry[] }>(`wiki:acl:${target.kind}:${target.id}`, () => api.get(url), { stale: 0 });
  const [restricted, setRestricted] = useState(false);
  const [entries, setEntries] = useState<AclEntry[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [kind, setKind] = useState<AclEntry['subject_type']>('user');
  const depts = useDepartments();
  const dlist = useMemo(() => flattenDepts(depts.data || []), [depts.data]);
  const groups = useQuery<any[]>('wiki:groups', () => api.get('/api/groups'), { stale: 60000 });
  useEffect(() => {
    if (!data) return;
    setRestricted(target.kind === 'space' ? data.resource.visibility === 'restricted' : !!data.resource.restricted);
    setEntries(data.entries.map((e) => ({ ...e, level: e.level === 2 ? 1 : e.level })));
  }, [data]);
  const page = target.kind === 'page';
  async function save() {
    setBusy(true); setErr('');
    try {
      const list = entries.map(({ subject_type, subject_id, subject_key, level }) => ({ subject_type, subject_id, subject_key, level }));
      await api.put(url, page ? { restricted, entries: list } : { visibility: restricted ? 'restricted' : 'company', entries: list });
      refreshWiki(); toast({ title: 'Права сохранены', kind: 'success' }); onClose();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  const add = (e: AclEntry) => !entries.some((x) => x.subject_type === e.subject_type && x.subject_id === e.subject_id && x.subject_key === e.subject_key) && setEntries([...entries, e]);
  const shown = page && !restricted ? entries.filter((e) => e.level >= 3) : entries;
  const label = (e: AclEntry) => (e.subject_type === 'role' ? ROLE_LABEL[e.subject_key] || e.subject_key : e.subject_type === 'all' ? 'Все сотрудники' : e.name || '#' + e.subject_id);
  return (
    <Modal title={title || (page ? 'Права на страницу' : 'Права на базу знаний')} onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} onClick={save}>Сохранить</Btn></>}>
      {error ? <div className="err">{errMsg(error)}</div> : !data ? <Loading /> : (
        <div className="stack">
          {page ? (
            <Field label="Доступ к странице и её подстраницам">
              <Select value={restricted ? 'r' : 'i'} onChange={(e) => setRestricted(e.target.value === 'r')}>
                <option value="i">Как у родительской страницы (наследуется)</option>
                <option value="r">Ограничить: только указанные ниже</option>
              </Select>
            </Field>
          ) : (
            <Field label="Кто видит базу знаний">
              <Select value={restricted ? 'r' : 'i'} onChange={(e) => setRestricted(e.target.value === 'r')}>
                <option value="i">Все, кто видит её папку в «Материалах»</option>
                <option value="r">Только указанные ниже</option>
              </Select>
            </Field>
          )}
          <div className="hint">
            {page
              ? restricted
                ? 'Права на базу и вышестоящие страницы на эту ветку не распространяются (кроме управляющих базой и администраторов). Скрытая страница не видна ни в дереве, ни в поиске, ни в ссылках.'
                : 'Страница наследует доступ родителя. Здесь можно добавить дополнительных редакторов этой ветки.'
              : 'Читатель видит страницы, редактор — правит, управляющий — меняет права и удаляет. Права редактирования и управления действуют на всю базу; для подразделений — на все дочерние подразделения. Отдельные страницы и ветки можно ограничить в меню страницы.'}
          </div>
          <div className="stackS">
            <div className="lbl">{page && !restricted ? 'Дополнительные редакторы' : 'Доступ'}</div>
            {shown.map((e) => {
              const Ic = ICON[e.subject_type];
              return (
                <div className="row" key={e.subject_type + e.subject_id + e.subject_key}>
                  <Ic size={16} />
                  <div className="sp clip">{label(e)}{e.subject_type === 'department' && <span className="faint tiny"> · с подразделениями</span>}</div>
                  <Select style={{ width: 170 }} value={e.level} onChange={(ev) => setEntries(entries.map((x) => (x === e ? { ...x, level: +ev.target.value } : x)))}>
                    {LEVELS.filter((l) => !(page && !restricted && l.v === 1)).map((l) => <option key={l.v} value={l.v}>{l.l}</option>)}
                  </Select>
                  <Btn kind="ghost" size="sm" icon onClick={() => setEntries(entries.filter((x) => x !== e))} aria-label="Убрать"><I.X size={15} /></Btn>
                </div>
              );
            })}
            {!shown.length && <div className="small muted">{restricted || !page ? 'Пока никого не добавлено' : 'Нет дополнительных редакторов'}</div>}
          </div>
          {(restricted || !page || true) && (
            <div className="stackS">
              <div className="chips">
                {([['user', 'Сотрудник'], ['department', 'Подразделение'], ['group', 'Группа'], ['role', 'Роль'], ['all', 'Все']] as const).map(([k, l]) => (
                  <button type="button" key={k} className={cx('chip', kind === k && 'on')} onClick={() => setKind(k)}>{l}</button>
                ))}
              </div>
              {kind === 'user' && <UserPicker value={[]} onChange={(v) => v[0] && add({ subject_type: 'user', subject_id: v[0].id, subject_key: '', level: page && !restricted ? 3 : 1, name: v[0].name })} />}
              {kind === 'department' && (
                <Select value="" onChange={(e) => { const d = dlist.find((x) => x.id === +e.target.value); d && add({ subject_type: 'department', subject_id: d.id, subject_key: '', level: page && !restricted ? 3 : 1, name: d.name }); }}>
                  <option value="">Выберите подразделение…</option>
                  {dlist.map((d) => <option key={d.id} value={d.id}>{'  '.repeat(d.depth) + d.name}</option>)}
                </Select>
              )}
              {kind === 'group' && (
                <Select value="" onChange={(e) => { const g = (groups.data || []).find((x: any) => x.id === +e.target.value); g && add({ subject_type: 'group', subject_id: g.id, subject_key: '', level: page && !restricted ? 3 : 1, name: g.name }); }}>
                  <option value="">Выберите группу…</option>
                  {(groups.data || []).map((g: any) => <option key={g.id} value={g.id}>{g.name}</option>)}
                </Select>
              )}
              {kind === 'role' && (
                <Select value="" onChange={(e) => e.target.value && add({ subject_type: 'role', subject_id: 0, subject_key: e.target.value, level: page && !restricted ? 3 : 1 })}>
                  <option value="">Выберите роль…</option>
                  {Object.entries(ROLE_LABEL).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
                </Select>
              )}
              {kind === 'all' && <Btn size="sm" onClick={() => add({ subject_type: 'all', subject_id: 0, subject_key: '', level: page && !restricted ? 3 : 1 })}><I.Plus size={15} /> Добавить «Все сотрудники»</Btn>}
            </div>
          )}
          {err && <div className="err">{err}</div>}
        </div>
      )}
    </Modal>
  );
}

// ---------------------------------------------------------------- выбор места в дереве (перемещение / копирование)

export function TreePick({ tree, value, onChange, disabled, allowRoot = true, minLevel = 3 }: { tree: WTree; value: number | null | undefined; onChange: (id: number | null) => void; disabled?: Set<number>; allowRoot?: boolean; minLevel?: number }) {
  const [open, setOpen] = useState<Set<number>>(new Set());
  const row = (n: WNode, depth: number): React.ReactNode => {
    const off = n.level < minLevel || disabled?.has(n.id);
    const isOpen = open.has(n.id);
    return (
      <React.Fragment key={n.id}>
        <div className={cx('wkPick', value === n.id && 'on', off && 'off')} style={{ paddingLeft: 6 + depth * 16 }}>
          <button type="button" className={cx('wkTog', !n.kids.length && 'none', isOpen && 'open')} onClick={() => setOpen((s) => { const x = new Set(s); x.has(n.id) ? x.delete(n.id) : x.add(n.id); return x; })} aria-label="Развернуть"><I.ChevronRight size={14} /></button>
          <label className="sp clip"><input type="radio" checked={value === n.id} disabled={off} onChange={() => onChange(n.id)} /> <I.FileText size={15} /> {n.title}</label>
        </div>
        {isOpen && n.kids.slice(0, 300).map((k) => row(k, depth + 1))}
      </React.Fragment>
    );
  };
  return (
    <div className="wkPicker">
      {allowRoot && <label className={cx('wkPick', value === null && 'on')} style={{ paddingLeft: 12 }}><input type="radio" checked={value === null} onChange={() => onChange(null)} /> <I.Layers size={15} /> В корень базы</label>}
      {tree.roots.slice(0, 500).map((n) => row(n, 0))}
      {!tree.roots.length && <div className="small muted" style={{ padding: 10 }}>В базе пока нет страниц</div>}
    </div>
  );
}

export function MoveModal({ page, tree, spaceId, onClose }: { page: WNode; tree: WTree; spaceId: number; onClose: () => void }) {
  const [to, setTo] = useState<number | null | undefined>(page.pid || null);
  const [busy, setBusy] = useState(false);
  const bad = useMemo(() => tree.subtree(page.id), [page.id, tree]);
  async function go() {
    setBusy(true);
    try {
      await api.post(`${W}/pages/${page.id}/move`, { parent_id: to, before_id: 0 });
      refreshWiki(); toast({ title: 'Страница перемещена', kind: 'success' }); onClose();
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); setBusy(false); }
  }
  return (
    <Modal title={`Переместить «${page.title}»`} size="sm" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={to === undefined} onClick={go}>Переместить сюда</Btn></>}>
      <TreePick tree={tree} value={to} onChange={setTo} disabled={bad} />
      <div className="hint" style={{ marginTop: 10 }}>Страница переедет вместе со всеми подстраницами. Доступ определяется новым расположением и собственными ограничениями страниц.</div>
    </Modal>
  );
}

export function CopyModal({ page, spaceId, onClose }: { page: WNode; spaceId: number; onClose: () => void }) {
  const spaces = useQuery<any[]>('wiki:spaces', () => api.get(`${W}/spaces`), { stale: 30000 });
  const [sp, setSp] = useState(spaceId);
  const tq = useQuery<{ pages: any }>(sp ? `wiki:tree:${sp}` : null, () => api.get(`${W}/spaces/${sp}/tree`), { stale: 20000 });
  const tree = useMemo(() => buildWikiTree(tq.data?.pages), [tq.data]);
  const [to, setTo] = useState<number | null | undefined>(undefined);
  const [kids, setKids] = useState(true);
  const [busy, setBusy] = useState(false);
  const editable = (spaces.data || []).filter((s) => s.level >= 3);
  async function go() {
    setBusy(true);
    try {
      const r = await api.post(`${W}/pages/${page.id}/copy`, { space_id: sp, parent_id: to, with_children: kids });
      refreshWiki(); toast({ title: `Скопировано страниц: ${r.count}`, kind: 'success' });
      onClose();
      navigate(`/learning/wiki/${r.space_id}/${r.id}`);
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); setBusy(false); }
  }
  return (
    <Modal title={`Копировать «${page.title}»`} size="sm" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={to === undefined} onClick={go}>Копировать сюда</Btn></>}>
      <div className="stack">
        <Field label="База знаний">
          <Select value={sp} onChange={(e) => { setSp(+e.target.value); setTo(undefined); }}>
            {editable.map((s) => <option key={s.id} value={s.id}>{s.title}</option>)}
          </Select>
        </Field>
        {tq.loading && !tq.data ? <Loading /> : <TreePick tree={tree} value={to} onChange={setTo} />}
        <label className="chk"><input type="checkbox" checked={kids} onChange={(e) => setKids(e.target.checked)} /> Вместе с подстраницами (скрытые от вас страницы не копируются)</label>
      </div>
    </Modal>
  );
}

// ---------------------------------------------------------------- новая страница

export function NewPageModal({ space, parent, tree, title: t0, onClose }: { space: WSpace; parent: number | null; tree: WTree; title?: string; onClose: () => void }) {
  const cur = parent ? tree.byId.get(parent) : undefined;
  const [title, setTitle] = useState(t0 || '');
  const [tpl, setTpl] = useState('blank');
  const [where, setWhere] = useState<'child' | 'sibling' | 'root'>(cur ? 'child' : 'root');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  async function go() {
    if (!title.trim()) return setErr('Введите название страницы');
    const t = TEMPLATES.find((x) => x.key === tpl)!;
    const pid = where === 'child' ? cur?.id ?? null : where === 'sibling' ? (cur?.pid || null) : null;
    setBusy(true); setErr('');
    try {
      const r = await api.post(`${W}/pages`, { space_id: space.id, parent_id: pid, title, body: t.body, icon: '' });
      refreshWiki();
      navigate(`${pagePath(space.id, r.id, title.trim())}?edit=1`);
      onClose();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title="Новая страница" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} onClick={go}>Создать</Btn></>}>
      <form className="stack" onSubmit={(e) => { e.preventDefault(); go(); }}>
        <Field label="Название"><Input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} autoFocus placeholder="Например: Как оформить командировку" /></Field>
        {cur && (
          <Field label="Расположение">
            <Select value={where} onChange={(e) => setWhere(e.target.value as any)}>
              <option value="child">Внутри «{cur.title}»</option>
              {cur.pid > 0 && <option value="sibling">Рядом с «{cur.title}»</option>}
              <option value="root">В корне базы</option>
            </Select>
          </Field>
        )}
        <div>
          <div className="lbl" style={{ marginBottom: 6 }}>Шаблон</div>
          <div className="wkTpls">
            {TEMPLATES.map((t) => (
              <button type="button" key={t.key} className={cx('wkTpl', tpl === t.key && 'on')} onClick={() => setTpl(t.key)}>
                <span className="ic">{t.icon}</span><b>{t.name}</b><span className="tiny muted">{t.desc}</span>
              </button>
            ))}
          </div>
        </div>
        {err && <div className="err">{err}</div>}
        <button type="submit" hidden />
      </form>
    </Modal>
  );
}

// ---------------------------------------------------------------- база знаний: создание / настройки

const COVERS = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'c8'];
const ICONS = ['📘', '📚', '🧭', '🛠️', '💼', '🎓', '🔒', '🚀', '🏢', '🧩', '📋', '💡'];

export function SpaceModal({ edit, folder, onClose }: { edit?: WSpace; folder?: number | null; onClose: () => void }) {
  const [title, setTitle] = useState(edit?.title || '');
  const [desc, setDesc] = useState(edit?.description || '');
  const [icon, setIcon] = useState(edit?.icon || '📘');
  const [cover, setCover] = useState(edit?.cover || 'c1');
  const [vis, setVis] = useState<'company' | 'restricted'>('company');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  async function save() {
    if (!title.trim()) return setErr('Введите название');
    setBusy(true); setErr('');
    try {
      const body = { folder_id: folder || null, title, description: desc, icon, cover, visibility: vis };
      const r = edit ? await api.put(`${W}/spaces/${edit.id}`, body) : await api.post(`${W}/spaces`, body);
      refreshWiki();
      onClose();
      if (!edit) navigate(spacePath(r.id));
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title={edit ? 'Настройки базы знаний' : 'Новая база знаний'} onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} onClick={save}>{edit ? 'Сохранить' : 'Создать'}</Btn></>}>
      <form className="stack" onSubmit={(e) => { e.preventDefault(); save(); }}>
        <Field label="Название"><Input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} autoFocus /></Field>
        <Field label="Описание"><Textarea value={desc} onChange={(e) => setDesc(e.target.value)} rows={3} style={{ minHeight: 70 }} maxLength={2000} /></Field>
        <Field label="Значок">
          <div className="wkEmojis">
            {ICONS.map((x) => <button type="button" key={x} className={cx(icon === x && 'on')} onClick={() => setIcon(x)}>{x}</button>)}
            <Input value={icon} onChange={(e) => setIcon(Array.from(e.target.value).slice(0, 2).join(''))} style={{ width: 70 }} aria-label="Свой значок" />
          </div>
        </Field>
        <Field label="Обложка">
          <div className="wkCovers">
            {COVERS.map((c) => <button type="button" key={c} className={cx('wkCoverSw', c, cover === c && 'on')} onClick={() => setCover(c)} aria-label={'Цвет ' + c} />)}
          </div>
        </Field>
        {!edit && (
          <Field label="Кто видит" hint="Детальные права и ограничения отдельных страниц можно настроить позже.">
            <Select value={vis} onChange={(e) => setVis(e.target.value as any)}>
              <option value="company">Все, кто видит папку в «Материалах»</option>
              <option value="restricted">Только я (дальше добавлю участников)</option>
            </Select>
          </Field>
        )}
        {err && <div className="err">{err}</div>}
        <button type="submit" hidden />
      </form>
    </Modal>
  );
}

// ---------------------------------------------------------------- импорт

export function ImportModal({ spaceId, parent, onClose }: { spaceId: number; parent: number | null; onClose: () => void }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [res, setRes] = useState<{ pages: number; files: number } | null>(null);
  const inp = useRef<HTMLInputElement>(null);
  async function pick(f?: File) {
    if (!f) return;
    setBusy(true); setErr('');
    try { setRes(await api.upload(`${W}/spaces/${spaceId}/import${parent ? '?parent=' + parent : ''}`, f)); refreshWiki(); }
    catch (e) { setErr(errMsg(e)); }
    setBusy(false);
  }
  return (
    <Modal title="Импорт из markdown" size="sm" onClose={onClose} footer={<Btn onClick={onClose}>{res ? 'Готово' : 'Закрыть'}</Btn>}>
      <div className="stack">
        <p className="muted small">Загрузите zip-архив с .md-файлами или один .md-файл. Каталоги станут страницами с вложенностью; рядом лежащие картинки и файлы прикрепятся к страницам. {parent ? 'Страницы добавятся внутрь текущей страницы.' : 'Страницы добавятся в корень базы.'}</p>
        <Btn kind="pri" busy={busy} onClick={() => inp.current?.click()}><I.Upload size={16} /> Выбрать zip или .md</Btn>
        <input ref={inp} type="file" accept=".zip,.md,.markdown,application/zip" hidden onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ''; }} />
        {res && <div className="ok">Импортировано страниц: {res.pages}{res.files ? `, файлов: ${res.files}` : ''}</div>}
        {err && <div className="err">{err}</div>}
      </div>
    </Modal>
  );
}

// ---------------------------------------------------------------- diff и версии

export function DiffView({ a, b, context = 3 }: { a: string; b: string; context?: number }) {
  const ops = useMemo(() => diffLines(splitLines(a), splitLines(b)), [a, b]);
  const st = useMemo(() => diffStat(ops), [ops]);
  // сворачиваем длинные участки без изменений
  const rows: (DiffOp | { gap: number })[] = [];
  const keep = new Array(ops.length).fill(false);
  ops.forEach((o, i) => { if (o.t !== '=') for (let k = Math.max(0, i - context); k <= Math.min(ops.length - 1, i + context); k++) keep[k] = true; });
  let gap = 0;
  ops.forEach((o, i) => {
    if (keep[i] || !ops.some((x) => x.t !== '=')) { if (gap) { rows.push({ gap }); gap = 0; } rows.push(o); } else gap++;
  });
  if (gap) rows.push({ gap });
  if (!st.add && !st.del) return <div className="small muted" style={{ padding: 12 }}>Различий нет</div>;
  return (
    <div className="wkDiff">
      <div className="wkDiffStat"><span className="add">+{st.add}</span> <span className="del">−{st.del}</span></div>
      <div className="wkDiffBody">
        {rows.map((r, i) => 'gap' in r
          ? <div key={i} className="wkDiffGap">… {plural(r.gap, ['строка без изменений', 'строки без изменений', 'строк без изменений'])} …</div>
          : <div key={i} className={cx('wkDiffLn', r.t === '+' ? 'add' : r.t === '-' ? 'del' : '')}><span className="n">{r.a ?? ''}</span><span className="n">{r.b ?? ''}</span><span className="m">{r.t === '+' ? '+' : r.t === '-' ? '−' : ' '}</span><code>{r.s || ' '}</code></div>)}
      </div>
    </div>
  );
}

interface Ver { version: number; title: string; comment: string; created_at: string; author: string | null; size: number }

export function VersionsModal({ pageId, current, curVersion, canRestore, onClose, onRestored }: { pageId: number; current: { title: string; body: string }; curVersion: number; canRestore: boolean; onClose: () => void; onRestored: () => void }) {
  const list = useQuery<Ver[]>(`wiki:vers:${pageId}`, () => api.get(`${W}/pages/${pageId}/versions`), { stale: 0 });
  const [a, setA] = useState<number | null>(null); // старая
  const [b, setB] = useState<number | null>(null); // новая (null — текущая)
  const vs = list.data || [];
  useEffect(() => { if (vs.length > 1 && a === null) setA(vs[1].version); }, [vs.length]);
  const va = useQuery<any>(a ? `wiki:ver:${pageId}:${a}` : null, () => api.get(`${W}/pages/${pageId}/versions/${a}`), { stale: 600000 });
  const vb = useQuery<any>(b ? `wiki:ver:${pageId}:${b}` : null, () => api.get(`${W}/pages/${pageId}/versions/${b}`), { stale: 600000 });
  const [busy, setBusy] = useState(false);
  async function restore(v: number) {
    if (!confirm(`Восстановить версию ${v}? Текущий текст сохранится в истории.`)) return;
    setBusy(true);
    try { await api.post(`${W}/pages/${pageId}/restore`, { version: v }); refreshWiki(); toast({ title: 'Версия восстановлена', kind: 'success' }); onRestored(); onClose(); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); setBusy(false); }
  }
  const newer = b === null ? current.body : vb.data?.body;
  return (
    <Modal title="История изменений" size="lg" onClose={onClose}>
      {list.loading && !list.data ? <Loading /> : (
        <div className="wkVers">
          <div className="wkVerList">
            {vs.map((v) => (
              <div key={v.version} className={cx('wkVer', (a === v.version || b === v.version) && 'on')}>
                <div className="row"><b>Версия {v.version}</b>{v.version === curVersion && <Badge kind="ok">текущая</Badge>}</div>
                <div className="tiny muted">{dtRu(v.created_at)} · {v.author || '—'}</div>
                {v.comment && <div className="small">{v.comment}</div>}
                <div className="rowW" style={{ marginTop: 4 }}>
                  <button type="button" className={cx('chip sm', a === v.version && 'on')} onClick={() => setA(v.version)}>Сравнить: старая</button>
                  <button type="button" className={cx('chip sm', (b === v.version || (b === null && v.version === curVersion)) && 'on')} onClick={() => setB(v.version === curVersion ? null : v.version)}>новая</button>
                  {canRestore && v.version !== curVersion && <button type="button" className="chip sm" disabled={busy} onClick={() => restore(v.version)}>Восстановить</button>}
                </div>
              </div>
            ))}
          </div>
          <div className="wkVerDiff">
            {a === null ? <div className="muted" style={{ padding: 16 }}>Выберите версию для сравнения</div>
              : va.loading || (b !== null && vb.loading) || newer === undefined ? <Loading /> : <DiffView a={va.data?.body || ''} b={newer || ''} />}
          </div>
        </div>
      )}
    </Modal>
  );
}

// ---------------------------------------------------------------- конфликт редактирования

export function ConflictModal({ base, mine, theirs, onTake, onClose }: {
  base: string; mine: string;
  theirs: { version: number; title: string; body: string; updated_by_name?: string | null; updated_at?: string };
  onTake: (mode: 'merged' | 'mine' | 'theirs', text: string) => void; onClose: () => void;
}) {
  const merged = useMemo(() => merge3(base, mine, theirs.body), [base, mine, theirs.body]);
  const [tab, setTab] = useState<'theirs' | 'mine'>('theirs');
  return (
    <Modal title="Страницу уже изменили" size="lg" onClose={onClose} footer={
      <>
        <Btn onClick={onClose}>Вернуться к правке</Btn>
        <Btn onClick={() => onTake('theirs', theirs.body)}>Взять версию коллеги</Btn>
        <Btn onClick={() => onTake('mine', mine)}>Сохранить мою (перезаписать)</Btn>
        <Btn kind="pri" onClick={() => onTake('merged', merged.text)}>{merged.conflicts ? 'Объединить и разобрать конфликты' : 'Применить объединённый текст'}</Btn>
      </>
    }>
      <div className="stack">
        <div className="warnBox">
          Пока вы правили страницу, {theirs.updated_by_name || 'другой сотрудник'} сохранил(а) версию {theirs.version}{theirs.updated_at ? ` (${dtRu(theirs.updated_at)})` : ''}.
          {merged.conflicts === 0 ? ' Правки не пересекаются — их можно объединить автоматически.' : ` Автоматически объединить не удалось: пересекающихся фрагментов — ${merged.conflicts}. Они будут помечены в тексте маркерами <<<<<<< … ======= … >>>>>>>.`}
        </div>
        <div className="chips">
          <button type="button" className={cx('chip', tab === 'theirs' && 'on')} onClick={() => setTab('theirs')}>Что изменил коллега</button>
          <button type="button" className={cx('chip', tab === 'mine' && 'on')} onClick={() => setTab('mine')}>Что изменили вы</button>
        </div>
        <DiffView a={base} b={tab === 'theirs' ? theirs.body : mine} />
      </div>
    </Modal>
  );
}

// ---------------------------------------------------------------- быстрый переход (Ctrl+K)

export function Switcher({ space, tree, onClose }: { space: WSpace; tree: WTree; onClose: () => void }) {
  const [q, setQ] = useState('');
  const dq = useDebounced(q.trim(), 200);
  const [sel, setSel] = useState(0);
  const local = useMemo(() => {
    const t = q.trim().toLowerCase();
    const out: WNode[] = [];
    if (!t) { for (const n of tree.roots) out.push(n); return out.slice(0, 12); }
    for (const n of tree.byId.values()) {
      if (n.title.toLowerCase().includes(t)) { out.push(n); if (out.length >= 12) break; }
    }
    out.sort((x, y) => Number(y.title.toLowerCase().startsWith(t)) - Number(x.title.toLowerCase().startsWith(t)));
    return out;
  }, [q, tree]);
  const remote = useQuery<any[]>(dq.length >= 2 ? `wiki:sw:${dq}` : null, () => api.get(`${W}/search?q=${encodeURIComponent(dq)}&limit=12`), { stale: 30000 });
  const items: { key: string; to: string; title: string; sub: string; snippet?: string; restricted?: boolean }[] = [];
  const seen = new Set<string>();
  for (const n of local) {
    seen.add(`${space.id}:${n.id}`);
    items.push({ key: 'l' + n.id, to: pagePath(space.id, n.id, n.title), title: n.title, sub: tree.path(n.id).slice(0, -1).map((x) => x.title).join(' › ') || space.title, restricted: n.restricted });
  }
  for (const r of remote.data || []) {
    if (seen.has(`${r.space_id}:${r.id}`)) continue;
    items.push({ key: 'r' + r.id, to: pagePath(r.space_id, r.id, r.title), title: r.title, sub: r.space_id === space.id ? 'в тексте страницы' : r.space_title, snippet: r.snippet });
  }
  useEffect(() => setSel(0), [q]);
  const go = (i: number) => { const it = items[i]; if (it) { onClose(); navigate(it.to); } };
  return (
    <div className="modalBack" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="wkSw" role="dialog" aria-modal="true" aria-label="Быстрый переход">
        <div className="wkSwIn">
          <I.Search size={18} />
          <input autoFocus value={q} placeholder={`Перейти к странице в «${space.title}»…`} onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Escape') onClose();
              else if (e.key === 'ArrowDown') { e.preventDefault(); setSel((s) => Math.min(s + 1, items.length - 1)); }
              else if (e.key === 'ArrowUp') { e.preventDefault(); setSel((s) => Math.max(s - 1, 0)); }
              else if (e.key === 'Enter') { e.preventDefault(); go(sel); }
            }} />
          <kbd>Esc</kbd>
        </div>
        <div className="wkSwList">
          {items.map((it, i) => (
            <a key={it.key} href={it.to} className={cx('wkSwRow', sel === i && 'on')} onMouseEnter={() => setSel(i)} onClick={(e) => { e.preventDefault(); go(i); }}>
              <I.FileText size={16} />
              <span className="sp" style={{ minWidth: 0 }}>
                <span className="bold clip" style={{ display: 'block' }}>{it.title}{it.restricted && <I.Lock size={11} className="faint" style={{ marginLeft: 6 }} />}</span>
                <span className="tiny muted clip" style={{ display: 'block' }}>{it.snippet ? <WikiSnippet text={it.snippet} /> : it.sub}</span>
              </span>
            </a>
          ))}
          {!items.length && <div className="muted" style={{ padding: 16 }}>{q.trim() ? (remote.loading ? 'Ищем…' : 'Ничего не найдено') : 'В базе пока нет страниц'}</div>}
        </div>
      </div>
    </div>
  );
}
