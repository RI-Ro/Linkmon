// Базы знаний (Wiki): типы, дерево, ссылки, шаблоны страниц.
import { useMemo } from 'react';
import { api } from '../../lib/api';
import { invalidate, useQuery } from '../../lib/query';

export const W = '/api/wiki';

export interface WSpace {
  id: number; folder_id: number | null; title: string; slug?: string; description: string; icon: string; cover: string;
  visibility: 'company' | 'restricted'; owner_id?: number | null; level: number; folder_name?: string; updated_at?: string;
}
/** строка плоского дерева: [id, parent_id (0 — корень), title, flags]; flags: &7 — уровень (1/3/4), 8 — ограниченная, 16 — просрочена проверка */
export type TreeRow = [number, number, string, number];
export interface TreeData { space: WSpace; pages: TreeRow[] }

export interface WNode {
  id: number; pid: number; title: string; level: number; restricted: boolean; overdue: boolean; kids: WNode[]; depth: number;
}
export interface WTree {
  byId: Map<number, WNode>;
  roots: WNode[];
  byTitle: Map<string, WNode>;
  count: number;
  path(id: number): WNode[];
  subtree(id: number): Set<number>;
}

export function buildWikiTree(rows?: TreeRow[]): WTree {
  const byId = new Map<number, WNode>();
  const roots: WNode[] = [];
  const byTitle = new Map<string, WNode>();
  for (const r of rows || []) {
    byId.set(r[0], { id: r[0], pid: r[1], title: r[2], level: r[3] & 7, restricted: !!(r[3] & 8), overdue: !!(r[3] & 16), kids: [], depth: 0 });
  }
  for (const r of rows || []) {
    const n = byId.get(r[0])!;
    const p = n.pid ? byId.get(n.pid) : undefined;
    if (p) { p.kids.push(n); n.depth = p.depth + 1; } else roots.push(n);
    const k = n.title.trim().toLowerCase();
    if (!byTitle.has(k)) byTitle.set(k, n);
  }
  return {
    byId, roots, byTitle, count: byId.size,
    path(id) {
      const out: WNode[] = [];
      let cur = byId.get(id);
      while (cur && out.length < 60) { out.unshift(cur); cur = cur.pid ? byId.get(cur.pid) : undefined; }
      return out;
    },
    subtree(id) {
      const out = new Set<number>();
      const walk = (n: WNode) => { out.add(n.id); n.kids.forEach(walk); };
      const n = byId.get(id);
      if (n) walk(n);
      return out;
    },
  };
}

export function useWikiTree(spaceId: number) {
  const q = useQuery<TreeData>(spaceId ? `wiki:tree:${spaceId}` : null, () => api.get(`${W}/spaces/${spaceId}/tree`), { stale: 20000, keepPrevious: false });
  const tree = useMemo(() => buildWikiTree(q.data?.pages), [q.data]);
  return { ...q, tree, space: q.data?.space };
}

export const refreshWiki = () => invalidate('wiki:');

// ---------------------------------------------------------------- ссылки

const TR: Record<string, string> = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'c', ч: 'ch', ш: 'sh', щ: 'sch', ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya' };

/** Тот же slug, что строит сервер (красивая ссылка; идентификатором служит число перед ним). */
export function slugify(title: string): string {
  let out = '', dash = true;
  for (const ch of title.toLowerCase()) {
    if (/[a-z0-9]/.test(ch)) { out += ch; dash = false; }
    else if (TR[ch] !== undefined && TR[ch] !== '') { out += TR[ch]; dash = false; }
    else if (!dash) { out += '-'; dash = true; }
    if (out.length >= 60) break;
  }
  return out.replace(/^-+|-+$/g, '');
}

export const pageSeg = (id: number, title: string) => { const s = slugify(title); return s ? `${id}-${s}` : String(id); };
export const spacePath = (space: number, title?: string) => `/learning/wiki/${title ? pageSeg(space, title) : space}`;
export const pagePath = (space: number, id: number, title: string) => `/learning/wiki/${space}/${pageSeg(id, title)}`;
export const idOf = (seg?: string) => { const m = /^(\d{1,15})(?:-.*)?$/.exec(seg || ''); return m ? +m[1] : 0; };

/** id заголовка для якоря: буквы любого алфавита и цифры, пробелы → «-» */
export function headSlug(text: string): string {
  return text.toLowerCase().replace(/[`*_~[\]()!]/g, '').replace(/[^\p{L}\p{N}\s-]/gu, '').trim().replace(/\s+/g, '-') || 'section';
}

// ---------------------------------------------------------------- шаблоны страниц

export interface Template { key: string; name: string; icon: string; desc: string; body: string }
export const TEMPLATES: Template[] = [
  { key: 'blank', name: 'Пустая страница', icon: '📄', desc: 'Начать с чистого листа', body: '' },
  {
    key: 'howto', name: 'Инструкция', icon: '🧭', desc: 'Пошаговая инструкция с условиями и контактами',
    body: `## Для чего эта инструкция

Коротко: какую задачу решает и для кого написана.

## Что понадобится

- доступ или документ
- согласование руководителя

## Шаги

1. Первое действие.
2. Второе действие.
3. Проверьте результат.

> [!tip] Подсказка: напишите, на что чаще всего обращают внимание ошибки.

## Если что-то пошло не так

Куда обратиться: **support@corpnet.local**.
`,
  },
  {
    key: 'policy', name: 'Регламент', icon: '📋', desc: 'Цель, область применения, роли, порядок, ответственность',
    body: `## 1. Цель

Для чего нужен регламент.

## 2. Область применения

На кого и на какие процессы распространяется.

## 3. Роли и ответственность

| Роль | Ответственность |
|---|---|
| Руководитель | Согласование |
| Сотрудник | Исполнение |

## 4. Порядок

1. Шаг первый.
2. Шаг второй.

## 5. Сроки

| Этап | Срок |
|---|---|
| Подача заявки | за 5 рабочих дней |

## 6. История изменений

- Версия 1.0 — первая редакция.
`,
  },
  {
    key: 'faq', name: 'Вопросы и ответы (FAQ)', icon: '❓', desc: 'Список частых вопросов с короткими ответами',
    body: `## Как это сделать?

Короткий ответ в одном-двух предложениях и ссылка на подробную страницу.

## Куда обращаться?

Контакты ответственных.

## Что делать, если не получилось?

Опишите проблему и напишите в поддержку.
`,
  },
  {
    key: 'meeting', name: 'Протокол встречи', icon: '🗒️', desc: 'Участники, повестка, решения и задачи',
    body: `**Дата:** ${new Date().toLocaleDateString('ru')}
**Участники:**
**Ведёт:**

## Повестка

1. Вопрос первый
2. Вопрос второй

## Обсуждение

Ключевые тезисы.

## Решения

- Решение 1

## Задачи

| Задача | Ответственный | Срок |
|---|---|---|
|  |  |  |
`,
  },
  {
    key: 'onboarding', name: 'Онбординг', icon: '🚀', desc: 'План адаптации на первые недели',
    body: `## Добро пожаловать!

Кратко о команде и о том, чем вы будете заниматься.

## Первый день

- [ ] Получить пропуск и оборудование
- [ ] Познакомиться с командой и наставником
- [ ] Войти на портал и заполнить профиль

## Первая неделя

- [ ] Пройти вводный инструктаж
- [ ] Изучить материалы раздела «Обучение»
- [ ] Первая встреча 1:1 с руководителем

## Первый месяц

| Срок | Цель |
|---|---|
| Неделя 2 | Первая самостоятельная задача |
| Неделя 4 | Итоговая встреча |

## Полезные ссылки

-
`,
  },
];

export const dtRu = (iso?: string | null) => (iso ? new Date(iso).toLocaleString('ru', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '');
export const dRu = (iso?: string | null) => (iso ? new Date(iso.length === 10 ? iso + 'T00:00:00' : iso).toLocaleDateString('ru', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '');

export const ROLE_LABEL: Record<string, string> = { user: 'Все сотрудники', editor: 'Редакторы', head: 'Руководители подразделений', admin: 'Администраторы' };

/** Ссылка на страницу из результата поиска ({space_id, id, title}). */
export const wikiLink = (r: { space_id: number; id: number; title: string }) => pagePath(r.space_id, r.id, r.title);
