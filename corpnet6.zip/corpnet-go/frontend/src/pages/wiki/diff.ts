// Построчный diff (LCS) и простое трёхстороннее слияние для конфликтов редактирования.

export type DiffOp = { t: '=' | '+' | '-'; s: string; a?: number; b?: number };

/** Пары совпавших индексов (i в a, j в b) наибольшей общей подпоследовательности. Общие начало и конец отбрасываются заранее. */
export function lcsPairs(a: string[], b: string[]): [number, number][] {
  let s = 0;
  while (s < a.length && s < b.length && a[s] === b[s]) s++;
  let ea = a.length, eb = b.length;
  while (ea > s && eb > s && a[ea - 1] === b[eb - 1]) { ea--; eb--; }
  const pairs: [number, number][] = [];
  for (let i = 0; i < s; i++) pairs.push([i, i]);
  const n = ea - s, m = eb - s;
  if (n > 0 && m > 0 && n * m <= 6_000_000) {
    const w = m + 1;
    const dp = new Uint32Array((n + 1) * w);
    for (let i = n - 1; i >= 0; i--) {
      for (let j = m - 1; j >= 0; j--) {
        dp[i * w + j] = a[s + i] === b[s + j] ? dp[(i + 1) * w + j + 1] + 1 : Math.max(dp[(i + 1) * w + j], dp[i * w + j + 1]);
      }
    }
    let i = 0, j = 0;
    while (i < n && j < m) {
      if (a[s + i] === b[s + j]) { pairs.push([s + i, s + j]); i++; j++; }
      else if (dp[(i + 1) * w + j] >= dp[i * w + j + 1]) i++;
      else j++;
    }
  }
  for (let k = 0; k < a.length - ea; k++) pairs.push([ea + k, eb + k]);
  return pairs;
}

export function diffLines(a: string[], b: string[]): DiffOp[] {
  const out: DiffOp[] = [];
  let i = 0, j = 0;
  for (const [pi, pj] of lcsPairs(a, b)) {
    while (i < pi) out.push({ t: '-', s: a[i], a: i++ + 1 });
    while (j < pj) out.push({ t: '+', s: b[j], b: j++ + 1 });
    out.push({ t: '=', s: a[pi], a: pi + 1, b: pj + 1 });
    i = pi + 1; j = pj + 1;
  }
  while (i < a.length) out.push({ t: '-', s: a[i], a: i++ + 1 });
  while (j < b.length) out.push({ t: '+', s: b[j], b: j++ + 1 });
  return out;
}

export const splitLines = (s: string) => (s === '' ? [] : s.replace(/\r/g, '').split('\n'));

export function diffStat(ops: DiffOp[]) {
  let add = 0, del = 0;
  for (const o of ops) { if (o.t === '+') add++; else if (o.t === '-') del++; }
  return { add, del };
}

const eq = (x: string[], y: string[]) => x.length === y.length && x.every((v, i) => v === y[i]);

/**
 * Трёхстороннее слияние (diff3): base — версия, с которой начал редактировать пользователь, mine — его текст,
 * theirs — текущий текст на сервере. Несовместимые правки одного места оформляются маркерами конфликта.
 */
export function merge3(base: string, mine: string, theirs: string): { text: string; conflicts: number } {
  const B = splitLines(base), A = splitLines(mine), T = splitLines(theirs);
  const pa = new Map(lcsPairs(B, A));
  const pb = new Map(lcsPairs(B, T));
  const sync: [number, number, number][] = [];
  for (let k = 0; k < B.length; k++) if (pa.has(k) && pb.has(k)) sync.push([k, pa.get(k)!, pb.get(k)!]);
  sync.push([B.length, A.length, T.length]);
  const out: string[] = [];
  let conflicts = 0, bi = 0, ai = 0, ti = 0;
  for (const [k, ak, tk] of sync) {
    const bc = B.slice(bi, k), ac = A.slice(ai, ak), tc = T.slice(ti, tk);
    if (eq(ac, bc)) out.push(...tc);
    else if (eq(tc, bc) || eq(ac, tc)) out.push(...ac);
    else {
      conflicts++;
      out.push('<<<<<<< ваша версия', ...ac, '=======', ...tc, '>>>>>>> версия коллеги');
    }
    if (k < B.length) out.push(B[k]);
    bi = k + 1; ai = ak + 1; ti = tk + 1;
  }
  return { text: out.join('\n'), conflicts };
}
