import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Reactions, type Rx } from '../ui/Reactions';
import { BookmarkButton } from '../ui/Bookmark';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { Link, navigate, useSearchParams, useTitle } from '../lib/router';
import { toast } from '../lib/store';
import { usePersist } from '../lib/persist';
import { cx, copyText, fmtDate, useDebounced } from '../lib/util';
import { Markdown, stripMd } from '../lib/markdown';
import { Avatar, Btn, Empty, ErrorBox, Field, Input, Loading, Modal, Tabs, useConfirm } from '../ui';
import { MdEditor } from '../ui/MdEditor';
import { Comments } from '../ui/Comments';
import { useRealtime, useTopic } from '../lib/ws';
import './ideas.css';

interface Idea {
  id: number; title: string; summary: string; likes_count: number; comments_count: number; views_count: number; created_at: string;
  author_id: number; author: string; author_avatar: string; author_title: string; liked: boolean; cur?: string;
  body?: string; can_edit?: boolean;
}

async function toggleLike(id: number): Promise<{ liked: boolean; count: number }> {
  return api.post('/api/likes', { entity_type: 'idea', entity_id: id });
}

// ---------------------------------------------------------------- list
function IdeaCard({ i, onLike }: { i: Idea; onLike: (i: Idea) => void }) {
  return (
    <article className="card ideaCard">
      <Link to={`/ideas/${i.id}`} className="main">
        <h3 className="clamp2">{i.title}</h3>
        {i.summary && <p className="muted small clamp3">{stripMd(i.summary)}</p>}
        <div className="by">
          <Avatar name={i.author} src={i.author_avatar} size={26} userId={i.author_id} />
          <div style={{ minWidth: 0 }}><div className="small bold clip">{i.author}</div><div className="tiny faint clip">{fmtDate(i.created_at)}</div></div>
        </div>
      </Link>
      <div className="ft">
        <button type="button" className={cx('miniLike', i.liked && 'on')} onClick={() => onLike(i)} aria-pressed={i.liked} title="Поддержать идею"><I.Heart size={15} /> {i.likes_count}</button>
        <span className="stat" title="Комментарии"><I.Comment size={15} /> {i.comments_count}</span>
        <span className="sp" />
        <span className="stat" title="Просмотры"><I.Eye size={15} /> {i.views_count}</span>
      </div>
    </article>
  );
}

function NewIdeaModal({ onClose }: { onClose: () => void }) {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  async function submit() {
    if (!title.trim()) return setErr('Опишите идею в заголовке');
    setBusy(true); setErr('');
    try {
      const r = await api.post<{ id: number }>('/api/ideas', { title: title.trim(), body });
      invalidate('idea');
      toast({ title: 'Идея опубликована', kind: 'success' }, 2500);
      onClose();
      navigate('/ideas/' + r.id);
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title="Предложить идею" size="lg" onClose={onClose}
      footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} onClick={submit}><I.Zap size={16} /> Опубликовать</Btn></>}>
      <Field label="Суть идеи" hint="Коротко, до 200 символов — это заголовок карточки"><Input value={title} maxLength={200} onChange={(e) => setTitle(e.target.value)} placeholder="Что предлагаете улучшить?" style={{ fontWeight: 600 }} /></Field>
      <div className="field"><label>Подробности</label>
        <MdEditor value={body} onChange={setBody} rows={10} placeholder={'Какую проблему решает идея, как это может работать, что нужно для запуска…\n\nМожно прикладывать картинки.'} />
      </div>
      {err && <div className="err">{err}</div>}
    </Modal>
  );
}

export function IdeasPage() {
  useTitle('Есть идея');
  const [sp, setSp] = useSearchParams();
  const sort = sp.get('sort') === 'popular' ? 'popular' : 'new';
  const urlQ = sp.get('q') || '';
  const [q, setQ] = useState(urlQ);
  // последняя выбранная вкладка запоминается и применяется, если открыть раздел без параметров
  const [saved, setSaved] = usePersist<{ sort?: string }>('ideas.filters', {});
  useEffect(() => { if (!location.search && saved.sort === 'popular') setSp({ sort: 'popular' }, true); }, []); // eslint-disable-line
  const pref = (patch: { sort?: string | null }) => {
    setSaved({ sort: patch.sort || '' });
    setSp(patch);
  };
  const dq = useDebounced(q.trim(), 350);
  useEffect(() => { if (dq !== urlQ) setSp({ q: dq || null }, true); }, [dq]);
  const [items, setItems] = useState<Idea[] | null>(null);
  const [more, setMore] = useState(false);
  const [err, setErr] = useState<any>(null);
  const [busyMore, setBusyMore] = useState(false);
  const [creating, setCreating] = useState(false);
  const seq = useRef(0);
  const base = useMemo(() => {
    const p = new URLSearchParams({ per: '18', sort });
    if (urlQ) p.set('q', urlQ);
    return p.toString();
  }, [sort, urlQ]);
  const loadFirst = useCallback(async (blank: boolean) => {
    const my = ++seq.current;
    if (blank) setItems(null);
    setErr(null);
    try {
      const r = await api.get(`/api/ideas?${base}`);
      if (my !== seq.current) return;
      setItems(r.items); setMore(!!r.has_more);
    } catch (e) { if (my === seq.current) setErr(e); }
  }, [base]);
  useEffect(() => { loadFirst(true); }, [loadFirst]);
  useRealtime('refresh', (d) => { if (d?.what === 'ideas') loadFirst(false); }, [loadFirst]);
  useRealtime('reconnected', () => loadFirst(false), [loadFirst]);
  async function loadMore() {
    const last = items?.[items.length - 1];
    if (!last?.cur) return;
    const my = seq.current;
    setBusyMore(true);
    try {
      const r = await api.get(`/api/ideas?${base}&cursor=${encodeURIComponent(last.cur)}`);
      if (my !== seq.current) return;
      setItems((cur) => { const seen = new Set((cur || []).map((x) => x.id)); return [...(cur || []), ...r.items.filter((x: Idea) => !seen.has(x.id))]; });
      setMore(!!r.has_more);
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusyMore(false);
  }
  async function like(i: Idea) {
    try {
      const r = await toggleLike(i.id);
      setItems((cur) => (cur || []).map((x) => (x.id === i.id ? { ...x, liked: r.liked, likes_count: r.count } : x)));
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  return (
    <div className="stack">
      <div className="ideaHead">
        <div className="sp"><h1>Есть идея</h1><div className="muted small">Предлагайте, как сделать компанию и работу в ней лучше. Голосуйте и обсуждайте идеи коллег.</div></div>
        <Btn kind="pri" onClick={() => setCreating(true)}><I.Plus size={17} /> Предложить идею</Btn>
      </div>
      <Tabs value={sort as 'new' | 'popular'} onChange={(v) => pref({ sort: v === 'popular' ? 'popular' : null })} items={[{ id: 'new', label: 'Новые' }, { id: 'popular', label: 'Популярные' }]} />
      <div className="ideaFilters">
        <div className="fSearch"><Input placeholder="Поиск по идеям…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
      </div>
      {err && !items ? <ErrorBox error={err} retry={() => loadFirst(true)} /> : !items ? <Loading /> : items.length === 0 ? (
        <div className="card"><Empty icon={I.Zap} title={urlQ ? 'Идей не найдено' : 'Идей пока нет'}>{urlQ ? 'Измените запрос или фильтр' : 'Станьте первым — предложите свою идею'}</Empty></div>
      ) : (
        <>
          <div className="ideaGrid">{items.map((i) => <IdeaCard key={i.id} i={i} onLike={like} />)}</div>
          {more && <div className="ideaMore"><Btn busy={busyMore} onClick={loadMore}>Показать ещё</Btn></div>}
        </>
      )}
      {creating && <NewIdeaModal onClose={() => setCreating(false)} />}
    </div>
  );
}

// ---------------------------------------------------------------- one idea
export function IdeaView({ id }: { id: number }) {
  const { data: it, error, refetch, mutate } = useQuery<Idea>('idea:' + id, () => api.get('/api/ideas/' + id), { stale: 0 });
  useTitle(it?.title || 'Идея');
  useTopic(`idea:${id}`);
  const [cc, setCc] = useState<number | null>(null);
  const [edit, setEdit] = useState(false);
  const [f, setF] = useState({ title: '', body: '' });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [confirm, node] = useConfirm();
  useRealtime('comment', (c) => { if (c.entity_type === 'idea' && c.entity_id === id) mutate((o) => (o ? { ...o, comments_count: o.comments_count + 1 } : o as any)); }, [id]);
  if (error && !it) return <ErrorBox error={error} retry={refetch} />;
  if (!it) return <Loading />;
  async function save(patch: { title?: string; body?: string }) {
    setBusy(true); setErr('');
    try {
      await api.put('/api/ideas/' + id, { title: it!.title, body: it!.body || '', ...patch });
      invalidate('idea');
      await refetch();
      setEdit(false);
      toast({ title: 'Идея сохранена', kind: 'success' }, 2000);
    } catch (e) { const m = errMsg(e); setErr(m); if (!edit) toast({ title: m, kind: 'error' }); }
    setBusy(false);
  }
  async function del() {
    if (!(await confirm('Удалить идею?', { text: 'Вместе с комментариями. Действие необратимо.', ok: 'Удалить' }))) return;
    try { await api.del('/api/ideas/' + id); invalidate('idea'); navigate('/ideas'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  const count = cc ?? it.comments_count;
  return (
    <div className="stack" style={{ maxWidth: 900 }}>
      <div className="crumbs"><Link to="/ideas"><I.ArrowLeft size={15} style={{ verticalAlign: -2 }} /> Есть идея</Link></div>
      <article className="card ideaArt">
        <div className="in">
          {edit ? (
            <>
              <Field label="Суть идеи"><Input value={f.title} maxLength={200} onChange={(e) => setF({ ...f, title: e.target.value })} style={{ fontWeight: 600, fontSize: 18 }} /></Field>
              <div className="field"><label>Подробности</label><MdEditor value={f.body} onChange={(v) => setF({ ...f, body: v })} rows={12} /></div>
              {err && <div className="err">{err}</div>}
              <div className="row" style={{ justifyContent: 'flex-end', flexWrap: 'wrap' }}>
                <Btn onClick={() => { setEdit(false); setErr(''); }}>Отмена</Btn>
                <Btn kind="pri" busy={busy} disabled={!f.title.trim()} onClick={() => save({ title: f.title.trim(), body: f.body })}><I.Check size={17} /> Сохранить</Btn>
              </div>
            </>
          ) : (
            <>
              <h1>{it.title}</h1>
              <div className="byline">
                <Link to={`/people/${it.author_id}`}><Avatar name={it.author} src={it.author_avatar} size={44} userId={it.author_id} /></Link>
                <div className="sp" style={{ minWidth: 160 }}><Link to={`/people/${it.author_id}`} className="bold">{it.author}</Link><div className="small muted">{it.author_title} · {fmtDate(it.created_at)}</div></div>
                <span className="stat muted small"><I.Eye size={16} /> {it.views_count}</span>
              </div>
              <div className="divider" style={{ margin: 0 }} />
              {it.body ? <Markdown text={it.body} className="prose md" /> : <p className="muted">Автор не добавил подробностей.</p>}
              <div className="actions">
                <Reactions type="idea" id={id} initial={(it as any).reactions as Rx[] | undefined} pinLike />
                <a className="btn" href="#comments"><I.Comment size={18} /> {count}</a>
                <button className="btn" onClick={() => copyText(location.href).then(() => toast({ title: 'Ссылка скопирована', kind: 'success' }, 2000))}><I.Share size={18} /> Поделиться</button>
                <BookmarkButton type="idea" id={id} initial={(it as any).bookmarked} label />
                <div className="sp" />
                {it.can_edit && <><Btn onClick={() => { setF({ title: it.title, body: it.body || '' }); setEdit(true); }}><I.Edit size={17} /> Изменить</Btn><Btn kind="dng" onClick={del} aria-label="Удалить"><I.Trash size={17} /></Btn></>}
              </div>
            </>
          )}
        </div>
      </article>
      <section className="card pad stack" id="comments">
        <h3>Обсуждение <span className="muted">{count}</span></h3>
        <Comments type={'idea' as any} id={id} live onCount={setCc} />
      </section>
      {node}
    </div>
  );
}
