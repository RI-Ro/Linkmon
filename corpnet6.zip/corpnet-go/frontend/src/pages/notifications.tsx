import React, { useCallback, useEffect, useRef, useState } from 'react';
import * as I from '../lib/icons';
import * as X from '../lib/social-icons';
import { api, errMsg } from '../lib/api';
import { openLink, useTitle } from '../lib/router';
import { usePersist } from '../lib/persist';
import { setState, toast, useStore } from '../lib/store';
import { cx, fmtDate } from '../lib/util';
import { useRealtime } from '../lib/ws';
import { Btn, Empty, ErrorBox, Loading, Tabs } from '../ui';
import '../layout/shell.css';
import './notifications.css';

export interface Notif { id: number; kind: string; title: string; body: string; link: string; created_at: string; read: boolean }
interface NotifPage { items: Notif[]; has_more: boolean; next: number; unread: number }
export type NotifFilter = 'unread' | 'read';

export const NOTE_ICON: Record<string, any> = {
  comment: I.Comment, reply: I.Reply, group: I.Users, event: I.Calendar, access: I.Key, news: I.Newspaper, like: I.Heart, mention: X.AtSign,
  birthday: I.Cake, message: I.Message, idea: I.Lightbulb, vacation: I.Calendar,
};

/** Переход по ссылке уведомления; якорь #comment-<id> обрабатывает компонент Comments (router шлёт HASH_EVENT). */
export const goLink = openLink;

/** Постраничный (keyset) список уведомлений + действия «прочитать». Счётчик непрочитанных синхронизируется с сервером. */
export function useNotifications(filter: NotifFilter, per: number) {
  const [st, setSt] = useState<{ items: Notif[]; hasMore: boolean; next: number }>({ items: [], hasMore: false, next: 0 });
  const { items, hasMore, next } = st;
  const setItems = (f: (o: Notif[]) => Notif[]) => setSt((s) => ({ ...s, items: f(s.items) }));
  const setHasMore = (hasMore: boolean) => setSt((s) => ({ ...s, hasMore }));
  const [loading, setLoading] = useState(true);
  const [moreBusy, setMoreBusy] = useState(false);
  const [error, setError] = useState<any>(null);
  const seq = useRef(0);

  const url = useCallback((cursor: number) => `/api/notifications?filter=${filter}&per=${per}` + (cursor ? `&cursor=${cursor}` : ''), [filter, per]);

  const first = useCallback(async (silent = false) => {
    const my = ++seq.current;
    if (!silent) setLoading(true);
    try {
      const r = await api.get<NotifPage>(url(0));
      if (my !== seq.current) return;
      setState({ unreadNotifications: r.unread });
      setError(null);
      setSt((old) => {
        // свежая первая страница + уже подгруженный «хвост» старше неё (при тихом обновлении)
        const tail = silent && r.has_more ? old.items.filter((x) => x.id < r.next) : [];
        if (!tail.length) return { items: r.items, hasMore: r.has_more, next: r.next };
        return { items: [...r.items, ...tail], hasMore: old.hasMore, next: old.next };
      });
    } catch (e) {
      if (my === seq.current) setError(e);
    }
    if (my === seq.current) setLoading(false);
  }, [url]);

  useEffect(() => { setSt({ items: [], hasMore: false, next: 0 }); first(); }, [first]);
  useRealtime('refresh', (d) => { if (d?.what === 'notifications') first(true); }, [first]);

  async function more() {
    if (moreBusy || !hasMore) return;
    setMoreBusy(true);
    try {
      const r = await api.get<NotifPage>(url(next));
      setState({ unreadNotifications: r.unread });
      setSt((old) => ({ items: [...old.items, ...r.items.filter((x) => !old.items.some((o) => o.id === x.id))], hasMore: r.has_more, next: r.next }));
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setMoreBusy(false);
  }
  async function markRead(ids: number[]) {
    const set = new Set(ids);
    const was = items.filter((x) => set.has(x.id) && !x.read).length;
    if (!was) return;
    setItems((old) => (filter === 'unread' ? old.filter((x) => !set.has(x.id)) : old.map((x) => (set.has(x.id) ? { ...x, read: true } : x))));
    setState((s) => ({ unreadNotifications: Math.max(0, s.unreadNotifications - was) }));
    try {
      const r = await api.post<{ unread: number }>('/api/notifications/read', { ids });
      setState({ unreadNotifications: r.unread });
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); first(true); }
  }
  async function markAll() {
    try {
      const r = await api.post<{ unread: number }>('/api/notifications/read', { all: true });
      setState({ unreadNotifications: r.unread });
      setItems((old) => (filter === 'unread' ? [] : old.map((x) => ({ ...x, read: true }))));
      setHasMore(false);
      if (filter === 'unread') first(true);
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  /** Клик по уведомлению: пометить прочитанным и перейти на событие. */
  function open(n: Notif, after?: () => void) {
    if (!n.read) markRead([n.id]);
    after?.();
    if (n.link) goLink(n.link);
  }
  return { items, hasMore, loading, moreBusy, error, more, markRead, markAll, open, reload: () => first() };
}

export function NotifRow({ n, onOpen, onRead }: { n: Notif; onOpen: () => void; onRead: () => void }) {
  const Ic = NOTE_ICON[n.kind] || I.Bell;
  return (
    <div className={cx('nItem', !n.read && 'unread', n.link && 'clickable')} role={n.link ? 'link' : undefined} tabIndex={n.link ? 0 : undefined}
      onClick={onOpen} onKeyDown={(e) => { if (n.link && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); onOpen(); } }}>
      <div className="nIco"><Ic size={18} /></div>
      <div className="nTxt">
        <div className="small bold">{n.title}</div>
        {n.body && <div className="small muted clamp2">{n.body}</div>}
        <div className="tiny faint">{fmtDate(n.created_at)}</div>
      </div>
      {!n.read && (
        <button type="button" className="nRead" title="Отметить прочитанным" aria-label="Отметить прочитанным" onClick={(e) => { e.stopPropagation(); onRead(); }}>
          <I.Check size={16} />
        </button>
      )}
    </div>
  );
}

export function NotificationsPage() {
  useTitle('Уведомления');
  const unread = useStore((s) => s.unreadNotifications);
  const [tab, setTab] = usePersist<NotifFilter>('notif.tab', 'unread');
  const L = useNotifications(tab, 20);
  const sentinel = useRef<HTMLDivElement>(null);

  // бесконечная подгрузка: как только «Показать ещё» попадает в область видимости
  useEffect(() => {
    const el = sentinel.current;
    if (!el || !L.hasMore || typeof IntersectionObserver === 'undefined') return;
    const io = new IntersectionObserver((e) => e[0].isIntersecting && L.more(), { rootMargin: '300px' });
    io.observe(el);
    return () => io.disconnect();
  });

  return (
    <div className="stack" style={{ maxWidth: 820 }}>
      <div className="pageH">
        <h1>Уведомления</h1>
        <div className="sp" />
        {tab === 'unread' && unread > 0 && <Btn onClick={L.markAll}><I.CheckCheck size={17} /> Прочитать все</Btn>}
      </div>
      <Tabs<NotifFilter> value={tab} onChange={setTab} items={[{ id: 'unread', label: 'Непрочитанные', count: unread > 0 ? unread : undefined }, { id: 'read', label: 'Прочитанные' }]} />
      <div className="card notifList">
        {L.loading && !L.items.length ? <Loading /> : L.error && !L.items.length ? <ErrorBox error={L.error} retry={L.reload} /> : L.items.length === 0 ? (
          <Empty icon={I.Bell} title={tab === 'unread' ? 'Новых уведомлений нет' : 'Прочитанных уведомлений нет'}>
            {tab === 'unread' ? 'Все прочитано. Прочитанные можно посмотреть на соседней вкладке.' : ''}
          </Empty>
        ) : (
          L.items.map((n) => <NotifRow key={n.id} n={n} onOpen={() => L.open(n)} onRead={() => L.markRead([n.id])} />)
        )}
        {L.hasMore && (
          <div className="loadMore" ref={sentinel}>
            <Btn busy={L.moreBusy} onClick={L.more}>Показать ещё</Btn>
          </div>
        )}
      </div>
    </div>
  );
}
