import React, { useMemo, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { Link, useTitle } from '../lib/router';
import { toast } from '../lib/store';
import { usePersist } from '../lib/persist';
import { cx, plural, useDebounced } from '../lib/util';
import { Avatar, Badge, Btn, Check, Empty, ErrorBox, Field, Input, Loading, Modal, Textarea, UserPicker, useConfirm } from '../ui';
import type { UserLite } from '../ui';
import { DeptSelect } from '../ui/DeptSelect';
import './vacations.css';

interface Vac {
  id: number; user_id: number; name: string; job_title: string; avatar: string; department: string | null;
  starts_on: string; ends_on: string; deputy_id: number | null; deputy: string | null; deputy_title: string | null;
  city: string; note: string; active_now: boolean;
}

// ---------------------------------------------------------------- dates (всё в UTC, чтобы часовой пояс не сдвигал день)
const DAY = 86400000;
const parse = (s: string) => Date.parse(s.slice(0, 10) + 'T00:00:00Z');
const iso = (t: number) => new Date(t).toISOString().slice(0, 10);
const dmy = (s: string) => s.slice(8, 10) + '.' + s.slice(5, 7) + '.' + s.slice(0, 4);
const dm = (s: string) => s.slice(8, 10) + '.' + s.slice(5, 7);
const daysOf = (v: Vac) => Math.round((parse(v.ends_on) - parse(v.starts_on)) / DAY) + 1;
const todayIso = () => new Date().toISOString().slice(0, 10);
const monthRange = (ym: string) => {
  const [y, m] = ym.split('-').map(Number);
  return { from: iso(Date.UTC(y, m - 1, 1)), to: iso(Date.UTC(y, m, 0)) };
};
const MONTHS = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
const monthLabel = (ym: string) => { const [y, m] = ym.split('-').map(Number); return MONTHS[m - 1] + ' ' + y; };
const shiftMonth = (ym: string, d: number) => { const [y, m] = ym.split('-').map(Number); const t = new Date(Date.UTC(y, m - 1 + d, 1)); return t.toISOString().slice(0, 7); };

type Mode = 'month' | 'year' | 'range';

// ---------------------------------------------------------------- Gantt
function Gantt({ items, from, to }: { items: Vac[]; from: string; to: string }) {
  const t0 = parse(from), t1 = parse(to);
  const span = Math.round((t1 - t0) / DAY) + 1;
  const pct = (t: number) => ((t - t0) / DAY / span) * 100;
  const today = Date.parse(todayIso() + 'T00:00:00Z');
  // подписи шкалы: дни (если период ≤ 40 дней) или начала месяцев
  const ticks: { left: number; label: string; major?: boolean }[] = [];
  if (span <= 40) {
    for (let t = t0; t <= t1; t += DAY) { const d = new Date(t); ticks.push({ left: pct(t), label: String(d.getUTCDate()), major: d.getUTCDay() === 1 }); }
  } else {
    for (let t = t0; t <= t1; t += DAY) { const d = new Date(t); if (d.getUTCDate() === 1 || t === t0) ticks.push({ left: pct(t), label: MONTHS[d.getUTCMonth()].slice(0, 3), major: true }); }
  }
  const todayLeft = today >= t0 && today <= t1 ? pct(today) + 100 / span / 2 : null;
  // одна строка на сотрудника
  const rows = useMemo(() => {
    const m = new Map<number, { u: Vac; list: Vac[] }>();
    for (const v of items) { if (!m.has(v.user_id)) m.set(v.user_id, { u: v, list: [] }); m.get(v.user_id)!.list.push(v); }
    return [...m.values()];
  }, [items]);
  return (
    <div className="gantt" role="img" aria-label="Диаграмма отпусков">
      <div className="gRow gHead">
        <div className="gName" />
        <div className="gTrack">{ticks.map((t, i) => <span key={i} className={cx('gTick', t.major && 'maj')} style={{ left: t.left + '%' }}>{t.label}</span>)}</div>
      </div>
      {rows.map(({ u, list }) => (
        <div className="gRow" key={u.user_id}>
          <div className="gName"><Link to={`/people/${u.user_id}`} className="clip">{u.name}</Link></div>
          <div className="gTrack">
            {todayLeft != null && <span className="gToday" style={{ left: todayLeft + '%' }} />}
            {list.map((v) => {
              const a = Math.max(parse(v.starts_on), t0), b = Math.min(parse(v.ends_on), t1);
              return <span key={v.id} className={cx('gBar', v.active_now && 'now')} style={{ left: pct(a) + '%', width: ((b - a) / DAY + 1) / span * 100 + '%' }}
                title={`${dmy(v.starts_on)} — ${dmy(v.ends_on)}${v.deputy ? '\nЗамещает: ' + v.deputy : ''}${v.city ? '\n' + v.city : ''}`} />;
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

// ---------------------------------------------------------------- form
function VacModal({ v, onClose, onSaved }: { v: Vac | null; onClose: () => void; onSaved: () => void }) {
  const [user, setUser] = useState<UserLite[]>(v ? [{ id: v.user_id, name: v.name, job_title: v.job_title, avatar: v.avatar }] : []);
  const [deputy, setDeputy] = useState<UserLite[]>(v?.deputy_id ? [{ id: v.deputy_id, name: v.deputy || '', job_title: v.deputy_title || '' }] : []);
  const [f, setF] = useState({ starts_on: v?.starts_on || '', ends_on: v?.ends_on || '', city: v?.city || '', note: v?.note || '' });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const bad = !user.length || !f.starts_on || !f.ends_on || f.ends_on < f.starts_on;
  async function submit() {
    setBusy(true); setErr('');
    const body = { user_id: user[0].id, starts_on: f.starts_on, ends_on: f.ends_on, deputy_id: deputy[0]?.id ?? null, city: f.city.trim(), note: f.note.trim() };
    try {
      if (v) await api.put('/api/vacations/' + v.id, body); else await api.post('/api/vacations', body);
      toast({ title: v ? 'Отпуск обновлён' : 'Отпуск добавлен', kind: 'success' }, 2000);
      onSaved(); onClose();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title={v ? 'Изменить отпуск' : 'Добавить отпуск'} size="lg" onClose={onClose}
      footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={bad} onClick={submit}><I.Check size={16} /> Сохранить</Btn></>}>
      <div className="field"><label>Сотрудник (руководитель)</label><UserPicker single value={user} onChange={setUser} placeholder="Найти руководителя…" /></div>
      <div className="formGrid">
        <Field label="Начало отпуска"><Input type="date" value={f.starts_on} onChange={(e) => setF({ ...f, starts_on: e.target.value, ends_on: f.ends_on && f.ends_on >= e.target.value ? f.ends_on : e.target.value })} /></Field>
        <Field label="Окончание" hint={f.starts_on && f.ends_on && f.ends_on >= f.starts_on ? plural(Math.round((parse(f.ends_on) - parse(f.starts_on)) / DAY) + 1, ['день', 'дня', 'дней']) : undefined}><Input type="date" min={f.starts_on} value={f.ends_on} onChange={(e) => setF({ ...f, ends_on: e.target.value })} /></Field>
      </div>
      <div className="field"><label>Кто замещает</label><UserPicker single value={deputy} onChange={setDeputy} exclude={user.map((u) => u.id)} placeholder="Найти заместителя…" /></div>
      <Field label="Город / где будет"><Input maxLength={100} value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })} placeholder="Например: Сочи" /></Field>
      <Field label="Комментарий"><Textarea rows={3} maxLength={500} value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} /></Field>
      {err && <div className="err">{err}</div>}
    </Modal>
  );
}

// ---------------------------------------------------------------- page
export function VacationsPage() {
  useTitle('График отпусков');
  const nowYm = todayIso().slice(0, 7);
  const [mode, setMode] = usePersist<Mode>('vac.mode', 'month');
  const [ym, setYm] = useState(nowYm);
  const [year, setYear] = useState(+nowYm.slice(0, 4));
  const [rng, setRng] = useState({ from: todayIso(), to: iso(Date.now() + 90 * DAY) });
  const [dept, setDept] = usePersist<number | null>('vac.dept', null);
  const [nowOnly, setNowOnly] = usePersist<boolean>('vac.now', false);
  const [q, setQ] = useState('');
  const dq = useDebounced(q.trim(), 300);
  const [ganttOpen, setGanttOpen] = usePersist<boolean>('vac.gantt', true);
  const [edit, setEdit] = useState<Vac | 'new' | null>(null);
  const [confirm, node] = useConfirm();

  const { from, to } = useMemo(() => {
    if (mode === 'month') return monthRange(ym);
    if (mode === 'year') return { from: `${year}-01-01`, to: `${year}-12-31` };
    return rng.from && rng.to && rng.to >= rng.from ? rng : { from: todayIso(), to: todayIso() };
  }, [mode, ym, year, rng]);

  const qs = new URLSearchParams({ from, to });
  if (dept) qs.set('department', String(dept));
  if (dq) qs.set('q', dq);
  const { data, error, refetch } = useQuery<{ items: Vac[]; can_manage: boolean }>('vacations:' + qs, () => api.get('/api/vacations?' + qs), { stale: 15000, keepPrevious: true });
  const items = useMemo(() => (data?.items || []).filter((v) => !nowOnly || v.active_now), [data, nowOnly]);
  const can = !!data?.can_manage;
  const reload = () => { invalidate('vacations'); refetch(); };

  async function remove(v: Vac) {
    if (!(await confirm('Удалить отпуск?', { text: `${v.name}: ${dmy(v.starts_on)} — ${dmy(v.ends_on)}`, ok: 'Удалить' }))) return;
    try { await api.del('/api/vacations/' + v.id); toast({ title: 'Отпуск удалён', kind: 'success' }, 2000); reload(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }

  return (
    <div className="stack">
      <div className="pageH">
        <h1>График отпусков</h1>
        <span className="sub">руководящий состав</span>
        <span className="sp" />
        {can && <Btn kind="pri" onClick={() => setEdit('new')}><I.Plus size={17} /> Добавить отпуск</Btn>}
      </div>

      <div className="vFilters card pad">
        <div className="vPeriod">
          <div className="viewSw" role="group" aria-label="Период">
            {([['month', 'Месяц'], ['year', 'Год'], ['range', 'Период']] as [Mode, string][]).map(([m, l]) => (
              <button key={m} type="button" className={cx(mode === m && 'on')} onClick={() => setMode(m)} style={{ width: 'auto', padding: '0 12px' }}>{l}</button>
            ))}
          </div>
          {mode === 'month' && (
            <div className="row vNav">
              <button type="button" className="btn ghost icon sm" onClick={() => setYm(shiftMonth(ym, -1))} aria-label="Предыдущий месяц"><I.ChevronLeft size={18} /></button>
              <b className="vMonth">{monthLabel(ym)}</b>
              <button type="button" className="btn ghost icon sm" onClick={() => setYm(shiftMonth(ym, 1))} aria-label="Следующий месяц"><I.ChevronRight size={18} /></button>
              {ym !== nowYm && <Btn size="sm" onClick={() => setYm(nowYm)}>Сегодня</Btn>}
            </div>
          )}
          {mode === 'year' && (
            <div className="row vNav">
              <button type="button" className="btn ghost icon sm" onClick={() => setYear(year - 1)} aria-label="Предыдущий год"><I.ChevronLeft size={18} /></button>
              <b className="vMonth">{year}</b>
              <button type="button" className="btn ghost icon sm" onClick={() => setYear(year + 1)} aria-label="Следующий год"><I.ChevronRight size={18} /></button>
            </div>
          )}
          {mode === 'range' && (
            <div className="row vNav" style={{ flexWrap: 'wrap' }}>
              <Input type="date" style={{ width: 'auto' }} value={rng.from} max={rng.to} onChange={(e) => setRng({ ...rng, from: e.target.value })} aria-label="С" />
              <span className="muted">—</span>
              <Input type="date" style={{ width: 'auto' }} value={rng.to} min={rng.from} onChange={(e) => setRng({ ...rng, to: e.target.value })} aria-label="По" />
            </div>
          )}
        </div>
        <div className="vRow2">
          <div className="fSearch"><Input placeholder="Поиск по сотруднику…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
          <div className="fDept"><DeptSelect value={dept} onChange={setDept} emptyLabel="Все подразделения" /></div>
          <Check checked={nowOnly} onChange={setNowOnly} label="Сейчас в отпуске" />
        </div>
      </div>

      {error && !data ? <ErrorBox error={error} retry={refetch} /> : !data ? <Loading /> : items.length === 0 ? (
        <div className="card"><Empty icon={I.Clock} title="Отпусков не найдено">{nowOnly || dept || dq ? 'Измените фильтры' : 'В выбранном периоде отпусков нет'}</Empty></div>
      ) : (
        <>
          <section className="card ganttCard">
            <button type="button" className="ganttHead" aria-expanded={ganttOpen} onClick={() => setGanttOpen(!ganttOpen)}>
              <span className="chev"><I.ChevronRight size={18} /></span><b>Диаграмма</b>
              <span className="muted small">{dmy(from)} — {dmy(to)}</span>
            </button>
            {ganttOpen && <div className="ganttBody"><Gantt items={items} from={from} to={to} /></div>}
          </section>

          <div className="card vTable">
            <table className="vTbl">
              <thead><tr><th>Сотрудник</th><th>Подразделение</th><th>Период</th><th>Замещает</th><th>Город</th>{can && <th />}</tr></thead>
              <tbody>
                {items.map((v) => (
                  <tr key={v.id} className={cx(v.active_now && 'now')}>
                    <td data-l="Сотрудник">
                      <Link to={`/people/${v.user_id}`} className="vWho">
                        <Avatar name={v.name} src={v.avatar} size={38} userId={v.user_id} />
                        <span style={{ minWidth: 0 }}><span className="bold">{v.name}</span><span className="small muted vJob">{v.job_title}</span></span>
                      </Link>
                    </td>
                    <td data-l="Подразделение" className="small">{v.department || '—'}</td>
                    <td data-l="Период">
                      <div className="bold nowrap">{dm(v.starts_on)} — {dmy(v.ends_on)}</div>
                      <div className="small muted">{plural(daysOf(v), ['день', 'дня', 'дней'])}{v.active_now && <> · <Badge kind="lime">сейчас в отпуске</Badge></>}</div>
                    </td>
                    <td data-l="Замещает">{v.deputy_id ? <Link to={`/people/${v.deputy_id}`} className="vDep"><span className="bold small">{v.deputy}</span>{v.deputy_title && <span className="tiny muted">{v.deputy_title}</span>}</Link> : <span className="muted">—</span>}</td>
                    <td data-l="Город" className="small">{v.city || '—'}{v.note && <div className="tiny muted">{v.note}</div>}</td>
                    {can && <td className="vAct"><button type="button" className="btn ghost icon sm" onClick={() => setEdit(v)} aria-label="Изменить"><I.Edit size={16} /></button><button type="button" className="btn ghost icon sm" onClick={() => remove(v)} aria-label="Удалить"><I.Trash size={16} /></button></td>}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="small muted">Всего записей: {items.length}</div>
        </>
      )}
      {edit && <VacModal v={edit === 'new' ? null : edit} onClose={() => setEdit(null)} onSaved={reload} />}
      {node}
    </div>
  );
}
