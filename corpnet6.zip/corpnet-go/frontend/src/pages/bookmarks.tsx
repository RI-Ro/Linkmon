import React, { useState } from 'react';
import * as I from '../lib/icons';
import * as X from '../lib/social-icons';
import { api, errMsg } from '../lib/api';
import { useQuery } from '../lib/query';
import { usePersist } from '../lib/persist';
import { Link, useTitle } from '../lib/router';
import { toast } from '../lib/store';
import { cx, fmtDate, useDebounced } from '../lib/util';
import { Btn, Empty, ErrorBox, Input, Loading, Pager } from '../ui';
import '../ui/social.css';

interface Item { entity_type: string; entity_id: number; title: string; subtitle: string; link: string; at: string; created_at: string; note: string; label: string; icon: string }
interface Page { items: Item[]; total: number; page: number; pages: number; per: number; types: { type: string; label: string; icon: string; count: number }[] }

const ICON: Record<string, any> = { news: I.Newspaper, idea: I.Lightbulb, file: I.FileText, post: I.Users, event: I.Calendar, message: I.Message, learn: I.GradCap, wiki: I.Book, bookmark: X.Bookmark };
const PER = 30;

function Row({ it, onChanged }: { it: Item; onChanged: () => void }) {
  const Ic = ICON[it.icon] || X.Bookmark;
  const [edit, setEdit] = useState(false);
  const [note, setNote] = useState(it.note);
  async function saveNote() {
    try { await api.put('/api/bookmarks', { entity_type: it.entity_type, entity_id: it.entity_id, note }); setEdit(false); onChanged(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function remove() {
    try { await api.post('/api/bookmarks', { entity_type: it.entity_type, entity_id: it.entity_id, on: false }); onChanged(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  return (
    <div className="bmRow">
      <span className="bmIc"><Ic size={19} /></span>
      <div className="bmMain">
        <Link to={it.link} className="t">{it.title || 'Без названия'}</Link>
        <div className="s">{[it.subtitle, it.at && fmtDate(it.at)].filter(Boolean).join(' · ')} · в закладках с {fmtDate(it.created_at)}</div>
        {edit ? (
          <div className="row" style={{ marginTop: 4 }}>
            <Input className="sp" value={note} maxLength={500} autoFocus placeholder="Заметка к закладке" onChange={(e) => setNote(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') saveNote(); if (e.key === 'Escape') setEdit(false); }} />
            <Btn kind="pri" size="sm" onClick={saveNote}>Сохранить</Btn><Btn size="sm" kind="ghost" onClick={() => { setEdit(false); setNote(it.note); }}>Отмена</Btn>
          </div>
        ) : it.note ? <div className="bmNote">{it.note}</div> : null}
      </div>
      <div className="row" style={{ gap: 2 }}>
        <button type="button" className="bmBtn" title="Заметка" aria-label="Заметка" onClick={() => setEdit(true)}><I.Edit size={16} /></button>
        <button type="button" className="bmBtn on" title="Убрать из закладок" aria-label="Убрать из закладок" onClick={remove}><X.BookmarkFill size={17} /></button>
      </div>
    </div>
  );
}

export function BookmarksPage() {
  useTitle('Закладки');
  const [type, setType] = usePersist('bookmarks.type', '');
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const dq = useDebounced(q.trim(), 250);
  const key = `bookmarks:${type}:${dq}:${page}`;
  const r = useQuery<Page>(key, () => api.get(`/api/bookmarks?type=${encodeURIComponent(type)}&q=${encodeURIComponent(dq)}&page=${page}&per=${PER}`), { stale: 5000, keepPrevious: true });
  const d = r.data;
  const total = d?.types.reduce((a, b) => a + b.count, 0) || 0;
  // без фильтра по типу — группировка по типам внутри страницы
  const groups: { label: string; items: Item[] }[] = [];
  for (const it of d?.items || []) {
    const g = groups.find((x) => x.label === it.label);
    if (g) g.items.push(it); else groups.push({ label: it.label, items: [it] });
  }
  const pick = (t: string) => { setType(t); setPage(1); };
  return (
    <div className="bmPage">
      <div className="card pad stackS">
        <div className="bmHead">
          <h1 className="sp" style={{ fontSize: 26, display: 'flex', alignItems: 'center', gap: 10 }}><X.BookmarkFill size={26} style={{ color: 'var(--accent)' }} /> Закладки</h1>
          <div style={{ position: 'relative', minWidth: 240, flex: '0 1 340px' }}>
            <Input placeholder="Поиск по заголовку и заметке" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} aria-label="Поиск по закладкам" />
          </div>
        </div>
        {d && d.types.length > 0 && (
          <div className="bmTabs" role="tablist">
            <button type="button" role="tab" aria-selected={type === ''} className={cx(type === '' && 'on')} onClick={() => pick('')}>Все <span className="c">{total}</span></button>
            {d.types.map((t) => <button type="button" role="tab" key={t.type} aria-selected={type === t.type} className={cx(type === t.type && 'on')} onClick={() => pick(t.type)}>{t.label} <span className="c">{t.count}</span></button>)}
          </div>
        )}
      </div>
      {r.error && !d ? <div className="card"><ErrorBox error={r.error} retry={r.refetch} /></div> : !d ? <Loading /> : d.items.length === 0 ? (
        <div className="card"><Empty icon={X.Bookmark} title={dq ? 'Ничего не найдено' : 'Закладок пока нет'}>{dq ? 'Измените запрос.' : 'Нажмите значок закладки на новости, идее, документе, публикации группы, событии календаря или сообщении — они появятся здесь.'}</Empty></div>
      ) : (
        <div className="card" style={{ opacity: r.loading ? 0.7 : 1, transition: 'opacity .15s' }}>
          {groups.map((g) => (
            <section key={g.label} className="bmGroup">
              {!type && <h4>{g.label}</h4>}
              {g.items.map((it) => <Row key={it.entity_type + it.entity_id} it={it} onChanged={() => r.refetch()} />)}
            </section>
          ))}
          <div style={{ padding: '6px 12px 14px' }}><Pager page={d.page} total={d.total} per={d.per} pages={d.pages} onChange={setPage} /></div>
        </div>
      )}
    </div>
  );
}
