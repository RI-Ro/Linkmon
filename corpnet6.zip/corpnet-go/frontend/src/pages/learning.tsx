import React, { useEffect } from 'react';
import { matchPath, navigate, useLocation, Link } from '../lib/router';
import { usePersist } from '../lib/persist';
import { cx } from '../lib/util';
import * as I from '../lib/icons';
import { Empty } from '../ui';
import './learning/learning.css';
import { ItemPage, MaterialsPage } from './learning/materials';
import { AttemptPage, RunPage } from './learning/run';
import { MyResultsPage, TestPage, TestsPage } from './learning/tests';
import { TestEditor } from './learning/editor';
import { ResultsPage } from './learning/results';
import { wikiRoute } from './wiki';
import { CoursesPage } from './learning/lms-courses';
import { CoursePage } from './learning/lms-course';
import { CourseEditor } from './learning/lms-editor';
import { MyLearningPage } from './learning/lms-my';
import { CertificatePage, CertificatesPage } from './learning/lms-certs';
import { AssignForm, AssignmentPage, AssignmentsPage } from './learning/lms-assign';
import { StatsPage, TargetStatsPage, UserStatsPage } from './learning/lms-stats';
import { useStatsMe } from './learning/lms-common';

type Tab = 'my' | 'courses' | 'materials' | 'tests' | 'certs' | 'assign' | 'stats';
const TAB_OF: [string, Tab][] = [['/learning/my', 'my'], ['/learning/courses', 'courses'], ['/learning/materials', 'materials'], ['/learning/wiki', 'materials'], ['/learning/tests', 'tests'], ['/learning/certificates', 'certs'], ['/learning/assignments', 'assign'], ['/learning/stats', 'stats']];

export function LearningPage() {
  const { path: pathname } = useLocation();
  const [tab, setTab] = usePersist<Tab>('learn:tab2', 'my');
  const sm = useStatsMe();
  const mgr = !!sm.data?.manager;
  const path = pathname.replace(/\/+$/, '') || '/';
  const cur: Tab | null = TAB_OF.find(([p]) => path === p || path.startsWith(p + '/'))?.[1] ?? null;
  useEffect(() => { if (cur && cur !== tab) setTab(cur); }, [cur]);
  useEffect(() => { if (path === '/learning') navigate(`/learning/${({ my: 'my', courses: 'courses', materials: 'materials', tests: 'tests', certs: 'certificates', assign: 'my', stats: 'my' } as Record<Tab, string>)[tab] || 'my'}`, { replace: true }); }, [path]);

  const run = matchPath('/learning/tests/:id/run', path);
  const focus = !!run; // экран прохождения без вкладок
  let body: React.ReactNode = null;
  let m: Record<string, string> | null;
  if ((m = matchPath('/learning/materials/item/:id', path))) body = <ItemPage id={+m.id} key={m.id} />;
  else if (path.startsWith('/learning/wiki') && wikiRoute(path)) body = wikiRoute(path); // базы знаний (pages/wiki)
  else if (path === '/learning/materials') body = <MaterialsPage />;
  else if (path === '/learning/tests') body = <TestsPage />;
  else if (path === '/learning/tests/my') body = <MyResultsPage />;
  else if (path === '/learning/tests/new') body = <TestEditor key="new" />;
  else if ((m = matchPath('/learning/tests/attempt/:id', path))) body = <AttemptPage id={+m.id} key={m.id} />;
  else if (run) body = <RunPage id={+run.id} key={run.id} />;
  else if ((m = matchPath('/learning/tests/:id/results', path))) body = <ResultsPage id={+m.id} key={m.id} />;
  else if ((m = matchPath('/learning/tests/:id/edit', path))) body = <TestEditor id={+m.id} key={m.id} />;
  else if ((m = matchPath('/learning/tests/:id', path)) && /^\d+$/.test(m.id)) body = <TestPage id={+m.id} key={m.id} />;
  else if (path === '/learning/my') body = <MyLearningPage />;
  else if (path === '/learning/courses') body = <CoursesPage />;
  else if (path === '/learning/courses/new') body = <CourseEditor key="new" />;
  else if ((m = matchPath('/learning/courses/:id/edit', path)) && /^\d+$/.test(m.id)) body = <CourseEditor id={+m.id} key={m.id} />;
  else if ((m = matchPath('/learning/courses/:id/step/:sid', path)) && /^\d+$/.test(m.id) && /^\d+$/.test(m.sid)) body = <CoursePage id={+m.id} sid={+m.sid} key={m.id} />;
  else if ((m = matchPath('/learning/courses/:id', path)) && /^\d+$/.test(m.id)) body = <CoursePage id={+m.id} key={m.id} />;
  else if (path === '/learning/certificates') body = <CertificatesPage />;
  else if ((m = matchPath('/learning/certificates/:id', path)) && /^\d+$/.test(m.id)) body = <CertificatePage id={+m.id} key={m.id} />;
  else if (path === '/learning/assignments') body = <AssignmentsPage />;
  else if (path === '/learning/assignments/new') body = <AssignForm />;
  else if ((m = matchPath('/learning/assignments/:id', path)) && /^\d+$/.test(m.id)) body = <AssignmentPage id={+m.id} key={m.id} />;
  else if (path === '/learning/stats') body = <StatsPage />;
  else if ((m = matchPath('/learning/stats/:type/:id', path)) && /^\d+$/.test(m.id) && (m.type === 'course' || m.type === 'test')) body = <TargetStatsPage type={m.type} id={+m.id} key={m.type + m.id} />;
  else if ((m = matchPath('/learning/stats/user/:id', path)) && /^\d+$/.test(m.id)) body = <UserStatsPage id={+m.id} key={m.id} />;
  else if (path !== '/learning') body = <Empty icon={I.Search} title="Страница не найдена"><Link to="/learning">В раздел «Обучение»</Link></Empty>;

  return (
    <div className={cx('lnPage', focus && 'focus')}>
      {!focus && (
        <nav className="lnTabs" aria-label="Разделы обучения">
          <Link to="/learning/my" className={cx(cur === 'my' && 'on')}><I.Home size={17} /> Моё обучение</Link>
          <Link to="/learning/courses" className={cx(cur === 'courses' && 'on')}><I.GradCap size={17} /> Курсы</Link>
          <Link to="/learning/materials" className={cx(cur === 'materials' && 'on')}><I.Book size={17} /> Материалы</Link>
          <Link to="/learning/tests" className={cx(cur === 'tests' && 'on')}><I.Check size={17} /> Тесты</Link>
          <Link to="/learning/certificates" className={cx(cur === 'certs' && 'on')}><I.Star size={17} /> Сертификаты</Link>
          {mgr && <Link to="/learning/assignments" className={cx(cur === 'assign' && 'on')}><I.UserPlus size={17} /> Назначения</Link>}
          {mgr && <Link to="/learning/stats" className={cx(cur === 'stats' && 'on')}><I.Chart size={17} /> Статистика</Link>}
          {cur === 'tests' && <Link to="/learning/tests/my" className={cx('lnTabMy', path === '/learning/tests/my' && 'on')}><I.Activity size={16} /> Мои результаты</Link>}
        </nav>
      )}
      {body}
    </div>
  );
}
