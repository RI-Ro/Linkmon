import React, { useEffect, useMemo, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { Link, navigate, pageHref, useSearchParams, useTitle } from '../lib/router';
import { useStore, setState, toast } from '../lib/store';
import { usePersist, usePersistSet } from '../lib/persist';
import { callHref, cleanDial, cx, useDebounced, plural, thumb, view } from '../lib/util';
import { Markdown } from '../lib/markdown';
import { Avatar, Badge, Btn, Check, Empty, ErrorBox, Field, ImageUpload, Input, Loading, Pager, Skel, Textarea } from '../ui';
import { DeptSelect, useDepartments } from '../ui/DeptSelect';
import { NewsCard } from './news';
import { FileHitsSection } from '../ui/FileHit';
import { ThemeChips } from '../layout/ThemePicker';
import { trackSearchClick } from '../lib/analytics';
import './people.css';

export { useDepartments };

// ---------------------------------------------------------------- helpers
const HeadBadge = () => <Badge kind="lime">руководитель</Badge>;

const telHref = (p: string) => 'tel:' + p.replace(/[^\d+]/g, '');
/** Обычные телефоны 1–3; «Видеотелефон» (phone4) показывается отдельно ссылкой call://makecall$… */
const phonesOf = (u: any): string[] => [u.phone1, u.phone2, u.phone3].filter((x) => !!x && String(x).trim());

const fmtBirthday = (s?: string | null) =>
  s ? new Date(s.slice(0, 10) + 'T00:00:00Z').toLocaleDateString('ru', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }) : '';

/** «Видеотелефон»: ссылка call://makecall$НОМЕР, текст — номер как введён. */
export function VideoPhone({ value }: { value?: string | null }) {
  const v = String(value ?? '').trim();
  if (!v) return <>—</>;
  if (!cleanDial(v)) return <>{v}</>;
  return <a className="videoPhone" href={callHref(v)}>{v}</a>;
}

function Phones({ u }: { u: any }) {
  const ph = phonesOf(u);
  if (!ph.length) return <>—</>;
  return <span className="phoneList">{ph.map((p, i) => <a key={i} href={telHref(p)}>{p}</a>)}</span>;
}

/** Плоский список с parent_id → дети в порядке сервера. Сироты (родитель не виден) считаются корневыми. */
function useTree<T extends { id: number; parent_id: number | null }>(list: T[] | undefined) {
  return useMemo(() => {
    const ids = new Set((list || []).map((d) => d.id));
    const kids = new Map<number | null, T[]>();
    for (const d of list || []) {
      const p = d.parent_id != null && ids.has(d.parent_id) ? d.parent_id : null;
      if (!kids.has(p)) kids.set(p, []);
      kids.get(p)!.push(d);
    }
    return kids;
  }, [list]);
}

/** Раскрытые узлы дерева — предпочтение пользователя, хранится между сеансами (по умолчанию всё свёрнуто). */
function useOpenSet(key: string) {
  const [open, upd] = usePersistSet(key);
  const toggle = (id: number) => upd((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const setOpen = (n: Set<number>) => upd(() => n);
  return { open, toggle, setOpen };
}

function Toggle({ has, open, onClick, label }: { has: boolean; open: boolean; onClick: () => void; label: string }) {
  return (
    <button type="button" className={cx('tTog', open && 'open', !has && 'none')} onClick={onClick} aria-expanded={open} aria-label={(open ? 'Свернуть: ' : 'Развернуть: ') + label} tabIndex={has ? 0 : -1}>
      <span className="ic"><I.ChevronRight size={17} /></span>
    </button>
  );
}

export function MessageButton({ userId, size }: { userId: number; size?: 'sm' }) {
  const [busy, setBusy] = useState(false);
  return (
    <Btn kind="pri" size={size} busy={busy} onClick={async () => {
      setBusy(true);
      try { const c = await api.post('/api/chats', { user_id: userId }); invalidate('chats'); navigate('/messages?chat=' + c.id); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); setBusy(false); }
    }}><I.Message size={16} /> Написать</Btn>
  );
}

function PersonCard({ u, size = 72 }: { u: any; size?: number }) {
  return (
    <Link to={`/people/${u.id}`} className="card person">
      <Avatar name={u.name} src={u.avatar} size={size} userId={u.id} />
      <div className="nm">{u.name}</div>
      {u.is_head && <HeadBadge />}
      <div className="jt clamp2">{u.job_title}</div>
      {u.department && <div className="tiny faint clip" style={{ maxWidth: '100%' }}>{u.department}</div>}
    </Link>
  );
}

// ---------------------------------------------------------------- people
export function PeoplePage() {
  useTitle('Сотрудники');
  const [sp, setSp] = useSearchParams();
  const [q, setQ] = useState(sp.get('q') || '');
  const dq = useDebounced(q, 300);
  useEffect(() => { if (dq !== (sp.get('q') || '')) setSp({ q: dq || null, page: null }); }, [dq]);
  const dept = sp.get('department') || '', heads = sp.get('heads') === '1', page = +(sp.get('page') || 1);
  const [view, pickView] = usePersist<'cards' | 'list'>('people.view', 'cards');
  const qs = new URLSearchParams({ page: String(page), per: '24' });
  if (sp.get('q')) qs.set('q', sp.get('q')!);
  if (dept) qs.set('department', dept);
  if (heads) qs.set('heads', '1');
  const { data, error, refetch } = useQuery<any>('users:' + qs, () => api.get('/api/users?' + qs), { stale: 30000, keepPrevious: true });
  return (
    <div className="stack">
      <div className="pageH"><h1>Сотрудники</h1>{data && <span className="sub">{plural(data.total, ['человек', 'человека', 'человек'])}</span>}</div>
      <div className="pFilters">
        <div className="fSearch"><Input placeholder="Фамилия, имя, должность, e-mail…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <div className="fDept"><DeptSelect value={dept ? +dept : null} onChange={(id) => setSp({ department: id, page: null })} emptyLabel="Все подразделения" /></div>
        <Check checked={heads} onChange={(v) => setSp({ heads: v ? 1 : null, page: null })} label="Только руководители" />
        <div className="viewSw" role="group" aria-label="Вид">
          <button className={cx(view === 'cards' && 'on')} onClick={() => pickView('cards')} title="Карточки" aria-label="Карточки"><I.Dashboard size={17} /></button>
          <button className={cx(view === 'list' && 'on')} onClick={() => pickView('list')} title="Список" aria-label="Список"><I.List size={17} /></button>
        </div>
      </div>
      {error && !data ? <ErrorBox error={error} retry={refetch} /> : !data ? <Loading /> : data.items.length === 0 ? <div className="card"><Empty icon={I.Users} title="Никого не нашли">Измените запрос или сбросьте фильтры</Empty></div> : (
        <>
          {view === 'cards' ? (
            <div className="grid3">{data.items.map((u: any) => <PersonCard key={u.id} u={u} />)}</div>
          ) : (
            <div className="card pRows">
              {data.items.map((u: any) => (
                <Link key={u.id} to={`/people/${u.id}`} className="pRow">
                  <Avatar name={u.name} src={u.avatar} size={42} userId={u.id} />
                  <div className="who">
                    <div className="nmRow"><span className="bold">{u.name}</span>{u.is_head && <HeadBadge />}</div>
                    <div className="small muted clip">{u.job_title}</div>
                  </div>
                  <div className="dep small muted clip">{u.department}</div>
                  <div className="con small muted clip">{phonesOf(u)[0] || ''}{phonesOf(u)[0] && u.email ? ' · ' : ''}{u.email}</div>
                </Link>
              ))}
            </div>
          )}
          <Pager href={pageHref} page={page} total={data.total} per={data.per} onChange={(p) => setSp({ page: p > 1 ? p : null }, false)} />
        </>
      )}
    </div>
  );
}

export function ProfilePage({ id }: { id: number }) {
  const me = useStore((s) => s.me)!;
  const { data: u, error, refetch } = useQuery<any>('user:' + id, () => api.get('/api/users/' + id), { stale: 60000 });
  useTitle(u?.name || 'Профиль');
  const online = useStore((s) => s.online.has(id));
  if (error) return <ErrorBox error={error} retry={refetch} />;
  if (!u) return <div className="card pad"><Skel h={200} /></div>;
  const bd = fmtBirthday(u.birthday);
  return (
    <div className="stack" style={{ maxWidth: 900 }}>
      <div className="card profHead">
        <div className="profBanner" />
        <div className="profBody">
          <div className="profTop">
            <Avatar name={u.name} src={u.avatar} size={112} userId={id} />
            <div className="sp" style={{ paddingBottom: 6, minWidth: 200 }}>
              <h1 style={{ fontSize: 26 }}>{u.name}</h1>
              <div className="muted">{u.job_title}</div>
              <div className="row small" style={{ marginTop: 4, flexWrap: 'wrap' }}>
                {u.is_head && <HeadBadge />}
                {online ? <Badge kind="ok">● в сети</Badge> : <Badge>не в сети</Badge>}
                {u.role !== 'user' && <Badge kind="accent">{u.role === 'admin' ? 'Администратор' : 'Редактор'}</Badge>}
              </div>
            </div>
            <div className="row" style={{ paddingBottom: 6 }}>
              {id === me.id ? <Link to="/settings" className="btn"><I.Edit size={16} /> Редактировать</Link> : <MessageButton userId={id} />}
            </div>
          </div>
          <dl className="infoGrid" style={{ margin: 0 }}>
            <div><dt>Подразделение</dt><dd>{u.department_id ? <Link to={`/departments/${u.department_id}`} style={{ color: 'var(--accent)' }}>{u.department}</Link> : '—'}</dd></div>
            <div><dt>Должность</dt><dd>{u.job_title || '—'}</dd></div>
            <div><dt>Email</dt><dd>{u.email ? <a href={`mailto:${u.email}`}>{u.email}</a> : '—'}</dd></div>
            <div><dt>Телефоны</dt><dd><Phones u={u} /></dd></div>
            <div><dt>Видеотелефон</dt><dd><VideoPhone value={u.phone4} /></dd></div>
            <div><dt>День рождения</dt><dd>{bd ? <>{bd}{u.age != null && <span className="muted"> · {plural(u.age, ['год', 'года', 'лет'])}</span>}</> : '—'}</dd></div>
            <div><dt>Логин</dt><dd>{u.login}</dd></div>
          </dl>
          {u.extra_info && <div><div className="lbl" style={{ marginBottom: 4 }}>Дополнительная информация</div><div className="extraInfo">{u.extra_info}</div></div>}
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- departments
export function DepartmentsPage() {
  useTitle('Подразделения');
  const { data, error, refetch } = useDepartments();
  const kids = useTree<any>(data as any);
  const { open, toggle, setOpen } = useOpenSet('dept.open');
  const [f, setF] = useState('');
  const df = useDebounced(f.trim().toLowerCase(), 150);
  const byId = useMemo(() => new Map((data || []).map((d: any) => [d.id, d])), [data]);
  // при поиске: показываем совпадения вместе с предками и раскрываем путь до них
  const shown = useMemo(() => {
    if (!df) return null;
    const s = new Set<number>();
    for (const d of (data || []) as any[]) {
      if (!d.name.toLowerCase().includes(df)) continue;
      let cur: any = d, n = 0;
      while (cur && n++ < 20) { s.add(cur.id); cur = cur.parent_id != null ? byId.get(cur.parent_id) : null; }
    }
    return s;
  }, [df, data, byId]);
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data) return <Loading />;
  const render = (pid: number | null): React.ReactNode => (kids.get(pid) || []).filter((d: any) => !shown || shown.has(d.id)).map((d: any) => {
    const ch = (kids.get(d.id) || []).filter((c: any) => !shown || shown.has(c.id));
    const isOpen = shown ? true : open.has(d.id);
    return (
      <div className="tNode" key={d.id}>
        <div className="tRow">
          <Toggle has={ch.length > 0} open={isOpen} onClick={() => toggle(d.id)} label={d.name} />
          <div className="tIco" style={d.image ? { backgroundImage: `url(${thumb(d.image)})` } : undefined}>{!d.image && <I.Building size={18} />}</div>
          <div className="tMain">
            <Link to={`/departments/${d.id}`} className="tt">{d.name}</Link>
            {d.head && <div className="tMeta"><HeadBadge /><span className="clip">{d.head}</span></div>}
          </div>
          <span className="tCnt">{plural(d.employees, ['сотрудник', 'сотрудника', 'сотрудников'])}</span>
        </div>
        {ch.length > 0 && isOpen && <div className="tKids">{render(d.id)}</div>}
      </div>
    );
  });
  const parents = (data as any[]).filter((d) => d.children_count > 0 || (kids.get(d.id) || []).length > 0).map((d) => d.id);
  return (
    <div className="stack" style={{ maxWidth: 960 }}>
      <div className="pageH"><h1>Подразделения</h1><span className="sub">{data.length}</span></div>
      <div className="pFilters">
        <div className="fSearch"><Input placeholder="Найти подразделение…" value={f} onChange={(e) => setF(e.target.value)} /></div>
        <Btn size="sm" onClick={() => setOpen(new Set(parents))}>Развернуть все</Btn>
        <Btn size="sm" onClick={() => setOpen(new Set())}>Свернуть все</Btn>
      </div>
      <div className="card pad">
        {shown && shown.size === 0 ? <Empty icon={I.Building} title="Ничего не найдено" /> : <div className="tree">{render(null)}</div>}
      </div>
    </div>
  );
}

export function DepartmentPage({ id }: { id: number }) {
  const { data, error, refetch } = useQuery<any>('department:' + id, () => api.get('/api/departments/' + id), { stale: 60000 });
  const news = useQuery<any>('news:list:dept:' + id, () => api.get(`/api/news?department=${id}&per=6`), { stale: 30000 });
  useTitle(data?.department.name || 'Подразделение');
  if (error) return <ErrorBox error={error} retry={refetch} />;
  if (!data) return <Loading />;
  const { department: d, children, employees, breadcrumbs } = data;
  const head = employees.find((u: any) => u.id === d.head_id);
  return (
    <div className="stack">
      <div className="crumbs">
        <Link to="/departments">Подразделения</Link>
        {(breadcrumbs || []).map((b: any) => <React.Fragment key={b.id}><I.ChevronRight size={14} /><Link to={`/departments/${b.id}`}>{b.name}</Link></React.Fragment>)}
        <I.ChevronRight size={14} /><span style={{ color: 'var(--text)' }}>{d.name}</span>
      </div>
      <div className="card deptHero" style={{ overflow: 'hidden' }}>
        {d.image && <div className="im" style={{ backgroundImage: `url(${view(d.image)})` }} />}
        <div className="pad stackS">
          <h1 style={{ fontSize: 28 }}>{d.name}</h1>
          <div className="small muted">{plural(d.employees_total, ['сотрудник', 'сотрудника', 'сотрудников'])} в подразделении и дочерних</div>
          {d.head_id && (
            <Link to={`/people/${d.head_id}`} className="row" style={{ gap: 12, marginTop: 4 }}>
              <Avatar name={d.head} src={head?.avatar} size={44} userId={d.head_id} />
              <div style={{ minWidth: 0 }}>
                <div className="bold">{d.head}</div>
                <div className="row small muted" style={{ gap: 8, flexWrap: 'wrap' }}><HeadBadge />{head?.job_title}</div>
              </div>
            </Link>
          )}
        </div>
      </div>
      {d.description && (
        <section className="card pad stackS">
          <h3>Описание</h3>
          <Markdown text={d.description} className="prose md deptDesc" />
        </section>
      )}
      {children.length > 0 && (
        <section className="stackS"><h3>Дочерние подразделения · {children.length}</h3>
          <div className="grid3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))' }}>
            {children.map((c: any) => (
              <Link key={c.id} to={`/departments/${c.id}`} className="card deptCard">
                <div className="im" style={c.image ? { backgroundImage: `url(${thumb(c.image)})` } : undefined} />
                <div className="bd">
                  <div className="bold">{c.name}</div>
                  <div className="small muted">{plural(c.employees, ['сотрудник', 'сотрудника', 'сотрудников'])}{c.children_count > 0 ? ' · ' + c.children_count + ' доч.' : ''}</div>
                  {c.head && <div className="row small" style={{ gap: 6, flexWrap: 'wrap' }}><HeadBadge /><span className="muted">{c.head}</span></div>}
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
      <section className="stackS"><h3>Сотрудники · {employees.length}</h3>
        {employees.length === 0 ? <div className="card"><Empty title="В подразделении пока никого нет" /></div> : (
          <div className="grid3">{employees.map((u: any) => <PersonCard key={u.id} u={{ ...u, department: undefined }} size={64} />)}</div>
        )}
      </section>
      {news.data?.items?.length > 0 && (
        <section className="stackS"><div className="row"><h3 className="sp">Новости подразделения</h3><Link to={`/?department=${id}`} className="btn ghost sm">Все →</Link></div>
          <div className="newsGrid">{news.data.items.map((n: any) => <NewsCard key={n.id} n={n} />)}</div></section>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- directions
function DirectionTree({ list }: { list: any[] }) {
  const kids = useTree<any>(list);
  const { open, toggle, setOpen } = useOpenSet('dir.open');
  const parents = list.filter((d) => (kids.get(d.id) || []).length > 0).map((d) => d.id);
  const render = (pid: number | null): React.ReactNode => (kids.get(pid) || []).map((d: any) => {
    const ch = kids.get(d.id) || [];
    const isOpen = open.has(d.id);
    return (
      <div className="tNode" key={d.id}>
        <div className="tRow dirRow">
          <Toggle has={ch.length > 0} open={isOpen} onClick={() => toggle(d.id)} label={d.name} />
          <Link to={`/?direction=${d.id}`}><div className="cv" style={d.cover ? { backgroundImage: `url(${thumb(d.cover)})` } : undefined} /></Link>
          <div className="tMain" style={{ gap: 3 }}>
            <Link to={`/?direction=${d.id}`} className="tt" style={{ whiteSpace: 'normal' }}>{d.name}</Link>
            {d.description && <div className="desc clamp2">{d.description}</div>}
            <div className="links">
              <Link to={`/?direction=${d.id}`} className="chip" style={{ height: 28, fontSize: 12.5 }}><I.Newspaper size={13} /> Новости</Link>
              {d.department_id && <Link to={`/departments/${d.department_id}`} className="chip" style={{ height: 28, fontSize: 12.5 }}><I.Building size={13} /> {d.department}</Link>}
              {ch.length > 0 && <span className="tiny faint" style={{ alignSelf: 'center' }}>вложенных: {ch.length}</span>}
            </div>
          </div>
        </div>
        {ch.length > 0 && isOpen && <div className="tKids">{render(d.id)}</div>}
      </div>
    );
  });
  return (
    <>
      <div className="pFilters">
        <Btn size="sm" onClick={() => setOpen(new Set(parents))}>Развернуть все</Btn>
        <Btn size="sm" onClick={() => setOpen(new Set())}>Свернуть все</Btn>
      </div>
      <div className="tree">{render(null)}</div>
    </>
  );
}

export function DirectionsPage() {
  useTitle('Направления деятельности');
  const { data, error, refetch } = useQuery<any[]>('directions', () => api.get('/api/directions'), { stale: 120000 });
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data) return <Loading />;
  return (
    <div className="stack" style={{ maxWidth: 960 }}>
      <div className="pageH"><h1>Направления деятельности</h1><span className="sub">тематические разделы новостей</span></div>
      {data.length === 0 ? <div className="card"><Empty icon={I.Layers} title="Направлений пока нет" /></div> : <div className="card pad"><DirectionTree list={data} /></div>}
    </div>
  );
}

// ---------------------------------------------------------------- company / resources
export function CompanyPage() {
  useTitle('О компании');
  const c = useStore((s) => s.company);
  if (!c) return <Loading />;
  return (
    <div className="stack" style={{ maxWidth: 960 }}>
      <div className="card profHead">
        <div className="profBanner" style={{ height: 160 }} />
        <div className="profBody" style={{ paddingTop: 20 }}>
          <h1 style={{ fontSize: 30 }}>{c.name}</h1>
          <div className="muted" style={{ fontSize: 17 }}>{c.tagline}</div>
          <p>{c.about}</p>
          <dl className="infoGrid" style={{ margin: 0 }}>
            <div><dt>Адрес</dt><dd>{c.address}</dd></div>
            <div><dt>Телефон</dt><dd>{c.phone ? <a href={telHref(c.phone)}>{c.phone}</a> : '—'}</dd></div>
            <div><dt>Email</dt><dd>{c.email ? <a href={`mailto:${c.email}`}>{c.email}</a> : '—'}</dd></div>
            {c.founded ? <div><dt>Основана</dt><dd>{c.founded} г.</dd></div> : null}
          </dl>
        </div>
      </div>
    </div>
  );
}

export function ResourcesPage() {
  useTitle('Ресурсы');
  const { data, error, refetch } = useQuery<any[]>('resources', () => api.get('/api/resources'), { stale: 120000 });
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data) return <Loading />;
  const icons: any = I;
  const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
  return (
    <div className="stack">
      <div className="pageH"><h1>Корпоративные ресурсы</h1></div>
      <div className="grid3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))' }}>
        {data.map((r) => { const Ic = icons[cap(r.icon)] || I.Link; return (
          <a key={r.id} href={r.url} target="_blank" rel="noopener noreferrer" className="card pad row" style={{ alignItems: 'flex-start', gap: 14 }}>
            <div className="fico" style={{ width: 46, height: 46 }}><Ic size={22} /></div>
            <div style={{ minWidth: 0 }}><div className="bold">{r.name}</div><div className="small muted clamp2">{r.description}</div></div>
          </a>
        ); })}
      </div>
    </div>
  );
}

import { wikiLink } from './wiki/lib';
import { WikiSnippet } from './wiki';
// ---------------------------------------------------------------- search page
// Сервер ограничивает выдачу каждой группы — при достижении лимита просим уточнить запрос.
const LIMITS = { news: 6, users: 6, departments: 5, files: 6, groups: 5, ideas: 4 };

function SearchMore({ n, limit, to, label }: { n: number; limit: number; to?: string; label?: string }) {
  if (n < limit) return null;
  return <div className="sMore"><span>Показаны первые {limit} результатов, уточните запрос.</span>{to && <Link to={to}>{label || 'Показать все'} →</Link>}</div>;
}

export function SearchPage() {
  const [sp, setSp] = useSearchParams();
  const urlQ = sp.get('q') || '';
  const [q, setQ] = useState(urlQ);
  useEffect(() => { setQ(urlQ); }, [urlQ]);
  const dq = useDebounced(q.trim(), 350);
  useEffect(() => { if (dq !== urlQ.trim()) setSp({ q: dq || null }, true); }, [dq]);
  useTitle('Поиск: ' + urlQ);
  const active = urlQ.trim();
  const { data, error } = useQuery<any>(active.length >= 2 ? 'search:' + active : null, () => api.get('/api/search?q=' + encodeURIComponent(active)), { stale: 30000, keepPrevious: true });
  const ideas = data?.ideas || [];
  const total = data ? data.news.length + data.users.length + data.departments.length + data.files.length + data.groups.length + ideas.length + (data.file_content?.length || 0) + (data.wiki?.length || 0) : 0;
  const enc = encodeURIComponent(active);
  return (
    <div className="stack" style={{ maxWidth: 900 }} onClickCapture={(e) => { const a = (e.target as HTMLElement).closest?.('a.fileRow'); if (a) trackSearchClick(active, 'global', (a.getAttribute('href') || '').replace(/^\//, '').replace(/\?.*$/, '')); }}>
      <div className="pageH"><h1>Результаты поиска</h1>{active && <span className="sub">«{active}»</span>}</div>
      <Input autoFocus placeholder="Поиск по порталу…" value={q} onChange={(e) => setQ(e.target.value)} />
      {active.length < 2 ? <div className="card"><Empty icon={I.Search} title="Введите запрос">Не короче двух символов</Empty></div>
        : error && !data ? <ErrorBox error={error} /> : !data ? <Loading /> : total === 0 ? <div className="card"><Empty icon={I.Search} title="Ничего не найдено">Проверьте написание или попробуйте другой запрос</Empty></div> : (
        <>
          {data.news.length > 0 && <section className="stackS sGroup"><h3>Новости</h3><div className="card">{data.news.map((n: any) => <Link key={n.id} to={`/news/${n.id}`} className="fileRow"><div className="thumbS" style={{ background: `url(${thumb(n.cover)}) center/cover var(--surface3)` }} /><div className="sp"><div className="bold">{n.title}</div><div className="small muted">{n.category}</div></div></Link>)}<SearchMore n={data.news.length} limit={LIMITS.news} to={`/?q=${enc}`} label="Все новости" /></div></section>}
          {data.users.length > 0 && <section className="stackS sGroup"><h3>Сотрудники</h3><div className="card">{data.users.map((u: any) => <Link key={u.id} to={`/people/${u.id}`} className="fileRow"><Avatar name={u.name} src={u.avatar} size={44} userId={u.id} /><div style={{ minWidth: 0 }}><div className="row" style={{ gap: 8, flexWrap: 'wrap' }}><span className="bold">{u.name}</span>{u.is_head && <HeadBadge />}</div><div className="small muted">{u.job_title}{u.department ? ' · ' + u.department : ''}</div></div></Link>)}<SearchMore n={data.users.length} limit={LIMITS.users} to={`/people?q=${enc}`} label="Все сотрудники" /></div></section>}
          {data.departments.length > 0 && <section className="stackS sGroup"><h3>Подразделения</h3><div className="card">{data.departments.map((d: any) => <Link key={d.id} to={`/departments/${d.id}`} className="fileRow"><I.Building /><span className="bold">{d.name}</span></Link>)}<SearchMore n={data.departments.length} limit={LIMITS.departments} /></div></section>}
          {ideas.length > 0 && <section className="stackS sGroup"><h3>Идеи</h3><div className="card">{ideas.map((i: any) => <Link key={i.id} to={`/ideas/${i.id}`} className="fileRow"><I.Zap /><span className="bold sp">{i.title}</span></Link>)}<SearchMore n={ideas.length} limit={LIMITS.ideas} to={`/ideas?q=${enc}`} label="Все идеи" /></div></section>}
          {data.groups.length > 0 && <section className="stackS sGroup"><h3>Группы</h3><div className="card">{data.groups.map((g: any) => <Link key={g.id} to={`/groups/${g.id}`} className="fileRow"><I.Users /><span className="bold">{g.name}</span></Link>)}<SearchMore n={data.groups.length} limit={LIMITS.groups} to={`/groups?q=${enc}`} /></div></section>}
          {data.files.length > 0 && <section className="stackS sGroup"><h3>Файлы</h3><div className="card">{data.files.map((f: any) => <Link key={f.id} to={`/${f.kind}?folder=${f.folder_id}`} className="fileRow"><I.File /><div><div className="bold">{f.name}</div><div className="small muted">{f.folder}</div></div></Link>)}<SearchMore n={data.files.length} limit={LIMITS.files} /></div></section>}
          {data.wiki?.length > 0 && <section className="stackS sGroup"><h3>Базы знаний</h3><div className="card">{data.wiki.map((w: any) => <Link key={w.id} to={wikiLink(w)} className="fileRow"><span style={{ fontSize: 20 }}>{w.space_icon || '📘'}</span><div className="sp" style={{ minWidth: 0 }}><div className="bold">{w.title}</div><div className="small muted clamp2">{w.space_title} · <WikiSnippet text={w.snippet} /></div></div></Link>)}</div></section>}
          {data.file_content?.length > 0 && <FileHitsSection q={active} initial={data.file_content} limit={6} />}
        </>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- settings
const profileOf = (me: any) => ({
  last_name: me.last_name || '', first_name: me.first_name || '', middle_name: me.middle_name || '', job_title: me.job_title || '', extra_info: me.extra_info || '',
  email: me.email || '', phone1: me.phone1 ?? me.phone ?? '', phone2: me.phone2 || '', phone3: me.phone3 || '', phone4: me.phone4 || '',
  birthday: (me.birthday || '').slice(0, 10), avatar: me.avatar || '',
});

export function SettingsPage() {
  useTitle('Настройки');
  const me = useStore((s) => s.me)!;
  const [f, setF] = useState(() => profileOf(me));
  const [pw, setPw] = useState({ old: '', new: '' });
  const [busy, setBusy] = useState(false);
  const [pbusy, setPbusy] = useState(false);
  const [err, setErr] = useState('');
  const [perr, setPerr] = useState('');
  const set = (k: string, v: any) => setF((s) => ({ ...s, [k]: v }));
  const ldap = !!me.ldap;
  const lock = (k: 'first_name' | 'last_name') => ldap && { disabled: true };
  async function save() {
    setBusy(true); setErr('');
    try {
      const u = await api.put('/api/me', { ...f, settings: me.settings || {} });
      setState({ me: u }); setF(profileOf(u)); invalidate('user:');
      toast({ title: 'Профиль сохранён', kind: 'success' }, 2500);
    } catch (e) { setErr(errMsg(e)); }
    setBusy(false);
  }
  async function chpw() {
    setPbusy(true); setPerr('');
    try { await api.post('/api/me/password', pw); setPw({ old: '', new: '' }); toast({ title: 'Пароль изменён', kind: 'success' }, 2500); } catch (e) { setPerr(errMsg(e)); }
    setPbusy(false);
  }
  const ldapHint = ldap ? 'Управляется LDAP' : undefined;
  return (
    <div className="stack" style={{ maxWidth: 780 }}>
      <div className="pageH"><h1>Настройки</h1></div>
      <div className="card pad stack">
        <h3>Профиль</h3>
        {ldap && <div className="small muted"><Badge kind="accent">LDAP</Badge> Учётная запись управляется каталогом LDAP: фамилия и имя доступны только для чтения, а остальные поля, которые администратор привязал к каталогу, при сохранении будут возвращены к значениям из LDAP.</div>}
        <div className="row" style={{ flexWrap: 'wrap' }}><Avatar name={me.name} src={f.avatar} size={72} /><div className="sp" style={{ minWidth: 200 }}><ImageUpload avatar label="Аватар" value={f.avatar} onChange={(v) => set('avatar', v)} /></div></div>
        <div className="formGrid">
          <Field label="Фамилия" hint={ldapHint}><Input value={f.last_name} onChange={(e) => set('last_name', e.target.value)} {...lock('last_name')} /></Field>
          <Field label="Имя" hint={ldapHint}><Input value={f.first_name} onChange={(e) => set('first_name', e.target.value)} {...lock('first_name')} /></Field>
          <Field label="Отчество"><Input value={f.middle_name} onChange={(e) => set('middle_name', e.target.value)} /></Field>
          <Field label="Должность"><Input value={f.job_title} onChange={(e) => set('job_title', e.target.value)} /></Field>
          <Field label="Email"><Input type="email" value={f.email} onChange={(e) => set('email', e.target.value)} /></Field>
          <Field label="День рождения"><Input type="date" value={f.birthday} onChange={(e) => set('birthday', e.target.value)} /></Field>
          <Field label="Телефон 1"><Input type="tel" value={f.phone1} onChange={(e) => set('phone1', e.target.value)} /></Field>
          <Field label="Телефон 2"><Input type="tel" value={f.phone2} onChange={(e) => set('phone2', e.target.value)} /></Field>
          <Field label="Телефон 3"><Input type="tel" value={f.phone3} onChange={(e) => set('phone3', e.target.value)} /></Field>
          <Field label="Видеотелефон"><Input type="tel" value={f.phone4} onChange={(e) => set('phone4', e.target.value)} /></Field>
          <Field label="Дополнительная информация" className="full"><Textarea rows={3} maxLength={4000} value={f.extra_info} onChange={(e) => set('extra_info', e.target.value)} placeholder="Например: график работы, как быстрее связаться, зона ответственности" /></Field>
        </div>
        {me.is_head && <div className="small muted"><HeadBadge /> Вы отмечены как руководитель подразделения (отметку ставит администратор).</div>}
        {err && <div className="err">{err}</div>}
        <div><Btn kind="pri" busy={busy} onClick={save}>Сохранить</Btn></div>
      </div>
      <div className="card pad stack">
        <h3>Оформление</h3>
        <div className="chips">
          <ThemeChips />
        </div>
      </div>
      {!ldap && (
        <div className="card pad stack">
          <h3>Смена пароля</h3>
          <div className="formGrid">
            <Field label="Текущий пароль"><Input type="password" autoComplete="current-password" value={pw.old} onChange={(e) => setPw({ ...pw, old: e.target.value })} /></Field>
            <Field label="Новый пароль" hint="Не короче 8 символов"><Input type="password" autoComplete="new-password" value={pw.new} onChange={(e) => setPw({ ...pw, new: e.target.value })} /></Field>
          </div>
          {perr && <div className="err">{perr}</div>}
          <div><Btn busy={pbusy} disabled={!pw.old || pw.new.length < 8} onClick={chpw}>Изменить пароль</Btn></div>
        </div>
      )}
    </div>
  );
}
