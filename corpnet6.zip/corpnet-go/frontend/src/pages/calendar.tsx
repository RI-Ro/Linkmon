import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { Link, useSearchParams, useTitle } from '../lib/router';
import { useStore, toast } from '../lib/store';
import { usePersist } from '../lib/persist';
import { cx, sameDay, toLocalInput, fmtTime, fmtDate, plural, copyLink } from '../lib/util';
import { BookmarkButton } from '../ui/Bookmark';
import { AclEditor, Avatar, Badge, Btn, Check, Field, Input, Loading, Modal, Select, Switch, Textarea, UserPicker, UserLite, useConfirm, ErrorBox } from '../ui';
import './calendar.css';

type Freq = 'none' | 'daily' | 'weekly' | 'monthly' | 'yearly';
interface Ev {
  id: number; calendar_id: number; title: string; description: string; location: string; starts_at: string; ends_at: string; all_day: boolean;
  video_url: string; creator_id: number | null; calendar: string; color: string; kind: string; creator: string;
  attendees: { id: number; name: string; status: string }[];
  rec_freq: Freq; rec_interval: number; rec_until: string | null; base_starts_at: string;
  user_id: number | null; birthday: string | null; age: number | null; user_avatar: string | null;
}
interface Cal { id: number; name: string; description: string; kind: string; color: string; owner_id: number | null; visibility: string; open_add: boolean; level: number }

const DAY0 = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
const addDays = (d: Date, n: number) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const monday = (d: Date) => addDays(DAY0(d), -((d.getDay() + 6) % 7));
const DOW = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
const evKey = (e: Ev) => `${e.id}:${e.starts_at}`;
const isRec = (e: Ev) => !!e.rec_freq && e.rec_freq !== 'none';

type View = 'month' | 'week' | 'list';
type Period = '1m' | '3m' | 'year';
const PERIODS: { id: Period; label: string }[] = [{ id: '1m', label: 'Месяц' }, { id: '3m', label: '3 месяца' }, { id: 'year', label: 'Год' }];
const LIST_LIMIT = 1000;

const FREQ_LABEL: Record<Freq, string> = { none: 'Не повторять', daily: 'Каждый день', weekly: 'Каждую неделю', monthly: 'Каждый месяц', yearly: 'Каждый год' };
const FREQ_UNIT: Record<string, [string, string, string]> = { daily: ['день', 'дня', 'дней'], weekly: ['неделю', 'недели', 'недель'], monthly: ['месяц', 'месяца', 'месяцев'], yearly: ['год', 'года', 'лет'] };
const FREQ_ONE: Record<string, string> = { daily: 'Каждый день', weekly: 'Каждую неделю', monthly: 'Каждый месяц', yearly: 'Каждый год' };

function recText(e: Pick<Ev, 'rec_freq' | 'rec_interval' | 'rec_until'>): string {
  if (!e.rec_freq || e.rec_freq === 'none') return '';
  const n = e.rec_interval || 1;
  let t = n === 1 ? FREQ_ONE[e.rec_freq] : 'Раз в ' + plural(n, FREQ_UNIT[e.rec_freq]);
  if (e.rec_until) t += ', до ' + new Date(e.rec_until).toLocaleDateString('ru', { day: 'numeric', month: 'long', year: 'numeric' }).replace(/ г\.$/, '');
  return t;
}

const bdDate = (s?: string | null) => {
  if (!s) return '';
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString('ru', { day: 'numeric', month: 'long', year: 'numeric' }).replace(/ г\.$/, '');
};
function ageText(e: Ev): string {
  if (e.age == null) return '';
  const n = plural(e.age, ['год', 'года', 'лет']);
  return +DAY0(new Date(e.starts_at)) >= +DAY0(new Date()) ? `исполняется ${n}` : `исполнилось ${n}`;
}
const bdName = (e: Ev) => e.title.replace(/^День рождения:\s*/, '');
const timeLabel = (e: Ev) => {
  if (e.all_day) return 'Весь день';
  const s = new Date(e.starts_at), en = new Date(e.ends_at);
  return sameDay(s, en) ? `${fmtTime(s)}–${fmtTime(en)}` : fmtTime(s);
};

export function CalendarPage() {
  useTitle('Календарь');
  const [sp, setSp] = useSearchParams();
  const [view, setView] = usePersist<View>('cal.view', typeof innerWidth !== 'undefined' && innerWidth < 700 ? 'list' : 'month');
  const [period, setPeriod] = usePersist<Period>('cal.period', '1m');
  const [cursor, setCursor] = useState(() => DAY0(new Date()));
  const [hidden, setHidden] = usePersist<number[]>('cal.hidden', []);
  const [modal, setModal] = useState<null | { ev?: Ev; start?: Date; view?: boolean; day?: Date }>(null);
  const [calModal, setCalModal] = useState<null | { cal?: Cal }>(null);
  const [aclFor, setAclFor] = useState<number | null>(null);
  const cals = useQuery<Cal[]>('calendars', () => api.get('/api/calendars'), { stale: 60000 });

  const [from, to] = useMemo(() => {
    if (view === 'week') { const m = monday(cursor); return [m, addDays(m, 7)]; }
    const y = cursor.getFullYear(), mo = cursor.getMonth();
    if (view === 'list') {
      if (period === 'year') return [new Date(y, 0, 1), new Date(y + 1, 0, 1)];
      return [new Date(y, mo, 1), new Date(y, mo + (period === '3m' ? 3 : 1), 1)];
    }
    const m = monday(new Date(y, mo, 1));
    return [m, addDays(m, 42)];
  }, [view, period, cursor]);

  const shown = cals.data ? cals.data.filter((c) => !hidden.includes(c.id)).map((c) => c.id) : null;
  const allShown = !!cals.data && shown!.length === cals.data.length;
  const noneShown = !!cals.data && shown!.length === 0;
  const listQ = view === 'list' ? `&list=1${allShown || !shown ? '' : '&calendars=' + shown.join(',')}` : '';
  const key = view === 'list' && (!cals.data || noneShown) ? null : `events:${view === 'list' ? 'list' : 'grid'}:${from.toISOString()}:${to.toISOString()}:${listQ}`;
  const evq = useQuery<Ev[]>(key, () => api.get(`/api/events?from=${encodeURIComponent(from.toISOString())}&to=${encodeURIComponent(to.toISOString())}${listQ}`), { stale: 20000, keepPrevious: true });
  const events = (evq.data || []).filter((e) => !hidden.includes(e.calendar_id));

  // ссылка на событие: /calendar?event=ID[&date=YYYY-MM-DD] (id < 0 — виртуальный день рождения). Открывает карточку, даже если
  // событие вне видимого периода, повторяющееся или принадлежит скрытому календарю.
  const upcoming = useQuery<Ev[]>('rail:events', () => api.get('/api/events/upcoming'), { stale: 60000 });
  const wantId = /^-?\d+$/.test(sp.get('event') || '') ? +sp.get('event')! : 0;
  const wantDate = /^\d{4}-\d{2}-\d{2}$/.test(sp.get('date') || '') ? sp.get('date')! : '';
  const opened = useRef(0);
  const [missing, setMissing] = useState(0);
  useEffect(() => {
    if (!wantId) { opened.current = 0; setMissing(0); return; }
    if (wantDate) setCursor(DAY0(new Date(wantDate + 'T00:00:00')));
  }, [wantId, wantDate]);
  const pickOf = (list?: Ev[]) => {
    const m = (list || []).filter((x) => x.id === wantId);
    return (wantDate && m.find((x) => sameDay(new Date(x.starts_at), new Date(wantDate + 'T00:00:00')))) || m[0];
  };
  const inView = pickOf(evq.data) || (wantDate ? undefined : pickOf(upcoming.data));
  const mainDone = !!wantId && !inView && !evq.loading && !upcoming.loading && missing !== wantId;
  const wide = useQuery<Ev[]>(mainDone ? 'event:find:' + wantId : null, () => {
    const f = addDays(DAY0(new Date()), -90), t = addDays(f, 390);
    return api.get(`/api/events?from=${encodeURIComponent(f.toISOString())}&to=${encodeURIComponent(t.toISOString())}&list=1`);
  }, { stale: 30000 });
  useEffect(() => {
    if (!wantId || opened.current === wantId) return;
    const e = inView || (wide.data ? pickOf(wide.data) : undefined);
    if (e) { opened.current = wantId; setCursor(DAY0(new Date(e.starts_at))); setModal({ ev: e, view: true }); }
    else if (mainDone && wide.data) { setMissing(wantId); toast({ title: 'Событие не найдено или у вас нет к нему доступа', kind: 'error' }); setSp({ event: null, date: null }); }
  }, [wantId, evq.data, upcoming.data, wide.data, mainDone]); // eslint-disable-line

  const toggle = (id: number) => setHidden(hidden.includes(id) ? hidden.filter((x) => x !== id) : [...hidden, id]);
  const only = (id: number) => setHidden((cals.data || []).filter((c) => c.id !== id).map((c) => c.id));
  const showAll = () => setHidden([]);
  const setV = setView;
  const setP = setPeriod;
  const step = view === 'week' ? 0 : view === 'list' ? (period === 'year' ? 12 : period === '3m' ? 3 : 1) : 1;
  const nav = (d: number) => setCursor(view === 'week' ? addDays(cursor, 7 * d) : new Date(cursor.getFullYear(), cursor.getMonth() + step * d, 1));
  const mon = (d: Date, o: Intl.DateTimeFormatOptions) => d.toLocaleDateString('ru', o).replace(' г.', '');
  const last = addDays(to, -1);
  const title = view === 'week'
    ? `${from.toLocaleDateString('ru', { day: 'numeric', month: 'short' })} — ${last.toLocaleDateString('ru', { day: 'numeric', month: 'short', year: 'numeric' })}`
    : view === 'list' && period === 'year' ? String(from.getFullYear())
    : view === 'list' && period === '3m' ? `${mon(from, { month: 'long' })} — ${mon(last, { month: 'long', year: 'numeric' })}`
    : mon(cursor, { month: 'long', year: 'numeric' });
  const writable = (cals.data || []).filter((c) => c.level >= 2 && c.kind !== 'birthdays');
  const closeModal = () => { setModal(null); if (sp.get('event')) setSp({ event: null, date: null }); };
  const openNew = (d: Date) => writable.length && setModal({ start: d });
  const pick = (e: Ev) => setModal({ ev: e, view: true });
  const truncated = view === 'list' && (evq.data?.length || 0) >= LIST_LIMIT;

  return (
    <div className="stack">
      <div className="pageH"><h1>Календарь</h1><div className="sp" />
        {writable.length > 0 && <Btn kind="pri" onClick={() => setModal({ start: new Date() })}><I.Plus size={18} /> Событие</Btn>}
      </div>
      <div className="calLayout">
        <div className="card padS stackS">
          <div className="row"><b className="sp">Календари</b><Btn size="sm" kind="ghost" icon title="Новый календарь" onClick={() => setCalModal({})}><I.Plus size={16} /></Btn></div>
          {!cals.data ? <Loading /> : cals.data.map((c) => (
            <div key={c.id} className={cx('calItem', hidden.includes(c.id) && 'off')} style={{ '--c': c.color } as any}>
              <button className="sw" style={{ border: 0, cursor: 'pointer' }} onClick={() => toggle(c.id)} aria-label={'Показать/скрыть ' + c.name} />
              <div className="sp clip small" title={c.description} style={{ cursor: 'pointer' }} onDoubleClick={() => only(c.id)}>{c.name}{c.kind === 'personal' && <span className="tiny faint"> · только вы</span>}</div>
              {c.level >= 4 && c.kind !== 'birthdays' && <>{c.kind !== 'personal' && <button className="btn ghost sm icon" style={{ width: 26, height: 26 }} title="Права доступа" onClick={() => setAclFor(c.id)}><I.Lock size={13} /></button>}{(c.kind === 'custom' || c.kind === 'personal') && <button className="btn ghost sm icon" style={{ width: 26, height: 26 }} title="Настройки календаря" onClick={() => setCalModal({ cal: c })}><I.Edit size={13} /></button>}</>}
            </div>
          ))}
          {cals.data && hidden.length > 0 && <button className="btn sm ghost" onClick={showAll}>Показать все</button>}
          {cals.data && <div className="tiny faint">Двойной щелчок по названию — показать только этот календарь</div>}
        </div>
        <div className="card" style={{ overflow: 'hidden' }}>
          <div className="calHead">
            <Btn size="sm" onClick={() => setCursor(DAY0(new Date()))}>Сегодня</Btn>
            <Btn size="sm" icon kind="ghost" onClick={() => nav(-1)} aria-label="Назад"><I.ChevronLeft /></Btn>
            <Btn size="sm" icon kind="ghost" onClick={() => nav(1)} aria-label="Вперёд"><I.ChevronRight /></Btn>
            <h2 className="sp">{title}</h2>
            {evq.loading && <span className="spin muted" />}
            <div className="chips">
              <button className={cx('chip', view === 'month' && 'on')} onClick={() => setV('month')}>Месяц</button>
              <button className={cx('chip', view === 'week' && 'on')} onClick={() => setV('week')}>Неделя</button>
              <button className={cx('chip', view === 'list' && 'on')} onClick={() => setV('list')}><I.List size={14} /> Список</button>
            </div>
          </div>
          {view === 'list' && (
            <div className="calTools">
              <span className="small muted">Период:</span>
              <Select value={period} onChange={(e) => setP(e.target.value as Period)} aria-label="Период списка">{PERIODS.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}</Select>
              <span className="note">{noneShown ? 'Все календари скрыты' : evq.data ? `Событий: ${events.length}` : ''}</span>
            </div>
          )}
          {truncated && <div className="calTools"><span className="note" style={{ color: 'var(--warn)' }}>Показаны первые {LIST_LIMIT} событий — выберите период покороче или скройте часть календарей.</span></div>}
          {evq.error && !evq.data ? <ErrorBox error={evq.error} retry={evq.refetch} /> : view === 'month'
            ? <MonthGrid from={from} cursor={cursor} events={events} onPick={pick} onDay={(d) => openNew(d)} onMore={(d) => setModal({ day: d })} />
            : view === 'week' ? <WeekGrid from={from} events={events} onPick={pick} onSlot={openNew} />
            : !cals.data || (evq.loading && !evq.data) ? <Loading /> : <EventList from={from} to={to} events={events} onPick={pick} />}
        </div>
      </div>
      {modal && (modal.day ? <DayModal day={modal.day} events={events} onPick={pick} onClose={closeModal} />
        : modal.view && modal.ev ? <EventView ev={modal.ev} cals={cals.data || []} onClose={closeModal} onEdit={() => setModal({ ev: modal.ev })} />
        : <EventForm ev={modal.ev} start={modal.start} cals={writable} onClose={closeModal} />)}
      {calModal && <CalModal cal={calModal.cal} onClose={() => setCalModal(null)} />}
      {aclFor && <AclEditor type="calendar" id={aclFor} onClose={() => { setAclFor(null); invalidate('calendars'); }} />}
    </div>
  );
}

const dayEvents = (events: Ev[], d: Date) => {
  const next = addDays(d, 1);
  return events.filter((e) => new Date(e.starts_at) < next && new Date(e.ends_at) >= d && !(new Date(e.ends_at).getTime() === d.getTime() && new Date(e.starts_at) < d))
    .sort((a, b) => +new Date(a.starts_at) - +new Date(b.starts_at) || (a.all_day === b.all_day ? 0 : a.all_day ? -1 : 1));
};

function EvIcons({ e }: { e: Ev }) {
  return <>{e.kind === 'birthdays' && <I.Cake size={11} />}{isRec(e) && <span className="rep" title={recText(e)}><I.Refresh size={11} /></span>}</>;
}

function MonthGrid({ from, cursor, events, onPick, onDay, onMore }: { from: Date; cursor: Date; events: Ev[]; onPick: (e: Ev) => void; onDay: (d: Date) => void; onMore: (d: Date) => void }) {
  const today = new Date();
  const days = Array.from({ length: 42 }, (_, i) => addDays(from, i));
  return (
    <div className="month">
      {DOW.map((d) => <div key={d} className="dow">{d}</div>)}
      {days.map((d) => {
        const evs = dayEvents(events, d);
        return (
          <div key={+d} className={cx('mcell', d.getMonth() !== cursor.getMonth() && 'off', sameDay(d, today) && 'today')} onClick={() => onDay(new Date(d.getFullYear(), d.getMonth(), d.getDate(), 10))}>
            <div className="dn">{d.getDate()}</div>
            {evs.slice(0, 3).map((e) => <button key={evKey(e)} className="ev" style={{ '--c': e.color } as any} onClick={(ev) => { ev.stopPropagation(); onPick(e); }} title={e.title}>{!e.all_day && <b>{fmtTime(e.starts_at)}</b>}<EvIcons e={e} />{e.kind === 'birthdays' ? bdName(e) : e.title}</button>)}
            {evs.length > 3 && <button className="more" style={{ border: 0, background: 'none', textAlign: 'left' }} onClick={(ev) => { ev.stopPropagation(); onMore(d); }}>ещё {evs.length - 3}</button>}
          </div>
        );
      })}
    </div>
  );
}

function WeekGrid({ from, events, onPick, onSlot }: { from: Date; events: Ev[]; onPick: (e: Ev) => void; onSlot: (d: Date) => void }) {
  const today = new Date();
  const days = Array.from({ length: 7 }, (_, i) => addDays(from, i));
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => { if (ref.current) ref.current.scrollTop = 52 * 7.5; }, []);
  const allDay = (d: Date) => dayEvents(events, d).filter((e) => e.all_day);
  return (
    <div className="week" ref={ref}>
      <div className="hdrc" />
      {days.map((d) => {
        const ad = allDay(d);
        return (
          <div key={+d} className={cx('hdrc', sameDay(d, today) && 'today')}>
            <span className="muted tiny">{DOW[(d.getDay() + 6) % 7]}</span><b>{d.getDate()}</b>
            {ad.slice(0, 2).map((e) => <button key={evKey(e)} className="ev" style={{ '--c': e.color, marginTop: 2 } as any} onClick={() => onPick(e)} title={e.title}><EvIcons e={e} />{e.kind === 'birthdays' ? bdName(e) : e.title}</button>)}
            {ad.length > 2 && <div className="more">ещё {ad.length - 2}</div>}
          </div>
        );
      })}
      <div>{Array.from({ length: 24 }, (_, h) => <div key={h} className="hr">{String(h).padStart(2, '0')}:00</div>)}</div>
      {days.map((d) => {
        const evs = events.filter((e) => !e.all_day && sameDay(new Date(e.starts_at), d)).sort((a, b) => +new Date(a.starts_at) - +new Date(b.starts_at));
        // greedy lane assignment so concurrent events sit side by side
        const lanes: number[] = [];
        const placed = evs.map((e) => {
          const s = +new Date(e.starts_at);
          let l = lanes.findIndex((end) => end <= s);
          if (l < 0) l = lanes.length;
          lanes[l] = +new Date(e.ends_at);
          return { e, l };
        });
        const n = Math.max(1, lanes.length);
        return (
          <div key={+d} className="col">
            {Array.from({ length: 24 }, (_, h) => <div key={h} className="slot" onClick={() => onSlot(new Date(d.getFullYear(), d.getMonth(), d.getDate(), h))} />)}
            {placed.map(({ e, l }) => {
              const s = new Date(e.starts_at), en = new Date(e.ends_at);
              const top = (s.getHours() + s.getMinutes() / 60) * 52;
              const h = Math.max(22, ((+en - +s) / 3600000) * 52 - 2);
              return <button key={evKey(e)} className="evb" style={{ '--c': e.color, top, height: h, left: `calc(${(l / n) * 100}% + 2px)`, width: `calc(${100 / n}% - 4px)`, right: 'auto' } as any} onClick={() => onPick(e)}><b>{fmtTime(e.starts_at)}</b> <EvIcons e={e} />{e.title}</button>;
            })}
          </div>
        );
      })}
    </div>
  );
}

function EvRow({ e, onPick, showDate }: { e: Ev; onPick: (e: Ev) => void; showDate?: boolean }) {
  if (e.kind === 'birthdays' && e.user_id) {
    return (
      <div className="evRow bd" role="button" tabIndex={0} style={{ '--c': e.color } as any} onClick={() => onPick(e)} onKeyDown={(k) => k.key === 'Enter' && onPick(e)}>
        <Avatar name={bdName(e)} src={e.user_avatar || undefined} size={36} userId={e.user_id} />
        <div style={{ minWidth: 0 }}>
          <div className="ttl"><I.Cake size={15} /><Link to={`/people/${e.user_id}`} onClick={(k) => k.stopPropagation()} className="bold">{bdName(e)}</Link><span className="calTag">{e.calendar}</span></div>
          <div className="sub"><span>Дата рождения: {bdDate(e.birthday)}</span>{e.age != null && <span>· {ageText(e)}</span>}</div>
        </div>
      </div>
    );
  }
  const multi = !sameDay(new Date(e.starts_at), new Date(e.ends_at)) && new Date(e.ends_at) > new Date(e.starts_at);
  return (
    <button className="evRow" style={{ '--c': e.color } as any} onClick={() => onPick(e)}>
      <div className="tm">{timeLabel(e)}{showDate && <div className="tiny faint">{new Date(e.starts_at).toLocaleDateString('ru', { day: 'numeric', month: 'short' })}</div>}</div>
      <div style={{ minWidth: 0 }}>
        <div className="ttl">{e.title}{isRec(e) && <span className="rep" title={recText(e)}><I.Refresh size={14} /></span>}<span className="calTag">{e.calendar}</span></div>
        {(e.location || multi || isRec(e)) && <div className="sub">
          {e.location && <span><I.Pin size={13} />{e.location}</span>}
          {multi && <span><I.Clock size={13} />до {new Date(e.ends_at).toLocaleDateString('ru', { day: 'numeric', month: 'short' })}{e.all_day ? '' : ', ' + fmtTime(e.ends_at)}</span>}
          {isRec(e) && <span><I.Refresh size={13} />{recText(e)}</span>}
        </div>}
      </div>
    </button>
  );
}

function EventList({ from, to, events, onPick }: { from: Date; to: Date; events: Ev[]; onPick: (e: Ev) => void }) {
  const groups = useMemo(() => {
    const m = new Map<number, Ev[]>();
    for (const e of events) {
      let d = DAY0(new Date(e.starts_at));
      if (+d < +from) d = from;
      m.set(+d, [...(m.get(+d) || []), e]);
    }
    return [...m.entries()].sort((a, b) => a[0] - b[0]);
  }, [events, from, to]);
  const today = DAY0(new Date());
  if (!groups.length) return <div className="empty" style={{ padding: 40 }}><I.Calendar size={42} />В выбранном периоде событий нет</div>;
  return (
    <div className="evList">
      {groups.map(([t, evs]) => {
        const d = new Date(t);
        const isToday = sameDay(d, today);
        return (
          <section key={t} className={cx('evDay', isToday && 'today', +d < +today && 'past')}>
            <div className="dh"><b>{d.getDate()}</b><span>{d.toLocaleDateString('ru', { month: 'short' }).replace('.', '')}, {d.toLocaleDateString('ru', { weekday: 'short' })}{isToday ? ' · сегодня' : ''}</span></div>
            <div className="rows">{evs.sort((a, b) => (a.all_day === b.all_day ? +new Date(a.starts_at) - +new Date(b.starts_at) : a.all_day ? -1 : 1)).map((e) => <EvRow key={evKey(e)} e={e} onPick={onPick} />)}</div>
          </section>
        );
      })}
    </div>
  );
}

function DayModal({ day, events, onPick, onClose }: { day: Date; events: Ev[]; onPick: (e: Ev) => void; onClose: () => void }) {
  const evs = dayEvents(events, day);
  return (
    <Modal title={day.toLocaleDateString('ru', { weekday: 'long', day: 'numeric', month: 'long' })} onClose={onClose}>
      <div className="dayModalList">{evs.length ? evs.map((e) => <EvRow key={evKey(e)} e={e} onPick={onPick} />) : <div className="muted">Событий нет</div>}</div>
    </Modal>
  );
}

function EventView({ ev, cals, onClose, onEdit }: { ev: Ev; cals: Cal[]; onClose: () => void; onEdit: () => void }) {
  const me = useStore((s) => s.me)!;
  const cal = cals.find((c) => c.id === ev.calendar_id);
  const virtual = ev.id < 0;
  const can = !virtual && cal && (cal.level >= 3 || (ev.creator_id === me.id && cal.level >= 2));
  const [confirm, node] = useConfirm();
  const s = new Date(ev.starts_at), e = new Date(ev.ends_at);
  const rec = recText(ev);
  const day = `${s.getFullYear()}-${String(s.getMonth() + 1).padStart(2, '0')}-${String(s.getDate()).padStart(2, '0')}`;
  const share = <button type="button" className="btn ghost sm" style={{ justifySelf: 'start' }} onClick={() => copyLink(`/calendar?event=${ev.id}&date=${day}`)}><I.Share size={15} /> Скопировать ссылку</button>;
  const del = async () => {
    if (await confirm(isRec(ev) ? 'Удалить всё повторяющееся событие?' : 'Удалить событие?', { text: isRec(ev) ? 'Будут удалены все повторения серии.' : undefined, ok: 'Удалить' })) {
      try { await api.del('/api/events/' + ev.id); invalidate('events'); invalidate('rail:'); onClose(); } catch (er) { toast({ title: errMsg(er), kind: 'error' }); }
    }
  };
  if (ev.kind === 'birthdays' && ev.user_id) {
    return (
      <Modal title="День рождения" onClose={onClose}>
        <div className="bdCard">
          <Avatar name={bdName(ev)} src={ev.user_avatar || undefined} size={64} userId={ev.user_id} />
          <div>
            <Link to={`/people/${ev.user_id}`} className="big" onClick={onClose}>{bdName(ev)}</Link>
            {ev.description && <div className="small muted">{ev.description}</div>}
          </div>
        </div>
        <div className="row"><I.Cake size={18} className="muted" /><div>Дата рождения: <b>{bdDate(ev.birthday)}</b></div></div>
        <div className="row"><I.Calendar size={18} className="muted" /><div>{s.toLocaleDateString('ru', { day: 'numeric', month: 'long', year: 'numeric', weekday: 'long' }).replace(/ г\.$/, '')}{ev.age != null && <> — <b>{ageText(ev)}</b></>}</div></div>
        <div className="row" style={{ gap: 8 }}><span className="badge" style={{ background: ev.color + '26', color: ev.color }}>{ev.calendar}</span></div>
        <Link to={`/people/${ev.user_id}`} className="btn" onClick={onClose}>Открыть страницу сотрудника</Link>
        {share}
      </Modal>
    );
  }
  return (
    <Modal title={ev.title} onClose={onClose} footer={can ? <><Btn kind="dng" onClick={del}><I.Trash size={16} /> Удалить</Btn><div className="sp" /><Btn kind="pri" onClick={onEdit}><I.Edit size={16} /> Изменить</Btn></> : undefined}>
      <div className="row" style={{ gap: 8 }}><span className="badge" style={{ background: ev.color + '26', color: ev.color }}>{ev.calendar}</span>{rec && <Badge kind="accent"><I.Refresh size={12} /> повторяется</Badge>}<div className="sp" /><BookmarkButton type="event" id={ev.id} label /></div>
      <div className="row"><I.Clock size={18} className="muted" /><div>{ev.all_day ? (sameDay(s, e) ? s.toLocaleDateString('ru', { day: 'numeric', month: 'long', weekday: 'long' }) : `${s.toLocaleDateString('ru', { day: 'numeric', month: 'long' })} — ${e.toLocaleDateString('ru', { day: 'numeric', month: 'long' })}`) : <>{fmtDate(ev.starts_at)} — {sameDay(s, e) ? fmtTime(ev.ends_at) : fmtDate(ev.ends_at)}</>}</div></div>
      {rec && <div className="row"><I.Refresh size={18} className="muted" /><div>{rec}</div></div>}
      {ev.location && <div className="row"><I.Pin size={18} className="muted" />{ev.location}</div>}
      {ev.description && <p className="muted" style={{ whiteSpace: 'pre-wrap' }}>{ev.description}</p>}
      {ev.creator && <div className="small muted">Организатор: {ev.creator}</div>}
      {share}
      {ev.attendees.length > 0 && <div className="stackS"><div className="lbl">Участники · {ev.attendees.length}</div><div className="tokens">{ev.attendees.map((a) => <Link key={a.id} to={`/people/${a.id}`} className="token" onClick={onClose}><Avatar name={a.name} size={22} />{a.name}</Link>)}</div></div>}
      {node}
    </Modal>
  );
}

function EventForm({ ev, start, cals, onClose }: { ev?: Ev; start?: Date; cals: Cal[]; onClose: () => void }) {
  // an occurrence of a recurring event edits the whole series, so the form works with the series' first occurrence
  const base = ev ? new Date(ev.base_starts_at || ev.starts_at) : null;
  const dur = ev ? +new Date(ev.ends_at) - +new Date(ev.starts_at) : 3600000;
  const s0 = base || start || new Date();
  const e0 = new Date(+s0 + dur);
  const [f, setF] = useState({
    title: ev?.title || '', description: ev?.description || '', location: ev?.location || '', calendar_id: ev?.calendar_id || cals[0]?.id,
    all_day: ev?.all_day || false, starts: toLocalInput(s0), ends: toLocalInput(e0),
    freq: (ev?.rec_freq || 'none') as Freq, interval: String(ev?.rec_interval || 1), until: ev?.rec_until ? toLocalInput(new Date(ev.rec_until)).slice(0, 10) : '',
  });
  const [att, setAtt] = useState<UserLite[]>((ev?.attendees || []).map((a) => ({ id: a.id, name: a.name })));
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const set = (k: string, v: any) => setF((x) => ({ ...x, [k]: v }));
  const n = Math.min(100, Math.max(1, parseInt(f.interval) || 1));
  async function save() {
    setBusy(true); setErr('');
    try {
      let st = new Date(f.starts), en = new Date(f.ends);
      if (f.all_day) { st = new Date(f.starts.slice(0, 10) + 'T00:00'); en = new Date(f.ends.slice(0, 10) + 'T23:59'); }
      if (isNaN(+st) || isNaN(+en)) throw new Error('Укажите дату начала и окончания');
      if (en < st) throw new Error('Окончание не может быть раньше начала');
      const rec = f.freq !== 'none';
      const body = {
        calendar_id: +f.calendar_id, title: f.title, description: f.description, location: f.location, starts_at: st.toISOString(), ends_at: en.toISOString(), all_day: f.all_day,
        video: false, video_url: ev?.video_url || '', attendee_ids: att.map((a) => a.id),
        rec_freq: f.freq, rec_interval: rec ? n : 1, rec_until: rec && f.until ? new Date(f.until + 'T23:59:59').toISOString() : '',
      };
      if (ev) await api.put('/api/events/' + ev.id, body); else await api.post('/api/events', body);
      invalidate('events'); invalidate('rail:');
      onClose();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title={ev ? (isRec(ev) ? 'Изменить серию событий' : 'Изменить событие') : 'Новое событие'} size="lg" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={!f.title.trim()} onClick={save}>Сохранить</Btn></>}>
      {ev && isRec(ev) && <div className="recNote"><I.Refresh size={16} />Это повторяющееся событие: изменения применятся ко всей серии.</div>}
      <Field label="Название"><Input value={f.title} onChange={(e) => set('title', e.target.value)} maxLength={200} /></Field>
      <div className="formGrid">
        <Field label="Календарь"><Select value={f.calendar_id} onChange={(e) => set('calendar_id', e.target.value)}>{cals.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select></Field>
        <Field label="Место"><Input value={f.location} onChange={(e) => set('location', e.target.value)} placeholder="Офис, адрес или ссылка" /></Field>
        <Field label={ev && isRec(ev) ? 'Начало серии' : 'Начало'}><Input type={f.all_day ? 'date' : 'datetime-local'} value={f.all_day ? f.starts.slice(0, 10) : f.starts} onChange={(e) => set('starts', e.target.value)} /></Field>
        <Field label="Окончание"><Input type={f.all_day ? 'date' : 'datetime-local'} value={f.all_day ? f.ends.slice(0, 10) : f.ends} onChange={(e) => set('ends', e.target.value)} /></Field>
      </div>
      <Switch checked={f.all_day} onChange={(v) => set('all_day', v)} label="Весь день" />
      <div className="recBox">
        <div className="rec3">
          <Field label="Повторение"><Select value={f.freq} onChange={(e) => set('freq', e.target.value)}>{(Object.keys(FREQ_LABEL) as Freq[]).map((k) => <option key={k} value={k}>{FREQ_LABEL[k]}</option>)}</Select></Field>
          {f.freq !== 'none' && <Field label="Шаг" hint={n === 1 ? undefined : 'Раз в ' + plural(n, FREQ_UNIT[f.freq])}><Input type="number" min={1} max={100} value={f.interval} onChange={(e) => set('interval', e.target.value)} /></Field>}
          {f.freq !== 'none' && <Field label="Повторять до" hint="Не заполняйте — без ограничения"><Input type="date" value={f.until} min={f.starts.slice(0, 10)} onChange={(e) => set('until', e.target.value)} /></Field>}
        </div>
        {f.freq === 'none' && <div className="hint">Для праздников и годовщин (День города, День Победы) выберите «Каждый год», для регулярных встреч — «Каждую неделю» или «Каждый месяц».</div>}
        {f.freq !== 'none' && <div className="hint">{recText({ rec_freq: f.freq, rec_interval: n, rec_until: f.until ? new Date(f.until + 'T23:59:59').toISOString() : null })}</div>}
      </div>
      <Field label="Описание"><Textarea rows={3} value={f.description} onChange={(e) => set('description', e.target.value)} /></Field>
      <Field label="Участники" hint="Приглашённые получат уведомление"><UserPicker value={att} onChange={setAtt} /></Field>
      {err && <div className="err">{err}</div>}
    </Modal>
  );
}

function CalModal({ cal, onClose }: { cal?: Cal; onClose: () => void }) {
  const personal = cal?.kind === 'personal';
  const [f, setF] = useState({ name: cal?.name || '', description: cal?.description || '', color: cal?.color || '#286b9e', visibility: cal?.visibility || 'restricted', open_add: cal?.open_add || false });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [confirm, node] = useConfirm();
  async function save() {
    setBusy(true);
    try { if (cal) await api.put('/api/calendars/' + cal.id, f); else await api.post('/api/calendars', f); invalidate('calendars'); onClose(); } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title={cal ? 'Настройки календаря' : 'Новый календарь'} onClose={onClose} footer={<>{cal && cal.kind === 'custom' && <Btn kind="dng" onClick={async () => { if (await confirm('Удалить календарь вместе с событиями?', { ok: 'Удалить' })) { try { await api.del('/api/calendars/' + cal.id); invalidate('calendars'); invalidate('events'); onClose(); } catch (e) { setErr(errMsg(e)); } } }}>Удалить</Btn>}<div className="sp" /><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={!f.name.trim()} onClick={save}>Сохранить</Btn></>}>
      <Field label="Название"><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
      <Field label="Описание"><Input value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
      <div className="formGrid">
        <Field label="Цвет"><input type="color" className="inp" style={{ padding: 4, height: 42 }} value={f.color} onChange={(e) => setF({ ...f, color: e.target.value })} /></Field>
        {!personal && <Field label="Видимость"><Select value={f.visibility} onChange={(e) => setF({ ...f, visibility: e.target.value })}><option value="restricted">Только по приглашению</option><option value="company">Вся компания</option></Select></Field>}
      </div>
      {personal ? <div className="hint">Личный календарь виден только вам.</div> : (
        <>
          <Check checked={f.open_add} onChange={(v) => setF({ ...f, open_add: v })} label="Все, кто видит календарь, могут добавлять события" />
          <div className="hint">Конкретным людям и подразделениям можно выдать доступ кнопкой «замок» рядом с календарём.</div>
        </>
      )}
      {err && <div className="err">{err}</div>}
      {node}
    </Modal>
  );
}
