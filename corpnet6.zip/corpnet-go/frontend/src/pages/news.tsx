import React, { useCallback, useEffect, useRef, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate, updateQueries, prefetch } from '../lib/query';
import { usePersist } from '../lib/persist';
import { Link, navigate, pageHref, useSearchParams, useTitle } from '../lib/router';
import { useStore, isEditor, isAdmin, toast } from '../lib/store';
import { cx, fmtDate, thumb, view, copyText, toLocalInput, useDebounced } from '../lib/util';
import { Markdown } from '../lib/markdown';
import { Avatar, Badge, Btn, Empty, ErrorBox, Field, FileLink, Img, ImageUpload, Input, Loading, Pager, Select, Skel, Switch, Textarea, useConfirm } from '../ui';
import { Comments } from '../ui/Comments';
import { Reactions, type Rx } from '../ui/Reactions';
import { BookmarkButton } from '../ui/Bookmark';
import { Banners } from '../ui/Banners';
import { DeptSelect, useDepartments } from '../ui/DeptSelect';
import { DirSelect } from '../ui/DirSelect';
import { MdEditor } from '../ui/MdEditor';
import { GalleryPreview, type NewsGallery } from '../ui/GalleryPreview';
import { useRealtime } from '../lib/ws';

export interface News {
  id: number; title: string; summary: string; cover: string; important: boolean; pinned: boolean; status: string; hidden?: boolean; published_at: string; visible_until?: string | null;
  likes_count: number; comments_count: number; views_count: number; category_id: number | null; category: string | null; category_color: string | null;
  author_id: number; author: string; author_avatar: string; author_title: string; department_id: number | null; department: string | null; direction_id: number | null;
  cur?: string;
  body?: string; liked?: boolean; attachments?: any[]; galleries?: NewsGallery[]; gallery_refs?: { folder_id: number; title: string; kind: 'photos' | 'videos'; folder_name: string }[];
  can_edit?: boolean; live?: boolean; reactions?: Rx[]; bookmarked?: boolean;
}

export function NewsCard({ n, liked }: { n: News; liked?: boolean }) {
  return (
    <Link to={`/news/${n.id}`} className="card ncard">
      <div className="cv">
        <Img src={thumb(n.cover)} alt="" />
        {n.category && <Badge kind="accent">{n.category}</Badge>}
      </div>
      <div className="bd">
        <div className="row" style={{ gap: 8 }}>
          {n.important && <Badge kind="warn"><I.Zap size={12} /> Важное</Badge>}
          {n.pinned && <Badge><I.Pin size={12} /> Закреплено</Badge>}
          {n.status === 'draft' && <Badge kind="dng">Черновик</Badge>}
        </div>
        <h3 className="clamp2">{n.title}</h3>
        {n.summary && <p className="muted small clamp3">{n.summary}</p>}
      </div>
      <div className="ft">
        <Avatar name={n.author} src={n.author_avatar} size={24} />
        <span className="clip" style={{ flex: 1 }}>{n.author}</span>
        <span title="Лайки" style={liked ? { color: 'var(--danger)' } : undefined}><I.Heart size={15} />{n.likes_count}</span>
        <span title="Комментарии"><I.Comment size={15} />{n.comments_count}</span>
      </div>
    </Link>
  );
}

function Hero({ items }: { items: News[] }) {
  const [a, b, c] = items;
  const tile = (n: News, big?: boolean) => (
    <Link to={`/news/${n.id}`} className="heroMain" key={n.id}>
      <Img src={big ? view(n.cover) : thumb(n.cover)} eager={big} />
      <div className="heroTxt">
        <div className="row" style={{ gap: 8 }}>
          {n.category && <Badge kind="accent">{n.category}</Badge>}
          <Badge kind="warn"><I.Zap size={12} /> Важное</Badge>
        </div>
        <h2 className="clamp3">{n.title}</h2>
        {big && n.summary && <p className="clamp2">{n.summary}</p>}
        <div className="row small" style={{ color: 'rgba(255,255,255,.8)' }}>{n.author} · {fmtDate(n.published_at)}</div>
      </div>
    </Link>
  );
  return <div className="hero">{tile(a, true)}{(b || c) && <div className="heroSide">{b && tile(b)}{c && tile(c)}</div>}</div>;
}

// ---------------------------------------------------------------- feed
const PER = 10;
interface Feed { items: News[]; pinned: News[]; has_more: boolean; liked: number[]; page?: number; per?: number; total?: number; pages?: number; total_capped?: boolean }
const FILTER_KEYS = ['category', 'important', 'department', 'direction'] as const;

export function NewsList() {
  useTitle('Новости');
  const me = useStore((s) => s.me)!;
  const cats = useStore((s) => s.categories);
  const [sp, setSp] = useSearchParams();
  // все фильтры и номер страницы живут в URL: ссылка воспроизводит то же состояние
  const cat = sp.get('category') || '', imp = sp.get('important') === '1', dept = sp.get('department') || '', dir = sp.get('direction') || '';
  const urlQ = sp.get('q') || '';
  const page = Math.max(1, parseInt(sp.get('page') || '1', 10) || 1);
  const [q, setQ] = useState(urlQ);
  const dq = useDebounced(q, 400);
  useEffect(() => { if (dq.trim() !== urlQ) setSp({ q: dq.trim() || null, page: null }); }, [dq]); // eslint-disable-line
  useEffect(() => { setQ(urlQ); }, [urlQ]);

  // последние выбранные фильтры запоминаются для пользователя и применяются, если открыть ленту без параметров
  const [saved, setSaved] = usePersist<Record<string, string>>('news.filters', {});
  useEffect(() => {
    if (!location.search && Object.keys(saved).length) setSp({ ...saved, page: null }, true);
  }, []); // eslint-disable-line
  const setFilter = (patch: Record<string, string | number | null>) => {
    const next: Record<string, string> = { category: cat, important: imp ? '1' : '', department: dept, direction: dir };
    for (const k of FILTER_KEYS) if (k in patch) next[k] = patch[k] == null ? '' : String(patch[k]);
    setSaved(Object.fromEntries(Object.entries(next).filter(([, v]) => v)));
    setSp({ ...patch, page: null });
  };

  const baseQs = (p: number) => {
    const qs = new URLSearchParams({ per: String(PER), page: String(p) });
    if (cat) qs.set('category', cat);
    if (imp) qs.set('important', '1');
    if (dept) qs.set('department', dept);
    if (dir) qs.set('direction', dir);
    if (urlQ) qs.set('q', urlQ);
    return qs.toString();
  };
  const key = 'news:feed:' + baseQs(page);
  const first = useQuery<Feed>(key, () => api.get('/api/news?' + baseQs(page)), { stale: 20000, keepPrevious: true });
  const data = first.data;
  const filtered = !!(cat || imp || dept || dir || urlQ);
  // важные новости (общий кэш с правой колонкой)
  const hot = useQuery<{ items: News[] }>('rail:important', () => api.get('/api/news?important=1&per=4'), { stale: 60000 });

  // старый бэкенд без постраничного режима: нет total — работаем курсором, «Далее» подгружает следующую порцию
  const legacy = !!data && data.total === undefined;
  const [extra, setExtra] = useState<News[]>([]);
  const [extraMore, setExtraMore] = useState<boolean | null>(null);
  const [moreBusy, setMoreBusy] = useState(false);
  const [moreErr, setMoreErr] = useState('');
  useEffect(() => { setExtra([]); setExtraMore(null); setMoreErr(''); }, [key]);
  const items = data?.items || [];
  const lastCur = [...items, ...extra].at(-1)?.cur;
  async function loadMore() {
    if (moreBusy || !lastCur) return;
    setMoreBusy(true); setMoreErr('');
    try {
      const r = await api.get<Feed>(`/api/news?${baseQs(1)}&cursor=${encodeURIComponent(lastCur)}`);
      setExtra((e) => [...e, ...r.items.filter((x) => !e.some((y) => y.id === x.id))]);
      setExtraMore(r.has_more);
    } catch (e) { setMoreErr(errMsg(e)); }
    setMoreBusy(false);
  }

  // страница вне диапазона → последняя (или первая, если новостей нет)
  useEffect(() => {
    if (!data || legacy || first.loading || data.page !== page) return;
    const pages = Math.max(1, data.pages || 1);
    if (page > pages) setSp({ page: pages > 1 ? pages : null }, true);
  }, [data, page, legacy, first.loading]); // eslint-disable-line

  // предзагрузка следующей страницы
  useEffect(() => {
    if (!data || legacy || !data.has_more) return;
    prefetch('news:feed:' + baseQs(page + 1), () => api.get('/api/news?' + baseQs(page + 1)));
  }, [data, page]); // eslint-disable-line

  // при смене страницы — к началу списка
  const top = useRef<HTMLDivElement>(null);
  const prevPage = useRef(page);
  useEffect(() => {
    if (prevPage.current === page) return;
    prevPage.current = page;
    top.current?.scrollIntoView({ block: 'start' });
  }, [page]);

  const liked = new Set(data?.liked || []);
  const all = [...items, ...extra.filter((x) => !items.some((y) => y.id === x.id))];
  const hero = !filtered && page === 1 ? (hot.data?.items || []).slice(0, 3) : [];
  const heroIds = new Set(hero.map((h) => h.id));
  const pinned = page === 1 && !urlQ ? (data?.pinned || []).filter((p) => !heroIds.has(p.id)) : [];
  const rest = all.filter((n) => !heroIds.has(n.id));
  const goPage = (p: number) => setSp({ page: p > 1 ? p : null }, false);
  const legacyMore = legacy && (extraMore === null ? data?.has_more : extraMore);

  return (
    <div className="stack">
      <div className="pageH">
        <h1>Новости</h1>
        <div className="sp" />
        {isEditor(me) && <Link to="/news/new" className="btn pri"><I.Plus size={18} /> Новая публикация</Link>}
      </div>
      <div className="bnMobile"><Banners strip /></div>
      {hero.length > 0 && <Hero items={hero} />}
      <div className="newsFilters">
        <div className="searchNews">
          <I.Search size={17} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск по новостям" aria-label="Поиск по новостям" onKeyDown={(e) => { if (e.key === 'Enter') setSp({ q: q.trim() || null, page: null }); }} />
          {q && <button type="button" aria-label="Очистить" onClick={() => { setQ(''); setSp({ q: null, page: null }); }}><I.X size={15} /></button>}
        </div>
        <div className="nfSel"><DeptSelect value={dept ? +dept : null} onChange={(v) => setFilter({ department: v })} emptyLabel="Все подразделения" /></div>
        <div className="nfSel"><DirSelect value={dir ? +dir : null} onChange={(v) => setFilter({ direction: v })} emptyLabel="Все направления" /></div>
      </div>
      <div className="chips">
        <button className={cx('chip', !cat && !imp && 'on')} onClick={() => setFilter({ category: null, important: null })}>Все</button>
        <button className={cx('chip', imp && 'on')} onClick={() => setFilter({ important: imp ? null : 1 })}><I.Zap size={14} /> Важное</button>
        {cats.map((c) => (
          <button key={c.id} className={cx('chip', cat === String(c.id) && 'on')} onClick={() => setFilter({ category: cat === String(c.id) ? null : c.id })}>{c.name}</button>
        ))}
      </div>
      {filtered && (
        <div className="row small muted" style={{ flexWrap: 'wrap' }}>
          {urlQ && <Badge kind="accent">Поиск: {urlQ}</Badge>}
          {dept && <Badge kind="accent">Подразделение</Badge>}
          {dir && <Badge kind="accent">Направление</Badge>}
          <button className="btn ghost sm" onClick={() => { setQ(''); setSaved({}); setSp({ q: null, department: null, direction: null, category: null, important: null, page: null }); }}>Сбросить</button>
        </div>
      )}
      <div ref={top} className="feedTop" />
      {first.error && !data ? <ErrorBox error={first.error} retry={first.refetch} /> : !data ? (
        <div className="newsGrid">{Array.from({ length: 6 }, (_, i) => <div key={i} className="card" style={{ height: 320 }}><Skel h={170} r={0} /><div style={{ padding: 16, display: 'grid', gap: 10 }}><Skel h={20} /><Skel h={14} w="70%" /></div></div>)}</div>
      ) : rest.length === 0 && pinned.length === 0 ? (
        <>
          <div className="card"><Empty icon={I.Newspaper} title="Публикаций не найдено">{urlQ ? 'Ничего не нашлось по такому запросу. Поиск ищет точное вхождение слов.' : 'Попробуйте изменить фильтры'}</Empty></div>
          {!legacy && (data.pages || 0) > 1 && <Pager href={pageHref} page={page} total={data.total || 0} per={data.per || PER} pages={data.pages} capped={data.total_capped} onChange={goPage} />}
        </>
      ) : (
        <>
          {pinned.length > 0 && (
            <section className="stackS">
              <div className="lbl"><I.Pin size={14} style={{ verticalAlign: -2 }} /> Закреплено</div>
              <div className="newsGrid">{pinned.map((n) => <NewsCard key={n.id} n={n} liked={liked.has(n.id)} />)}</div>
            </section>
          )}
          {rest.length > 0 && (
            <section className="stackS">
              {pinned.length > 0 && <div className="lbl">Лента</div>}
              <div className="newsGrid" style={{ opacity: first.loading && !!data && data.page !== page ? 0.6 : 1, transition: 'opacity .15s' }}>{rest.map((n) => <NewsCard key={n.id} n={n} liked={liked.has(n.id)} />)}</div>
            </section>
          )}
          {!legacy && <Pager href={pageHref} page={page} total={data.total || 0} per={data.per || PER} pages={data.pages} capped={data.total_capped} onChange={goPage} />}
          {legacy && legacyMore && <div className="loadMore"><Btn busy={moreBusy} onClick={loadMore}>Далее</Btn></div>}
          {moreErr && <div className="err" style={{ textAlign: 'center' }}>{moreErr}</div>}
        </>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- article
export function NewsView({ id }: { id: number }) {
  const me = useStore((s) => s.me)!;
  const key = 'news:' + id;
  // stale: 0 — каждый заход перечитывает новость, чтобы счётчик просмотров был актуальным
  const { data: n, error, refetch, mutate } = useQuery<News>(key, () => api.get('/api/news/' + id), { stale: 0 });
  useTitle(n?.title || 'Новость');
  const [confirm, node] = useConfirm();
  const [cc, setCc] = useState<number | null>(null);
  useEffect(() => setCc(null), [id]);
  useRealtime('comment', (c) => c.entity_type === 'news' && c.entity_id === id && mutate((o) => (o ? { ...o, comments_count: o.comments_count + 1 } : o)), [id]);
  useRealtime('comment.delete', () => refetch(), [id]);

  if (error && !n) return <div className="card"><ErrorBox error={error} retry={refetch} /></div>;
  if (!n) return <div className="card pad stack"><Skel h={300} /><Skel h={34} w="70%" /><Skel h={16} /><Skel h={16} w="90%" /></div>;

  async function del() {
    if (!(await confirm('Удалить публикацию?', { text: 'Вместе с комментариями. Действие необратимо.', ok: 'Удалить' }))) return;
    try { await api.del('/api/news/' + id); invalidate('news'); invalidate('rail:'); navigate('/'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function toggleHidden() {
    try {
      await api.post(`/api/news/${id}/hidden`, { hidden: !n!.hidden });
      invalidate('news'); invalidate('rail:');
      toast({ title: n!.hidden ? 'Публикация снова показывается' : 'Публикация скрыта', kind: 'success' }, 2500);
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  const canEdit = n.can_edit ?? isEditor(me);
  const future = new Date(n.published_at).getTime() > Date.now();
  const expired = !!n.visible_until && new Date(n.visible_until).getTime() <= Date.now();
  const galleries = n.galleries || [];
  return (
    <div className="stack" style={{ maxWidth: 900 }}>
      <div className="crumbs"><Link to="/"><I.ArrowLeft size={15} style={{ verticalAlign: -2 }} /> Новости</Link>{n.category && <><I.ChevronRight size={14} /><Link to={`/?category=${n.category_id}`}>{n.category}</Link></>}</div>
      {canEdit && n.live === false && (
        <div className="notice warn">
          <I.EyeOff size={18} />
          <div>
            {n.status === 'draft' ? 'Черновик — читатели эту публикацию не видят.' : n.hidden ? 'Публикация скрыта с показа — читатели её не видят.' : future ? `Запланированная публикация — появится автоматически ${fmtDate(n.published_at)}.` : expired ? 'Срок показа истёк — публикация скрыта от читателей.' : 'Публикация сейчас не показывается читателям.'}
          </div>
        </div>
      )}
      <article className="card article">
        {n.cover && <Img className="cover" src={view(n.cover)} eager />}
        <div className="in">
          <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
            {n.category && <span className="catDot" style={{ '--c': n.category_color || undefined } as any}>{n.category}</span>}
            {n.important && <Badge kind="warn"><I.Zap size={12} /> Важное</Badge>}
            {n.pinned && <Badge><I.Pin size={12} /> Закреплено</Badge>}
            {n.status === 'draft' && <Badge kind="dng">Черновик</Badge>}
            {n.department && <Link to={`/departments/${n.department_id}`} className="badge"><I.Building size={12} /> {n.department}</Link>}
            {n.direction_id && <Link to={`/?direction=${n.direction_id}`} className="badge"><I.Layers size={12} /> Направление</Link>}
          </div>
          <h1>{n.title}</h1>
          {n.summary && <p className="muted" style={{ fontSize: 18 }}>{n.summary}</p>}
          <div className="byline">
            <Link to={`/people/${n.author_id}`}><Avatar name={n.author} src={n.author_avatar} size={44} userId={n.author_id} /></Link>
            <div className="sp" style={{ minWidth: 0 }}>
              <div className="tiny faint">Разместил(а)</div>
              <Link to={`/people/${n.author_id}`} className="bold">{n.author}</Link>
              <div className="small muted">{[n.author_title, fmtDate(n.published_at)].filter(Boolean).join(' · ')}</div>
            </div>
            <span className="stat muted small" title="Просмотры"><I.Eye size={16} /> {n.views_count}</span>
          </div>
          <div className="divider" style={{ margin: 0 }} />
          {n.body && <Markdown text={n.body} className="md" />}
          {galleries.length > 0 && <div className="stack">{galleries.map((g) => <GalleryPreview key={g.id} g={g} />)}</div>}
          {n.attachments && n.attachments.length > 0 && (
            <div className="stackS"><div className="lbl">Вложения</div>{n.attachments.map((f) => <FileLink key={f.id} f={f} />)}</div>
          )}
          <div className="actions">
            <Reactions type="news" id={id} initial={n.reactions} pinLike />
            <a className="btn" href="#comments" onClick={(e) => { e.preventDefault(); document.getElementById('comments')?.scrollIntoView({ behavior: 'smooth' }); }}><I.Comment size={18} /> {cc ?? n.comments_count}</a>
            <button className="btn" onClick={() => copyText(location.origin + location.pathname).then(() => toast({ title: 'Ссылка скопирована', kind: 'success' }, 2000))}><I.Share size={18} /> Поделиться</button>
            <BookmarkButton type="news" id={id} initial={n.bookmarked} label />
            <div className="sp" />
            {canEdit && (
              <>
                <button className="btn" onClick={toggleHidden} title={n.hidden ? 'Показывать читателям' : 'Скрыть с публикации'}>{n.hidden ? <I.Eye size={17} /> : <I.EyeOff size={17} />}<span className="hide-m"> {n.hidden ? 'Показать' : 'Скрыть'}</span></button>
                <Link to={`/news/${id}/edit`} className="btn"><I.Edit size={17} /> Изменить</Link>
                <button className="btn dng" onClick={del} aria-label="Удалить"><I.Trash size={17} /></button>
              </>
            )}
          </div>
        </div>
      </article>
      <section className="card pad stack" id="comments">
        <h3>Комментарии <span className="muted">{cc ?? n.comments_count}</span></h3>
        <Comments type="news" id={id} live onCount={setCc} />
      </section>
      {node}
    </div>
  );
}

// ---------------------------------------------------------------- editor
interface GalRow { key: number; folder_id: number | ''; title: string; kind: 'photos' | 'videos'; name?: string }
interface FolderOpt { id: number; name: string; parent_name: string | null; files_count: number }

function GalleryRow({ row, onChange, onRemove }: { row: GalRow; onChange: (r: GalRow) => void; onRemove: () => void }) {
  const { data } = useQuery<FolderOpt[]>('folders:all:' + row.kind, () => api.get('/api/folders/all?kind=' + row.kind), { stale: 60000 });
  const opts = data || [];
  const known = opts.some((o) => o.id === row.folder_id);
  const videos = row.kind === 'videos';
  return (
    <div className="galRow">
      <span className="galKind">{videos ? <I.Video size={17} /> : <I.Image size={17} />}{videos ? 'Видео' : 'Фото'}</span>
      <Select value={row.folder_id} aria-label="Папка" onChange={(e) => {
        const id = +e.target.value;
        const o = opts.find((x) => x.id === id);
        onChange({ ...row, folder_id: id || '', title: row.title || o?.name || '' });
      }}>
        <option value="">— выберите папку —</option>
        {!known && row.folder_id !== '' && <option value={row.folder_id}>{row.name || 'Папка #' + row.folder_id}</option>}
        {opts.map((o) => <option key={o.id} value={o.id}>{o.parent_name ? o.parent_name + ' / ' : ''}{o.name} · {o.files_count}</option>)}
      </Select>
      <Input value={row.title} maxLength={120} placeholder="Название ссылки" aria-label="Название ссылки" onChange={(e) => onChange({ ...row, title: e.target.value })} />
      <Btn kind="ghost" icon type="button" onClick={onRemove} aria-label="Убрать галерею"><I.X size={17} /></Btn>
    </div>
  );
}

const toIso = (v: string) => (v ? new Date(v).toISOString() : '');

export function NewsEditor({ id }: { id?: number }) {
  useTitle(id ? 'Редактирование' : 'Новая публикация');
  const me = useStore((s) => s.me)!;
  const cats = useStore((s) => s.categories);
  const existing = useQuery<News>(id ? 'news:edit:' + id : null, () => api.get('/api/news/' + id), { stale: 0 });
  const depts = useDepartments();
  const companyOk = isAdmin(me) || !!me.company_news;
  const [f, setF] = useState({
    title: '', summary: '', body: '', category_id: '' as any, cover: '', important: false, pinned: false, hidden: false, status: 'published',
    published_at: toLocalInput(new Date()), visible_until: '',
    department_id: (!id && !companyOk ? me.department_id : null) as number | null, direction_id: null as number | null,
  });
  const [files, setFiles] = useState<any[]>([]);
  const [gals, setGals] = useState<GalRow[]>([]);
  const [preview, setPreview] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [upl, setUpl] = useState(0);
  const fileInp = useRef<HTMLInputElement>(null);
  const gk = useRef(1);
  useEffect(() => {
    const n = existing.data;
    if (!n) return;
    setF({
      title: n.title, summary: n.summary, body: n.body || '', category_id: n.category_id ?? '', cover: n.cover, important: n.important, pinned: n.pinned,
      hidden: !!n.hidden, status: n.status, published_at: toLocalInput(new Date(n.published_at)), visible_until: n.visible_until ? toLocalInput(new Date(n.visible_until)) : '',
      department_id: n.department_id, direction_id: n.direction_id,
    });
    setFiles(n.attachments || []);
    setGals((n.gallery_refs || []).map((g) => ({ key: gk.current++, folder_id: g.folder_id, title: g.title, kind: g.kind, name: g.folder_name })));
  }, [existing.data]);
  const set = (k: string, v: any) => setF((s) => ({ ...s, [k]: v }));

  async function addFiles(list: FileList | null) {
    if (!list) return;
    for (const file of Array.from(list)) {
      try { setUpl(0.01); const r = await api.upload('/api/news/files', file, setUpl); setFiles((x) => [...x, r]); } catch (e) { setErr(errMsg(e)); }
    }
    setUpl(0);
  }
  async function save(status: string) {
    if (!f.title.trim()) return setErr('Укажите заголовок');
    if (f.department_id == null && !companyOk) return setErr('Выберите подразделение: публиковать для всей компании вам не разрешено');
    if (f.published_at && f.visible_until && new Date(f.visible_until) <= new Date(f.published_at)) return setErr('Дата окончания показа должна быть позже даты начала');
    if (gals.some((g) => !g.folder_id)) return setErr('Выберите папку для каждой ссылки на галерею или удалите пустые строки');
    setBusy(true); setErr('');
    try {
      const body = {
        title: f.title.trim(), summary: f.summary, body: f.body, cover: f.cover, important: f.important, pinned: f.pinned, hidden: f.hidden, status,
        category_id: f.category_id ? +f.category_id : null, department_id: f.department_id, direction_id: f.direction_id,
        published_at: toIso(f.published_at), visible_until: toIso(f.visible_until),
        files: files.map((x) => x.id), galleries: gals.map((g) => ({ folder_id: +g.folder_id, title: g.title.trim() })),
      };
      const r = id ? await api.put<{ id: number }>('/api/news/' + id, body) : await api.post<{ id: number }>('/api/news', body);
      invalidate('news'); invalidate('rail:');
      navigate('/news/' + r.id);
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  if (id && !existing.data) return existing.error ? <ErrorBox error={existing.error} /> : <Loading />;
  const scheduled = f.published_at && new Date(f.published_at).getTime() > Date.now() + 30000;
  const catName = cats.find((c) => String(c.id) === String(f.category_id))?.name;
  return (
    <div className="stack" style={{ maxWidth: 960 }}>
      <div className="pageH"><h1>{id ? 'Редактирование публикации' : 'Новая публикация'}</h1></div>
      <div className="card pad stack">
        <Field label="Заголовок"><Input value={f.title} onChange={(e) => set('title', e.target.value)} maxLength={300} placeholder="О чём новость?" style={{ fontSize: 18, fontWeight: 600 }} /></Field>
        <Field label="Краткое описание"><Textarea rows={2} value={f.summary} onChange={(e) => set('summary', e.target.value)} placeholder="Одно-два предложения для ленты" /></Field>
        <div className="formGrid">
          <Field label="Категория"><Select value={f.category_id} onChange={(e) => set('category_id', e.target.value)}><option value="">— без категории —</option>{cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select></Field>
          <Field label="Подразделение" hint={companyOk ? undefined : 'Доступны подразделения вашей области управления'}>
            <DeptSelect value={f.department_id} onChange={(v) => set('department_id', v)} onlyManageable={!isAdmin(me)} allowEmpty={companyOk} emptyLabel="Вся компания" />
          </Field>
          <Field label="Направление деятельности"><DirSelect value={f.direction_id} onChange={(v) => set('direction_id', v)} onlyManageable={!isAdmin(me)} /></Field>
          <div className="field"><label>Параметры</label><div className="stackS" style={{ paddingTop: 6 }}><Switch checked={f.important} onChange={(v) => set('important', v)} label="Важная новость (уведомит всех)" /><Switch checked={f.pinned} onChange={(v) => set('pinned', v)} label="Закрепить вверху ленты" /></div></div>
        </div>
        <fieldset className="visBox">
          <legend><I.Clock size={15} /> Видимость</legend>
          <div className="formGrid">
            <Field label="Показывать с" hint="Дата в будущем — новость готовится заранее и появится сама"><Input type="datetime-local" value={f.published_at} onChange={(e) => set('published_at', e.target.value)} /></Field>
            <Field label="Показывать до" hint="Пусто — не скрывать"><div className="row"><Input type="datetime-local" value={f.visible_until} onChange={(e) => set('visible_until', e.target.value)} />{f.visible_until && <Btn kind="ghost" icon type="button" aria-label="Очистить" onClick={() => set('visible_until', '')}><I.X size={16} /></Btn>}</div></Field>
          </div>
          <label className="chk"><input type="checkbox" checked={f.hidden} onChange={(e) => set('hidden', e.target.checked)} /> Скрыть с публикации <span className="muted small">— читатели не видят, но её можно вернуть в любой момент</span></label>
          {scheduled && !f.hidden && <div className="notice"><I.Calendar size={18} /><div>Запланированная новость: появится автоматически {fmtDate(new Date(f.published_at))}. Сохраняйте через «Опубликовать».</div></div>}
        </fieldset>
        <ImageUpload label="Обложка" value={f.cover} onChange={(v) => set('cover', v)} />
        <div className="field">
          <div className="row"><label className="sp lbl">Текст (Markdown)</label><button type="button" className="btn sm ghost" onClick={() => setPreview(!preview)}><I.Eye size={15} /> {preview ? 'Редактор' : 'Предпросмотр'}</button></div>
          {preview ? (
            <div className="card padS" style={{ minHeight: 240 }}>
              <div className="row" style={{ gap: 8, marginBottom: 8, flexWrap: 'wrap' }}>{catName && <Badge kind="accent">{catName}</Badge>}{f.important && <Badge kind="warn"><I.Zap size={12} /> Важное</Badge>}</div>
              <h2 style={{ marginBottom: 8 }}>{f.title || 'Без заголовка'}</h2>
              {f.summary && <p className="muted">{f.summary}</p>}
              <Markdown text={f.body} className="md" />
            </div>
          ) : <MdEditor value={f.body} onChange={(v) => set('body', v)} rows={14} placeholder={'## Подзаголовок\n\nТекст новости…'} />}
        </div>
        <div className="stackS">
          <div className="row"><div className="lbl sp">Фото- и видеогалереи</div>
            <Btn size="sm" type="button" onClick={() => setGals((g) => [...g, { key: gk.current++, folder_id: '', title: '', kind: 'photos' }])}><I.Image size={15} /> Фотогалерея</Btn>
            <Btn size="sm" type="button" onClick={() => setGals((g) => [...g, { key: gk.current++, folder_id: '', title: '', kind: 'videos' }])}><I.Video size={15} /> Видеогалерея</Btn>
          </div>
          {gals.length === 0 && <div className="small muted">Можно добавить ссылки на папки из разделов «Фотогалерея» и «Видео»: в новости они покажутся миниатюрами.</div>}
          {gals.map((g) => <GalleryRow key={g.key} row={g} onChange={(r) => setGals((x) => x.map((y) => (y.key === g.key ? r : y)))} onRemove={() => setGals((x) => x.filter((y) => y.key !== g.key))} />)}
        </div>
        <div className="stackS">
          <div className="row"><div className="lbl sp">Вложения</div><Btn size="sm" onClick={() => fileInp.current?.click()}><I.Paperclip size={15} /> Добавить файл</Btn><input ref={fileInp} type="file" multiple hidden onChange={(e) => { addFiles(e.target.files); e.target.value = ''; }} /></div>
          {upl > 0 && <div className="prog"><i style={{ width: upl * 100 + '%' }} /></div>}
          {files.map((x) => <div key={x.id} className="row"><div className="sp"><FileLink f={x} /></div><Btn kind="ghost" icon onClick={() => setFiles(files.filter((y) => y.id !== x.id))}><I.X /></Btn></div>)}
        </div>
        {err && <div className="err" role="alert">{err}</div>}
        <div className="row" style={{ justifyContent: 'flex-end', flexWrap: 'wrap' }}>
          <Btn onClick={() => history.back()}>Отмена</Btn>
          <Btn busy={busy} onClick={() => save('draft')}>Сохранить как черновик</Btn>
          <Btn kind="pri" busy={busy} onClick={() => save('published')}><I.Check size={17} /> {f.status === 'published' && id ? 'Сохранить' : scheduled ? 'Запланировать' : 'Опубликовать'}</Btn>
        </div>
      </div>
    </div>
  );
}
