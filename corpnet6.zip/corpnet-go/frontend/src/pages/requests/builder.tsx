import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { useQuery, invalidate } from '../../lib/query';
import { Link, navigate, useTitle } from '../../lib/router';
import { toast, useStore } from '../../lib/store';
import { cx, fmtDate } from '../../lib/util';
import { Badge, Btn, Empty, ErrorBox, Field as UiField, Input, Loading, Select, Switch, Textarea } from '../../ui';
import { DeptSelect } from '../../ui/DeptSelect';
import { Markdown } from '../../lib/markdown';
import { SubjectAdder, clone } from './builder_common';
import type { Picked } from './builder_common';
import { FormEditor } from './builder_form';
import { FlowEditor } from './builder_flow';
import { FormView } from './form';
import { IconColor, useCategories } from './manage';
import { TypeIcon } from './icons';
import { STEP_KIND, UNIT_LABEL, defaultsFor } from './model';
import type { Schema, Workflow } from './model';

interface Subj { type: string; id?: number; key?: string; name?: string }
interface Acl { submit: Subj[]; owner: Subj[]; responsible: Subj[]; watcher: Subj[] }
interface Meta {
  name: string; description: string; icon: string; color: string; code: string; number_mask: string; category_id: number | null; sla_value: number; sla_unit: string;
  remind_before_h: number; active: boolean; archived: boolean; department_id: number | null;
}
interface Doc { meta: Meta; schema: Schema; workflow: Workflow; acl: Acl; note: string }

const NEW_DOC = (): Doc => ({
  meta: { name: '', description: '', icon: 'file', color: '#286b9e', code: '', number_mask: '', category_id: null, sla_value: 0, sla_unit: 'wd', remind_before_h: 4, active: false, archived: false, department_id: null },
  schema: { layout: 'single', sections: [{ id: 's1', title: 'Данные заявки', fields: [{ key: 'subject', type: 'text', label: 'Тема', required: true }] }] },
  workflow: { steps: [] },
  acl: { submit: [{ type: 'all' }], owner: [], responsible: [], watcher: [] },
  note: '',
});

const strip = (sc: Schema): Schema => {
  const s = clone(sc);
  for (const sec of s.sections) for (const f of sec.fields) { delete (f as any)._auto; for (const k of Object.keys(f)) if ((f as any)[k] === undefined || (f as any)[k] === null || (f as any)[k] === '') delete (f as any)[k]; }
  return s;
};

function SubjectList({ title, hint, list, onChange, kinds, icon }: { title: string; hint: string; list: Subj[]; onChange: (l: Subj[]) => void; kinds: any[]; icon: any }) {
  const label = (s: Subj) => (s.type === 'all' ? 'Все сотрудники' : s.type === 'user' ? s.name || '#' + s.id : s.type === 'department' ? `Подразделение: ${s.name || '#' + s.id} (и дочерние)` : s.type === 'group' ? `Группа: ${s.name || '#' + s.id}` : `Роль: ${s.name || s.key}`);
  const add = (p: Picked) => {
    const s: Subj = { type: p.kind === 'dept' ? 'department' : p.kind, id: p.id, key: p.key, name: p.name };
    if (list.some((x) => x.type === s.type && (x.id || 0) === (s.id || 0) && (x.key || '') === (s.key || ''))) return;
    onChange(s.type === 'all' ? [s] : [...list.filter((x) => x.type !== 'all'), s]);
  };
  return (
    <div className="card pad stack">
      <div className="row"><span className="rqSubjIco">{React.createElement(icon, { size: 18 })}</span><div><h3 style={{ fontSize: 16, fontWeight: 700 }}>{title}</h3><div className="muted small">{hint}</div></div></div>
      <div className="tokens">
        {list.map((s, i) => <span className="token" key={i}>{label(s)}<button type="button" aria-label="Убрать" onClick={() => onChange(list.filter((_, j) => j !== i))}><I.X size={14} /></button></span>)}
        {list.length === 0 && <span className="muted small">Никто не назначен</span>}
      </div>
      <SubjectAdder kinds={kinds} onAdd={add} />
    </div>
  );
}

export function BuilderPage({ id }: { id?: number }) {
  const me = useStore((s) => s.me)!;
  const q = useQuery<any>(id ? 'req:type:' + id : null, () => api.get('/api/requests/manage/types/' + id), { stale: 0 });
  const cats = useCategories();
  const [doc, setDoc] = useState<Doc | null>(id ? null : NEW_DOC());
  const [base, setBase] = useState('');
  const [tab, setTab] = useState<'main' | 'form' | 'flow' | 'access' | 'preview' | 'versions'>('main');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const loaded = useRef(false);
  const canEditAll = me.role === 'admin' || me.role === 'editor';
  useTitle(id ? 'Конструктор заявки' : 'Новый тип заявки');

  const fromServer = (d: any): Doc => ({
    meta: { name: d.type.name, description: d.type.description, icon: d.type.icon, color: d.type.color, code: d.type.code, number_mask: d.type.number_mask, category_id: d.type.category_id, sla_value: d.type.sla_value,
      sla_unit: d.type.sla_unit, remind_before_h: d.type.remind_before_h, active: d.type.active, archived: d.type.archived, department_id: d.type.department_id },
    schema: d.type.schema, workflow: d.type.workflow?.steps ? d.type.workflow : { steps: [] }, acl: d.acl, note: '',
  });
  useEffect(() => {
    if (q.data && !loaded.current) { loaded.current = true; const d = fromServer(q.data); setDoc(d); setBase(JSON.stringify(strip(d.schema)) + JSON.stringify(d.workflow) + JSON.stringify({ ...d.meta, acl: d.acl })); }
  }, [q.data]);
  useEffect(() => { if (!id && doc && !base) setBase(JSON.stringify(strip(doc.schema)) + JSON.stringify(doc.workflow) + JSON.stringify({ ...doc.meta, acl: doc.acl })); }, [!!doc]);
  const sig = doc ? JSON.stringify(strip(doc.schema)) + JSON.stringify(doc.workflow) + JSON.stringify({ ...doc.meta, acl: doc.acl }) : '';
  const dirty = !!doc && !!base && sig !== base;
  useEffect(() => {
    if (!dirty) return;
    const h = (e: BeforeUnloadEvent) => { e.preventDefault(); e.returnValue = ''; };
    addEventListener('beforeunload', h);
    return () => removeEventListener('beforeunload', h);
  }, [dirty]);

  const [pdata, setPdata] = useState<Record<string, any>>({});
  const previewKey = useMemo(() => (doc ? JSON.stringify(doc.schema.sections.map((s) => s.fields.map((f) => f.key + f.type))) : ''), [doc?.schema]);
  useEffect(() => { if (tab === 'preview' && doc) setPdata(defaultsFor(strip(doc.schema), me)); }, [tab, previewKey]); // eslint-disable-line

  if (id && q.error && !doc) return <div className="card">{(q.error as any).status === 403 ? <Empty icon={I.Lock} title="Нет прав на этот тип заявки"><Link to="/requests/manage">К списку</Link></Empty> : <ErrorBox error={q.error} retry={q.refetch} />}</div>;
  if (!doc) return <Loading />;
  const set = (patch: Partial<Doc>) => setDoc({ ...doc, ...patch });
  const setMeta = (p: Partial<Meta>) => setDoc({ ...doc, meta: { ...doc.meta, ...p } });

  async function save() {
    setErr('');
    if (!doc!.meta.name.trim()) { setTab('main'); return setErr('Укажите название типа заявки'); }
    setBusy(true);
    try {
      const body = { ...doc!.meta, schema: strip(doc!.schema), workflow: doc!.workflow, acl: doc!.acl, note: doc!.note };
      const r = id ? await api.put('/api/requests/manage/types/' + id, body) : await api.post('/api/requests/manage/types', body);
      invalidate('req:');
      toast({ title: r.new_version ? 'Сохранено, создана новая версия формы' : 'Сохранено', kind: 'success' });
      if (!id) { navigate('/requests/manage/' + r.id, { replace: true }); return; }
      loaded.current = false; q.refetch();
      setDoc({ ...doc!, note: '' });
      setBase(sig);
    } catch (e) { setErr(errMsg(e)); }
    setBusy(false);
  }

  const m = doc.meta;
  const tabs: { id: typeof tab; label: string; icon: any }[] = [
    { id: 'main', label: 'Основное', icon: I.Settings }, { id: 'form', label: 'Форма', icon: I.Edit }, { id: 'flow', label: 'Маршрут', icon: I.UserCheck },
    { id: 'access', label: 'Доступ и ответственные', icon: I.Shield }, { id: 'preview', label: 'Предпросмотр', icon: I.Eye },
  ];
  if (id) tabs.push({ id: 'versions', label: 'Версии', icon: I.Archive });
  const issues: string[] = [];
  if (!doc.acl.submit.length) issues.push('Никто не может подавать заявку — тип не будет виден в каталоге.');
  if (doc.workflow.steps.some((s) => s.branches.some((b) => !b.assignees.length))) issues.push('В маршруте есть ветка без исполнителей.');
  if (doc.workflow.steps.some((s) => s.branches.some((b) => b.assignees.some((a) => a.t === 'responsible'))) && !doc.acl.responsible.length) issues.push('В маршруте используются «ответственные за заявку», но ответственные не назначены.');

  return (
    <div className="stack rqBuilder">
      <div className="crumbs"><Link to="/requests/manage"><I.ArrowLeft size={15} /> Конструктор заявок</Link></div>
      <div className="card padS rqBHead">
        <TypeIcon name={m.icon} color={m.color} size={22} box={44} />
        <div style={{ minWidth: 0, flex: 1 }}>
          <div className="bold clip" style={{ fontSize: 18 }}>{m.name || 'Новый тип заявки'}</div>
          <div className="tiny muted">{id ? `Тип №${id}${q.data ? ` · версия формы ${q.data.type.version} · заявок: ${q.data.type.requests}` : ''}` : 'Черновик типа'}{dirty && <span className="rqDirty"> · есть несохранённые изменения</span>}</div>
        </div>
        <Switch checked={m.active} onChange={(v) => setMeta({ active: v })} label={<span className="small">{m.active ? 'Опубликован' : 'Скрыт'}</span>} />
        <Btn kind="pri" busy={busy} disabled={!dirty && !!id} onClick={save}><I.Check size={16} /> Сохранить</Btn>
      </div>
      {err && <div className="err">{err}</div>}
      <nav className="rqBTabs" aria-label="Разделы конструктора">
        {tabs.map((t) => <button key={t.id} type="button" className={cx(tab === t.id && 'on')} onClick={() => setTab(t.id)}><t.icon size={16} /> {t.label}</button>)}
      </nav>
      {issues.length > 0 && tab !== 'main' && <div className="notice warn"><I.Alert size={18} /><div>{issues.map((x) => <div key={x}>{x}</div>)}</div></div>}

      {tab === 'main' && (
        <div className="card pad stack">
          <div className="rqG2">
            <UiField label="Название"><Input value={m.name} maxLength={150} onChange={(e) => setMeta({ name: e.target.value })} placeholder="Например: Справка с места работы" autoFocus={!id} /></UiField>
            <UiField label="Категория">
              <Select value={m.category_id ?? ''} onChange={(e) => setMeta({ category_id: e.target.value ? +e.target.value : null })}><option value="">Без категории</option>{(cats.data || []).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select>
            </UiField>
          </div>
          <UiField label="Описание для заявителя" hint="Поддерживается Markdown: списки, выделение, ссылки. Показывается над формой.">
            <div className="rqG2"><Textarea rows={7} value={m.description} onChange={(e) => setMeta({ description: e.target.value })} /><div className="rqDesc" style={{ minHeight: 100 }}>{m.description ? <Markdown text={m.description} /> : <span className="faint small">Предпросмотр описания</span>}</div></div>
          </UiField>
          <UiField label="Значок и цвет"><IconColor icon={m.icon} color={m.color} onIcon={(v) => setMeta({ icon: v })} onColor={(v) => setMeta({ color: v })} /></UiField>
          <div className="rqG2">
            <UiField label="Подразделение-владелец (область управления)" hint="Редакторы управляют типами только своих подразделений (включая дочерние).">
              <DeptSelect value={m.department_id} onChange={(v) => setMeta({ department_id: v })} onlyManageable={!canEditAll || me.role !== 'admin'} emptyLabel="Вся компания" allowEmpty={me.role === 'admin'} />
            </UiField>
            <div className="rqG2">
              <UiField label="Код типа" hint="Для нумерации: {CODE}"><Input value={m.code} maxLength={12} onChange={(e) => setMeta({ code: e.target.value })} placeholder="СПР" /></UiField>
              <UiField label="Маска номера" hint="{CODE} {YYYY} {NNNN}"><Input value={m.number_mask} maxLength={60} onChange={(e) => setMeta({ number_mask: e.target.value })} placeholder="{CODE}-{YYYY}-{NNNNNN}" /></UiField>
            </div>
          </div>
          <div className="rqG3">
            <UiField label="Срок на шаг по умолчанию"><Input type="number" min={0} value={m.sla_value} onChange={(e) => setMeta({ sla_value: Math.max(0, +e.target.value || 0) })} /></UiField>
            <UiField label="Единица"><Select value={m.sla_unit} onChange={(e) => setMeta({ sla_unit: e.target.value })}>{Object.entries(UNIT_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></UiField>
            <UiField label="Напоминать за, ч. до срока"><Input type="number" min={0} value={m.remind_before_h} onChange={(e) => setMeta({ remind_before_h: Math.max(0, +e.target.value || 0) })} /></UiField>
          </div>
          {id && <UiField label="Комментарий к изменениям (попадёт в историю версий)"><Input value={doc.note} maxLength={300} onChange={(e) => set({ note: e.target.value })} placeholder="Что изменилось" /></UiField>}
          {id && <Switch checked={m.archived} onChange={(v) => setMeta({ archived: v })} label={<span className="small">В архиве (не показывается в каталоге, заявки сохраняются)</span>} />}
        </div>
      )}

      {tab === 'form' && <FormEditor schema={doc.schema} workflow={doc.workflow} onChange={(schema, workflow) => set({ schema, workflow })} />}
      {tab === 'flow' && <FlowEditor schema={doc.schema} workflow={doc.workflow} onChange={(workflow) => set({ workflow })} />}

      {tab === 'access' && (
        <div className="stack">
          <div className="notice"><I.Info size={18} /><div>Область видимости: подразделения учитываются вместе с дочерними. Редакторы могут изменять только типы своей области управления.</div></div>
          <SubjectList icon={I.LogIn} title="Кто может подавать заявку" hint="Тип виден в каталоге только этим сотрудникам." list={doc.acl.submit} onChange={(l) => set({ acl: { ...doc.acl, submit: l } })} kinds={['all', 'user', 'dept', 'group', 'role']} />
          <SubjectList icon={I.Briefcase} title="Ответственные за заявки этого типа" hint="Видят все заявки типа, выгружают CSV, назначают исполнителей; на них назначаются шаги «Ответственные за заявку»." list={doc.acl.responsible} onChange={(l) => set({ acl: { ...doc.acl, responsible: l } })} kinds={['user', 'dept', 'group', 'role']} />
          <SubjectList icon={I.Edit} title="Кто может редактировать тип (владельцы)" hint="Настраивают форму, маршрут и доступ этого типа. Создатель и администраторы — всегда." list={doc.acl.owner} onChange={(l) => set({ acl: { ...doc.acl, owner: l } })} kinds={['user', 'dept', 'group', 'role']} />
          <SubjectList icon={I.Eye} title="Наблюдатели" hint="Видят все заявки типа (только чтение), не участвуют в согласовании." list={doc.acl.watcher} onChange={(l) => set({ acl: { ...doc.acl, watcher: l } })} kinds={['user', 'dept', 'group', 'role']} />
        </div>
      )}

      {tab === 'preview' && (
        <div className="stack">
          <div className="notice"><I.Eye size={18} /><div>Так форма выглядит для заявителя. Данные здесь не сохраняются.</div></div>
          <div className="card pad">
            <div className="row" style={{ gap: 14, marginBottom: 12 }}><TypeIcon name={m.icon} color={m.color} size={26} box={52} /><h1 style={{ fontSize: 24, fontWeight: 800 }}>{m.name || 'Без названия'}</h1></div>
            {m.description && <div className="rqDesc"><Markdown text={m.description} /></div>}
          </div>
          <div className="card pad">
            <FormView schema={strip(doc.schema)} data={pdata} setData={setPdata} preview>
              {doc.workflow.steps.length > 0 && <div className="rqRoutePrev"><div className="lbl" style={{ marginBottom: 6 }}>Маршрут согласования</div><ol>{doc.workflow.steps.map((s, i) => <li key={i}><span className={'rqKind ' + s.kind}>{STEP_KIND[s.kind]}</span> {s.name}{s.cond?.items?.length ? <span className="tiny faint"> · по условию</span> : null}</li>)}</ol></div>}
              <div className="rowW"><Btn kind="pri" size="lg" disabled><I.Send size={17} /> Отправить заявку</Btn></div>
            </FormView>
          </div>
        </div>
      )}

      {tab === 'versions' && id && <Versions id={id} versions={q.data?.versions || []} onRestore={(sc, wf) => { set({ schema: sc, workflow: wf }); setTab('form'); toast({ title: 'Версия загружена в редактор. Нажмите «Сохранить», чтобы применить', kind: 'info' }); }} />}
    </div>
  );
}

function Versions({ id, versions, onRestore }: { id: number; versions: any[]; onRestore: (s: Schema, w: Workflow) => void }) {
  const [busy, setBusy] = useState(0);
  async function restore(v: number) {
    setBusy(v);
    try { const r = await api.get(`/api/requests/manage/types/${id}/versions/${v}`); onRestore(r.schema, r.workflow?.steps ? r.workflow : { steps: [] }); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(0);
  }
  return (
    <div className="card">
      <div className="padS muted small">Каждое изменение формы или маршрута создаёт новую версию. Уже поданные заявки продолжают идти по той версии, на которой были поданы.</div>
      <div className="tblW"><table className="tbl">
        <thead><tr><th>Версия</th><th>Когда</th><th>Автор</th><th>Комментарий</th><th>Заявок</th><th /></tr></thead>
        <tbody>{versions.map((v, i) => <tr key={v.version}><td className="bold">v{v.version} {i === 0 && <Badge kind="ok">текущая</Badge>}</td><td className="small">{fmtDate(v.created_at)}</td><td className="small">{v.author || '—'}</td><td className="small">{v.note || <span className="faint">—</span>}</td><td className="small">{v.requests}</td><td className="act">{i > 0 && <Btn size="sm" busy={busy === v.version} onClick={() => restore(v.version)}><I.Refresh size={14} /> Загрузить в редактор</Btn>}</td></tr>)}</tbody>
      </table></div>
    </div>
  );
}
