import React, { useState } from 'react';
import * as I from '../../lib/icons';
import { api } from '../../lib/api';
import { useDebounced, cx } from '../../lib/util';
import { useQuery } from '../../lib/query';
import { Btn, Input, Select, UserPicker } from '../../ui';
import { DeptSelect, useDepartments } from '../../ui/DeptSelect';
import { CMP_LABEL, isDisplay } from './model';
import type { Cond, CondItem, Field, Schema, Workflow } from './model';

export const clone = <T,>(x: T): T => JSON.parse(JSON.stringify(x));

export function allFields(schema: Schema): Field[] {
  return schema.sections.flatMap((s) => s.fields).filter((f) => !isDisplay(f.type) && f.key);
}

// ---------------------------------------------------------------- ссылки на поля (переименование / удаление)

function mapConds(schema: Schema, wf: Workflow, fn: (c: Cond) => Cond | null) {
  const fix = (c?: Cond | null) => (c ? fn(c) : c);
  for (const s of schema.sections) {
    s.visible_if = fix(s.visible_if) as any;
    for (const f of s.fields) { f.visible_if = fix(f.visible_if) as any; f.required_if = fix(f.required_if) as any; }
  }
  for (const st of wf.steps) st.cond = fix(st.cond) as any;
}
export function renameKey(schema: Schema, wf: Workflow, from: string, to: string) {
  mapConds(schema, wf, (c) => { c.items.forEach((it) => { const [b, ...r] = it.field.split('.'); if (b === from) it.field = [to, ...r].join('.'); }); return c; });
  for (const st of wf.steps) {
    for (const b of st.branches) for (const a of b.assignees) if (a.t === 'field' && a.key === from) a.key = to;
    for (const a of st.fallback || []) if (a.t === 'field' && a.key === from) a.key = to;
  }
  for (const h of wf.hooks || []) { if (h.period === from) h.period = to; if (h.deputy === from) h.deputy = to; if (h.flag === from) h.flag = to; }
}
/** Убирает ссылки на удаляемые поля; возвращает число затронутых мест. */
export function dropRefs(schema: Schema, wf: Workflow, keys: string[]): number {
  let n = 0;
  const has = (f: string) => keys.includes(f.split('.')[0]);
  mapConds(schema, wf, (c) => { const items = c.items.filter((it) => { const h = has(it.field); if (h) n++; return !h; }); return items.length ? { ...c, items } : null; });
  for (const st of wf.steps) {
    for (const b of st.branches) { const l = b.assignees.length; b.assignees = b.assignees.filter((a) => !(a.t === 'field' && keys.includes(a.key || ''))); n += l - b.assignees.length; }
    if (st.fallback) st.fallback = st.fallback.filter((a) => !(a.t === 'field' && keys.includes(a.key || '')));
  }
  if (wf.hooks) {
    const l = wf.hooks.length;
    wf.hooks = wf.hooks.filter((h) => !keys.includes(h.period));
    n += l - wf.hooks.length;
    wf.hooks.forEach((h) => { if (h.deputy && keys.includes(h.deputy)) h.deputy = ''; if (h.flag && keys.includes(h.flag)) h.flag = ''; });
  }
  return n;
}

// ---------------------------------------------------------------- редактор условий

const CMPS_BY: Record<string, string[]> = {
  choice: ['eq', 'ne', 'in', 'empty', 'notempty'],
  bool: ['eq', 'empty', 'notempty'],
  num: ['eq', 'ne', 'gt', 'gte', 'lt', 'lte', 'empty', 'notempty'],
  date: ['eq', 'ne', 'gt', 'gte', 'lt', 'lte', 'empty', 'notempty'],
  text: ['eq', 'ne', 'contains', 'empty', 'notempty'],
  any: ['empty', 'notempty'],
};
function kindOf(f: Field | undefined, sub: string): string {
  if (!f) return 'text';
  if (f.type === 'period') return sub ? 'num' : 'any';
  if (['select', 'radio', 'checkboxes'].includes(f.type)) return 'choice';
  if (f.type === 'switch') return 'bool';
  if (f.type === 'number' || f.type === 'money') return 'num';
  if (f.type === 'date') return 'date';
  if (['user', 'department', 'file', 'table'].includes(f.type)) return 'any';
  return 'text';
}

export function CondEditor({ value, onChange, schema, exclude, empty = 'Условий нет — показывается всегда' }: { value?: Cond | null; onChange: (c: Cond | null) => void; schema: Schema; exclude?: string; empty?: string }) {
  const fields = allFields(schema).filter((f) => f.key !== exclude);
  const opts: { v: string; l: string }[] = [];
  for (const f of fields) {
    if (f.type === 'period') { opts.push({ v: f.key + '.days', l: f.label + ' — календарных дней' }, { v: f.key + '.workdays', l: f.label + ' — рабочих дней' }); } else opts.push({ v: f.key, l: f.label });
  }
  const c: Cond = value || { op: 'and', items: [] };
  const set = (items: CondItem[], op = c.op) => onChange(items.length ? { op, items } : null);
  const upd = (i: number, patch: Partial<CondItem>) => set(c.items.map((x, j) => (j === i ? { ...x, ...patch } : x)));
  const add = () => { const f = opts[0]; if (f) set([...c.items, { field: f.v, cmp: 'eq', value: '' }]); };
  return (
    <div className="rqCond">
      {c.items.length === 0 && <div className="muted small">{empty}</div>}
      {c.items.length > 1 && (
        <div className="small">Выполняются <Select className="rqInl" value={c.op || 'and'} onChange={(e) => set(c.items, e.target.value as any)}><option value="and">все условия</option><option value="or">любое из условий</option></Select></div>
      )}
      {c.items.map((it, i) => {
        const [base, sub] = it.field.split('.');
        const f = fields.find((x) => x.key === base);
        const kind = kindOf(f, sub || '');
        const cmps = CMPS_BY[kind];
        const needVal = it.cmp !== 'empty' && it.cmp !== 'notempty';
        const valueInput = !needVal ? null
          : kind === 'choice' && it.cmp === 'in' ? (
            <div className="rqOpts">{(f?.options || []).map((o) => { const cur: string[] = Array.isArray(it.value) ? it.value : []; return <label key={o.value} className={cx('rqOpt', cur.includes(o.value) && 'on')}><input type="checkbox" checked={cur.includes(o.value)} onChange={(e) => upd(i, { value: e.target.checked ? [...cur, o.value] : cur.filter((x) => x !== o.value) })} />{o.label}</label>; })}</div>
          ) : kind === 'choice' ? (
            <Select value={String(it.value ?? '')} onChange={(e) => upd(i, { value: e.target.value })}><option value="">— значение —</option>{(f?.options || []).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</Select>
          ) : kind === 'bool' ? (
            <Select value={String(!!it.value)} onChange={(e) => upd(i, { value: e.target.value === 'true' })}><option value="true">Да</option><option value="false">Нет</option></Select>
          ) : kind === 'num' ? <Input type="number" value={it.value ?? ''} onChange={(e) => upd(i, { value: e.target.value === '' ? '' : Number(e.target.value) })} />
          : kind === 'date' ? <Input type="date" value={it.value ?? ''} onChange={(e) => upd(i, { value: e.target.value })} />
          : <Input value={it.value ?? ''} onChange={(e) => upd(i, { value: e.target.value })} />;
        return (
          <div className="rqCondRow" key={i}>
            <Select value={it.field} onChange={(e) => { const nf = fields.find((x) => x.key === e.target.value.split('.')[0]); const k = kindOf(nf, e.target.value.split('.')[1] || ''); upd(i, { field: e.target.value, cmp: CMPS_BY[k].includes(it.cmp) ? it.cmp : CMPS_BY[k][0], value: '' }); }}>
              {!opts.some((o) => o.v === it.field) && <option value={it.field}>{it.field} (поле удалено)</option>}
              {opts.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
            </Select>
            <Select value={it.cmp} onChange={(e) => upd(i, { cmp: e.target.value, value: e.target.value === 'in' ? [] : '' })}>{cmps.map((k) => <option key={k} value={k}>{CMP_LABEL[k]}</option>)}</Select>
            <div className="rqCondVal">{valueInput}</div>
            <button type="button" className="btn ghost sm icon" aria-label="Убрать условие" onClick={() => set(c.items.filter((_, j) => j !== i))}><I.X size={15} /></button>
          </div>
        );
      })}
      <div><Btn size="sm" type="button" disabled={!opts.length} onClick={add}><I.Plus size={14} /> Условие</Btn>{!opts.length && <span className="tiny faint"> Сначала добавьте поля формы</span>}</div>
    </div>
  );
}

// ---------------------------------------------------------------- выбор субъекта (исполнитель / доступ)

export type SubjKind = 'user' | 'manager' | 'manager_up' | 'dept_head' | 'dept' | 'group' | 'responsible' | 'field' | 'all' | 'role';
export interface Picked { kind: SubjKind; id?: number; n?: number; key?: string; name?: string }
export const SUBJ_LABEL: Record<SubjKind, string> = {
  user: 'Конкретный сотрудник', manager: 'Непосредственный руководитель заявителя', manager_up: 'Руководитель заявителя на N уровней выше', dept_head: 'Руководитель подразделения…',
  dept: 'Все сотрудники подразделения…', group: 'Группа…', responsible: 'Ответственные за тип заявки', field: 'Сотрудник из поля формы…', all: 'Все сотрудники', role: 'Роль…',
};
export const ROLE_OPTS = [{ k: 'head', l: 'Руководители подразделений' }, { k: 'editor', l: 'Редакторы' }, { k: 'admin', l: 'Администраторы' }, { k: 'user', l: 'Все сотрудники (роль)' }];

function GroupSearch({ onPick }: { onPick: (g: { id: number; name: string }) => void }) {
  const [q, setQ] = useState('');
  const dq = useDebounced(q, 200);
  const { data } = useQuery<{ id: number; name: string }[]>('req:groups:' + dq, () => api.get('/api/requests/manage/groups?q=' + encodeURIComponent(dq)), { stale: 30000 });
  return (
    <div className="pick">
      <input className="sel" placeholder="Найти группу…" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="lst">{(data || []).map((g) => <div key={g.id} className="pickRow" onClick={() => onPick(g)}><I.Users size={16} /> <span className="small bold">{g.name}</span></div>)}{data?.length === 0 && <div className="small muted" style={{ padding: 12 }}>Групп не найдено</div>}</div>
    </div>
  );
}

export function SubjectAdder({ kinds, schema, onAdd }: { kinds: SubjKind[]; schema?: Schema; onAdd: (p: Picked) => void }) {
  const [kind, setKind] = useState<SubjKind | ''>('');
  const [n, setN] = useState(1);
  const { data: depts } = useDepartments();
  const userFields = schema ? allFields(schema).filter((f) => f.type === 'user') : [];
  const done = (p: Picked) => { onAdd(p); setKind(''); };
  const direct: SubjKind[] = ['manager', 'responsible', 'all'];
  return (
    <div className="rqAdder">
      <Select value={kind} onChange={(e) => { const k = e.target.value as SubjKind; if (direct.includes(k)) { done({ kind: k }); } else setKind(k); }} aria-label="Добавить">
        <option value="">+ Добавить…</option>
        {kinds.map((k) => <option key={k} value={k}>{SUBJ_LABEL[k]}</option>)}
      </Select>
      {kind === 'user' && <UserPicker single value={[]} onChange={(l) => l[0] && done({ kind: 'user', id: l[0].id, name: l[0].name })} />}
      {kind === 'manager_up' && <div className="row"><span className="small">Уровней выше:</span><Input type="number" min={1} max={10} value={n} onChange={(e) => setN(Math.max(1, Math.min(10, +e.target.value || 1)))} style={{ width: 80 }} /><Btn size="sm" kind="pri" onClick={() => done({ kind: 'manager_up', n })}>Добавить</Btn></div>}
      {(kind === 'dept' || kind === 'dept_head') && <DeptSelect value={null} allowEmpty={false} emptyLabel="Выберите подразделение…" onChange={(id) => id != null && done({ kind, id, name: (depts || []).find((d) => d.id === id)?.name })} />}
      {kind === 'group' && <GroupSearch onPick={(g) => done({ kind: 'group', id: g.id, name: g.name })} />}
      {kind === 'role' && <div className="rowW">{ROLE_OPTS.map((r) => <Btn key={r.k} size="sm" onClick={() => done({ kind: 'role', key: r.k, name: r.l })}>{r.l}</Btn>)}</div>}
      {kind === 'field' && (userFields.length ? <div className="rowW">{userFields.map((f) => <Btn key={f.key} size="sm" onClick={() => done({ kind: 'field', key: f.key, name: f.label })}>{f.label}</Btn>)}</div> : <div className="small muted">В форме нет полей типа «Сотрудник» — добавьте такое поле.</div>)}
    </div>
  );
}

export function asgLabel(a: { t: string; id?: number; n?: number; key?: string; name?: string }, schema?: Schema): string {
  switch (a.t) {
    case 'manager': return 'Руководитель заявителя';
    case 'manager_up': return `Руководитель заявителя +${a.n || 1} ур.`;
    case 'dept_head': return 'Руководитель: ' + (a.name || '#' + a.id);
    case 'dept': return 'Подразделение: ' + (a.name || '#' + a.id);
    case 'group': return 'Группа: ' + (a.name || '#' + a.id);
    case 'responsible': return 'Ответственные за заявку';
    case 'field': return 'Из поля: ' + ((schema && allFields(schema).find((f) => f.key === a.key)?.label) || a.key || '');
  }
  return a.name || 'Сотрудник #' + a.id;
}
