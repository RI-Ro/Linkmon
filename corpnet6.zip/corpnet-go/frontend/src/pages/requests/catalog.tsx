import React, { useMemo, useState } from 'react';
import * as I from '../../lib/icons';
import { Link } from '../../lib/router';
import { Empty, ErrorBox, Input, Loading } from '../../ui';
import { TypeIcon } from './icons';
import { useCatalog } from './lists';
import type { Catalog } from './lists';

type CT = Catalog['types'][number];

/** Каталог: типы заявок по категориям, «часто используемые», поиск. */
export function CatalogPage() {
  const q = useCatalog();
  const [s, setS] = useState('');
  const data = q.data;
  const groups = useMemo(() => {
    if (!data) return [];
    const ql = s.trim().toLowerCase();
    const list = data.types.filter((t) => !ql || t.name.toLowerCase().includes(ql) || t.description.toLowerCase().includes(ql));
    const out: { id: number; name: string; icon: string; color: string; items: CT[] }[] = [];
    for (const c of data.categories) {
      const items = list.filter((t) => t.category_id === c.id);
      if (items.length) out.push({ ...c, items });
    }
    const rest = list.filter((t) => !data.categories.some((c) => c.id === t.category_id));
    if (rest.length) out.push({ id: 0, name: 'Прочее', icon: 'file', color: '#286b9e', items: rest });
    return out;
  }, [data, s]);
  if (q.error && !data) return <ErrorBox error={q.error} retry={q.refetch} />;
  if (!data) return <Loading />;
  const freq = s ? [] : data.frequent.map((f) => data.types.find((t) => t.id === f.type_id)).filter(Boolean) as CT[];
  const slaText = (t: CT) => (t.sla_value ? `срок: ${t.sla_value} ${({ h: 'ч.', wh: 'раб. ч.', d: 'дн.', wd: 'раб. дн.' } as any)[t.sla_unit]}` : '');
  const tile = (t: CT) => (
    <Link key={t.id} to={`/requests/new/${t.id}`} className="rqTile">
      <TypeIcon name={t.icon} color={t.color} size={22} box={44} />
      <div style={{ minWidth: 0 }}>
        <div className="bold clamp2">{t.name}</div>
        <div className="tiny muted clamp2">{t.description.replace(/[#*_`>\-]/g, '').split('\n').find((x) => x.trim()) || ''}</div>
        {slaText(t) && <div className="tiny faint"><I.Clock size={12} /> {slaText(t)}</div>}
      </div>
    </Link>
  );
  return (
    <div className="stack">
      <div className="card pad rqHero">
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={{ fontSize: 24, fontWeight: 800 }}>Заявки и формы</h1>
          <p className="muted">Выберите тип заявки: справка, отпуск, обращение в ИТ, командировка и другие. Статус и согласование можно отслеживать в разделе «Мои заявки».</p>
        </div>
        <div className="rqSearch"><I.Search size={17} /><Input placeholder="Найти тип заявки…" value={s} onChange={(e) => setS(e.target.value)} aria-label="Поиск типа заявки" /></div>
      </div>
      {data.types.length === 0 && <div className="card"><Empty icon={I.FileText} title="Нет доступных типов заявок">{data.can_manage ? <Link to="/requests/manage/new" className="btn pri" style={{ marginTop: 10 }}>Создать тип заявки</Link> : 'Обратитесь к администратору.'}</Empty></div>}
      {data.types.length > 0 && groups.length === 0 && <div className="card"><Empty icon={I.Search} title="Ничего не найдено">Измените запрос.</Empty></div>}
      {freq.length > 0 && (
        <section className="stackS">
          <h2 className="rqH2"><I.Star size={18} /> Часто подаёте</h2>
          <div className="rqTiles">{freq.map(tile)}</div>
        </section>
      )}
      {groups.map((g) => (
        <section key={g.id} className="stackS">
          <h2 className="rqH2"><TypeIcon name={g.icon} color={g.color} size={16} box={28} /> {g.name}</h2>
          <div className="rqTiles">{g.items.map(tile)}</div>
        </section>
      ))}
    </div>
  );
}
