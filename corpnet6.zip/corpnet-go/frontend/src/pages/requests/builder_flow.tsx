import React, { useRef, useState } from 'react';
import * as I from '../../lib/icons';
import { cx } from '../../lib/util';
import { Btn, Field as UiField, Input, Select, UserPicker, useConfirm } from '../../ui';
import { CondEditor, SubjectAdder, allFields, asgLabel, clone } from './builder_common';
import type { Picked } from './builder_common';
import { MODE_LABEL, STEP_KIND, UNIT_LABEL, uid } from './model';
import type { Assignee, Branch, Schema, Step, Workflow } from './model';

const toAsg = (p: Picked): Assignee => {
  switch (p.kind) {
    case 'user': return { t: 'user', id: p.id, name: p.name };
    case 'manager_up': return { t: 'manager_up', n: p.n || 1 };
    case 'dept': case 'dept_head': case 'group': return { t: p.kind, id: p.id, name: p.name };
    case 'field': return { t: 'field', key: p.key, name: p.name };
  }
  return { t: p.kind };
};

function AsgList({ list, onChange, schema, kinds }: { list: Assignee[]; onChange: (l: Assignee[]) => void; schema: Schema; kinds?: any[] }) {
  return (
    <div className="stackS">
      <div className="tokens">
        {list.map((a, i) => <span className="token" key={i}>{asgLabel(a, schema)}<button type="button" aria-label="Убрать" onClick={() => onChange(list.filter((_, j) => j !== i))}><I.X size={14} /></button></span>)}
        {list.length === 0 && <span className="muted small">Исполнители не назначены</span>}
      </div>
      <SubjectAdder kinds={kinds || ['user', 'manager', 'manager_up', 'dept_head', 'dept', 'group', 'responsible', 'field']} schema={schema} onAdd={(p) => onChange([...list, toAsg(p)])} />
    </div>
  );
}

function StepEditor({ st, schema, onPatch }: { st: Step; schema: Schema; onPatch: (p: Partial<Step>) => void }) {
  const setBranch = (i: number, p: Partial<Branch>) => onPatch({ branches: st.branches.map((b, j) => (j === i ? { ...b, ...p } : b)) });
  const esc = st.escalate;
  const [userEsc, setUserEsc] = useState<{ id: number; name: string }[]>(esc?.user_id ? [{ id: esc.user_id, name: esc.name || '#' + esc.user_id }] : []);
  return (
    <div className="stack rqStepBody">
      <div className="rqG2">
        <UiField label="Название шага"><Input value={st.name} maxLength={120} onChange={(e) => onPatch({ name: e.target.value })} /></UiField>
        <UiField label="Что делает участник">
          <Select value={st.kind} onChange={(e) => onPatch({ kind: e.target.value as any })}>
            <option value="approve">Согласование (согласовать / отклонить / вернуть)</option><option value="execute">Исполнение (выполнить)</option><option value="inform">Ознакомление</option>
          </Select>
        </UiField>
      </div>

      <div className="rqSub">
        <div className="small bold">Ветки исполнителей{st.branches.length > 1 ? ' — выполняются параллельно, шаг завершается когда завершены все' : ''}</div>
        {st.branches.map((b, bi) => (
          <div className="rqBranch" key={bi}>
            <div className="rowW">
              <b className="small">{st.branches.length > 1 ? `Ветка ${bi + 1}` : 'Исполнители'}</b>
              {b.assignees.length > 1 && (
                <label className="small row">Решает: <Select className="rqInl" value={b.mode} onChange={(e) => setBranch(bi, { mode: e.target.value as any })}>{Object.entries(MODE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></label>
              )}
              <span className="sp" />
              {st.branches.length > 1 && <button type="button" className="btn ghost sm icon" aria-label="Удалить ветку" onClick={() => onPatch({ branches: st.branches.filter((_, j) => j !== bi) })}><I.Trash size={15} /></button>}
            </div>
            <AsgList list={b.assignees} onChange={(l) => setBranch(bi, { assignees: l })} schema={schema} />
          </div>
        ))}
        {st.branches.length < 6 && <div><Btn size="sm" onClick={() => onPatch({ branches: [...st.branches, { mode: 'any', assignees: [] }] })}><I.Plus size={14} /> Параллельная ветка</Btn></div>}
      </div>

      <div className="rqSub">
        <div className="small bold">Запасные исполнители</div>
        <div className="tiny muted">Если ни один основной исполнитель недоступен (заблокирован, в отпуске без заместителя), шаг уйдёт к ним. Замещение на время отпуска берётся из графика отпусков автоматически.</div>
        <AsgList list={st.fallback || []} onChange={(l) => onPatch({ fallback: l })} schema={schema} />
      </div>

      <div className="rqSub">
        <div className="small bold">Срок и напоминания</div>
        <div className="rqG3">
          <UiField label="Срок на шаг"><Input type="number" min={0} value={st.sla?.value ?? ''} placeholder="по умолч. типа" onChange={(e) => onPatch({ sla: e.target.value === '' ? null : { value: Math.max(0, +e.target.value), unit: st.sla?.unit || 'wd' } })} /></UiField>
          <UiField label="Единица"><Select value={st.sla?.unit || 'wd'} disabled={!st.sla} onChange={(e) => onPatch({ sla: { value: st.sla?.value || 0, unit: e.target.value } })}>{Object.entries(UNIT_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></UiField>
          <UiField label="Напомнить за, ч."><Input type="number" min={0} value={st.remind_before_h ?? ''} placeholder="по умолч." onChange={(e) => onPatch({ remind_before_h: e.target.value === '' ? null : +e.target.value })} /></UiField>
        </div>
        <UiField label="При просрочке">
          <Select value={esc?.to || ''} onChange={(e) => { const to = e.target.value; onPatch({ escalate: to ? { to, n: to === 'manager_up' ? esc?.n || 1 : undefined, user_id: to === 'user' ? esc?.user_id : undefined } : null }); }}>
            <option value="">Только уведомить о просрочке</option><option value="manager">Подключить руководителя исполнителя</option><option value="manager_up">Подключить руководителя на N уровней выше</option><option value="user">Подключить конкретного сотрудника</option>
          </Select>
        </UiField>
        {esc?.to === 'manager_up' && <UiField label="Уровней выше"><Input type="number" min={1} max={10} value={esc.n || 1} onChange={(e) => onPatch({ escalate: { ...esc, n: Math.max(1, Math.min(10, +e.target.value || 1)) } })} style={{ width: 100 }} /></UiField>}
        {esc?.to === 'user' && <UserPicker single value={userEsc} onChange={(l) => { setUserEsc(l); onPatch({ escalate: { to: 'user', user_id: l[0]?.id, name: l[0]?.name } }); }} placeholder="Кому передать при просрочке…" />}
      </div>

      <div className="rqSub">
        <div className="small bold">Этот шаг выполняется, если…</div>
        <CondEditor value={st.cond} onChange={(c) => onPatch({ cond: c })} schema={schema} empty="Условий нет — шаг выполняется всегда" />
      </div>
    </div>
  );
}

/** Редактор маршрута согласования. */
export function FlowEditor({ schema, workflow, onChange }: { schema: Schema; workflow: Workflow; onChange: (w: Workflow) => void }) {
  const [open, setOpen] = useState<number | null>(workflow.steps.length ? 0 : null);
  const drag = useRef<number | null>(null);
  const [over, setOver] = useState(-1);
  const [confirm, node] = useConfirm();
  const apply = (fn: (w: Workflow) => void) => { const w = clone(workflow); fn(w); onChange(w); };
  const move = (a: number, b: number) => { if (a === b || b < 0 || b >= workflow.steps.length) return; apply((w) => { const [x] = w.steps.splice(a, 1); w.steps.splice(b, 0, x); }); setOpen(b); };
  const add = (kind: 'approve' | 'execute' | 'inform') => {
    apply((w) => { w.steps.push({ id: 'st' + uid().slice(0, 5), name: kind === 'approve' ? 'Согласование' : kind === 'execute' ? 'Исполнение' : 'Ознакомление', kind, branches: [{ mode: 'any', assignees: kind === 'approve' ? [{ t: 'manager' }] : [{ t: 'responsible' }] }] }); });
    setOpen(workflow.steps.length);
  };
  async function remove(i: number) {
    if (!(await confirm(`Удалить шаг «${workflow.steps[i].name}»?`, { ok: 'Удалить' }))) return;
    apply((w) => { w.steps.splice(i, 1); }); setOpen(null);
  }
  const fields = allFields(schema);
  const periods = fields.filter((f) => f.type === 'period'), users = fields.filter((f) => f.type === 'user'), switches = fields.filter((f) => f.type === 'switch');
  const hook = workflow.hooks?.[0];
  return (
    <div className="stack">
      <div className="notice"><I.Info size={18} /><div>Заявка проходит шаги сверху вниз. На каждом шаге — одна или несколько <b>параллельных веток</b>, в ветке — один или несколько исполнителей. Если шагов нет, заявка сразу получает статус «Согласована».</div></div>
      <div className="rqFlow">
        <div className="rqFlowEnd start"><I.Send size={14} /> Заявитель подаёт заявку</div>
        {workflow.steps.map((st, i) => {
          const on = open === i;
          return (
            <div key={st.id + i} className={cx('card rqStep', on && 'open', over === i && 'over')}
              onDragOver={(e) => { if (drag.current !== null) { e.preventDefault(); setOver(i); } }} onDrop={(e) => { e.preventDefault(); const f = drag.current; drag.current = null; setOver(-1); if (f !== null) move(f, i); }}>
              <div className="rqStepHead" onClick={() => setOpen(on ? null : i)}>
                <span draggable className="rqHandle" onClick={(e) => e.stopPropagation()} onDragStart={(e) => { drag.current = i; e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', 'step'); }} onDragEnd={() => { drag.current = null; setOver(-1); }} title="Перетащить шаг">
                  <svg viewBox="0 0 10 16" width="10" height="16" fill="currentColor" className="rqGrip">{[3, 8, 13].map((y) => <React.Fragment key={y}><circle cx="2" cy={y} r="1.3" /><circle cx="8" cy={y} r="1.3" /></React.Fragment>)}</svg>
                </span>
                <span className="rqStepNo">{i + 1}</span>
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div className="bold clip">{st.name || '(без названия)'} <span className={'rqKind ' + st.kind}>{STEP_KIND[st.kind]}</span></div>
                  <div className="tiny muted clip">{st.branches.map((b) => b.assignees.map((a) => asgLabel(a, schema)).join(', ') || 'нет исполнителей').join(' ‖ ')}{st.sla ? ` · срок ${st.sla.value} ${UNIT_LABEL[st.sla.unit]}` : ''}{st.cond?.items?.length ? ' · по условию' : ''}</div>
                </div>
                <button type="button" className="btn ghost sm icon" aria-label="Выше" disabled={i === 0} onClick={(e) => { e.stopPropagation(); move(i, i - 1); }}><I.ChevronUp size={16} /></button>
                <button type="button" className="btn ghost sm icon" aria-label="Ниже" disabled={i === workflow.steps.length - 1} onClick={(e) => { e.stopPropagation(); move(i, i + 1); }}><I.ChevronDown size={16} /></button>
                <button type="button" className="btn ghost sm icon" aria-label="Удалить шаг" onClick={(e) => { e.stopPropagation(); remove(i); }}><I.Trash size={16} /></button>
              </div>
              {on && <StepEditor st={st} schema={schema} onPatch={(p) => apply((w) => { Object.assign(w.steps[i], p); for (const k of Object.keys(w.steps[i])) if ((w.steps[i] as any)[k] === null && k !== 'cond') delete (w.steps[i] as any)[k]; })} />}
            </div>
          );
        })}
        <div className="rqFlowAdd">
          <Btn onClick={() => add('approve')}><I.UserCheck size={16} /> Согласование</Btn>
          <Btn onClick={() => add('execute')}><I.Briefcase size={16} /> Исполнение</Btn>
          <Btn onClick={() => add('inform')}><I.Eye size={16} /> Ознакомление</Btn>
        </div>
        <div className="rqFlowEnd end"><I.CheckCheck size={14} /> {workflow.steps.length ? 'Заявка выполнена / согласована' : 'Без согласования: сразу «Согласована»'}</div>
      </div>

      <div className="card pad stack">
        <div><h3 style={{ fontSize: 16, fontWeight: 700 }}>Действие после завершения</h3><div className="muted small">Заявка на отпуск после согласования может автоматически создавать запись в графике отпусков.</div></div>
        {!hook ? (
          <div><Btn disabled={!periods.length} onClick={() => apply((w) => { w.hooks = [{ action: 'vacation', period: periods[0].key, deputy: '', flag: '' }]; })}><I.Calendar size={16} /> Добавлять отпуск в график отпусков</Btn>{!periods.length && <div className="tiny faint" style={{ marginTop: 6 }}>Добавьте в форму поле «Период дат».</div>}</div>
        ) : (
          <div className="stackS">
            <div className="rqG3">
              <UiField label="Поле с периодом"><Select value={hook.period} onChange={(e) => apply((w) => { w.hooks![0].period = e.target.value; })}>{periods.map((f) => <option key={f.key} value={f.key}>{f.label}</option>)}{!periods.some((f) => f.key === hook.period) && <option value={hook.period}>{hook.period}</option>}</Select></UiField>
              <UiField label="Заместитель (поле «Сотрудник»)"><Select value={hook.deputy || ''} onChange={(e) => apply((w) => { w.hooks![0].deputy = e.target.value; })}><option value="">— не указывать —</option>{users.map((f) => <option key={f.key} value={f.key}>{f.label}</option>)}</Select></UiField>
              <UiField label="Добавлять, только если включено"><Select value={hook.flag || ''} onChange={(e) => apply((w) => { w.hooks![0].flag = e.target.value; })}><option value="">— всегда —</option>{switches.map((f) => <option key={f.key} value={f.key}>{f.label}</option>)}</Select></UiField>
            </div>
            <div className="tiny muted">Запись создаётся для заявителя, если он руководитель, ведущий график (иначе пропускается). Дубликаты не создаются.</div>
            <div><Btn size="sm" kind="ghost" onClick={() => apply((w) => { delete w.hooks; })}>Убрать действие</Btn></div>
          </div>
        )}
      </div>
      {node}
    </div>
  );
}
