import React, { useRef, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { useQuery, invalidate } from '../../lib/query';
import { Link, navigate } from '../../lib/router';
import { toast, useStore, isAdmin } from '../../lib/store';
import { cx, fmtShort } from '../../lib/util';
import { Badge, Btn, Empty, ErrorBox, Field as UiField, Input, Loading, Modal, useConfirm } from '../../ui';
import { ICON_NAMES, TYPE_ICONS, TypeIcon } from './icons';

export const useCategories = () => useQuery<any[]>('req:cats', () => api.get('/api/requests/categories'), { stale: 30000 });

export function IconColor({ icon, color, onIcon, onColor }: { icon: string; color: string; onIcon: (v: string) => void; onColor: (v: string) => void }) {
  return (
    <div className="stackS">
      <div className="rqIcons">
        {ICON_NAMES.map((n) => { const Ic = TYPE_ICONS[n]; return <button key={n} type="button" className={cx(icon === n && 'on')} aria-label={n} title={n} onClick={() => onIcon(n)}><Ic size={18} /></button>; })}
      </div>
      <div className="row"><input type="color" value={/^#[0-9a-f]{6}$/i.test(color) ? color : '#286b9e'} onChange={(e) => onColor(e.target.value)} aria-label="Цвет" className="rqColor" /><span className="muted small">{color}</span></div>
    </div>
  );
}

function CategoriesDialog({ onClose }: { onClose: () => void }) {
  const cats = useCategories();
  const me = useStore((s) => s.me);
  const [edit, setEdit] = useState<any>(null);
  const [err, setErr] = useState('');
  const [confirm, node] = useConfirm();
  async function save() {
    setErr('');
    try {
      if (edit.id) await api.put('/api/requests/manage/categories/' + edit.id, edit); else await api.post('/api/requests/manage/categories', edit);
      invalidate('req:'); setEdit(null);
    } catch (e) { setErr(errMsg(e)); }
  }
  async function del(c: any) {
    if (!(await confirm(`Удалить категорию «${c.name}»?`, { text: 'Типы заявок останутся, но окажутся без категории.', ok: 'Удалить' }))) return;
    try { await api.del('/api/requests/manage/categories/' + c.id); invalidate('req:'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  return (
    <Modal title="Категории заявок" onClose={onClose} footer={<Btn onClick={onClose}>Закрыть</Btn>}>
      {edit ? (
        <div className="stack">
          <UiField label="Название"><Input value={edit.name} maxLength={80} onChange={(e) => setEdit({ ...edit, name: e.target.value })} autoFocus /></UiField>
          <UiField label="Значок и цвет"><IconColor icon={edit.icon} color={edit.color} onIcon={(v) => setEdit({ ...edit, icon: v })} onColor={(v) => setEdit({ ...edit, color: v })} /></UiField>
          {err && <div className="err">{err}</div>}
          <div className="rowW"><Btn kind="pri" onClick={save}>Сохранить</Btn><Btn onClick={() => { setEdit(null); setErr(''); }}>Отмена</Btn></div>
        </div>
      ) : (
        <>
          <div className="stackS">
            {(cats.data || []).map((c) => (
              <div className="rqCatRow" key={c.id}><TypeIcon name={c.icon} color={c.color} size={16} box={30} /><span className="grow bold">{c.name}</span>
                <button className="btn ghost sm icon" aria-label="Изменить" onClick={() => setEdit({ ...c })}><I.Edit size={16} /></button>
                {isAdmin(me) && <button className="btn ghost sm icon" aria-label="Удалить" onClick={() => del(c)}><I.Trash size={16} /></button>}
              </div>
            ))}
            {cats.data?.length === 0 && <p className="muted">Категорий пока нет.</p>}
          </div>
          <div><Btn onClick={() => setEdit({ name: '', icon: 'file', color: '#286b9e' })}><I.Plus size={16} /> Добавить категорию</Btn></div>
        </>
      )}
      {node}
    </Modal>
  );
}

/** Список типов заявок, которыми пользователь вправе управлять. */
export function ManagePage() {
  const q = useQuery<any[]>('req:manage', () => api.get('/api/requests/manage/types'), { stale: 0 });
  const cats = useCategories();
  const me = useStore((s) => s.me);
  const [catDlg, setCatDlg] = useState(false);
  const [confirm, node] = useConfirm();
  const fileRef = useRef<HTMLInputElement>(null);
  const [showArch, setShowArch] = useState(false);
  const catName = (id: number | null) => cats.data?.find((c) => c.id === id)?.name || '—';
  async function dup(t: any) {
    try { const r = await api.post(`/api/requests/manage/types/${t.id}/duplicate`, {}); invalidate('req:'); navigate('/requests/manage/' + r.id); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function del(t: any) {
    if (!(await confirm(`Удалить тип «${t.name}»?`, { text: t.requests > 0 ? 'Есть поданные заявки — тип будет перемещён в архив (заявки сохранятся).' : 'Тип будет удалён без возможности восстановления.', ok: 'Удалить' }))) return;
    try { const r = await api.del(`/api/requests/manage/types/${t.id}`); invalidate('req:'); if (r?.archived) toast({ title: 'Тип перемещён в архив', kind: 'info' }); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function toggle(t: any) {
    try {
      const full = await api.get(`/api/requests/manage/types/${t.id}`);
      const x = full.type;
      await api.put(`/api/requests/manage/types/${t.id}`, { ...x, active: !t.active, archived: false, acl: full.acl, schema: x.schema, workflow: x.workflow });
      invalidate('req:');
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function exportJson(t: any) {
    try {
      const r = await api.get(`/api/requests/manage/types/${t.id}/export`);
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([JSON.stringify(r, null, 2)], { type: 'application/json' }));
      a.download = `request-type-${t.id}.json`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function importJson(f: File | undefined) {
    if (!f) return;
    try {
      const body = JSON.parse(await f.text());
      const r = await api.post('/api/requests/manage/import', body);
      invalidate('req:');
      if (r.warnings?.length) toast({ title: 'Импортировано с замечаниями', body: r.warnings.slice(0, 3).join('\n'), kind: 'info' });
      navigate('/requests/manage/' + r.id);
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  if (q.error && !q.data) return <ErrorBox error={q.error} retry={q.refetch} />;
  if (!q.data) return <Loading />;
  const list = q.data.filter((t) => showArch || !t.archived);
  return (
    <div className="card">
      <div className="rqBar">
        <div className="grow"><h2 style={{ fontSize: 18, fontWeight: 700 }}>Типы заявок</h2><div className="muted small">Форма, маршрут согласования, ответственные и область видимости настраиваются для каждого типа отдельно.</div></div>
        <label className="chk small"><input type="checkbox" checked={showArch} onChange={(e) => setShowArch(e.target.checked)} /> Архив</label>
        {(me?.role === 'admin' || me?.role === 'editor') && <Btn onClick={() => setCatDlg(true)}><I.Folder size={16} /> Категории</Btn>}
        <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={(e) => { importJson(e.target.files?.[0]); e.target.value = ''; }} />
        <Btn onClick={() => fileRef.current?.click()}><I.Upload size={16} /> Импорт</Btn>
        <Link to="/requests/manage/new" className="btn pri"><I.Plus size={16} /> Новый тип</Link>
      </div>
      {list.length === 0 ? <Empty icon={I.FileText} title="Типов заявок пока нет">Создайте первый тип или импортируйте его из файла.</Empty> : (
        <div className="tblW">
          <table className="tbl">
            <thead><tr><th>Тип</th><th>Категория</th><th>Область</th><th>Версия</th><th>Заявок</th><th>Статус</th><th /></tr></thead>
            <tbody>
              {list.map((t) => (
                <tr key={t.id}>
                  <td><Link to={`/requests/manage/${t.id}`} className="row"><TypeIcon name={t.icon} color={t.color} size={16} box={32} /><span className="bold">{t.name}</span></Link></td>
                  <td className="small">{catName(t.category_id)}</td>
                  <td className="small">{t.department || <span className="faint">вся компания</span>}</td>
                  <td className="small">v{t.version}<div className="tiny faint">{fmtShort(t.updated_at)}</div></td>
                  <td className="small">{t.requests}{t.open_requests > 0 && <span className="tiny muted"> · в работе {t.open_requests}</span>}</td>
                  <td>{t.archived ? <Badge>архив</Badge> : t.active ? <Badge kind="ok">опубликован</Badge> : <Badge kind="warn">скрыт</Badge>}</td>
                  <td className="act">
                    <Link to={`/requests/manage/${t.id}`} className="btn ghost sm icon" aria-label="Редактировать" title="Редактировать"><I.Edit size={16} /></Link>
                    {!t.archived && <button className="btn ghost sm icon" aria-label={t.active ? 'Скрыть' : 'Опубликовать'} title={t.active ? 'Скрыть из каталога' : 'Опубликовать'} onClick={() => toggle(t)}>{t.active ? <I.EyeOff size={16} /> : <I.Eye size={16} />}</button>}
                    <button className="btn ghost sm icon" aria-label="Дублировать" title="Дублировать" onClick={() => dup(t)}><I.Copy size={16} /></button>
                    <button className="btn ghost sm icon" aria-label="Экспорт в файл" title="Экспорт в JSON" onClick={() => exportJson(t)}><I.Download size={16} /></button>
                    <button className="btn ghost sm icon" aria-label="Удалить" title="Удалить" onClick={() => del(t)}><I.Trash size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {catDlg && <CategoriesDialog onClose={() => setCatDlg(false)} />}
      {node}
    </div>
  );
}
