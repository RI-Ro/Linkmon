import React from 'react';
import * as I from '../../lib/icons';
import { api } from '../../lib/api';
import { useQuery } from '../../lib/query';
import { Link, matchPath, useLocation, useTitle } from '../../lib/router';
import { cx } from '../../lib/util';
import { Empty } from '../../ui';
import './requests.css';
import { CatalogPage } from './catalog';
import { RequestsList, useCatalog } from './lists';
import { SubmitPage } from './submit';
import { CardPage } from './card';
import { ManagePage } from './manage';
import { BuilderPage } from './builder';

export function useReqCounts() {
  return useQuery<{ inbox: number; approve: number; assigned: number; rework: number; active: number }>('req:counts', () => api.get('/api/requests/counts'), { stale: 20000 });
}

/** Раздел «Заявки»: каталог, мои, «на согласовании у меня», «мне назначено», все по типу, конструктор. */
export function RequestsPage() {
  const { path: raw } = useLocation();
  const path = raw.replace(/\/+$/, '') || '/';
  const cat = useCatalog();
  const cnt = useReqCounts();
  const c = cnt.data;
  let m: Record<string, string> | null;
  let body: React.ReactNode = null;
  let tab = '';
  let title = 'Заявки';
  if (path === '/requests') { tab = 'catalog'; body = <CatalogPage />; }
  else if (path === '/requests/mine') { tab = 'mine'; title = 'Мои заявки'; body = <RequestsList scope="mine" />; }
  else if (path === '/requests/inbox') { tab = 'inbox'; title = 'На согласовании у меня'; body = <RequestsList scope="inbox" kind="approve" />; }
  else if (path === '/requests/assigned') { tab = 'assigned'; title = 'Мне назначено'; body = <RequestsList scope="inbox" kind="execute,inform" />; }
  else if (path === '/requests/done') { tab = 'done'; title = 'Прошли через меня'; body = <RequestsList scope="participated" />; }
  else if (path === '/requests/all') { tab = 'all'; title = 'Все заявки типа'; body = <RequestsList scope="type" />; }
  else if (path === '/requests/manage') { tab = 'manage'; title = 'Конструктор заявок'; body = <ManagePage />; }
  else if (path === '/requests/manage/new') body = <BuilderPage key="new" />;
  else if ((m = matchPath('/requests/manage/:id', path)) && /^\d+$/.test(m.id)) body = <BuilderPage key={m.id} id={+m.id} />;
  else if ((m = matchPath('/requests/new/:id', path)) && /^\d+$/.test(m.id)) body = <SubmitPage key={'n' + m.id} typeId={+m.id} />;
  else if ((m = matchPath('/requests/:id/edit', path)) && /^\d+$/.test(m.id)) body = <SubmitPage key={'e' + m.id} requestId={+m.id} />;
  else if ((m = matchPath('/requests/:id', path)) && /^\d+$/.test(m.id)) body = <CardPage key={m.id} id={+m.id} />;
  else body = <div className="card"><Empty icon={I.Search} title="Страница не найдена"><Link to="/requests">В раздел «Заявки»</Link></Empty></div>;
  useTitle(title);

  const tabs: { id: string; to: string; label: string; icon: any; n?: number; hot?: boolean }[] = [
    { id: 'catalog', to: '/requests', label: 'Новая заявка', icon: I.Plus },
    { id: 'mine', to: '/requests/mine', label: 'Мои заявки', icon: I.FileText, n: c?.rework, hot: true },
    { id: 'inbox', to: '/requests/inbox', label: 'На согласовании у меня', icon: I.UserCheck, n: c?.approve, hot: true },
    { id: 'assigned', to: '/requests/assigned', label: 'Мне назначено', icon: I.Briefcase, n: c?.assigned, hot: true },
  ];
  if (cat.data?.view_types.length) tabs.push({ id: 'all', to: '/requests/all', label: 'Все по типу', icon: I.Layers });
  if (cat.data?.can_manage) tabs.push({ id: 'manage', to: '/requests/manage', label: 'Конструктор', icon: I.Settings });
  return (
    <div className="rqPage">
      {tab && (
        <nav className="rqTabs" aria-label="Разделы заявок">
          {tabs.map((t) => (
            <Link key={t.id} to={t.to} className={cx(tab === t.id && 'on')}>
              <t.icon size={17} /> {t.label}{!!t.n && <span className={cx('rqCnt', t.hot && 'hot')}>{t.n > 99 ? '99+' : t.n}</span>}
            </Link>
          ))}
          {tab === 'done' ? null : <Link to="/requests/done" className="rqTabMy" title="Заявки, через которые вы проходили как согласующий или исполнитель"><I.CheckCheck size={16} /> Прошли через меня</Link>}
        </nav>
      )}
      {body}
    </div>
  );
}
