import React, { useRef, useState } from 'react';
import * as I from '../../lib/icons';
import { toast } from '../../lib/store';
import { cx } from '../../lib/util';
import { Btn, Field as UiField, Input, Select, Switch, Textarea, useConfirm } from '../../ui';
import { CondEditor, clone, dropRefs, renameKey } from './builder_common';
import { FIELD_TYPES, PROFILE_DEFAULTS, isDisplay, keyFromLabel, newKey, typeLabel, uid } from './model';
import type { Field, Opt, Schema, Section, Workflow } from './model';

const TYPE_ICON: Record<string, any> = {
  text: I.Edit, textarea: I.ScrollText, number: I.Hash, money: I.Tag, phone: I.Phone, email: I.Mail, date: I.Calendar, period: I.Calendar, time: I.Clock,
  select: I.ChevronDown, radio: I.Check, checkboxes: I.CheckCheck, switch: I.Zap, user: I.Users, department: I.Building, file: I.Paperclip, table: I.Sheet,
  heading: I.Heading, divider: I.More, note: I.Info,
};
const HAS_OPTS = ['select', 'radio', 'checkboxes'];

function Grip() {
  return <svg className="rqGrip" viewBox="0 0 10 16" width="10" height="16" fill="currentColor" aria-hidden="true">{[3, 8, 13].map((y) => <React.Fragment key={y}><circle cx="2" cy={y} r="1.3" /><circle cx="8" cy={y} r="1.3" /></React.Fragment>)}</svg>;
}

function makeField(schema: Schema, type: string): Field {
  const label = typeLabel(type);
  const f: Field = { key: isDisplay(type) ? '' : newKey(schema, type), type, label, width: '1' };
  if (HAS_OPTS.includes(type)) f.options = [{ value: 'opt1', label: 'Вариант 1' }, { value: 'opt2', label: 'Вариант 2' }];
  if (type === 'table') { f.columns = [{ key: 'name', type: 'text', label: 'Наименование', required: true }, { key: 'qty', type: 'number', label: 'Кол-во' }]; f.max_rows = 20; }
  if (type === 'file') f.max_files = 5;
  if (type === 'note') f.label = 'Текст пояснения (поддерживается Markdown)';
  if (type === 'divider') f.label = '';
  if (!isDisplay(type)) (f as any)._auto = true;
  return f;
}

function OptionsEditor({ opts, onChange }: { opts: Opt[]; onChange: (o: Opt[]) => void }) {
  const [bulk, setBulk] = useState(false);
  const [txt, setTxt] = useState('');
  const set = (i: number, label: string) => onChange(opts.map((o, j) => (j === i ? { ...o, label } : o)));
  const setVal = (i: number, value: string) => onChange(opts.map((o, j) => (j === i ? { ...o, value } : o)));
  const nextVal = () => { let i = opts.length + 1; while (opts.some((o) => o.value === 'opt' + i)) i++; return 'opt' + i; };
  return (
    <div className="stackS">
      {bulk ? (
        <>
          <Textarea rows={6} value={txt} placeholder="Каждый вариант с новой строки" onChange={(e) => setTxt(e.target.value)} />
          <div className="rowW"><Btn size="sm" kind="pri" onClick={() => {
            const lines = txt.split('\n').map((x) => x.trim()).filter(Boolean).slice(0, 200);
            const out: Opt[] = lines.map((l, i) => ({ value: opts.find((o) => o.label === l)?.value || 'opt' + (i + 1), label: l }));
            const seen = new Set<string>(); out.forEach((o, i) => { while (seen.has(o.value)) o.value = 'opt' + (i + 1) + '_' + uid().slice(0, 3); seen.add(o.value); });
            onChange(out); setBulk(false);
          }}>Применить</Btn><Btn size="sm" onClick={() => setBulk(false)}>Отмена</Btn></div>
        </>
      ) : (
        <>
          {opts.map((o, i) => (
            <div className="rqOptRow" key={i}>
              <Input value={o.label} placeholder="Название варианта" onChange={(e) => set(i, e.target.value)} />
              <Input value={o.value} className="rqOptVal" title="Значение, которое сохраняется в заявке и используется в условиях" onChange={(e) => setVal(i, e.target.value.replace(/\s+/g, '_'))} />
              <button type="button" className="btn ghost sm icon" aria-label="Выше" disabled={i === 0} onClick={() => { const n = [...opts]; [n[i - 1], n[i]] = [n[i], n[i - 1]]; onChange(n); }}><I.ChevronUp size={15} /></button>
              <button type="button" className="btn ghost sm icon" aria-label="Убрать" onClick={() => onChange(opts.filter((_, j) => j !== i))}><I.X size={15} /></button>
            </div>
          ))}
          <div className="rowW"><Btn size="sm" onClick={() => onChange([...opts, { value: nextVal(), label: 'Вариант ' + (opts.length + 1) }])}><I.Plus size={14} /> Вариант</Btn><Btn size="sm" kind="ghost" onClick={() => { setTxt(opts.map((o) => o.label).join('\n')); setBulk(true); }}>Списком</Btn></div>
        </>
      )}
    </div>
  );
}

function ColumnsEditor({ cols, onChange }: { cols: Field[]; onChange: (c: Field[]) => void }) {
  const types = FIELD_TYPES.filter((t) => ['text', 'number', 'money', 'date', 'select', 'switch', 'user', 'phone', 'email', 'textarea'].includes(t.id));
  const set = (i: number, patch: Partial<Field>) => onChange(cols.map((c, j) => (j === i ? { ...c, ...patch } : c)));
  return (
    <div className="stackS">
      {cols.map((c, i) => (
        <div className="rqColRow" key={i}>
          <Input value={c.label} placeholder="Название колонки" onChange={(e) => { const label = e.target.value; const auto = !c.key || c.key === keyFromCol(c.label, cols, i); set(i, { label, ...(auto ? { key: keyFromCol(label, cols, i) } : {}) }); }} />
          <Select value={c.type} onChange={(e) => set(i, { type: e.target.value, ...(e.target.value === 'select' && !c.options?.length ? { options: [{ value: 'opt1', label: 'Вариант 1' }] } : {}) })}>{types.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}</Select>
          <label className="chk small"><input type="checkbox" checked={!!c.required} onChange={(e) => set(i, { required: e.target.checked })} /> обяз.</label>
          <button type="button" className="btn ghost sm icon" aria-label="Убрать колонку" disabled={cols.length <= 1} onClick={() => onChange(cols.filter((_, j) => j !== i))}><I.X size={15} /></button>
          {c.type === 'select' && <div style={{ gridColumn: '1 / -1' }}><OptionsEditor opts={c.options || []} onChange={(o) => set(i, { options: o })} /></div>}
        </div>
      ))}
      <div><Btn size="sm" onClick={() => onChange([...cols, { key: keyFromCol('col', cols, -1) , type: 'text', label: 'Колонка ' + (cols.length + 1) }])} disabled={cols.length >= 12}><I.Plus size={14} /> Колонка</Btn></div>
    </div>
  );
}
function keyFromCol(label: string, cols: Field[], self: number): string {
  const TR: Record<string, string> = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'c', ч: 'ch', ш: 'sh', щ: 'sch', ы: 'y', э: 'e', ю: 'yu', я: 'ya' };
  let k = label.toLowerCase().split('').map((c) => TR[c] ?? c).join('').replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 24);
  if (!/^[a-z]/.test(k)) k = 'c_' + k;
  const used = new Set(cols.filter((_, i) => i !== self).map((c) => c.key));
  let out = k, i = 2;
  while (used.has(out)) out = k + '_' + i++;
  return out;
}

function FieldProps({ f, schema, onPatch, onRename }: { f: Field; schema: Schema; onPatch: (p: Partial<Field>) => void; onRename: (k: string) => void }) {
  const t = f.type;
  const num = (v: string) => (v === '' ? undefined : Number(v));
  const display = isDisplay(t);
  const [keyEdit, setKeyEdit] = useState(false);
  const stringOrToday = (v: any) => (v === 'today' ? 'today' : v || '');
  return (
    <div className="stack rqProps">
      <div className="rqG2">
        <UiField label="Тип поля">
          <Select value={t} onChange={(e) => { const nt = e.target.value; const p: Partial<Field> = { type: nt }; if (HAS_OPTS.includes(nt) && !f.options?.length) p.options = [{ value: 'opt1', label: 'Вариант 1' }]; if (nt === 'table' && !f.columns?.length) p.columns = [{ key: 'name', type: 'text', label: 'Наименование' }]; onPatch(p); }}>
            {['Ввод', 'Дата и время', 'Выбор', 'Справочники', 'Структура', 'Оформление'].map((g) => <optgroup key={g} label={g}>{FIELD_TYPES.filter((x) => x.group === g).map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}</optgroup>)}
          </Select>
        </UiField>
        <UiField label="Ширина">
          <Select value={f.width || '1'} onChange={(e) => onPatch({ width: e.target.value as any })}><option value="1">Вся строка</option><option value="1/2">Половина</option><option value="1/3">Треть</option></Select>
        </UiField>
      </div>
      {t !== 'divider' && <UiField label={t === 'note' ? 'Текст пояснения' : t === 'heading' ? 'Заголовок' : 'Подпись поля'}>{t === 'note' ? <Textarea rows={3} value={f.label} onChange={(e) => onPatch({ label: e.target.value })} /> : <Input value={f.label} maxLength={300} onChange={(e) => onPatch({ label: e.target.value })} />}</UiField>}
      {!display && (
        <UiField label="Ключ поля" hint="Латиница, цифры и «_». Используется в условиях, маршруте и выгрузке CSV. Менять у работающего типа не рекомендуется.">
          {keyEdit ? <Input value={f.key} maxLength={40} onChange={(e) => onRename(e.target.value.replace(/[^A-Za-z0-9_]/g, '').slice(0, 40))} onBlur={() => setKeyEdit(false)} autoFocus />
            : <div className="row"><code className="rqCode">{f.key}</code><Btn size="sm" kind="ghost" onClick={() => setKeyEdit(true)}>Изменить</Btn></div>}
        </UiField>
      )}
      {(t === 'note' || t === 'heading') && <UiField label="Дополнительный текст"><Input value={f.hint || ''} onChange={(e) => onPatch({ hint: e.target.value })} /></UiField>}
      {!display && <UiField label="Подсказка под полем"><Input value={f.hint || ''} maxLength={2000} onChange={(e) => onPatch({ hint: e.target.value })} /></UiField>}
      {!display && !['switch', 'radio', 'checkboxes', 'file', 'table', 'period'].includes(t) && <UiField label="Текст-заполнитель (placeholder)"><Input value={f.placeholder || ''} maxLength={200} onChange={(e) => onPatch({ placeholder: e.target.value })} /></UiField>}
      {!display && (
        <div className="stackS">
          <Switch checked={!!f.required} onChange={(v) => onPatch({ required: v })} label={<span className="small">Обязательное поле</span>} />
          {!f.required && (
            <div className="rqSub">
              <div className="small bold">Обязательно, если…</div>
              <CondEditor value={f.required_if} onChange={(c) => onPatch({ required_if: c })} schema={schema} exclude={f.key} empty="Не задано — поле необязательное" />
            </div>
          )}
        </div>
      )}
      {HAS_OPTS.includes(t) && <UiField label="Варианты"><OptionsEditor opts={f.options || []} onChange={(o) => onPatch({ options: o })} /></UiField>}
      {t === 'table' && <><UiField label="Колонки таблицы"><ColumnsEditor cols={f.columns || []} onChange={(c) => onPatch({ columns: c })} /></UiField>
        <div className="rqG2"><UiField label="Мин. строк"><Input type="number" min={0} value={f.min_rows ?? ''} onChange={(e) => onPatch({ min_rows: num(e.target.value) })} /></UiField><UiField label="Макс. строк"><Input type="number" min={1} value={f.max_rows ?? ''} onChange={(e) => onPatch({ max_rows: num(e.target.value) })} /></UiField></div></>}
      {(t === 'text' || t === 'textarea') && (
        <>
          <div className="rqG2"><UiField label="Мин. длина"><Input type="number" min={0} value={f.min_len ?? ''} onChange={(e) => onPatch({ min_len: num(e.target.value) })} /></UiField><UiField label="Макс. длина"><Input type="number" min={1} value={f.max_len ?? ''} onChange={(e) => onPatch({ max_len: num(e.target.value) })} /></UiField></div>
          {t === 'text' && <div className="rqG2"><UiField label="Шаблон (регулярное выражение)" hint="Например: ^\d{10}$"><Input value={f.pattern || ''} onChange={(e) => onPatch({ pattern: e.target.value })} /></UiField><UiField label="Сообщение при несоответствии"><Input value={f.pattern_msg || ''} onChange={(e) => onPatch({ pattern_msg: e.target.value })} /></UiField></div>}
        </>
      )}
      {(t === 'number' || t === 'money') && <div className="rqG3"><UiField label="Минимум"><Input type="number" value={f.min ?? ''} onChange={(e) => onPatch({ min: num(e.target.value) })} /></UiField><UiField label="Максимум"><Input type="number" value={f.max ?? ''} onChange={(e) => onPatch({ max: num(e.target.value) })} /></UiField>{t === 'number' && <UiField label="Единица"><Input value={f.unit || ''} maxLength={20} placeholder="шт., кг…" onChange={(e) => onPatch({ unit: e.target.value })} /></UiField>}</div>}
      {t === 'date' && <div className="rqG2"><UiField label="Не раньше"><div className="stackS"><Input type="date" value={f.min === 'today' ? '' : f.min || ''} onChange={(e) => onPatch({ min: e.target.value || undefined })} disabled={f.min === 'today'} /><label className="chk small"><input type="checkbox" checked={f.min === 'today'} onChange={(e) => onPatch({ min: e.target.checked ? 'today' : undefined })} /> не раньше сегодняшнего дня</label></div></UiField><UiField label="Не позже"><div className="stackS"><Input type="date" value={f.max === 'today' ? '' : f.max || ''} onChange={(e) => onPatch({ max: e.target.value || undefined })} disabled={f.max === 'today'} /><label className="chk small"><input type="checkbox" checked={f.max === 'today'} onChange={(e) => onPatch({ max: e.target.checked ? 'today' : undefined })} /> не позже сегодняшнего дня</label></div></UiField></div>}
      {t === 'period' && <div className="rqG2"><UiField label="Начало не раньше"><div className="stackS"><Input type="date" value={stringOrToday(f.min) === 'today' ? '' : f.min || ''} onChange={(e) => onPatch({ min: e.target.value || undefined })} disabled={f.min === 'today'} /><label className="chk small"><input type="checkbox" checked={f.min === 'today'} onChange={(e) => onPatch({ min: e.target.checked ? 'today' : undefined })} /> не раньше сегодняшнего дня</label></div></UiField><UiField label="Макс. длительность, дней"><Input type="number" min={1} value={f.max ?? ''} onChange={(e) => onPatch({ max: num(e.target.value) })} /></UiField></div>}
      {t === 'file' && <div className="rqG3"><UiField label="Макс. файлов"><Input type="number" min={1} max={20} value={f.max_files ?? ''} onChange={(e) => onPatch({ max_files: num(e.target.value) })} /></UiField><UiField label="Допустимые типы" hint=".pdf,.docx,image/*"><Input value={f.accept || ''} onChange={(e) => onPatch({ accept: e.target.value })} /></UiField><div className="field"><label>&nbsp;</label><Switch checked={!!f.multiple} onChange={(v) => onPatch({ multiple: v })} label={<span className="small">Несколько</span>} /></div></div>}
      {t === 'user' && <Switch checked={!!f.multiple} onChange={(v) => onPatch({ multiple: v })} label={<span className="small">Можно выбрать нескольких сотрудников</span>} />}
      {!display && !['file', 'table', 'period', 'user'].includes(t) && (
        <UiField label="Значение по умолчанию">
          {(() => {
            const prof = f.default && typeof f.default === 'object' && 'profile' in f.default ? f.default.profile : '';
            const profs = PROFILE_DEFAULTS.filter((p) => p.types.includes(t));
            return (
              <div className="rqG2">
                <Select value={prof ? 'profile' : 'fixed'} onChange={(e) => onPatch({ default: e.target.value === 'profile' ? { profile: profs[0]?.id } : undefined })}><option value="fixed">Своё значение</option>{profs.length > 0 && <option value="profile">Из профиля сотрудника</option>}</Select>
                {prof ? <Select value={prof} onChange={(e) => onPatch({ default: { profile: e.target.value } })}>{profs.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}</Select>
                  : t === 'switch' ? <Select value={String(!!f.default)} onChange={(e) => onPatch({ default: e.target.value === 'true' ? true : undefined })}><option value="false">Нет</option><option value="true">Да</option></Select>
                  : HAS_OPTS.includes(t) && t !== 'checkboxes' ? <Select value={f.default ?? ''} onChange={(e) => onPatch({ default: e.target.value || undefined })}><option value="">— нет —</option>{(f.options || []).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</Select>
                  : t === 'checkboxes' ? <span className="muted small">—</span>
                  : <Input type={t === 'number' || t === 'money' ? 'number' : t === 'date' ? 'date' : 'text'} value={f.default ?? ''} onChange={(e) => onPatch({ default: t === 'number' || t === 'money' ? num(e.target.value) : e.target.value || undefined })} />}
              </div>
            );
          })()}
        </UiField>
      )}
      <div className="rqSub">
        <div className="small bold">Показывать поле, если…</div>
        <CondEditor value={f.visible_if} onChange={(c) => onPatch({ visible_if: c })} schema={schema} exclude={f.key} />
      </div>
    </div>
  );
}

type Sel = { s: number; f: number } | null;
type Drag = { kind: 'field'; s: number; f: number } | { kind: 'new'; type: string } | { kind: 'section'; s: number } | null;

/** Конструктор формы: секции и поля, перетаскивание, свойства поля, условная видимость. */
export function FormEditor({ schema, workflow, onChange }: { schema: Schema; workflow: Workflow; onChange: (s: Schema, w: Workflow) => void }) {
  const [sel, setSel] = useState<Sel>(schema.sections[0]?.fields.length ? { s: 0, f: 0 } : null);
  const drag = useRef<Drag>(null);
  const [over, setOver] = useState<string>('');
  const [confirm, node] = useConfirm();
  const apply = (fn: (s: Schema, w: Workflow) => void) => { const s = clone(schema), w = clone(workflow); fn(s, w); onChange(s, w); };
  const cur = sel ? schema.sections[sel.s]?.fields[sel.f] : undefined;
  const target = (): number => (sel ? sel.s : Math.max(0, schema.sections.length - 1));

  function addField(type: string, s = target(), at?: number) {
    apply((sc) => {
      const f = makeField(sc, type);
      const sec = sc.sections[s];
      const i = at ?? sec.fields.length;
      sec.fields.splice(i, 0, f);
      setSel({ s, f: i });
    });
  }
  function patch(p: Partial<Field>) {
    if (!sel) return;
    apply((sc, w) => {
      const f = sc.sections[sel.s].fields[sel.f];
      const oldKey = f.key;
      Object.assign(f, p);
      if ('label' in p && (f as any)._auto && !isDisplay(f.type)) {
        f.key = keyFromLabel(f.label || f.type, sc, f.key);
        if (oldKey && f.key !== oldKey) renameKey(sc, w, oldKey, f.key);
      }
      for (const k of Object.keys(f)) if ((f as any)[k] === undefined) delete (f as any)[k];
    });
  }
  function rename(nk: string) {
    if (!sel || !cur) return;
    const old = cur.key;
    apply((sc, w) => {
      const f = sc.sections[sel.s].fields[sel.f];
      f.key = nk; delete (f as any)._auto;
      if (nk && old) renameKey(sc, w, old, nk);
    });
  }
  async function removeField(s: number, i: number) {
    const f = schema.sections[s].fields[i];
    apply((sc, w) => {
      const dropped = sc.sections[s].fields.splice(i, 1)[0];
      if (dropped.key) { const n = dropRefs(sc, w, [dropped.key]); if (n) toast({ title: `Удалены условия и ссылки на поле «${dropped.label}»: ${n}`, kind: 'info' }); }
    });
    setSel(null);
  }
  function moveField(from: { s: number; f: number }, to: { s: number; f: number }) {
    apply((sc) => {
      const [f] = sc.sections[from.s].fields.splice(from.f, 1);
      let i = to.f;
      if (from.s === to.s && from.f < to.f) i--;
      sc.sections[to.s].fields.splice(i, 0, f);
      setSel({ s: to.s, f: i });
    });
  }
  function moveSection(a: number, b: number) {
    if (a === b || b < 0 || b >= schema.sections.length) return;
    apply((sc) => { const [x] = sc.sections.splice(a, 1); sc.sections.splice(b, 0, x); });
    setSel(null);
  }
  function addSection() {
    apply((sc) => { sc.sections.push({ id: 's' + uid().slice(0, 5), title: 'Раздел ' + (sc.sections.length + 1), fields: [] }); });
    setSel(null);
  }
  async function removeSection(i: number) {
    const sec = schema.sections[i];
    if (schema.sections.length <= 1) return toast({ title: 'В форме должна остаться хотя бы одна секция', kind: 'error' });
    if (sec.fields.length && !(await confirm(`Удалить раздел «${sec.title || i + 1}» вместе с полями (${sec.fields.length})?`, { ok: 'Удалить' }))) return;
    apply((sc, w) => { const keys = sc.sections[i].fields.map((f) => f.key).filter(Boolean); sc.sections.splice(i, 1); if (keys.length) dropRefs(sc, w, keys); });
    setSel(null);
  }
  function secPatch(i: number, p: Partial<Section>) { apply((sc) => { Object.assign(sc.sections[i], p); }); }
  function copyField(s: number, i: number) {
    apply((sc) => { const f = clone(sc.sections[s].fields[i]); if (f.key) f.key = newKey(sc, f.key.replace(/_\d+$/, '')); f.label += ' (копия)'; delete (f as any)._auto; sc.sections[s].fields.splice(i + 1, 0, f); setSel({ s, f: i + 1 }); });
  }

  const onDropRow = (e: React.DragEvent, s: number, f: number) => {
    e.preventDefault(); e.stopPropagation();
    const d = drag.current; setOver(''); drag.current = null;
    if (!d) return;
    if (d.kind === 'new') addField(d.type, s, f);
    else if (d.kind === 'field') moveField(d, { s, f });
  };
  const onDropSec = (e: React.DragEvent, s: number) => {
    e.preventDefault();
    const d = drag.current; setOver(''); drag.current = null;
    if (!d) return;
    if (d.kind === 'new') addField(d.type, s);
    else if (d.kind === 'field') moveField(d, { s, f: schema.sections[s].fields.length });
    else if (d.kind === 'section') moveSection(d.s, s);
  };

  return (
    <div className="rqFE">
      <aside className="rqPalette card">
        <div className="small bold" style={{ padding: '2px 4px 8px' }}>Элементы формы</div>
        <div className="muted tiny" style={{ padding: '0 4px 8px' }}>Перетащите на форму или нажмите</div>
        {['Ввод', 'Дата и время', 'Выбор', 'Справочники', 'Структура', 'Оформление'].map((g) => (
          <div key={g}>
            <div className="rqPalH">{g}</div>
            {FIELD_TYPES.filter((t) => t.group === g).map((t) => {
              const Ic = TYPE_ICON[t.id] || I.File;
              return <button key={t.id} type="button" draggable className="rqPalItem" onDragStart={(e) => { drag.current = { kind: 'new', type: t.id }; e.dataTransfer.effectAllowed = 'copy'; e.dataTransfer.setData('text/plain', t.id); }} onDragEnd={() => { drag.current = null; setOver(''); }} onClick={() => addField(t.id)}><Ic size={15} /> {t.label}</button>;
            })}
          </div>
        ))}
      </aside>

      <div className="rqCanvas">
        <div className="card padS rqLayout">
          <span className="small bold">Режим формы:</span>
          <Select value={schema.layout || 'single'} onChange={(e) => apply((sc) => { sc.layout = e.target.value as any; })}><option value="single">Одна страница</option><option value="wizard">Пошаговый (каждая секция — шаг)</option></Select>
        </div>
        {schema.sections.map((sec, si) => (
          <section key={sec.id} className={cx('card rqSecEd', over === 's' + si && 'over')} onDragOver={(e) => { if (drag.current) { e.preventDefault(); setOver('s' + si); } }} onDragLeave={(e) => { if (e.currentTarget === e.target) setOver(''); }} onDrop={(e) => onDropSec(e, si)}>
            <header className="rqSecHead">
              <span draggable className="rqHandle" title="Перетащить раздел" onDragStart={(e) => { drag.current = { kind: 'section', s: si }; e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', 'section'); }} onDragEnd={() => { drag.current = null; setOver(''); }}><Grip /></span>
              <Input className="rqSecTitle" value={sec.title || ''} placeholder="Название раздела" onChange={(e) => secPatch(si, { title: e.target.value })} />
              <button type="button" className="btn ghost sm icon" aria-label="Выше" disabled={si === 0} onClick={() => moveSection(si, si - 1)}><I.ChevronUp size={16} /></button>
              <button type="button" className="btn ghost sm icon" aria-label="Ниже" disabled={si === schema.sections.length - 1} onClick={() => moveSection(si, si + 1)}><I.ChevronDown size={16} /></button>
              <button type="button" className="btn ghost sm icon" aria-label="Удалить раздел" onClick={() => removeSection(si)}><I.Trash size={16} /></button>
            </header>
            <Input className="rqSecDesc" value={sec.desc || ''} placeholder="Описание раздела (необязательно)" onChange={(e) => secPatch(si, { desc: e.target.value })} />
            <details className="rqSecCond"><summary className="small muted">Условие показа раздела{sec.visible_if?.items?.length ? ' · задано' : ''}</summary><CondEditor value={sec.visible_if} onChange={(c) => secPatch(si, { visible_if: c as any })} schema={schema} /></details>
            <div className="rqFields">
              {sec.fields.length === 0 && <div className="rqEmpty">Перетащите сюда элемент или нажмите на него в списке слева</div>}
              {sec.fields.map((f, fi) => {
                const Ic = TYPE_ICON[f.type] || I.File;
                const on = sel?.s === si && sel?.f === fi;
                return (
                  <div key={fi} className={cx('rqFRow', on && 'on', over === `${si}.${fi}` && 'over', f.width === '1/2' && 'half', f.width === '1/3' && 'third')}
                    onClick={() => setSel({ s: si, f: fi })} tabIndex={0} onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { if ((e.target as HTMLElement).tagName === 'DIV') { e.preventDefault(); setSel({ s: si, f: fi }); } } }}
                    draggable onDragStart={(e) => { drag.current = { kind: 'field', s: si, f: fi }; e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', 'field'); e.stopPropagation(); }}
                    onDragEnd={() => { drag.current = null; setOver(''); }}
                    onDragOver={(e) => { if (drag.current && drag.current.kind !== 'section') { e.preventDefault(); e.stopPropagation(); setOver(`${si}.${fi}`); } }}
                    onDrop={(e) => onDropRow(e, si, fi)}>
                    <Grip />
                    <span className="rqFIco"><Ic size={16} /></span>
                    <div className="rqFMain">
                      <div className="small bold clip">{f.type === 'divider' ? '— разделитель —' : f.label || '(без названия)'}{f.required && <span className="rqReq"> *</span>}</div>
                      <div className="tiny muted clip">{typeLabel(f.type)}{f.key && <> · <code>{f.key}</code></>}{f.visible_if?.items?.length ? ' · условие показа' : ''}{f.required_if?.items?.length ? ' · обяз. по условию' : ''}</div>
                    </div>
                    <div className="rqFAct">
                      <button type="button" className="btn ghost sm icon" aria-label="Выше" disabled={fi === 0 && si === 0} onClick={(e) => { e.stopPropagation(); if (fi > 0) moveField({ s: si, f: fi }, { s: si, f: fi - 1 }); else moveField({ s: si, f: fi }, { s: si - 1, f: schema.sections[si - 1].fields.length }); }}><I.ChevronUp size={15} /></button>
                      <button type="button" className="btn ghost sm icon" aria-label="Ниже" disabled={fi === sec.fields.length - 1 && si === schema.sections.length - 1} onClick={(e) => { e.stopPropagation(); if (fi < sec.fields.length - 1) moveField({ s: si, f: fi }, { s: si, f: fi + 2 }); else moveField({ s: si, f: fi }, { s: si + 1, f: 0 }); }}><I.ChevronDown size={15} /></button>
                      <button type="button" className="btn ghost sm icon" aria-label="Дублировать" onClick={(e) => { e.stopPropagation(); copyField(si, fi); }}><I.Copy size={15} /></button>
                      <button type="button" className="btn ghost sm icon" aria-label="Удалить поле" onClick={(e) => { e.stopPropagation(); removeField(si, fi); }}><I.Trash size={15} /></button>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="rqSecFoot"><Btn size="sm" onClick={() => addField('text', si)}><I.Plus size={14} /> Поле</Btn></div>
          </section>
        ))}
        <Btn onClick={addSection}><I.Plus size={16} /> Добавить раздел</Btn>
      </div>

      <aside className="rqInspector card pad">
        {cur ? (
          <>
            <div className="row" style={{ marginBottom: 8 }}><h3 style={{ fontSize: 16, fontWeight: 700 }}>Свойства поля</h3><span className="sp" /><button className="btn ghost sm icon" aria-label="Закрыть" onClick={() => setSel(null)}><I.X size={15} /></button></div>
            <FieldProps key={sel!.s + '.' + sel!.f} f={cur} schema={schema} onPatch={patch} onRename={rename} />
          </>
        ) : <div className="muted small" style={{ padding: 6 }}>Выберите поле в форме, чтобы настроить подпись, обязательность, проверки, условия показа и значение по умолчанию.</div>}
      </aside>
      {node}
    </div>
  );
}
