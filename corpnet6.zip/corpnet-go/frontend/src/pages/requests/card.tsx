import React, { useEffect, useRef, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { useQuery, invalidate } from '../../lib/query';
import { Link, navigate, useTitle } from '../../lib/router';
import { toast } from '../../lib/store';
import { cx, fmtDate, fmtSize } from '../../lib/util';
import { Avatar, Badge, Btn, Empty, ErrorBox, Field as UiField, Loading, Modal, Textarea, UserPicker, useConfirm } from '../../ui';
import type { UserLite } from '../../ui';
import { ValueView } from './form';
import { TypeIcon } from './icons';
import { StatusBadge } from './lists';
import { MODE_LABEL, STEP_KIND, evalCond, isDisplay, isEmpty } from './model';
import type { Schema } from './model';

const EV: Record<string, { t: string; icon: any; tone?: string }> = {
  created: { t: 'создал(а) черновик', icon: I.Edit }, edited: { t: 'изменил(а) заявку', icon: I.Edit },
  submitted: { t: 'подал(а) заявку', icon: I.Send, tone: 'accent' }, resubmitted: { t: 'отправил(а) заявку повторно', icon: I.Send, tone: 'accent' },
  step_started: { t: 'Начат этап', icon: I.Play }, step_skipped: { t: 'Этап пропущен', icon: I.ChevronRight },
  approved: { t: 'согласовал(а)', icon: I.Check, tone: 'ok' }, executed: { t: 'выполнил(а)', icon: I.CheckCheck, tone: 'ok' }, acked: { t: 'ознакомлен(а)', icon: I.Eye, tone: 'ok' },
  rejected: { t: 'отклонил(а)', icon: I.Ban, tone: 'dng' }, returned: { t: 'вернул(а) на доработку', icon: I.Refresh, tone: 'warn' },
  question: { t: 'задал(а) вопрос заявителю', icon: I.Message, tone: 'warn' }, answer: { t: 'ответил(а) на вопрос', icon: I.Reply },
  delegated: { t: 'передал(а) решение', icon: I.UserPlus }, assigned: { t: 'назначил(а) исполнителя', icon: I.UserPlus },
  escalated: { t: 'Эскалация по сроку', icon: I.Alert, tone: 'warn' }, escalation_failed: { t: 'Эскалация не удалась', icon: I.Alert, tone: 'warn' },
  cancelled: { t: 'отозвал(а) заявку', icon: I.X }, comment: { t: 'написал(а)', icon: I.Comment }, status: { t: 'Статус изменён', icon: I.Info },
  overdue: { t: 'Просрочка', icon: I.Alert, tone: 'warn' }, rework: { t: 'Заявка возвращена на доработку', icon: I.Refresh, tone: 'warn' }, note: { t: '', icon: I.Info }, via: { t: '', icon: I.Info }, stuck: { t: 'Нет исполнителей', icon: I.Alert, tone: 'warn' },
};
const ASG: Record<string, { t: string; kind?: 'ok' | 'dng' | 'warn' | 'accent' }> = {
  pending: { t: 'ожидает', kind: 'accent' }, approved: { t: 'согласовано', kind: 'ok' }, rejected: { t: 'отклонено', kind: 'dng' }, done: { t: 'выполнено', kind: 'ok' },
  acked: { t: 'ознакомлен', kind: 'ok' }, returned: { t: 'на доработку', kind: 'warn' }, skipped: { t: 'пропущено' }, delegated: { t: 'передано' },
};
const VIA: Record<string, string> = { deputy: 'замещает', fallback: 'запасной', delegate: 'делегировано', escalation: 'эскалация', assigned: 'назначен' };
const ACTION: Record<string, { label: string; icon: any; kind?: 'pri' | 'dng'; ask: string; need?: boolean }> = {
  approve: { label: 'Согласовать', icon: I.Check, kind: 'pri', ask: 'Комментарий (необязательно)' },
  execute: { label: 'Выполнено', icon: I.CheckCheck, kind: 'pri', ask: 'Результат или комментарий (необязательно)' },
  ack: { label: 'Ознакомлен(а)', icon: I.Eye, kind: 'pri', ask: 'Комментарий (необязательно)' },
  reject: { label: 'Отклонить', icon: I.Ban, kind: 'dng', ask: 'Причина отказа', need: true },
  return: { label: 'На доработку', icon: I.Refresh, ask: 'Что нужно доработать', need: true },
  ask: { label: 'Задать вопрос', icon: I.Message, ask: 'Вопрос заявителю', need: true },
  delegate: { label: 'Передать другому', icon: I.UserPlus, ask: 'Комментарий (необязательно)' },
};

function Person({ name, avatar, size = 28 }: { name: string; avatar?: string; size?: number }) {
  return <Avatar name={name} src={avatar} size={size} />;
}

function ActionDialog({ id, act, stepId, onClose }: { id: number; act: string; stepId?: number; onClose: () => void }) {
  const a = ACTION[act];
  const [text, setText] = useState('');
  const [to, setTo] = useState<UserLite[]>([]);
  const [files, setFiles] = useState<{ id: number; name: string }[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const ref = useRef<HTMLInputElement>(null);
  async function upload(list: FileList | null) {
    if (!list) return;
    try { for (const f of Array.from(list)) { const r = await api.upload('/api/requests/files', f); setFiles((o) => [...o, { id: r.id, name: r.name }]); } } catch (e) { setErr(errMsg(e)); }
  }
  async function go() {
    if (a.need && !text.trim()) return setErr(a.ask + ' — обязательное поле');
    if (act === 'delegate' && !to.length) return setErr('Выберите сотрудника');
    setBusy(true); setErr('');
    try {
      await api.post(`/api/requests/${id}/action`, { action: act, comment: text.trim(), step_id: stepId, to: to[0]?.id, files: files.map((f) => f.id) });
      invalidate('req:'); toast({ title: 'Готово', kind: 'success' }); onClose();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title={a.label} onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind={a.kind} busy={busy} onClick={go}>{a.label}</Btn></>}>
      {act === 'delegate' && <UiField label="Кому передать"><UserPicker single value={to} onChange={setTo} placeholder="Найти сотрудника…" /></UiField>}
      <UiField label={a.ask}><Textarea rows={4} value={text} onChange={(e) => setText(e.target.value)} maxLength={5000} /></UiField>
      <div className="stackS">
        {files.map((f) => <div className="rqFile" key={f.id}><I.Paperclip size={15} /><span className="clip">{f.name}</span><button className="btn ghost sm icon" aria-label="Убрать" onClick={() => setFiles(files.filter((x) => x.id !== f.id))}><I.X size={14} /></button></div>)}
        <input ref={ref} type="file" hidden multiple onChange={(e) => { upload(e.target.files); e.target.value = ''; }} />
        <div><Btn size="sm" type="button" onClick={() => ref.current?.click()}><I.Paperclip size={15} /> Прикрепить файл</Btn></div>
      </div>
      {err && <div className="err">{err}</div>}
    </Modal>
  );
}

function AssignDialog({ id, onClose }: { id: number; onClose: () => void }) {
  const [u, setU] = useState<UserLite[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  async function go() {
    if (!u.length) return setErr('Выберите сотрудника');
    setBusy(true);
    try { await api.post(`/api/requests/${id}/action`, { action: 'assign', to: u[0].id }); invalidate('req:'); onClose(); } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title="Назначить исполнителя" size="sm" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} onClick={go}>Назначить</Btn></>}>
      <p className="muted small">Сотрудник добавится к текущему этапу маршрута и получит уведомление.</p>
      <UserPicker single value={u} onChange={setU} />
      {err && <div className="err">{err}</div>}
    </Modal>
  );
}

export function CardPage({ id }: { id: number }) {
  const q = useQuery<any>('req:card:' + id, () => api.get('/api/requests/' + id), { stale: 0 });
  const [act, setAct] = useState<string | null>(null);
  const [assign, setAssign] = useState(false);
  const [text, setText] = useState('');
  const [files, setFiles] = useState<{ id: number; name: string }[]>([]);
  const [busy, setBusy] = useState(false);
  const [confirm, confirmNode] = useConfirm();
  const fileRef = useRef<HTMLInputElement>(null);
  const d = q.data;
  useTitle(d ? `${d.request.number || 'Черновик'} — ${d.request.type_name}` : 'Заявка');
  useEffect(() => {
    if (!d) return;
    const h = location.hash.match(/^#step-(\d+)/);
    if (h) setTimeout(() => document.getElementById('rq-step-' + h[1])?.scrollIntoView({ block: 'center' }), 50);
  }, [!!d]);

  if (q.error && !d) {
    const st = (q.error as any).status;
    return <div className="card">{st === 404 || st === 403 ? <Empty icon={I.Lock} title="Заявка не найдена или недоступна"><Link to="/requests/mine" className="btn" style={{ marginTop: 10 }}>К моим заявкам</Link></Empty> : <ErrorBox error={q.error} retry={q.refetch} />}</div>;
  }
  if (!d) return <Loading />;
  const r = d.request, can = d.can || {}, schema: Schema = d.schema;
  const reload = () => { invalidate('req:'); };

  async function send() {
    if (!text.trim() && !files.length) return;
    setBusy(true);
    try { await api.post(`/api/requests/${id}/comments`, { text: text.trim(), files: files.map((f) => f.id) }); setText(''); setFiles([]); reload(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  async function upload(list: FileList | null) {
    if (!list) return;
    try { for (const f of Array.from(list)) { const x = await api.upload('/api/requests/files', f); setFiles((o) => [...o, { id: x.id, name: x.name }]); } } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function cancel() {
    if (!(await confirm('Отозвать заявку?', { text: 'Заявка будет отменена, согласующие получат уведомление. Это возможно только до первого решения.', ok: 'Отозвать' }))) return;
    try { await api.post(`/api/requests/${id}/action`, { action: 'cancel' }); reload(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function del() {
    if (!(await confirm('Удалить черновик?', { ok: 'Удалить' }))) return;
    try { await api.del('/api/requests/' + id); reload(); navigate('/requests/mine', { replace: true }); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }

  const stepsByRound = (d.steps as any[]).filter((s) => s.round === d.round);
  const asgOf = (sid: number) => (d.assignees as any[]).filter((a) => a.step_id === sid);
  const evText = (e: any) => {
    const m = EV[e.kind] || { t: e.kind, icon: I.Info };
    return m;
  };
  const sections = schema.sections.filter((s) => evalCond(s.visible_if, d.data));
  const myActs: string[] = can.my_actions || [];
  const primary = myActs.filter((a) => ['approve', 'execute', 'ack'].includes(a));
  const secondary = myActs.filter((a) => !['approve', 'execute', 'ack'].includes(a));
  const closed = ['rejected', 'done', 'cancelled'].includes(r.status);

  return (
    <div className="stack rqCardPage">
      <div className="crumbs"><Link to="/requests/mine"><I.ArrowLeft size={15} /> Заявки</Link></div>
      <div className="card pad">
        <div className="row" style={{ alignItems: 'flex-start', gap: 14, flexWrap: 'wrap' }}>
          <TypeIcon name={r.type_icon} color={r.type_color} size={26} box={52} />
          <div style={{ minWidth: 0, flex: 1 }}>
            <div className="muted small">{r.type_name} · версия формы {r.version}</div>
            <h1 style={{ fontSize: 24, fontWeight: 800 }}>{r.number || 'Черновик'} <StatusBadge s={r.status} info={!!r.info_by} /></h1>
            <div className="rqMeta">
              <span><I.Users size={14} /> <Link to={`/people/${r.author_id}`}>{r.author}</Link>{r.department && ` · ${r.department}`}</span>
              <span><I.Calendar size={14} /> {r.submitted_at ? 'подана ' + fmtDate(r.submitted_at) : 'создана ' + fmtDate(r.created_at)}</span>
              {r.due_at && !closed && <span className={cx(new Date(r.due_at) < new Date() && 'rqLate')}><I.Clock size={14} /> срок {fmtDate(r.due_at)}</span>}
              {r.closed_at && <span><I.Check size={14} /> закрыта {fmtDate(r.closed_at)}</span>}
              {d.round > 1 && <span><I.Refresh size={14} /> круг согласования {d.round}</span>}
            </div>
          </div>
          <div className="rowW">
            {can.edit && <Link to={`/requests/${id}/edit`} className="btn"><I.Edit size={16} /> {r.status === 'draft' ? 'Редактировать' : 'Доработать'}</Link>}
            {can.cancel && <Btn onClick={cancel}><I.X size={16} /> Отозвать</Btn>}
            {can.delete && <Btn kind="dng" onClick={del}><I.Trash size={16} /> Удалить</Btn>}
            <Btn onClick={() => window.print()} title="Печать"><I.File size={16} /> Печать</Btn>
          </div>
        </div>
        {r.info_by && can.answer && <div className="notice warn" style={{ marginTop: 14 }}><I.Message size={18} /><div><b>{r.info_by_name} задал(а) вопрос по заявке.</b> Ответьте в комментариях ниже — согласование продолжится.</div></div>}
        {r.status === 'rework' && can.edit && <div className="notice warn" style={{ marginTop: 14 }}><I.Refresh size={18} /><div><b>Заявка возвращена на доработку.</b> Нажмите «Доработать», исправьте данные и отправьте повторно.</div></div>}
      </div>

      {myActs.length > 0 && (
        <div className="card pad rqAct" id={'rq-step-' + can.my_step}>
          <div style={{ flex: 1, minWidth: 200 }}><b>Ваше решение</b><div className="muted small">{STEP_KIND[can.my_kind]} · этап «{(d.steps as any[]).find((s) => s.id === can.my_step)?.name}»</div></div>
          <div className="rowW">
            {primary.map((a) => <Btn key={a} kind={ACTION[a].kind} onClick={() => setAct(a)}>{React.createElement(ACTION[a].icon, { size: 16 })} {ACTION[a].label}</Btn>)}
            {secondary.map((a) => <Btn key={a} kind={a === 'reject' ? 'dng' : undefined} onClick={() => setAct(a)}>{React.createElement(ACTION[a].icon, { size: 16 })} {ACTION[a].label}</Btn>)}
          </div>
        </div>
      )}

      <div className="rqCols">
        <div className="stack" style={{ minWidth: 0 }}>
          <div className="card pad">
            <h2 className="rqH2">Данные заявки</h2>
            {sections.map((s) => {
              const rows = s.fields.filter((f) => !isDisplay(f.type) && evalCond(f.visible_if, d.data) && !isEmpty(d.data[f.key]));
              if (!rows.length) return null;
              return (
                <section key={s.id} className="rqRoSec">
                  {s.title && <h3>{s.title}</h3>}
                  <dl className="rqDl">{rows.map((f) => <React.Fragment key={f.key}><dt>{f.label}</dt><dd><ValueView f={f} v={d.data[f.key]} /></dd></React.Fragment>)}</dl>
                </section>
              );
            })}
            {Object.keys(d.data).length === 0 && <div className="muted">Данные не заполнены.</div>}
          </div>

          <div className="card pad">
            <h2 className="rqH2"><I.Activity size={18} /> История и комментарии</h2>
            <ol className="rqTl">
              {(d.events as any[]).map((e) => {
                const m = evText(e);
                const msg = ['comment', 'answer', 'question', 'approved', 'executed', 'acked', 'rejected', 'returned', 'delegated'].includes(e.kind);
                const system = !e.actor_id || ['step_started', 'step_skipped', 'escalated', 'escalation_failed', 'note', 'via', 'stuck', 'status', 'rework'].includes(e.kind);
                const inline = (system || ['assigned', 'cancelled'].includes(e.kind)) && !msg && !!e.text && e.text !== m.t;
                return (
                  <li key={e.id} className={cx('rqEv', m.tone, msg && 'msg')}>
                    <span className="rqEvIco">{system ? React.createElement(m.icon, { size: 15 }) : <Person name={e.actor || '?'} avatar={e.actor_avatar} size={30} />}</span>
                    <div className="rqEvBody">
                      <div className="small">
                        {!system && <b>{e.actor}</b>} {m.t}{inline ? <>{m.t ? ': ' : ''}<span className="muted">{e.text}</span></> : null}
                        <span className="tiny faint"> · {fmtDate(e.created_at)}</span>
                      </div>
                      {msg && e.text && <div className="rqEvText">{e.text}</div>}
                      {e.files?.length > 0 && <div className="stackS" style={{ marginTop: 6 }}>{e.files.map((f: any) => <div className="rqFile" key={f.id}><I.Paperclip size={15} /><a href={`/files/${f.id}?dl=1`} target="_blank" rel="noopener noreferrer" className="clip">{f.name}</a><span className="tiny faint">{fmtSize(f.size)}</span></div>)}</div>}
                    </div>
                  </li>
                );
              })}
            </ol>
            {can.comment && (
              <div className="rqCompose">
                <Textarea rows={3} placeholder={can.answer && r.info_by ? 'Ответ на вопрос…' : 'Написать комментарий…'} value={text} maxLength={5000} onChange={(e) => setText(e.target.value)} />
                {files.length > 0 && <div className="stackS">{files.map((f) => <div className="rqFile" key={f.id}><I.Paperclip size={15} /><span className="clip">{f.name}</span><button className="btn ghost sm icon" aria-label="Убрать" onClick={() => setFiles(files.filter((x) => x.id !== f.id))}><I.X size={14} /></button></div>)}</div>}
                <div className="rowW">
                  <input ref={fileRef} type="file" hidden multiple onChange={(e) => { upload(e.target.files); e.target.value = ''; }} />
                  <Btn size="sm" onClick={() => fileRef.current?.click()}><I.Paperclip size={15} /> Файл</Btn>
                  <span className="sp" />
                  <Btn kind="pri" busy={busy} disabled={!text.trim() && !files.length} onClick={send}><I.Send size={16} /> Отправить</Btn>
                </div>
              </div>
            )}
          </div>
        </div>

        <aside className="stack rqSide">
          <div className="card pad">
            <div className="row"><h2 className="rqH2" style={{ margin: 0 }}>Маршрут согласования</h2><span className="sp" />{can.assign && <Btn size="sm" onClick={() => setAssign(true)}><I.UserPlus size={15} /> Назначить</Btn>}</div>
            {stepsByRound.length === 0 && r.status === 'draft' && <p className="muted small">Маршрут начнётся после подачи заявки.</p>}
            <ol className="rqRoute">
              {d.route.map((st: any) => {
                const real = stepsByRound.find((s) => s.idx === st.idx || s.key === st.id);
                const sk = real ? (real.state === 'active' ? 'active' : real.state) : st.applies ? 'wait' : 'skip';
                return (
                  <li key={st.idx} id={real ? 'rq-step-' + real.id : undefined} className={cx('rqRs', sk)}>
                    <span className="rqDot">{sk === 'done' ? <I.Check size={12} sw={3} /> : sk === 'rejected' ? <I.X size={12} sw={3} /> : sk === 'returned' ? <I.Refresh size={11} sw={3} /> : null}</span>
                    <div style={{ minWidth: 0, flex: 1 }}>
                      <div className="small bold">{st.name}</div>
                      <div className="tiny muted">{STEP_KIND[st.kind]}{st.mode && st.who.length > 1 ? ` · ${MODE_LABEL[st.mode]}` : ''}{!st.applies && !real ? ' · не требуется' : ''}{st.cond && !real && st.applies ? ' · по условию' : ''}</div>
                      {real ? (
                        <ul className="rqAsg">
                          {asgOf(real.id).map((a) => (
                            <li key={a.id} className={cx(a.overdue && 'late')}>
                              <Person name={a.name} avatar={a.avatar} size={24} />
                              <div style={{ minWidth: 0, flex: 1 }}>
                                <div className="small clip"><Link to={`/people/${a.user_id}`}>{a.name}</Link></div>
                                <div className="tiny muted clip">{a.via !== 'direct' && VIA[a.via] ? `${VIA[a.via]}${a.orig_name ? ' ' + a.orig_name : ''}` : a.job_title}{a.state === 'pending' && a.due_at ? ` · до ${fmtDate(a.due_at)}` : ''}{a.decided_at ? ` · ${fmtDate(a.decided_at)}` : ''}</div>
                                {a.comment && <div className="tiny clamp2">«{a.comment}»</div>}
                              </div>
                              <Badge kind={a.overdue ? 'dng' : ASG[a.state]?.kind}>{a.overdue ? 'просрочено' : ASG[a.state]?.t || a.state}</Badge>
                            </li>
                          ))}
                          {asgOf(real.id).length === 0 && <li className="tiny warn-t">Исполнители не определены</li>}
                        </ul>
                      ) : st.who.length > 0 && st.applies ? <div className="tiny faint">{st.who.join('; ')}</div> : null}
                    </div>
                  </li>
                );
              })}
            </ol>
          </div>
        </aside>
      </div>
      {act && <ActionDialog id={id} act={act} stepId={can.my_step} onClose={() => setAct(null)} />}
      {assign && <AssignDialog id={id} onClose={() => setAssign(false)} />}
      {confirmNode}
    </div>
  );
}
