// Модель раздела «Заявки»: типы схемы, условия, значения «из профиля», проверка на клиенте (зеркало серверной).
// Сервер всегда проверяет данные заново по снимку схемы — клиентская проверка только для удобства.

export interface Opt { value: string; label: string }
export interface CondItem { field: string; cmp: string; value?: any }
export interface Cond { op?: 'and' | 'or'; items: CondItem[] }
export interface Field {
  key: string; type: string; label: string; hint?: string; placeholder?: string; required?: boolean; default?: any; width?: '1' | '1/2' | '1/3';
  options?: Opt[]; multiple?: boolean; min?: any; max?: any; min_len?: number; max_len?: number; pattern?: string; pattern_msg?: string; unit?: string;
  accept?: string; max_files?: number; visible_if?: Cond | null; required_if?: Cond | null; columns?: Field[]; min_rows?: number; max_rows?: number;
}
export interface Section { id: string; title?: string; desc?: string; visible_if?: Cond | null; fields: Field[] }
export interface Schema { layout?: 'single' | 'wizard'; sections: Section[] }

export interface Assignee { t: string; id?: number; n?: number; key?: string; name?: string }
export interface Branch { name?: string; mode: 'any' | 'all' | 'majority'; assignees: Assignee[] }
export interface Step {
  id: string; name: string; kind: 'approve' | 'execute' | 'inform'; cond?: Cond | null; branches: Branch[];
  sla?: { value: number; unit: string } | null; remind_before_h?: number | null; escalate?: { to: string; n?: number; user_id?: number; name?: string } | null; fallback?: Assignee[];
}
export interface Hook { action: 'vacation'; period: string; deputy?: string; flag?: string }
export interface Workflow { steps: Step[]; hooks?: Hook[] }

export const STATUS: Record<string, { label: string; kind?: 'accent' | 'ok' | 'warn' | 'dng' }> = {
  draft: { label: 'Черновик' },
  pending: { label: 'На согласовании', kind: 'accent' },
  rework: { label: 'На доработке', kind: 'warn' },
  rejected: { label: 'Отклонена', kind: 'dng' },
  approved: { label: 'Согласована', kind: 'ok' },
  in_progress: { label: 'В работе', kind: 'accent' },
  done: { label: 'Выполнена', kind: 'ok' },
  cancelled: { label: 'Отменена' },
};
export const STATUS_GROUPS: { id: string; label: string; list: string }[] = [
  { id: 'all', label: 'Все', list: '' },
  { id: 'active', label: 'Активные', list: 'pending,in_progress,rework' },
  { id: 'draft', label: 'Черновики', list: 'draft' },
  { id: 'ok', label: 'Завершённые', list: 'approved,done' },
  { id: 'bad', label: 'Отклонённые и отменённые', list: 'rejected,cancelled' },
];
export const STEP_KIND: Record<string, string> = { approve: 'Согласование', execute: 'Исполнение', inform: 'Ознакомление' };
export const MODE_LABEL: Record<string, string> = { any: 'достаточно одного', all: 'все', majority: 'большинство' };
export const UNIT_LABEL: Record<string, string> = { h: 'час.', wh: 'раб. час.', d: 'дн.', wd: 'раб. дн.' };
export const CMP_LABEL: Record<string, string> = { eq: 'равно', ne: 'не равно', gt: 'больше', gte: 'не меньше', lt: 'меньше', lte: 'не больше', contains: 'содержит', in: 'одно из', empty: 'не заполнено', notempty: 'заполнено' };

export const FIELD_TYPES: { id: string; label: string; group: string }[] = [
  { id: 'text', label: 'Строка', group: 'Ввод' }, { id: 'textarea', label: 'Многострочный текст', group: 'Ввод' }, { id: 'number', label: 'Число', group: 'Ввод' },
  { id: 'money', label: 'Деньги', group: 'Ввод' }, { id: 'phone', label: 'Телефон', group: 'Ввод' }, { id: 'email', label: 'Email', group: 'Ввод' },
  { id: 'date', label: 'Дата', group: 'Дата и время' }, { id: 'period', label: 'Период дат', group: 'Дата и время' }, { id: 'time', label: 'Время', group: 'Дата и время' },
  { id: 'select', label: 'Выпадающий список', group: 'Выбор' }, { id: 'radio', label: 'Радио-кнопки', group: 'Выбор' }, { id: 'checkboxes', label: 'Флажки', group: 'Выбор' },
  { id: 'switch', label: 'Переключатель', group: 'Выбор' },
  { id: 'user', label: 'Сотрудник', group: 'Справочники' }, { id: 'department', label: 'Подразделение', group: 'Справочники' }, { id: 'file', label: 'Файлы', group: 'Справочники' },
  { id: 'table', label: 'Таблица (повторяемые строки)', group: 'Структура' },
  { id: 'heading', label: 'Заголовок', group: 'Оформление' }, { id: 'divider', label: 'Разделитель', group: 'Оформление' }, { id: 'note', label: 'Пояснение', group: 'Оформление' },
];
export const typeLabel = (t: string) => FIELD_TYPES.find((x) => x.id === t)?.label || t;
export const isDisplay = (t: string) => t === 'heading' || t === 'divider' || t === 'note';
export const PROFILE_DEFAULTS: { id: string; label: string; types: string[] }[] = [
  { id: 'full_name', label: 'ФИО', types: ['text'] }, { id: 'job_title', label: 'Должность', types: ['text'] }, { id: 'department', label: 'Подразделение', types: ['department', 'text'] },
  { id: 'phone', label: 'Телефон', types: ['phone', 'text'] }, { id: 'email', label: 'Email', types: ['email', 'text'] },
];

// ---------------------------------------------------------------- значения и условия

export function valKey(v: any): string {
  if (v === null || v === undefined) return '';
  if (typeof v === 'string') return v;
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  if (typeof v === 'number') return String(v);
  if (typeof v === 'object' && !Array.isArray(v)) { if ('id' in v) return valKey(v.id); if ('value' in v) return valKey(v.value); }
  return JSON.stringify(v);
}
export function isEmpty(v: any): boolean {
  if (v === null || v === undefined) return true;
  if (typeof v === 'string') return v.trim() === '';
  if (Array.isArray(v)) return v.length === 0;
  if (typeof v === 'object') { if ('from' in v) return valKey(v.from) === '' && valKey(v.to) === ''; return Object.keys(v).length === 0; }
  return false;
}
const toNum = (v: any): number | null => {
  if (typeof v === 'number') return v;
  if (typeof v === 'string' && v.trim() !== '') { const n = Number(v.trim().replace(',', '.')); return Number.isNaN(n) ? null : n; }
  return null;
};
export function lookup(data: Record<string, any>, path: string): any {
  const i = path.indexOf('.');
  if (i < 0) return data[path];
  const v = data[path.slice(0, i)];
  return v && typeof v === 'object' && !Array.isArray(v) ? v[path.slice(i + 1)] : undefined;
}
function evalItem(it: CondItem, data: Record<string, any>): boolean {
  const v = lookup(data, it.field);
  const cv = it.value;
  switch (it.cmp) {
    case 'empty': return isEmpty(v);
    case 'notempty': return !isEmpty(v);
    case 'eq': case 'ne': {
      const eq = Array.isArray(v) ? v.some((e) => valKey(e) === valKey(cv)) : valKey(v) === valKey(cv);
      return it.cmp === 'eq' ? eq : !eq;
    }
    case 'in': {
      const list = Array.isArray(cv) ? cv.map(valKey) : typeof cv === 'string' ? cv.split(',').map((x) => x.trim()) : [];
      return Array.isArray(v) ? v.some((e) => list.includes(valKey(e))) : list.includes(valKey(v));
    }
    case 'contains':
      return Array.isArray(v) ? v.some((e) => valKey(e) === valKey(cv)) : valKey(v).toLowerCase().includes(valKey(cv).toLowerCase());
    case 'gt': case 'gte': case 'lt': case 'lte': {
      const a = toNum(v), b = toNum(cv);
      let c: number;
      if (a !== null && b !== null) c = a < b ? -1 : a > b ? 1 : 0;
      else if (!isEmpty(v) && a === null && b === null) { const x = valKey(v), y = valKey(cv); c = x < y ? -1 : x > y ? 1 : 0; }
      else return false;
      return it.cmp === 'gt' ? c > 0 : it.cmp === 'gte' ? c >= 0 : it.cmp === 'lt' ? c < 0 : c <= 0;
    }
  }
  return false;
}
export function evalCond(c: Cond | null | undefined, data: Record<string, any>): boolean {
  if (!c || !c.items?.length) return true;
  return c.op === 'or' ? c.items.some((i) => evalItem(i, data)) : c.items.every((i) => evalItem(i, data));
}

// ---------------------------------------------------------------- даты

const isoDay = (d: Date) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
export const todayIso = () => isoDay(new Date());
export const dmy = (s?: string | null) => (s && s.length >= 10 ? s.slice(8, 10) + '.' + s.slice(5, 7) + '.' + s.slice(0, 4) : s || '');
/** Календарные и рабочие (пн–пт) дни периода включительно — так же считает сервер. */
export function countDays(from: string, to: string): { days: number; workdays: number } {
  const a = Date.parse(from + 'T00:00:00Z'), b = Date.parse(to + 'T00:00:00Z');
  if (Number.isNaN(a) || Number.isNaN(b) || b < a) return { days: 0, workdays: 0 };
  let days = 0, workdays = 0;
  for (let t = a; t <= b; t += 86400000) { days++; const wd = new Date(t).getUTCDay(); if (wd !== 0 && wd !== 6) workdays++; }
  return { days, workdays };
}
export const plural = (n: number, f: [string, string, string]) => { const m = Math.abs(n) % 100, d = m % 10; return m > 10 && m < 20 ? f[2] : d > 1 && d < 5 ? f[1] : d === 1 ? f[0] : f[2]; };

// ---------------------------------------------------------------- значения по умолчанию

export function defaultsFor(schema: Schema, me: any): Record<string, any> {
  const out: Record<string, any> = {};
  const prof = (k: string, f: Field) => {
    switch (k) {
      case 'full_name': return me?.name || '';
      case 'job_title': return me?.job_title || '';
      case 'department': return f.type === 'department' ? (me?.department_id ? { id: me.department_id, name: me.department || '' } : undefined) : me?.department || '';
      case 'phone': return me?.phone || '';
      case 'email': return me?.email || '';
    }
  };
  for (const s of schema.sections) for (const f of s.fields) {
    if (isDisplay(f.type) || f.default === undefined || f.default === null || f.default === '') continue;
    const v = typeof f.default === 'object' && !Array.isArray(f.default) && 'profile' in f.default ? prof(f.default.profile, f) : f.default;
    if (v !== undefined && v !== '') out[f.key] = v;
  }
  return out;
}

// ---------------------------------------------------------------- проверка на клиенте

const phoneRe = /^\+?[0-9()\-\s.]{5,25}$/;
const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** Ошибки по ключам полей (таблицы — «key.строка.колонка»). Скрытые условиями поля не проверяются. */
export function validateData(schema: Schema, data: Record<string, any>, sectionIdx?: number): Record<string, string> {
  const errs: Record<string, string> = {};
  const checkOne = (f: Field, v: any, key: string, prefix = '') => {
    const lbl = prefix + '«' + f.label + '»';
    if (isEmpty(v)) return;
    switch (f.type) {
      case 'text': case 'textarea': case 'phone': case 'email': {
        const s = String(v).trim();
        if (f.max_len && s.length > f.max_len) errs[key] = `Поле ${lbl}: не более ${f.max_len} символов`;
        else if (f.min_len && s.length < f.min_len) errs[key] = `Поле ${lbl}: не менее ${f.min_len} символов`;
        else if (f.type === 'email' && !emailRe.test(s)) errs[key] = `Поле ${lbl}: укажите корректный email`;
        else if (f.type === 'phone' && !phoneRe.test(s)) errs[key] = `Поле ${lbl}: укажите корректный телефон`;
        else if (f.pattern) { try { if (!new RegExp(f.pattern).test(s)) errs[key] = f.pattern_msg || `Поле ${lbl}: значение не соответствует формату`; } catch {} }
        break;
      }
      case 'number': case 'money': {
        const n = toNum(v);
        if (n === null) errs[key] = `Поле ${lbl}: ожидается число`;
        else if (toNum(f.min) !== null && n < toNum(f.min)!) errs[key] = `Поле ${lbl}: не меньше ${f.min}`;
        else if (toNum(f.max) !== null && n > toNum(f.max)!) errs[key] = `Поле ${lbl}: не больше ${f.max}`;
        break;
      }
      case 'date': {
        const lim = (b: any) => (b === 'today' ? todayIso() : typeof b === 'string' ? b : '');
        if (lim(f.min) && v < lim(f.min)) errs[key] = `Поле ${lbl}: не раньше ${dmy(lim(f.min))}`;
        else if (lim(f.max) && v > lim(f.max)) errs[key] = `Поле ${lbl}: не позже ${dmy(lim(f.max))}`;
        break;
      }
      case 'period': {
        if (!v.from || !v.to) errs[key] = `Поле ${lbl}: укажите даты начала и окончания`;
        else if (v.to < v.from) errs[key] = `Поле ${lbl}: окончание раньше начала`;
        else {
          const lim = f.min === 'today' ? todayIso() : typeof f.min === 'string' ? f.min : '';
          if (lim && v.from < lim) errs[key] = `Поле ${lbl}: не раньше ${dmy(lim)}`;
          const mx = toNum(f.max);
          if (mx !== null && countDays(v.from, v.to).days > mx) errs[key] = `Поле ${lbl}: период не более ${mx} дн.`;
        }
        break;
      }
    }
  };
  schema.sections.forEach((sec, si) => {
    if (sectionIdx !== undefined && si !== sectionIdx) return;
    if (!evalCond(sec.visible_if, data)) return;
    for (const f of sec.fields) {
      if (isDisplay(f.type) || !evalCond(f.visible_if, data)) continue;
      const v = data[f.key];
      if (isEmpty(v)) {
        if (f.required || (f.required_if && evalCond(f.required_if, data))) errs[f.key] = `Заполните поле «${f.label}»`;
        if (f.type === 'table' && f.min_rows) errs[f.key] = `Таблица «${f.label}»: минимум строк — ${f.min_rows}`;
        continue;
      }
      if (f.type === 'table') {
        const rows: any[] = v || [];
        if (f.min_rows && rows.length < f.min_rows) errs[f.key] = `Таблица «${f.label}»: минимум строк — ${f.min_rows}`;
        rows.forEach((r, ri) => (f.columns || []).forEach((c) => {
          const cv = r?.[c.key];
          if (isEmpty(cv)) { if (c.required) errs[`${f.key}.${ri}.${c.key}`] = `Строка ${ri + 1}: заполните «${c.label}»`; }
          else checkOne(c, cv, `${f.key}.${ri}.${c.key}`, `Строка ${ri + 1}, `);
        }));
        continue;
      }
      checkOne(f, v, f.key);
    }
  });
  return errs;
}

/** Только видимые поля с данными (для шагов-секций и итоговой отправки). */
export function cleanData(schema: Schema, data: Record<string, any>): Record<string, any> {
  const out: Record<string, any> = {};
  for (const sec of schema.sections) {
    if (!evalCond(sec.visible_if, data)) continue;
    for (const f of sec.fields) if (!isDisplay(f.type) && evalCond(f.visible_if, data) && !isEmpty(data[f.key])) out[f.key] = data[f.key];
  }
  return out;
}

// ---------------------------------------------------------------- отображение значений

export function fmtValue(f: Field, v: any): string {
  if (isEmpty(v)) return '';
  const label = (x: any) => f.options?.find((o) => o.value === valKey(x))?.label ?? valKey(x);
  switch (f.type) {
    case 'date': return dmy(String(v));
    case 'period': return `${dmy(v.from)} — ${dmy(v.to)}` + (v.days ? ` (${v.days} ${plural(v.days, ['календарный день', 'календарных дня', 'календарных дней'])}, рабочих: ${v.workdays})` : '');
    case 'select': case 'radio': return label(v);
    case 'checkboxes': return (v as any[]).map(label).join(', ');
    case 'switch': return v ? 'Да' : 'Нет';
    case 'user': return (Array.isArray(v) ? v : [v]).map((x: any) => x.name).join(', ');
    case 'department': return v.name || '';
    case 'file': return (v as any[]).map((x) => x.name).join(', ');
    case 'money': return Number(v).toLocaleString('ru', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ₽';
    case 'number': return Number(v).toLocaleString('ru') + (f.unit ? ' ' + f.unit : '');
  }
  return String(v);
}

export const newKey = (schema: Schema, base = 'field'): string => {
  const used = new Set<string>();
  schema.sections.forEach((s) => s.fields.forEach((f) => { used.add(f.key); f.columns?.forEach((c) => used.add(c.key)); }));
  let i = 1;
  while (used.has(`${base}_${i}`)) i++;
  return `${base}_${i}`;
};
export const uid = () => Math.random().toString(36).slice(2, 10);
const TR: Record<string, string> = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'c', ч: 'ch', ш: 'sh', щ: 'sch', ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya' };
/** Ключ поля из подписи: «Дата начала» → date_nachala_… (латиница, цифры, _). */
export function keyFromLabel(label: string, schema: Schema, self?: string): string {
  let k = label.toLowerCase().split('').map((c) => TR[c] ?? c).join('').replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 30);
  if (!/^[a-z]/.test(k)) k = 'f_' + k;
  const used = new Set<string>();
  schema.sections.forEach((s) => s.fields.forEach((f) => { if (f.key !== self) used.add(f.key); }));
  let out = k, i = 2;
  while (used.has(out)) out = k + '_' + i++;
  return out;
}
