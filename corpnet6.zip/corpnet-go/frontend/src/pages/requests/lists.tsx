import React, { useEffect, useMemo, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { useQuery, invalidate } from '../../lib/query';
import { Link, pageHref, navigate, useSearchParams } from '../../lib/router';
import { usePersist } from '../../lib/persist';
import { toast } from '../../lib/store';
import { cx, fmtDate, useDebounced } from '../../lib/util';
import { Badge, Btn, Empty, ErrorBox, Input, Loading, Pager, Select, Tabs } from '../../ui';
import { TypeIcon } from './icons';
import { STATUS, STATUS_GROUPS } from './model';

export interface ReqRow {
  id: number; number: string; title: string; status: string; type_id: number; type_name: string; type_icon: string; type_color: string;
  author_id: number; author: string; created_at: string; submitted_at: string | null; updated_at: string; due_at: string | null; info_asked: boolean;
  step_name: string | null; waiting: string[]; my_due_at?: string | null; overdue?: boolean; my_step_id?: number; my_kind?: string;
}
export interface Catalog {
  types: { id: number; category_id: number | null; name: string; description: string; icon: string; color: string; sla_value: number; sla_unit: string }[];
  categories: { id: number; name: string; icon: string; color: string }[];
  frequent: { type_id: number; n: number }[];
  view_types: { id: number; name: string; icon: string; color: string }[];
  view_all: boolean; can_manage: boolean;
}
export const useCatalog = () => useQuery<Catalog>('req:catalog', () => api.get('/api/requests/catalog'), { stale: 60000 });

export const StatusBadge = ({ s, info }: { s: string; info?: boolean }) => (
  <><Badge kind={STATUS[s]?.kind}>{STATUS[s]?.label || s}</Badge>{info && <Badge kind="warn"><I.Message size={12} /> вопрос</Badge>}</>
);

interface Filters { status: string; type: string; q: string; from: string; to: string; view: 'table' | 'cards'; overdue: boolean }
const DEF: Filters = { status: 'all', type: '', q: '', from: '', to: '', view: 'table', overdue: false };
const TITLES: Record<string, string> = { mine: 'Мои заявки', inbox: 'На мне', participated: 'Прошли через меня', type: 'Все заявки типа' };

export function RequestsList({ scope, kind }: { scope: 'mine' | 'inbox' | 'participated' | 'type'; kind?: string }) {
  const cat = useCatalog();
  const [f, setF] = usePersist<Filters>('req.f.' + scope + (kind || ''), DEF);
  const flt = { ...DEF, ...f };
  const [sp] = useSearchParams();
  const page = Math.max(1, +(sp.get('page') || 1));
  const dq = useDebounced(flt.q.trim(), 300);
  const [sel, setSel] = useState<Set<number>>(new Set());
  const [busy, setBusy] = useState(false);
  const per = 20;
  const typeId = flt.type || (scope === 'type' ? String(cat.data?.view_types[0]?.id || '') : '');
  const grp = STATUS_GROUPS.find((g) => g.id === flt.status) || STATUS_GROUPS[0];
  const qs = useMemo(() => {
    const p = new URLSearchParams({ scope, page: String(page), per: String(per) });
    if (grp.list && scope !== 'inbox') p.set('status', grp.list);
    if (typeId) p.set('type_id', typeId);
    if (dq) p.set('q', dq);
    if (flt.from) p.set('from', flt.from);
    if (flt.to) p.set('to', flt.to);
    if (scope === 'inbox' && flt.overdue) p.set('overdue', '1');
    if (scope === 'inbox' && kind) p.set('kind', kind);
    return p.toString();
  }, [scope, kind, page, grp.list, typeId, dq, flt.from, flt.to, flt.overdue]);
  const enabled = scope !== 'type' || !!typeId;
  const q = useQuery<{ items: ReqRow[]; total: number; capped: boolean }>(enabled ? 'req:list:' + qs : null, () => api.get('/api/requests?' + qs), { stale: 10000, keepPrevious: true });
  useEffect(() => setSel(new Set()), [qs]);
  const set = (patch: Partial<Filters>) => { setF({ ...flt, ...patch }); if (page > 1) navigate(pageHref(1), { replace: true }); };
  const items = q.data?.items || [];
  const kinds = new Set(items.filter((r) => sel.has(r.id)).map((r) => r.my_kind));
  const bulkAction = kinds.size === 1 ? ({ approve: 'approve', execute: 'execute', inform: 'ack' } as any)[[...kinds][0] as string] : '';
  const bulkLabel = { approve: 'Согласовать', execute: 'Исполнить', ack: 'Ознакомлен(а)' } as any;

  async function bulk() {
    setBusy(true);
    try {
      const r = await api.post('/api/requests/bulk', { ids: [...sel], action: bulkAction });
      const ok = r.results.filter((x: any) => x.ok).length;
      const bad = r.results.filter((x: any) => !x.ok);
      toast({ title: `Выполнено: ${ok} из ${r.results.length}`, body: bad.length ? bad.slice(0, 3).map((b: any) => '#' + b.id + ': ' + b.error).join('\n') : undefined, kind: bad.length ? 'error' : 'success' });
      setSel(new Set());
      invalidate('req:');
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  const exportUrl = `/api/requests/export.csv?type_id=${typeId}` + (grp.list ? '&status=' + grp.list : '') + (dq ? '&q=' + encodeURIComponent(dq) : '') + (flt.from ? '&from=' + flt.from : '') + (flt.to ? '&to=' + flt.to : '');

  const typeOpts = scope === 'type' ? (cat.data?.view_types || []) : (cat.data?.types || []);
  return (
    <div className="card">
      <div className="rqBar">
        <div className="grow" style={{ position: 'relative' }}>
          <Input placeholder="Поиск по номеру, теме, заявителю…" value={flt.q} onChange={(e) => set({ q: e.target.value })} aria-label="Поиск" />
        </div>
        {scope !== 'inbox' && (
          <Select className="w230" value={flt.status} onChange={(e) => set({ status: e.target.value })} aria-label="Статус">
            {STATUS_GROUPS.map((g) => <option key={g.id} value={g.id}>{g.label}</option>)}
          </Select>
        )}
        <Select className="w230" value={scope === 'type' ? typeId : flt.type} onChange={(e) => set({ type: e.target.value })} aria-label="Тип заявки">
          {scope !== 'type' && <option value="">Все типы</option>}
          {typeOpts.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
        </Select>
        <Input type="date" className="w160" value={flt.from} onChange={(e) => set({ from: e.target.value })} aria-label="Создана с" title="Создана с" />
        <Input type="date" className="w160" value={flt.to} onChange={(e) => set({ to: e.target.value })} aria-label="Создана по" title="Создана по" />
        {scope === 'inbox' && <label className="chk small"><input type="checkbox" checked={flt.overdue} onChange={(e) => set({ overdue: e.target.checked })} /> Просроченные</label>}
        <div className="rqViewSw" role="group" aria-label="Вид">
          <button className={cx(flt.view === 'table' && 'on')} onClick={() => setF({ ...flt, view: 'table' })} aria-label="Таблица" title="Таблица"><I.List size={17} /></button>
          <button className={cx(flt.view === 'cards' && 'on')} onClick={() => setF({ ...flt, view: 'cards' })} aria-label="Карточки" title="Карточки"><I.Layers size={17} /></button>
        </div>
        {scope === 'type' && typeId && <a className="btn" href={exportUrl} download><I.Download size={16} /> CSV</a>}
      </div>
      {scope === 'inbox' && sel.size > 0 && (
        <div className="rqBulk">
          <b>Выбрано: {sel.size}</b>
          {bulkAction ? <Btn kind="pri" size="sm" busy={busy} onClick={bulk}><I.Check size={15} /> {bulkLabel[bulkAction]}</Btn> : <span className="muted small">Для массового действия выберите заявки одного вида шага</span>}
          <Btn size="sm" kind="ghost" onClick={() => setSel(new Set())}>Снять выбор</Btn>
        </div>
      )}
      {!enabled ? <Empty icon={I.Lock} title="Нет типов для просмотра">Вы не назначены ответственным или наблюдателем ни одного типа заявок.</Empty>
        : q.error && !q.data ? <ErrorBox error={q.error} retry={q.refetch} />
        : !q.data ? <Loading />
        : items.length === 0 ? <Empty icon={I.FileText} title={scope === 'inbox' ? 'Нет заявок, ожидающих вашего решения' : 'Заявок не найдено'}>{scope === 'mine' ? <Link to="/requests" className="btn pri" style={{ marginTop: 10 }}>Создать заявку</Link> : 'Измените фильтры или зайдите позже.'}</Empty>
        : flt.view === 'cards' ? (
          <div className="rqCards">
            {items.map((r) => (
              <Link key={r.id} to={`/requests/${r.id}`} className={cx('rqCard', r.overdue && 'late')}>
                <div className="row"><TypeIcon name={r.type_icon} color={r.type_color} size={18} box={34} /><div style={{ minWidth: 0 }}><div className="bold clip">{r.number || 'Черновик'}</div><div className="tiny muted clip">{r.type_name}</div></div><span className="sp" /><StatusBadge s={r.status} info={r.info_asked} /></div>
                <div className="clamp2 small">{r.title}</div>
                <div className="tiny muted">{scope !== 'mine' && r.author + ' · '}{fmtDate(r.created_at)}{r.step_name && r.status === 'pending' ? ' · ' + r.step_name : ''}</div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="tblW">
            <table className="tbl rqTbl">
              <thead><tr>
                {scope === 'inbox' && <th style={{ width: 34 }}><input type="checkbox" aria-label="Выбрать все" checked={items.length > 0 && sel.size === items.length} onChange={(e) => setSel(e.target.checked ? new Set(items.map((x) => x.id)) : new Set())} /></th>}
                <th>Номер</th><th>Заявка</th>{scope !== 'mine' && <th>Заявитель</th>}<th>Статус</th><th>{scope === 'inbox' ? 'Срок' : 'Этап'}</th><th>Создана</th>
              </tr></thead>
              <tbody>
                {items.map((r) => (
                  <tr key={r.id} className={cx(r.overdue && 'late')} onClick={(e) => { if ((e.target as HTMLElement).closest('a,input,button')) return; navigate(`/requests/${r.id}`); }} style={{ cursor: 'pointer' }}>
                    {scope === 'inbox' && <td><input type="checkbox" aria-label="Выбрать" checked={sel.has(r.id)} onChange={(e) => setSel((o) => { const n = new Set(o); e.target.checked ? n.add(r.id) : n.delete(r.id); return n; })} /></td>}
                    <td className="bold" style={{ whiteSpace: 'nowrap' }}><Link to={r.my_step_id ? `/requests/${r.id}#step-${r.my_step_id}` : `/requests/${r.id}`}>{r.number || '— черновик'}</Link></td>
                    <td><div className="row"><TypeIcon name={r.type_icon} color={r.type_color} size={16} box={30} /><div style={{ minWidth: 0 }}><div className="clip bold small">{r.type_name}</div><div className="clip tiny muted" style={{ maxWidth: 360 }}>{r.title.replace(r.type_name, '').replace(/^: /, '')}</div></div></div></td>
                    {scope !== 'mine' && <td className="small">{r.author}</td>}
                    <td><StatusBadge s={r.status} info={r.info_asked} /></td>
                    <td className="small">
                      {scope === 'inbox' ? (r.my_due_at ? <span className={cx(r.overdue && 'rqLate')}>{r.overdue && <I.Alert size={13} />} {fmtDate(r.my_due_at)}</span> : <span className="faint">без срока</span>)
                        : r.status === 'pending' || r.status === 'in_progress' ? <div><div className="clip" style={{ maxWidth: 220 }}>{r.step_name}</div>{r.waiting?.length > 0 && <div className="tiny muted clip" style={{ maxWidth: 220 }}>{r.waiting.join(', ')}</div>}</div>
                        : <span className="faint">—</span>}
                    </td>
                    <td className="small muted" style={{ whiteSpace: 'nowrap' }}>{fmtDate(r.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      {q.data && q.data.total > per && (
        <div className="padS"><Pager page={page} total={q.data.total} per={per} capped={q.data.capped} href={pageHref} onChange={(p) => navigate(pageHref(p))} /></div>
      )}
    </div>
  );
}
