import React, { useRef, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { cx, fmtSize } from '../../lib/util';
import { Btn, Field as UiField, Input, Select, Switch, Textarea, UserPicker } from '../../ui';
import type { UserLite } from '../../ui';
import { DeptSelect, useDepartments } from '../../ui/DeptSelect';
import { Markdown } from '../../lib/markdown';
import { countDays, dmy, evalCond, isEmpty, plural, todayIso, validateData } from './model';
import type { Field, Schema } from './model';

const span = (w?: string) => (w === '1/2' ? 3 : w === '1/3' ? 2 : 6);

interface CtlProps { f: Field; value: any; onChange: (v: any) => void; error?: string; disabled?: boolean; preview?: boolean; compact?: boolean }

function FileInput({ f, value, onChange, disabled, preview }: CtlProps) {
  const files: any[] = value || [];
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const max = f.max_files || (f.multiple ? 10 : 1);
  async function add(list: FileList | null) {
    if (!list?.length) return;
    setErr(''); setBusy(true);
    let cur = [...files];
    try {
      for (const file of Array.from(list)) {
        if (cur.length >= max) { setErr(`Не более ${max} файлов`); break; }
        const r = await api.upload('/api/requests/files', file);
        cur = [...cur, { id: r.id, name: r.name, size: r.size, mime: r.mime }];
        onChange(cur);
      }
    } catch (e) { setErr(errMsg(e)); }
    setBusy(false);
    if (ref.current) ref.current.value = '';
  }
  return (
    <div className="stackS">
      {files.map((x) => (
        <div className="rqFile" key={x.id}>
          <I.Paperclip size={16} />
          <a href={`/files/${x.id}?dl=1`} target="_blank" rel="noopener noreferrer" className="clip">{x.name}</a>
          <span className="tiny faint">{fmtSize(x.size)}</span>
          {!disabled && <button type="button" className="btn ghost sm icon" aria-label="Убрать" onClick={() => onChange(files.filter((y) => y.id !== x.id))}><I.X size={15} /></button>}
        </div>
      ))}
      {!disabled && files.length < max && (
        <div>
          <input ref={ref} type="file" hidden multiple={f.multiple && max > 1} accept={f.accept || undefined} onChange={(e) => add(e.target.files)} />
          <Btn type="button" size="sm" busy={busy} disabled={preview} onClick={() => ref.current?.click()}><I.Upload size={15} /> {preview ? 'Загрузка в предпросмотре отключена' : 'Прикрепить файл'}</Btn>
        </div>
      )}
      {err && <div className="err">{err}</div>}
    </div>
  );
}

function DeptInput({ value, onChange, disabled }: CtlProps) {
  const { data } = useDepartments();
  if (disabled) return <Input value={value?.name || ''} disabled readOnly />;
  return <DeptSelect value={value?.id ?? null} allowEmpty emptyLabel="— не выбрано —" onChange={(id) => onChange(id == null ? undefined : { id, name: (data || []).find((d) => d.id === id)?.name || '' })} />;
}

function Control(p: CtlProps) {
  const { f, value, onChange, disabled } = p;
  const num = (v: string) => (v === '' ? undefined : Number(v));
  switch (f.type) {
    case 'text': case 'phone': case 'email':
      return <Input type={f.type === 'phone' ? 'tel' : f.type === 'email' ? 'email' : 'text'} value={value ?? ''} placeholder={f.placeholder} maxLength={f.max_len || 500} disabled={disabled} onChange={(e) => onChange(e.target.value)} />;
    case 'textarea':
      return <Textarea rows={4} value={value ?? ''} placeholder={f.placeholder} maxLength={f.max_len || 10000} disabled={disabled} onChange={(e) => onChange(e.target.value)} />;
    case 'number': case 'money':
      return (
        <div className="rqUnit">
          <Input type="number" inputMode="decimal" step={f.type === 'money' ? '0.01' : 'any'} min={f.min as any} max={f.max as any} value={value ?? ''} placeholder={f.placeholder} disabled={disabled} onChange={(e) => onChange(num(e.target.value))} />
          {(f.type === 'money' || f.unit) && <span className="rqUnitTag">{f.type === 'money' ? '₽' : f.unit}</span>}
        </div>
      );
    case 'date':
      return <Input type="date" value={value ?? ''} min={f.min === 'today' ? todayIso() : f.min} max={f.max === 'today' ? todayIso() : f.max} disabled={disabled} onChange={(e) => onChange(e.target.value || undefined)} />;
    case 'time':
      return <Input type="time" value={value ?? ''} disabled={disabled} onChange={(e) => onChange(e.target.value || undefined)} />;
    case 'period': {
      const v = value || {};
      const set = (k: 'from' | 'to', x: string) => {
        const n = { ...v, [k]: x };
        if (k === 'from' && n.to && n.to < x) n.to = x;
        if (!n.from && !n.to) return onChange(undefined);
        if (n.from && n.to) Object.assign(n, { days: countDays(n.from, n.to).days, workdays: countDays(n.from, n.to).workdays });
        else { delete n.days; delete n.workdays; }
        onChange(n);
      };
      const c = v.from && v.to ? countDays(v.from, v.to) : null;
      return (
        <div className="stackS">
          <div className="rqPeriod">
            <Input type="date" aria-label="Начало" value={v.from ?? ''} min={f.min === 'today' ? todayIso() : f.min} disabled={disabled} onChange={(e) => set('from', e.target.value)} />
            <span className="muted">—</span>
            <Input type="date" aria-label="Окончание" value={v.to ?? ''} min={v.from || (f.min === 'today' ? todayIso() : f.min)} disabled={disabled} onChange={(e) => set('to', e.target.value)} />
          </div>
          {c && c.days > 0 && <div className="rqCalc"><I.Calendar size={15} /> {c.days} {plural(c.days, ['календарный день', 'календарных дня', 'календарных дней'])} · {c.workdays} {plural(c.workdays, ['рабочий день', 'рабочих дня', 'рабочих дней'])}</div>}
        </div>
      );
    }
    case 'select':
      return (
        <Select value={value ?? ''} disabled={disabled} onChange={(e) => onChange(e.target.value || undefined)}>
          <option value="">{f.placeholder || '— выберите —'}</option>
          {(f.options || []).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </Select>
      );
    case 'radio':
      return (
        <div className="rqOpts" role="radiogroup">
          {(f.options || []).map((o) => (
            <label key={o.value} className={cx('rqOpt', value === o.value && 'on')}>
              <input type="radio" name={'rq_' + f.key} checked={value === o.value} disabled={disabled} onChange={() => onChange(o.value)} />{o.label}
            </label>
          ))}
        </div>
      );
    case 'checkboxes': {
      const cur: string[] = value || [];
      return (
        <div className="rqOpts">
          {(f.options || []).map((o) => (
            <label key={o.value} className={cx('rqOpt', cur.includes(o.value) && 'on')}>
              <input type="checkbox" checked={cur.includes(o.value)} disabled={disabled} onChange={(e) => { const n = e.target.checked ? [...cur, o.value] : cur.filter((x) => x !== o.value); onChange(n.length ? n : undefined); }} />{o.label}
            </label>
          ))}
        </div>
      );
    }
    case 'switch':
      return <Switch checked={!!value} onChange={(v) => onChange(v)} label={<span className="muted small">{value ? 'Да' : 'Нет'}</span>} />;
    case 'user': {
      const list: UserLite[] = (Array.isArray(value) ? value : value ? [value] : []).map((u: any) => ({ id: u.id, name: u.name }));
      if (disabled) return <Input value={list.map((u) => u.name).join(', ')} disabled readOnly />;
      return <UserPicker value={list} single={!f.multiple} placeholder={f.placeholder || 'Найти сотрудника…'}
        onChange={(l) => onChange(l.length ? (f.multiple ? l.map((u) => ({ id: u.id, name: u.name })) : { id: l[0].id, name: l[0].name }) : undefined)} />;
    }
    case 'department': return <DeptInput {...p} />;
    case 'file': return <FileInput {...p} />;
    case 'table': return <TableInput {...p} />;
  }
  return null;
}

function TableInput({ f, value, onChange, disabled, error }: CtlProps) {
  const rows: any[] = value || [];
  const cols = f.columns || [];
  const max = f.max_rows || 100;
  const setCell = (ri: number, k: string, v: any) => {
    const n = rows.map((r, i) => (i === ri ? { ...r, [k]: v } : r));
    onChange(n.map((r) => Object.fromEntries(Object.entries(r).filter(([, x]) => x !== undefined))));
  };
  return (
    <div className="rqTable">
      <div className="tblW">
        <table className="tbl">
          <thead><tr><th style={{ width: 36 }}>#</th>{cols.map((c) => <th key={c.key}>{c.label}{c.required ? ' *' : ''}</th>)}<th /></tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={cols.length + 2} className="muted small" style={{ textAlign: 'center' }}>Строк нет — добавьте первую</td></tr>}
            {rows.map((r, ri) => (
              <tr key={ri}>
                <td className="muted">{ri + 1}</td>
                {cols.map((c) => (
                  <td key={c.key} data-err={error?.includes('Строка ' + (ri + 1)) ? 1 : undefined}>
                    <Control f={{ ...c, placeholder: c.label }} value={r[c.key]} onChange={(v) => setCell(ri, c.key, v)} disabled={disabled} compact />
                  </td>
                ))}
                <td className="act">{!disabled && <button type="button" className="btn ghost sm icon" aria-label="Удалить строку" onClick={() => onChange(rows.filter((_, i) => i !== ri))}><I.Trash size={15} /></button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!disabled && rows.length < max && <Btn type="button" size="sm" onClick={() => onChange([...rows, {}])}><I.Plus size={15} /> Добавить строку</Btn>}
    </div>
  );
}

/** Динамическая форма по схеме: условная видимость/обязательность, секции, пошаговый режим. */
export function FormView({ schema, data, setData, errors = {}, disabled, preview, children, onStepErrors }: {
  schema: Schema; data: Record<string, any>; setData: (d: Record<string, any>) => void; errors?: Record<string, string>; disabled?: boolean; preview?: boolean;
  children?: React.ReactNode; onStepErrors?: (e: Record<string, string>) => void;
}) {
  const [step, setStep] = useState(0);
  const set = (k: string, v: any) => {
    const n = { ...data };
    if (v === undefined || (typeof v === 'string' && v === '')) delete n[k]; else n[k] = v;
    setData(n);
  };
  const visible = schema.sections.map((s, i) => ({ s, i })).filter(({ s }) => evalCond(s.visible_if, data));
  const wizard = schema.layout === 'wizard' && visible.length > 1;
  const cur = wizard ? Math.min(step, visible.length - 1) : -1;
  const shown = wizard ? [visible[cur]] : visible;
  const last = !wizard || cur === visible.length - 1;
  function next() {
    const errs = validateData(schema, data, visible[cur].i);
    onStepErrors?.(errs);
    if (Object.keys(errs).length === 0) { setStep(cur + 1); window.scrollTo({ top: 0, behavior: 'smooth' }); }
  }
  return (
    <div className="rqForm">
      {wizard && (
        <ol className="rqSteps" aria-label="Шаги формы">
          {visible.map(({ s }, i) => (
            <li key={s.id} className={cx(i === cur && 'on', i < cur && 'done')}><button type="button" disabled={i > cur} onClick={() => setStep(i)}><b>{i < cur ? <I.Check size={14} sw={3} /> : i + 1}</b><span>{s.title || 'Шаг ' + (i + 1)}</span></button></li>
          ))}
        </ol>
      )}
      {shown.map(({ s }) => (
        <section key={s.id} className="rqSec">
          {(s.title || s.desc) && <header>{s.title && <h3>{s.title}</h3>}{s.desc && <p className="muted small">{s.desc}</p>}</header>}
          <div className="rqGrid">
            {s.fields.filter((f) => evalCond(f.visible_if, data)).map((f, fi) => {
              const colStyle = { gridColumn: `span ${span(f.width)}` };
              if (f.type === 'heading') return <h4 key={f.key || fi} className="rqHeading" style={{ gridColumn: '1 / -1' }}>{f.label}</h4>;
              if (f.type === 'divider') return <hr key={f.key || fi} className="rqDiv" style={{ gridColumn: '1 / -1' }} />;
              if (f.type === 'note') return <div key={f.key || fi} className="notice rqNote" style={{ gridColumn: '1 / -1' }}><I.Info size={18} /><div><Markdown text={f.label} />{f.hint && <div className="small" style={{ opacity: .85 }}>{f.hint}</div>}</div></div>;
              const req = f.required || (f.required_if && evalCond(f.required_if, data));
              const err = errors[f.key] || Object.entries(errors).find(([k]) => k.startsWith(f.key + '.'))?.[1];
              return (
                <div key={f.key} id={'rq-f-' + f.key} className={cx('field rqField', err && 'bad')} style={colStyle}>
                  <label>{f.label}{req && <span className="rqReq"> *</span>}</label>
                  <Control f={f} value={data[f.key]} onChange={(v) => set(f.key, v)} error={err} disabled={disabled} preview={preview} />
                  {f.hint && <div className="hint">{f.hint}</div>}
                  {err && <div className="rqErr">{err}</div>}
                </div>
              );
            })}
          </div>
        </section>
      ))}
      {wizard && (
        <div className="rowW">
          <Btn type="button" disabled={cur === 0} onClick={() => setStep(cur - 1)}><I.ChevronLeft size={16} /> Назад</Btn>
          {!last && <Btn type="button" kind="pri" onClick={next}>Далее <I.ChevronRight size={16} /></Btn>}
        </div>
      )}
      {last && children}
    </div>
  );
}

/** Значение поля только для чтения (карточка заявки, печатная форма). */
export function ValueView({ f, v }: { f: Field; v: any }) {
  if (isEmpty(v)) return <span className="faint">—</span>;
  switch (f.type) {
    case 'file': return <div className="stackS">{(v as any[]).map((x) => <div className="rqFile" key={x.id}><I.Paperclip size={15} /><a href={`/files/${x.id}?dl=1`} target="_blank" rel="noopener noreferrer">{x.name}</a><span className="tiny faint">{fmtSize(x.size)}</span></div>)}</div>;
    case 'table':
      return (
        <div className="tblW"><table className="tbl rqRo">
          <thead><tr><th>#</th>{(f.columns || []).map((c) => <th key={c.key}>{c.label}</th>)}</tr></thead>
          <tbody>{(v as any[]).map((r, i) => <tr key={i}><td>{i + 1}</td>{(f.columns || []).map((c) => <td key={c.key}><ValueView f={c} v={r[c.key]} /></td>)}</tr>)}</tbody>
        </table></div>
      );
    case 'period': return <span>{dmy(v.from)} — {dmy(v.to)} <span className="muted">· {v.days} {plural(v.days, ['календарный день', 'календарных дня', 'календарных дней'])}, рабочих {v.workdays}</span></span>;
    case 'textarea': return <span style={{ whiteSpace: 'pre-wrap' }}>{String(v)}</span>;
    case 'user': return <span>{(Array.isArray(v) ? v : [v]).map((u: any, i: number) => <React.Fragment key={u.id}>{i > 0 && ', '}<a href={`/people/${u.id}`}>{u.name}</a></React.Fragment>)}</span>;
  }
  return <span>{(() => {
    const label = (x: any) => f.options?.find((o) => o.value === String(x))?.label ?? String(x);
    switch (f.type) {
      case 'date': return dmy(String(v));
      case 'select': case 'radio': return label(v);
      case 'checkboxes': return (v as any[]).map(label).join(', ');
      case 'switch': return v ? 'Да' : 'Нет';
      case 'department': return v.name;
      case 'money': return Number(v).toLocaleString('ru', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ₽';
      case 'number': return Number(v).toLocaleString('ru') + (f.unit ? ' ' + f.unit : '');
    }
    return String(v);
  })()}</span>;
}
