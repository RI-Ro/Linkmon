import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg, ApiError } from '../../lib/api';
import { useQuery, invalidate } from '../../lib/query';
import { Link, navigate, useTitle } from '../../lib/router';
import { useStore, toast } from '../../lib/store';
import { uid } from './model';
import { Badge, Btn, Empty, ErrorBox, Loading } from '../../ui';
import { Markdown } from '../../lib/markdown';
import { FormView } from './form';
import { TypeIcon } from './icons';
import { STEP_KIND, cleanData, defaultsFor, validateData } from './model';
import type { Schema } from './model';

interface FormInfo { type: { id: number; name: string; description: string; icon: string; color: string; active: boolean }; schema: Schema; route: { name: string; kind: string; conditional: boolean }[]; can_submit: boolean; version: number }

/** Подача новой заявки (typeId) или правка черновика / доработка (requestId). */
export function SubmitPage({ typeId, requestId }: { typeId?: number; requestId?: number }) {
  const me = useStore((s) => s.me)!;
  const editing = !!requestId;
  const form = useQuery<FormInfo>(typeId ? 'req:form:' + typeId : null, () => api.get(`/api/requests/types/${typeId}/form`), { stale: 0 });
  const card = useQuery<any>(requestId ? 'req:edit:' + requestId : null, () => api.get('/api/requests/' + requestId), { stale: 0 });
  const [data, setData] = useState<Record<string, any> | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState<'' | 'draft' | 'send'>('');
  const [msg, setMsg] = useState('');
  const clientId = useRef(uid() + uid());
  const schema: Schema | undefined = editing ? card.data?.schema : form.data?.schema;
  const info = editing ? card.data?.request : form.data?.type;
  useTitle(editing ? 'Редактирование заявки' : form.data?.type.name || 'Новая заявка');
  useEffect(() => {
    if (data) return;
    if (editing && card.data) setData(card.data.data || {});
    if (!editing && form.data) setData(defaultsFor(form.data.schema, me));
  }, [form.data, card.data]); // eslint-disable-line

  const err = editing ? card.error : form.error;
  if (err && !(editing ? card.data : form.data)) {
    return <div className="card">{(err as ApiError).status === 403 ? <Empty icon={I.Lock} title="Этот тип заявки вам недоступен">Обратитесь к ответственному за тип или к администратору.</Empty> : <ErrorBox error={err} retry={editing ? card.refetch : form.refetch} />}</div>;
  }
  if (!schema || !data || !info) return <Loading />;
  if (editing && !card.data.can.edit) return <div className="card"><Empty icon={I.Lock} title="Заявку нельзя редактировать">Править можно только черновик или заявку, возвращённую на доработку.<Link to={`/requests/${requestId}`} className="btn" style={{ marginTop: 10 }}>К заявке</Link></Empty></div>;
  const route = editing ? card.data.route.map((s: any) => ({ name: s.name, kind: s.kind, conditional: s.cond })) : form.data!.route;
  const rework = editing && card.data.request.status === 'rework';
  const comment = rework ? (card.data.events as any[]).filter((e) => e.kind === 'returned').slice(-1)[0] : null;

  async function save(submit: boolean) {
    setMsg('');
    const clean = cleanData(schema!, data!);
    if (submit) {
      const errs = validateData(schema!, clean);
      setErrors(errs);
      if (Object.keys(errs).length) {
        setMsg('Проверьте заполнение формы: ' + Object.values(errs)[0]);
        const first = Object.keys(errs)[0].split('.')[0];
        document.getElementById('rq-f-' + first)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }
    }
    setBusy(submit ? 'send' : 'draft');
    try {
      const r = editing
        ? await api.put(`/api/requests/${requestId}`, { data: clean, submit })
        : await api.post('/api/requests', { type_id: typeId, data: clean, submit, client_id: clientId.current });
      invalidate('req:');
      toast({ title: submit ? `Заявка ${r.number || ''} отправлена` : 'Черновик сохранён', kind: 'success' });
      navigate('/requests/' + r.id, { replace: true });
    } catch (e: any) {
      if (e instanceof ApiError && e.status === 422) {
        // сервер вернул ошибки по полям — покажем их; их текст приходит в поле error первой ошибкой
        try { const j = await fetchFields(e); setErrors(j); } catch {}
      }
      setMsg(errMsg(e));
      setBusy('');
    }
  }
  // ApiError не хранит тело; повторно проверим локально и добавим серверное сообщение к первому невалидному полю
  async function fetchFields(e: ApiError) {
    const errs = validateData(schema!, cleanData(schema!, data!));
    if (Object.keys(errs).length === 0) { const first = schema!.sections.flatMap((s) => s.fields).find((f) => f.required); if (first) errs[first.key] = e.message; }
    return errs;
  }

  return (
    <div className="stack rqSubmit">
      <div className="crumbs"><Link to="/requests"><I.ArrowLeft size={15} /> Заявки</Link></div>
      <div className="card pad">
        <div className="row" style={{ alignItems: 'flex-start', gap: 14 }}>
          <TypeIcon name={info.type_icon || info.icon} color={info.type_color || info.color} size={26} box={52} />
          <div style={{ minWidth: 0, flex: 1 }}>
            <h1 style={{ fontSize: 24, fontWeight: 800 }}>{info.type_name || info.name}</h1>
            {editing && <div className="muted small">{card.data.request.number || 'Черновик'} · <Badge kind={rework ? 'warn' : undefined}>{rework ? 'На доработке' : 'Черновик'}</Badge></div>}
          </div>
        </div>
        {(info.description || info.type_description) && <div className="rqDesc"><Markdown text={info.description || info.type_description} /></div>}
      </div>
      {rework && comment && <div className="notice warn"><I.Alert size={18} /><div><b>Заявка возвращена на доработку.</b> {comment.actor}: «{comment.text}»<div className="small">Исправьте данные и отправьте повторно — согласование начнётся с первого шага.</div></div></div>}
      <div className="card pad">
        <FormView schema={schema} data={data} setData={setData} errors={errors} onStepErrors={setErrors}>
          {route.length > 0 && (
            <div className="rqRoutePrev">
              <div className="lbl" style={{ marginBottom: 6 }}>Маршрут согласования</div>
              <ol>{route.map((s: any, i: number) => <li key={i}><span className={'rqKind ' + s.kind}>{STEP_KIND[s.kind]}</span> {s.name}{s.conditional && <span className="tiny faint"> · по условию</span>}</li>)}</ol>
            </div>
          )}
          {msg && <div className="err">{msg}</div>}
          <div className="rowW" style={{ marginTop: 8 }}>
            <Btn kind="pri" size="lg" busy={busy === 'send'} disabled={!!busy} onClick={() => save(true)}><I.Send size={17} /> {rework ? 'Отправить повторно' : 'Отправить заявку'}</Btn>
            <Btn size="lg" busy={busy === 'draft'} disabled={!!busy} onClick={() => save(false)}>Сохранить черновик</Btn>
            <Link to={editing ? `/requests/${requestId}` : '/requests'} className="btn ghost">Отмена</Link>
          </div>
        </FormView>
      </div>
    </div>
  );
}
