import React from 'react';
import * as I from '../../lib/icons';

/** Иконка раздела «Заявки» в меню (Lucide clipboard-list). */
export const ReqIcon = (p: I.IconProps) => (
  <svg viewBox="0 0 24 24" width={p.size ?? 18} height={p.size ?? 18} fill="none" stroke="currentColor" strokeWidth={p.sw ?? 2} strokeLinecap="round" strokeLinejoin="round" className={p.className} style={p.style} aria-hidden="true">
    <rect width="8" height="4" x="8" y="2" rx="1" ry="1" /><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /><path d="M12 11h4" /><path d="M12 16h4" /><path d="M8 11h.01" /><path d="M8 16h.01" />
  </svg>
);

export const TYPE_ICONS: Record<string, (p: I.IconProps) => React.ReactElement> = {
  file: I.FileText, calendar: I.Calendar, cpu: I.Cpu, briefcase: I.Briefcase, building: I.Building, mail: I.Mail, clock: I.Clock, key: I.Key, tag: I.Tag, shield: I.Shield,
  book: I.Book, phone: I.Phone, server: I.Server, database: I.Database, star: I.Star, zap: I.Zap, users: I.Users, home: I.Home, globe: I.Globe, lightbulb: I.Lightbulb,
  gradcap: I.GradCap, heart: I.Heart, wifi: I.Wifi, image: I.Image, folder: I.Folder, chart: I.Chart, settings: I.Settings, activity: I.Activity, link: I.Link, request: ReqIcon,
};
export const ICON_NAMES = Object.keys(TYPE_ICONS);
export function TypeIcon({ name, color, size = 22, box = 40 }: { name?: string; color?: string; size?: number; box?: number }) {
  const Ic = TYPE_ICONS[name || 'file'] || I.FileText;
  return <span className="rqIco" style={{ width: box, height: box, background: `color-mix(in srgb, ${color || 'var(--accent)'} 16%, transparent)`, color: color || 'var(--accent)' }}><Ic size={size} /></span>;
}
