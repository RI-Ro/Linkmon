import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { Link, navigate, useSearchParams, useTitle } from '../lib/router';
import { useStore, toast } from '../lib/store';
import { realtime, useRealtime } from '../lib/ws';
import { cx, fmtChatTime, fmtDay, fmtTime, sameDay, thumb, fmtSize, imgFallback } from '../lib/util';
import { usePdfPreview } from '../ui/PdfViewer';
import { Avatar, Btn, Empty, FileIcon, Loading, Modal, UserPicker, UserLite, Input, Field, useConfirm, usePopover } from '../ui';
import { Poll, PollCard, PollModal } from './polls';
import './cal-groups.css';
import { stripMd } from '../lib/markdown';
import { EmojiButton, TextAssist } from '../ui/EmojiPicker';
import { Reactions, ReactionAddButton, type Rx } from '../ui/Reactions';
import { BookmarkButton } from '../ui/Bookmark';
import { RichText, isStickerOnly, previewText } from '../lib/richtext';

interface Msg {
  id: number; chat_id: number; user_id: number; kind?: string; poll?: Poll | null; author: string; author_avatar: string; body: string; reply_to: number | null;
  reply_body: string | null; reply_author: string | null; client_id: string | null; created_at: string; edited_at: string | null; deleted: boolean;
  file: { id: number; name: string; mime: string; size: number; width: number; height: number } | null;
  reactions?: Rx[]; bookmarked?: boolean;
  _state?: 'pending' | 'failed'; _local?: { fileName?: string };
}
interface Read { user_id: number; last_read_id: number }

const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2) + Date.now().toString(36));

export function MessengerPage() {
  useTitle('Сообщения');
  const [sp, setSp] = useSearchParams();
  const chatId = +(sp.get('chat') || 0);
  const chats = useQuery<any[]>('chats', () => api.get('/api/chats'), { stale: 20000 });
  const [filter, setFilter] = useState('');
  const [creating, setCreating] = useState(false);
  const online = useStore((s) => s.online);
  const list = (chats.data || []).filter((c) => !filter || c.title.toLowerCase().includes(filter.toLowerCase()));
  const current = chats.data?.find((c) => c.id === chatId);
  useRealtime('chat.hide', () => invalidate('chats'));
  useRealtime('chat.clear', () => invalidate('chats'));
  return (
    <div className={cx('card msgr', chatId && 'open')}>
      <div className="chatList">
        <div className="top">
          <div className="row"><h2 className="sp" style={{ fontSize: 20 }}>Сообщения</h2><Btn kind="pri" size="sm" icon onClick={() => setCreating(true)} title="Новый чат"><I.Plus size={18} /></Btn></div>
          <div style={{ position: 'relative' }}><Input placeholder="Поиск по чатам" value={filter} onChange={(e) => setFilter(e.target.value)} style={{ minHeight: 38, paddingLeft: 12 }} /></div>
        </div>
        <div className="lst">
          {!chats.data ? <Loading /> : list.length === 0 ? <Empty icon={I.Message} title="Чатов пока нет">Нажмите «+», чтобы начать диалог</Empty> : list.map((c) => (
            <div key={c.id} className={cx('chatRow', c.id === chatId && 'on')} onClick={() => setSp({ chat: c.id }, false)}>
              {c.kind === 'direct' ? <Avatar name={c.title} src={c.avatar} size={46} userId={c.peer_id} /> : <div className="av" style={{ '--s': '46px', '--h': (c.title.length * 37) % 360 } as any}><I.Users size={20} /></div>}
              <div className="sp" style={{ minWidth: 0 }}>
                <div className="nm clip">{c.title}</div>
                <div className="lm clip">{c.last_deleted ? 'Сообщение удалено' : c.last_kind === 'poll' ? '📊 Голосование: ' + c.last_body : c.last_body ? previewText(stripMd(c.last_body)) : c.last_has_file ? '📎 Вложение' : <span className="faint">Нет сообщений</span>}</div>
              </div>
              <div className="meta"><span>{fmtChatTime(c.last_message_at)}</span>{c.unread > 0 && <span className="cnt">{c.unread}</span>}</div>
            </div>
          ))}
        </div>
      </div>
      {chatId && chats.data && !chats.loading && !current ? <div className="chatMain chatEmpty"><div className="empty"><I.Message size={52} /><div className="bold">Чат не найден или недоступен</div><div>Возможно, вас удалили из чата или ссылка устарела.</div><Btn onClick={() => setSp({ chat: null }, false)}>К списку чатов</Btn></div></div> : chatId ? <ChatView key={chatId} id={chatId} summary={current} onBack={() => setSp({ chat: null }, false)} /> : <div className="chatMain chatEmpty"><div className="empty"><I.Message size={52} /><div className="bold">Выберите чат</div><div>или начните новый диалог</div></div></div>}
      {creating && <NewChatModal onClose={() => setCreating(false)} onCreated={(id) => { setCreating(false); invalidate('chats'); setSp({ chat: id }, false); }} />}
    </div>
  );
}

function NewChatModal({ onClose, onCreated }: { onClose: () => void; onCreated: (id: number) => void }) {
  const [users, setUsers] = useState<UserLite[]>([]);
  const [title, setTitle] = useState('');
  const [busy, setBusy] = useState(false);
  const me = useStore((s) => s.me)!;
  async function go() {
    setBusy(true);
    try {
      const c = users.length === 1 && !title ? await api.post('/api/chats', { user_id: users[0].id }) : await api.post('/api/chats', { user_ids: users.map((u) => u.id), title: title || users.map((u) => u.name.split(' ')[0]).join(', ') });
      onCreated(c.id);
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); setBusy(false); }
  }
  return (
    <Modal title="Новый чат" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={!users.length} onClick={go}>{users.length > 1 ? 'Создать группу' : 'Начать диалог'}</Btn></>}>
      <Field label="Участники" hint="Один человек — личный диалог, несколько — групповой чат"><UserPicker value={users} onChange={setUsers} exclude={[me.id]} /></Field>
      {users.length > 1 && <Field label="Название чата"><Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Например, «Проект Альфа»" /></Field>}
    </Modal>
  );
}

function ChatView({ id, summary, onBack }: { id: number; summary: any; onBack: () => void }) {
  const me = useStore((s) => s.me)!;
  const pdf = usePdfPreview(); // PDF из чата открываются во встроенном просмотре
  const info = useQuery<{ chat: any; members: any[] }>('chat:' + id, () => api.get('/api/chats/' + id), { stale: 30000 });
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [reads, setReads] = useState<Read[]>([]);
  const [hasMore, setHasMore] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [loadErr, setLoadErr] = useState('');
  const [text, setText] = useState('');
  const [reply, setReply] = useState<Msg | null>(null);
  const [editing, setEditing] = useState<Msg | null>(null);
  const [typing, setTyping] = useState<Record<number, string>>({});
  const [members, setMembers] = useState(false);
  const [pollOpen, setPollOpen] = useState(false);
  const menu = usePopover();
  const [up, setUp] = useState<number | null>(null);
  const [confirm, node] = useConfirm();
  const box = useRef<HTMLDivElement>(null);
  const stick = useRef(true);
  const lastTyping = useRef(0);
  const fileInp = useRef<HTMLInputElement>(null);
  const area = useRef<HTMLTextAreaElement>(null);
  const chat = info.data?.chat || summary;
  useTitle(chat?.title || 'Сообщения');

  const load = useCallback(async () => {
    try {
      const r = await api.get<{ items: Msg[]; has_more: boolean; reads: Read[] }>(`/api/chats/${id}/messages`);
      setMsgs((cur) => mergeMsgs(r.items, cur.filter((m) => m._state)));
      setReads(r.reads); setHasMore(r.has_more); setLoaded(true); setLoadErr('');
    } catch (e) { setLoadErr(errMsg(e)); setLoaded(true); }
  }, [id]);
  useEffect(() => { load(); }, [load]);
  useRealtime('reconnected', load, [load]);

  // mark as read (debounced; only when the tab is visible and the newest message is from somebody else)
  const readTimer = useRef<any>();
  const lastId = msgs.filter((m) => !m._state).at(-1)?.id || 0;
  useEffect(() => {
    if (!lastId || document.visibilityState !== 'visible') return;
    const my = reads.find((r) => r.user_id === me.id)?.last_read_id || 0;
    if (my >= lastId && !(summary?.unread > 0)) return;
    clearTimeout(readTimer.current);
    readTimer.current = setTimeout(() => {
      api.post(`/api/chats/${id}/read`, { message_id: lastId }).then(() => { setReads((rs) => rs.map((r) => (r.user_id === me.id ? { ...r, last_read_id: lastId } : r))); invalidate('chats'); }).catch(() => {});
    }, 350);
    return () => clearTimeout(readTimer.current);
  }, [lastId, id]);
  useEffect(() => {
    const vis = () => document.visibilityState === 'visible' && lastId && api.post(`/api/chats/${id}/read`, { message_id: lastId }).then(() => invalidate('chats')).catch(() => {});
    document.addEventListener('visibilitychange', vis);
    return () => document.removeEventListener('visibilitychange', vis);
  }, [lastId, id]);

  // realtime
  useRealtime('message', (d) => {
    if (d.chat_id !== id) return;
    const m: Msg = d.message;
    setMsgs((cur) => mergeMsgs(cur, [m]));
    setTyping((t) => { const { [m.user_id]: _, ...rest } = t; return rest; });
  }, [id]);
  useRealtime('message.update', (d) => d.chat_id === id && setMsgs((cur) => cur.map((m) => (m.id === d.message.id ? { ...m, ...d.message } : m))), [id]);
  useRealtime('read', (d) => d.chat_id === id && setReads((rs) => (rs.some((r) => r.user_id === d.user_id) ? rs.map((r) => (r.user_id === d.user_id ? { ...r, last_read_id: Math.max(r.last_read_id, d.last_read_id) } : r)) : [...rs, { user_id: d.user_id, last_read_id: d.last_read_id }])), [id]);
  useRealtime('chat.clear', (d) => { if (d.chat_id !== id) return; setMsgs((cur) => cur.filter((m) => m._state)); setHasMore(false); invalidate('chats'); }, [id]);
  useRealtime('chat.hide', (d) => { if (d.chat_id !== id) return; invalidate('chats'); onBack(); }, [id]);
  useRealtime('typing', (d) => {
    if (d.chat_id !== id) return;
    setTyping((t) => ({ ...t, [d.user_id]: d.name }));
    setTimeout(() => setTyping((t) => { const { [d.user_id]: _, ...rest } = t; return rest; }), 3000);
  }, [id]);

  // переход по ссылке-якорю /messages?chat=…&msg=… (упоминание, закладка): догружаем историю, пока сообщение не найдётся
  const [spp] = useSearchParams();
  const wantMsg = +(spp.get('msg') || 0);
  const jumped = useRef(0);
  useEffect(() => {
    if (!wantMsg || !loaded || jumped.current === wantMsg) return;
    const el = document.getElementById('msg-' + wantMsg);
    if (el) {
      jumped.current = wantMsg; stick.current = false;
      el.scrollIntoView({ block: 'center' });
      el.classList.add('hlc'); setTimeout(() => el.classList.remove('hlc'), 3500);
    } else if (hasMore) loadOlder();
    else jumped.current = wantMsg;
  }, [wantMsg, loaded, msgs.length, hasMore]);

  // scrolling
  useLayoutEffect(() => { if (stick.current && box.current) box.current.scrollTop = box.current.scrollHeight; }, [msgs.length, typing, loaded]);
  const onScroll = () => {
    const el = box.current!;
    stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 120;
    if (el.scrollTop < 60 && hasMore) loadOlder();
  };
  const loading = useRef(false);
  async function loadOlder() {
    if (loading.current) return;
    const first = msgs.find((m) => !m._state);
    if (!first) return;
    loading.current = true;
    const el = box.current!, prevH = el.scrollHeight;
    try {
      const r = await api.get<{ items: Msg[]; has_more: boolean }>(`/api/chats/${id}/messages?before=${first.id}`);
      setMsgs((cur) => mergeMsgs(r.items, cur)); setHasMore(r.has_more);
      requestAnimationFrame(() => { el.scrollTop = el.scrollHeight - prevH; });
    } catch {}
    loading.current = false;
  }

  async function post(body: string, fileId?: number, local?: Msg) {
    const cid = local?.client_id || uid();
    const tmp: Msg = local ? { ...local, _state: 'pending' } : { id: -Date.now(), chat_id: id, user_id: me.id, kind: 'text', poll: null, author: me.name, author_avatar: me.avatar, body, reply_to: reply?.id ?? null, reply_body: reply?.body ?? null, reply_author: reply?.author ?? null, client_id: cid, created_at: new Date().toISOString(), edited_at: null, deleted: false, file: null, _state: 'pending' };
    stick.current = true;
    setMsgs((cur) => (local ? cur.map((m) => (m.client_id === cid ? tmp : m)) : [...cur, tmp]));
    try {
      const m = await api.post<Msg>(`/api/chats/${id}/messages`, { body, file_id: fileId ?? null, reply_to: tmp.reply_to, client_id: cid });
      setMsgs((cur) => mergeMsgs(cur, [m]));
      invalidate('chats');
    } catch (e) {
      setMsgs((cur) => cur.map((m) => (m.client_id === cid ? { ...m, _state: 'failed' } : m)));
      toast({ title: errMsg(e), kind: 'error' }, 3000);
    }
  }
  async function submit() {
    const body = text.trim();
    if (!body) return;
    if (editing) {
      const e = editing;
      setEditing(null); setText('');
      try { const m = await api.put<Msg>('/api/messages/' + e.id, { body }); setMsgs((cur) => cur.map((x) => (x.id === m.id ? { ...x, ...m } : x))); } catch (er) { toast({ title: errMsg(er), kind: 'error' }); }
      return;
    }
    setText(''); area.current && (area.current.style.height = '42px');
    const r = reply; setReply(null);
    await post(body);
    void r;
  }
  async function sendFiles(list: FileList | null) {
    if (!list) return;
    for (const f of Array.from(list)) {
      try { setUp(0.02); const file = await api.upload<{ id: number }>(`/api/chats/${id}/files`, f, setUp); await post('', file.id); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    }
    setUp(null);
  }
  async function delMsg(m: Msg) {
    if (!(await confirm('Удалить сообщение?', { ok: 'Удалить' }))) return;
    try { await api.del('/api/messages/' + m.id); setMsgs((cur) => cur.map((x) => (x.id === m.id ? { ...x, deleted: true, body: '', file: null } : x))); invalidate('chats'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function clearChat() {
    menu.setOpen(false);
    if (!(await confirm('Очистить историю?', { text: 'Все сообщения исчезнут только у вас. У других участников переписка останется без изменений.', ok: 'Очистить' }))) return;
    try { await api.post(`/api/chats/${id}/clear`); setMsgs([]); setHasMore(false); invalidate('chats'); toast({ title: 'История очищена у вас', kind: 'success' }, 3000); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function deleteChat() {
    menu.setOpen(false);
    if (!(await confirm('Удалить чат?', { text: 'Чат пропадёт из вашего списка, а история будет очищена — только у вас. У других участников чат и переписка останутся. Если в чате появится новое сообщение, он вернётся в список.', ok: 'Удалить у меня' }))) return;
    try { await api.del('/api/chats/' + id); invalidate('chats'); onBack(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  const setPoll = (mid: number) => (p: Poll) => setMsgs((cur) => cur.map((x) => (x.id === mid ? { ...x, poll: p } : x)));
  const onInput = (v: string) => {
    setText(v);
    const now = Date.now();
    if (now - lastTyping.current > 1500 && v) { lastTyping.current = now; realtime.send({ t: 'typing', chat_id: id }); }
  };

  const others = (info.data?.members || []).filter((m) => m.id !== me.id);
  const peer = chat?.kind === 'direct' ? others[0] : null;
  const online = useStore((s) => (peer ? s.online.has(peer.id) : false));
  const peerRead = (m: Msg) => reads.some((r) => r.user_id !== me.id && r.last_read_id >= m.id);
  const typingNames = Object.values(typing);

  const rows = useMemo(() => {
    const out: React.ReactNode[] = [];
    let prev: Msg | null = null;
    for (const m of msgs) {
      const d = new Date(m.created_at);
      if (!prev || !sameDay(new Date(prev.created_at), d)) out.push(<div key={'d' + m.created_at} className="dayTag">{fmtDay(m.created_at)}</div>);
      const mine = m.user_id === me.id;
      const first = !prev || prev.user_id !== m.user_id || !sameDay(new Date(prev.created_at), d);
      out.push(
        <div key={m.client_id || m.id} id={'msg-' + m.id} className={cx('msg', mine && 'mine', m._state, m.deleted && 'deleted', !m.deleted && m.body && isStickerOnly(m.body) && 'stkOnly', m.kind === 'poll' && !m.deleted && 'poll')} style={{ marginTop: first ? 8 : 0 }}>
          {!mine && (first ? <Avatar name={m.author} src={m.author_avatar} size={32} userId={m.user_id} /> : <div style={{ width: 32 }} />)}
          <div className="bub">
            {!mine && first && chat?.kind !== 'direct' && <div className="who">{m.author}</div>}
            {m.reply_to && !m.deleted && <div className="reply"><b>{m.reply_author}</b><div className="clamp2">{m.reply_body ? previewText(stripMd(m.reply_body)) : '📎 Вложение'}</div></div>}
            {m.deleted ? <div className="tx" style={{ fontStyle: 'italic', opacity: .7 }}>Сообщение удалено</div> : (
              <>
                {m.file && (m.file.mime.startsWith('image/') ? (
                  <a href={`/files/${m.file.id}?v=1`} target="_blank" rel="noopener noreferrer"><img className="img" onError={imgFallback} src={`/files/${m.file.id}?t=1`} alt={m.file.name} loading="lazy" style={m.file.width ? { aspectRatio: `${m.file.width}/${m.file.height}`, width: Math.min(320, m.file.width) } : undefined} /></a>
                ) : (
                  <a className="fl" href={`/files/${m.file.id}`} download={m.file.name} onClick={(e) => pdf.onLinkClick(e, m.file)}><FileIcon name={m.file.name} mime={m.file.mime} /><div><div className="bold small">{m.file.name}</div><div className="tiny" style={{ opacity: .75 }}>{fmtSize(m.file.size)}</div></div></a>
                ))}
                {m.kind === 'poll' && m.poll ? <PollCard poll={m.poll} canClose={mine || me.role === 'admin'} onChange={setPoll(m.id)} /> : m.body && <div className="tx"><RichText text={m.body} /></div>}
              </>
            )}
            {!m._state && !m.deleted && <Reactions type="message" id={m.id} initial={m.reactions} noAdd compact />}
            <div className="mt">
              {m.edited_at && !m.deleted && <span>изменено</span>}
              <span>{fmtTime(m.created_at)}</span>
              {mine && !m.deleted && (m._state === 'pending' ? <I.Clock size={12} /> : m._state === 'failed' ? <I.Alert size={12} /> : peerRead(m) ? <I.CheckCheck size={14} /> : <I.Check size={14} />)}
            </div>
          </div>
          {m._state === 'failed' ? <button className="btn sm dng" onClick={() => post(m.body, m.file?.id, m)}><I.Refresh size={14} /> Повторить</button> : !m._state && !m.deleted && (
            <div className="mact">
              <ReactionAddButton type="message" id={m.id} size={14} />
              <BookmarkButton type="message" id={m.id} initial={m.bookmarked} size={14} />
              <button title="Ответить" onClick={() => { setReply(m); setEditing(null); area.current?.focus(); }}><I.Reply size={14} /></button>
              {mine && !m.file && m.kind !== 'poll' && <button title="Изменить" onClick={() => { setEditing(m); setReply(null); setText(m.body); area.current?.focus(); }}><I.Edit size={14} /></button>}
              {mine && <button title="Удалить" onClick={() => delMsg(m)}><I.Trash size={14} /></button>}
            </div>
          )}
        </div>
      );
      prev = m;
    }
    return out;
  }, [msgs, reads, me.id, chat?.kind]);

  return (
    <div className="chatMain">
      <div className="chatHead">
        <button className="btn ghost icon back" onClick={onBack} aria-label="К списку"><I.ArrowLeft /></button>
        {chat?.kind === 'direct' ? <Avatar name={chat.title} src={chat.avatar} size={42} userId={chat.peer_id} /> : <div className="av" style={{ '--s': '42px', '--h': ((chat?.title || '').length * 37) % 360 } as any}><I.Users size={19} /></div>}
        <div className="sp" style={{ minWidth: 0 }}>
          <div className="bold clip">{chat?.kind === 'direct' && chat.peer_id ? <Link to={`/people/${chat.peer_id}`}>{chat.title}</Link> : chat?.title}</div>
          <div className="small muted clip">{chat?.kind === 'direct' ? (online ? <span style={{ color: 'var(--ok)' }}>в сети</span> : chat.peer_title) : `${chat?.members ?? ''} участн.`}</div>
        </div>
        {chat?.kind !== 'direct' && <Btn kind="ghost" icon onClick={() => setMembers(true)} title="Участники"><I.Users size={19} /></Btn>}
        {chat?.group_id && <Link to={`/groups/${chat.group_id}`} className="btn ghost sm">Группа</Link>}
        <div className="chatMenuWrap" ref={menu.ref}>
          <Btn kind="ghost" icon onClick={() => menu.setOpen(!menu.open)} title="Меню чата" aria-haspopup="menu" aria-expanded={menu.open}><I.More size={20} /></Btn>
          {menu.open && (
            <div className="chatMenu" role="menu">
              {chat?.kind !== 'direct' && <button role="menuitem" onClick={() => { menu.setOpen(false); setMembers(true); }}><I.Users size={17} /> Участники</button>}
              {chat?.kind === 'group' && <button role="menuitem" onClick={() => { menu.setOpen(false); setPollOpen(true); }}><I.Chart size={17} /> Создать голосование</button>}
              <hr />
              <button role="menuitem" onClick={clearChat}><I.Refresh size={17} /> Очистить историю</button>
              <button role="menuitem" className="dng" onClick={deleteChat}><I.Trash size={17} /> Удалить чат</button>
            </div>
          )}
        </div>
      </div>
      <div className="msgs" ref={box} onScroll={onScroll}>
        {!loaded ? <Loading /> : loadErr ? <div className="empty"><I.Alert size={32} />{loadErr}<Btn onClick={load}>Повторить</Btn></div> : (
          <>
            {hasMore && <div style={{ textAlign: 'center' }}><Btn size="sm" kind="ghost" onClick={loadOlder}>Загрузить ранее</Btn></div>}
            {msgs.length === 0 && <div className="empty"><I.Message size={40} />Сообщений пока нет — напишите первым</div>}
            {rows}
          </>
        )}
      </div>
      <div className="typing">{typingNames.length > 0 && `${typingNames.join(', ')} ${typingNames.length > 1 ? 'печатают' : 'печатает'}…`}</div>
      <div className="composer">
        {(reply || editing) && (
          <div className="replyBar">
            {editing ? <I.Edit size={15} /> : <I.Reply size={15} />}
            <div className="sp clip"><b>{editing ? 'Редактирование' : reply!.author}</b> · {previewText(stripMd((editing || reply)!.body || '📎 Вложение'))}</div>
            <button className="btn ghost icon sm" onClick={() => { setReply(null); setEditing(null); setText(''); }}><I.X size={15} /></button>
          </div>
        )}
        {up !== null && <div className="prog"><i style={{ width: up * 100 + '%' }} /></div>}
        <div className="line">
          <Btn kind="ghost" icon onClick={() => fileInp.current?.click()} title="Прикрепить файл"><I.Paperclip size={20} /></Btn>
          {chat?.kind === 'group' && <Btn kind="ghost" icon onClick={() => setPollOpen(true)} title="Создать голосование"><I.Chart size={20} /></Btn>}
          <input ref={fileInp} type="file" multiple hidden onChange={(e) => { sendFiles(e.target.files); e.target.value = ''; }} />
          <EmojiButton target={area} value={text} onChange={onInput} align="start" />
          <textarea ref={area} className="txt" rows={1} value={text} placeholder="Написать сообщение…" maxLength={4000}
            onChange={(e) => { onInput(e.target.value); e.target.style.height = '42px'; e.target.style.height = Math.min(e.target.scrollHeight, 160) + 'px'; }}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); submit(); } if (e.key === 'Escape') { setReply(null); setEditing(null); } }}
            onPaste={(e) => { const fs = e.clipboardData.files; if (fs.length) { e.preventDefault(); sendFiles(fs); } }} />
          <TextAssist target={area} value={text} onChange={onInput} scope="chat" id={id} />
          <Btn kind="pri" icon onClick={submit} disabled={!text.trim()} aria-label="Отправить"><I.Send size={19} /></Btn>
        </div>
      </div>
      {pollOpen && <PollModal chatId={id} onClose={() => setPollOpen(false)} onCreated={(m: Msg) => { stick.current = true; setMsgs((cur) => mergeMsgs(cur, [m])); invalidate('chats'); }} />}
      {members && info.data && <MembersModal id={id} chat={chat} members={info.data.members} onClose={() => setMembers(false)} />}
      {node}
      {pdf.node}
    </div>
  );
}

function mergeMsgs(a: Msg[], b: Msg[]): Msg[] {
  const real = new Map<number, Msg>();
  const pend = new Map<string, Msg>();
  const done = new Set<string>();
  for (const m of [...a, ...b]) {
    if (m._state) { pend.set(m.client_id!, m); continue; }
    real.set(m.id, m);
    if (m.client_id) done.add(m.client_id);
  }
  done.forEach((c) => pend.delete(c)); // server copy supersedes the optimistic one
  return [...[...real.values()].sort((x, y) => x.id - y.id), ...pend.values()];
}

function MembersModal({ id, chat, members, onClose }: { id: number; chat: any; members: any[]; onClose: () => void }) {
  const me = useStore((s) => s.me)!;
  const [add, setAdd] = useState<UserLite[]>([]);
  const [busy, setBusy] = useState(false);
  const [confirm, node] = useConfirm();
  const canAdd = chat?.kind !== 'direct' && !chat?.group_id;
  return (
    <Modal title={chat?.title || 'Участники'} onClose={onClose}>
      <div className="stackS">{members.map((m) => <div key={m.id} className="row"><Avatar name={m.name} src={m.avatar} size={36} userId={m.id} /><div className="sp"><Link to={`/people/${m.id}`} onClick={onClose} className="bold small">{m.name}</Link><div className="tiny muted">{m.job_title}</div></div></div>)}</div>
      {chat?.group_id && <div className="small muted">Состав чата совпадает с участниками группы. <Link to={`/groups/${chat.group_id}`} onClick={onClose} className="lnk">Управлять участниками</Link></div>}
      {canAdd && (
        <>
          <div className="divider" style={{ margin: 0 }} />
          <Field label="Добавить участников"><UserPicker value={add} onChange={setAdd} exclude={members.map((m) => m.id)} /></Field>
          {add.length > 0 && <Btn kind="pri" busy={busy} onClick={async () => { setBusy(true); try { await api.post(`/api/chats/${id}/members`, { user_ids: add.map((u) => u.id) }); invalidate('chat:'); invalidate('chats'); onClose(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); setBusy(false); } }}>Добавить</Btn>}
        </>
      )}
      {!chat?.group_id && chat?.kind !== 'direct' && <Btn kind="dng" onClick={async () => { if (await confirm('Покинуть чат?', { ok: 'Покинуть' })) { await api.post(`/api/chats/${id}/leave`); invalidate('chats'); onClose(); navigate('/messages'); } }}>Покинуть чат</Btn>}
      {node}
    </Modal>
  );
}
