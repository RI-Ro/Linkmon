// LMS: общие типы, форматирование и небольшие компоненты (статусы, сроки, прогресс).
import React, { useMemo } from 'react';
import * as I from '../../lib/icons';
import { api } from '../../lib/api';
import { useQuery } from '../../lib/query';
import { useStore } from '../../lib/store';
import { cx } from '../../lib/util';
import { Badge, Img } from '../../ui';
import { DeptSelect, useDepartments } from '../../ui/DeptSelect';
import { L } from './common';
import './lms.css';

export { L };
export const LM = '/learning';

/** Пользователь — администратор или ответственный за обучение (видит статистику и назначает). */
export const isLmsManager = (me?: { role?: string; learning_manager?: boolean } | null) => !!me && (me.role === 'admin' || !!me.learning_manager);

export function useIsManager() {
  const me = useStore((s) => s.me);
  return isLmsManager(me as any);
}

export interface StatsMe { manager: boolean; all?: boolean; roots?: { id: number; name: string }[] }
export function useStatsMe() {
  return useQuery<StatsMe>('learn:stats:me', () => api.get(`${L}/stats/me`), { stale: 60000 });
}

// ---------------------------------------------------------------- форматирование

const DAY = 86400000;
export const dmy = (iso?: string | null) => (iso ? new Date(iso).toLocaleDateString('ru', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '—');
export const dmyTime = (iso?: string | null) => (iso ? new Date(iso).toLocaleString('ru', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—');
/** «1 ч 05 мин» / «12 мин» */
export function hm(sec?: number | null) {
  if (!sec || sec < 60) return sec ? '< 1 мин' : '—';
  const m = Math.round(sec / 60);
  return m < 60 ? `${m} мин` : `${Math.floor(m / 60)} ч ${String(m % 60).padStart(2, '0')} мин`;
}
export const mins = (m?: number | null) => (!m ? '' : m < 60 ? `${m} мин` : `${Math.floor(m / 60)} ч${m % 60 ? ' ' + (m % 60) + ' мин' : ''}`);
export const ratio = (a: number, b: number) => (b > 0 ? Math.round((a / b) * 100) : 0);
export const score1 = (v?: number | null) => (v == null ? '—' : `${String(Math.round(v * 10) / 10).replace('.', ',')}%`);

/** Дней до срока (целое, отрицательное — просрочка); считаем по календарным дням. */
export function daysTo(iso?: string | null): number | null {
  if (!iso) return null;
  const a = new Date(iso), n = new Date();
  const d0 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate()), n0 = Date.UTC(n.getFullYear(), n.getMonth(), n.getDate());
  return Math.round((d0 - n0) / DAY);
}

export function dueText(iso?: string | null): string {
  const d = daysTo(iso);
  if (d == null) return 'без срока';
  if (d < 0) return `просрочено на ${-d} ${-d % 10 === 1 && -d % 100 !== 11 ? 'день' : [2, 3, 4].includes(-d % 10) && ![12, 13, 14].includes(-d % 100) ? 'дня' : 'дней'}`;
  if (d === 0) return 'срок сегодня';
  if (d === 1) return 'срок завтра';
  return `до ${dmy(iso)}`;
}

// ---------------------------------------------------------------- статусы

export const ASSIGNEE_STATUS: Record<number, string> = { 0: 'Назначено', 1: 'В процессе', 2: 'Завершено', 3: 'Отозвано' };

export function StatusBadge({ status, overdue }: { status: number; overdue?: boolean }) {
  if (overdue && status < 2) return <Badge kind="dng"><I.Alert size={11} /> Просрочено</Badge>;
  if (status === 2) return <Badge kind="ok"><I.Check size={11} /> Завершено</Badge>;
  if (status === 1) return <Badge kind="accent"><I.Clock size={11} /> В процессе</Badge>;
  if (status === 3) return <Badge>Отозвано</Badge>;
  return <Badge kind="warn">Назначено</Badge>;
}

export function DueChip({ due, status, high }: { due?: string | null; status?: number; high?: boolean }) {
  const d = daysTo(due);
  const done = (status ?? 0) >= 2;
  const cls = done ? '' : d == null ? '' : d < 0 ? 'bad' : d <= 3 ? 'warn' : '';
  return <span className={cx('lmDue', cls)}><I.Calendar size={13} /> {done && due ? `срок был ${dmy(due)}` : dueText(due)}{high && !done && <b className="lmHigh" title="Высокий приоритет"> !</b>}</span>;
}

export function Bar({ p, ok, thin }: { p: number; ok?: boolean; thin?: boolean }) {
  const v = Math.max(0, Math.min(100, p || 0));
  return <div className={cx('prog', thin && 'thin')} role="progressbar" aria-valuenow={v} aria-valuemin={0} aria-valuemax={100}><i style={{ width: v + '%', background: ok || v === 100 ? 'var(--ok)' : undefined }} /></div>;
}

/** Круговой индикатор прогресса (SVG) */
export function Ring({ p, size = 64, label }: { p: number; size?: number; label?: React.ReactNode }) {
  const r = size / 2 - 5, c = 2 * Math.PI * r, v = Math.max(0, Math.min(100, p || 0));
  return (
    <div className="lmRing" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} aria-hidden="true">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface3)" strokeWidth="6" />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={v === 100 ? 'var(--ok)' : 'var(--accent)'} strokeWidth="6" strokeLinecap="round" strokeDasharray={`${(v / 100) * c} ${c}`} transform={`rotate(-90 ${size / 2} ${size / 2})`} />
      </svg>
      <span>{label ?? v + '%'}</span>
    </div>
  );
}

export function Cover({ src, title, className }: { src?: string | null; title: string; className?: string }) {
  return src ? <Img src={src} alt="" className={cx('lmCoverImg', className)} /> : <div className={cx('lmCoverImg ph', className)} aria-hidden="true"><I.GradCap size={34} /><span>{title.slice(0, 1)}</span></div>;
}

export const STEP_KIND: Record<string, { label: string; icon: any }> = {
  item: { label: 'Материал', icon: I.Book },
  wiki: { label: 'База знаний', icon: I.FileText },
  video: { label: 'Видео', icon: I.Video },
  link: { label: 'Ссылка', icon: I.Link },
  test: { label: 'Тест', icon: I.GradCap },
  ack: { label: 'Ознакомление', icon: I.Check },
};

export const ORDER_LABEL = { free: 'Любой порядок', sequential: 'По порядку' } as const;

// ---------------------------------------------------------------- выбор подразделений

export function DeptTokens({ value, onChange, placeholder }: { value: number[]; onChange: (v: number[]) => void; placeholder?: string }) {
  const { data } = useDepartments();
  const byId = useMemo(() => new Map((data || []).map((d) => [d.id, d])), [data]);
  return (
    <div className="stackS">
      {value.length > 0 && (
        <div className="tokens">
          {value.map((id) => (
            <span className="token" key={id}>{byId.get(id)?.name || '#' + id}
              <button type="button" onClick={() => onChange(value.filter((x) => x !== id))} aria-label="Убрать"><I.X size={14} /></button>
            </span>
          ))}
        </div>
      )}
      <DeptSelect value={null} allowEmpty emptyLabel={placeholder || 'Добавить подразделение…'} onChange={(id) => { if (id != null && !value.includes(id)) onChange([...value, id]); }} />
    </div>
  );
}

export function useCertTemplates() {
  return useQuery<any[]>('learn:cert-tpl', () => api.get(`${L}/cert-templates`), { stale: 30000 });
}

export function csvHref(path: string, params: Record<string, string | number | undefined | null>) {
  const u = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => { if (v != null && v !== '' && v !== 0) u.set(k, String(v)); });
  const s = u.toString();
  return `${L}/${path}${s ? '?' + s : ''}`;
}
