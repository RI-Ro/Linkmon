import React, { useEffect, useMemo, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { invalidate, useQuery } from '../../lib/query';
import { Link, navigate, useSearchParams, useTitle } from '../../lib/router';
import { toast, useStore } from '../../lib/store';
import { usePersist } from '../../lib/persist';
import { cx, plural, useDebounced } from '../../lib/util';
import { Badge, Btn, Empty, ErrorBox, Pager, Select, Skel, useConfirm } from '../../ui';
import { Crumbs, FolderShell, KIND, L, ListSkeleton, MoveItemsModal, dt, dtShort, fmtDur, num, pct, refreshLearning, useTree } from './common';
import { ImportModal } from './editor';
import { isLmsManager } from './lms-common';

interface TestRow {
  id: number; folder_id: number; folder_name: string; title: string; description: string; status: 'draft' | 'published'; pass_percent: number;
  time_limit_min: number | null; max_attempts: number | null; available_from: string | null; available_to: string | null; questions_count: number;
  attempts_count: number; passed_count: number; avg_percent: number; my: { n: number; best: number | null; passed: boolean | null; open_id: number | null };
}

export function MyBadge({ my, max }: { my: TestRow['my']; max?: number | null }) {
  if (my.open_id) return <Badge kind="accent"><I.Clock size={11} /> В процессе</Badge>;
  if (!my.n) return <Badge>Не пройден</Badge>;
  return my.passed ? <Badge kind="ok"><I.Check size={11} /> Сдан · {pct(my.best)}</Badge> : <Badge kind="dng">Не сдан · {pct(my.best)}</Badge>;
}

// ---------------------------------------------------------------- страница «Тесты»

export function TestsPage() {
  const me = useStore((s) => s.me)!;
  const [sp, setSp] = useSearchParams();
  const folder = +(sp.get('folder') || 0), page = +(sp.get('page') || 1), q = sp.get('q') || '';
  const [order, setOrder] = usePersist<'manual' | 'new' | 'title'>('learn:t:order', 'manual');
  const { tree, loading: treeLoading } = useTree('tests');
  const cur = folder ? tree.byId.get(folder) : undefined;
  useTitle(cur ? cur.name : 'Тесты');
  const canManage = (cur?.level ?? 0) >= 3;
  const [qIn, setQIn] = useState(q);
  const dq = useDebounced(qIn, 250);
  useEffect(() => { if (dq.trim() !== q) setSp({ q: dq.trim() || null, page: null }); }, [dq]);
  useEffect(() => { if (q !== qIn.trim()) setQIn(q); }, [q]);
  const searching = q.length > 0;
  const key = searching ? `learn:t:search:${q}:${page}` : folder ? `learn:t:list:${folder}:${page}:${order}` : null;
  const url = searching ? `${L}/tests?q=${encodeURIComponent(q)}&page=${page}` : `${L}/tests?folder=${folder}&page=${page}&order=${order}`;
  const { data, error, refetch } = useQuery<{ items: TestRow[]; total?: number; has_more: boolean; per: number }>(key, () => api.get(url), { stale: 15000, keepPrevious: true });
  const [sel, setSel] = useState<Set<number>>(new Set());
  const [moving, setMoving] = useState<number[] | null>(null);
  const [imp, setImp] = useState(false);
  useEffect(() => setSel(new Set()), [folder, q, page]);
  const canRoot = me.role !== 'user';
  const anyManage = tree.list.some((f) => f.level >= 3);
  const pages = data?.total != null ? Math.ceil(data.total / (data.per || 30)) : data?.has_more ? page + 1 : page;
  const items = data?.items || [];

  return (
    <FolderShell kind="tests" tree={tree} loading={treeLoading} folder={folder}>
      <div className="lnBar">
        <div className="lnSearch"><I.Search size={17} /><input value={qIn} placeholder="Поиск тестов по названию…" onChange={(e) => setQIn(e.target.value)} aria-label="Поиск" />{qIn && <button onClick={() => { setQIn(''); setSp({ q: null, page: null }); }} aria-label="Сбросить"><I.X size={15} /></button>}</div>
        {!searching && folder > 0 && (
          <Select className="lnOrder" value={order} onChange={(e) => { setOrder(e.target.value as any); setSp({ page: null }); }} aria-label="Сортировка">
            <option value="manual">По порядку</option><option value="new">Сначала новые</option><option value="title">По названию</option>
          </Select>
        )}
        <Link to="/learning/tests/my" className="btn"><I.Activity size={16} /> Мои результаты</Link>
        {anyManage && !searching && (
          <a className="btn" href={`${L}/results/export.csv${folder ? '?folder=' + folder : ''}`} title="Результаты всех тестов выбранной папки и вложенных (CSV для Excel)"><I.Download size={16} /> Результаты CSV</a>
        )}
        {canManage && !searching && (
          <>
            <Btn onClick={() => setImp(true)}><I.Upload size={16} /> Импорт</Btn>
            <Btn kind="pri" onClick={() => navigate(`/learning/tests/new?folder=${folder}`)}><I.Plus size={16} /> Тест</Btn>
          </>
        )}
      </div>
      {sel.size > 0 && (
        <div className="lnSelBar card"><b>Выбрано: {sel.size}</b><div className="sp" /><Btn size="sm" onClick={() => setMoving([...sel])}><I.Folder size={15} /> Переместить</Btn><Btn size="sm" kind="ghost" onClick={() => setSel(new Set())}>Снять выбор</Btn></div>
      )}
      {!folder && !searching ? (
        <TestsHome tree={tree} />
      ) : error && !data ? <ErrorBox error={error} retry={refetch} /> : !data ? <ListSkeleton /> : items.length === 0 ? (
        <div className="card"><Empty icon={I.GradCap} title={searching ? 'Ничего не найдено' : 'В этой папке пока нет тестов'}>{searching ? 'Попробуйте изменить запрос' : canManage ? 'Создайте тест или импортируйте задания из файла' : 'Тесты появятся здесь, когда их опубликуют'}</Empty></div>
      ) : (
        <div className="lnTests">
          {items.map((t) => (
            <div key={t.id} className={cx('card lnTest', sel.has(t.id) && 'sel')}>
              {canManage && !searching && <input type="checkbox" className="lnChk" checked={sel.has(t.id)} onChange={() => setSel((s) => { const n = new Set(s); n.has(t.id) ? n.delete(t.id) : n.add(t.id); return n; })} aria-label="Выбрать" />}
              <Link to={`/learning/tests/${t.id}`} className="lnTestMain">
                <span className="fico pdf"><I.GradCap size={20} /></span>
                <span className="sp" style={{ minWidth: 0 }}>
                  <span className="bold" style={{ display: 'block' }}>{t.title}{t.status === 'draft' && <> <Badge kind="warn">Черновик</Badge></>}</span>
                  {t.description && <span className="small muted clamp2" style={{ display: 'block' }}>{t.description}</span>}
                  <span className="lnMeta">
                    <span>{plural(t.questions_count, ['вопрос', 'вопроса', 'вопросов'])}</span>
                    <span>проходной {t.pass_percent}%</span>
                    {t.time_limit_min && <span><I.Clock size={12} /> {t.time_limit_min} мин</span>}
                    {t.max_attempts && <span>попыток: {t.my.n}/{t.max_attempts}</span>}
                    {t.available_to && <span>до {dtShort(t.available_to)}</span>}
                    {searching && <span><I.Folder size={12} /> {t.folder_name}</span>}
                    {(tree.byId.get(t.folder_id)?.level ?? 0) >= 3 && t.attempts_count > 0 && <span className="lnStat">{t.attempts_count} попыток · сдали {Math.round((t.passed_count / t.attempts_count) * 100)}% · средний {pct(t.avg_percent)}</span>}
                  </span>
                </span>
              </Link>
              <div className="lnTestSide"><MyBadge my={t.my} /></div>
            </div>
          ))}
        </div>
      )}
      {data && pages > 1 && <Pager page={page} total={0} per={0} pages={pages} onChange={(p) => setSp({ page: p > 1 ? p : null }, false)} />}
      {moving && <MoveItemsModal kind="tests" tree={tree} ids={moving} onClose={() => setMoving(null)} onDone={() => { setMoving(null); setSel(new Set()); }} />}
      {imp && <ImportModal mode="create" folder={folder} onClose={() => setImp(false)} onDone={(id) => { setImp(false); refreshLearning(); navigate(`/learning/tests/${id}/edit`); }} />}
    </FolderShell>
  );
}

function TestsHome({ tree }: { tree: ReturnType<typeof useTree>['tree'] }) {
  const { data } = useQuery<any>('learn:t:mine', () => api.get(`${L}/my/attempts?per=5`), { stale: 10000 });
  const s = data?.summary;
  return (
    <div className="stack">
      {s && s.attempts > 0 && (
        <div className="kpis">
          <div className="card kpi"><div className="n">{s.tests_passed}<span className="muted" style={{ fontSize: 16 }}> / {s.tests}</span></div><div className="l">тестов сдано</div></div>
          <div className="card kpi"><div className="n">{s.attempts}</div><div className="l">попыток</div></div>
          <div className="card kpi"><div className="n">{pct(s.avg_percent)}</div><div className="l">средний результат</div></div>
        </div>
      )}
      {data?.items?.length > 0 && (
        <div className="stackS">
          <div className="row"><h3 className="lnH3 sp">Последние попытки</h3><Link to="/learning/tests/my" className="small" style={{ color: 'var(--accent)' }}>Все результаты</Link></div>
          <AttemptTable rows={data.items} />
        </div>
      )}
      {!tree.list.length ? <div className="card"><Empty icon={I.GradCap} title="Тестов пока нет">Папки с тестами появятся здесь</Empty></div> : <div className="small muted">Выберите папку слева или воспользуйтесь поиском.</div>}
    </div>
  );
}

// ---------------------------------------------------------------- таблица моих попыток

export function AttemptTable({ rows }: { rows: any[] }) {
  return (
    <div className="card tblW">
      <table className="tbl">
        <thead><tr><th>Тест</th><th>Дата</th><th>Баллы</th><th>Результат</th><th>Время</th></tr></thead>
        <tbody>
          {rows.map((a) => (
            <tr key={a.id}>
              <td><Link className="bold" to={a.finished_at ? `/learning/tests/attempt/${a.id}` : `/learning/tests/${a.test_id}/run`}>{a.title}</Link><div className="tiny muted">попытка {a.no}</div></td>
              <td>{dt(a.started_at)}</td>
              <td>{a.finished_at ? <>{num(a.score)} / {num(a.max_score)} <span className="muted">({pct(a.percent)})</span></> : '—'}</td>
              <td>{!a.finished_at ? <Badge kind="accent">В процессе</Badge> : a.passed ? <Badge kind="ok">Сдан</Badge> : <Badge kind="dng">Не сдан</Badge>}{a.expired && <span className="tiny muted"> · время вышло</span>}</td>
              <td>{fmtDur(a.duration_sec)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function MyResultsPage() {
  const [sp, setSp] = useSearchParams();
  const page = +(sp.get('page') || 1);
  const [flt, setFlt] = usePersist<string>('learn:t:myflt', '');
  const { data, error, refetch } = useQuery<any>(`learn:t:my:${page}:${flt}`, () => api.get(`${L}/my/attempts?page=${page}&per=20${flt ? '&result=' + flt : ''}`), { stale: 5000, keepPrevious: true });
  useTitle('Мои результаты');
  const s = data?.summary;
  return (
    <div className="stack">
      <div className="lnHead"><div className="sp"><div className="crumbs"><Link to="/learning/tests">Тесты</Link><I.ChevronRight size={14} /><b style={{ color: 'var(--text)' }}>Мои результаты</b></div><h2 className="lnTitle">История прохождения</h2></div></div>
      {s && (
        <div className="kpis">
          <div className="card kpi"><div className="n">{s.attempts}</div><div className="l">завершённых попыток</div></div>
          <div className="card kpi"><div className="n">{s.tests}</div><div className="l">тестов пройдено</div></div>
          <div className="card kpi"><div className="n">{s.tests_passed}</div><div className="l">тестов сдано</div></div>
          <div className="card kpi"><div className="n">{pct(s.avg_percent)}</div><div className="l">средний результат</div></div>
        </div>
      )}
      <div className="chips">
        {[['', 'Все'], ['passed', 'Сдано'], ['failed', 'Не сдано'], ['open', 'В процессе']].map(([v, l]) => <button key={v} className={cx('chip', flt === v && 'on')} onClick={() => { setFlt(v); setSp({ page: null }); }}>{l}</button>)}
      </div>
      {error && !data ? <ErrorBox error={error} retry={refetch} /> : !data ? <ListSkeleton /> : !data.items.length ? <div className="card"><Empty icon={I.Activity} title="Попыток пока нет">Пройдите тест — результат появится здесь</Empty></div> : <AttemptTable rows={data.items} />}
      {data && (data.has_more || page > 1) && <Pager page={page} total={0} per={0} pages={data.has_more ? page + 1 : page} onChange={(p) => setSp({ page: p > 1 ? p : null }, false)} />}
    </div>
  );
}

// ---------------------------------------------------------------- карточка теста

export function TestPage({ id }: { id: number }) {
  const me = useStore((s) => s.me)!;
  const { tree } = useTree('tests');
  const { data, error, refetch } = useQuery<any>(`learn:t:test:${id}`, () => api.get(`${L}/tests/${id}`), { stale: 3000 });
  const [confirm, node] = useConfirm();
  useTitle(data?.test?.title || 'Тест');
  const [busy, setBusy] = useState(false);
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data) return <div className="card pad stack"><Skel h={30} w="50%" /><Skel h={16} /><Skel h={16} w="70%" /><Skel h={44} w={200} /></div>;
  const { test: t, my, level } = data;
  const manage = level >= 3;

  async function act(fn: () => Promise<any>, ok?: string) {
    setBusy(true);
    try { await fn(); if (ok) toast({ title: ok, kind: 'success' }); refreshLearning(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  async function remove() {
    if (!(await confirm('Удалить тест?', { text: `Будут удалены вопросы и все результаты прохождения${t.attempts_count ? ` (${plural(t.attempts_count, ['попытка', 'попытки', 'попыток'])})` : ''}. Действие необратимо.`, ok: 'Удалить' }))) return;
    await act(async () => { await api.del(`${L}/tests/${id}`); navigate(`/learning/tests?folder=${t.folder_id}`); }, 'Тест удалён');
  }

  return (
    <div className="stack lnItemPage">
      <div className="lnHead">
        <div className="sp" style={{ minWidth: 0 }}><Crumbs kind="tests" tree={tree} folder={t.folder_id} tail={t.title} /></div>
        <Btn onClick={() => navigate(`/learning/tests?folder=${t.folder_id}`)}><I.ArrowLeft size={16} /> К папке</Btn>
      </div>
      <div className="card lnArticle">
        <header className="stackS">
          <h1 className="lnItemTitle">{t.title} {t.status === 'draft' && <Badge kind="warn">Черновик</Badge>}</h1>
          {t.description && <p className="muted" style={{ whiteSpace: 'pre-wrap' }}>{t.description}</p>}
        </header>
        <div className="lnFacts">
          <Row l="Вопросов" v={t.questions_count} />
          <Row l="Проходной балл" v={`${t.pass_percent}%`} />
          <Row l="Время" v={t.time_limit_min ? `${t.time_limit_min} мин` : 'без ограничения'} />
          <Row l="Попытки" v={t.max_attempts ? `${my.used} из ${t.max_attempts}` : 'без ограничения'} />
          <Row l="Правильные ответы" v={{ never: 'не показываются', after_attempt: 'после попытки', after_finish: 'после всех попыток' }[t.show_answers as string]} />
          {(t.available_from || t.available_to) && <Row l="Доступен" v={`${t.available_from ? 'с ' + dt(t.available_from) : ''} ${t.available_to ? 'по ' + dt(t.available_to) : ''}`} />}
        </div>
        {t.status === 'draft' && <div className="notice"><I.Info size={16} /> Тест не опубликован: его видят только редакторы. Вы можете пройти его для проверки.</div>}
        <div className="lnStart">
          {my.open_id ? (
            <Link to={`/learning/tests/${id}/run`} className="btn pri lg"><I.Play size={18} /> Продолжить попытку</Link>
          ) : my.can_start ? (
            <Link to={`/learning/tests/${id}/run`} className="btn pri lg"><I.Play size={18} /> {my.used ? 'Пройти ещё раз' : 'Начать тест'}</Link>
          ) : (
            <div className="notice warn"><I.Alert size={16} /> {my.reason}</div>
          )}
          {my.best != null && <span className="muted">Лучший результат: <b style={{ color: my.passed ? 'var(--ok)' : 'var(--danger)' }}>{pct(my.best)}</b>{my.passed ? ' · тест сдан' : ''}</span>}
        </div>
        {manage && (
          <div className="lnManage">
            <div className="lbl">Управление тестом</div>
            <div className="rowW">
              <Link to={`/learning/tests/${id}/edit`} className="btn"><I.Edit size={16} /> Редактировать</Link>
              <Link to={`/learning/tests/${id}/results`} className="btn"><I.Chart size={16} /> Результаты и статистика{t.attempts_count > 0 && ` · ${t.attempts_count}`}</Link>
              {isLmsManager(me as any) && t.status === 'published' && <Link to={`/learning/assignments/new?type=test&target=${id}`} className="btn"><I.UserPlus size={16} /> Назначить</Link>}
              <a className="btn" href={`${L}/tests/${id}/export.csv`}><I.Download size={16} /> Результаты CSV</a>
              <a className="btn" href={`${L}/tests/${id}/export.json`}><I.Download size={16} /> Задания JSON</a>
              <Btn busy={busy} onClick={() => act(() => api.post(`${L}/tests/${id}/status`, { status: t.status === 'published' ? 'draft' : 'published' }).then(() => refetch()), t.status === 'published' ? 'Тест снят с публикации' : 'Тест опубликован')}>{t.status === 'published' ? 'Снять с публикации' : 'Опубликовать'}</Btn>
              <Btn busy={busy} onClick={() => act(async () => { const r = await api.post(`${L}/tests/${id}/copy`); navigate(`/learning/tests/${r.id}/edit`); }, 'Копия создана')}><I.Copy size={16} /> Копировать</Btn>
              <Btn kind="dng" icon onClick={remove} aria-label="Удалить тест"><I.Trash size={16} /></Btn>
            </div>
          </div>
        )}
      </div>
      <div className="stackS">
        <h3 className="lnH3">Мои попытки</h3>
        {!my.attempts.length ? <div className="card"><Empty icon={I.Activity} title="Попыток пока нет">Нажмите «Начать тест» — результат сохранится в вашей истории</Empty></div> : (
          <div className="card tblW">
            <table className="tbl">
              <thead><tr><th>№</th><th>Дата</th><th>Баллы</th><th>Результат</th><th>Время</th><th /></tr></thead>
              <tbody>
                {my.attempts.map((a: any) => (
                  <tr key={a.id}>
                    <td>{a.no}</td><td>{dt(a.started_at)}</td>
                    <td>{a.finished_at ? <>{num(a.score)} / {num(a.max_score)} <span className="muted">({pct(a.percent)})</span></> : '—'}</td>
                    <td>{!a.finished_at ? <Badge kind="accent">В процессе</Badge> : a.passed ? <Badge kind="ok">Сдан</Badge> : <Badge kind="dng">Не сдан</Badge>}{a.expired && <span className="tiny muted"> · время вышло</span>}</td>
                    <td>{fmtDur(a.duration_sec)}</td>
                    <td className="act">{a.finished_at ? <Link to={`/learning/tests/attempt/${a.id}`} className="btn sm">Подробнее</Link> : <Link to={`/learning/tests/${id}/run`} className="btn sm pri">Продолжить</Link>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      {node}
    </div>
  );
}

function Row({ l, v }: { l: string; v: React.ReactNode }) {
  return <div className="lnFact"><span className="muted small">{l}</span><b>{v}</b></div>;
}
