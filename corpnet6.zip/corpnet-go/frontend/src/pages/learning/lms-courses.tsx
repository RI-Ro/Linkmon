// LMS: каталог курсов (папки, фильтры по моему статусу, поиск, теги).
import React, { useEffect, useState } from 'react';
import * as I from '../../lib/icons';
import { api } from '../../lib/api';
import { useQuery } from '../../lib/query';
import { Link, navigate, useSearchParams, useTitle } from '../../lib/router';
import { useStore } from '../../lib/store';
import { cx, plural, useDebounced } from '../../lib/util';
import { Badge, Empty, ErrorBox, Pager, Skel } from '../../ui';
import { FolderShell, L, useTree } from './common';
import { Bar, Cover, DueChip, dmy, mins } from './lms-common';

export interface CourseRow {
  id: number; folder_id: number; folder_name: string; title: string; description: string; cover: string; tags: string[]; status: 'draft' | 'published';
  est_minutes: number; order_mode: string; steps_count: number; required_count: number; validity_months: number; version: number;
  e_status: number | null; percent: number | null; completed_at: string | null; expires_at: string | null; last_at: string | null; due_at: string | null; assigned: boolean; overdue: boolean;
}

const FILTERS: { id: string; label: string; count?: string }[] = [
  { id: '', label: 'Все', count: 'all' },
  { id: 'assigned', label: 'Назначенные', count: 'assigned' },
  { id: 'progress', label: 'В процессе', count: 'progress' },
  { id: 'overdue', label: 'Просроченные', count: 'overdue' },
  { id: 'done', label: 'Завершённые', count: 'done' },
];

export function CourseCard({ c }: { c: CourseRow }) {
  const done = c.e_status === 2;
  const expired = done && !!c.expires_at && new Date(c.expires_at) < new Date();
  return (
    <Link to={`/learning/courses/${c.id}`} className="card lmCard">
      <div className="lmCardCover">
        <Cover src={c.cover} title={c.title} />
        {c.status === 'draft' && <span className="lmCardTag"><Badge kind="warn">Черновик</Badge></span>}
        {c.assigned && !done && <span className="lmCardTag r"><Badge kind={c.overdue ? 'dng' : 'accent'}>{c.overdue ? 'Просрочен' : 'Назначен'}</Badge></span>}
      </div>
      <div className="lmCardBd">
        <div className="bold clamp2">{c.title}</div>
        {c.description && <div className="small muted clamp2">{c.description}</div>}
        <div className="lmMeta">
          <span><I.Layers size={12} /> {plural(c.steps_count, ['шаг', 'шага', 'шагов'])}</span>
          {c.est_minutes > 0 && <span><I.Clock size={12} /> {mins(c.est_minutes)}</span>}
          {c.validity_months > 0 && <span><I.Refresh size={12} /> {c.validity_months} мес.</span>}
        </div>
        {c.tags.length > 0 && <div className="lmMeta">{c.tags.slice(0, 3).map((t) => <span key={t} className="lnTag">#{t}</span>)}</div>}
      </div>
      <div className="lmCardFt">
        {done ? (
          <div className="row small"><Badge kind={expired ? 'warn' : 'ok'}><I.Check size={11} /> {expired ? 'Срок истёк' : 'Пройден'}</Badge><span className="muted">{expired ? dmy(c.expires_at) : dmy(c.completed_at)}</span></div>
        ) : c.e_status === 1 ? (
          <div className="stackS"><div className="row small"><span className="sp muted">Прогресс</span><b>{c.percent ?? 0}%</b></div><Bar p={c.percent ?? 0} thin /></div>
        ) : c.due_at ? <DueChip due={c.due_at} /> : <span className="small muted">Не начат</span>}
      </div>
    </Link>
  );
}

export function CoursesPage() {
  const me = useStore((s) => s.me)!;
  const [sp, setSp] = useSearchParams();
  const folder = +(sp.get('folder') || 0), page = +(sp.get('page') || 1), q = sp.get('q') || '', filter = sp.get('filter') || '', tag = sp.get('tag') || '';
  const { tree, loading: treeLoading } = useTree('courses');
  const cur = folder ? tree.byId.get(folder) : undefined;
  useTitle(cur ? cur.name : 'Курсы');
  const [qIn, setQIn] = useState(q);
  const dq = useDebounced(qIn, 250);
  useEffect(() => { if (dq.trim() !== q) setSp({ q: dq.trim() || null, page: null }); }, [dq]);
  useEffect(() => { if (q !== qIn.trim()) setQIn(q); }, [q]);
  const canAny = tree.list.some((f) => f.level >= 3) || me.role !== 'user';
  const canManage = (cur?.level ?? 0) >= 3;
  const params = new URLSearchParams();
  if (folder) params.set('folder', String(folder));
  if (q) params.set('q', q);
  if (tag) params.set('tag', tag);
  const fl = filter === 'drafts' && !canAny ? '' : filter;
  if (fl) params.set('filter', fl);
  params.set('page', String(page));
  const { data, error, refetch } = useQuery<{ items: CourseRow[]; has_more: boolean; per: number; counts?: Record<string, number>; tags?: { tag: string; n: number }[] }>(
    `learn:c:list:${params}`, () => api.get(`${L}/courses?${params}`), { stale: 10000, keepPrevious: true });
  const counts = data?.counts;
  const [tags, setTags] = useState<{ tag: string; n: number }[]>([]);
  const [cnt, setCnt] = useState<Record<string, number>>({});
  useEffect(() => { if (data?.tags) setTags(data.tags); if (data?.counts) setCnt(data.counts); }, [data]);
  void counts;
  const items = data?.items || [];
  const pages = data?.has_more ? page + 1 : page;

  return (
    <FolderShell kind="courses" tree={tree} loading={treeLoading} folder={folder}>
      <div className="lnBar">
        <div className="lnSearch"><I.Search size={17} /><input value={qIn} placeholder="Поиск курсов…" onChange={(e) => setQIn(e.target.value)} aria-label="Поиск курсов" />{qIn && <button onClick={() => { setQIn(''); setSp({ q: null, page: null }); }} aria-label="Очистить"><I.X size={15} /></button>}</div>
        {canManage && <Link className="btn pri" to={`/learning/courses/new?folder=${folder}`}><I.Plus size={16} /> Курс</Link>}
        {!folder && canAny && <Link className="btn pri" to="/learning/courses/new"><I.Plus size={16} /> Курс</Link>}
      </div>
      <div className="chips">
        {FILTERS.map((f) => (
          <button key={f.id} className={cx('chip', fl === f.id && 'on')} onClick={() => setSp({ filter: f.id || null, page: null })}>
            {f.label}{f.count && cnt[f.count] != null && <span className="lmChipN">{cnt[f.count]}</span>}
          </button>
        ))}
        {canAny && <button className={cx('chip', fl === 'drafts' && 'on')} onClick={() => setSp({ filter: 'drafts', page: null })}>Черновики</button>}
      </div>
      {tags.length > 0 && (
        <div className="chips lmTags">
          {tag && <button className="chip on" onClick={() => setSp({ tag: null, page: null })}><I.Tag size={12} /> {tag} <I.X size={12} /></button>}
          {!tag && tags.slice(0, 12).map((t) => <button key={t.tag} className="lnTag lmTagBtn" onClick={() => setSp({ tag: t.tag, page: null })}>#{t.tag} <small>{t.n}</small></button>)}
        </div>
      )}
      {error && !data ? <ErrorBox error={error} retry={refetch} /> : !data ? (
        <div className="lmGrid">{[0, 1, 2, 3, 4, 5].map((i) => <div key={i} className="card"><Skel h={140} r={0} /><div className="padS stackS"><Skel h={18} /><Skel h={14} w="70%" /></div></div>)}</div>
      ) : items.length === 0 ? (
        <div className="card"><Empty icon={I.GradCap} title={q || tag || fl ? 'Курсы не найдены' : 'Курсов пока нет'}>{q || tag || fl ? 'Измените поиск или фильтры' : canAny ? 'Создайте первый курс в одной из папок' : 'Здесь появятся курсы вашей компании'}
          {(q || tag || fl) && <div style={{ marginTop: 12 }}><button className="btn" onClick={() => navigate('/learning/courses' + (folder ? '?folder=' + folder : ''))}>Сбросить фильтры</button></div>}</Empty></div>
      ) : (
        <div className="lmGrid">{items.map((c) => <CourseCard key={c.id} c={c} />)}</div>
      )}
      {data && pages > 1 && <Pager page={page} total={0} per={0} pages={pages} onChange={(p) => setSp({ page: p > 1 ? p : null }, false)} />}
    </FolderShell>
  );
}
