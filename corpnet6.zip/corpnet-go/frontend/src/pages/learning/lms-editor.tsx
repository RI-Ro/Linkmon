// LMS: конструктор курса — свойства, разделы, шаги (материал / тест / видео / ссылка / база знаний / ознакомление), порядок, условия завершения.
import React, { useEffect, useMemo, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { invalidate, useQuery } from '../../lib/query';
import { Link, navigate, useSearchParams, useTitle } from '../../lib/router';
import { toast } from '../../lib/store';
import { cx, plural, useDebounced } from '../../lib/util';
import { Badge, Btn, Check, Empty, ErrorBox, Field, ImageUpload, Input, Modal, Select, Skel, Textarea, usePopover } from '../../ui';
import { FolderPicker, L, refreshLearning, useTree } from './common';
import { STEP_KIND, useCertTemplates } from './lms-common';
import { CourseData, refreshCourse } from './lms-course';

interface EStep {
  key: string; id?: number; kind: 'item' | 'wiki' | 'video' | 'link' | 'test' | 'ack'; ref_id: number | null; ref_title: string; title: string; body: string; url: string;
  required: boolean; pass_percent: string; est_minutes: string; open?: boolean;
}
interface EGroup { key: string; title: string | null; steps: EStep[] }

let seq = 0;
const nk = () => 'k' + ++seq;

function fromData(d: CourseData): EGroup[] {
  const mk = (s: any): EStep => ({ key: nk(), id: s.id, kind: s.kind, ref_id: s.ref_id, ref_title: s.ref_title || '', title: s.title, body: s.body || '', url: s.url || '', required: s.required, pass_percent: s.pass_percent == null ? '' : String(s.pass_percent), est_minutes: s.est_minutes ? String(s.est_minutes) : '' });
  const groups: EGroup[] = [{ key: nk(), title: null, steps: d.steps.filter((s) => s.section_id == null).map(mk) }];
  for (const sec of d.sections) groups.push({ key: nk(), title: sec.title, steps: d.steps.filter((s) => s.section_id === sec.id).map(mk) });
  return groups;
}

export function CourseEditor({ id }: { id?: number }) {
  const [sp] = useSearchParams();
  const { tree } = useTree('courses');
  const q = useQuery<CourseData>(id ? `learn:c:edit:${id}` : null, () => api.get(`${L}/courses/${id}`), { stale: 0 });
  const tpls = useCertTemplates();
  const [f, setF] = useState<any>(null);
  const [groups, setGroups] = useState<EGroup[]>([{ key: nk(), title: null, steps: [] }]);
  const [prereqs, setPrereqs] = useState<{ id: number; title: string }[]>([]);
  const [busy, setBusy] = useState('');
  const [err, setErr] = useState('');
  const [picker, setPicker] = useState<null | { kind: 'item' | 'test'; group: number }>(null);
  useTitle(id ? 'Редактирование курса' : 'Новый курс');

  useEffect(() => {
    if (id) {
      const d = q.data;
      if (!d || f) return;
      const c = d.course;
      setF({ folder_id: c.folder_id, title: c.title, description: c.description, cover: c.cover, tags: (c.tags || []).join(', '), status: c.status, order_mode: c.order_mode, pass_percent: String(c.pass_percent),
        validity_months: String(c.validity_months || 0), max_attempts: c.max_attempts == null ? '' : String(c.max_attempts), cert_template_id: c.cert_template_id == null ? '' : String(c.cert_template_id), est_minutes: c.est_minutes ? String(c.est_minutes) : '' });
      setGroups(fromData(d));
      setPrereqs((d.prereqs || []).map((x) => ({ id: x.id, title: x.title })));
    } else if (!f) {
      setF({ folder_id: +(sp.get('folder') || 0) || null, title: '', description: '', cover: '', tags: '', status: 'draft', order_mode: 'free', pass_percent: '70', validity_months: '0', max_attempts: '', cert_template_id: '', est_minutes: '' });
    }
  }, [q.data, id]);

  const set = (k: string, v: any) => setF((x: any) => ({ ...x, [k]: v }));
  const total = groups.reduce((a, g) => a + g.steps.length, 0);
  const reqN = groups.reduce((a, g) => a + g.steps.filter((s) => s.required).length, 0);
  const autoMin = groups.reduce((a, g) => a + g.steps.reduce((b, s) => b + (+s.est_minutes || 0), 0), 0);

  const upd = (gi: number, si: number, patch: Partial<EStep>) => setGroups((gs) => gs.map((g, i) => (i !== gi ? g : { ...g, steps: g.steps.map((s, j) => (j === si ? { ...s, ...patch } : s)) })));
  const addStep = (gi: number, s: Partial<EStep>) => setGroups((gs) => gs.map((g, i) => (i !== gi ? g : { ...g, steps: [...g.steps, { key: nk(), kind: 'link', ref_id: null, ref_title: '', title: '', body: '', url: '', required: true, pass_percent: '', est_minutes: '', open: true, ...s } as EStep] })));
  const move = (gi: number, si: number, dir: -1 | 1) => setGroups((gs) => gs.map((g, i) => {
    if (i !== gi) return g;
    const a = [...g.steps], j = si + dir;
    if (j < 0 || j >= a.length) return g;
    [a[si], a[j]] = [a[j], a[si]];
    return { ...g, steps: a };
  }));
  const remove = (gi: number, si: number) => setGroups((gs) => gs.map((g, i) => (i !== gi ? g : { ...g, steps: g.steps.filter((_, j) => j !== si) })));
  const toGroup = (gi: number, si: number, to: number) => setGroups((gs) => {
    const s = gs[gi].steps[si];
    return gs.map((g, i) => (i === gi ? { ...g, steps: g.steps.filter((_, j) => j !== si) } : i === to ? { ...g, steps: [...g.steps, s] } : g));
  });
  const moveGroup = (gi: number, dir: -1 | 1) => setGroups((gs) => {
    const j = gi + dir;
    if (gi < 1 || j < 1 || j >= gs.length) return gs;
    const a = [...gs];
    [a[gi], a[j]] = [a[j], a[gi]];
    return a;
  });

  function validate(): string {
    if (!f.title.trim()) return 'Укажите название курса';
    if (!f.folder_id) return 'Выберите папку курса';
    const p = +f.pass_percent;
    if (!(p >= 0 && p <= 100)) return 'Проходной балл — от 0 до 100';
    for (const [gi, g] of groups.entries()) {
      if (gi > 0 && !(g.title || '').trim()) return 'У раздела должно быть название';
      for (const s of g.steps) {
        const nm = s.title.trim() || s.ref_title || 'шаг';
        if ((s.kind === 'item' || s.kind === 'test') && !s.ref_id) return `«${nm}»: не выбран материал или тест`;
        if ((s.kind === 'link' || s.kind === 'video') && !/^https?:\/\//i.test(s.url.trim())) return `«${nm}»: ссылка должна начинаться с http:// или https://`;
        if (s.kind === 'wiki' && !s.url.trim()) return `«${nm}»: укажите ссылку на страницу базы знаний`;
        if ((s.kind === 'link' || s.kind === 'video' || s.kind === 'wiki' || s.kind === 'ack') && !s.title.trim()) return 'У шага нужно название';
      }
    }
    return '';
  }

  function payload(status?: string) {
    const sections = groups.slice(1).map((g) => ({ title: (g.title || '').trim() }));
    const steps: any[] = [];
    groups.forEach((g, gi) => g.steps.forEach((s) => steps.push({
      id: s.id || 0, section: gi === 0 ? null : gi - 1, kind: s.kind, ref_id: s.ref_id, title: s.title.trim() || s.ref_title, body: s.body, url: s.url.trim(), required: s.required,
      pass_percent: s.kind === 'test' && s.pass_percent !== '' ? +s.pass_percent : null, est_minutes: +s.est_minutes || 0,
    })));
    return {
      folder_id: f.folder_id, title: f.title.trim(), description: f.description, cover: f.cover, tags: f.tags.split(/[,;]/).map((t: string) => t.trim().replace(/^#/, '')).filter(Boolean), status: status || f.status,
      est_minutes: +f.est_minutes || autoMin, order_mode: f.order_mode, pass_percent: +f.pass_percent, validity_months: +f.validity_months || 0, max_attempts: f.max_attempts === '' ? null : +f.max_attempts,
      cert_template_id: f.cert_template_id === '' ? null : +f.cert_template_id, prereqs: prereqs.map((p) => p.id), sections, steps,
    };
  }

  async function save(publish: boolean) {
    const v = validate();
    if (v) return setErr(v);
    setErr(''); setBusy(publish ? 'pub' : 'save');
    try {
      const body = payload();
      const r = id ? await api.put<{ id: number }>(`${L}/courses/${id}`, body) : await api.post<{ id: number }>(`${L}/courses`, body);
      if (publish && f.status !== 'published') await api.post(`${L}/courses/${r.id}/status`, { status: 'published' });
      invalidate('learn:'); refreshLearning(); refreshCourse(r.id);
      toast({ title: publish ? 'Курс сохранён и опубликован' : 'Курс сохранён', kind: 'success' });
      navigate(`/learning/courses/${r.id}`);
    } catch (e) { setErr(errMsg(e)); }
    setBusy('');
  }

  if (id && q.error && !q.data) return <ErrorBox error={q.error} retry={q.refetch} />;
  if (!f) return <div className="card pad stack"><Skel h={28} w="40%" /><Skel h={46} /><Skel h={90} /></div>;
  const foldersOff = new Set(tree.list.filter((x) => x.level < 3).map((x) => x.id));
  const published = f.status === 'published';

  return (
    <div className="stack lmEd">
      <div className="lnHead">
        <div className="sp">
          <div className="crumbs"><Link to="/learning/courses">Курсы</Link><I.ChevronRight size={14} /><b style={{ color: 'var(--text)' }}>{id ? 'Редактирование' : 'Новый курс'}</b></div>
          <h2 className="lnTitle">{id ? f.title || 'Курс' : 'Новый курс'}{published ? <> <Badge kind="ok">Опубликован</Badge></> : <> <Badge kind="warn">Черновик</Badge></>}</h2>
        </div>
        <div className="rowW">
          <Link className="btn" to={id ? `/learning/courses/${id}` : '/learning/courses'}>Отмена</Link>
          <Btn busy={busy === 'save'} onClick={() => save(false)}>Сохранить</Btn>
          {!published && <Btn kind="pri" busy={busy === 'pub'} onClick={() => save(true)}><I.Globe size={16} /> Сохранить и опубликовать</Btn>}
        </div>
      </div>
      {err && <div className="err">{err}</div>}
      {id && published && <div className="notice"><I.Info size={16} /> Курс опубликован. Если изменить набор или порядок шагов, версия курса увеличится: у сотрудников, уже завершивших курс, результат сохранится.</div>}

      <div className="card pad">
        <div className="formGrid">
          <div className="fsec">Основное</div>
          <Field label="Название" className="full"><Input value={f.title} maxLength={300} onChange={(e) => set('title', e.target.value)} placeholder="Например: Информационная безопасность" autoFocus={!id} /></Field>
          <Field label="Описание" className="full"><Textarea rows={4} value={f.description} onChange={(e) => set('description', e.target.value)} placeholder="О чём курс, для кого он, чему научит" /></Field>
          <Field label="Обложка"><ImageUpload value={f.cover} onChange={(v) => set('cover', v)} label="" /></Field>
          <Field label="Теги" hint="Через запятую — для поиска и рекомендаций"><Input value={f.tags} onChange={(e) => set('tags', e.target.value)} placeholder="безопасность, обязательное" /></Field>
          <Field label="Папка" className="full"><FolderPicker tree={tree} value={f.folder_id} onChange={(v) => set('folder_id', v)} disabled={foldersOff} /></Field>
        </div>
      </div>

      <div className="card pad">
        <div className="formGrid">
          <div className="fsec">Условия прохождения</div>
          <Field label="Порядок шагов" hint={f.order_mode === 'sequential' ? 'Следующий шаг открывается, когда выполнены все предыдущие обязательные' : 'Шаги можно проходить в любом порядке'}>
            <Select value={f.order_mode} onChange={(e) => set('order_mode', e.target.value)}><option value="free">В любом порядке</option><option value="sequential">Строго по порядку</option></Select>
          </Field>
          <Field label="Проходной балл тестов, %" hint="Можно переопределить для отдельного теста"><Input type="number" min={0} max={100} value={f.pass_percent} onChange={(e) => set('pass_percent', e.target.value)} /></Field>
          <Field label="Попыток на каждый тест" hint="Пусто — без ограничения"><Input type="number" min={1} max={100} value={f.max_attempts} onChange={(e) => set('max_attempts', e.target.value)} placeholder="не ограничено" /></Field>
          <Field label="Срок действия результата, мес." hint="0 — бессрочно. По истечении курс нужно пройти заново"><Input type="number" min={0} max={600} value={f.validity_months} onChange={(e) => set('validity_months', e.target.value)} /></Field>
          <Field label="Сертификат"><Select value={f.cert_template_id} onChange={(e) => set('cert_template_id', e.target.value)}><option value="">Не выдавать</option>{(tpls.data || []).map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</Select></Field>
          <Field label="Длительность, мин" hint={autoMin > 0 ? `По шагам: ${autoMin} мин` : 'Оценка для сотрудников'}><Input type="number" min={0} value={f.est_minutes} onChange={(e) => set('est_minutes', e.target.value)} placeholder={autoMin ? String(autoMin) : '0'} /></Field>
          <Field label="Предпосылки" className="full" hint="Курс откроется только после завершения этих курсов"><PrereqPicker value={prereqs} onChange={setPrereqs} exclude={id} /></Field>
        </div>
      </div>

      <div className="card pad stack">
        <div className="row"><h3 className="lnH3 sp">Программа курса</h3><span className="small muted">{plural(total, ['шаг', 'шага', 'шагов'])}, обязательных: {reqN}</span></div>
        <div className="small muted">Курс завершается, когда выполнены все <b>обязательные</b> шаги. Тесты засчитываются при наборе проходного балла.</div>
        {groups.map((g, gi) => (
          <div key={g.key} className="lmEdGroup">
            {gi > 0 && (
              <div className="lmEdGroupHd">
                <I.Folder size={16} />
                <Input value={g.title || ''} placeholder="Название раздела" maxLength={200} onChange={(e) => setGroups((gs) => gs.map((x, i) => (i === gi ? { ...x, title: e.target.value } : x)))} />
                <Btn size="sm" kind="ghost" icon aria-label="Раздел выше" disabled={gi < 2} onClick={() => moveGroup(gi, -1)}><I.ChevronDown size={16} style={{ transform: 'rotate(180deg)' }} /></Btn>
                <Btn size="sm" kind="ghost" icon aria-label="Раздел ниже" disabled={gi >= groups.length - 1} onClick={() => moveGroup(gi, 1)}><I.ChevronDown size={16} /></Btn>
                <Btn size="sm" kind="ghost" icon aria-label="Удалить раздел" title="Удалить раздел (шаги перейдут в начало курса)" onClick={() => setGroups((gs) => { const x = gs[gi]; return gs.filter((_, i) => i !== gi).map((y, i) => (i === 0 ? { ...y, steps: [...y.steps, ...x.steps] } : y)); })}><I.Trash size={16} /></Btn>
              </div>
            )}
            {gi === 0 && groups.length > 1 && <div className="tiny muted">Шаги без раздела</div>}
            {g.steps.map((s, si) => (
              <StepRow key={s.key} s={s} first={si === 0} last={si === g.steps.length - 1} groups={groups} gi={gi}
                onChange={(p) => upd(gi, si, p)} onMove={(d) => move(gi, si, d)} onRemove={() => remove(gi, si)} onGroup={(to) => toGroup(gi, si, to)} />
            ))}
            <AddMenu onItem={() => setPicker({ kind: 'item', group: gi })} onTest={() => setPicker({ kind: 'test', group: gi })}
              onOther={(kind) => addStep(gi, { kind })} />
          </div>
        ))}
        {total === 0 && <Empty icon={I.Layers} title="Добавьте первый шаг">Материал, тест, видео, ссылка, страница базы знаний или подтверждение ознакомления</Empty>}
        <div><Btn size="sm" onClick={() => setGroups((gs) => [...gs, { key: nk(), title: '', steps: [] }])}><I.Plus size={15} /> Раздел</Btn></div>
      </div>
      {err && <div className="err">{err}</div>}
      <div className="lnSaveBar">
        <Link className="btn" to={id ? `/learning/courses/${id}` : '/learning/courses'}>Отмена</Link>
        <Btn busy={busy === 'save'} onClick={() => save(false)}>Сохранить</Btn>
        {!published && <Btn kind="pri" busy={busy === 'pub'} onClick={() => save(true)}><I.Globe size={16} /> Сохранить и опубликовать</Btn>}
      </div>
      {picker && <RefPicker kind={picker.kind} onClose={() => setPicker(null)} onPick={(list) => { list.forEach((r) => addStep(picker.group, { kind: picker.kind, ref_id: r.id, ref_title: r.title, title: r.title, open: false, required: true })); setPicker(null); }} />}
    </div>
  );
}

// ---------------------------------------------------------------- шаг

function StepRow({ s, first, last, groups, gi, onChange, onMove, onRemove, onGroup }: {
  s: EStep; first: boolean; last: boolean; groups: EGroup[]; gi: number; onChange: (p: Partial<EStep>) => void; onMove: (d: -1 | 1) => void; onRemove: () => void; onGroup: (to: number) => void;
}) {
  const K = STEP_KIND[s.kind];
  const name = s.title || s.ref_title || 'Без названия';
  return (
    <div className={cx('lmEdStep', s.open && 'open')}>
      <div className="lmEdStepHd">
        <span className="lmSi"><K.icon size={14} /></span>
        <button type="button" className="lmEdStepName" onClick={() => onChange({ open: !s.open })} aria-expanded={!!s.open}>
          <span className="bold clip">{name}</span>
          <span className="tiny muted">{K.label}{s.kind === 'item' || s.kind === 'test' ? (s.ref_title && s.ref_title !== name ? ` · ${s.ref_title}` : '') : ''}{!s.required && ' · по желанию'}</span>
        </button>
        <Btn size="sm" kind="ghost" icon aria-label="Выше" disabled={first} onClick={() => onMove(-1)}><I.ChevronDown size={16} style={{ transform: 'rotate(180deg)' }} /></Btn>
        <Btn size="sm" kind="ghost" icon aria-label="Ниже" disabled={last} onClick={() => onMove(1)}><I.ChevronDown size={16} /></Btn>
        <Btn size="sm" kind="ghost" icon aria-label="Удалить шаг" onClick={onRemove}><I.Trash size={16} /></Btn>
      </div>
      {s.open && (
        <div className="lmEdStepBd formGrid">
          <Field label="Название шага" className="full"><Input value={s.title} maxLength={300} onChange={(e) => onChange({ title: e.target.value })} placeholder={s.ref_title || 'Название'} /></Field>
          {(s.kind === 'link' || s.kind === 'video' || s.kind === 'wiki') && (
            <Field label={s.kind === 'wiki' ? 'Ссылка на страницу базы знаний' : 'Ссылка'} className="full" hint={s.kind === 'wiki' ? 'Например: /learning/wiki/hr/onboarding или полный адрес' : s.kind === 'video' ? 'Прямая ссылка на .mp4/.webm воспроизводится на странице, остальные открываются на сайте-источнике' : undefined}>
              <Input value={s.url} onChange={(e) => onChange({ url: e.target.value })} placeholder={s.kind === 'wiki' ? '/learning/wiki/…' : 'https://…'} />
            </Field>
          )}
          {s.kind === 'ack' && <Field label="Текст для ознакомления" className="full"><Textarea rows={4} value={s.body} onChange={(e) => onChange({ body: e.target.value })} placeholder="Я ознакомился(лась) с … и обязуюсь соблюдать" /></Field>}
          {s.kind === 'test' && <Field label="Проходной балл теста, %" hint="Пусто — как в курсе"><Input type="number" min={0} max={100} value={s.pass_percent} onChange={(e) => onChange({ pass_percent: e.target.value })} /></Field>}
          <Field label="Время, мин"><Input type="number" min={0} value={s.est_minutes} onChange={(e) => onChange({ est_minutes: e.target.value })} /></Field>
          {groups.length > 1 && (
            <Field label="Раздел"><Select value={gi} onChange={(e) => onGroup(+e.target.value)}>{groups.map((g, i) => <option key={g.key} value={i}>{i === 0 ? 'Без раздела' : g.title || `Раздел ${i}`}</option>)}</Select></Field>
          )}
          <div className="full"><Check checked={s.required} onChange={(v) => onChange({ required: v })} label="Обязательный шаг (нужен для завершения курса)" /></div>
        </div>
      )}
    </div>
  );
}

function AddMenu({ onItem, onTest, onOther }: { onItem: () => void; onTest: () => void; onOther: (k: 'video' | 'link' | 'wiki' | 'ack') => void }) {
  const pop = usePopover();
  return (
    <div style={{ position: 'relative', display: 'inline-block' }} ref={pop.ref}>
      <Btn size="sm" onClick={() => pop.setOpen(!pop.open)}><I.Plus size={15} /> Добавить шаг</Btn>
      {pop.open && (
        <div className="menu" onClick={() => pop.setOpen(false)}>
          <button onClick={onItem}><I.Book size={16} /> Материал…</button>
          <button onClick={onTest}><I.GradCap size={16} /> Тест…</button>
          <button onClick={() => onOther('video')}><I.Video size={16} /> Видео</button>
          <button onClick={() => onOther('link')}><I.Link size={16} /> Ссылка</button>
          <button onClick={() => onOther('wiki')}><I.FileText size={16} /> Страница базы знаний</button>
          <button onClick={() => onOther('ack')}><I.Check size={16} /> Ознакомление (подтверждение)</button>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- выбор материалов / тестов

function RefPicker({ kind, onClose, onPick }: { kind: 'item' | 'test'; onClose: () => void; onPick: (r: { id: number; title: string }[]) => void }) {
  const [q, setQ] = useState('');
  const dq = useDebounced(q.trim(), 250);
  const url = kind === 'item' ? `${L}/materials?q=${encodeURIComponent(dq)}&page=1` : `${L}/tests?q=${encodeURIComponent(dq)}&page=1`;
  const { data, loading } = useQuery<{ items: any[] }>(dq ? `learn:pick:${kind}:${dq}` : null, () => api.get(url), { stale: 15000 });
  const [sel, setSel] = useState<Map<number, string>>(new Map());
  const items = (data?.items || []).filter((x) => kind === 'item' || x.status === 'published');
  return (
    <Modal title={kind === 'item' ? 'Выбор материалов' : 'Выбор тестов'} onClose={onClose}
      footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" disabled={!sel.size} onClick={() => onPick([...sel].map(([id, title]) => ({ id, title })))}>Добавить{sel.size ? ` (${sel.size})` : ''}</Btn></>}>
      <div className="stack">
        <div className="lnSearch"><I.Search size={17} /><input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Начните вводить название…" aria-label="Поиск" /></div>
        {!dq ? <div className="small muted">Введите часть названия {kind === 'item' ? 'материала' : 'опубликованного теста'}.</div> : loading && !data ? <Skel h={50} /> : !items.length ? <div className="small muted">Ничего не найдено{kind === 'test' ? ' (в курс можно добавить только опубликованные тесты)' : ''}.</div> : (
          <div className="lmPickList">
            {items.map((x) => (
              <label key={x.id} className={cx('lmPickRow', sel.has(x.id) && 'on')}>
                <input type="checkbox" checked={sel.has(x.id)} onChange={() => setSel((m) => { const n = new Map(m); n.has(x.id) ? n.delete(x.id) : n.set(x.id, x.title); return n; })} />
                <span className="sp" style={{ minWidth: 0 }}><span className="bold clip" style={{ display: 'block' }}>{x.title}</span>{x.folder_name && <span className="tiny muted"><I.Folder size={11} /> {x.folder_name}</span>}</span>
              </label>
            ))}
          </div>
        )}
      </div>
    </Modal>
  );
}

function PrereqPicker({ value, onChange, exclude }: { value: { id: number; title: string }[]; onChange: (v: { id: number; title: string }[]) => void; exclude?: number }) {
  const [q, setQ] = useState('');
  const dq = useDebounced(q.trim(), 200);
  const { data } = useQuery<any[]>(`learn:c:pick:${dq}:${exclude || 0}`, () => api.get(`${L}/courses/pick?q=${encodeURIComponent(dq)}${exclude ? '&exclude=' + exclude : ''}`), { stale: 20000 });
  const ids = useMemo(() => new Set(value.map((v) => v.id)), [value]);
  const list = (data || []).filter((x) => !ids.has(x.id));
  return (
    <div className="stackS">
      {value.length > 0 && <div className="tokens">{value.map((p) => <span className="token" key={p.id}>{p.title}<button type="button" onClick={() => onChange(value.filter((x) => x.id !== p.id))} aria-label="Убрать"><I.X size={14} /></button></span>)}</div>}
      <div className="pick">
        <input className="sel" placeholder="Найти курс…" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="lst">
          {list.map((x) => <div key={x.id} className="pickRow" onClick={() => { onChange([...value, { id: x.id, title: x.title }]); setQ(''); }}><I.GradCap size={16} /><div className="bold small clip">{x.title}</div></div>)}
          {!list.length && <div className="small muted" style={{ padding: 12 }}>Нет подходящих опубликованных курсов</div>}
        </div>
      </div>
    </div>
  );
}
