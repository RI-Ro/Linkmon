// LMS: страница курса — обзор, оглавление, плеер шагов, прогресс «продолжить с места остановки».
import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { invalidate, useQuery } from '../../lib/query';
import { Link, navigate, useSearchParams, useTitle } from '../../lib/router';
import { toast, useStore } from '../../lib/store';
import { cx, plural } from '../../lib/util';
import { Badge, Btn, Check, Empty, ErrorBox, Skel, useConfirm } from '../../ui';
import { L, refreshLearning } from './common';
import { Bar, Cover, DueChip, ORDER_LABEL, Ring, STEP_KIND, dmy, hm, isLmsManager, mins, score1 } from './lms-common';

export interface Step {
  id: number; section_id: number | null; sort: number; kind: 'item' | 'wiki' | 'video' | 'link' | 'test' | 'ack'; ref_id: number | null; title: string; body: string; url: string;
  required: boolean; pass_percent: number | null; est_minutes: number; ref_title: string | null; item_kind: string | null; questions_count: number | null; time_limit_min: number | null;
  test_status: string | null; status: number; score: number | null; time_sec: number; available: boolean; locked?: string;
}
export interface CourseData {
  course: any; level: number; folder_name: string; author: string | null; sections: { id: number; title: string; sort: number }[]; steps: Step[];
  prereqs: { id: number; title: string; done: boolean }[]; prereqs_ok: boolean; next_step_id: number | null; can_edit: boolean; prereq_ids?: number[];
  enrollment?: { status: number; cycle: number; started_at: string | null; last_at: string | null; completed_at: string | null; expires_at: string | null; steps_done: number; steps_total: number; percent: number; time_sec: number; score: number | null; cert_id: number | null };
  cert?: { id: number; number: string; status: string; issued_at: string; expires_at: string | null };
  assignment?: { id: number; due_at: string | null; status: number; high: boolean; mandatory: boolean; assigned_at: string; overdue: boolean };
}

export const courseKey = (id: number) => `learn:c:${id}`;
export const refreshCourse = (id: number) => { invalidate(courseKey(id)); invalidate('learn:c:list'); invalidate('learn:my'); invalidate('learn:stats'); };
const stepTo = (cid: number, sid: number) => `/learning/courses/${cid}/step/${sid}`;

function StepIcon({ s, size = 16 }: { s: Step; size?: number }) {
  if (s.status === 2) return <span className="lmSi ok"><I.Check size={size - 3} /></span>;
  if (!s.available) return <span className="lmSi lock"><I.Lock size={size - 4} /></span>;
  const Ic = STEP_KIND[s.kind]?.icon || I.File;
  return <span className={cx('lmSi', s.status === 1 && 'cur')}><Ic size={size - 3} /></span>;
}

/** Оглавление: шаги без раздела, затем разделы по порядку. */
function groupSteps(d: CourseData) {
  const groups: { id: number | null; title: string | null; steps: Step[] }[] = [];
  const free = d.steps.filter((s) => s.section_id == null);
  if (free.length) groups.push({ id: null, title: d.sections.length ? 'Введение' : null, steps: free });
  for (const sec of d.sections) groups.push({ id: sec.id, title: sec.title, steps: d.steps.filter((s) => s.section_id === sec.id) });
  return groups;
}

function Outline({ d, cur }: { d: CourseData; cur?: number }) {
  const cid = d.course.id;
  const groups = groupSteps(d);
  return (
    <div className="lmOutline">
      {groups.map((g, gi) => {
        const done = g.steps.filter((s) => s.status === 2).length;
        return (
          <div key={g.id ?? 'free'} className="lmSec">
            {g.title && <div className="lmSecHd"><span className="sp clip">{g.title}</span><span className="tiny muted">{done}/{g.steps.length}</span></div>}
            {g.steps.map((s, i) => {
              const inner = (
                <>
                  <StepIcon s={s} />
                  <span className="sp" style={{ minWidth: 0 }}>
                    <span className="lmStTitle clip">{s.title}</span>
                    <span className="tiny muted">{STEP_KIND[s.kind]?.label}{s.est_minutes > 0 && ` · ${mins(s.est_minutes)}`}{!s.required && ' · по желанию'}</span>
                  </span>
                  {s.kind === 'test' && s.score != null && <span className="tiny bold">{score1(s.score)}</span>}
                </>
              );
              const ok = s.available && d.prereqs_ok;
              return ok
                ? <Link key={s.id} to={stepTo(cid, s.id)} className={cx('lmSt', cur === s.id && 'on', s.status === 2 && 'done')} aria-current={cur === s.id ? 'step' : undefined}>{inner}</Link>
                : <div key={s.id} className="lmSt locked" title={s.locked || 'Сначала пройдите курсы-предпосылки'}>{inner}</div>;
            })}
          </div>
        );
      })}
    </div>
  );
}

// ---------------------------------------------------------------- страница курса

export function CoursePage({ id, sid }: { id: number; sid?: number }) {
  const me = useStore((s) => s.me)!;
  const { data, error, refetch } = useQuery<CourseData>(courseKey(id), () => api.get(`${L}/courses/${id}`), { stale: 0, keepPrevious: true });
  const [confirm, confirmNode] = useConfirm();
  const [busy, setBusy] = useState('');
  useTitle(data?.course?.title || 'Курс');
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data || data.course.id !== id) return <div className="card pad stack"><Skel h={160} /><Skel h={26} w="50%" /><Skel h={16} /><Skel h={16} w="70%" /></div>;
  const { course: c, enrollment: enr, cert, assignment: asg } = data;
  const mgr = isLmsManager(me as any);
  const status = enr?.status ?? 0;
  const expired = status === 2 && !!enr?.expires_at && new Date(enr.expires_at) < new Date();
  const soon = status === 2 && !!enr?.expires_at && !expired && new Date(enr.expires_at).getTime() - Date.now() < 30 * 86400000;
  const step = sid ? data.steps.find((s) => s.id === sid) : undefined;
  const pct = status === 2 ? 100 : enr?.percent ?? 0;

  async function start() {
    setBusy('start');
    try {
      if (status === 2 && (expired || soon)) await api.post(`${L}/courses/${id}/restart`);
      else if (status === 0) await api.post(`${L}/courses/${id}/start`);
      refreshCourse(id);
      const fresh = await api.get<CourseData>(`${L}/courses/${id}`);
      const target = fresh.next_step_id || fresh.steps[0]?.id;
      if (target) navigate(stepTo(id, target));
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy('');
  }
  async function setStatus(st: 'published' | 'draft') {
    setBusy('st');
    try { await api.post(`${L}/courses/${id}/status`, { status: st }); toast({ title: st === 'published' ? 'Курс опубликован' : 'Курс скрыт (черновик)', kind: 'success' }); refreshCourse(id); refreshLearning(); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy('');
  }
  async function copy() {
    setBusy('copy');
    try { const r = await api.post<{ id: number }>(`${L}/courses/${id}/copy`); refreshLearning(); toast({ title: 'Копия создана (черновик)', kind: 'success' }); navigate(`/learning/courses/${r.id}/edit`); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy('');
  }
  async function remove() {
    if (!(await confirm(`Удалить курс «${c.title}»?`, { text: 'Вместе с прогрессом сотрудников и назначениями. Выданные сертификаты сохранятся. Действие необратимо.', ok: 'Удалить' }))) return;
    try { await api.del(`${L}/courses/${id}`); refreshLearning(); invalidate('learn:'); toast({ title: 'Курс удалён', kind: 'success' }); navigate('/learning/courses'); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }

  const head = (
    <div className="lmHead card">
      <Cover src={c.cover} title={c.title} className="lmHeadCover" />
      <div className="lmHeadBd stackS">
        <div className="crumbs"><Link to="/learning/courses">Курсы</Link><I.ChevronRight size={14} /><Link to={`/learning/courses?folder=${c.folder_id}`}>{data.folder_name}</Link></div>
        <h2 className="lnTitle">{c.title}{c.status === 'draft' && <> <Badge kind="warn">Черновик</Badge></>}</h2>
        {c.tags.length > 0 && <div className="lmMeta">{c.tags.map((t: string) => <Link key={t} to={`/learning/courses?tag=${encodeURIComponent(t)}`} className="lnTag">#{t}</Link>)}</div>}
        <div className="lmFacts">
          <span><I.Layers size={14} /> {plural(c.steps_count, ['шаг', 'шага', 'шагов'])}{c.steps_count !== c.required_count && `, обязательных ${c.required_count}`}</span>
          {c.est_minutes > 0 && <span><I.Clock size={14} /> ~{mins(c.est_minutes)}</span>}
          <span><I.List size={14} /> {ORDER_LABEL[c.order_mode as keyof typeof ORDER_LABEL]}</span>
          <span><I.Check size={14} /> проходной балл {c.pass_percent}%</span>
          {c.max_attempts && <span><I.Refresh size={14} /> до {plural(c.max_attempts, ['попытка', 'попытки', 'попыток'])} на тест</span>}
          {c.validity_months > 0 && <span><I.Calendar size={14} /> результат действует {c.validity_months} мес.</span>}
          {data.author && <span><I.Edit size={14} /> {data.author}</span>}
        </div>
      </div>
      <div className="lmHeadAct rowW">
        {data.can_edit && <Link className="btn" to={`/learning/courses/${id}/edit`}><I.Edit size={16} /> Править</Link>}
        {data.can_edit && (c.status === 'draft'
          ? <Btn kind="pri" busy={busy === 'st'} onClick={() => setStatus('published')}><I.Globe size={16} /> Опубликовать</Btn>
          : <Btn busy={busy === 'st'} onClick={() => setStatus('draft')}>Снять с публикации</Btn>)}
        {mgr && c.status === 'published' && <Link className="btn" to={`/learning/assignments/new?type=course&target=${id}`}><I.UserPlus size={16} /> Назначить</Link>}
        {mgr && <Link className="btn" to={`/learning/stats/course/${id}`}><I.Chart size={16} /> Статистика</Link>}
        {data.can_edit && <Btn kind="ghost" icon aria-label="Копировать" title="Создать копию" busy={busy === 'copy'} onClick={copy}><I.Copy size={17} /></Btn>}
        {data.can_edit && <Btn kind="ghost" icon aria-label="Удалить" title="Удалить курс" onClick={remove}><I.Trash size={17} /></Btn>}
      </div>
    </div>
  );

  // ----- плеер
  if (sid) {
    if (!step) return <div className="stack">{head}<div className="card"><Empty icon={I.Search} title="Шаг не найден"><Link to={`/learning/courses/${id}`}>К курсу</Link></Empty></div>{confirmNode}</div>;
    return (
      <div className="stack">
        <div className="lmPlayerBar card">
          <Link to={`/learning/courses/${id}`} className="btn ghost sm"><I.ArrowLeft size={15} /> {c.title}</Link>
          <div className="sp" />
          <div className="lmPlayerProg"><span className="small muted">{pct}%</span><Bar p={pct} thin /></div>
        </div>
        <div className="lmPlayer">
          <aside className="lmSide card"><Outline d={data} cur={sid} /></aside>
          <StepPanel key={sid} d={data} step={step} onChanged={() => refreshCourse(id)} />
        </div>
        {confirmNode}
      </div>
    );
  }

  // ----- обзор
  const ctaText = status === 0 ? 'Начать курс' : status === 1 ? 'Продолжить' : expired || soon ? 'Пройти заново' : 'Повторить материалы';
  const blocked = !data.prereqs_ok;
  return (
    <div className="stack">
      {head}
      <div className="lmCols">
        <div className="stack" style={{ minWidth: 0 }}>
          {c.description && <div className="card pad lmDesc">{c.description}</div>}
          {blocked && (
            <div className="notice warn"><I.Lock size={18} /><div>Чтобы начать, пройдите курсы-предпосылки: {data.prereqs.filter((p) => !p.done).map((p, i) => <React.Fragment key={p.id}>{i > 0 && ', '}<Link to={`/learning/courses/${p.id}`}><b>{p.title}</b></Link></React.Fragment>)}</div></div>
          )}
          {data.prereqs.some((p) => p.done) && !blocked && <div className="small muted">Предпосылки выполнены: {data.prereqs.map((p) => p.title).join(', ')}</div>}
          {c.status === 'draft' && <div className="notice warn"><I.Info size={18} /> Курс — черновик: его видят только редакторы папки. Опубликуйте курс, чтобы назначать его сотрудникам.</div>}
          <div className="card">
            <div className="lmCardHd"><h3 className="lnH3">Программа курса</h3><span className="small muted">{data.steps.filter((s) => s.status === 2).length} из {data.steps.length} пройдено</span></div>
            {data.steps.length === 0 ? <Empty icon={I.Layers} title="В курсе пока нет шагов" /> : <Outline d={data} />}
          </div>
        </div>
        <aside className="stack lmAside">
          <div className="card pad stack lmProgCard">
            <div className="row" style={{ gap: 14 }}>
              <Ring p={pct} size={76} />
              <div className="stackS sp">
                <b>{status === 2 ? (expired ? 'Срок действия истёк' : 'Курс пройден') : status === 1 ? 'В процессе' : 'Не начат'}</b>
                {enr && status > 0 && <span className="small muted">Шагов: {enr.steps_done} из {enr.steps_total}{enr.time_sec > 0 && ` · ${hm(enr.time_sec)}`}</span>}
                {status === 2 && enr?.score != null && <span className="small">Средний балл: <b>{score1(enr.score)}</b></span>}
              </div>
            </div>
            {asg && asg.status < 2 && <div className="row small" style={{ flexWrap: 'wrap' }}><Badge kind={asg.overdue ? 'dng' : 'warn'}>{asg.mandatory ? 'Обязательный' : 'Назначен'}</Badge><DueChip due={asg.due_at} status={asg.status} high={asg.high} /></div>}
            {status === 2 && enr?.completed_at && <div className="small muted">Завершён {dmy(enr.completed_at)}{enr.expires_at && <> · действует до <b>{dmy(enr.expires_at)}</b></>}</div>}
            {(expired || soon) && <div className="notice warn small"><I.Refresh size={16} /> {expired ? 'Срок действия результата истёк — курс нужно пройти заново.' : 'Срок действия результата скоро закончится — можно пройти курс заново досрочно.'}</div>}
            {(c.status === 'published' || data.can_edit) && data.steps.length > 0 && (
              <Btn kind="pri" busy={busy === 'start'} disabled={blocked} onClick={status === 2 && !(expired || soon) ? () => navigate(stepTo(id, data.steps[0].id)) : start}><I.Play size={15} /> {ctaText}</Btn>
            )}
            {status === 1 && data.next_step_id && <div className="tiny muted">Вы остановились на шаге «{data.steps.find((s) => s.id === data.next_step_id)?.title}»</div>}
          </div>
          {cert && (
            <div className="card pad stackS">
              <div className="row"><I.Star size={18} /><b className="sp">Сертификат</b><Badge kind={cert.status === 'revoked' ? 'dng' : cert.expires_at && new Date(cert.expires_at) < new Date() ? 'warn' : 'ok'}>{cert.status === 'revoked' ? 'Отозван' : cert.expires_at && new Date(cert.expires_at) < new Date() ? 'Истёк' : 'Действителен'}</Badge></div>
              <div className="small muted">№ {cert.number} · выдан {dmy(cert.issued_at)}{cert.expires_at && ` · до ${dmy(cert.expires_at)}`}</div>
              <Link className="btn" to={`/learning/certificates/${cert.id}`}>Открыть сертификат</Link>
            </div>
          )}
          {!cert && c.cert_template_id && <div className="card pad small muted"><I.Star size={15} /> За прохождение курса выдаётся сертификат{c.validity_months > 0 && ` (действует ${c.validity_months} мес.)`}.</div>}
        </aside>
      </div>
      {confirmNode}
    </div>
  );
}

// ---------------------------------------------------------------- шаг

function adjacent(d: CourseData, sid: number) {
  const i = d.steps.findIndex((s) => s.id === sid);
  const prev = d.steps[i - 1], next = d.steps[i + 1];
  return { prev: prev && prev.available ? prev : undefined, next: next && next.available ? next : undefined };
}

function nextAfter(d: CourseData, sid: number): number | null {
  const i = d.steps.findIndex((s) => s.id === sid);
  const rest = [...d.steps.slice(i + 1), ...d.steps.slice(0, i)];
  const n = rest.find((s) => s.status !== 2 && s.available);
  return n ? n.id : null;
}

function StepPanel({ d, step, onChanged }: { d: CourseData; step: Step; onChanged: () => void }) {
  const cid = d.course.id;
  const [busy, setBusy] = useState(false);
  const [sure, setSure] = useState(false);
  const usable = step.available && d.prereqs_ok;
  const done = step.status === 2;
  const { prev, next } = adjacent(d, step.id);
  const enrolled = !!d.enrollment && d.enrollment.status > 0;

  // открытие шага (фиксирует «в процессе») и сигнал активности
  useEffect(() => {
    if (!usable) return;
    api.post(`${L}/courses/${cid}/steps/${step.id}/open`).then(() => { if (!enrolled) onChanged(); }).catch(() => {});
  }, [step.id]);
  const done_ = useRef(done);
  done_.current = done;
  useEffect(() => {
    if (!usable) return;
    const t = setInterval(() => { if (document.visibilityState === 'visible' && !done_.current) api.post(`${L}/courses/${cid}/steps/${step.id}/beat`).catch(() => {}); }, 30000);
    return () => clearInterval(t);
  }, [step.id, usable]);

  async function finish() {
    setBusy(true);
    try {
      const r = await api.post<{ completed: boolean }>(`${L}/courses/${cid}/steps/${step.id}/done`);
      onChanged();
      const fresh = await api.get<CourseData>(`${L}/courses/${cid}`);
      if (r.completed) {
        toast({ title: 'Курс пройден!', body: fresh.cert ? 'Сертификат выдан' : undefined, kind: 'success' });
        navigate(`/learning/courses/${cid}`);
      } else {
        const n = nextAfter(fresh, step.id);
        navigate(n ? stepTo(cid, n) : `/learning/courses/${cid}`);
      }
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }

  const K = STEP_KIND[step.kind];
  const passP = step.pass_percent ?? d.course.pass_percent;
  const ext = (u: string) => /^https?:\/\//i.test(u);
  const direct = /\.(mp4|webm|ogg)(\?|#|$)/i.test(step.url);
  return (
    <div className="card pad lmStep stack">
      <div className="stackS">
        <div className="row small muted"><K.icon size={15} /> {K.label}{!step.required && <Badge>по желанию</Badge>}{done && <Badge kind="ok"><I.Check size={11} /> пройден</Badge>}</div>
        <h2 className="lnTitle">{step.title}</h2>
      </div>
      {!usable ? (
        <div className="notice warn"><I.Lock size={18} /> {step.locked || 'Сначала пройдите курсы-предпосылки.'}</div>
      ) : (
        <>
          {step.kind === 'item' && (
            <div className="stackS">
              <div className="muted">Изучите материал, затем вернитесь и отметьте шаг пройденным.</div>
              <div className="rowW">
                <Link className="btn pri" to={`/learning/materials/item/${step.ref_id}?course=${cid}&step=${step.id}`}><I.Book size={16} /> Открыть материал</Link>
              </div>
            </div>
          )}
          {(step.kind === 'wiki' || step.kind === 'link' || step.kind === 'video') && (
            <div className="stackS">
              {step.kind === 'video' && direct && <video className="lnVideo" controls preload="metadata" src={step.url} />}
              <div className="rowW">
                {ext(step.url)
                  ? <a className="btn pri" href={step.url} target="_blank" rel="noopener noreferrer"><I.External size={16} /> {step.kind === 'video' ? 'Смотреть видео' : 'Открыть'}</a>
                  : <Link className="btn pri" to={step.url}><I.FileText size={16} /> Открыть страницу</Link>}
                <span className="small muted clip">{ext(step.url) ? new URL(step.url).hostname : step.url}</span>
              </div>
            </div>
          )}
          {step.kind === 'ack' && (
            <div className="stackS">
              {step.body && <div className="lmAck">{step.body}</div>}
              {!done && <Check checked={sure} onChange={setSure} label="Я ознакомился(лась) и подтверждаю" />}
            </div>
          )}
          {step.kind === 'test' && (
            <div className="stackS">
              <div className="lmFacts">
                {step.questions_count != null && <span><I.List size={14} /> {plural(step.questions_count, ['вопрос', 'вопроса', 'вопросов'])}</span>}
                {step.time_limit_min && <span><I.Clock size={14} /> {step.time_limit_min} мин</span>}
                <span><I.Check size={14} /> проходной балл {passP}%</span>
                {d.course.max_attempts && <span><I.Refresh size={14} /> попыток: {d.course.max_attempts}</span>}
              </div>
              {step.score != null && <div className={cx('notice', done ? '' : 'warn')}><I.Info size={16} /> Лучший результат: <b>{score1(step.score)}</b>{done ? ' — тест сдан.' : ` — до проходного балла не хватает ${Math.max(0, Math.ceil(passP - step.score))}%.`}</div>}
              {step.test_status && step.test_status !== 'published' && <div className="notice warn"><I.Alert size={16} /> Тест не опубликован — пройти его пока нельзя.</div>}
              <div className="rowW">
                <Link className="btn pri" to={`/learning/tests/${step.ref_id}/run?step=${step.id}`}><I.Play size={15} /> {done ? 'Пересдать тест' : step.score != null ? 'Пройти ещё раз' : 'Начать тест'}</Link>
                <Link className="btn" to="/learning/tests/my">Мои результаты</Link>
              </div>
              <div className="tiny muted">Шаг засчитывается автоматически, когда набран проходной балл.</div>
            </div>
          )}
        </>
      )}
      <div className="lmStepFt">
        {prev ? <Link className="btn" to={stepTo(cid, prev.id)}><I.ArrowLeft size={15} /> Назад</Link> : <span />}
        <div className="sp" />
        {usable && step.kind !== 'test' && !done && (
          <Btn kind="pri" busy={busy} disabled={step.kind === 'ack' && !sure} onClick={finish}><I.Check size={15} /> {step.kind === 'ack' ? 'Подтверждаю' : 'Отметить пройденным'}</Btn>
        )}
        {next && (done || step.kind === 'test' || !usable) && <Link className="btn pri" to={stepTo(cid, next.id)}>Далее <I.ChevronRight size={15} /></Link>}
        {next && !done && step.kind !== 'test' && usable && !step.required && <Link className="btn ghost" to={stepTo(cid, next.id)}>Пропустить</Link>}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- плашка на странице материала, открытого из курса

export function CourseStepBar() {
  const [sp] = useSearchParams();
  const cid = +(sp.get('course') || 0), sid = +(sp.get('step') || 0);
  const { data, refetch } = useQuery<CourseData>(cid && sid ? courseKey(cid) : null, () => api.get(`${L}/courses/${cid}`), { stale: 5000 });
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (cid && sid) api.post(`${L}/courses/${cid}/steps/${sid}/open`).catch(() => {}); }, [cid, sid]);
  const step = useMemo(() => data?.steps.find((s) => s.id === sid), [data, sid]);
  if (!cid || !sid || !data || !step) return null;
  async function finish() {
    setBusy(true);
    try {
      const r = await api.post<{ completed: boolean }>(`${L}/courses/${cid}/steps/${sid}/done`);
      refreshCourse(cid);
      const fresh = await api.get<CourseData>(`${L}/courses/${cid}`);
      if (r.completed) toast({ title: 'Курс пройден!', kind: 'success' });
      const n = r.completed ? null : nextAfter(fresh, sid);
      navigate(n ? stepTo(cid, n) : `/learning/courses/${cid}`);
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); setBusy(false); }
    void refetch;
  }
  return (
    <div className="card lmStepBar">
      <I.GradCap size={18} />
      <div className="sp" style={{ minWidth: 0 }}><div className="small muted">Шаг курса «{data.course.title}»</div><div className="bold clip">{step.title}</div></div>
      <Link className="btn sm" to={stepTo(cid, sid)}>К курсу</Link>
      {step.status !== 2 ? <Btn size="sm" kind="pri" busy={busy} onClick={finish}><I.Check size={15} /> Пройдено</Btn> : <Badge kind="ok"><I.Check size={11} /> пройден</Badge>}
    </div>
  );
}
