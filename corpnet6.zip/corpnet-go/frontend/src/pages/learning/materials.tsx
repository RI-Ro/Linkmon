import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { invalidate, setQueryData, updateQueries, useQuery } from '../../lib/query';
import { Link, navigate, useSearchParams, useTitle } from '../../lib/router';
import { toast, useStore } from '../../lib/store';
import { usePersist } from '../../lib/persist';
import { cx, fmtSize, plural, useDebounced, fileKind } from '../../lib/util';
import { Markdown } from '../../lib/markdown';
import { Badge, Btn, Empty, ErrorBox, Field, FileIcon, FileLink, Input, Loading, Modal, Pager, Select, Skel, Textarea, useConfirm } from '../../ui';
import { MdEditor } from '../../ui/MdEditor';
import { Lightbox } from '../../ui/Lightbox';
import { PdfViewer } from '../../ui/PdfViewer';
import { FolderShell, L, ListSkeleton, MoveItemsModal, Tree, Crumbs, dtShort, prefetchFolder, refreshLearning, useTree } from './common';
import { CourseStepBar } from './lms-course';
import { thumb, view as viewUrl } from '../../lib/util';
import { WikiNewSpace, WikiShelf } from '../wiki';

interface Item {
  id: number; folder_id: number; kind: 'text' | 'file' | 'video' | 'link'; title: string; description: string; tags: string[]; sort: number;
  views_count: number; created_at: string; files_count: number; done: boolean;
  first_file?: { id: number; name: string; mime: string; size: number; has_thumb: boolean } | null;
}
interface ListData { items: Item[]; total?: number; has_more: boolean; page: number; per: number; level?: number }

const KIND_LABEL = { text: 'Текст', file: 'Файлы', video: 'Видео', link: 'Ссылка' };
const KIND_ICON = { text: I.FileText, file: I.File, video: I.Video, link: I.Link };

function ItemIcon({ it }: { it: Item }) {
  if (it.kind === 'file' && it.first_file) return <FileIcon name={it.first_file.name} mime={it.first_file.mime} />;
  const Ic = KIND_ICON[it.kind];
  return <div className={cx('fico', it.kind === 'video' ? 'video' : it.kind === 'link' ? 'zip' : 'text')}><Ic size={20} /></div>;
}

// ---------------------------------------------------------------- страница «Материалы»

export function MaterialsPage() {
  const me = useStore((s) => s.me)!;
  const [sp, setSp] = useSearchParams();
  const folder = +(sp.get('folder') || 0), page = +(sp.get('page') || 1), q = sp.get('q') || '', tag = sp.get('tag') || '';
  const [vw, setVw] = usePersist<'list' | 'cards'>('learn:m:view', 'list');
  const [order, setOrder] = usePersist<'manual' | 'new' | 'title'>('learn:m:order', 'manual');
  const { tree, loading: treeLoading } = useTree('materials');
  const cur = folder ? tree.byId.get(folder) : undefined;
  useTitle(cur ? cur.name : 'Материалы');
  const level = cur?.level ?? 0;
  const canManage = level >= 3;

  const [qIn, setQIn] = useState(q);
  const dq = useDebounced(qIn, 250);
  useEffect(() => { if (dq.trim() !== q) setSp({ q: dq.trim() || null, page: null }); }, [dq]);
  useEffect(() => { if (q !== qIn.trim()) setQIn(q); }, [q]);

  const searching = q.length > 0;
  const key = searching ? `learn:m:search:${q}:${page}` : folder ? `learn:m:list:${folder}:${page}:${order}:${tag}` : null;
  const url = searching ? `${L}/materials?q=${encodeURIComponent(q)}&page=${page}` : `${L}/materials?folder=${folder}&page=${page}&order=${order}${tag ? '&tag=' + encodeURIComponent(tag) : ''}`;
  const { data, error, refetch, loading } = useQuery<ListData>(key, () => api.get(url), { stale: 15000, keepPrevious: true });
  const recent = useQuery<any[]>(!folder && !searching ? 'learn:m:recent' : null, () => api.get(`${L}/materials/recent`), { stale: 10000 });

  const [editor, setEditor] = useState<null | { id?: number }>(null);
  const [sel, setSel] = useState<Set<number>>(new Set());
  const [moving, setMoving] = useState<number[] | null>(null);
  const [uploads, setUploads] = useState<{ key: number; name: string; p: number; err?: string }[]>([]);
  const [over, setOver] = useState(false);
  const [confirm, confirmNode] = useConfirm();
  const inp = useRef<HTMLInputElement>(null);
  useEffect(() => setSel(new Set()), [folder, q, page]);

  const toggleDone = useCallback(async (it: Item) => {
    const done = !it.done;
    const patch = (d?: ListData) => d && { ...d, items: d.items.map((x) => (x.id === it.id ? { ...x, done } : x)) };
    updateQueries('learn:m:list:', patch as any); updateQueries('learn:m:search:', patch as any);
    setQueryData('learn:tree:materials', (t: any) => t && { ...t, done: { ...t.done, [it.folder_id]: Math.max(0, (t.done?.[it.folder_id] || 0) + (done ? 1 : -1)) } });
    try { await api.post(`${L}/items/${it.id}/done`, { done }); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); invalidate('learn:'); }
  }, []);

  async function moveDropped(to: number, ids: number[]) {
    try { await api.post(`${L}/items/move`, { ids, folder_id: to }); refreshLearning(); setSel(new Set()); toast({ title: `Перенесено: ${plural(ids.length, ['материал', 'материала', 'материалов'])}`, kind: 'success' }); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }

  const upload = useCallback(async (list: File[]) => {
    if (!folder) return toast({ title: 'Откройте папку, чтобы загрузить файлы', kind: 'error' });
    const jobs = list.map((f, i) => ({ f, key: Date.now() + i }));
    setUploads((u) => [...u, ...jobs.map((j) => ({ key: j.key, name: j.f.name, p: 0 }))]);
    let next = 0;
    const worker = async () => {
      while (next < jobs.length) {
        const j = jobs[next++];
        try {
          await api.upload(`${L}/folders/${folder}/bulk`, j.f, (p) => setUploads((u) => u.map((x) => (x.key === j.key ? { ...x, p } : x))));
          setUploads((u) => u.filter((x) => x.key !== j.key));
        } catch (e) { setUploads((u) => u.map((x) => (x.key === j.key ? { ...x, err: errMsg(e) } : x))); }
      }
    };
    await Promise.all([worker(), worker(), worker()]);
    refreshLearning();
  }, [folder]);

  async function removeSelected() {
    const ids = [...sel];
    if (!(await confirm(`Удалить материалы (${ids.length})?`, { text: 'Вместе с вложенными файлами. Действие необратимо.', ok: 'Удалить' }))) return;
    try { for (const id of ids) await api.del(`${L}/items/${id}`); toast({ title: 'Удалено', kind: 'success' }); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setSel(new Set()); refreshLearning();
  }

  const items = data?.items || [];
  const total = data?.total;
  const pages = total != null ? Math.ceil(total / (data?.per || 30)) : data?.has_more ? page + 1 : page;
  const dragStart = (e: React.DragEvent, it: Item) => {
    if (!canManage && !searching) return;
    const ids = sel.has(it.id) ? [...sel] : [it.id];
    e.dataTransfer.setData('application/x-learn-items', JSON.stringify(ids));
    e.dataTransfer.effectAllowed = 'move';
  };
  const folderName = (id: number) => tree.byId.get(id)?.name;

  return (
    <FolderShell kind="materials" tree={tree} loading={treeLoading} folder={folder} onDropItems={moveDropped}>
      {!searching && <WikiShelf folder={folder} />}
      <div className="lnBar">
        <div className="lnSearch"><I.Search size={17} /><input value={qIn} placeholder="Поиск материалов по названию…" onChange={(e) => setQIn(e.target.value)} aria-label="Поиск" />{qIn && <button onClick={() => { setQIn(''); setSp({ q: null, page: null }); }} aria-label="Сбросить"><I.X size={15} /></button>}</div>
        {!searching && folder > 0 && (
          <Select className="lnOrder" value={order} onChange={(e) => { setOrder(e.target.value as any); setSp({ page: null }); }} aria-label="Сортировка">
            <option value="manual">По порядку</option><option value="new">Сначала новые</option><option value="title">По названию</option>
          </Select>
        )}
        <div className="viewSw" role="group" aria-label="Вид">
          <button className={cx(vw === 'cards' && 'on')} onClick={() => setVw('cards')} title="Карточки" aria-label="Карточки"><I.Dashboard size={17} /></button>
          <button className={cx(vw === 'list' && 'on')} onClick={() => setVw('list')} title="Список" aria-label="Список"><I.List size={17} /></button>
        </div>
        {!searching && <WikiNewSpace folder={folder} canCreate={folder ? canManage : me.role !== 'user'} />}
        {canManage && !searching && (
          <>
            <Btn onClick={() => inp.current?.click()}><I.Upload size={16} /> Загрузить файлы</Btn>
            <Btn kind="pri" onClick={() => setEditor({})}><I.Plus size={16} /> Материал</Btn>
            <input ref={inp} type="file" hidden multiple onChange={(e) => { upload(Array.from(e.target.files || [])); e.target.value = ''; }} />
          </>
        )}
      </div>

      {tag && <div className="rowW"><Badge kind="accent"><I.Tag size={11} /> {tag}</Badge><button className="btn ghost sm" onClick={() => setSp({ tag: null, page: null })}>Сбросить тег</button></div>}
      {folder > 0 && !searching && cur && cur.count > 0 && <ProgressLine done={tree.done[folder] || 0} total={cur.count} />}

      {uploads.length > 0 && (
        <div className="card padS stackS">
          {uploads.map((u) => (
            <div key={u.key} className="stackS">
              <div className="row small"><span className="sp clip">{u.name}</span>{u.err ? <span style={{ color: 'var(--danger)' }}>{u.err}</span> : <span>{Math.round(u.p * 100)}%</span>}</div>
              {!u.err && <div className="prog"><i style={{ width: u.p * 100 + '%' }} /></div>}
            </div>
          ))}
          {uploads.some((u) => u.err) && <Btn size="sm" onClick={() => setUploads((u) => u.filter((x) => !x.err))}>Скрыть ошибки</Btn>}
        </div>
      )}

      {sel.size > 0 && (
        <div className="lnSelBar card">
          <b>Выбрано: {sel.size}</b><div className="sp" />
          <Btn size="sm" onClick={() => setMoving([...sel])}><I.Folder size={15} /> Переместить</Btn>
          <Btn size="sm" kind="dng" onClick={removeSelected}><I.Trash size={15} /> Удалить</Btn>
          <Btn size="sm" kind="ghost" onClick={() => setSel(new Set())}>Снять выбор</Btn>
        </div>
      )}

      <div
        className={cx('lnDrop', over && 'over')}
        onDragOver={(e) => { if (canManage && !searching && e.dataTransfer.types.includes('Files')) { e.preventDefault(); setOver(true); } }}
        onDragLeave={(e) => { if (e.currentTarget === e.target) setOver(false); }}
        onDrop={(e) => { if (e.dataTransfer.files.length) { e.preventDefault(); setOver(false); if (canManage) upload(Array.from(e.dataTransfer.files)); } }}
      >
        {over && <div className="lnDropMsg"><I.Upload size={22} /> Отпустите файлы — каждый станет материалом в этой папке</div>}
        {!folder && !searching ? (
          <Home recent={recent.data} tree={tree} loading={recent.loading} />
        ) : error && !data ? <ErrorBox error={error} retry={refetch} /> : !data ? <ListSkeleton /> : items.length === 0 ? (
          <div className="card"><Empty icon={I.Book} title={searching ? 'Ничего не найдено' : 'В этой папке пока нет материалов'}>
            {searching ? 'Попробуйте изменить запрос' : canManage ? 'Добавьте материал кнопкой выше или перетащите сюда файлы' : 'Материалы появятся здесь, когда их добавят'}
          </Empty></div>
        ) : vw === 'list' ? (
          <div className="card lnList">
            {items.map((it) => (
              <div key={it.id} className={cx('lnRow', sel.has(it.id) && 'sel')} draggable={canManage} onDragStart={(e) => dragStart(e, it)}>
                {canManage && <input type="checkbox" className="lnChk" checked={sel.has(it.id)} onChange={() => setSel((s) => { const n = new Set(s); n.has(it.id) ? n.delete(it.id) : n.add(it.id); return n; })} aria-label="Выбрать" />}
                <Link to={`/learning/materials/item/${it.id}`} className="lnRowMain">
                  <ItemIcon it={it} />
                  <span className="sp" style={{ minWidth: 0 }}>
                    <span className="bold clip" style={{ display: 'block' }}>{it.title}</span>
                    {it.description && <span className="small muted clip" style={{ display: 'block' }}>{it.description}</span>}
                    <span className="lnMeta">
                      <span>{KIND_LABEL[it.kind]}</span>
                      {it.files_count > 0 && <span>{plural(it.files_count, ['файл', 'файла', 'файлов'])}</span>}
                      <span><I.Eye size={12} /> {it.views_count}</span>
                      {searching && <span><I.Folder size={12} /> {folderName(it.folder_id) || '…'}</span>}
                      {it.tags.slice(0, 4).map((t) => <span key={t} className="lnTag">#{t}</span>)}
                    </span>
                  </span>
                </Link>
                <button className={cx('lnDone', it.done && 'on')} onClick={() => toggleDone(it)} title={it.done ? 'Изучено — снять отметку' : 'Отметить изученным'} aria-label="Изучено" aria-pressed={it.done}><I.Check size={16} /></button>
              </div>
            ))}
          </div>
        ) : (
          <div className="lnCards">
            {items.map((it) => {
              const img = it.first_file && it.first_file.mime.startsWith('image/');
              return (
                <div key={it.id} className={cx('card lnCard', sel.has(it.id) && 'sel')} draggable={canManage} onDragStart={(e) => dragStart(e, it)}>
                  <Link to={`/learning/materials/item/${it.id}`} className="lnCardPv" style={img ? { backgroundImage: `url(${thumb('/files/' + it.first_file!.id)})` } : undefined}>
                    {!img && <ItemIcon it={it} />}
                  </Link>
                  <div className="lnCardBd">
                    <Link to={`/learning/materials/item/${it.id}`} className="bold clamp2">{it.title}</Link>
                    {it.description && <div className="small muted clamp2">{it.description}</div>}
                    <div className="lnMeta"><span>{KIND_LABEL[it.kind]}</span><span><I.Eye size={12} /> {it.views_count}</span>{searching && <span>{folderName(it.folder_id)}</span>}</div>
                  </div>
                  <div className="lnCardFt">
                    {canManage && <input type="checkbox" className="lnChk" checked={sel.has(it.id)} onChange={() => setSel((s) => { const n = new Set(s); n.has(it.id) ? n.delete(it.id) : n.add(it.id); return n; })} aria-label="Выбрать" />}
                    <span className="sp" />
                    <button className={cx('lnDone', it.done && 'on')} onClick={() => toggleDone(it)} title="Изучено" aria-label="Изучено" aria-pressed={it.done}><I.Check size={16} /></button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
      {data && pages > 1 && <Pager page={page} total={0} per={0} pages={pages} onChange={(p) => setSp({ page: p > 1 ? p : null }, false)} href={(p) => { const u = new URLSearchParams(location.search); p > 1 ? u.set('page', String(p)) : u.delete('page'); return location.pathname + (u.toString() ? '?' + u : ''); }} />}
      {editor && <ItemEditor folder={folder} id={editor.id} onClose={() => setEditor(null)} onSaved={() => { setEditor(null); refreshLearning(); }} />}
      {moving && <MoveItemsModal kind="materials" tree={tree} ids={moving} onClose={() => setMoving(null)} onDone={() => { setMoving(null); setSel(new Set()); }} />}
      {confirmNode}
    </FolderShell>
  );
}

function ProgressLine({ done, total }: { done: number; total: number }) {
  const p = Math.min(100, Math.round((done / total) * 100));
  return (
    <div className="lnProg">
      <span className="small muted">Изучено {done} из {total}</span>
      <div className="prog sp"><i style={{ width: p + '%', background: p === 100 ? 'var(--ok)' : undefined }} /></div>
      <b className="small">{p}%</b>
    </div>
  );
}

function Home({ recent, tree, loading }: { recent?: any[]; tree: Tree; loading: boolean }) {
  const totalDone = Object.values(tree.done).reduce((a, b) => a + b, 0);
  const totalAll = (tree.kids.get(null) || []).reduce((a, f) => a + (tree.total.get(f.id) || 0), 0);
  return (
    <div className="stack">
      {totalAll > 0 && <div className="card padS"><ProgressLine done={Math.min(totalDone, totalAll)} total={totalAll} /></div>}
      <div className="stackS">
        <h3 className="lnH3">Недавно открытые</h3>
        {loading && !recent ? <ListSkeleton rows={3} /> : !recent?.length ? (
          <div className="card"><Empty icon={I.Book} title="Пока ничего не открывали">Выберите папку слева, чтобы начать обучение</Empty></div>
        ) : (
          <div className="card lnList">
            {recent.map((r) => {
              const Ic = KIND_ICON[r.kind as keyof typeof KIND_ICON] || I.File;
              return (
                <Link key={r.id} to={`/learning/materials/item/${r.id}`} className="lnRow lnRowMain">
                  <div className="fico text"><Ic size={20} /></div>
                  <span className="sp" style={{ minWidth: 0 }}><span className="bold clip" style={{ display: 'block' }}>{r.title}</span><span className="tiny muted">{tree.byId.get(r.folder_id)?.name} · {dtShort(r.opened_at)}</span></span>
                  {r.done && <Badge kind="ok"><I.Check size={11} /> Изучено</Badge>}
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- просмотр материала

interface FileRef { id: number; name: string; mime: string; size: number; has_thumb?: boolean }

function VideoLink({ url }: { url: string }) {
  let host = url;
  try { host = new URL(url).hostname.replace(/^www\./, ''); } catch {}
  const direct = /\.(mp4|webm|ogg)(\?|#|$)/i.test(url);
  return direct ? (
    <video className="lnVideo" controls preload="metadata" src={url} />
  ) : (
    <div className="card lnLinkCard">
      <div className="fico video"><I.Play size={22} /></div>
      <div className="sp" style={{ minWidth: 0 }}><div className="bold">Видео на внешнем сайте</div><div className="small muted clip">{host}</div></div>
      <a className="btn pri" href={url} target="_blank" rel="noopener noreferrer"><I.External size={16} /> Открыть видео</a>
    </div>
  );
}

function PdfBlock({ f, open: initial }: { f: FileRef; open: boolean }) {
  const [open, setOpen] = useState(initial);
  return (
    <div className="card lnPdf">
      <div className="lnPdfHd">
        <FileIcon name={f.name} mime={f.mime} /><div className="sp clip bold">{f.name}<span className="tiny muted"> · {fmtSize(f.size)}</span></div>
        <Btn size="sm" onClick={() => setOpen(!open)}>{open ? 'Свернуть' : 'Показать'}</Btn>
        <a className="btn sm" href={`/files/${f.id}`} target="_blank" rel="noopener noreferrer"><I.External size={15} /> Открыть</a>
        <a className="btn sm" href={`/files/${f.id}?dl=1`}><I.Download size={15} /> Скачать</a>
      </div>
      {open && <PdfViewer src={`/files/${f.id}`} name={f.name} fileKey={f.id} downloadHref={`/files/${f.id}?dl=1`} className="inline" autoFocus={false} />}
    </div>
  );
}

export function ItemPage({ id }: { id: number }) {
  const me = useStore((s) => s.me)!;
  const { tree } = useTree('materials');
  const { data, error, refetch } = useQuery<any>(`learn:m:item:${id}`, () => api.get(`${L}/items/${id}`), { stale: 5000 });
  useTitle(data?.title || 'Материал');
  const [light, setLight] = useState<number | null>(null);
  const [edit, setEdit] = useState(false);
  const [confirm, confirmNode] = useConfirm();
  useEffect(() => { invalidate('learn:m:recent'); }, [id]);
  // горячие клавиши: ← → между материалами папки
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.closest('input,textarea,select,.modal,.lightbox') || e.altKey || e.ctrlKey || e.metaKey) return;
      if (e.key === 'ArrowRight' && data?.next) navigate(`/learning/materials/item/${data.next.id}`);
      if (e.key === 'ArrowLeft' && data?.prev) navigate(`/learning/materials/item/${data.prev.id}`);
    };
    addEventListener('keydown', k);
    return () => removeEventListener('keydown', k);
  }, [data]);
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data) return <div className="card pad stack"><Skel h={28} w="50%" /><Skel h={16} /><Skel h={16} w="80%" /><Skel h={240} /></div>;

  const canManage = data.level >= 3;
  const files: FileRef[] = data.files || [];
  const images = files.filter((f) => f.mime.startsWith('image/'));
  const pdfs = files.filter((f) => f.mime === 'application/pdf');
  const videos = files.filter((f) => f.mime.startsWith('video/'));
  const audios = files.filter((f) => f.mime.startsWith('audio/'));
  const others = files.filter((f) => !images.includes(f) && !pdfs.includes(f) && !videos.includes(f) && !audios.includes(f));
  const done = !!data.done_at;

  async function toggle() {
    const nd = !done;
    setQueryData(`learn:m:item:${id}`, (d: any) => ({ ...d, done_at: nd ? new Date().toISOString() : null }));
    setQueryData('learn:tree:materials', (t: any) => t && { ...t, done: { ...t.done, [data.folder_id]: Math.max(0, (t.done?.[data.folder_id] || 0) + (nd ? 1 : -1)) } });
    invalidate('learn:m:list:'); invalidate('learn:m:search:');
    try { await api.post(`${L}/items/${id}/done`, { done: nd }); if (nd && data.next) toast({ title: 'Отмечено как изученное', kind: 'success' }); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); refetch(); }
  }
  async function remove() {
    if (!(await confirm('Удалить материал?', { text: 'Вместе с вложенными файлами. Действие необратимо.', ok: 'Удалить' }))) return;
    try { await api.del(`${L}/items/${id}`); refreshLearning(); toast({ title: 'Материал удалён', kind: 'success' }); navigate(`/learning/materials?folder=${data.folder_id}`); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }

  return (
    <div className="stack lnItemPage">
      <CourseStepBar />
      <div className="lnHead">
        <div className="sp" style={{ minWidth: 0 }}>
          <Crumbs kind="materials" tree={tree} folder={data.folder_id} tail={data.title} />
        </div>
        <div className="rowW">
          <Btn onClick={() => navigate(`/learning/materials?folder=${data.folder_id}`)}><I.ArrowLeft size={16} /> К папке</Btn>
          {canManage && <Btn onClick={() => setEdit(true)}><I.Edit size={16} /> Изменить</Btn>}
          {canManage && <Btn kind="dng" icon onClick={remove} aria-label="Удалить"><I.Trash size={16} /></Btn>}
        </div>
      </div>
      <article className="card lnArticle">
        <header className="stackS">
          <h1 className="lnItemTitle">{data.title}</h1>
          <div className="lnMeta">
            <span>{KIND_LABEL[data.kind as keyof typeof KIND_LABEL]}</span>
            <span><I.Eye size={12} /> {data.views_count} {plural(data.views_count, ['просмотр', 'просмотра', 'просмотров']).replace(/^\d+ /, '')}</span>
            {data.author && <span>{data.author}</span>}
            <span>{dtShort(data.updated_at)}</span>
            {data.tags.map((t: string) => <Link key={t} className="lnTag" to={`/learning/materials?folder=${data.folder_id}&tag=${encodeURIComponent(t)}`}>#{t}</Link>)}
          </div>
          {data.description && <p className="muted">{data.description}</p>}
        </header>
        {data.body && <Markdown text={data.body} />}
        {data.url && (data.kind === 'video' ? <VideoLink url={data.url} /> : (
          <a className="card lnLinkCard" href={data.url} target="_blank" rel="noopener noreferrer">
            <div className="fico zip"><I.Link size={20} /></div><div className="sp clip"><div className="bold">Открыть ссылку</div><div className="small muted clip">{data.url}</div></div><I.External size={18} className="muted" />
          </a>
        ))}
        {videos.map((f) => <video key={f.id} className="lnVideo" controls preload="metadata" src={`/files/${f.id}`} aria-label={f.name} />)}
        {audios.map((f) => <audio key={f.id} controls preload="metadata" src={`/files/${f.id}`} style={{ width: '100%' }} aria-label={f.name} />)}
        {pdfs.map((f, i) => <PdfBlock key={f.id} f={f} open={i === 0} />)}
        {images.length > 0 && (
          <div className="lnGallery">
            {images.map((f, i) => (
              <button key={f.id} className="lnImg" onClick={() => setLight(i)} aria-label={f.name}><img src={thumb(`/files/${f.id}`)} alt={f.name} loading="lazy" onError={(e) => { (e.target as HTMLImageElement).src = `/files/${f.id}`; }} /></button>
            ))}
          </div>
        )}
        {others.length > 0 && <div className="stackS">{others.map((f) => <FileLink key={f.id} f={f} />)}</div>}
        {files.length > 0 && (videos.length > 0 || images.length > 0 || pdfs.length > 0) && (
          <div className="rowW small muted">Скачать: {files.map((f) => <a key={f.id} className="lnTag" href={`/files/${f.id}?dl=1`}>{f.name}</a>)}</div>
        )}
      </article>
      <div className="lnNav card padS">
        {data.prev ? <Link to={`/learning/materials/item/${data.prev.id}`} className="lnNavL" title="←"><I.ChevronLeft size={18} /><span className="clip">{data.prev.title}</span></Link> : <span className="sp" />}
        <button className={cx('btn lg', done ? '' : 'pri')} onClick={toggle} aria-pressed={done}>
          <I.Check size={18} /> {done ? 'Изучено' : 'Отметить изученным'}
        </button>
        {data.next ? <Link to={`/learning/materials/item/${data.next.id}`} className="lnNavR" title="→"><span className="clip">{data.next.title}</span><I.ChevronRight size={18} /></Link> : <span className="sp" />}
      </div>
      {light !== null && <Lightbox items={images.map((f) => ({ src: viewUrl(`/files/${f.id}`), name: f.name }))} start={light} onClose={() => setLight(null)} />}
      {edit && <ItemEditor folder={data.folder_id} id={id} onClose={() => setEdit(false)} onSaved={() => { setEdit(false); refreshLearning(); }} />}
      {confirmNode}
    </div>
  );
}

// ---------------------------------------------------------------- редактор материала

export function ItemEditor({ folder, id, onClose, onSaved }: { folder: number; id?: number; onClose: () => void; onSaved: () => void }) {
  const ex = useQuery<any>(id ? `learn:m:item:${id}` : null, () => api.get(`${L}/items/${id}`), { stale: 0 });
  const [kind, setKind] = useState<'text' | 'file' | 'video' | 'link'>('text');
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [body, setBody] = useState('');
  const [url, setUrl] = useState('');
  const [tags, setTags] = useState('');
  const [sort, setSort] = useState('0');
  const [files, setFiles] = useState<FileRef[]>([]);
  const [prog, setProg] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [loaded, setLoaded] = useState(!id);
  const fin = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (id && ex.data && !loaded) {
      const d = ex.data;
      setKind(d.kind); setTitle(d.title); setDesc(d.description); setBody(d.body); setUrl(d.url); setTags(d.tags.join(', ')); setSort(String(d.sort)); setFiles(d.files); setLoaded(true);
    }
  }, [ex.data]);

  async function addFiles(list: File[]) {
    if (!list.length) return;
    setProg(0); setErr('');
    try {
      const r = await api.upload<FileRef[]>(`${L}/files?folder=${folder}`, list, (p) => setProg(p));
      setFiles((f) => [...f, ...r]);
      if (!title.trim() && r.length === 1) setTitle(r[0].name.replace(/\.[^.]+$/, ''));
    } catch (e) { setErr(errMsg(e)); }
    setProg(null);
  }
  const move = (i: number, d: number) => setFiles((f) => { const n = [...f]; const j = i + d; if (j < 0 || j >= n.length) return f; [n[i], n[j]] = [n[j], n[i]]; return n; });

  async function save() {
    if (!title.trim()) return setErr('Введите название материала');
    setBusy(true); setErr('');
    const payload = { folder_id: folder, kind, title, description: desc, body, url: kind === 'video' || kind === 'link' ? url : '', tags: tags.split(/[,;]+/).map((t) => t.trim()).filter(Boolean), sort: +sort || 0, file_ids: files.map((f) => f.id) };
    try { id ? await api.put(`${L}/items/${id}`, payload) : await api.post(`${L}/items`, payload); toast({ title: id ? 'Материал сохранён' : 'Материал добавлен', kind: 'success' }); onSaved(); }
    catch (e) { setErr(errMsg(e)); setBusy(false); }
  }

  return (
    <Modal title={id ? 'Редактирование материала' : 'Новый материал'} size="lg" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} onClick={save}>Сохранить</Btn></>}>
      {!loaded ? <Loading /> : (
        <div className="stack">
          <div className="chips" role="radiogroup" aria-label="Тип материала">
            {(['text', 'file', 'video', 'link'] as const).map((k) => {
              const Ic = KIND_ICON[k];
              return <button key={k} type="button" role="radio" aria-checked={kind === k} className={cx('chip', kind === k && 'on')} onClick={() => setKind(k)}><Ic size={15} /> {KIND_LABEL[k]}</button>;
            })}
          </div>
          <Field label="Название"><Input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={300} autoFocus={!id} /></Field>
          <Field label="Краткое описание (необязательно)"><Input value={desc} onChange={(e) => setDesc(e.target.value)} maxLength={500} /></Field>
          {(kind === 'video' || kind === 'link') && (
            <Field label={kind === 'video' ? 'Ссылка на видео (YouTube, RuTube, файл .mp4…) — или загрузите файл ниже' : 'Ссылка'} hint="Адрес должен начинаться с https://">
              <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://" inputMode="url" />
            </Field>
          )}
          {(kind === 'text' || kind === 'file' || kind === 'video') && (
            <Field label={kind === 'text' ? 'Текст материала (Markdown)' : 'Пояснение к материалу (Markdown, необязательно)'}>
              <MdEditor value={body} onChange={setBody} rows={kind === 'text' ? 14 : 5} />
            </Field>
          )}
          <div className="stackS">
            <div className="lbl">Вложения: PDF, документы, изображения, видео</div>
            {files.map((f, i) => (
              <div key={f.id} className="row lnAttach">
                <FileIcon name={f.name} mime={f.mime} /><div className="sp clip">{f.name}<span className="tiny muted"> · {fmtSize(f.size)}</span></div>
                <Btn size="sm" kind="ghost" icon onClick={() => move(i, -1)} disabled={i === 0} aria-label="Выше"><I.ChevronUp size={15} /></Btn>
                <Btn size="sm" kind="ghost" icon onClick={() => move(i, 1)} disabled={i === files.length - 1} aria-label="Ниже"><I.ChevronDown size={15} /></Btn>
                <Btn size="sm" kind="ghost" icon onClick={() => setFiles(files.filter((x) => x.id !== f.id))} aria-label="Убрать"><I.X size={15} /></Btn>
              </div>
            ))}
            <div className="dropzone" style={{ padding: 14 }} onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); addFiles(Array.from(e.dataTransfer.files)); }}>
              {prog !== null ? <div className="stackS"><div className="small">Загрузка… {Math.round(prog * 100)}%</div><div className="prog"><i style={{ width: prog * 100 + '%' }} /></div></div> : (
                <><Btn size="sm" onClick={() => fin.current?.click()}><I.Upload size={15} /> Выбрать файлы</Btn> <span className="small">или перетащите сюда</span></>
              )}
              <input ref={fin} type="file" multiple hidden onChange={(e) => { addFiles(Array.from(e.target.files || [])); e.target.value = ''; }} />
            </div>
          </div>
          <div className="formGrid" style={{ display: 'grid', gridTemplateColumns: '1fr 140px', gap: 12 }}>
            <Field label="Теги через запятую"><Input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="онбординг, безопасность" /></Field>
            <Field label="Порядок" hint="Меньше — выше"><Input type="number" value={sort} onChange={(e) => setSort(e.target.value)} /></Field>
          </div>
          {err && <div className="err">{err}</div>}
        </div>
      )}
    </Modal>
  );
}
