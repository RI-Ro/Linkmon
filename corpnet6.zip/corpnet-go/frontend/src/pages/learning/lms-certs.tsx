// LMS: сертификаты — мои, реестр (для ответственного), шаблоны, просмотр/печать, публичная проверка.
import React, { useEffect, useMemo, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { invalidate, useQuery } from '../../lib/query';
import { Link, navigate, useSearchParams, useTitle } from '../../lib/router';
import { toast, useStore } from '../../lib/store';
import { copyText, cx, useDebounced } from '../../lib/util';
import { Badge, Btn, Empty, ErrorBox, Field, ImageUpload, Input, Modal, Pager, Select, Skel, Textarea, useConfirm } from '../../ui';
import { DeptSelect } from '../../ui/DeptSelect';
import { L } from './common';
import { csvHref, dmy, isLmsManager, score1, useCertTemplates, useStatsMe } from './lms-common';
import { qrMatrix, qrPath } from './lms-qr';

const STATE: Record<string, { label: string; kind: 'ok' | 'warn' | 'dng' }> = { valid: { label: 'Действителен', kind: 'ok' }, expired: { label: 'Срок истёк', kind: 'warn' }, revoked: { label: 'Отозван', kind: 'dng' } };
export const StateBadge = ({ state, soon }: { state: string; soon?: boolean }) => (soon && state === 'valid' ? <Badge kind="warn">Скоро истекает</Badge> : <Badge kind={STATE[state]?.kind}>{STATE[state]?.label || state}</Badge>);

export const verifyUrl = (code: string) => `${location.origin}/verify/${code}`;

// ---------------------------------------------------------------- бланк сертификата

export interface Look {
  title: string; body: string; color: string; border: string; logo?: string; signer_name?: string; signer_title?: string; user_name?: string; course?: string; date?: string; score?: string; valid_until?: string;
}

export function Qr({ text, size = 96 }: { text: string; size?: number }) {
  const m = useMemo(() => qrMatrix(text), [text]);
  if (!m) return null;
  const n = m.length + 4;
  return (
    <svg width={size} height={size} viewBox={`-2 -2 ${n} ${n}`} role="img" aria-label="QR-код проверки сертификата" shapeRendering="crispEdges">
      <rect x="-2" y="-2" width={n} height={n} fill="#fff" />
      <path d={qrPath(m)} fill="#111" />
    </svg>
  );
}

function highlight(body: string, name?: string) {
  if (!name || !body.includes(name)) return body;
  const parts = body.split(name);
  return parts.flatMap((p, i) => (i < parts.length - 1 ? [p, <b key={i} className="lmCertName">{name}</b>] : [p]));
}

export function CertSheet({ look, number, code, state }: { look: Look; number: string; code: string; state?: string }) {
  return (
    <div className="lmCertWrap">
      <div className={cx('lmCertSheet', 'b-' + (look.border || 'double'))} style={{ ['--cc' as any]: look.color || '#1f5fa8' }}>
        <div className="lmCertIn">
          {look.logo && <img className="lmCertLogo" src={look.logo} alt="" />}
          <div className="lmCertTitle">{look.title}</div>
          <div className="lmCertRule" />
          <div className="lmCertBody">{highlight(look.body, look.user_name)}</div>
          <div className="lmCertFt">
            <div className="lmCertMeta">
              <div><span>Номер</span><b>{number}</b></div>
              {look.date && <div><span>Дата выдачи</span><b>{look.date}</b></div>}
              {look.valid_until && <div><span>Действителен до</span><b>{look.valid_until}</b></div>}
            </div>
            <div className="lmCertSign">
              {(look.signer_name || look.signer_title) && <><div className="lmCertLine" /><b>{look.signer_name}</b><span>{look.signer_title}</span></>}
            </div>
            <div className="lmCertQr">
              <Qr text={verifyUrl(code)} size={92} />
              <span>Проверка: {code}</span>
            </div>
          </div>
        </div>
        {state === 'revoked' && <div className="lmCertStamp">Отозван</div>}
        {state === 'expired' && <div className="lmCertStamp warn">Срок истёк</div>}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- один сертификат

export function CertificatePage({ id }: { id: number }) {
  const me = useStore((s) => s.me)!;
  const { data, error, refetch } = useQuery<any>(`learn:cert:${id}`, () => api.get(`${L}/certificates/${id}`), { stale: 0 });
  const [rev, setRev] = useState(false);
  const [busy, setBusy] = useState(false);
  useTitle(data ? `Сертификат ${data.number}` : 'Сертификат');
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data) return <div className="card pad stack"><Skel h={26} w="40%" /><Skel h={360} /></div>;
  const own = data.user_id === me.id;
  const mgr = isLmsManager(me as any);
  async function restore() {
    setBusy(true);
    try { await api.post(`${L}/certificates/${id}/restore`); invalidate('learn:cert'); refetch(); toast({ title: 'Сертификат восстановлен', kind: 'success' }); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  return (
    <div className="stack lmCertPage">
      <div className="lnHead lmNoPrint">
        <div className="sp">
          <div className="crumbs"><Link to="/learning/certificates">Сертификаты</Link><I.ChevronRight size={14} /><b style={{ color: 'var(--text)' }}>{data.number}</b></div>
          <h2 className="lnTitle">{data.title} <StateBadge state={data.state} /></h2>
          <div className="muted small">{data.user_name} · выдан {dmy(data.issued_at)}{data.expires_at ? ` · действует до ${dmy(data.expires_at)}` : ' · бессрочный'}{data.score != null && ` · результат ${score1(data.score)}`}</div>
        </div>
        <div className="rowW">
          <Btn kind="pri" onClick={() => window.print()}><I.Download size={16} /> Печать / PDF</Btn>
          <Btn onClick={() => { copyText(verifyUrl(data.code)); toast({ title: 'Ссылка для проверки скопирована', kind: 'success' }); }}><I.Link size={16} /> Ссылка проверки</Btn>
          {data.course_id && <Link className="btn" to={`/learning/courses/${data.course_id}`}>К курсу</Link>}
          {mgr && !own && data.state !== 'revoked' && <Btn kind="dng" onClick={() => setRev(true)}>Отозвать</Btn>}
          {mgr && data.state === 'revoked' && <Btn busy={busy} onClick={restore}>Восстановить</Btn>}
        </div>
      </div>
      {data.state === 'revoked' && <div className="notice warn lmNoPrint"><I.Alert size={18} /> Сертификат отозван{data.revoke_reason ? `: ${data.revoke_reason}` : ''}. Публичная проверка покажет, что он недействителен.</div>}
      <CertSheet look={data.look} number={data.number} code={data.code} state={data.state} />
      <div className="small muted lmNoPrint">Для сохранения в PDF выберите в диалоге печати «Сохранить как PDF», ориентация — альбомная. Подлинность подтверждается по QR-коду или номеру на странице <a href={verifyUrl(data.code)} target="_blank" rel="noopener noreferrer">{verifyUrl(data.code)}</a>.</div>
      {rev && <RevokeModal id={id} onClose={() => setRev(false)} onDone={() => { setRev(false); invalidate('learn:cert'); refetch(); }} />}
    </div>
  );
}

function RevokeModal({ id, onClose, onDone }: { id: number; onClose: () => void; onDone: () => void }) {
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  async function go() {
    setBusy(true);
    try { await api.post(`${L}/certificates/${id}/revoke`, { reason }); toast({ title: 'Сертификат отозван', kind: 'success' }); onDone(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); setBusy(false); }
  }
  return (
    <Modal title="Отозвать сертификат" size="sm" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="dngF" busy={busy} onClick={go}>Отозвать</Btn></>}>
      <Field label="Причина (увидит сотрудник)"><Textarea rows={3} maxLength={500} value={reason} onChange={(e) => setReason(e.target.value)} autoFocus /></Field>
    </Modal>
  );
}

// ---------------------------------------------------------------- страница «Сертификаты»

export function CertificatesPage() {
  const me = useStore((s) => s.me)!;
  const sm = useStatsMe();
  const mgr = !!sm.data?.manager;
  const editor = me.role !== 'user';
  const [sp, setSp] = useSearchParams();
  const tab = sp.get('tab') === 'registry' && mgr ? 'registry' : sp.get('tab') === 'templates' && editor ? 'templates' : 'my';
  useTitle('Сертификаты');
  return (
    <div className="stack">
      {(mgr || editor) && (
        <div className="chips">
          <button className={cx('chip', tab === 'my' && 'on')} onClick={() => setSp({ tab: null, page: null })}>Мои сертификаты</button>
          {mgr && <button className={cx('chip', tab === 'registry' && 'on')} onClick={() => setSp({ tab: 'registry', page: null })}>Реестр</button>}
          {editor && <button className={cx('chip', tab === 'templates' && 'on')} onClick={() => setSp({ tab: 'templates', page: null })}>Шаблоны</button>}
        </div>
      )}
      {tab === 'my' ? <MyCerts /> : tab === 'registry' ? <Registry /> : <Templates />}
    </div>
  );
}

function MyCerts() {
  const { data, error, refetch } = useQuery<{ items: any[] }>('learn:certs:my', () => api.get(`${L}/certificates`), { stale: 10000 });
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data) return <div className="lmGrid">{[0, 1, 2].map((i) => <div key={i} className="card pad"><Skel h={80} /></div>)}</div>;
  if (!data.items.length) return <div className="card"><Empty icon={I.Star} title="Сертификатов пока нет">Они выдаются автоматически за прохождение курсов и тестов, для которых настроен сертификат<div style={{ marginTop: 12 }}><Link className="btn" to="/learning/courses">Каталог курсов</Link></div></Empty></div>;
  return (
    <div className="lmGrid">
      {data.items.map((c) => (
        <Link key={c.id} to={`/learning/certificates/${c.id}`} className={cx('card lmCertCard', c.state !== 'valid' && 'off')}>
          <div className="lmCertCardIc"><I.Star size={26} /></div>
          <div className="sp" style={{ minWidth: 0 }}>
            <div className="bold clamp2">{c.title}</div>
            <div className="tiny muted">№ {c.number}</div>
            <div className="tiny muted">выдан {dmy(c.issued_at)}{c.expires_at ? ` · до ${dmy(c.expires_at)}` : ' · бессрочный'}</div>
          </div>
          <StateBadge state={c.state} soon={c.soon} />
        </Link>
      ))}
    </div>
  );
}

function Registry() {
  const [sp, setSp] = useSearchParams();
  const page = +(sp.get('page') || 1), q = sp.get('q') || '', status = sp.get('status') || '', dept = +(sp.get('dept') || 0) || null, from = sp.get('from') || '', to = sp.get('to') || '';
  const [qIn, setQIn] = useState(q);
  const dq = useDebounced(qIn, 250);
  useEffect(() => { if (dq.trim() !== q) setSp({ q: dq.trim() || null, page: null, tab: 'registry' }); }, [dq]);
  const params = new URLSearchParams({ all: '1', page: String(page) });
  if (q) params.set('q', q); if (status) params.set('status', status); if (dept) params.set('dept', String(dept)); if (from) params.set('from', from); if (to) params.set('to', to);
  const { data, error, refetch } = useQuery<{ items: any[]; total: number; per: number }>(`learn:certs:reg:${params}`, () => api.get(`${L}/certificates?${params}`), { stale: 5000, keepPrevious: true });
  const [rev, setRev] = useState<number | null>(null);
  const exportHref = csvHref('certificates/export.csv', { q, status, dept, from, to });
  return (
    <div className="stack">
      <div className="lnBar">
        <div className="lnSearch"><I.Search size={17} /><input value={qIn} placeholder="Сотрудник, номер, курс…" onChange={(e) => setQIn(e.target.value)} aria-label="Поиск" /></div>
        <Select value={status} onChange={(e) => setSp({ status: e.target.value || null, page: null, tab: 'registry' })} aria-label="Статус"><option value="">Любой статус</option><option value="valid">Действительные</option><option value="soon">Скоро истекают</option><option value="expired">Истёкшие</option><option value="revoked">Отозванные</option></Select>
        <a className="btn" href={exportHref}><I.Download size={16} /> CSV</a>
      </div>
      <div className="rowW lmFilters">
        <div style={{ minWidth: 220 }}><DeptSelect value={dept} onChange={(v) => setSp({ dept: v, page: null, tab: 'registry' })} emptyLabel="Все подразделения" /></div>
        <label className="lmDate">выдан с <input type="date" className="inp" value={from} onChange={(e) => setSp({ from: e.target.value || null, page: null, tab: 'registry' })} /></label>
        <label className="lmDate">по <input type="date" className="inp" value={to} onChange={(e) => setSp({ to: e.target.value || null, page: null, tab: 'registry' })} /></label>
      </div>
      {error && !data ? <ErrorBox error={error} retry={refetch} /> : !data ? <Skel h={200} /> : !data.items.length ? <div className="card"><Empty icon={I.Star} title="Сертификатов не найдено" /></div> : (
        <div className="card tblW">
          <table className="tbl">
            <thead><tr><th>Номер</th><th>Сотрудник</th><th>Курс / тест</th><th>Выдан</th><th>Действует до</th><th>Балл</th><th>Статус</th><th /></tr></thead>
            <tbody>
              {data.items.map((c) => (
                <tr key={c.id}>
                  <td className="small mono"><Link to={`/learning/certificates/${c.id}`}>{c.number}</Link></td>
                  <td><b>{c.user_name}</b><div className="tiny muted">{c.department}</div></td>
                  <td className="small">{c.title}</td>
                  <td className="small">{dmy(c.issued_at)}</td>
                  <td className="small">{c.expires_at ? dmy(c.expires_at) : 'бессрочно'}</td>
                  <td className="small">{score1(c.score)}</td>
                  <td><StateBadge state={c.state} />{c.revoke_reason && <div className="tiny muted" title={c.revoke_reason}>{c.revoke_reason.slice(0, 40)}</div>}</td>
                  <td className="act">
                    <Link className="btn ghost sm" to={`/learning/certificates/${c.id}`}>Открыть</Link>
                    {c.state !== 'revoked' && <Btn size="sm" kind="ghost" onClick={() => setRev(c.id)}>Отозвать</Btn>}
                    {c.state === 'revoked' && <Btn size="sm" kind="ghost" onClick={async () => { try { await api.post(`${L}/certificates/${c.id}/restore`); refetch(); invalidate('learn:certs'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }}>Восстановить</Btn>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {data && data.total > data.per && <Pager page={page} total={data.total} per={data.per} onChange={(p) => setSp({ page: p > 1 ? p : null, tab: 'registry' }, false)} />}
      {rev && <RevokeModal id={rev} onClose={() => setRev(null)} onDone={() => { setRev(null); invalidate('learn:certs'); refetch(); }} />}
    </div>
  );
}

// ---------------------------------------------------------------- шаблоны

const TOKENS = ['{ФИО}', '{курс}', '{дата}', '{балл}', '{номер}', '{срок_действия}'];
const SAMPLE = { 'ФИО': 'Иванов Иван Иванович', 'курс': 'Название курса', 'дата': dmy(new Date().toISOString()), 'балл': '92,5%', 'номер': 'CN-2026-00001', 'срок_действия': dmy(new Date(Date.now() + 365 * 86400000).toISOString()) };

function Templates() {
  const { data, error, refetch } = useCertTemplates() as any;
  const [edit, setEdit] = useState<any | null>(null);
  const [confirm, node] = useConfirm();
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data) return <Skel h={120} />;
  async function del(t: any) {
    if (!(await confirm(`Удалить шаблон «${t.name}»?`, { text: t.used > 0 ? `Шаблон используется в курсах и тестах (${t.used}): сертификаты за них выдаваться перестанут. Уже выданные сохранятся.` : 'Выданные сертификаты сохранятся.', ok: 'Удалить' }))) return;
    try { await api.del(`${L}/cert-templates/${t.id}`); invalidate('learn:cert-tpl'); refetch(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  return (
    <div className="stack">
      <div className="row"><div className="sp muted small">Шаблон задаёт внешний вид сертификата, текст и маску номера. Подключается в настройках курса или теста.</div><Btn kind="pri" onClick={() => setEdit({})}><I.Plus size={16} /> Шаблон</Btn></div>
      {!data.length ? <div className="card"><Empty icon={I.Star} title="Шаблонов нет">Создайте шаблон, чтобы выдавать сертификаты за курсы и тесты</Empty></div> : (
        <div className="lmGrid">
          {data.map((t: any) => (
            <div key={t.id} className="card pad stackS">
              <div className="lmTplPv" style={{ ['--cc' as any]: t.color }}><span>{t.title}</span></div>
              <div className="bold">{t.name}</div>
              <div className="tiny muted">Номер: {t.number_mask} · выдано {t.counter} · используется: {t.used}</div>
              <div className="rowW"><Btn size="sm" onClick={() => setEdit(t)}><I.Edit size={14} /> Изменить</Btn><Btn size="sm" kind="ghost" onClick={() => del(t)}><I.Trash size={14} /></Btn></div>
            </div>
          ))}
        </div>
      )}
      {edit && <TemplateModal t={edit} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); invalidate('learn:cert-tpl'); refetch(); }} />}
      {node}
    </div>
  );
}

function TemplateModal({ t, onClose, onSaved }: { t: any; onClose: () => void; onSaved: () => void }) {
  const [f, setF] = useState({
    name: t.name || '', title: t.title || 'Сертификат', body: t.body || 'Настоящим подтверждается, что {ФИО} успешно прошёл(ла) обучение по программе «{курс}» {дата}. Результат: {балл}.',
    color: t.color || '#1f5fa8', border: t.border || 'double', logo: t.logo || '', signer_name: t.signer_name || '', signer_title: t.signer_title || '', number_mask: t.number_mask || 'CN-{YYYY}-{N:5}', expire_remind_days: String(t.expire_remind_days ?? 30),
  });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const set = (k: string, v: any) => setF((x) => ({ ...x, [k]: v }));
  const text = TOKENS.reduce((a, tk) => a.split(tk).join((SAMPLE as any)[tk.slice(1, -1)]), f.body);
  async function save() {
    setBusy(true); setErr('');
    try {
      const body = { ...f, expire_remind_days: +f.expire_remind_days || 0 };
      if (t.id) await api.put(`${L}/cert-templates/${t.id}`, body); else await api.post(`${L}/cert-templates`, body);
      onSaved();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title={t.id ? 'Шаблон сертификата' : 'Новый шаблон'} size="lg" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} onClick={save}>Сохранить</Btn></>}>
      <div className="formGrid">
        <Field label="Название шаблона" hint="Для списка выбора"><Input value={f.name} maxLength={200} onChange={(e) => set('name', e.target.value)} autoFocus /></Field>
        <Field label="Заголовок на бланке"><Input value={f.title} maxLength={200} onChange={(e) => set('title', e.target.value)} /></Field>
        <Field label="Текст" className="full" hint="Подстановки: щёлкните, чтобы вставить">
          <Textarea rows={4} value={f.body} maxLength={3000} onChange={(e) => set('body', e.target.value)} />
          <div className="chips" style={{ marginTop: 6 }}>{TOKENS.map((tk) => <button key={tk} type="button" className="chip" onClick={() => set('body', f.body + (f.body.endsWith(' ') || !f.body ? '' : ' ') + tk)}>{tk}</button>)}</div>
        </Field>
        <Field label="Цвет"><input type="color" className="lmColor" value={f.color} onChange={(e) => set('color', e.target.value)} aria-label="Цвет" /></Field>
        <Field label="Рамка"><Select value={f.border} onChange={(e) => set('border', e.target.value)}><option value="none">Без рамки</option><option value="simple">Простая</option><option value="double">Двойная</option><option value="ornate">Узорная</option></Select></Field>
        <Field label="Подписант"><Input value={f.signer_name} maxLength={200} onChange={(e) => set('signer_name', e.target.value)} placeholder="Фамилия И. О." /></Field>
        <Field label="Должность подписанта"><Input value={f.signer_title} maxLength={200} onChange={(e) => set('signer_title', e.target.value)} /></Field>
        <Field label="Маска номера" hint="{YYYY} {YY} {MM} {DD} — дата, {N:5} — сквозной номер из 5 цифр"><Input value={f.number_mask} maxLength={60} onChange={(e) => set('number_mask', e.target.value)} /></Field>
        <Field label="Напоминать об окончании срока, дней" hint="0 — по умолчанию (30)"><Input type="number" min={0} max={365} value={f.expire_remind_days} onChange={(e) => set('expire_remind_days', e.target.value)} /></Field>
        <Field label="Логотип" className="full"><ImageUpload value={f.logo} onChange={(v) => set('logo', v)} label="" /></Field>
        <div className="full"><div className="small muted" style={{ marginBottom: 6 }}>Предпросмотр</div>
          <CertSheet look={{ title: f.title, body: text, color: f.color, border: f.border, logo: f.logo, signer_name: f.signer_name, signer_title: f.signer_title, user_name: SAMPLE['ФИО'], date: SAMPLE['дата'], valid_until: SAMPLE['срок_действия'] }} number={SAMPLE['номер']} code="ABCDE-23456" /></div>
      </div>
      {err && <div className="err" style={{ marginTop: 12 }}>{err}</div>}
    </Modal>
  );
}

// ---------------------------------------------------------------- публичная проверка (без входа)

export function VerifyPage({ code: initial }: { code?: string }) {
  const [code, setCode] = useState(initial || '');
  const [res, setRes] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  useTitle('Проверка сертификата');
  async function check(c: string) {
    c = c.trim();
    if (!c) return;
    setBusy(true);
    try { setRes(await api.get(`/api/verify/certificate/${encodeURIComponent(c)}`)); } catch (e) { setRes({ state: 'error', error: errMsg(e) }); }
    setBusy(false);
  }
  useEffect(() => { if (initial) check(initial); }, [initial]);
  const st = res?.state;
  return (
    <div className="lmVerify">
      <div className="card pad stack lmVerifyCard">
        <div className="row" style={{ gap: 10 }}><I.Shield size={26} /><h1 className="lnTitle" style={{ margin: 0 }}>Проверка сертификата</h1></div>
        <p className="muted">Введите код с сертификата (например, <span className="mono">ABCDE-23456</span>) или его номер. Если вы открыли страницу по QR-коду, результат ниже.</p>
        <form className="row" onSubmit={(e) => { e.preventDefault(); if (code.trim()) navigate('/verify/' + encodeURIComponent(code.trim()), { replace: true }); check(code); }}>
          <Input value={code} onChange={(e) => setCode(e.target.value)} placeholder="Код или номер сертификата" aria-label="Код или номер" />
          <Btn kind="pri" busy={busy} type="submit">Проверить</Btn>
        </form>
        {res && st === 'not_found' && <div className="notice warn"><I.Alert size={18} /> Сертификат с таким кодом или номером не найден. Проверьте правильность ввода.</div>}
        {res && st === 'error' && <div className="err">{res.error}</div>}
        {res && ['valid', 'expired', 'revoked'].includes(st) && (
          <div className={cx('lmVerifyRes', st)}>
            <div className="row" style={{ gap: 10 }}>{st === 'valid' ? <I.Check size={26} /> : <I.Alert size={26} />}<b>{st === 'valid' ? 'Сертификат подлинный и действителен' : st === 'expired' ? 'Сертификат подлинный, но срок его действия истёк' : 'Сертификат отозван и недействителен'}</b></div>
            <dl>
              <dt>Владелец</dt><dd>{res.name}</dd>
              <dt>Программа</dt><dd>{res.title}</dd>
              <dt>Номер</dt><dd className="mono">{res.number}</dd>
              <dt>Дата выдачи</dt><dd>{dmy(res.issued_at)}</dd>
              <dt>Действителен до</dt><dd>{res.expires_at ? dmy(res.expires_at) : 'бессрочно'}</dd>
            </dl>
          </div>
        )}
        <div><Link to="/" className="small">На главную</Link></div>
      </div>
    </div>
  );
}
