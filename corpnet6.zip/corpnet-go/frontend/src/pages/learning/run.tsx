import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as I from '../../lib/icons';
import { ApiError, api, errMsg } from '../../lib/api';
import { invalidate, useQuery } from '../../lib/query';
import { Link, navigate, useSearchParams, useTitle } from '../../lib/router';
import { toast } from '../../lib/store';
import { usePersist } from '../../lib/persist';
import { cx, plural, thumb, view as viewUrl } from '../../lib/util';
import { Badge, Btn, Empty, ErrorBox, Input, Modal, Skel } from '../../ui';
import { Lightbox } from '../../ui/Lightbox';
import { L, dt, fmtDur, num, pct, refreshLearning } from './common';

interface RQ { id: number; type: 'single' | 'multiple' | 'text'; text: string; file_id: number | null; weight: number; options?: { id: number; text: string }[] }

const answered = (q: RQ, v: any) => (q.type === 'text' ? typeof v === 'string' && v.trim() !== '' : q.type === 'multiple' ? Array.isArray(v) && v.length > 0 : typeof v === 'number');

// ---------------------------------------------------------------- прохождение

export function RunPage({ id }: { id: number }) {
  const [rsp] = useSearchParams();
  const stepQ = /^\d+$/.test(rsp.get('step') || '') ? `?step=${rsp.get('step')}` : ''; // запуск из шага курса
  const [st, setSt] = useState<{ phase: 'loading' | 'ready' | 'error'; data?: any; err?: string }>({ phase: 'loading' });
  useEffect(() => {
    let alive = true;
    api.post(`${L}/tests/${id}/start${stepQ}`).then((d) => {
      if (!alive) return;
      if (d.state === 'finished') return navigate(`/learning/tests/attempt/${d.attempt.id}`, { replace: true });
      setSt({ phase: 'ready', data: d });
    }).catch((e) => alive && setSt({ phase: 'error', err: errMsg(e) }));
    return () => { alive = false; };
  }, [id]);
  useTitle(st.data?.test?.title || 'Тест');
  if (st.phase === 'loading') return <div className="card pad stack"><Skel h={26} w="40%" /><Skel h={80} /><Skel h={50} /><Skel h={50} /></div>;
  if (st.phase === 'error') return (
    <div className="card"><Empty icon={I.Alert} title="Не удалось начать тест">{st.err}<div style={{ marginTop: 12 }}><Link className="btn" to={`/learning/tests/${id}`}>К тесту</Link></div></Empty></div>
  );
  return <Runner data={st.data} testId={id} />;
}

function Runner({ data, testId }: { data: any; testId: number }) {
  const aid: number = data.attempt.id;
  const qs: RQ[] = data.questions;
  const [answers, setAnswers] = useState<Record<string, any>>(data.answers || {});
  const [mode, setMode] = usePersist<'one' | 'list'>('learn:run:mode', 'one');
  const [idx, setIdx] = useState(() => Math.max(0, qs.findIndex((q) => !answered(q, (data.answers || {})[q.id]))));
  const [save, setSave] = useState<'idle' | 'saving' | 'saved' | 'offline'>('idle');
  const [confirm, setConfirm] = useState(false);
  const [finishing, setFinishing] = useState(false);
  const [light, setLight] = useState<string | null>(null);
  const pending = useRef<Record<string, any>>({});
  const timer = useRef<any>(0);
  const done = useRef(false);
  const offset = useRef(new Date(data.server_now).getTime() - Date.now());
  const deadline: number | null = data.attempt.deadline ? new Date(data.attempt.deadline).getTime() : null;
  const [left, setLeft] = useState<number | null>(deadline ? Math.max(0, Math.round((deadline - (Date.now() + offset.current)) / 1000)) : null);
  const cnt = qs.filter((q) => answered(q, answers[q.id])).length;

  const flush = useCallback(async () => {
    clearTimeout(timer.current);
    const snap = pending.current;
    if (!Object.keys(snap).length || done.current) return;
    pending.current = {};
    setSave('saving');
    try {
      await api.put(`${L}/attempts/${aid}/answers`, { answers: snap });
      setSave(Object.keys(pending.current).length ? 'saving' : 'saved');
    } catch (e) {
      if (e instanceof ApiError && (e.status === 409 || e.status === 404)) { done.current = true; navigate(`/learning/tests/attempt/${aid}`, { replace: true }); return; }
      pending.current = { ...snap, ...pending.current };
      setSave('offline');
      timer.current = setTimeout(flush, 3000);
    }
  }, [aid]);

  const setAnswer = useCallback((qid: number, v: any) => {
    setAnswers((a) => {
      const n = { ...a };
      if (v === null || v === undefined || (Array.isArray(v) && !v.length) || v === '') delete n[qid]; else n[qid] = v;
      return n;
    });
    pending.current[qid] = v === '' || (Array.isArray(v) && !v.length) ? null : v;
    setSave('saving');
    clearTimeout(timer.current);
    timer.current = setTimeout(flush, 600);
  }, [flush]);

  // отправка при уходе со страницы / сворачивании вкладки
  useEffect(() => {
    const send = () => {
      const snap = pending.current;
      if (!Object.keys(snap).length || done.current) return;
      pending.current = {};
      fetch(`${L}/attempts/${aid}/answers`, { method: 'PUT', keepalive: true, credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ answers: snap }) }).catch(() => {});
    };
    const vis = () => document.visibilityState === 'hidden' && send();
    document.addEventListener('visibilitychange', vis);
    addEventListener('pagehide', send);
    return () => { document.removeEventListener('visibilitychange', vis); removeEventListener('pagehide', send); send(); clearTimeout(timer.current); };
  }, [aid]);

  const finish = useCallback(async (auto = false) => {
    if (done.current && !auto) return;
    setFinishing(true); setConfirm(false);
    clearTimeout(timer.current);
    try {
      const r = await api.post(`${L}/attempts/${aid}/finish`, { answers });
      done.current = true;
      invalidate('learn:t:'); invalidate('learn:tree');
      if (auto) toast({ title: 'Время вышло — тест завершён', kind: 'info' });
      navigate(`/learning/tests/attempt/${r.attempt.id}`, { replace: true });
    } catch (e) { setFinishing(false); toast({ title: errMsg(e), kind: 'error' }); }
  }, [aid, answers]);

  // таймер
  useEffect(() => {
    if (deadline === null) return;
    const t = setInterval(() => {
      const s = Math.round((deadline - (Date.now() + offset.current)) / 1000);
      setLeft(Math.max(0, s));
      if (s <= 0 && !done.current) { done.current = true; finish(true); }
    }, 500);
    return () => clearInterval(t);
  }, [deadline, finish]);

  // горячие клавиши
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (confirm || light !== null || e.ctrlKey || e.metaKey || e.altKey) return;
      const el = e.target as HTMLElement;
      const typing = el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && (el as HTMLInputElement).type === 'text');
      const q = qs[idx];
      if (e.key === 'Enter' && mode === 'one') {
        if (el.tagName === 'BUTTON' && !el.classList.contains('lnOpt')) return;
        e.preventDefault();
        idx < qs.length - 1 ? setIdx(idx + 1) : setConfirm(true);
        return;
      }
      if (typing) return;
      if (mode === 'one') {
        if (e.key === 'ArrowRight') { e.preventDefault(); setIdx(Math.min(idx + 1, qs.length - 1)); }
        else if (e.key === 'ArrowLeft') { e.preventDefault(); setIdx(Math.max(idx - 1, 0)); }
        else if (/^[1-9]$/.test(e.key) && q?.options && q.options[+e.key - 1]) toggleOpt(q, q.options[+e.key - 1].id);
      }
    };
    addEventListener('keydown', k);
    return () => removeEventListener('keydown', k);
  });

  function toggleOpt(q: RQ, oid: number) {
    const cur = answers[q.id];
    if (q.type === 'single') setAnswer(q.id, cur === oid ? null : oid);
    else { const a: number[] = Array.isArray(cur) ? cur : []; setAnswer(q.id, a.includes(oid) ? a.filter((x) => x !== oid) : [...a, oid]); }
  }
  const goto = (i: number) => {
    if (mode === 'one') setIdx(i); else { setIdx(i); document.getElementById('lnq-' + qs[i].id)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
  };

  const m = left !== null ? Math.floor(left / 60) : 0, s = left !== null ? left % 60 : 0;
  const timeCls = left === null ? '' : left <= 60 ? 'dng' : left <= 300 ? 'warn' : '';
  const renderQ = (q: RQ, i: number) => (
    <section key={q.id} id={'lnq-' + q.id} className="card lnQ">
      <div className="lnQHd"><span className="lnQNum">Вопрос {i + 1} <span className="faint">из {qs.length}</span></span>{q.weight !== 1 && <Badge>{String(q.weight).replace('.', ',')} балла</Badge>}<span className="sp" /><span className="tiny muted">{q.type === 'single' ? 'Один ответ' : q.type === 'multiple' ? 'Несколько ответов' : 'Введите ответ'}</span></div>
      <div className="lnQText">{q.text}</div>
      {q.file_id && <button className="lnQImg" onClick={() => setLight(viewUrl(`/files/${q.file_id}`))}><img src={thumb(`/files/${q.file_id}`)} alt="Иллюстрация к вопросу" onError={(e) => { (e.target as HTMLImageElement).src = `/files/${q.file_id}`; }} /></button>}
      {q.type === 'text' ? (
        <Input value={answers[q.id] || ''} onChange={(e) => setAnswer(q.id, e.target.value)} placeholder="Ваш ответ" maxLength={1000} autoFocus={mode === 'one'} autoComplete="off" aria-label="Ответ" />
      ) : (
        <div className="lnOpts" role={q.type === 'single' ? 'radiogroup' : 'group'}>
          {q.options!.map((o, oi) => {
            const on = q.type === 'single' ? answers[q.id] === o.id : Array.isArray(answers[q.id]) && answers[q.id].includes(o.id);
            return (
              <button key={o.id} type="button" className={cx('lnOpt', on && 'on')} role={q.type === 'single' ? 'radio' : 'checkbox'} aria-checked={on} onClick={() => toggleOpt(q, o.id)}>
                <span className={cx('lnOptMark', q.type === 'multiple' && 'sq')}>{on ? <I.Check size={14} /> : mode === 'one' && oi < 9 ? oi + 1 : ''}</span>
                <span className="sp">{o.text}</span>
              </button>
            );
          })}
        </div>
      )}
    </section>
  );

  return (
    <div className="lnRun">
      <div className="lnRunHd card">
        <div className="sp" style={{ minWidth: 0 }}>
          <div className="bold clip">{data.test.title}</div>
          <div className="lnRunProg"><div className="prog sp"><i style={{ width: (cnt / qs.length) * 100 + '%' }} /></div><span className="tiny muted">{cnt} из {qs.length}</span></div>
        </div>
        {left !== null && <div className={cx('lnTimer', timeCls)} role="timer" aria-label="Осталось времени"><I.Clock size={16} /> {String(m).padStart(2, '0')}:{String(s).padStart(2, '0')}</div>}
        <span className={cx('lnSave', save)} aria-live="polite">{save === 'saving' ? 'Сохранение…' : save === 'saved' ? 'Сохранено' : save === 'offline' ? 'Нет связи — повторим' : ''}</span>
        <div className="viewSw" role="group" aria-label="Режим">
          <button className={cx(mode === 'one' && 'on')} onClick={() => setMode('one')} title="По одному вопросу" aria-label="По одному"><I.Maximize size={16} /></button>
          <button className={cx(mode === 'list' && 'on')} onClick={() => setMode('list')} title="Списком" aria-label="Списком"><I.List size={17} /></button>
        </div>
        <Btn kind="pri" busy={finishing} onClick={() => { flush(); setConfirm(true); }}>Завершить</Btn>
      </div>
      <div className="lnRunBody">
        <div className="stack lnRunMain">
          {mode === 'one' ? (
            <>
              {renderQ(qs[idx], idx)}
              <div className="lnRunBtns">
                <Btn size="lg" onClick={() => setIdx(idx - 1)} disabled={idx === 0}><I.ChevronLeft size={18} /> Назад</Btn>
                <span className="sp" />
                {idx < qs.length - 1 ? <Btn kind="pri" size="lg" onClick={() => setIdx(idx + 1)}>Дальше <I.ChevronRight size={18} /></Btn> : <Btn kind="pri" size="lg" onClick={() => { flush(); setConfirm(true); }}>Завершить тест</Btn>}
              </div>
              <div className="hint lnKeys">Клавиши: 1–9 — выбрать ответ · Enter — дальше · ← → — перейти к вопросу</div>
            </>
          ) : (
            <>
              {qs.map((q, i) => renderQ(q, i))}
              <div className="lnRunBtns"><span className="sp" /><Btn kind="pri" size="lg" onClick={() => { flush(); setConfirm(true); }}>Завершить тест</Btn></div>
            </>
          )}
        </div>
        <aside className="lnRunNav card" aria-label="Навигатор по вопросам">
          <div className="lbl">Вопросы</div>
          <div className="lnNavGrid">
            {qs.map((q, i) => <button key={q.id} className={cx('lnNavBtn', answered(q, answers[q.id]) && 'ok', i === idx && 'cur')} onClick={() => goto(i)} aria-label={`Вопрос ${i + 1}${answered(q, answers[q.id]) ? ', есть ответ' : ''}`}>{i + 1}</button>)}
          </div>
          <div className="lnLegend tiny muted"><span><i className="lnNavBtn ok" /> с ответом</span><span><i className="lnNavBtn" /> без ответа</span></div>
        </aside>
      </div>
      {confirm && (
        <Modal title="Завершить тест?" size="sm" onClose={() => setConfirm(false)} footer={<><Btn onClick={() => setConfirm(false)}>Вернуться к вопросам</Btn><Btn kind="pri" busy={finishing} onClick={() => finish()} autoFocus>Завершить</Btn></>}>
          <div className="stackS">
            <p>Отвечено: <b>{cnt}</b> из <b>{qs.length}</b>.</p>
            {cnt < qs.length && <div className="notice warn"><I.Alert size={16} /> Без ответа {plural(qs.length - cnt, ['вопрос', 'вопроса', 'вопросов'])} — за них баллы не начисляются.</div>}
            <p className="muted small">После завершения изменить ответы нельзя.</p>
          </div>
        </Modal>
      )}
      {light && <Lightbox items={[{ src: light }]} onClose={() => setLight(null)} />}
    </div>
  );
}

// ---------------------------------------------------------------- результат попытки

export function AttemptPage({ id }: { id: number }) {
  const { data, error, refetch } = useQuery<any>(`learn:t:attempt:${id}`, () => api.get(`${L}/attempts/${id}`), { stale: 0 });
  const [onlyWrong, setOnlyWrong] = useState(false);
  const [light, setLight] = useState<string | null>(null);
  useTitle(data?.test?.title ? 'Результат: ' + data.test.title : 'Результат');
  useEffect(() => { if (data?.state === 'running') navigate(`/learning/tests/${data.test.id}/run`, { replace: true }); }, [data]);
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data || data.state === 'running') return <div className="card pad stack"><Skel h={26} w="40%" /><Skel h={120} /><Skel h={60} /></div>;
  const a = data.attempt, t = data.test;
  const manager = data.level >= 3;
  const foreign = data.user;
  const review: any[] = data.review || [];
  const shown = onlyWrong ? review.filter((r) => r.status !== 2) : review;
  const p = a.percent ?? 0;
  const hiddenMsg = t.show_answers === 'never' ? 'Автор теста не показывает правильные ответы.' : 'Правильные ответы станут доступны после использования всех попыток или окончания срока теста.';

  if (data.state === 'open') return <div className="card"><Empty icon={I.Clock} title="Попытка ещё не завершена">Пользователь проходит тест.<div style={{ marginTop: 12 }}><Link className="btn" to={`/learning/tests/${t.id}/results`}>К результатам</Link></div></Empty></div>;

  return (
    <div className="stack lnItemPage">
      <div className="lnHead">
        <div className="sp">
          <div className="crumbs"><Link to="/learning/tests">Тесты</Link><I.ChevronRight size={14} /><Link to={`/learning/tests/${t.id}`}>{t.title}</Link><I.ChevronRight size={14} /><b style={{ color: 'var(--text)' }}>Попытка {a.no}</b></div>
          <h2 className="lnTitle">Результат прохождения</h2>
          {foreign && <div className="muted">{foreign.name}{foreign.department ? ' · ' + foreign.department : ''}</div>}
        </div>
      </div>
      <div className={cx('card lnResult', a.passed ? 'ok' : 'bad')}>
        <div className="lnRing" style={{ ['--p' as any]: p }}><div><b>{pct(a.percent)}</b><span>{a.passed ? 'Сдан' : 'Не сдан'}</span></div></div>
        <div className="stackS sp">
          <div className="lnResTitle">{a.passed ? <><I.Check size={22} /> Тест сдан</> : <><I.X size={22} /> Тест не сдан</>}</div>
          <div className="lnFacts">
            <div className="lnFact"><span className="muted small">Баллы</span><b>{num(a.score)} из {num(a.max_score)}</b></div>
            <div className="lnFact"><span className="muted small">Проходной</span><b>{t.pass_percent}%</b></div>
            <div className="lnFact"><span className="muted small">Время</span><b>{fmtDur(a.duration_sec)}</b></div>
            <div className="lnFact"><span className="muted small">Завершено</span><b>{dt(a.finished_at)}</b></div>
          </div>
          {a.expired && <div className="notice warn"><I.Clock size={16} /> Попытка завершена автоматически: время вышло.</div>}
          <div className="rowW">
            <Link to={`/learning/tests/${t.id}`} className="btn">К тесту</Link>
            {a.course_id && <Link to={`/learning/courses/${a.course_id}${a.step_id && a.passed ? '/step/' + a.step_id : ''}`} className={cx('btn', a.passed && 'pri')}><I.GradCap size={16} /> К курсу</Link>}
            {data.can_retry && <Link to={`/learning/tests/${t.id}/run${a.step_id ? '?step=' + a.step_id : ''}`} className="btn pri"><I.Refresh size={16} /> Пройти ещё раз{data.attempts_left != null ? ` (осталось ${data.attempts_left})` : ''}</Link>}
            {manager && <Link to={`/learning/tests/${t.id}/results`} className="btn">Все результаты</Link>}
            {!foreign && <Link to="/learning/tests/my" className="btn ghost">Мои результаты</Link>}
          </div>
        </div>
      </div>
      {data.answers_hidden ? (
        <div className="notice"><I.Info size={16} /> {hiddenMsg}</div>
      ) : (
        <div className="stackS">
          <div className="row"><h3 className="lnH3 sp">Разбор ответов</h3>
            <div className="chips"><button className={cx('chip', !onlyWrong && 'on')} onClick={() => setOnlyWrong(false)}>Все · {review.length}</button><button className={cx('chip', onlyWrong && 'on')} onClick={() => setOnlyWrong(true)}>Ошибки · {review.filter((r) => r.status !== 2).length}</button></div>
          </div>
          {shown.map((r) => {
            const idx = review.indexOf(r) + 1;
            return (
              <div key={r.id} className={cx('card lnQ lnRev', r.status === 2 ? 'ok' : r.status === 1 ? 'part' : 'bad')}>
                <div className="lnQHd">
                  <span className="lnQNum">Вопрос {idx}</span>
                  {r.status === 2 ? <Badge kind="ok"><I.Check size={11} /> Верно</Badge> : r.status === 1 ? <Badge kind="warn">Частично</Badge> : r.status === -1 ? <Badge>Нет ответа</Badge> : <Badge kind="dng"><I.X size={11} /> Неверно</Badge>}
                  <span className="sp" /><span className="small muted">{num(r.points)} / {num(r.weight)}</span>
                </div>
                <div className="lnQText">{r.text}</div>
                {r.file_id && <button className="lnQImg" onClick={() => setLight(viewUrl(`/files/${r.file_id}`))}><img src={thumb(`/files/${r.file_id}`)} alt="" onError={(e) => { (e.target as HTMLImageElement).src = `/files/${r.file_id}`; }} /></button>}
                {r.options && (
                  <div className="lnOpts">
                    {r.options.map((o: any) => (
                      <div key={o.id} className={cx('lnOpt static', o.correct && 'right', o.selected && !o.correct && 'wrong', o.selected && 'sel')}>
                        <span className="lnOptMark">{o.correct ? <I.Check size={14} /> : o.selected ? <I.X size={14} /> : ''}</span><span className="sp">{o.text}</span>
                        {o.selected && <span className="tiny muted">ваш ответ</span>}
                      </div>
                    ))}
                  </div>
                )}
                {r.type === 'text' && (
                  <div className="stackS small">
                    <div>Ваш ответ: <b className={r.status === 2 ? '' : 'lnWrongTxt'}>{r.my || '—'}</b></div>
                    {r.status !== 2 && <div>Правильно: <b>{(r.answers || []).join(' · ')}</b></div>}
                  </div>
                )}
                {r.explanation && <div className="lnExpl"><I.Lightbulb size={16} /> <span>{r.explanation}</span></div>}
              </div>
            );
          })}
          {!shown.length && <div className="card"><Empty icon={I.Check} title="Ошибок нет">Все ответы верные</Empty></div>}
        </div>
      )}
      {light && <Lightbox items={[{ src: light }]} onClose={() => setLight(null)} />}
    </div>
  );
}
