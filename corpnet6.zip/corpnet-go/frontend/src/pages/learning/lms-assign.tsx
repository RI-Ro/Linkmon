// LMS: назначения обучения (ответственный за обучение / администратор): список, создание, карточка с исполнителями и действиями.
import React, { useEffect, useMemo, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { invalidate, useQuery } from '../../lib/query';
import { Link, navigate, useSearchParams, useTitle } from '../../lib/router';
import { toast } from '../../lib/store';
import { cx, plural, useDebounced } from '../../lib/util';
import { Badge, Btn, Check, Empty, ErrorBox, Field, Input, Modal, Pager, Select, Skel, Switch, Textarea, UserPicker, UserLite, useConfirm } from '../../ui';
import { L } from './common';
import { Bar, DeptTokens, DueChip, StatusBadge, dmy, dmyTime, ratio, score1, useStatsMe } from './lms-common';

const refresh = () => { invalidate('learn:asg'); invalidate('learn:stats'); invalidate('learn:my'); invalidate('learn:c:'); };
const ROLE_LABEL: Record<string, string> = { user: 'Сотрудники', editor: 'Редакторы', admin: 'Администраторы', head: 'Руководители подразделений', learning_manager: 'Ответственные за обучение' };

export function targetLabel(t: { type: string; name?: string | null; key?: string }) {
  if (t.type === 'all') return 'Все сотрудники';
  if (t.type === 'role') return ROLE_LABEL[t.key || ''] || t.key || 'Роль';
  if (t.type === 'department') return `Подразделение: ${t.name || '—'}`;
  if (t.type === 'group') return `Группа: ${t.name || '—'}`;
  return t.name || 'Сотрудник';
}

function NoAccess() {
  return <div className="card"><Empty icon={I.Lock} title="Недостаточно прав">Назначать обучение могут администратор и ответственный за обучение.</Empty></div>;
}

// ---------------------------------------------------------------- список назначений

export function AssignmentsPage() {
  useTitle('Назначения');
  const sm = useStatsMe();
  const [sp, setSp] = useSearchParams();
  const page = +(sp.get('page') || 1), type = sp.get('type') || '', status = sp.get('status') || '';
  const params = new URLSearchParams({ page: String(page) });
  if (type) params.set('type', type);
  if (status) params.set('status', status);
  const mgr = !!sm.data?.manager;
  const { data, error, refetch } = useQuery<{ items: any[]; total: number; per: number }>(mgr ? `learn:asg:list:${params}` : null, () => api.get(`${L}/assignments?${params}`), { stale: 5000, keepPrevious: true });
  const [confirm, node] = useConfirm();
  if (sm.data && !mgr) return <NoAccess />;
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  async function cancel(a: any) {
    if (!(await confirm(`Отменить назначение «${a.title}»?`, { text: 'Невыполненные задания сотрудников будут отозваны. Прогресс сохранится.', ok: 'Отменить назначение' }))) return;
    try { await api.post(`${L}/assignments/${a.id}/cancel`); refresh(); refetch(); toast({ title: 'Назначение отменено', kind: 'success' }); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  return (
    <div className="stack">
      <div className="lnBar">
        <Select value={type} onChange={(e) => setSp({ type: e.target.value || null, page: null })} aria-label="Тип"><option value="">Курсы и тесты</option><option value="course">Курсы</option><option value="test">Тесты</option></Select>
        <Select value={status} onChange={(e) => setSp({ status: e.target.value || null, page: null })} aria-label="Статус"><option value="">Любой статус</option><option value="active">Действующие</option><option value="cancelled">Отменённые</option></Select>
        <span className="sp" />
        <Link className="btn pri" to="/learning/assignments/new"><I.Plus size={16} /> Назначить</Link>
      </div>
      {!data ? <div className="stackS">{[0, 1, 2].map((i) => <div key={i} className="card pad"><Skel h={50} /></div>)}</div> : !data.items.length ? (
        <div className="card"><Empty icon={I.UserPlus} title="Назначений пока нет">Назначьте курс или тест сотрудникам, подразделению или всей компании — с обязательностью и сроком</Empty></div>
      ) : (
        <div className="stackS">
          {data.items.map((a) => (
            <div key={a.id} className={cx('card lmAsg', a.status === 'cancelled' && 'off')}>
              <div className="lmAsgMain">
                <div className="row" style={{ flexWrap: 'wrap' }}>
                  <Link to={`/learning/assignments/${a.id}`} className="bold">{a.title}</Link>
                  <Badge>{a.target_type === 'course' ? 'Курс' : 'Тест'}</Badge>
                  {a.mandatory && <Badge kind="accent">обязательно</Badge>}
                  {a.priority === 'high' && <Badge kind="dng">высокий приоритет</Badge>}
                  {a.status === 'cancelled' && <Badge>отменено</Badge>}
                  {a.follow && <Badge kind="lime" >автоназначение</Badge>}
                </div>
                <div className="lmMeta">
                  <span><I.Users size={12} /> {a.targets.map(targetLabel).slice(0, 3).join(', ')}{a.targets.length > 3 && ` и ещё ${a.targets.length - 3}`}</span>
                  <span><I.Calendar size={12} /> {a.due_mode === 'date' ? `до ${dmy(a.due_date)}` : a.due_mode === 'days' ? `${plural(a.due_days, ['день', 'дня', 'дней'])} на выполнение` : 'без срока'}</span>
                  {a.recur_months > 0 && <span><I.Refresh size={12} /> каждые {a.recur_months} мес.</span>}
                  <span>{a.author} · {dmy(a.created_at)}</span>
                </div>
              </div>
              <div className="lmAsgStat">
                <div className="row small"><b>{a.done}</b><span className="muted">из {a.total}</span>{a.overdue > 0 && <Badge kind="dng">{a.overdue} просрочено</Badge>}</div>
                <Bar p={ratio(a.done, a.total)} thin />
                <div className="tiny muted">в процессе: {a.progress}</div>
              </div>
              <div className="rowW">
                <Link className="btn sm" to={`/learning/assignments/${a.id}`}>Открыть</Link>
                {a.status === 'active' && <Btn size="sm" kind="ghost" onClick={() => cancel(a)}>Отменить</Btn>}
              </div>
            </div>
          ))}
        </div>
      )}
      {data && data.total > data.per && <Pager page={page} total={data.total} per={data.per} onChange={(p) => setSp({ page: p > 1 ? p : null }, false)} />}
      {node}
    </div>
  );
}

// ---------------------------------------------------------------- создание назначения

export function AssignForm() {
  useTitle('Новое назначение');
  const sm = useStatsMe();
  const [sp] = useSearchParams();
  const [type, setType] = useState<'course' | 'test'>(sp.get('type') === 'test' ? 'test' : 'course');
  const [target, setTarget] = useState<{ id: number; title: string } | null>(null);
  const [all, setAll] = useState(false);
  const [users, setUsers] = useState<UserLite[]>([]);
  const [depts, setDepts] = useState<number[]>([]);
  const [groups, setGroups] = useState<{ id: number; name: string }[]>([]);
  const [roles, setRoles] = useState<string[]>([]);
  const [dueMode, setDueMode] = useState<'none' | 'date' | 'days'>('days');
  const [dueDate, setDueDate] = useState('');
  const [dueDays, setDueDays] = useState('14');
  const [priority, setPriority] = useState<'normal' | 'high'>('normal');
  const [mandatory, setMandatory] = useState(true);
  const [remind, setRemind] = useState<number[]>([7, 3, 1, 0]);
  const [remOver, setRemOver] = useState('3');
  const [recur, setRecur] = useState('0');
  const [follow, setFollow] = useState(false);
  const [within, setWithin] = useState('30');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const presetId = +(sp.get('target') || 0);
  useEffect(() => {
    if (!presetId || target) return;
    if (type === 'course') api.get(`${L}/courses/${presetId}`).then((d) => setTarget({ id: presetId, title: d.course.title })).catch(() => {});
    else api.get(`${L}/tests/${presetId}`).then((d) => setTarget({ id: presetId, title: d.test.title })).catch(() => {});
  }, [presetId, type]);
  const mgr = !!sm.data?.manager;
  if (sm.data && !mgr) return <NoAccess />;
  const scoped = sm.data && !sm.data.all;

  const toggleDay = (d: number) => setRemind((r) => (r.includes(d) ? r.filter((x) => x !== d) : [...r, d].sort((a, b) => b - a)));
  const nRecipients = (all ? 1 : 0) + users.length + depts.length + groups.length + roles.length;

  async function submit() {
    if (!target) return setErr('Выберите курс или тест');
    if (!nRecipients) return setErr('Выберите, кому назначить');
    if (dueMode === 'date' && (!dueDate || new Date(dueDate + 'T23:59:59') < new Date())) return setErr('Укажите срок в будущем');
    if (dueMode === 'days' && !(+dueDays >= 1)) return setErr('Укажите число дней на выполнение');
    setBusy(true); setErr('');
    const targets: any[] = [];
    if (all) targets.push({ type: 'all', id: 0, key: '' });
    users.forEach((u) => targets.push({ type: 'user', id: u.id, key: '' }));
    depts.forEach((d) => targets.push({ type: 'department', id: d, key: '' }));
    groups.forEach((g) => targets.push({ type: 'group', id: g.id, key: '' }));
    roles.forEach((r) => targets.push({ type: 'role', id: 0, key: r }));
    try {
      const r = await api.post<{ id: number; assigned: number }>(`${L}/assignments`, {
        target_type: type, target_id: target.id, targets, due_mode: dueMode,
        due_date: dueMode === 'date' ? new Date(dueDate + 'T23:59:59').toISOString() : null, due_days: dueMode === 'days' ? +dueDays : null,
        priority, mandatory, remind_days: dueMode === 'none' ? [] : remind, remind_overdue_days: +remOver || 0, recur_months: +recur || 0, follow, new_within_days: follow && within ? +within : null, note,
      });
      refresh();
      toast({ title: r.assigned ? `Назначено: ${plural(r.assigned, ['сотрудник', 'сотрудника', 'сотрудников'])}` : 'Назначение создано', body: r.assigned ? 'Сотрудники получили уведомление' : 'Подходящих сотрудников пока нет — правило сработает для новых', kind: 'success' });
      navigate(`/learning/assignments/${r.id}`);
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }

  return (
    <div className="stack lmEd">
      <div className="lnHead"><div className="sp"><div className="crumbs"><Link to="/learning/assignments">Назначения</Link><I.ChevronRight size={14} /><b style={{ color: 'var(--text)' }}>Новое</b></div><h2 className="lnTitle">Назначить обучение</h2></div></div>
      {scoped && <div className="notice"><I.Info size={16} /> Вы можете назначать обучение сотрудникам своего подразделения и дочерних. Выбор «Все сотрудники», роли и групп ограничится вашей областью.</div>}
      <div className="card pad">
        <div className="formGrid">
          <div className="fsec">Что назначить</div>
          <div className="full chips">
            <button type="button" className={cx('chip', type === 'course' && 'on')} onClick={() => { setType('course'); setTarget(null); }}>Курс</button>
            <button type="button" className={cx('chip', type === 'test' && 'on')} onClick={() => { setType('test'); setTarget(null); }}>Отдельный тест</button>
          </div>
          <div className="full"><TargetPicker type={type} value={target} onChange={setTarget} /></div>

          <div className="fsec">Кому</div>
          <div className="full stack">
            <Check checked={all} onChange={setAll} label={scoped ? 'Все сотрудники моей области' : 'Все сотрудники компании'} />
            <Field label="Сотрудники"><UserPicker value={users} onChange={setUsers} /></Field>
            <Field label="Подразделения" hint="Вместе с дочерними"><DeptTokens value={depts} onChange={setDepts} /></Field>
            <Field label="Группы"><GroupPicker value={groups} onChange={setGroups} /></Field>
            <Field label="Роли"><div className="chips">{Object.entries(ROLE_LABEL).map(([k, v]) => <button type="button" key={k} className={cx('chip', roles.includes(k) && 'on')} onClick={() => setRoles((r) => (r.includes(k) ? r.filter((x) => x !== k) : [...r, k]))}>{v}</button>)}</div></Field>
            <div className="small muted">Повторное назначение тем же сотрудникам ничего не дублирует.</div>
          </div>

          <div className="fsec">Срок и обязательность</div>
          <Field label="Срок выполнения">
            <Select value={dueMode} onChange={(e) => setDueMode(e.target.value as any)}><option value="days">N дней с момента назначения</option><option value="date">До конкретной даты</option><option value="none">Без срока</option></Select>
          </Field>
          {dueMode === 'days' && <Field label="Дней на выполнение"><Input type="number" min={1} max={3650} value={dueDays} onChange={(e) => setDueDays(e.target.value)} /></Field>}
          {dueMode === 'date' && <Field label="Дедлайн"><Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} /></Field>}
          <Field label="Приоритет"><Select value={priority} onChange={(e) => setPriority(e.target.value as any)}><option value="normal">Обычный</option><option value="high">Высокий</option></Select></Field>
          <div className="full"><Switch checked={mandatory} onChange={setMandatory} label="Обязательное обучение (просрочка попадает в отчёты и дайджест)" /></div>

          <div className="fsec">Напоминания</div>
          {dueMode !== 'none' ? (
            <Field label="Напоминать за N дней до срока" className="full" hint="0 — в день срока">
              <div className="chips">{[14, 7, 3, 2, 1, 0].map((d) => <button type="button" key={d} className={cx('chip', remind.includes(d) && 'on')} onClick={() => toggleDay(d)}>{d === 0 ? 'в день срока' : `за ${d} дн.`}</button>)}</div>
            </Field>
          ) : <div className="full small muted">Без срока напоминания до дедлайна не отправляются.</div>}
          <Field label="После срока напоминать" hint="Раз в день, но не более N раз; 0 — не напоминать"><Input type="number" min={0} max={90} value={remOver} onChange={(e) => setRemOver(e.target.value)} disabled={dueMode === 'none'} /></Field>

          <div className="fsec">Повторение и автоназначение</div>
          <Field label="Переназначать каждые, мес." hint="0 — один раз. Нужно для периодических инструктажей"><Input type="number" min={0} max={120} value={recur} onChange={(e) => setRecur(e.target.value)} /></Field>
          <div className="full"><Switch checked={follow} onChange={setFollow} label="Автоматически назначать новым сотрудникам этих подразделений и переведённым в них" /></div>
          {follow && <Field label="Применять в течение N дней после прихода/перевода" hint="Пусто — всегда"><Input type="number" min={1} max={3650} value={within} onChange={(e) => setWithin(e.target.value)} /></Field>}
          <Field label="Комментарий для сотрудников" className="full"><Textarea rows={3} maxLength={1000} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Например: Пройти до конца месяца, это условие допуска" /></Field>
        </div>
      </div>
      {err && <div className="err">{err}</div>}
      <div className="lnSaveBar"><Link className="btn" to="/learning/assignments">Отмена</Link><Btn kind="pri" busy={busy} onClick={submit}><I.UserPlus size={16} /> Назначить</Btn></div>
    </div>
  );
}

function TargetPicker({ type, value, onChange }: { type: 'course' | 'test'; value: { id: number; title: string } | null; onChange: (v: { id: number; title: string } | null) => void }) {
  const [q, setQ] = useState('');
  const dq = useDebounced(q.trim(), 200);
  const url = type === 'course' ? `${L}/courses/pick?q=${encodeURIComponent(dq)}` : `${L}/tests?q=${encodeURIComponent(dq)}&page=1`;
  const { data } = useQuery<any>(!value && (type === 'course' || dq) ? `learn:asg:pick:${type}:${dq}` : null, () => api.get(url), { stale: 15000 });
  const list: any[] = (type === 'course' ? data : data?.items?.filter((x: any) => x.status === 'published')) || [];
  if (value) return <div className="tokens"><span className="token">{type === 'course' ? <I.GradCap size={14} /> : <I.Check size={14} />} {value.title}<button type="button" onClick={() => onChange(null)} aria-label="Сменить"><I.X size={14} /></button></span></div>;
  return (
    <div className="pick">
      <input className="sel" placeholder={type === 'course' ? 'Найти опубликованный курс…' : 'Найти опубликованный тест (введите название)…'} value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="lst">
        {list.map((x) => <div key={x.id} className="pickRow" onClick={() => onChange({ id: x.id, title: x.title })}><I.GradCap size={16} /><div className="bold small clip">{x.title}</div></div>)}
        {!list.length && <div className="small muted" style={{ padding: 12 }}>{type === 'test' && !dq ? 'Введите часть названия теста' : 'Ничего не найдено'}</div>}
      </div>
    </div>
  );
}

function GroupPicker({ value, onChange }: { value: { id: number; name: string }[]; onChange: (v: { id: number; name: string }[]) => void }) {
  const [q, setQ] = useState('');
  const dq = useDebounced(q.trim(), 200);
  const { data } = useQuery<any[]>(`learn:asg:groups:${dq}`, () => api.get(`${L}/assign/targets?q=${encodeURIComponent(dq)}`), { stale: 20000 });
  const ids = new Set(value.map((v) => v.id));
  const list = (data || []).filter((g) => !ids.has(g.id));
  return (
    <div className="stackS">
      {value.length > 0 && <div className="tokens">{value.map((g) => <span className="token" key={g.id}>{g.name}<button type="button" onClick={() => onChange(value.filter((x) => x.id !== g.id))} aria-label="Убрать"><I.X size={14} /></button></span>)}</div>}
      <div className="pick">
        <input className="sel" placeholder="Найти группу…" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="lst">
          {list.map((g) => <div key={g.id} className="pickRow" onClick={() => { onChange([...value, { id: g.id, name: g.name }]); setQ(''); }}><I.Users size={16} /><div className="bold small clip">{g.name}</div><span className="tiny muted">{g.members}</span></div>)}
          {!list.length && <div className="small muted" style={{ padding: 12 }}>Групп не найдено</div>}
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- карточка назначения

export function AssignmentPage({ id }: { id: number }) {
  const sm = useStatsMe();
  const mgr = !!sm.data?.manager;
  const [sp, setSp] = useSearchParams();
  const page = +(sp.get('page') || 1), filter = sp.get('filter') || '', q = sp.get('q') || '';
  const [qIn, setQIn] = useState(q);
  const dq = useDebounced(qIn, 250);
  useEffect(() => { if (dq.trim() !== q) setSp({ q: dq.trim() || null, page: null }); }, [dq]);
  const params = new URLSearchParams({ page: String(page) });
  if (filter) params.set('filter', filter);
  if (q) params.set('q', q);
  const { data, error, refetch } = useQuery<any>(mgr ? `learn:asg:${id}:${params}` : null, () => api.get(`${L}/assignments/${id}?${params}`), { stale: 3000, keepPrevious: true });
  const [sel, setSel] = useState<Set<number>>(new Set());
  const [ext, setExt] = useState<any | null>(null);
  const [log, setLog] = useState<any | null>(null);
  const [confirm, node] = useConfirm();
  useEffect(() => setSel(new Set()), [page, filter, q]);
  useTitle(data?.assignment?.title ? 'Назначение: ' + data.assignment.title : 'Назначение');
  if (sm.data && !mgr) return <NoAccess />;
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data) return <div className="card pad stack"><Skel h={26} w="40%" /><Skel h={200} /></div>;
  const a = data.assignment;
  const items: any[] = data.items;
  const reload = () => { refresh(); refetch(); };
  async function remind(ids: number[]) {
    try {
      const r = ids.length === 1 ? await api.post(`${L}/assignees/${ids[0]}/remind`) : await api.post(`${L}/assignees/remind`, { ids });
      toast({ title: ids.length === 1 ? 'Напоминание отправлено' : `Напоминаний отправлено: ${r.sent ?? ids.length}`, kind: 'success' }); setSel(new Set()); reload();
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function revoke(row: any, restore: boolean) {
    if (!restore && !(await confirm(`Отозвать задание у «${row.name}»?`, { text: 'Сотрудник перестанет видеть его в списке назначенного. Прогресс сохранится.', ok: 'Отозвать' }))) return;
    try { await api.post(`${L}/assignees/${row.id}/revoke`, { restore }); reload(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function cancelAll() {
    if (!(await confirm('Отменить назначение целиком?', { text: 'Невыполненные задания всех сотрудников будут отозваны.', ok: 'Отменить назначение' }))) return;
    try { await api.post(`${L}/assignments/${id}/cancel`); reload(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  const FILTERS = [['', 'Все'], ['open', 'Не завершили'], ['overdue', 'Просрочено'], ['done', 'Завершили'], ['revoked', 'Отозвано']];
  return (
    <div className="stack">
      <div className="lnHead">
        <div className="sp" style={{ minWidth: 0 }}>
          <div className="crumbs"><Link to="/learning/assignments">Назначения</Link><I.ChevronRight size={14} /><b style={{ color: 'var(--text)' }}>№ {a.id}</b></div>
          <h2 className="lnTitle"><Link to={a.target_type === 'course' ? `/learning/courses/${a.target_id}` : `/learning/tests/${a.target_id}`}>{a.title}</Link> {a.status === 'cancelled' && <Badge>отменено</Badge>}</h2>
          <div className="lmMeta">
            <span><I.Users size={12} /> {a.targets.map(targetLabel).join(', ')}</span>
            <span><I.Calendar size={12} /> {a.due_mode === 'date' ? `до ${dmy(a.due_date)}` : a.due_mode === 'days' ? `${plural(a.due_days, ['день', 'дня', 'дней'])} на выполнение` : 'без срока'}</span>
            {a.mandatory && <span className="lmMand">обязательно</span>}{a.priority === 'high' && <span className="lmHigh">высокий приоритет</span>}
            {a.recur_months > 0 && <span><I.Refresh size={12} /> повтор каждые {a.recur_months} мес.</span>}
            {a.follow && <span>автоназначение{a.new_within_days ? ` (${a.new_within_days} дн.)` : ''}</span>}
            <span>напоминания: {a.remind_days?.length ? a.remind_days.map((d: number) => (d === 0 ? 'в день срока' : `за ${d} дн.`)).join(', ') : 'нет'}{a.remind_overdue_days > 0 && `, после срока ${a.remind_overdue_days} дн.`}</span>
            <span>{a.author}</span>
          </div>
          {a.note && <div className="small" style={{ marginTop: 6 }}>{a.note}</div>}
        </div>
        <div className="rowW">
          <Link className="btn" to={a.target_type === 'course' ? `/learning/stats/course/${a.target_id}` : `/learning/stats/test/${a.target_id}`}><I.Chart size={16} /> Статистика</Link>
          {a.status === 'active' && <Btn kind="ghost" onClick={cancelAll}>Отменить назначение</Btn>}
        </div>
      </div>
      <div className="lnBar">
        <div className="lnSearch"><I.Search size={17} /><input value={qIn} placeholder="Сотрудник…" onChange={(e) => setQIn(e.target.value)} aria-label="Поиск" /></div>
        <div className="chips">{FILTERS.map(([k, l]) => <button key={k} className={cx('chip', filter === k && 'on')} onClick={() => setSp({ filter: k || null, page: null })}>{l}</button>)}</div>
      </div>
      {sel.size > 0 && <div className="lnSelBar card"><b>Выбрано: {sel.size}</b><div className="sp" /><Btn size="sm" kind="pri" onClick={() => remind([...sel])}><I.Bell size={15} /> Напомнить</Btn><Btn size="sm" kind="ghost" onClick={() => setSel(new Set())}>Снять выбор</Btn></div>}
      {!items.length ? <div className="card"><Empty icon={I.Users} title="Никого не найдено" /></div> : (
        <div className="card tblW">
          <table className="tbl">
            <thead><tr><th style={{ width: 34 }}><input type="checkbox" className="lnChk" aria-label="Выбрать всех" checked={sel.size === items.length} onChange={(e) => setSel(e.target.checked ? new Set(items.filter((x) => x.status < 2).map((x) => x.id)) : new Set())} /></th><th>Сотрудник</th><th>Статус</th><th>Срок</th><th>Завершил(а)</th><th>Балл</th><th /></tr></thead>
            <tbody>
              {items.map((r) => (
                <tr key={r.id}>
                  <td>{r.status < 2 && <input type="checkbox" className="lnChk" aria-label="Выбрать" checked={sel.has(r.id)} onChange={() => setSel((s) => { const n = new Set(s); n.has(r.id) ? n.delete(r.id) : n.add(r.id); return n; })} />}</td>
                  <td><Link to={`/learning/stats/user/${r.user_id}`} className="bold">{r.name}</Link><div className="tiny muted">{r.department}{r.job_title && ` · ${r.job_title}`}</div></td>
                  <td><StatusBadge status={r.status} overdue={r.overdue} />{r.cycle > 1 && <div className="tiny muted">цикл {r.cycle}</div>}</td>
                  <td className="small"><DueChip due={r.due_at} status={r.status} /></td>
                  <td className="small">{dmy(r.done_at)}</td>
                  <td className="small">{score1(r.score)}</td>
                  <td className="act">
                    {r.status < 2 && <Btn size="sm" kind="ghost" title={r.manual_remind_at ? `Напоминали ${dmyTime(r.manual_remind_at)}` : 'Напомнить'} onClick={() => remind([r.id])}><I.Bell size={14} /></Btn>}
                    {r.status < 2 && <Btn size="sm" kind="ghost" title="Продлить срок" onClick={() => setExt(r)}><I.Calendar size={14} /></Btn>}
                    {r.status < 2 && <Btn size="sm" kind="ghost" title="Отозвать" onClick={() => revoke(r, false)}><I.Ban size={14} /></Btn>}
                    {r.status === 3 && <Btn size="sm" kind="ghost" onClick={() => revoke(r, true)}>Вернуть</Btn>}
                    <Btn size="sm" kind="ghost" title="История" onClick={() => setLog(r)}><I.Clock size={14} /></Btn>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {data.total > data.per && <Pager page={page} total={data.total} per={data.per} onChange={(p) => setSp({ page: p > 1 ? p : null }, false)} />}
      {ext && <ExtendModal row={ext} onClose={() => setExt(null)} onDone={() => { setExt(null); reload(); }} />}
      {log && <LogModal row={log} onClose={() => setLog(null)} />}
      {node}
    </div>
  );
}

function ExtendModal({ row, onClose, onDone }: { row: any; onClose: () => void; onDone: () => void }) {
  const [date, setDate] = useState('');
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  async function go() {
    if (!date || new Date(date + 'T23:59:59') < new Date()) return setErr('Новая дата должна быть в будущем');
    setBusy(true);
    try { await api.post(`${L}/assignees/${row.id}/extend`, { due_at: new Date(date + 'T23:59:59').toISOString(), reason }); toast({ title: 'Срок продлён', kind: 'success' }); onDone(); } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title={`Продлить срок: ${row.name}`} size="sm" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} onClick={go}>Продлить</Btn></>}>
      <div className="stack">
        <div className="small muted">Текущий срок: {row.due_at ? dmy(row.due_at) : 'нет'}</div>
        <Field label="Новый срок"><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} autoFocus /></Field>
        <Field label="Причина (необязательно)"><Input value={reason} maxLength={300} onChange={(e) => setReason(e.target.value)} /></Field>
        {err && <div className="err">{err}</div>}
      </div>
    </Modal>
  );
}

const ACTIONS: Record<string, string> = { create: 'Назначено', remind: 'Напоминание', extend: 'Срок продлён', revoke: 'Отозвано', restore: 'Возвращено', cancel: 'Назначение отменено', done: 'Выполнено', cycle: 'Новый цикл' };
function LogModal({ row, onClose }: { row: any; onClose: () => void }) {
  const { data } = useQuery<any[]>(`learn:asg:log:${row.id}`, () => api.get(`${L}/assignees/${row.id}/log`), { stale: 0 });
  return (
    <Modal title={`История: ${row.name}`} size="sm" onClose={onClose}>
      {!data ? <Skel h={80} /> : !data.length ? <div className="muted">Событий нет</div> : (
        <div className="lmLog">{data.map((l, i) => <div key={i}><b>{ACTIONS[l.action] || l.action}</b><span className="tiny muted">{dmyTime(l.at)}{l.actor ? ` · ${l.actor}` : ''}</span>{l.data?.reason && <div className="small">{l.data.reason}</div>}</div>)}</div>
      )}
    </Modal>
  );
}
