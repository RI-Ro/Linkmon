// LMS: статистика обучения для ответственного за обучение (своё подразделение и дочерние) и администратора (вся компания).
import React, { useEffect, useMemo, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { BarChart, Donut, HBars, LineChart } from '../../admin/charts';
import { invalidate, useQuery } from '../../lib/query';
import { Link, navigate, useSearchParams, useTitle } from '../../lib/router';
import { toast } from '../../lib/store';
import { cx, plural, useDebounced } from '../../lib/util';
import { Badge, Btn, Empty, ErrorBox, Pager, Select, Skel } from '../../ui';
import { L } from './common';
import { Bar, DueChip, ORDER_LABEL, StatusBadge, csvHref, dmy, dmyTime, hm, ratio, score1, useStatsMe } from './lms-common';

type SP = ReturnType<typeof useSearchParams>;
const fmtWeek = (d: string) => d.slice(8, 10) + '.' + d.slice(5, 7);

/** Общие фильтры статистики живут в адресной строке: dept, from, to, type, id, tab. */
function useF() {
  const [sp, setSp] = useSearchParams();
  const f = { dept: sp.get('dept') || '', from: sp.get('from') || '', to: sp.get('to') || '', type: sp.get('type') || '', id: sp.get('id') || '' };
  const qs = (extra: Record<string, string | number | undefined | null> = {}) => {
    const u = new URLSearchParams();
    Object.entries({ ...f, ...extra }).forEach(([k, v]) => { if (v != null && v !== '' && v !== 0) u.set(k, String(v)); });
    return u.toString();
  };
  return { sp, setSp, f, qs };
}

function NoAccess() {
  return <div className="card"><Empty icon={I.Lock} title="Недостаточно прав">Статистику обучения видят администратор и ответственный за обучение — в пределах своего подразделения и дочерних.</Empty></div>;
}

function useDeptOptions(enabled: boolean) {
  const q = useQuery<{ items: any[] }>(enabled ? 'learn:stats:depts-all' : null, () => api.get(`${L}/stats/departments`), { stale: 30000 });
  const opts = useMemo(() => {
    const items = q.data?.items || [];
    const ids = new Set(items.map((d) => d.id));
    const kids = new Map<number | null, any[]>();
    items.forEach((d) => { const p = d.parent_id != null && ids.has(d.parent_id) ? d.parent_id : null; kids.set(p, [...(kids.get(p) || []), d]); });
    const out: { id: number; name: string; depth: number }[] = [];
    const walk = (p: number | null, depth: number) => (kids.get(p) || []).forEach((d) => { out.push({ id: d.id, name: d.name, depth }); walk(d.id, depth + 1); });
    walk(null, 0);
    return out;
  }, [q.data]);
  return opts;
}

function FilterBar({ children, me, compact }: { children?: React.ReactNode; me: { all?: boolean; roots?: { id: number; name: string }[] }; compact?: boolean }) {
  const { f, setSp } = useF();
  const depts = useDeptOptions(true);
  const set = (p: Record<string, string | null>) => setSp({ ...p, page: null });
  return (
    <div className="card padS lmFilterBar">
      <label className="lmFl"><span>Подразделение</span>
        <Select value={f.dept} onChange={(e) => set({ dept: e.target.value || null })}>
          <option value="">{me.all ? 'Вся компания' : 'Вся моя область'}</option>
          {depts.map((d) => <option key={d.id} value={d.id}>{'  '.repeat(d.depth) + d.name}</option>)}
        </Select>
      </label>
      {!compact && <><label className="lmFl"><span>Назначено с</span><input type="date" className="inp" value={f.from} onChange={(e) => set({ from: e.target.value || null })} /></label>
      <label className="lmFl"><span>по</span><input type="date" className="inp" value={f.to} onChange={(e) => set({ to: e.target.value || null })} /></label>
      <label className="lmFl"><span>Тип</span>
        <Select value={f.type} onChange={(e) => set({ type: e.target.value || null, id: null })}><option value="">Курсы и тесты</option><option value="course">Только курсы</option><option value="test">Только тесты</option></Select>
      </label></>}
      {(f.dept || f.from || f.to || f.type) && <Btn size="sm" kind="ghost" onClick={() => set({ dept: null, from: null, to: null, type: null, id: null })}><I.X size={14} /> Сбросить</Btn>}
      {children}
    </div>
  );
}

function Kpi({ v, l, kind, sub }: { v: React.ReactNode; l: string; kind?: 'bad' | 'ok' | 'warn'; sub?: string }) {
  return <div className={cx('card lmKpi', kind)}><b>{v}</b><span>{l}</span>{sub && <small>{sub}</small>}</div>;
}

// ---------------------------------------------------------------- главная страница статистики

const TABS = [['overview', 'Обзор'], ['depts', 'Подразделения'], ['users', 'Сотрудники'], ['courses', 'Курсы'], ['tests', 'Тесты'], ['overdue', 'Просрочки']] as const;

export function StatsPage() {
  useTitle('Статистика обучения');
  const sm = useStatsMe();
  const { sp, setSp } = useF();
  if (sm.error && !sm.data) return <ErrorBox error={sm.error} retry={sm.refetch} />;
  if (!sm.data) return <Skel h={200} />;
  if (!sm.data.manager) return <NoAccess />;
  const tab = TABS.find((t) => t[0] === sp.get('tab'))?.[0] || 'overview';
  return (
    <div className="stack">
      {!sm.data.all && (
        <div className="notice"><I.Shield size={18} /> Область статистики: {sm.data.roots?.length ? sm.data.roots.map((r) => r.name).join(', ') : 'ваше подразделение'} и все дочерние подразделения.</div>
      )}
      <FilterBar me={sm.data} />
      <div className="chips">
        {TABS.map(([k, l]) => <button key={k} className={cx('chip', tab === k && 'on')} onClick={() => setSp({ tab: k === 'overview' ? null : k, page: null })}>{l}</button>)}
        <span className="sp" />
        <Link className="btn" to="/learning/assignments"><I.UserPlus size={16} /> Назначения</Link>
      </div>
      {tab === 'overview' ? <Overview /> : tab === 'depts' ? <DeptsTab /> : tab === 'users' ? <UsersTable /> : tab === 'courses' ? <TargetsTab type="course" /> : tab === 'tests' ? <TargetsTab type="test" /> : <OverdueTab />}
    </div>
  );
}

// ---------------------------------------------------------------- обзор

function Overview() {
  const { qs, setSp } = useF();
  const { data, error, refetch } = useQuery<any>(`learn:stats:ov:${qs()}`, () => api.get(`${L}/stats/overview?${qs()}`), { stale: 10000, keepPrevious: true });
  const depts = useQuery<{ items: any[] }>(`learn:stats:depts:${qs()}`, () => api.get(`${L}/stats/departments?${qs()}`), { stale: 10000, keepPrevious: true });
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data) return <div className="lmKpis">{[0, 1, 2, 3].map((i) => <div key={i} className="card pad"><Skel h={46} /></div>)}</div>;
  const a = data.assignments, at = data.attempts, ce = data.certs;
  const notStarted = Math.max(0, a.total - a.done - a.progress - (a.overdue - (a.progress_overdue || 0)));
  const rollup = rollupDepts(depts.data?.items || []);
  const worst = rollup.filter((d) => d.total > 0).map((d) => ({ ...d, rate: ratio(d.done, d.total) })).sort((x, y) => y.overdue - x.overdue || x.rate - y.rate).slice(0, 8);
  const trend = data.trend || [];
  return (
    <div className="stack">
      <div className="lmKpis">
        <Kpi v={a.total} l="назначений" sub={`сотрудников в области: ${data.employees.employees}`} />
        <Kpi v={a.progress} l="в процессе" />
        <Kpi v={a.done} l="завершено" kind="ok" sub={`${ratio(a.done, a.total)}% от назначенного`} />
        <Kpi v={a.overdue} l="просрочено" kind={a.overdue > 0 ? 'bad' : undefined} sub={a.overdue > 0 ? `у ${plural(a.overdue_users, ['сотрудника', 'сотрудников', 'сотрудников'])}` : undefined} />
        <Kpi v={score1(a.avg_score)} l="средний балл" />
        <Kpi v={at.attempts} l="попыток тестов за 30 дней" sub={at.attempts ? `сдано ${ratio(at.passed, at.attempts)}%` : undefined} />
        <Kpi v={ce.valid} l="действующих сертификатов" kind="ok" />
        <Kpi v={ce.soon} l="истекают за 30 дней" kind={ce.soon > 0 ? 'warn' : undefined} />
      </div>
      <div className="lmCols2">
        <div className="card pad"><LineChart area title="Динамика по неделям" sub="назначено и завершено" labels={trend.map((t: any) => t.week)} labelFmt={fmtWeek} csvName="learning-trend" height={220}
          series={[{ id: 'a', name: 'Назначено', values: trend.map((t: any) => t.assigned) }, { id: 'c', name: 'Завершено', values: trend.map((t: any) => t.completed) }]} /></div>
        <div className="card pad"><Donut title="Состояние назначений" csvName="learning-status" items={[{ id: 'done', label: 'Завершено', value: a.done }, { id: 'progress', label: 'В процессе (в срок)', value: a.progress - (a.progress_overdue || 0) }, { id: 'overdue', label: 'Просрочено', value: a.overdue }, { id: 'new', label: 'Не начато', value: notStarted }]} /></div>
      </div>
      <div className="card pad">
        <HBars title="Подразделения с наибольшими просрочками" sub="клик — сотрудники подразделения" csvName="learning-overdue-by-dept" empty="Просрочек нет"
          items={worst.filter((d) => d.overdue > 0).map((d) => ({ id: d.id, label: d.name, value: d.overdue, sub: `завершено ${d.rate}%` }))}
          onPick={(it) => setSp({ tab: 'users', dept: String(it.id), status: 'overdue', page: null })} />
      </div>
    </div>
  );
}

interface DNode { id: number; parent_id: number | null; name: string; employees: number; total: number; progress: number; done: number; overdue: number; score_sum: number; score_n: number; depth: number; kids: DNode[] }

/** Итоги по подразделению включают дочерние (клиентская свёртка поддерева). */
function rollupDepts(items: any[]): DNode[] {
  const ids = new Set(items.map((d) => d.id));
  const by = new Map<number, DNode>();
  items.forEach((d) => by.set(d.id, { ...d, depth: 0, kids: [] }));
  const roots: DNode[] = [];
  by.forEach((n) => { const p = n.parent_id != null && ids.has(n.parent_id) ? by.get(n.parent_id)! : null; p ? p.kids.push(n) : roots.push(n); });
  const out: DNode[] = [];
  const walk = (n: DNode, depth: number): void => {
    n.depth = depth;
    n.kids.forEach((k) => walk(k, depth + 1));
    n.kids.forEach((k) => { n.employees += k.employees; n.total += k.total; n.progress += k.progress; n.done += k.done; n.overdue += k.overdue; n.score_sum += k.score_sum; n.score_n += k.score_n; });
  };
  roots.forEach((r) => walk(r, 0));
  const flat = (n: DNode) => { out.push(n); n.kids.forEach(flat); };
  roots.forEach(flat);
  return out;
}

// ---------------------------------------------------------------- подразделения

function DeptsTab() {
  const { qs, setSp, f } = useF();
  const { data, error, refetch } = useQuery<{ items: any[] }>(`learn:stats:depts:${qs()}`, () => api.get(`${L}/stats/departments?${qs()}`), { stale: 10000, keepPrevious: true });
  const [open, setOpen] = useState<Set<number>>(new Set());
  const rows = useMemo(() => rollupDepts(data?.items || []), [data]);
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data) return <Skel h={240} />;
  const hidden = new Set<number>();
  rows.forEach((n) => { if (n.kids.length && !open.has(n.id)) { const w = (k: DNode): void => { hidden.add(k.id); k.kids.forEach(w); }; n.kids.forEach(w); } });
  const shown = rows.filter((n) => !hidden.has(n.id) && (!f.dept || true));
  return (
    <div className="stack">
      <div className="row"><div className="sp muted small">Итоги по подразделению включают дочерние. Нажмите на подразделение, чтобы увидеть сотрудников.</div>
        <a className="btn" href={csvHref('stats/export/departments', { from: f.from, to: f.to, type: f.type, id: f.id, dept: f.dept })}><I.Download size={16} /> CSV</a></div>
      {!rows.length ? <div className="card"><Empty icon={I.Building} title="Нет данных" /></div> : (
        <div className="card tblW">
          <table className="tbl">
            <thead><tr><th>Подразделение</th><th>Сотр.</th><th>Назначено</th><th>В процессе</th><th>Завершено</th><th>Просрочено</th><th style={{ minWidth: 150 }}>Прохождение</th><th>Ср. балл</th></tr></thead>
            <tbody>
              {shown.map((d) => (
                <tr key={d.id}>
                  <td style={{ paddingLeft: 14 + d.depth * 18 }}>
                    <div className="row" style={{ gap: 4 }}>
                      {d.kids.length > 0 ? <button className={cx('lnTog', open.has(d.id) && 'open')} aria-label="Раскрыть" onClick={() => setOpen((s) => { const n = new Set(s); n.has(d.id) ? n.delete(d.id) : n.add(d.id); return n; })}><I.ChevronRight size={15} /></button> : <span style={{ width: 22 }} />}
                      <a href="#" className="bold" onClick={(e) => { e.preventDefault(); setSp({ tab: 'users', dept: String(d.id), page: null }); }}>{d.name}</a>
                    </div>
                  </td>
                  <td>{d.employees}</td><td>{d.total}</td><td>{d.progress}</td><td>{d.done}</td>
                  <td>{d.overdue > 0 ? <Badge kind="dng">{d.overdue}</Badge> : 0}</td>
                  <td><div className="row" style={{ gap: 8 }}><div className="sp"><Bar p={ratio(d.done, d.total)} thin /></div><span className="small">{d.total ? ratio(d.done, d.total) + '%' : '—'}</span></div></td>
                  <td>{d.score_n ? score1(d.score_sum / d.score_n) : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- сотрудники

export function UsersTable({ fixed }: { fixed?: { type: string; id: number } }) {
  const { sp, setSp, f, qs } = useF();
  const page = +(sp.get('page') || 1), q = sp.get('q') || '', status = sp.get('status') || '', sort = sp.get('sort') || 'name';
  const [qIn, setQIn] = useState(q);
  const dq = useDebounced(qIn, 250);
  useEffect(() => { if (dq.trim() !== q) setSp({ q: dq.trim() || null, page: null }); }, [dq]);
  const extra = { page, q, status, sort, ...(fixed ? { type: fixed.type, id: fixed.id } : {}) };
  const { data, error, refetch } = useQuery<{ items: any[]; total: number; per: number }>(`learn:stats:users:${qs(extra)}`, () => api.get(`${L}/stats/users?${qs(extra)}`), { stale: 8000, keepPrevious: true });
  const SORTS: [string, string][] = [['name', 'По фамилии'], ['overdue', 'Больше просрочек'], ['done', 'Больше завершено'], ['total', 'Больше назначено'], ['score', 'По среднему баллу'], ['last', 'По активности'], ['dept', 'По подразделению']];
  return (
    <div className="stack">
      <div className="lnBar">
        <div className="lnSearch"><I.Search size={17} /><input value={qIn} placeholder="Поиск сотрудника…" onChange={(e) => setQIn(e.target.value)} aria-label="Поиск" /></div>
        <Select value={status} onChange={(e) => setSp({ status: e.target.value || null, page: null })} aria-label="Статус"><option value="">Все сотрудники</option><option value="overdue">Есть просрочки</option><option value="open">Не всё завершено</option><option value="done">Всё завершено</option><option value="none">Ничего не назначено</option></Select>
        <Select value={sort} onChange={(e) => setSp({ sort: e.target.value === 'name' ? null : e.target.value, page: null })} aria-label="Сортировка">{SORTS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select>
        <a className="btn" href={csvHref('stats/export/users', { from: f.from, to: f.to, dept: f.dept, q, status, sort, type: fixed?.type || f.type, id: fixed?.id || f.id })}><I.Download size={16} /> CSV</a>
      </div>
      {error && !data ? <ErrorBox error={error} retry={refetch} /> : !data ? <Skel h={240} /> : !data.items.length ? <div className="card"><Empty icon={I.Users} title="Сотрудники не найдены">Измените фильтры</Empty></div> : (
        <div className="card tblW">
          <table className="tbl">
            <thead><tr><th>Сотрудник</th><th>Подразделение</th><th>Назначено</th><th>В процессе</th><th>Завершено</th><th>Просрочено</th><th style={{ minWidth: 110 }}>Прохождение</th><th>Ср. балл</th><th>Активность</th></tr></thead>
            <tbody>
              {data.items.map((u) => (
                <tr key={u.id}>
                  <td><Link to={`/learning/stats/user/${u.id}`} className="bold">{u.name}</Link><div className="tiny muted">{u.job_title}</div></td>
                  <td className="small">{u.department || '—'}</td>
                  <td>{u.total}</td><td>{u.progress}</td><td>{u.done}</td>
                  <td>{u.overdue > 0 ? <Badge kind="dng">{u.overdue}</Badge> : 0}</td>
                  <td><div className="row" style={{ gap: 6 }}><div className="sp"><Bar p={ratio(u.done, u.total)} thin /></div><span className="tiny">{u.total ? ratio(u.done, u.total) + '%' : '—'}</span></div></td>
                  <td>{score1(u.score)}</td>
                  <td className="small muted">{dmy(u.last_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {data && data.total > data.per && <Pager page={page} total={data.total} per={data.per} onChange={(p) => setSp({ page: p > 1 ? p : null }, false)} />}
      {data && <div className="small muted">Всего сотрудников: {data.total}</div>}
    </div>
  );
}

// ---------------------------------------------------------------- курсы и тесты

function TargetsTab({ type }: { type: 'course' | 'test' }) {
  const { sp, setSp, f, qs } = useF();
  const q = sp.get('q') || '';
  const [qIn, setQIn] = useState(q);
  const dq = useDebounced(qIn, 250);
  useEffect(() => { if (dq.trim() !== q) setSp({ q: dq.trim() || null }); }, [dq]);
  const { data, error, refetch } = useQuery<{ items: any[] }>(`learn:stats:targets:${type}:${qs({ q })}`, () => api.get(`${L}/stats/targets?${qs({ q, type })}`), { stale: 10000, keepPrevious: true });
  const items = data?.items || [];
  const isC = type === 'course';
  const link = (id: number) => `/learning/stats/${type}/${id}?${qs({ type: null, id: null })}`;
  return (
    <div className="stack">
      <div className="lnBar">
        <div className="lnSearch"><I.Search size={17} /><input value={qIn} placeholder={isC ? 'Поиск курса…' : 'Поиск теста…'} onChange={(e) => setQIn(e.target.value)} aria-label="Поиск" /></div>
        <a className="btn" href={csvHref('stats/export/targets', { type, dept: f.dept, from: f.from, to: f.to, q })}><I.Download size={16} /> CSV</a>
        {isC && <a className="btn" href={csvHref('stats/export/matrix', { dept: f.dept })} title="Сотрудники × курсы: статус и дата завершения"><I.Download size={16} /> Матрица</a>}
      </div>
      {error && !data ? <ErrorBox error={error} retry={refetch} /> : !data ? <Skel h={200} /> : !items.length ? <div className="card"><Empty icon={I.GradCap} title="Нет данных">По выбранным фильтрам нет {isC ? 'прохождений курсов' : 'попыток тестов'}</Empty></div> : (
        <>
          <div className="card pad"><HBars title={isC ? 'Завершили курс' : 'Сдали тест'} sub="сотрудников; клик — подробная статистика" csvName={`learning-${type}s`}
            items={items.slice(0, 10).map((t) => ({ id: t.id, label: t.title, value: isC ? t.completed : t.users_passed, sub: isC ? `начали ${t.enrolled}` : `участвовали ${t.users}` }))} onPick={(it) => navigate(link(+it.id!))} /></div>
          <div className="card tblW">
            <table className="tbl">
              {isC ? (
                <>
                  <thead><tr><th>Курс</th><th>Начали</th><th>В процессе</th><th>Завершили</th><th>% завершения</th><th>Ср. балл</th><th>Ср. время</th><th>Истёк срок</th></tr></thead>
                  <tbody>{items.map((t) => <tr key={t.id}><td><Link to={link(t.id)} className="bold">{t.title}</Link></td><td>{t.enrolled}</td><td>{t.progress}</td><td>{t.completed}</td><td>{ratio(t.completed, t.enrolled)}%</td><td>{score1(t.avg_score)}</td><td>{hm(t.avg_sec)}</td><td>{t.expired || 0}</td></tr>)}</tbody>
                </>
              ) : (
                <>
                  <thead><tr><th>Тест</th><th>Попыток</th><th>Участников</th><th>Сдали</th><th>% сдавших</th><th>С первой попытки</th><th>Ср. результат</th><th>Ср. время</th></tr></thead>
                  <tbody>{items.map((t) => <tr key={t.id}><td><Link to={link(t.id)} className="bold">{t.title}</Link></td><td>{t.attempts}</td><td>{t.users}</td><td>{t.users_passed}</td><td>{ratio(t.users_passed, t.users)}%</td><td>{t.first_n ? ratio(t.first_passed, t.first_n) + '%' : '—'}</td><td>{score1(t.avg_percent)}</td><td>{hm(t.avg_sec)}</td></tr>)}</tbody>
                </>
              )}
            </table>
          </div>
        </>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- просрочки

function OverdueTab() {
  const { sp, setSp, f, qs } = useF();
  const page = +(sp.get('page') || 1), q = sp.get('q') || '', all = sp.get('all') === '1';
  const [qIn, setQIn] = useState(q);
  const dq = useDebounced(qIn, 250);
  useEffect(() => { if (dq.trim() !== q) setSp({ q: dq.trim() || null, page: null }); }, [dq]);
  const extra = { page, q, mandatory: all ? '0' : '' };
  const { data, error, refetch } = useQuery<any>(`learn:stats:od:${qs(extra)}`, () => api.get(`${L}/stats/overdue?${qs(extra)}`), { stale: 5000, keepPrevious: true });
  const [sel, setSel] = useState<Set<number>>(new Set());
  useEffect(() => setSel(new Set()), [page, q, all, f.dept, f.type]);
  async function remind(ids: number[]) {
    try {
      const r = await api.post(`${L}/assignees/remind`, { ids });
      toast({ title: `Напоминаний отправлено: ${r.sent}`, body: r.skipped ? `Пропущено: ${r.skipped} (уже напоминали недавно)` : undefined, kind: 'success' });
      setSel(new Set()); invalidate('learn:stats:od'); refetch();
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  const items: any[] = data?.items || [];
  return (
    <div className="stack">
      <div className="lnBar">
        <div className="lnSearch"><I.Search size={17} /><input value={qIn} placeholder="Сотрудник…" onChange={(e) => setQIn(e.target.value)} aria-label="Поиск" /></div>
        <label className="chip" style={{ cursor: 'pointer' }}><input type="checkbox" checked={all} onChange={(e) => setSp({ all: e.target.checked ? '1' : null, page: null })} style={{ marginRight: 6 }} />и необязательное</label>
        <a className="btn" href={csvHref('stats/export/overdue', { dept: f.dept, type: f.type, q, mandatory: all ? '0' : '' })}><I.Download size={16} /> CSV</a>
      </div>
      {data && <div className="small muted">Просроченных заданий: <b>{data.total}</b> у {plural(data.users, ['сотрудника', 'сотрудников', 'сотрудников'])}</div>}
      {sel.size > 0 && <div className="lnSelBar card"><b>Выбрано: {sel.size}</b><div className="sp" /><Btn size="sm" kind="pri" onClick={() => remind([...sel])}><I.Bell size={15} /> Напомнить</Btn><Btn size="sm" kind="ghost" onClick={() => setSel(new Set())}>Снять выбор</Btn></div>}
      {error && !data ? <ErrorBox error={error} retry={refetch} /> : !data ? <Skel h={200} /> : !items.length ? <div className="card"><Empty icon={I.Check} title="Просрочек нет">Все задания в области выполняются в срок</Empty></div> : (
        <div className="card tblW">
          <table className="tbl">
            <thead><tr><th style={{ width: 34 }}><input type="checkbox" className="lnChk" aria-label="Выбрать все" checked={sel.size === items.length} onChange={(e) => setSel(e.target.checked ? new Set(items.map((x) => x.id)) : new Set())} /></th><th>Сотрудник</th><th>Что назначено</th><th>Срок</th><th>Просрочка</th><th>Напоминали</th></tr></thead>
            <tbody>
              {items.map((r) => (
                <tr key={r.id}>
                  <td><input type="checkbox" className="lnChk" aria-label="Выбрать" checked={sel.has(r.id)} onChange={() => setSel((s) => { const n = new Set(s); n.has(r.id) ? n.delete(r.id) : n.add(r.id); return n; })} /></td>
                  <td><Link to={`/learning/stats/user/${r.user_id}`} className="bold">{r.name}</Link><div className="tiny muted">{r.department}</div></td>
                  <td className="small"><Link to={r.target_type === 'course' ? `/learning/courses/${r.target_id}` : `/learning/tests/${r.target_id}`}>{r.title}</Link><div className="tiny muted">{r.target_type === 'course' ? 'Курс' : 'Тест'}{r.high && ' · высокий приоритет'}</div></td>
                  <td className="small">{dmy(r.due_at)}</td>
                  <td><Badge kind="dng">{r.days} дн.</Badge></td>
                  <td className="small muted">{r.manual_remind_at ? dmyTime(r.manual_remind_at) : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {data && data.total > data.per && <Pager page={page} total={data.total} per={data.per} onChange={(p) => setSp({ page: p > 1 ? p : null }, false)} />}
    </div>
  );
}

// ---------------------------------------------------------------- подробно: курс / тест

export function TargetStatsPage({ type, id }: { type: 'course' | 'test'; id: number }) {
  const sm = useStatsMe();
  const { qs, f } = useF();
  const { data, error, refetch } = useQuery<any>(sm.data?.manager ? `learn:stats:t:${type}:${id}:${qs()}` : null, () => api.get(`${L}/stats/targets/${type}/${id}?${qs({ type: null, id: null, from: null, to: null })}`), { stale: 8000, keepPrevious: true });
  useTitle(data?.title ? 'Статистика: ' + data.title : 'Статистика');
  if (sm.data && !sm.data.manager) return <NoAccess />;
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data || !sm.data) return <div className="card pad stack"><Skel h={26} w="40%" /><Skel h={120} /></div>;
  const s = data.summary;
  const isC = type === 'course';
  const hist = Array.from({ length: 10 }, (_, i) => data.histogram.find((h: any) => h.b === i)?.n || 0);
  const labels = hist.map((_, i) => `${i * 10}–${i === 9 ? 100 : i * 10 + 9}`);
  return (
    <div className="stack">
      <div className="lnHead">
        <div className="sp" style={{ minWidth: 0 }}>
          <div className="crumbs"><Link to="/learning/stats">Статистика</Link><I.ChevronRight size={14} /><Link to={`/learning/stats?tab=${isC ? 'courses' : 'tests'}`}>{isC ? 'Курсы' : 'Тесты'}</Link></div>
          <h2 className="lnTitle">{data.title}</h2>
        </div>
        <div className="rowW">
          <Link className="btn" to={isC ? `/learning/courses/${id}` : `/learning/tests/${id}`}>Открыть {isC ? 'курс' : 'тест'}</Link>
          <Link className="btn" to={`/learning/assignments?type=${type}`}>Назначения</Link>
          <Link className="btn pri" to={`/learning/assignments/new?type=${type}&target=${id}`}><I.UserPlus size={16} /> Назначить</Link>
        </div>
      </div>
      <FilterBar me={sm.data} compact />
      <div className="lmKpis">
        {isC ? (
          <>
            <Kpi v={s.enrolled} l="начали" /><Kpi v={s.progress} l="в процессе" sub={s.progress ? `средний прогресс ${s.avg_progress}%` : undefined} />
            <Kpi v={s.completed} l="завершили" kind="ok" sub={`${ratio(s.completed, s.enrolled)}% от начавших`} /><Kpi v={score1(s.avg_score)} l="средний балл" /><Kpi v={hm(s.avg_sec)} l="среднее время" />
          </>
        ) : (
          <>
            <Kpi v={s.attempts} l="попыток" /><Kpi v={s.users} l="участников" /><Kpi v={s.users_passed} l="сдали" kind="ok" sub={`${ratio(s.users_passed, s.users)}% участников`} />
            <Kpi v={s.first_n ? ratio(s.first_passed, s.first_n) + '%' : '—'} l="сдали с первой попытки" /><Kpi v={score1(s.avg_percent)} l="средний результат" /><Kpi v={hm(s.avg_sec)} l="среднее время" />
          </>
        )}
      </div>
      <div className="lmCols2">
        <div className="card pad"><BarChart title="Распределение результатов" sub={isC ? 'число сотрудников по диапазонам баллов, %' : 'число попыток по диапазонам результата, %'} labels={labels} csvName={`learning-${type}-${id}-hist`} height={200} series={[{ id: 'n', name: isC ? 'Сотрудников' : 'Попыток', values: hist }]} /></div>
        <div className="card pad">
          {isC ? <LineChart title="Динамика по неделям" sub="начали и завершили" labels={data.weekly.map((w: any) => w.week)} labelFmt={fmtWeek} csvName={`learning-course-${id}-weekly`} height={200}
            series={[{ id: 's', name: 'Начали', values: data.weekly.map((w: any) => w.started) }, { id: 'c', name: 'Завершили', values: data.weekly.map((w: any) => w.completed) }]} />
            : <LineChart title="Динамика по неделям" sub="попытки, сдано и средний результат" labels={data.weekly.map((w: any) => w.week)} labelFmt={fmtWeek} csvName={`learning-test-${id}-weekly`} height={200}
              series={[{ id: 'a', name: 'Попыток', values: data.weekly.map((w: any) => w.attempts) }, { id: 'p', name: 'Сдано', values: data.weekly.map((w: any) => w.passed) }]} />}
        </div>
      </div>
      {isC ? (
        <div className="card">
          <div className="lmCardHd"><h3 className="lnH3">Шаги курса</h3><span className="small muted">где сотрудники застревают</span></div>
          <div className="tblW"><table className="tbl">
            <thead><tr><th>#</th><th>Шаг</th><th>Открыли</th><th>Прошли</th><th style={{ minWidth: 120 }}>Доля прошедших</th><th>Ср. время</th><th>Ср. балл</th></tr></thead>
            <tbody>{data.steps.map((st: any, i: number) => (
              <tr key={st.id}><td className="muted">{i + 1}</td><td><b>{st.title}</b><div className="tiny muted">{({ item: 'Материал', wiki: 'База знаний', video: 'Видео', link: 'Ссылка', test: 'Тест', ack: 'Ознакомление' } as any)[st.kind]}{!st.required && ' · по желанию'}</div></td>
                <td>{st.opened}</td><td>{st.done}</td><td><div className="row" style={{ gap: 6 }}><div className="sp"><Bar p={ratio(st.done, s.enrolled)} thin /></div><span className="tiny">{ratio(st.done, s.enrolled)}%</span></div></td><td>{hm(st.avg_sec)}</td><td>{score1(st.avg_score)}</td></tr>
            ))}</tbody></table></div>
        </div>
      ) : (
        <div className="card">
          <div className="lmCardHd"><h3 className="lnH3">Разбор вопросов</h3><span className="small muted">по последним попыткам; сложные вопросы — сверху</span></div>
          <div className="tblW"><table className="tbl">
            <thead><tr><th>Вопрос</th><th>Ответов</th><th style={{ minWidth: 130 }}>Верно</th><th>Пропущено</th><th>Частые ошибки</th></tr></thead>
            <tbody>{[...data.questions].sort((a: any, b: any) => ratio(a.correct, a.n) - ratio(b.correct, b.n)).map((qq: any) => (
              <tr key={qq.id}><td style={{ maxWidth: 360 }}>{qq.text}</td><td>{qq.n}</td>
                <td><div className="row" style={{ gap: 6 }}><div className="sp"><Bar p={ratio(qq.correct, qq.n)} thin ok={ratio(qq.correct, qq.n) >= 70} /></div><span className="tiny">{ratio(qq.correct, qq.n)}%</span></div></td>
                <td>{qq.skipped}</td><td className="small">{(qq.wrong || []).slice(0, 3).map((w: any, i: number) => <div key={i} className="clip" style={{ maxWidth: 260 }} title={w.text}>«{w.text}» · {w.n}</div>)}</td></tr>
            ))}</tbody></table></div>
        </div>
      )}
      <div className="stackS">
        <h3 className="lnH3">Сотрудники</h3>
        <UsersTable fixed={{ type, id }} />
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- подробно: сотрудник

export function UserStatsPage({ id }: { id: number }) {
  const sm = useStatsMe();
  const { data, error } = useQuery<any>(sm.data?.manager ? `learn:stats:user:${id}` : null, () => api.get(`${L}/stats/users/${id}`), { stale: 5000 });
  useTitle(data?.user?.name ? 'Обучение: ' + data.user.name : 'Обучение сотрудника');
  if (sm.data && !sm.data.manager) return <NoAccess />;
  if (error && !data) return <ErrorBox error={error} />;
  if (!data) return <div className="card pad stack"><Skel h={26} w="40%" /><Skel h={160} /></div>;
  const u = data.user;
  const open = data.assignments.filter((a: any) => a.status < 2);
  const overdue = open.filter((a: any) => a.overdue).length;
  return (
    <div className="stack">
      <div className="lnHead">
        <div className="sp">
          <div className="crumbs"><Link to="/learning/stats">Статистика</Link><I.ChevronRight size={14} /><Link to="/learning/stats?tab=users">Сотрудники</Link></div>
          <h2 className="lnTitle">{u.name}</h2>
          <div className="muted small">{u.job_title}{u.department && ` · ${u.department}`}</div>
        </div>
        <div className="rowW"><Link className="btn" to={`/people/${u.id}`}>Профиль</Link><Link className="btn pri" to={`/learning/assignments/new`}><I.UserPlus size={16} /> Назначить обучение</Link></div>
      </div>
      <div className="lmKpis">
        <Kpi v={data.assignments.length} l="назначений" /><Kpi v={data.assignments.filter((a: any) => a.status === 2).length} l="завершено" kind="ok" /><Kpi v={overdue} l="просрочено" kind={overdue ? 'bad' : undefined} /><Kpi v={data.certs.length} l="сертификатов" />
      </div>
      <Section title="Назначения" empty="Ничего не назначено" rows={data.assignments}>
        <thead><tr><th>Что</th><th>Статус</th><th>Назначено</th><th>Срок</th><th>Завершено</th><th>Балл</th></tr></thead>
        <tbody>{data.assignments.map((a: any) => <tr key={a.id}><td><Link to={a.target_type === 'course' ? `/learning/courses/${a.target_id}` : `/learning/tests/${a.target_id}`}>{a.title}</Link><div className="tiny muted">{a.target_type === 'course' ? 'Курс' : 'Тест'}{a.cycle > 1 && ` · цикл ${a.cycle}`}</div></td><td><StatusBadge status={a.status} overdue={a.overdue} /></td><td className="small">{dmy(a.assigned_at)}</td><td className="small"><DueChip due={a.due_at} status={a.status} /></td><td className="small">{dmy(a.done_at)}</td><td className="small">{score1(a.score)}</td></tr>)}</tbody>
      </Section>
      <Section title="Прохождение курсов" empty="Курсы не начинал(а)" rows={data.enrollments}>
        <thead><tr><th>Курс</th><th>Прогресс</th><th>Начат</th><th>Завершён</th><th>Действует до</th><th>Время</th><th>Балл</th></tr></thead>
        <tbody>{data.enrollments.map((e: any) => <tr key={e.id}><td><Link to={`/learning/courses/${e.id}`}>{e.title}</Link></td><td style={{ minWidth: 130 }}><div className="row" style={{ gap: 6 }}><div className="sp"><Bar p={e.status === 2 ? 100 : e.percent} thin /></div><span className="tiny">{e.status === 2 ? 100 : e.percent}%</span></div></td><td className="small">{dmy(e.started_at)}</td><td className="small">{dmy(e.completed_at)}</td><td className="small">{e.expires_at ? dmy(e.expires_at) : e.status === 2 ? 'бессрочно' : '—'}</td><td className="small">{hm(e.time_sec)}</td><td className="small">{score1(e.score)}</td></tr>)}</tbody>
      </Section>
      <Section title="Попытки тестов" empty="Попыток нет" rows={data.attempts}>
        <thead><tr><th>Тест</th><th>Попытка</th><th>Завершена</th><th>Результат</th><th>Время</th><th /></tr></thead>
        <tbody>{data.attempts.map((a: any) => <tr key={a.id}><td><Link to={`/learning/tests/${a.test_id}`}>{a.title}</Link>{a.course_id && <div className="tiny muted">в курсе</div>}</td><td>{a.no}</td><td className="small">{dmyTime(a.finished_at)}</td><td>{a.passed ? <Badge kind="ok">{score1(a.percent)} · сдан</Badge> : <Badge kind="dng">{score1(a.percent)} · не сдан</Badge>}</td><td className="small">{hm(a.duration_sec)}</td><td className="act"><Link className="btn ghost sm" to={`/learning/tests/attempt/${a.id}`}>Разбор</Link></td></tr>)}</tbody>
      </Section>
      <Section title="Сертификаты" empty="Сертификатов нет" rows={data.certs}>
        <thead><tr><th>Номер</th><th>Программа</th><th>Выдан</th><th>Действует до</th><th>Статус</th></tr></thead>
        <tbody>{data.certs.map((c: any) => <tr key={c.id}><td className="mono small"><Link to={`/learning/certificates/${c.id}`}>{c.number}</Link></td><td>{c.title}</td><td className="small">{dmy(c.issued_at)}</td><td className="small">{c.expires_at ? dmy(c.expires_at) : 'бессрочно'}</td><td><Badge kind={c.state === 'valid' ? 'ok' : c.state === 'expired' ? 'warn' : 'dng'}>{({ valid: 'Действителен', expired: 'Истёк', revoked: 'Отозван' } as any)[c.state]}</Badge></td></tr>)}</tbody>
      </Section>
    </div>
  );
}

function Section({ title, rows, empty, children }: { title: string; rows: any[]; empty: string; children: React.ReactNode }) {
  return (
    <div className="card">
      <div className="lmCardHd"><h3 className="lnH3">{title}</h3><span className="small muted">{rows.length}</span></div>
      {!rows.length ? <div className="padS small muted" style={{ padding: '4px 16px 16px' }}>{empty}</div> : <div className="tblW"><table className="tbl">{children}</table></div>}
    </div>
  );
}
