import React, { useEffect, useMemo, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { invalidate, prefetch, useQuery } from '../../lib/query';
import { Link, navigate } from '../../lib/router';
import { toast, useStore } from '../../lib/store';
import { cx, plural } from '../../lib/util';
import { usePersistSet } from '../../lib/persist';
import { Badge, Btn, Field, Input, Loading, Modal, Select, Skel, Textarea, UserPicker, usePopover } from '../../ui';
import { flattenDepts, useDepartments } from '../../ui/DeptSelect';

export const L = '/api/learning';
export type Kind = 'materials' | 'tests' | 'courses';

export interface LFolder {
  id: number; parent_id: number | null; name: string; description: string; visibility: 'company' | 'restricted';
  sort: number; owner_id: number | null; items_count: number; count: number; level: number;
}
export interface TreeData { folders: LFolder[]; done?: Record<string, number> }

export const KIND = {
  materials: { title: 'Материалы', root: 'Все материалы', one: ['материал', 'материала', 'материалов'] as [string, string, string], base: '/learning/materials' },
  tests: { title: 'Тесты', root: 'Все тесты', one: ['тест', 'теста', 'тестов'] as [string, string, string], base: '/learning/tests' },
  courses: { title: 'Курсы', root: 'Все курсы', one: ['курс', 'курса', 'курсов'] as [string, string, string], base: '/learning/courses' },
};

// ---------------------------------------------------------------- дерево

export interface Tree {
  list: LFolder[];
  byId: Map<number, LFolder>;
  kids: Map<number | null, LFolder[]>;
  total: Map<number, number>;
  done: Record<string, number>;
  /** от корня к папке (только доступные пользователю) */
  path(id: number): LFolder[];
  /** все потомки (включая саму) */
  subtree(id: number): number[];
}

export function buildTree(data?: TreeData): Tree {
  const list = data?.folders || [];
  const byId = new Map(list.map((f) => [f.id, f]));
  const kids = new Map<number | null, LFolder[]>();
  for (const f of list) {
    const p = f.parent_id != null && byId.has(f.parent_id) ? f.parent_id : null;
    if (!kids.has(p)) kids.set(p, []);
    kids.get(p)!.push(f);
  }
  const total = new Map<number, number>();
  const sum = (id: number): number => {
    if (total.has(id)) return total.get(id)!;
    let n = byId.get(id)!.count;
    for (const k of kids.get(id) || []) n += sum(k.id);
    total.set(id, n);
    return n;
  };
  list.forEach((f) => sum(f.id));
  return {
    list, byId, kids, total, done: data?.done || {},
    path(id) {
      const out: LFolder[] = [];
      let cur = byId.get(id);
      while (cur && out.length < 50) {
        out.unshift(cur);
        cur = cur.parent_id != null ? byId.get(cur.parent_id) : undefined;
      }
      return out;
    },
    subtree(id) {
      const out: number[] = [];
      const walk = (x: number) => { out.push(x); (kids.get(x) || []).forEach((k) => walk(k.id)); };
      if (byId.has(id)) walk(id);
      return out;
    },
  };
}

export function useTree(kind: Kind) {
  const q = useQuery<TreeData>(`learn:tree:${kind}`, () => api.get(`${L}/tree?kind=${kind}`), { stale: 20000, keepPrevious: true });
  const tree = useMemo(() => buildTree(q.data), [q.data]);
  return { ...q, tree };
}

export const refreshLearning = () => invalidate('learn:');

// ---------------------------------------------------------------- панель дерева

export function FolderTree({ kind, tree, selected, loading, onDropItems }: { kind: Kind; tree: Tree; selected: number; loading: boolean; onDropItems?: (folder: number, ids: number[]) => void }) {
  const [open, setOpen] = usePersistSet(`learn:exp:${kind}`);
  const K = KIND[kind];
  // раскрываем путь к выбранной папке
  useEffect(() => {
    if (!selected || !tree.byId.size) return;
    const anc = tree.path(selected).slice(0, -1).map((f) => f.id);
    if (anc.some((id) => !open.has(id))) setOpen((s) => { anc.forEach((id) => s.add(id)); return s; });
  }, [selected, tree.byId.size]);
  const [dropOn, setDropOn] = useState(0);
  const node = (f: LFolder, depth: number): React.ReactNode => {
    const kids = tree.kids.get(f.id) || [];
    const isOpen = open.has(f.id);
    return (
      <div key={f.id}>
        <div
          className={cx('lnNode', selected === f.id && 'on', dropOn === f.id && 'drop')}
          style={{ paddingLeft: 6 + depth * 16 }}
          onDragOver={(e) => { if (onDropItems && f.level >= 3 && e.dataTransfer.types.includes('application/x-learn-items')) { e.preventDefault(); setDropOn(f.id); } }}
          onDragLeave={() => setDropOn(0)}
          onDrop={(e) => {
            setDropOn(0);
            const raw = e.dataTransfer.getData('application/x-learn-items');
            if (onDropItems && raw) { e.preventDefault(); onDropItems(f.id, JSON.parse(raw)); }
          }}
        >
          <button className={cx('lnTog', !kids.length && 'none', isOpen && 'open')} aria-label={isOpen ? 'Свернуть' : 'Развернуть'}
            onClick={() => setOpen((s) => { s.has(f.id) ? s.delete(f.id) : s.add(f.id); return s; })}><I.ChevronRight size={15} /></button>
          <Link to={`${K.base}?folder=${f.id}`} className="lnLink" onMouseEnter={() => (kind === 'materials' ? prefetchFolder(f.id) : undefined)}>
            {selected === f.id ? <I.FolderOpen size={17} /> : <I.Folder size={17} />}
            <span className="clip sp">{f.name}</span>
            {f.visibility === 'restricted' && <I.Lock size={12} className="faint" />}
            {tree.total.get(f.id)! > 0 && <span className="lnCnt">{tree.total.get(f.id)}</span>}
          </Link>
        </div>
        {isOpen && kids.map((k) => node(k, depth + 1))}
      </div>
    );
  };
  const roots = tree.kids.get(null) || [];
  return (
    <nav className="lnTree card" aria-label="Папки">
      <Link to={K.base} className={cx('lnNode lnRoot', !selected && 'on')}><span className="lnLink"><I.Layers size={17} /><span className="sp">{K.root}</span></span></Link>
      {loading && !roots.length ? <div className="stackS" style={{ padding: 10 }}>{[0, 1, 2, 3].map((i) => <Skel key={i} h={26} />)}</div> : roots.map((f) => node(f, 0))}
      {!loading && !roots.length && <div className="small muted" style={{ padding: '10px 12px' }}>Папок пока нет</div>}
    </nav>
  );
}

export function prefetchFolder(id: number, order = 'manual') {
  prefetch(`learn:m:list:${id}:1:${order}:`, () => api.get(`${L}/materials?folder=${id}&page=1&order=${order}`));
}

// ---------------------------------------------------------------- оболочка: дерево + хлебные крошки + действия с папкой

export function Crumbs({ kind, tree, folder, tail }: { kind: Kind; tree: Tree; folder: number; tail?: string }) {
  const K = KIND[kind];
  const path = folder ? tree.path(folder) : [];
  return (
    <div className="crumbs" style={{ fontSize: 14 }}>
      <Link to={K.base}>{K.title}</Link>
      {path.map((f, i) => (
        <React.Fragment key={f.id}><I.ChevronRight size={14} />{i < path.length - 1 || tail ? <Link to={`${K.base}?folder=${f.id}`}>{f.name}</Link> : <span style={{ color: 'var(--text)', fontWeight: 600 }}>{f.name}</span>}</React.Fragment>
      ))}
      {tail && <><I.ChevronRight size={14} /><span style={{ color: 'var(--text)', fontWeight: 600 }}>{tail}</span></>}
    </div>
  );
}

export function FolderShell({ kind, tree, loading, folder, children, onDropItems }: { kind: Kind; tree: Tree; loading: boolean; folder: number; children: React.ReactNode; onDropItems?: (f: number, ids: number[]) => void }) {
  const me = useStore((s) => s.me)!;
  const K = KIND[kind];
  const cur = folder ? tree.byId.get(folder) : undefined;
  const kids = tree.kids.get(folder || null) || [];
  const [modal, setModal] = useState<null | { edit?: LFolder; parent?: number }>(null);
  const [move, setMove] = useState(false);
  const [acl, setAcl] = useState(false);
  const [showTree, setShowTree] = useState(false);
  const menu = usePopover();
  const canRoot = me.role !== 'user';
  const level = cur?.level ?? 0;
  const canAddFolder = folder ? level >= 3 : canRoot;

  async function remove() {
    if (!cur) return;
    if (!confirm(`Удалить папку «${cur.name}» со всем содержимым (вложенные папки, ${K.one[2]})? Действие необратимо.`)) return;
    try {
      await api.del(`${L}/folders/${cur.id}`);
      refreshLearning();
      toast({ title: 'Папка удалена', kind: 'success' });
      navigate(cur.parent_id && tree.byId.has(cur.parent_id) ? `${K.base}?folder=${cur.parent_id}` : K.base);
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }

  return (
    <div className="lnWrap">
      <aside className={cx('lnSide', showTree && 'open')}>
        <button className="btn lnSideBtn block" onClick={() => setShowTree(!showTree)}><I.Folder size={17} /><span className="sp clip" style={{ textAlign: 'left' }}>{cur ? cur.name : K.root}</span><I.ChevronDown size={16} /></button>
        <div className="lnSideBody"><FolderTree kind={kind} tree={tree} selected={folder} loading={loading} onDropItems={onDropItems} /></div>
      </aside>
      <div className="lnMain stack">
        <div className="lnHead">
          <div className="sp" style={{ minWidth: 0 }}>
            <Crumbs kind={kind} tree={tree} folder={folder} />
            <h2 className="lnTitle">{cur ? cur.name : K.root}{cur?.visibility === 'restricted' && <Badge><I.Lock size={11} /> Ограниченный доступ</Badge>}</h2>
            {cur?.description && <div className="muted small">{cur.description}</div>}
          </div>
          <div className="rowW" style={{ flex: 'none' }}>
            {canAddFolder && <Btn onClick={() => setModal({ parent: folder || undefined })}><I.Folder size={16} /> Папка</Btn>}
            {cur && level >= 3 && (
              <div style={{ position: 'relative' }} ref={menu.ref}>
                <Btn kind="ghost" icon onClick={() => menu.setOpen(!menu.open)} aria-label="Действия с папкой"><I.More size={18} /></Btn>
                {menu.open && (
                  <div className="menu" onClick={() => menu.setOpen(false)}>
                    <button onClick={() => setModal({ edit: cur })}><I.Edit size={16} /> Переименовать</button>
                    <button onClick={() => setMove(true)}><I.Folder size={16} /> Переместить…</button>
                    {level >= 4 && <button onClick={() => setAcl(true)}><I.Lock size={16} /> Права доступа</button>}
                    {level >= 4 && <><hr /><button style={{ color: 'var(--danger)' }} onClick={remove}><I.Trash size={16} /> Удалить папку</button></>}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
        {kids.length > 0 && (
          <div className="lnFolders">
            {kids.map((f) => <FolderCard key={f.id} kind={kind} f={f} tree={tree} />)}
          </div>
        )}
        {children}
      </div>
      {modal && <FolderModal kind={kind} parent={modal.parent} edit={modal.edit} onClose={() => setModal(null)} onSaved={(f, created) => { setModal(null); refreshLearning(); if (created) { navigate(`${K.base}?folder=${f.id}`); if (f.visibility === 'restricted') setTimeout(() => setAcl(true), 0); } }} />}
      {move && cur && <MoveFolderModal kind={kind} tree={tree} folder={cur} onClose={() => setMove(false)} />}
      {acl && cur && <LearnAclEditor folder={cur.id} onClose={() => setAcl(false)} />}
    </div>
  );
}

function FolderCard({ kind, f, tree }: { kind: Kind; f: LFolder; tree: Tree }) {
  const K = KIND[kind];
  const sub = (tree.kids.get(f.id) || []).length;
  const total = tree.total.get(f.id) || 0;
  const done = kind === 'materials' ? tree.done[f.id] || 0 : 0;
  return (
    <Link to={`${K.base}?folder=${f.id}`} className="lnFolder card" onMouseEnter={() => (kind === 'materials' ? prefetchFolder(f.id) : undefined)}>
      <span className="ico"><I.Folder size={22} /></span>
      <span className="sp" style={{ minWidth: 0 }}>
        <span className="bold clip" style={{ display: 'block' }}>{f.name}</span>
        <span className="tiny muted">{sub > 0 && plural(sub, ['папка', 'папки', 'папок']) + ' · '}{plural(total, K.one)}{kind === 'materials' && f.count > 0 && done > 0 ? ` · изучено ${done}` : ''}</span>
      </span>
      {f.visibility === 'restricted' && <I.Lock size={14} className="faint" />}
    </Link>
  );
}

// ---------------------------------------------------------------- папка: создание / переименование

function FolderModal({ kind, parent, edit, onClose, onSaved }: { kind: Kind; parent?: number; edit?: LFolder; onClose: () => void; onSaved: (f: any, created: boolean) => void }) {
  const [name, setName] = useState(edit?.name || '');
  const [desc, setDesc] = useState(edit?.description || '');
  const [vis, setVis] = useState<'company' | 'restricted'>('company');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  async function save() {
    if (!name.trim()) return setErr('Введите название папки');
    setBusy(true); setErr('');
    try {
      const r = edit ? await api.put(`${L}/folders/${edit.id}`, { name, description: desc, sort: edit.sort }) : await api.post(`${L}/folders`, { kind, parent_id: parent || null, name, description: desc, visibility: vis });
      onSaved(r, !edit);
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title={edit ? 'Переименовать папку' : 'Новая папка'} size="sm" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} onClick={save}>{edit ? 'Сохранить' : 'Создать'}</Btn></>}>
      <form className="stack" onSubmit={(e) => { e.preventDefault(); save(); }}>
        <Field label="Название"><Input value={name} onChange={(e) => setName(e.target.value)} maxLength={200} autoFocus /></Field>
        <Field label="Описание (необязательно)"><Textarea value={desc} onChange={(e) => setDesc(e.target.value)} rows={3} style={{ minHeight: 70 }} /></Field>
        {!edit && (
          <Field label="Кто видит" hint={parent ? 'Вложенная папка наследует доступ родителя; ограничение можно задать только для этой папки.' : undefined}>
            <Select value={vis} onChange={(e) => setVis(e.target.value as any)}>
              <option value="company">{parent ? 'Как у родительской папки' : 'Все сотрудники компании'}</option>
              <option value="restricted">Только выбранные сотрудники и подразделения</option>
            </Select>
          </Field>
        )}
        {err && <div className="err">{err}</div>}
        <button type="submit" hidden />
      </form>
    </Modal>
  );
}

// ---------------------------------------------------------------- выбор папки (перенос)

export function FolderPicker({ tree, value, onChange, disabled, allowRoot }: { tree: Tree; value: number | null; onChange: (id: number | null) => void; disabled?: Set<number>; allowRoot?: boolean }) {
  const rows: { f: LFolder; depth: number }[] = [];
  const walk = (p: number | null, depth: number) => (tree.kids.get(p) || []).forEach((f) => { rows.push({ f, depth }); walk(f.id, depth + 1); });
  walk(null, 0);
  return (
    <div className="lnPicker">
      {allowRoot && <label className={cx('lnPick', value === null && 'on')}><input type="radio" checked={value === null} onChange={() => onChange(null)} /><I.Layers size={16} /> В корень</label>}
      {rows.map(({ f, depth }) => {
        const off = f.level < 3 || disabled?.has(f.id);
        return (
          <label key={f.id} className={cx('lnPick', value === f.id && 'on', off && 'off')} style={{ paddingLeft: 10 + depth * 18 }}>
            <input type="radio" checked={value === f.id} disabled={off} onChange={() => onChange(f.id)} /><I.Folder size={16} /><span className="clip">{f.name}</span>
          </label>
        );
      })}
      {!rows.length && <div className="small muted" style={{ padding: 10 }}>Нет доступных папок</div>}
    </div>
  );
}

function MoveFolderModal({ kind, tree, folder, onClose }: { kind: Kind; tree: Tree; folder: LFolder; onClose: () => void }) {
  const me = useStore((s) => s.me)!;
  const [to, setTo] = useState<number | null | undefined>(undefined);
  const [busy, setBusy] = useState(false);
  const bad = useMemo(() => new Set(tree.subtree(folder.id)), [folder.id]);
  async function go() {
    setBusy(true);
    try { await api.post(`${L}/folders/${folder.id}/move`, { parent_id: to }); refreshLearning(); toast({ title: 'Папка перенесена', kind: 'success' }); onClose(); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); setBusy(false); }
  }
  return (
    <Modal title={`Переместить «${folder.name}»`} size="sm" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={to === undefined} onClick={go}>Переместить</Btn></>}>
      <FolderPicker tree={tree} value={to === undefined ? -1 : to} onChange={setTo} disabled={bad} allowRoot={me.role !== 'user'} />
      <div className="hint" style={{ marginTop: 10 }}>Доступ к папке определяется её новым расположением: если новая родительская папка ограничена, права изменятся.</div>
    </Modal>
  );
}

export function MoveItemsModal({ kind, tree, ids, onClose, onDone }: { kind: Kind; tree: Tree; ids: number[]; onClose: () => void; onDone: () => void }) {
  const [to, setTo] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  async function go() {
    if (!to) return;
    setBusy(true);
    try { await api.post(`${L}/${kind === 'materials' ? 'items' : 'tests'}/move`, { ids, folder_id: to }); refreshLearning(); toast({ title: 'Перенесено', kind: 'success' }); onDone(); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); setBusy(false); }
  }
  return (
    <Modal title={`Переместить: ${plural(ids.length, KIND[kind].one)}`} size="sm" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={!to} onClick={go}>Переместить</Btn></>}>
      <FolderPicker tree={tree} value={to} onChange={setTo} />
    </Modal>
  );
}

// ---------------------------------------------------------------- права доступа к папке

interface AclEntry { subject_type: 'user' | 'department'; subject_id: number; level: number; name?: string }
const LEVELS = [{ v: 1, l: 'Просмотр' }, { v: 3, l: 'Редактирование' }, { v: 4, l: 'Управление' }];

export function LearnAclEditor({ folder, onClose }: { folder: number; onClose: () => void }) {
  const { data, error } = useQuery<{ resource: { visibility: string; kind: Kind }; entries: AclEntry[] }>(`learn:acl:${folder}`, () => api.get(`${L}/folders/${folder}/acl`), { stale: 0 });
  const [vis, setVis] = useState('company');
  const [entries, setEntries] = useState<AclEntry[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [kind, setKind] = useState<'user' | 'department'>('user');
  const depts = useDepartments();
  const dlist = useMemo(() => flattenDepts(depts.data || []), [depts.data]);
  useEffect(() => { if (data) { setVis(data.resource.visibility); setEntries(data.entries.map((e) => ({ ...e, level: e.level === 2 ? 1 : e.level }))); } }, [data]);
  async function save() {
    setBusy(true); setErr('');
    try {
      await api.put(`${L}/folders/${folder}/acl`, { visibility: vis, entries: entries.map(({ subject_type, subject_id, level }) => ({ subject_type, subject_id, level })) });
      refreshLearning(); toast({ title: 'Права сохранены', kind: 'success' }); onClose();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  const add = (e: AclEntry) => !entries.some((x) => x.subject_type === e.subject_type && x.subject_id === e.subject_id) && setEntries([...entries, e]);
  return (
    <Modal title="Права доступа к папке" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} onClick={save}>Сохранить</Btn></>}>
      {error ? <div className="err">{errMsg(error)}</div> : !data ? <Loading /> : (
        <div className="stack">
          <Field label="Кто видит папку и всё внутри">
            <Select value={vis} onChange={(e) => setVis(e.target.value)}>
              <option value="company">Все сотрудники компании (если выше нет ограничений)</option>
              <option value="restricted">Только указанные ниже</option>
            </Select>
          </Field>
          <div className="hint">Доступ действует на все вложенные папки, материалы и тесты. Права «Редактирование» и «Управление» наследуются вниз всегда; для подразделений действуют и на все дочерние подразделения.</div>
          <div className="stackS">
            <div className="lbl">Сотрудники и подразделения</div>
            {entries.map((e, i) => (
              <div className="row" key={e.subject_type + e.subject_id}>
                {e.subject_type === 'user' ? <I.Users size={16} /> : <I.Building size={16} />}
                <div className="sp clip">{e.name || '#' + e.subject_id}{e.subject_type === 'department' && <span className="faint tiny"> · с подразделениями</span>}</div>
                <Select style={{ width: 170 }} value={e.level} onChange={(ev) => setEntries(entries.map((x, j) => (j === i ? { ...x, level: +ev.target.value } : x)))}>
                  {LEVELS.map((l) => <option key={l.v} value={l.v}>{l.l}</option>)}
                </Select>
                <Btn kind="ghost" size="sm" icon onClick={() => setEntries(entries.filter((_, j) => j !== i))}><I.X size={15} /></Btn>
              </div>
            ))}
            {!entries.length && <div className="small muted">Пока никого не добавлено</div>}
          </div>
          <div className="stackS">
            <div className="chips">
              <button type="button" className={cx('chip', kind === 'user' && 'on')} onClick={() => setKind('user')}>Сотрудник</button>
              <button type="button" className={cx('chip', kind === 'department' && 'on')} onClick={() => setKind('department')}>Подразделение</button>
            </div>
            {kind === 'user' ? (
              <UserPicker value={[]} onChange={(v) => v[0] && add({ subject_type: 'user', subject_id: v[0].id, level: 1, name: v[0].name })} />
            ) : (
              <Select value="" onChange={(e) => { const d = dlist.find((x) => x.id === +e.target.value); d && add({ subject_type: 'department', subject_id: d.id, level: 1, name: d.name }); }}>
                <option value="">Выберите подразделение…</option>
                {dlist.map((d) => <option key={d.id} value={d.id}>{'\u00a0\u00a0'.repeat(d.depth) + d.name}</option>)}
              </Select>
            )}
          </div>
          {err && <div className="err">{err}</div>}
        </div>
      )}
    </Modal>
  );
}

// ---------------------------------------------------------------- мелочи

export const fmtDur = (sec?: number | null) => (sec == null ? '—' : `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`);
export const pct = (v?: number | null) => (v == null ? '—' : `${String(Math.round(v * 10) / 10).replace('.', ',')}%`);
export const num = (v?: number | null) => (v == null ? '—' : String(Math.round(v * 100) / 100).replace('.', ','));

export function ListSkeleton({ rows = 5 }: { rows?: number }) {
  return <div className="card lnList">{Array.from({ length: rows }, (_, i) => <div key={i} className="lnRow"><Skel h={38} w={38} r={10} /><div className="sp stackS"><Skel h={16} w="55%" /><Skel h={12} w="80%" /></div></div>)}</div>;
}

export const dt = (iso?: string | null) => (iso ? new Date(iso).toLocaleString('ru', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '');
export const dtShort = (iso?: string | null) => (iso ? new Date(iso).toLocaleDateString('ru', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '');
