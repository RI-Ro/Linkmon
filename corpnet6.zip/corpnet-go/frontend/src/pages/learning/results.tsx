import React, { useEffect, useState } from 'react';
import * as I from '../../lib/icons';
import { api } from '../../lib/api';
import { useQuery } from '../../lib/query';
import { Link, useSearchParams, useTitle } from '../../lib/router';
import { usePersist } from '../../lib/persist';
import { cx, useDebounced } from '../../lib/util';
import { Badge, Check, Empty, ErrorBox, Pager, Select, Skel, Tabs } from '../../ui';
import { DeptSelect } from '../../ui/DeptSelect';
import { Crumbs, L, ListSkeleton, dt, fmtDur, num, pct, useTree } from './common';

export function ResultsPage({ id }: { id: number }) {
  const [tab, setTab] = usePersist<'results' | 'stats'>('learn:res:tab', 'results');
  const { tree } = useTree('tests');
  const t = useQuery<any>(`learn:t:test:${id}`, () => api.get(`${L}/tests/${id}`), { stale: 5000 });
  const test = t.data?.test;
  useTitle(test ? `Результаты: ${test.title}` : 'Результаты теста');
  if (t.error && !t.data) return <ErrorBox error={t.error} retry={t.refetch} />;
  if (t.data && (t.data.level || 0) < 3) return <Empty icon={I.Lock} title="Нет доступа">Результаты видят только редакторы теста</Empty>;

  return (
    <div className="stack">
      <div className="lnHead">
        <div className="sp" style={{ minWidth: 0 }}>
          {test && <Crumbs kind="tests" tree={tree} folder={test.folder_id} tail={test.title} />}
          <h2 className="lnTitle">Результаты{test ? `: ${test.title}` : ''}</h2>
        </div>
        <Link to={`/learning/tests/${id}`} className="btn"><I.ArrowLeft size={16} /> К тесту</Link>
      </div>
      <Tabs value={tab} onChange={(v) => setTab(v)} items={[{ id: 'results', label: 'Результаты' }, { id: 'stats', label: 'Статистика' }]} />
      {tab === 'results' ? <Results id={id} /> : <Stats id={id} />}
    </div>
  );
}

function Results({ id }: { id: number }) {
  const [sp, setSp] = useSearchParams();
  const page = +(sp.get('page') || 1), q = sp.get('q') || '', dept = +(sp.get('dept') || 0) || null;
  const from = sp.get('from') || '', to = sp.get('to') || '', passed = sp.get('passed') || '';
  const [best, setBest] = usePersist('learn:res:best', false);
  const [qIn, setQIn] = useState(q);
  const dq = useDebounced(qIn, 300);
  useEffect(() => { if (dq.trim() !== q) setSp({ q: dq.trim() || null, page: null }); }, [dq]);
  const qs = new URLSearchParams();
  if (q) qs.set('q', q);
  if (dept) qs.set('dept', String(dept));
  if (from) qs.set('from', from);
  if (to) qs.set('to', to);
  if (passed) qs.set('passed', passed);
  if (best) qs.set('best', '1');
  const filt = qs.toString();
  const { data, error, refetch } = useQuery<any>(`learn:t:res:${id}:${page}:${filt}`, () => api.get(`${L}/tests/${id}/attempts?page=${page}&per=30${filt ? '&' + filt : ''}`), { stale: 5000, keepPrevious: true });
  const any = q || dept || from || to || passed;

  return (
    <div className="stack">
      <div className="card lnFilters">
        <div className="lnSearch"><I.Search size={17} /><input value={qIn} placeholder="Сотрудник…" onChange={(e) => setQIn(e.target.value)} aria-label="Сотрудник" /></div>
        <div className="lnDept"><DeptSelect value={dept} onChange={(d) => setSp({ dept: d, page: null })} emptyLabel="Все отделы" /></div>
        <input className="inp lnDate" type="date" value={from} onChange={(e) => setSp({ from: e.target.value || null, page: null })} aria-label="С даты" />
        <input className="inp lnDate" type="date" value={to} onChange={(e) => setSp({ to: e.target.value || null, page: null })} aria-label="По дату" />
        <Select value={passed} onChange={(e) => setSp({ passed: e.target.value || null, page: null })} aria-label="Результат">
          <option value="">Любой результат</option><option value="1">Сдали</option><option value="0">Не сдали</option>
        </Select>
        <Check checked={best} onChange={(v) => { setBest(v); setSp({ page: null }); }} label="Лучшая попытка каждого" />
        {any ? <button className="btn ghost sm" onClick={() => { setQIn(''); setSp({ q: null, dept: null, from: null, to: null, passed: null, page: null }); }}>Сбросить</button> : null}
        <a className="btn pri" href={`${L}/tests/${id}/export.csv${filt ? '?' + filt : ''}`}><I.Download size={16} /> Экспорт CSV</a>
      </div>
      {error && !data ? <ErrorBox error={error} retry={refetch} /> : !data ? <ListSkeleton /> : !data.items.length ? (
        <div className="card"><Empty icon={I.Activity} title={any ? 'Ничего не найдено' : 'Результатов пока нет'}>{any ? 'Измените фильтры' : 'Они появятся, когда сотрудники пройдут тест'}</Empty></div>
      ) : (
        <>
          <div className="card tblW">
            <table className="tbl">
              <thead><tr><th>Сотрудник</th><th>Отдел</th><th>№</th><th>Завершён</th><th>Баллы</th><th>Результат</th><th>Время</th></tr></thead>
              <tbody>
                {data.items.map((a: any) => (
                  <tr key={a.id}>
                    <td><Link className="bold" to={`/learning/tests/attempt/${a.id}`}>{a.user_name}</Link></td>
                    <td className="muted">{a.department || '—'}</td>
                    <td>{a.no}</td><td>{dt(a.finished_at)}</td>
                    <td>{num(a.score)} / {num(a.max_score)} <span className="muted">({pct(a.percent)})</span></td>
                    <td>{a.passed ? <Badge kind="ok">Сдан</Badge> : <Badge kind="dng">Не сдан</Badge>}{a.expired && <span className="tiny muted"> · время вышло</span>}</td>
                    <td>{fmtDur(a.duration_sec)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pager page={page} total={data.total} per={data.per} onChange={(p) => setSp({ page: p > 1 ? p : null })} />
        </>
      )}
    </div>
  );
}

function Stats({ id }: { id: number }) {
  const { data, error, refetch } = useQuery<any>(`learn:t:stats:${id}`, () => api.get(`${L}/tests/${id}/stats`), { stale: 10000 });
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data) return <div className="stack"><Skel h={90} r={12} /><Skel h={200} r={12} /></div>;
  const s = data.summary;
  if (!s.attempts) return <div className="card"><Empty icon={I.Chart} title="Пока нет данных">Статистика появится после первых завершённых попыток</Empty></div>;
  const hist: number[] = Array(10).fill(0);
  data.histogram.forEach((h: any) => { hist[h.b] = h.n; });
  const mx = Math.max(1, ...hist);
  const kpi: [string, React.ReactNode][] = [
    ['Попыток', s.attempts], ['Сотрудников', s.users], ['Средний результат', pct(s.avg_percent)],
    ['Сдали', `${s.users_passed} из ${s.users}`], ['Доля сданных попыток', pct(Math.round((s.passed / s.attempts) * 100))], ['Среднее время', fmtDur(s.avg_duration)],
  ];
  return (
    <div className="stack">
      <div className="lnKpis">{kpi.map(([l, v]) => <div className="card lnKpi" key={l}><span className="muted small">{l}</span><b>{v}</b></div>)}</div>
      <div className="card pad">
        <h3 className="lnH3">Распределение результатов</h3>
        <div className="lnHist" role="img" aria-label="Гистограмма результатов">
          {hist.map((n, i) => (
            <div className="lnHistCol" key={i} title={`${i * 10}–${i === 9 ? 100 : i * 10 + 9}%: ${n}`}>
              <span className="lnHistN">{n || ''}</span>
              <i style={{ height: `${(n / mx) * 100}%` }} className={cx(n && 'has')} />
              <span className="lnHistL">{i * 10}{i === 9 ? '+' : ''}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="card tblW">
        <table className="tbl">
          <thead><tr><th>Вопрос</th><th>Ответов</th><th>Верно</th><th>Пропущено</th><th>Сложность</th></tr></thead>
          <tbody>
            {data.questions.map((q: any, i: number) => {
              const r = q.n ? Math.round((q.correct / q.n) * 100) : null;
              return (
                <tr key={q.id}>
                  <td className="lnQCell"><span className="muted">{i + 1}.</span> {q.text}</td>
                  <td>{q.n}</td>
                  <td>{r == null ? '—' : <span className={cx('lnPctB', r < 40 ? 'bad' : r < 70 ? 'mid' : 'ok')}>{r}%</span>}</td>
                  <td>{q.skipped || 0}</td>
                  <td style={{ minWidth: 120 }}>{r != null && <div className="lnBar2"><i style={{ width: `${100 - r}%` }} /></div>}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
