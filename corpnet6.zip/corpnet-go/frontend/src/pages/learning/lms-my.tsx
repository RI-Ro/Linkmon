// LMS: «Моё обучение» — назначенное, в процессе, просроченное, завершённое, сертификаты, рекомендации.
import React from 'react';
import * as I from '../../lib/icons';
import { api } from '../../lib/api';
import { useQuery } from '../../lib/query';
import { Link, useSearchParams, useTitle } from '../../lib/router';
import { cx } from '../../lib/util';
import { Badge, Empty, ErrorBox, Skel } from '../../ui';
import { L } from './common';
import { Bar, Cover, DueChip, StatusBadge, dmy, mins, score1 } from './lms-common';

interface My {
  assigned: any[]; progress: any[]; completed: any[]; certs: any[]; recommended: any[];
  summary: { open: number; overdue: number; soon: number; done: number };
}

const TABS = [
  { id: 'assigned', label: 'Назначено' },
  { id: 'progress', label: 'В процессе' },
  { id: 'overdue', label: 'Просрочено' },
  { id: 'done', label: 'Завершено' },
] as const;

function AssignedRow({ a }: { a: any }) {
  const isCourse = a.target_type === 'course';
  const to = isCourse ? `/learning/courses/${a.target_id}` : `/learning/tests/${a.target_id}`;
  return (
    <Link to={to} className={cx('lmRow card', a.overdue && 'bad')}>
      {isCourse ? <Cover src={a.cover} title={a.title} className="lmRowCover" /> : <div className="lmRowCover lmCoverImg ph"><I.GradCap size={26} /></div>}
      <div className="sp" style={{ minWidth: 0 }}>
        <div className="bold clip">{a.title}</div>
        <div className="lmMeta"><span>{isCourse ? 'Курс' : 'Тест'}</span>{a.est_minutes > 0 && <span><I.Clock size={12} /> {mins(a.est_minutes)}</span>}{a.mandatory && <span className="lmMand">обязательно</span>}
          {!isCourse && a.best != null && <span>лучший результат {score1(a.best)}</span>}</div>
        {isCourse && a.e_status === 1 && <div className="lmRowProg"><Bar p={a.percent} thin /><span className="tiny muted">{a.percent}%</span></div>}
      </div>
      <div className="lmRowSide"><StatusBadge status={a.status} overdue={a.overdue} /><DueChip due={a.due_at} status={a.status} high={a.high} /></div>
    </Link>
  );
}

export function MyLearningPage() {
  useTitle('Моё обучение');
  const [sp, setSp] = useSearchParams();
  const { data, error, refetch } = useQuery<My>('learn:my', () => api.get(`${L}/my`), { stale: 5000 });
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data) return <div className="stack"><div className="lmKpis">{[0, 1, 2, 3].map((i) => <div key={i} className="card pad"><Skel h={40} /></div>)}</div><Skel h={80} /><Skel h={80} /></div>;
  const overdue = data.assigned.filter((a) => a.overdue);
  const open = data.assigned.filter((a) => !a.overdue);
  const lists = { assigned: open, progress: data.progress, overdue, done: data.completed };
  const def = overdue.length ? 'overdue' : open.length ? 'assigned' : data.progress.length ? 'progress' : 'assigned';
  const tab = (TABS.find((t) => t.id === sp.get('tab'))?.id || def) as keyof typeof lists;
  const sm = data.summary;
  return (
    <div className="stack">
      <div className="lmKpis">
        <div className="card lmKpi"><b>{sm.open}</b><span>к выполнению</span></div>
        <div className={cx('card lmKpi', sm.overdue > 0 && 'bad')}><b>{sm.overdue}</b><span>просрочено</span></div>
        <div className={cx('card lmKpi', sm.soon > 0 && 'warn')}><b>{sm.soon}</b><span>срок в ближайшие 7 дней</span></div>
        <div className="card lmKpi ok"><b>{sm.done}</b><span>завершено</span></div>
      </div>

      <div className="chips">
        {TABS.map((t) => (
          <button key={t.id} className={cx('chip', tab === t.id && 'on')} onClick={() => setSp({ tab: t.id }, true)}>
            {t.label}<span className="lmChipN">{lists[t.id].length}</span>
          </button>
        ))}
        <span className="sp" />
        <Link className="btn" to="/learning/certificates"><I.Star size={16} /> Мои сертификаты{data.certs.length > 0 && ` · ${data.certs.length}`}</Link>
      </div>

      {tab === 'done' ? (
        data.completed.length === 0 ? <div className="card"><Empty icon={I.Check} title="Завершённых курсов пока нет">Пройденные курсы и результаты появятся здесь</Empty></div> : (
          <div className="stackS">
            {data.completed.map((c) => (
              <div key={c.id} className="lmRow card">
                <Link to={`/learning/courses/${c.id}`} className="lmRowLink"><Cover src={c.cover} title={c.title} className="lmRowCover" /></Link>
                <div className="sp" style={{ minWidth: 0 }}>
                  <Link to={`/learning/courses/${c.id}`} className="bold clip" style={{ display: 'block' }}>{c.title}</Link>
                  <div className="lmMeta"><span>завершён {dmy(c.completed_at)}</span>{c.score != null && <span>балл {score1(c.score)}</span>}{c.expires_at && <span>{c.expired ? 'срок истёк' : 'действует до'} {dmy(c.expires_at)}</span>}</div>
                </div>
                <div className="lmRowSide">
                  {c.expired ? <Badge kind="warn">Нужно пройти заново</Badge> : <Badge kind="ok"><I.Check size={11} /> Пройден</Badge>}
                  {c.cert_id && <Link className="btn sm" to={`/learning/certificates/${c.cert_id}`}><I.Star size={14} /> Сертификат</Link>}
                </div>
              </div>
            ))}
          </div>
        )
      ) : tab === 'progress' ? (
        data.progress.length === 0 ? <div className="card"><Empty icon={I.Play} title="Нет курсов в процессе">Начните курс из каталога или из списка назначенных</Empty></div> : (
          <div className="stackS">
            {data.progress.map((c) => (
              <Link key={c.id} to={`/learning/courses/${c.id}`} className="lmRow card">
                <Cover src={c.cover} title={c.title} className="lmRowCover" />
                <div className="sp" style={{ minWidth: 0 }}>
                  <div className="bold clip">{c.title}</div>
                  <div className="lmMeta"><span>шагов: {c.steps_done} из {c.steps_total}</span>{c.last_at && <span>был(а) здесь {dmy(c.last_at)}</span>}</div>
                  <div className="lmRowProg"><Bar p={c.percent} thin /><span className="tiny muted">{c.percent}%</span></div>
                </div>
                <div className="lmRowSide"><span className="btn pri sm"><I.Play size={14} /> Продолжить</span></div>
              </Link>
            ))}
          </div>
        )
      ) : lists[tab].length === 0 ? (
        <div className="card"><Empty icon={tab === 'overdue' ? I.Check : I.GradCap} title={tab === 'overdue' ? 'Просроченных заданий нет' : 'Нет назначенных заданий'}>{tab === 'overdue' ? 'Так держать!' : 'Когда вам назначат курс или тест, он появится здесь'}</Empty></div>
      ) : (
        <div className="stackS">{lists[tab].map((a) => <AssignedRow key={a.assignee_id} a={a} />)}</div>
      )}

      {data.recommended.length > 0 && (
        <div className="stackS">
          <h3 className="lnH3">Рекомендуем</h3>
          <div className="lmGrid">
            {data.recommended.map((c) => (
              <Link key={c.id} to={`/learning/courses/${c.id}`} className="card lmCard">
                <div className="lmCardCover"><Cover src={c.cover} title={c.title} /></div>
                <div className="lmCardBd"><div className="bold clamp2">{c.title}</div>{c.description && <div className="small muted clamp2">{c.description}</div>}</div>
                <div className="lmCardFt"><span className="small muted">{c.est_minutes > 0 ? mins(c.est_minutes) : 'Курс'}</span></div>
              </Link>
            ))}
          </div>
          <div><Link className="btn" to="/learning/courses">Весь каталог курсов</Link></div>
        </div>
      )}
    </div>
  );
}
