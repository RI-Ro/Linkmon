import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as I from '../../lib/icons';
import { api, errMsg } from '../../lib/api';
import { invalidate, useQuery } from '../../lib/query';
import { Link, navigate, useSearchParams, useTitle } from '../../lib/router';
import { toast } from '../../lib/store';
import { usePersist } from '../../lib/persist';
import { cx, plural } from '../../lib/util';
import { Badge, Btn, Check, Empty, ErrorBox, Field, Input, Modal, Select, Skel, Switch, Textarea, useConfirm } from '../../ui';
import { Crumbs, L, refreshLearning, useTree } from './common';
import { useCertTemplates } from './lms-common';

// ---------------------------------------------------------------- модель

interface QOpt { id: number; text: string; correct: boolean }
interface Q { key: number; id: number; type: 'single' | 'multiple' | 'text'; text: string; file_id: number | null; options: QOpt[]; answers: string[]; weight: number; explanation: string; open: boolean }
interface ImportErr { line?: number; index?: number; message: string }
interface ImportRes { format: string; questions: any[]; errors: ImportErr[]; test?: Record<string, any>; total: number }

let keySeq = 1;
const mkOpts = (n = 3): QOpt[] => Array.from({ length: n }, (_, i) => ({ id: i + 1, text: '', correct: i === 0 }));
const fromServer = (q: any, open = false): Q => ({
  key: keySeq++, id: q.id || 0, type: q.type || 'single', text: q.text || '', file_id: q.file_id ?? null,
  options: (q.options || []).map((o: any, i: number) => ({ id: o.id || i + 1, text: o.text || '', correct: !!o.correct })),
  answers: q.answers || [], weight: q.weight || 1, explanation: q.explanation || '', open,
});
const newQ = (type: Q['type'] = 'single'): Q => ({ key: keySeq++, id: 0, type, text: '', file_id: null, options: type === 'text' ? [] : mkOpts(), answers: type === 'text' ? [''] : [], weight: 1, explanation: '', open: true });
const toServer = (q: Q) => ({ id: q.id || 0, type: q.type, text: q.text, file_id: q.file_id, options: q.type === 'text' ? undefined : q.options, answers: q.type === 'text' ? q.answers : undefined, weight: q.weight || 1, explanation: q.explanation });

function qProblem(q: Q): string {
  if (!q.text.trim()) return 'Нет текста вопроса';
  if (q.type === 'text') return q.answers.some((a) => a.trim()) ? '' : 'Не указан правильный ответ';
  const f = q.options.filter((o) => o.text.trim());
  if (f.length < 2) return 'Нужно минимум два варианта';
  const r = f.filter((o) => o.correct).length;
  if (!r) return 'Не отмечен правильный вариант';
  if (q.type === 'single' && r !== 1) return 'Нужен ровно один правильный вариант';
  return '';
}

const TYPES = { single: 'Один ответ', multiple: 'Несколько ответов', text: 'Текст / число' };
const toLocal = (s?: string | null) => { if (!s) return ''; const d = new Date(s); const p = (n: number) => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`; };
const fromLocal = (s: string) => (s ? new Date(s).toISOString() : null);

// ---------------------------------------------------------------- редактор теста

export function TestEditor({ id }: { id?: number }) {
  const [sp] = useSearchParams();
  const qFolder = +(sp.get('folder') || 0);
  const loaded = useQuery<any>(id ? `learn:t:edit:${id}` : null, () => api.get(`${L}/tests/${id}?edit=1`), { stale: 0 });
  const [ready, setReady] = useState(!id);
  const [folder, setFolder] = useState(qFolder);
  const certTpls = useCertTemplates();
  const [f, setF] = useState({
    title: '', description: '', status: 'draft' as 'draft' | 'published', pass_percent: 70, time_limit_min: '' as string | number, max_attempts: '' as string | number,
    shuffle_questions: false, shuffle_answers: false, partial_credit: false, show_answers: 'after_attempt', available_from: '', available_to: '',
    cert_template_id: '' as string | number, cert_validity_months: 0 as string | number,
  });
  const [qs, setQs] = useState<Q[]>(() => (id ? [] : [newQ()]));
  const [busy, setBusy] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [imp, setImp] = useState(false);
  const [adv, setAdv] = usePersist('learn:ed:adv', true);
  const [confirm, confirmNode] = useConfirm();
  const { tree } = useTree('tests');
  useTitle(id ? 'Редактирование теста' : 'Новый тест');

  useEffect(() => {
    const d = loaded.data;
    if (!d || ready) return;
    const t = d.test || d;
    setFolder(t.folder_id);
    setF({
      title: t.title, description: t.description || '', status: t.status, pass_percent: t.pass_percent, time_limit_min: t.time_limit_min ?? '', max_attempts: t.max_attempts ?? '',
      shuffle_questions: t.shuffle_questions, shuffle_answers: t.shuffle_answers, partial_credit: t.partial_credit, show_answers: t.show_answers,
      available_from: toLocal(t.available_from), available_to: toLocal(t.available_to),
      cert_template_id: t.cert_template_id ?? '', cert_validity_months: t.cert_validity_months ?? 0,
    });
    setQs((d.questions || []).map((q: any) => fromServer(q)));
    setReady(true);
  }, [loaded.data]);

  useEffect(() => {
    if (!dirty) return;
    const h = (e: BeforeUnloadEvent) => { e.preventDefault(); e.returnValue = ''; };
    addEventListener('beforeunload', h);
    return () => removeEventListener('beforeunload', h);
  }, [dirty]);

  const set = (p: Partial<typeof f>) => { setF((o) => ({ ...o, ...p })); setDirty(true); };
  const setQ = (key: number, p: Partial<Q>) => { setQs((l) => l.map((q) => (q.key === key ? { ...q, ...p } : q))); setDirty(true); };
  const moveQ = (i: number, d: number) => { setQs((l) => { const n = [...l]; const j = i + d; if (j < 0 || j >= n.length) return l; [n[i], n[j]] = [n[j], n[i]]; return n; }); setDirty(true); };
  const delQ = (key: number) => { setQs((l) => l.filter((q) => q.key !== key)); setDirty(true); };
  const dupQ = (q: Q) => { setQs((l) => { const i = l.findIndex((x) => x.key === q.key); const n = [...l]; n.splice(i + 1, 0, { ...q, key: keySeq++, id: 0, options: q.options.map((o) => ({ ...o })), answers: [...q.answers], open: true }); return n; }); setDirty(true); };
  const add = (type: Q['type']) => { setQs((l) => [...l.map((q) => ({ ...q, open: false })), newQ(type)]); setDirty(true); setTimeout(() => document.querySelector('.lnQCard:last-of-type textarea')?.scrollIntoView({ block: 'center', behavior: 'smooth' }), 50); };

  const problems = useMemo(() => qs.map(qProblem), [qs]);
  const bad = problems.filter(Boolean).length;
  const totalW = qs.reduce((a, q) => a + (+q.weight || 1), 0);

  async function save(status?: 'draft' | 'published') {
    if (!f.title.trim()) return toast({ title: 'Укажите название теста', kind: 'error' });
    if (!folder) return toast({ title: 'Не выбрана папка', kind: 'error' });
    const firstBad = problems.findIndex(Boolean);
    if (firstBad >= 0) {
      setQs((l) => l.map((q, i) => (i === firstBad ? { ...q, open: true } : q)));
      return toast({ title: `Вопрос ${firstBad + 1}: ${problems[firstBad]}`, kind: 'error' });
    }
    const st = status || f.status;
    if (st === 'published' && !qs.length) return toast({ title: 'Добавьте хотя бы один вопрос', kind: 'error' });
    setBusy(true);
    try {
      const body = {
        folder_id: folder, title: f.title.trim(), description: f.description, status: st, pass_percent: +f.pass_percent || 0,
        time_limit_min: f.time_limit_min === '' ? null : +f.time_limit_min, max_attempts: f.max_attempts === '' ? null : +f.max_attempts,
        shuffle_questions: f.shuffle_questions, shuffle_answers: f.shuffle_answers, partial_credit: f.partial_credit, show_answers: f.show_answers,
        available_from: fromLocal(f.available_from), available_to: fromLocal(f.available_to), questions: qs.map(toServer),
        cert_template_id: f.cert_template_id === '' ? null : +f.cert_template_id, cert_validity_months: +f.cert_validity_months || 0,
      };
      const r = id ? await api.put<{ id: number }>(`${L}/tests/${id}`, body) : await api.post<{ id: number }>(`${L}/tests`, body);
      setDirty(false);
      refreshLearning();
      toast({ title: st === 'published' ? 'Тест опубликован' : 'Сохранено', kind: 'success' });
      if (id) { set0(st); invalidate(`learn:t:edit:${id}`); setReady(false); loaded.refetch?.(); } else navigate(`/learning/tests/${r.id}/edit`, { replace: true });
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  const set0 = (st: 'draft' | 'published') => setF((o) => ({ ...o, status: st }));

  async function leave() {
    if (dirty && !(await confirm('Выйти без сохранения?', { text: 'Несохранённые изменения будут потеряны.', ok: 'Выйти' }))) return;
    setDirty(false);
    navigate(id ? `/learning/tests/${id}` : `/learning/tests?folder=${folder}`);
  }

  // горячие клавиши: Ctrl+S
  const saveRef = useRef(save); saveRef.current = save;
  useEffect(() => {
    const h = (e: KeyboardEvent) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); saveRef.current(); } };
    addEventListener('keydown', h);
    return () => removeEventListener('keydown', h);
  }, []);

  if (id && loaded.error) return <ErrorBox error={loaded.error} retry={loaded.refetch} />;
  if (!ready) return <div className="lnEd"><Skel h={36} w="40%" /><div style={{ height: 12 }} /><Skel h={180} r={12} /><div style={{ height: 12 }} /><Skel h={120} r={12} /></div>;

  return (
    <div className="lnEd">
      <div className="lnEdHead">
        <Crumbs kind="tests" tree={tree} folder={folder} tail={id ? 'Редактирование' : 'Новый тест'} />
        <div className="lnEdAct">
          <Badge kind={f.status === 'published' ? 'ok' : undefined}>{f.status === 'published' ? 'Опубликован' : 'Черновик'}</Badge>
          <Btn kind="ghost" onClick={leave}>Отмена</Btn>
          <Btn onClick={() => save()} busy={busy}><I.Check size={16} /> Сохранить</Btn>
          {f.status === 'draft' ? <Btn kind="pri" onClick={() => save('published')} busy={busy}>Опубликовать</Btn>
            : <Btn onClick={() => save('draft')} busy={busy}>В черновик</Btn>}
        </div>
      </div>

      <section className="card lnEdCard">
        <Field label="Название"><Input value={f.title} maxLength={200} autoFocus={!id} placeholder="Например: Охрана труда, вводный тест" onChange={(e) => set({ title: e.target.value })} /></Field>
        <Field label="Описание (показывается перед началом)"><Textarea rows={2} value={f.description} onChange={(e) => set({ description: e.target.value })} /></Field>
        <div className="lnGrid">
          <Field label="Проходной балл, %"><Input type="number" min={0} max={100} value={f.pass_percent} onChange={(e) => set({ pass_percent: e.target.value as any })} /></Field>
          <Field label="Время, минут" hint="пусто — без ограничения"><Input type="number" min={1} max={1440} value={f.time_limit_min} onChange={(e) => set({ time_limit_min: e.target.value })} /></Field>
          <Field label="Попыток" hint="пусто — без ограничения"><Input type="number" min={1} max={100} value={f.max_attempts} onChange={(e) => set({ max_attempts: e.target.value })} /></Field>
          <Field label="Показывать ответы">
            <Select value={f.show_answers} onChange={(e) => set({ show_answers: e.target.value })}>
              <option value="never">Никогда</option><option value="after_attempt">После попытки</option><option value="after_finish">После всех попыток</option>
            </Select>
          </Field>
          <Field label="Сертификат за сдачу" hint="Выдаётся при сдаче отдельного теста"><Select value={f.cert_template_id} onChange={(e) => set({ cert_template_id: e.target.value })}><option value="">Не выдавать</option>{(certTpls.data || []).map((x: any) => <option key={x.id} value={x.id}>{x.name}</option>)}</Select></Field>
          {f.cert_template_id !== '' && <Field label="Срок действия, мес." hint="0 — бессрочно"><Input type="number" min={0} max={600} value={f.cert_validity_months} onChange={(e) => set({ cert_validity_months: e.target.value })} /></Field>}
        </div>
        <button className="lnMore" onClick={() => setAdv(!adv)}>{adv ? <I.ChevronDown size={15} /> : <I.ChevronRight size={15} />} Дополнительно</button>
        {adv && (
          <div className="lnAdv">
            <Switch checked={f.shuffle_questions} onChange={(v) => set({ shuffle_questions: v })} label="Перемешивать вопросы" />
            <Switch checked={f.shuffle_answers} onChange={(v) => set({ shuffle_answers: v })} label="Перемешивать варианты ответов" />
            <Switch checked={f.partial_credit} onChange={(v) => set({ partial_credit: v })} label="Частичный балл в вопросах с несколькими ответами" />
            <div className="lnGrid">
              <Field label="Доступен с"><Input type="datetime-local" value={f.available_from} onChange={(e) => set({ available_from: e.target.value })} /></Field>
              <Field label="Доступен до"><Input type="datetime-local" value={f.available_to} onChange={(e) => set({ available_to: e.target.value })} /></Field>
            </div>
          </div>
        )}
      </section>

      <div className="lnQHead">
        <h3>Вопросы <span className="muted">{qs.length} · {plural(Math.round(totalW), ['балл', 'балла', 'баллов'])}</span></h3>
        <div className="row">
          {bad > 0 && <Badge kind="warn">Ошибок: {bad}</Badge>}
          <Btn size="sm" onClick={() => setQs((l) => l.map((q) => ({ ...q, open: !l.every((x) => x.open) })))}>{qs.every((q) => q.open) ? 'Свернуть все' : 'Развернуть все'}</Btn>
          <Btn size="sm" onClick={() => setImp(true)}><I.Upload size={15} /> Импорт</Btn>
          {id && <a className="btn sm" href={`${L}/tests/${id}/export.json`} download><I.Download size={15} /> JSON</a>}
        </div>
      </div>

      {!qs.length && <Empty icon={I.FileText} title="Вопросов пока нет">Добавьте вопрос вручную или импортируйте из файла JSON, CSV или текста.</Empty>}
      <div className="lnQList">
        {qs.map((q, i) => (
          <QCard key={q.key} q={q} i={i} n={qs.length} folder={folder} problem={problems[i]}
            onChange={(p) => setQ(q.key, p)} onMove={(d) => moveQ(i, d)} onDel={() => delQ(q.key)} onDup={() => dupQ(q)} />
        ))}
      </div>
      <div className="lnAddBar">
        <Btn onClick={() => add('single')}><I.Plus size={16} /> Один ответ</Btn>
        <Btn onClick={() => add('multiple')}><I.Plus size={16} /> Несколько ответов</Btn>
        <Btn onClick={() => add('text')}><I.Plus size={16} /> Текст / число</Btn>
      </div>
      <div className="lnSaveBar">
        <span className="muted">{dirty ? 'Есть несохранённые изменения · Ctrl+S' : 'Все изменения сохранены'}</span>
        <Btn kind="pri" onClick={() => save()} busy={busy}><I.Check size={16} /> Сохранить</Btn>
      </div>

      {confirmNode}
      {imp && (
        <ImportModal mode="local" folder={folder} onClose={() => setImp(false)} onQuestions={(list, meta) => {
          setQs((l) => [...l.filter((q) => q.text.trim() || q.id).map((q) => ({ ...q, open: false })), ...list.map((x) => fromServer(x))]);
          if (meta && !f.title.trim()) setF((o) => ({ ...o, title: meta.title || o.title, description: meta.description || o.description }));
          setDirty(true); setImp(false);
        }} />
      )}
    </div>
  );
}

// ---------------------------------------------------------------- карточка вопроса

function QCard({ q, i, n, folder, problem, onChange, onMove, onDel, onDup }: {
  q: Q; i: number; n: number; folder: number; problem: string; onChange: (p: Partial<Q>) => void; onMove: (d: number) => void; onDel: () => void; onDup: () => void;
}) {
  const [up, setUp] = useState(false);
  const inp = useRef<HTMLInputElement>(null);
  async function pick(file?: File) {
    if (!file) return;
    setUp(true);
    try { const r = await api.upload<{ id: number }[]>(`${L}/files?folder=${folder}`, file); onChange({ file_id: r[0].id }); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setUp(false);
  }
  const setOpt = (k: number, p: Partial<QOpt>) => onChange({ options: q.options.map((o, j) => (j === k ? { ...o, ...p } : o)) });
  const toggle = (k: number) => {
    if (q.type === 'single') onChange({ options: q.options.map((o, j) => ({ ...o, correct: j === k })) });
    else setOpt(k, { correct: !q.options[k].correct });
  };
  const changeType = (t: Q['type']) => {
    if (t === q.type) return;
    if (t === 'text') onChange({ type: t, answers: q.options.filter((o) => o.correct && o.text.trim()).map((o) => o.text) .concat(q.answers).filter(Boolean).slice(0, 5).concat(['']).slice(0, Math.max(1, 1)), options: [] });
    else if (q.type === 'text') onChange({ type: t, options: mkOpts(), answers: [] });
    else {
      let opts = q.options;
      if (t === 'single') { const first = opts.findIndex((o) => o.correct); opts = opts.map((o, j) => ({ ...o, correct: j === Math.max(0, first) })); }
      onChange({ type: t, options: opts });
    }
  };
  const nextId = () => q.options.reduce((a, o) => Math.max(a, o.id), 0) + 1;
  const title = q.text.trim().split('\n')[0] || 'Новый вопрос';

  return (
    <div className={cx('lnQCard', problem && 'bad', q.open && 'open')}>
      <div className="lnQTop" onClick={() => !q.open && onChange({ open: true })}>
        <span className="lnQNum">{i + 1}</span>
        <button className="lnQTitle" onClick={() => onChange({ open: !q.open })} aria-expanded={q.open}>
          <b>{title}</b>
          <span className="muted">{TYPES[q.type]} · вес {q.weight}{problem && <em> · {problem}</em>}</span>
        </button>
        <div className="lnQTools" onClick={(e) => e.stopPropagation()}>
          <button className="btn ghost icon sm" disabled={i === 0} onClick={() => onMove(-1)} title="Выше" aria-label="Выше"><I.ChevronUp size={16} /></button>
          <button className="btn ghost icon sm" disabled={i === n - 1} onClick={() => onMove(1)} title="Ниже" aria-label="Ниже"><I.ChevronDown size={16} /></button>
          <button className="btn ghost icon sm" onClick={onDup} title="Дублировать" aria-label="Дублировать"><I.Copy size={15} /></button>
          <button className="btn ghost icon sm" onClick={onDel} title="Удалить" aria-label="Удалить"><I.Trash size={15} /></button>
        </div>
      </div>
      {q.open && (
        <div className="lnQBody">
          <div className="lnGrid">
            <Field label="Тип"><Select value={q.type} onChange={(e) => changeType(e.target.value as Q['type'])}>{Object.entries(TYPES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></Field>
            <Field label="Вес (баллов)"><Input type="number" min={0.01} max={100} step={0.5} value={q.weight} onChange={(e) => onChange({ weight: +e.target.value })} /></Field>
          </div>
          <Field label="Текст вопроса"><Textarea rows={2} value={q.text} onChange={(e) => onChange({ text: e.target.value })} placeholder="Сформулируйте вопрос" /></Field>
          <div className="lnQImg">
            {q.file_id ? <img src={`/files/${q.file_id}?t=1`} alt="" /> : null}
            <Btn size="sm" busy={up} onClick={() => inp.current?.click()}><I.Image size={15} /> {q.file_id ? 'Заменить картинку' : 'Добавить картинку'}</Btn>
            {q.file_id && <Btn size="sm" kind="ghost" onClick={() => onChange({ file_id: null })}>Убрать</Btn>}
            <input ref={inp} type="file" accept="image/*" hidden onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ''; }} />
          </div>

          {q.type === 'text' ? (
            <Field label="Допустимые ответы" hint="Регистр, лишние пробелы и «ё/е» не учитываются; числа сравниваются по значению (3,5 = 3.5)">
              <div className="lnAns">
                {q.answers.map((a, k) => (
                  <div className="lnAnsRow" key={k}>
                    <Input value={a} placeholder="Правильный ответ" onChange={(e) => onChange({ answers: q.answers.map((x, j) => (j === k ? e.target.value : x)) })} />
                    {q.answers.length > 1 && <button className="btn ghost icon sm" onClick={() => onChange({ answers: q.answers.filter((_, j) => j !== k) })} aria-label="Убрать"><I.X size={15} /></button>}
                  </div>
                ))}
                <Btn size="sm" kind="ghost" onClick={() => onChange({ answers: [...q.answers, ''] })}><I.Plus size={14} /> Ещё вариант ответа</Btn>
              </div>
            </Field>
          ) : (
            <Field label={q.type === 'single' ? 'Варианты (отметьте верный)' : 'Варианты (отметьте все верные)'}>
              <div className="lnAns">
                {q.options.map((o, k) => (
                  <div className={cx('lnAnsRow', o.correct && 'ok')} key={o.id + ':' + k}>
                    <button type="button" className={cx('lnTick', q.type === 'single' ? 'round' : 'sq', o.correct && 'on')} onClick={() => toggle(k)} aria-label="Верный ответ" aria-pressed={o.correct}>{o.correct && <I.Check size={14} />}</button>
                    <Input value={o.text} placeholder={`Вариант ${k + 1}`} onChange={(e) => setOpt(k, { text: e.target.value })}
                      onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); if (k === q.options.length - 1 && q.options.length < 20) onChange({ options: [...q.options, { id: nextId(), text: '', correct: false }] }); } }} />
                    {q.options.length > 2 && <button className="btn ghost icon sm" onClick={() => onChange({ options: q.options.filter((_, j) => j !== k) })} aria-label="Убрать"><I.X size={15} /></button>}
                  </div>
                ))}
                {q.options.length < 20 && <Btn size="sm" kind="ghost" onClick={() => onChange({ options: [...q.options, { id: nextId(), text: '', correct: false }] })}><I.Plus size={14} /> Добавить вариант</Btn>}
              </div>
            </Field>
          )}
          <Field label="Пояснение (показывается после ответа)"><Textarea rows={2} value={q.explanation} onChange={(e) => onChange({ explanation: e.target.value })} /></Field>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- импорт

export function ImportModal({ mode, folder, testId, onClose, onDone, onQuestions }: {
  mode: 'create' | 'append' | 'local'; folder?: number; testId?: number; onClose: () => void; onDone?: (id: number) => void;
  onQuestions?: (qs: any[], meta?: Record<string, any>) => void;
}) {
  const [text, setText] = useState('');
  const [fname, setFname] = useState('');
  const [fmt, setFmt] = useState('auto');
  const [res, setRes] = useState<ImportRes | null>(null);
  const [busy, setBusy] = useState(false);
  const [title, setTitle] = useState('');
  const [replace, setReplace] = useState(false);
  const [drag, setDrag] = useState(false);
  const fi = useRef<HTMLInputElement>(null);

  async function readFile(file?: File) {
    if (!file) return;
    if (file.size > 5 << 20) return toast({ title: 'Файл больше 5 МБ', kind: 'error' });
    const buf = await file.arrayBuffer();
    let s = new TextDecoder('utf-8').decode(buf);
    if (s.includes('�')) { try { s = new TextDecoder('windows-1251').decode(buf); } catch {} }
    setText(s.replace(/^﻿/, '')); setFname(file.name); setRes(null);
    parse(s.replace(/^﻿/, ''), file.name);
  }
  async function parse(content = text, filename = fname) {
    if (!content.trim()) return toast({ title: 'Вставьте текст или выберите файл', kind: 'error' });
    setBusy(true);
    try {
      const r = await api.post<ImportRes>(`${L}/import/parse`, { content, filename, format: fmt === 'auto' ? '' : fmt });
      setRes(r);
      if (r.test?.title && !title) setTitle(r.test.title);
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  async function commit() {
    if (!res?.questions.length) return;
    setBusy(true);
    try {
      if (mode === 'local') { onQuestions?.(res.questions, res.test); return; }
      if (mode === 'append') {
        await api.post(`${L}/tests/${testId}/questions/import`, { questions: res.questions, replace });
        refreshLearning(); invalidate(`learn:t:edit:${testId}`); toast({ title: `Добавлено: ${res.questions.length}`, kind: 'success' }); onDone?.(testId!);
      } else {
        const t = res.test || {};
        const r = await api.post<{ id: number }>(`${L}/tests`, { ...t, folder_id: folder, title: title.trim() || t.title || fname.replace(/\.[^.]+$/, '') || 'Импортированный тест', status: 'draft', questions: res.questions });
        toast({ title: 'Тест создан как черновик', kind: 'success' }); onDone?.(r.id);
      }
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  const ok = res?.questions.length || 0;

  return (
    <Modal title="Импорт заданий" size="lg" onClose={onClose} footer={
      <>
        <Btn kind="ghost" onClick={onClose}>Отмена</Btn>
        {!res ? <Btn kind="pri" busy={busy} onClick={() => parse()} disabled={!text.trim()}>Проверить</Btn>
          : <Btn kind="pri" busy={busy} onClick={commit} disabled={!ok}>{mode === 'create' ? `Создать тест (${ok})` : `Импортировать ${ok} ${plural(ok, ['задание', 'задания', 'заданий'])}`}</Btn>}
      </>
    }>
      <div className="lnImp">
        {!res ? (
          <>
            <div className={cx('lnDrop', drag && 'over')} onDragOver={(e) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)}
              onDrop={(e) => { e.preventDefault(); setDrag(false); readFile(e.dataTransfer.files[0]); }} onClick={() => fi.current?.click()} role="button" tabIndex={0}>
              <I.Upload size={22} />
              <b>{fname || 'Перетащите файл или нажмите для выбора'}</b>
              <span className="muted">JSON, CSV (; , или Tab) или обычный текст · до 500 заданий</span>
              <input ref={fi} type="file" accept=".json,.csv,.txt,.tsv,text/*,application/json" hidden onChange={(e) => { readFile(e.target.files?.[0]); e.target.value = ''; }} />
            </div>
            <Field label="…или вставьте текст">
              <Textarea rows={8} className="mono" value={text} onChange={(e) => { setText(e.target.value); setFname(''); }} placeholder={'Столица России?\n*Москва\nСанкт-Петербург\nКазань\n\n2+2=?\n= 4'} />
            </Field>
            <div className="lnImpOpts">
              <Field label="Формат"><Select value={fmt} onChange={(e) => setFmt(e.target.value)}><option value="auto">Определить автоматически</option><option value="json">JSON</option><option value="csv">CSV</option><option value="text">Текст</option></Select></Field>
              <div className="lnTpl">
                <span className="muted">Шаблоны:</span>
                {(['json', 'csv', 'txt'] as const).map((e) => <a key={e} className="btn sm" href={`${L}/import/template/${e}`} download><I.Download size={14} /> .{e}</a>)}
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="lnImpSum">
              <Badge kind="ok">Найдено: {ok}</Badge>
              {res.errors.length > 0 && <Badge kind="warn">Ошибок: {res.errors.length}</Badge>}
              <Badge>{res.format.toUpperCase()}</Badge>
              <button className="lnMore" onClick={() => setRes(null)}><I.ChevronLeft size={15} /> Изменить файл</button>
            </div>
            {mode === 'create' && <Field label="Название теста"><Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder={fname.replace(/\.[^.]+$/, '') || 'Название'} /></Field>}
            {mode === 'append' && <Check checked={replace} onChange={setReplace} label="Заменить все существующие вопросы (иначе — добавить в конец)" />}
            {res.errors.length > 0 && (
              <div className="lnImpErr" role="alert">
                <b>Эти задания не будут импортированы:</b>
                <ul>{res.errors.slice(0, 100).map((e, k) => <li key={k}><span>{e.line ? `Строка ${e.line}` : e.index ? `Задание ${e.index}` : 'Файл'}</span> {e.message}</li>)}</ul>
              </div>
            )}
            <div className="lnPrev">
              {res.questions.slice(0, 50).map((q, k) => (
                <div className="lnPrevQ" key={k}>
                  <b>{k + 1}. {q.text}</b>
                  <span className="muted">{TYPES[q.type as Q['type']]} · вес {q.weight}</span>
                  {q.type === 'text' ? <div className="lnPrevA ok">{(q.answers || []).join(' | ')}</div>
                    : (q.options || []).map((o: any, j: number) => <div key={j} className={cx('lnPrevA', o.correct && 'ok')}>{o.correct ? '✓' : '○'} {o.text}</div>)}
                </div>
              ))}
              {ok > 50 && <div className="muted">… и ещё {ok - 50}</div>}
              {!ok && <Empty icon={I.Info} title="Нет подходящих заданий">Проверьте формат по шаблону.</Empty>}
            </div>
          </>
        )}
      </div>
    </Modal>
  );
}
