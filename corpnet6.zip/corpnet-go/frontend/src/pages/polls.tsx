import React, { useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { Link } from '../lib/router';
import { toast, useStore } from '../lib/store';
import { cx, fmtDate, plural } from '../lib/util';
import { Avatar, Btn, Field, Input, Modal, Switch, useConfirm } from '../ui';
import './cal-groups.css';

export interface PollVote { user_id: number; name: string; avatar: string; at: string }
export interface PollOption { id: number; text: string; votes: PollVote[] }
export interface Poll { id: number; question: string; multiple: boolean; closed: boolean; closed_at: string | null; created_by: number | null; voters: number; options: PollOption[] }

const votesWord = (n: number) => plural(n, ['голос', 'голоса', 'голосов']);

/** Local copy of the poll after `me` picked `ids` (shown immediately, replaced by the server's answer). */
function applyVote(p: Poll, me: { id: number; name: string; avatar: string }, ids: number[]): Poll {
  const now = new Date().toISOString();
  const options = p.options.map((o) => {
    const rest = o.votes.filter((v) => v.user_id !== me.id);
    return { ...o, votes: ids.includes(o.id) ? [...rest, { user_id: me.id, name: me.name, avatar: me.avatar, at: now }] : rest };
  });
  return { ...p, options, voters: new Set(options.flatMap((o) => o.votes.map((v) => v.user_id))).size };
}

/** Telegram-like poll card: bars with percentages, who/when voted, change or withdraw a vote until the poll is closed. */
export function PollCard({ poll, canClose, onChange }: { poll: Poll; canClose: boolean; onChange: (p: Poll) => void }) {
  const me = useStore((s) => s.me)!;
  const [busy, setBusy] = useState(false);
  const [who, setWho] = useState(false);
  const [confirm, node] = useConfirm();
  const mine = poll.options.filter((o) => o.votes.some((v) => v.user_id === me.id)).map((o) => o.id);
  const max = Math.max(0, ...poll.options.map((o) => o.votes.length));

  async function vote(ids: number[]) {
    if (poll.closed || busy) return;
    const prev = poll;
    onChange(applyVote(poll, me, ids));
    setBusy(true);
    try {
      const m = await api.post<{ poll: Poll }>(`/api/polls/${poll.id}/vote`, { option_ids: ids });
      if (m?.poll) onChange(m.poll);
    } catch (e) {
      onChange(prev);
      toast({ title: errMsg(e), kind: 'error' }, 3500);
    }
    setBusy(false);
  }
  const pick = (id: number) => {
    if (poll.closed) return;
    if (poll.multiple) vote(mine.includes(id) ? mine.filter((x) => x !== id) : [...mine, id]);
    else vote(mine.includes(id) ? [] : [id]);
  };
  async function close() {
    if (!(await confirm('Завершить голосование?', { text: 'После завершения никто не сможет голосовать и менять свой выбор. Итоги останутся в чате.', ok: 'Завершить' }))) return;
    setBusy(true);
    try { const m = await api.post<{ poll: Poll }>(`/api/polls/${poll.id}/close`); if (m?.poll) onChange(m.poll); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }

  return (
    <div className={cx('poll', poll.closed && 'closed')}>
      <div className="pq"><I.Chart size={16} /><span>{poll.question}</span></div>
      <div className="psub">{poll.closed ? 'Голосование завершено' : poll.multiple ? 'Можно выбрать несколько вариантов' : 'Выберите один вариант'}</div>
      <div className="popts">
        {poll.options.map((o) => {
          const n = o.votes.length;
          const pct = poll.voters ? Math.round((n / poll.voters) * 100) : 0;
          const on = mine.includes(o.id);
          return (
            <div key={o.id} className={cx('popt', on && 'on', poll.closed && n > 0 && n === max && 'win')}>
              <button type="button" className="pbtn" disabled={poll.closed} onClick={() => pick(o.id)} aria-pressed={on} title={poll.closed ? 'Голосование завершено' : on ? 'Нажмите, чтобы отозвать выбор' : 'Выбрать'}>
                <span className={cx('pmark', poll.multiple && 'sq')}>{on && <I.Check size={12} />}</span>
                <span className="ptx">{o.text}</span>
                <span className="ppc">{n > 0 && <span className="faint">{n} · </span>}{pct}%</span>
                <span className="pbar"><i style={{ width: pct + '%' }} /></span>
              </button>
              {who && (
                <div className="pwho">
                  {n === 0 ? <span className="tiny faint">Нет голосов</span> : o.votes.map((v) => (
                    <div key={v.user_id} className="row">
                      <Avatar name={v.name} src={v.avatar} size={20} userId={v.user_id} />
                      <Link to={`/people/${v.user_id}`} className="small clip sp">{v.name}</Link>
                      <span className="tiny faint">{fmtDate(v.at)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
      <div className="pfoot">
        <span>{poll.voters ? votesWord(poll.voters) : 'Пока нет голосов'}{poll.closed && poll.closed_at ? ` · завершено ${fmtDate(poll.closed_at)}` : ''}</span>
        <div className="pact">
          {poll.voters > 0 && <button type="button" className="plnk" onClick={() => setWho(!who)}>{who ? 'Скрыть голоса' : 'Кто голосовал'}</button>}
          {!poll.closed && mine.length > 0 && <button type="button" className="plnk" disabled={busy} onClick={() => vote([])}>Отозвать голос</button>}
          {!poll.closed && canClose && <button type="button" className="plnk dng" disabled={busy} onClick={close}>Завершить голосование</button>}
        </div>
      </div>
      {node}
    </div>
  );
}

export function PollModal({ chatId, onClose, onCreated }: { chatId: number; onClose: () => void; onCreated: (msg: any) => void }) {
  const [q, setQ] = useState('');
  const [opts, setOpts] = useState(['', '']);
  const [multiple, setMultiple] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const filled = opts.map((o) => o.trim()).filter(Boolean);
  const ok = q.trim().length > 0 && filled.length >= 2;
  async function go() {
    setBusy(true); setErr('');
    try { onCreated(await api.post(`/api/chats/${chatId}/polls`, { question: q.trim(), options: filled, multiple })); onClose(); } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title="Новое голосование" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={!ok} onClick={go}>Создать</Btn></>}>
      <Field label="Вопрос"><Input value={q} onChange={(e) => setQ(e.target.value)} maxLength={300} placeholder="Например, когда проведём встречу?" /></Field>
      <div className="stackS">
        <div className="lbl">Варианты ответа · от 2 до 12</div>
        {opts.map((o, i) => (
          <div className="row" key={i}>
            <Input className="sp" value={o} maxLength={200} placeholder={`Вариант ${i + 1}`} onChange={(e) => setOpts(opts.map((x, j) => (j === i ? e.target.value : x)))}
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); if (i === opts.length - 1 && opts.length < 12 && o.trim()) setOpts([...opts, '']); } }} />
            {opts.length > 2 && <Btn kind="ghost" size="sm" icon aria-label="Убрать вариант" onClick={() => setOpts(opts.filter((_, j) => j !== i))}><I.X size={16} /></Btn>}
          </div>
        ))}
        {opts.length < 12 && <div><Btn size="sm" onClick={() => setOpts([...opts, ''])}><I.Plus size={15} /> Добавить вариант</Btn></div>}
      </div>
      <Switch checked={multiple} onChange={setMultiple} label="Можно выбрать несколько вариантов" />
      <div className="hint">Участники чата видят, кто и когда проголосовал. Пока голосование не завершено, выбор можно менять или отозвать; завершить его может автор или администратор.</div>
      {err && <div className="err">{err}</div>}
    </Modal>
  );
}
