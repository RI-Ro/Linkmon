import React, { useCallback, useEffect, useRef, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { Link, navigate, pageHref, useSearchParams, useTitle } from '../lib/router';
import { useStore, toast } from '../lib/store';
import { usePersist } from '../lib/persist';
import { cx, fmtShort, fmtSize, plural, extLabel, thumb, view, imgFallback } from '../lib/util';
import { Lightbox } from '../ui/Lightbox';
import { usePdfPreview } from '../ui/PdfViewer';
import { BookmarkButton } from '../ui/Bookmark';
import { AclEditor, Badge, Btn, Empty, ErrorBox, Field, FileIcon, ImageUpload, Input, Loading, Modal, Pager, Textarea, useConfirm } from '../ui';

const KINDS = {
  documents: { title: 'Документы', icon: I.FileText, hint: 'Регламенты, шаблоны, презентации' },
  photos: { title: 'Фотогалерея', icon: I.Image, hint: 'События и жизнь компании' },
  videos: { title: 'Видео', icon: I.Video, hint: 'Записи встреч, обучение, ролики' },
} as const;
type Kind = keyof typeof KINDS;

/** Вариант файла: original — исходник, thumb — превью для сетки, view — для просмотра (у картинок). */
const fileUrl = (f: any, mode: 'original' | 'thumb' | 'view' = 'original') => {
  if (f.external_url) return f.external_url;
  const u = `/files/${f.id}`;
  return mode === 'thumb' ? thumb(u) : mode === 'view' && f.mime?.startsWith('image/') ? view(u) : u;
};

export function FilesPage({ kind }: { kind: Kind }) {
  const K = KINDS[kind];
  const me = useStore((s) => s.me)!;
  const [sp, setSp] = useSearchParams();
  const folder = +(sp.get('folder') || 0), page = +(sp.get('page') || 1);
  const key = `files:${kind}:${folder}:${page}`;
  const { data, error, refetch } = useQuery<any>(key, () => api.get(`/api/folders?kind=${kind}${folder ? '&parent_id=' + folder : ''}&page=${page}`), { stale: 15000, keepPrevious: true });
  useTitle(data?.folder?.name || K.title);
  const [folderModal, setFolderModal] = useState<null | { edit?: any }>(null);
  const [acl, setAcl] = useState<number | null>(null);
  const [light, setLight] = useState<number | null>(null);
  // вид (список / плитки) — предпочтение пользователя для каждого раздела
  const [view, setView] = usePersist<'list' | 'grid'>('files.' + kind + '.view', kind === 'documents' ? 'list' : 'grid');
  const [uploads, setUploads] = useState<{ name: string; p: number; err?: string }[]>([]);
  const [over, setOver] = useState(false);
  const [confirm, node] = useConfirm();
  const pdf = usePdfPreview(); // PDF открываются во встроенном просмотре (Range-запросы), а не скачиваются целиком
  const inp = useRef<HTMLInputElement>(null);
  const level = data?.level ?? 1;
  const canAdd = level >= 2 && (folder > 0 || me.role !== 'user');
  const files: any[] = data?.files || [];
  const images = files.filter((f) => f.mime.startsWith('image/') || f.mime.startsWith('video/'));

  const upload = useCallback(async (list: File[]) => {
    if (!folder) return toast({ title: 'Откройте папку, чтобы загрузить файлы', kind: 'error' });
    for (const f of list) {
      const idx = Date.now() + Math.random();
      setUploads((u) => [...u, { name: f.name, p: 0, idx } as any]);
      try {
        await api.upload(`/api/folders/${folder}/files`, f, (p) => setUploads((u) => u.map((x: any) => (x.idx === idx ? { ...x, p } : x))));
        setUploads((u) => u.filter((x: any) => x.idx !== idx));
      } catch (e) { setUploads((u) => u.map((x: any) => (x.idx === idx ? { ...x, err: errMsg(e) } : x))); }
    }
    invalidate('files:');
    setTimeout(() => setUploads((u) => u.filter((x) => x.err)), 100);
  }, [folder]);

  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  return (
    <div className="stack" onDragOver={(e) => { if (canAdd && folder && e.dataTransfer.types.includes('Files')) { e.preventDefault(); setOver(true); } }} onDragLeave={(e) => e.currentTarget === e.target && setOver(false)} onDrop={(e) => { e.preventDefault(); setOver(false); if (canAdd) upload(Array.from(e.dataTransfer.files)); }}>
      <div className="pageH">
        <div className="crumbs" style={{ fontSize: 20, fontWeight: 700 }}>
          <Link to={`/${kind}`} style={{ color: folder ? 'var(--muted)' : undefined }}>{K.title}</Link>
          {data?.breadcrumbs?.map((b: any, i: number, a: any[]) => <React.Fragment key={b.id}><I.ChevronRight size={16} />{i < a.length - 1 ? <Link to={`/${kind}?folder=${b.id}`}>{b.name}</Link> : <span style={{ color: 'var(--text)' }}>{b.name}</span>}</React.Fragment>)}
        </div>
        <div className="sp" />
        {folder > 0 && files.length > 0 && (
          <div className="viewSw" role="group" aria-label="Вид">
            <button type="button" className={cx(view === 'grid' && 'on')} onClick={() => setView('grid')} title="Плитки" aria-label="Плитки"><I.Dashboard size={17} /></button>
            <button type="button" className={cx(view === 'list' && 'on')} onClick={() => setView('list')} title="Список" aria-label="Список"><I.List size={17} /></button>
          </div>
        )}
        {canAdd && <Btn onClick={() => setFolderModal({})}><I.Folder size={17} /> Папка</Btn>}
        {canAdd && folder > 0 && <Btn kind="pri" onClick={() => inp.current?.click()}><I.Upload size={17} /> Загрузить</Btn>}
        <input ref={inp} type="file" hidden multiple accept={kind === 'photos' ? 'image/*' : kind === 'videos' ? 'video/*' : undefined} onChange={(e) => { upload(Array.from(e.target.files || [])); e.target.value = ''; }} />
        {data?.folder && level >= 3 && <Btn kind="ghost" icon onClick={() => setFolderModal({ edit: data.folder })} title="Переименовать"><I.Edit size={17} /></Btn>}
        {data?.folder && level >= 4 && <Btn kind="ghost" icon onClick={() => setAcl(folder)} title="Права доступа"><I.Lock size={17} /></Btn>}
        {data?.folder && level >= 3 && <Btn kind="ghost" icon onClick={async () => { if (await confirm('Удалить папку?', { text: 'Будут удалены все вложенные папки и файлы.', ok: 'Удалить' })) { try { await api.del('/api/folders/' + folder); invalidate('files:'); navigate(data.folder.parent_id ? `/${kind}?folder=${data.folder.parent_id}` : `/${kind}`); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } } }} title="Удалить"><I.Trash size={17} /></Btn>}
      </div>
      {data?.folder?.description && <div className="muted">{data.folder.description}</div>}
      {data?.folder?.visibility === 'restricted' && <div><Badge><I.Lock size={11} /> Ограниченный доступ</Badge></div>}
      {over && <div className="dropzone over">Отпустите, чтобы загрузить файлы в эту папку</div>}
      {uploads.length > 0 && <div className="card padS stackS">{uploads.map((u, i) => <div key={i} className="stackS"><div className="row small"><span className="sp clip">{u.name}</span>{u.err ? <span style={{ color: 'var(--danger)' }}>{u.err}</span> : <span>{Math.round(u.p * 100)}%</span>}</div>{!u.err && <div className="prog"><i style={{ width: u.p * 100 + '%' }} /></div>}</div>)}</div>}
      {!data ? <Loading /> : (
        <>
          {data.folders.length > 0 && (
            <div className="fgrid">
              {data.folders.map((f: any) => (
                <Link key={f.id} to={`/${kind}?folder=${f.id}`} className="card folder">
                  <div className="pv" style={f.preview ? { backgroundImage: `url(${thumb(f.preview)})` } : undefined}>{!f.preview && <I.Folder size={44} />}</div>
                  <div className="bd"><div className="bold clip">{f.name}</div><div className="tiny muted">{f.folders_count > 0 && plural(f.folders_count, ['папка', 'папки', 'папок']) + ' · '}{plural(f.files_count, ['файл', 'файла', 'файлов'])}{f.visibility === 'restricted' && ' · 🔒'}</div></div>
                </Link>
              ))}
            </div>
          )}
          {folder > 0 && (files.length === 0 ? (data.folders.length === 0 && <div className="card"><Empty icon={K.icon} title="Здесь пока пусто">{canAdd ? 'Перетащите файлы сюда или нажмите «Загрузить»' : ''}</Empty></div>) : view === 'list' ? (
            <div className="card">
              {files.map((f) => (
                <div key={f.id} className="fileRow">
                  {f.mime.startsWith('image/') ? <img className="fileThumb" src={fileUrl(f, 'thumb')} alt="" loading="lazy" decoding="async" onError={imgFallback} /> : <FileIcon name={f.name} mime={f.mime} />}
                  <a className="sp" style={{ minWidth: 0 }} href={fileUrl(f)} target="_blank" rel="noopener noreferrer" onClick={(e) => { if (pdf.onLinkClick(e, f)) return; const i = images.findIndex((x) => x.id === f.id); if (i >= 0 && !e.metaKey && !e.ctrlKey && !e.shiftKey && e.button === 0) { e.preventDefault(); setLight(i); } }}><div className="bold clip">{f.name}</div><div className="tiny muted">{extLabel(f.name)} · {fmtSize(f.size)} · {fmtShort(f.created_at)}</div></a>
                  <BookmarkButton type="file" id={f.id} /><a className="btn ghost sm icon" href={f.external_url || `/files/${f.id}?dl=1`} download title="Скачать"><I.Download size={17} /></a>
                  {(level >= 3 || f.owner_id === me.id) && <Btn kind="ghost" size="sm" icon onClick={async () => { if (await confirm('Удалить файл?', { ok: 'Удалить' })) { await api.del('/api/files/' + f.id); invalidate('files:'); } }}><I.Trash size={16} /></Btn>}
                </div>
              ))}
            </div>
          ) : kind === 'documents' ? (
            <div className="fgrid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))' }}>
              {files.map((f) => (
                <div key={f.id} className="card docTile">
                  <a className="docOpen" href={fileUrl(f)} target="_blank" rel="noopener noreferrer" onClick={(e) => pdf.onLinkClick(e, f)}><FileIcon name={f.name} mime={f.mime} /><div className="bold clamp2">{f.name}</div><div className="tiny muted">{extLabel(f.name)} · {fmtSize(f.size)}</div></a>
                  <BookmarkButton type="file" id={f.id} /><a className="btn ghost sm icon" href={f.external_url || `/files/${f.id}?dl=1`} download title="Скачать"><I.Download size={16} /></a>
                  {(level >= 3 || f.owner_id === me.id) && <Btn kind="ghost" size="sm" icon title="Удалить" onClick={async () => { if (await confirm('Удалить файл?', { ok: 'Удалить' })) { await api.del('/api/files/' + f.id); invalidate('files:'); } }}><I.Trash size={15} /></Btn>}
                </div>
              ))}
            </div>
          ) : (
            <div className="fgrid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(' + (kind === 'videos' ? 260 : 190) + 'px, 1fr))' }}>
              {files.map((f) => (
                <div key={f.id} style={{ position: 'relative' }}>
                  <button className="photo" style={kind === 'videos' ? { aspectRatio: '16/9' } : undefined} onClick={() => setLight(images.findIndex((x) => x.id === f.id))} aria-label={f.name}>
                    {f.mime.startsWith('image/') ? <img src={fileUrl(f, 'thumb')} alt={f.name} loading="lazy" decoding="async" onError={imgFallback} /> : <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(135deg,#1d3b57,#0e1b2a)' }} />}
                    {f.mime.startsWith('video/') && <span className="pl"><I.Play size={40} /></span>}
                  </button>
                  {kind === 'videos' && <div className="small clip" style={{ padding: '6px 2px' }}>{f.name}</div>}
                  {(level >= 3 || f.owner_id === me.id) && <button className="btn sm icon" style={{ position: 'absolute', top: 6, right: 6, width: 28, height: 28, opacity: .9 }} aria-label="Удалить" onClick={async () => { if (await confirm('Удалить файл?', { ok: 'Удалить' })) { await api.del('/api/files/' + f.id); invalidate('files:'); } }}><I.Trash size={14} /></button>}
                </div>
              ))}
            </div>
          ))}
          {folder > 0 && <Pager href={pageHref} page={page} total={data.total || 0} per={data.per || 60} onChange={(p) => setSp({ page: p > 1 ? p : null }, false)} />}
          {!folder && data.folders.length === 0 && <div className="card"><Empty icon={K.icon} title="Папок пока нет">{K.hint}</Empty></div>}
        </>
      )}
      {light !== null && images[light] && <Lightbox items={images.map((f) => ({ src: fileUrl(f, 'view'), full: fileUrl(f), name: f.name, video: f.mime.startsWith('video/') }))} start={light} onClose={() => setLight(null)} />}
      {folderModal && <FolderModal kind={kind} parent={folder || null} edit={folderModal.edit} onClose={() => setFolderModal(null)} />}
      {acl && <AclEditor type="folder" id={acl} onClose={() => { setAcl(null); invalidate('files:'); }} />}
      {node}
      {pdf.node}
    </div>
  );
}

function FolderModal({ kind, parent, edit, onClose }: { kind: Kind; parent: number | null; edit?: any; onClose: () => void }) {
  const [f, setF] = useState({ name: edit?.name || '', description: edit?.description || '', cover: '', visibility: edit?.visibility || 'company' });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  async function save() {
    setBusy(true);
    try {
      if (edit) await api.put('/api/folders/' + edit.id, { ...f, cover: f.cover || '' });
      else { const r = await api.post('/api/folders', { kind, parent_id: parent, ...f }); invalidate('files:'); navigate(`/${kind}?folder=${r.id}`); }
      invalidate('files:'); onClose();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title={edit ? 'Переименовать папку' : 'Новая папка'} size="sm" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={!f.name.trim()} onClick={save}>{edit ? 'Сохранить' : 'Создать'}</Btn></>}>
      <Field label="Название"><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} maxLength={200} onKeyDown={(e) => e.key === 'Enter' && f.name.trim() && save()} /></Field>
      <Field label="Описание"><Textarea rows={2} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
      {!edit && !parent && <Field label="Доступ"><select className="sel" value={f.visibility} onChange={(e) => setF({ ...f, visibility: e.target.value })}><option value="company">Вся компания</option><option value="restricted">Ограниченный (настроить после создания)</option></select></Field>}
      {err && <div className="err">{err}</div>}
    </Modal>
  );
}
