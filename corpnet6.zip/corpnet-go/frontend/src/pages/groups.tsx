import React, { useEffect, useRef, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { Link, navigate, useSearchParams, useTitle } from '../lib/router';
import { usePersist } from '../lib/persist';
import { useStore, toast, isAdmin } from '../lib/store';
import { cx, fmtDate, thumb, view, imgFallback, plural, copyLink } from '../lib/util';
import { Avatar, Badge, Btn, Empty, ErrorBox, Field, ImageUpload, Input, Loading, Modal, Select, Tabs, Textarea, UserPicker, UserLite, useConfirm } from '../ui';
import './groups.css';
import './cal-groups.css';
import { Comments } from '../ui/Comments';
import { Reactions, type Rx } from '../ui/Reactions';
import { BookmarkButton } from '../ui/Bookmark';
import { EmojiTextarea } from '../ui/EmojiPicker';
import { RichText } from '../lib/richtext';
import { useTopic } from '../lib/ws';

type Vis = 'public' | 'closed' | 'secret';
const VIS: Record<Vis, { label: string; title: string; desc: string; icon: any; kind?: 'ok' | 'warn' | 'accent' }> = {
  public: { label: 'открытая', title: 'Открытая', desc: 'Видна всем сотрудникам. Вступить может любой — достаточно нажать «Вступить».', icon: I.Globe, kind: 'ok' },
  closed: { label: 'закрытая', title: 'Закрытая', desc: 'Видна в списке, но вступить можно только по заявке — её одобряет администратор группы. Публикации видят только участники.', icon: I.Lock },
  secret: { label: 'закрытая, невидимая', title: 'Закрытая и невидимая', desc: 'Не показывается в списках и поиске, для посторонних страницы не существует. Участников добавляет только администратор группы.', icon: I.Shield, kind: 'warn' },
};
function VisBadge({ v }: { v: string }) {
  const m = VIS[(v as Vis)] || VIS.public;
  const Ic = m.icon;
  return <Badge kind={m.kind}><Ic size={11} /> {m.label}</Badge>;
}
const roleBadge = (r?: string) => r === 'owner' ? <Badge kind="accent">владелец</Badge> : r === 'admin' ? <Badge kind="accent">администратор</Badge> : null;

function GroupModal({ g, onClose }: { g?: any; onClose: () => void }) {
  const [f, setF] = useState({ name: g?.name || '', description: g?.description || '', cover: g?.cover || '', visibility: (g?.visibility || 'public') as Vis });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  async function save() {
    setBusy(true); setErr('');
    try {
      const r = g ? await api.put('/api/groups/' + g.id, f) : await api.post('/api/groups', f);
      invalidate('group'); invalidate('chats');
      onClose();
      if (!g) navigate('/groups/' + (r.id ?? r.group?.id));
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title={g ? 'Настройки группы' : 'Новая группа'} onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} onClick={save} disabled={!f.name.trim()}>{g ? 'Сохранить' : 'Создать'}</Btn></>}>
      <Field label="Название"><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} maxLength={120} /></Field>
      <Field label="Описание"><Textarea rows={3} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
      <Field label="Вид группы">
        <div className="visPick" role="radiogroup">
          {(Object.keys(VIS) as Vis[]).map((k) => { const m = VIS[k]; const Ic = m.icon; return (
            <button key={k} type="button" role="radio" aria-checked={f.visibility === k} className={cx('visOpt', f.visibility === k && 'on')} onClick={() => setF({ ...f, visibility: k })}>
              <span className="ic"><Ic size={18} /></span><span><div className="tt">{m.title}</div><div className="ds">{m.desc}</div></span>
            </button>
          ); })}
        </div>
      </Field>
      {g && g.visibility !== 'public' && f.visibility === 'public' && <div className="hint">При переводе в открытую группу все ожидающие заявки на вступление будут сняты.</div>}
      <ImageUpload label="Обложка" value={f.cover} onChange={(v) => setF({ ...f, cover: v })} />
      {err && <div className="err">{err}</div>}
    </Modal>
  );
}

export function GroupsPage() {
  useTitle('Группы');
  const { data, error, refetch } = useQuery<any[]>('groups', () => api.get('/api/groups'), { stale: 30000 });
  const [create, setCreate] = useState(false);
  const [savedTab, setTab] = usePersist<'mine' | 'all'>('groups.tab', 'mine');
  const [sp] = useSearchParams();
  const [q, setQ] = useState(sp.get('q') || ''); // ссылка из поиска: /groups?q=…
  const [fromLink] = useState(!!sp.get('q'));
  const tab = fromLink && q.trim() ? 'all' : savedTab; // найденные по ссылке группы ищем среди всех
  const isMine = (g: any) => g.my_role && g.my_role !== 'pending';
  const base = (data || []).filter((g) => tab === 'all' || isMine(g));
  const list = base.filter((g) => !q.trim() || g.name.toLowerCase().includes(q.trim().toLowerCase()));
  const mineCount = (data || []).filter(isMine).length;
  return (
    <div className="stack">
      <div className="pageH"><h1>Группы</h1><div className="sp" /><Btn kind="pri" onClick={() => setCreate(true)}><I.Plus size={18} /> Создать группу</Btn></div>
      <div className="gTools">
        <Tabs value={tab} onChange={setTab} items={[{ id: 'mine', label: 'Мои группы', count: data ? mineCount : undefined }, { id: 'all', label: 'Все группы', count: data?.length }]} />
        <div className="sp" />
        <Input placeholder="Поиск по названию" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Поиск групп" />
      </div>
      {error && !data ? <ErrorBox error={error} retry={refetch} /> : !data ? <Loading /> : list.length === 0 ? (
        <div className="card"><Empty icon={I.Users} title={q ? 'Ничего не найдено' : tab === 'mine' ? 'Вы пока не состоите в группах' : 'Групп пока нет'}>
          {q ? 'Измените запрос' : tab === 'mine' ? <>Загляните во вкладку «Все группы» или создайте свою — для проекта, команды или интересов.<div style={{ marginTop: 10 }}><Btn onClick={() => setTab('all')}>Все группы</Btn></div></> : 'Создайте первую — для проекта, команды или интересов'}
        </Empty></div>
      ) : (
        <div className="gGrid">
          {list.map((g) => (
            <Link key={g.id} to={`/groups/${g.id}`} className={cx('card deptCard', g.visibility === 'secret' && 'gSecret')}>
              <div className="im" style={g.cover ? { backgroundImage: `url(${thumb(g.cover)})` } : { background: 'linear-gradient(120deg,var(--accent),var(--purple))' }} />
              <div className="bd">
                <div className="row"><span className="bold sp clip">{g.name}</span></div>
                <div className="row" style={{ flexWrap: 'wrap', gap: 6 }}><VisBadge v={g.visibility} />{roleBadge(g.my_role)}{g.my_role === 'pending' && <Badge kind="warn">заявка отправлена</Badge>}{g.my_role === 'member' && <Badge kind="ok">вы в группе</Badge>}</div>
                <div className="small muted clamp2">{g.description}</div>
                <div className="tiny faint row" style={{ gap: 12 }}><span>{plural(g.members, ['участник', 'участника', 'участников'])}</span><span>{plural(g.posts, ['пост', 'поста', 'постов'])}</span></div>
              </div>
            </Link>
          ))}
        </div>
      )}
      {create && <GroupModal onClose={() => setCreate(false)} />}
    </div>
  );
}

function PostCard({ p, canDel, onDeleted, hl, openComments, focusComment }: { p: any; canDel: boolean; onDeleted: () => void; hl?: boolean; openComments?: boolean; focusComment?: number }) {
  const [open, setOpen] = useState(!!openComments);
  const [cc, setCc] = useState(p.comments_count);
  const [confirm, node] = useConfirm();
  useEffect(() => { if (openComments) setOpen(true); }, [openComments]);
  // #comment-<id> deep link: the thread loads asynchronously, so wait for the element to show up
  useEffect(() => {
    if (!open || !focusComment) return;
    let n = 0;
    const t = setInterval(() => {
      const el = document.getElementById('comment-' + focusComment);
      if (el) { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); el.classList.add('hlc'); setTimeout(() => el.classList.remove('hlc'), 3500); clearInterval(t); }
      else if (++n > 20) clearInterval(t);
    }, 250);
    return () => clearInterval(t);
  }, [open, focusComment]);
  return (
    <article id={'post-' + p.id} className={cx('card pad stackS postCard', hl && 'hl')}>
      <div className="row">
        <Link to={`/people/${p.user_id}`}><Avatar name={p.author} src={p.author_avatar} size={44} userId={p.user_id} /></Link>
        <div className="sp"><Link to={`/people/${p.user_id}`} className="bold">{p.author}</Link><div className="tiny muted">{p.author_title} · {fmtDate(p.created_at)}</div></div>
        {canDel && <Btn kind="ghost" size="sm" icon title="Удалить публикацию" onClick={async () => { if (await confirm('Удалить публикацию?', { text: 'Вместе с ней будут удалены комментарии.' })) { try { await api.del('/api/posts/' + p.id); onDeleted(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } } }}><I.Trash size={16} /></Btn>}
      </div>
      <div style={{ whiteSpace: 'pre-wrap', overflowWrap: 'anywhere' }}><RichText text={p.body} /></div>
      {p.image && <img src={view(p.image)} onError={imgFallback} alt="" loading="lazy" style={{ borderRadius: 12, maxHeight: 460, objectFit: 'cover', width: '100%' }} />}
      <div className="actions">
        <Reactions type="post" id={p.id} initial={p.reactions as Rx[] | undefined} pinLike />
        <button className="btn sm" onClick={() => setOpen(!open)}><I.Comment size={16} /> {cc}</button>
        <button className="btn sm ghost" onClick={() => copyLink(`/groups/${p.group_id}?post=${p.id}`)} title="Скопировать ссылку на публикацию"><I.Share size={16} /> <span className="hide-m">Ссылка</span></button>
        <BookmarkButton type="post" id={p.id} initial={p.bookmarked} />
      </div>
      {open && <div style={{ paddingTop: 8 }}><Comments type="post" id={p.id} live onCount={setCc} /></div>}
      {node}
    </article>
  );
}

function AddMembersModal({ gid, secret, existing, onClose }: { gid: number; secret: boolean; existing: number[]; onClose: () => void }) {
  const [users, setUsers] = useState<UserLite[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  async function go() {
    setBusy(true); setErr('');
    try {
      const r = await api.post(`/api/groups/${gid}/members`, { user_ids: users.map((u) => u.id) });
      invalidate('group'); invalidate('groups'); invalidate('chats');
      toast({ title: r.added ? `Добавлено: ${r.added}` : 'Все выбранные уже в группе', kind: 'success' });
      onClose();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title="Добавить участников" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={!users.length} onClick={go}>Добавить{users.length ? ` · ${users.length}` : ''}</Btn></>}>
      {secret && <div className="gNote"><I.Shield size={18} /><div>Группа закрыта и невидима: вступить самостоятельно в неё нельзя. Участников добавляете только вы и другие администраторы группы.</div></div>}
      <Field label="Сотрудники" hint="Добавленные сразу получат доступ к ленте и чату группы и уведомление"><UserPicker value={users} onChange={setUsers} exclude={existing} /></Field>
      {err && <div className="err">{err}</div>}
    </Modal>
  );
}

export function GroupPage({ id }: { id: number }) {
  const me = useStore((s) => s.me)!;
  const [sp, setSp] = useSearchParams();
  const { data, error, refetch } = useQuery<any>('group:' + id, () => api.get('/api/groups/' + id), { stale: 15000 });
  const posts = useQuery<any[]>(data?.can_read ? `group:${id}:posts` : null, () => api.get(`/api/groups/${id}/posts`), { stale: 15000 });
  const [tab, setTab] = usePersist<'feed' | 'chat' | 'members' | 'requests'>('group.tab', 'feed');
  const [edit, setEdit] = useState(false);
  const [adding, setAdding] = useState(false);
  const [text, setText] = useState('');
  const [image, setImage] = useState('');
  const [busy, setBusy] = useState(false);
  const [confirm, node] = useConfirm();
  const [more, setMore] = useState<any[]>([]);
  const [hl, setHl] = useState(0);
  const wantPost = +(sp.get('post') || 0);
  const wantComment = +((location.hash.match(/comment-(\d+)/) || [])[1] || 0);
  const done = useRef(0);
  useTitle(data?.group.name || 'Группа');
  useTopic(data?.can_read ? 'group:' + id : null); // реакции в ленте группы в реальном времени

  const all = [...(posts.data || []), ...more.filter((m) => !posts.data?.some((x) => x.id === m.id))];
  // deep link /groups/<id>?post=<pid>: make sure the post is loaded, scroll to it and highlight
  useEffect(() => {
    if (!wantPost || !data?.can_read || !posts.data || done.current === wantPost) return;
    setTab('feed');
    if (all.some((p) => p.id === wantPost)) {
      done.current = wantPost;
      setTimeout(() => {
        document.getElementById('post-' + wantPost)?.scrollIntoView({ block: 'start', behavior: 'smooth' });
        setHl(wantPost);
        setTimeout(() => setHl(0), 4000);
      }, 150);
    } else {
      done.current = wantPost;
      api.get<any[]>(`/api/groups/${id}/posts?before=${wantPost + 1}`).then((r) => { done.current = 0; setMore((m) => [...m, ...r.filter((x) => !m.some((y) => y.id === x.id))]); if (!r.some((x) => x.id === wantPost)) done.current = wantPost; }).catch(() => {});
    }
  }, [wantPost, data?.can_read, posts.data, all.length]);

  if (error) return <ErrorBox error={error} retry={refetch} />;
  if (!data) return <Loading />;
  const { group: g, members, can_read, can_manage, is_owner } = data;
  const act = async (fn: () => Promise<any>) => { try { await fn(); invalidate('group'); invalidate('groups'); invalidate('chats'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } };
  const pending = members.filter((m: any) => m.role === 'pending');
  const real = members.filter((m: any) => m.role !== 'pending');
  const isMember = !!g.my_role && g.my_role !== 'pending';
  const secret = g.visibility === 'secret';
  async function post() {
    setBusy(true);
    try { await api.post(`/api/groups/${id}/posts`, { body: text.trim(), image }); setText(''); setImage(''); setMore([]); posts.refetch(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  async function loadMore() {
    const last = all.at(-1);
    if (!last) return;
    try { const r = await api.get<any[]>(`/api/groups/${id}/posts?before=${last.id}`); setMore([...more, ...r]); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  const tabs: { id: typeof tab; label: string; count?: number }[] = [{ id: 'feed', label: 'Лента' }];
  if (g.chat_id && (isMember || can_manage)) tabs.push({ id: 'chat', label: 'Чат' });
  tabs.push({ id: 'members', label: 'Участники', count: real.length });
  if (can_manage && pending.length > 0) tabs.push({ id: 'requests', label: 'Заявки', count: pending.length });
  const curTab = tabs.some((t) => t.id === tab) ? tab : 'feed';
  const joinLabel = g.visibility === 'closed' ? 'Подать заявку' : 'Вступить';
  return (
    <div className="stack" style={{ maxWidth: 940 }}>
      <div className="crumbs"><Link to="/groups">Группы</Link><I.ChevronRight size={14} />{g.name}</div>
      <div className="card gHead" style={{ overflow: 'hidden' }}>
        <div className="gCover" style={g.cover ? { background: `url(${thumb(g.cover)}) center/cover` } : secret ? { background: 'linear-gradient(120deg,var(--surface3),var(--purple))' } : undefined} />
        <div className="pad stackS">
          <div className="row" style={{ flexWrap: 'wrap' }}>
            <h1 className="sp" style={{ fontSize: 26 }}>{g.name} <VisBadge v={g.visibility} /></h1>
            {g.chat_id && (isMember || can_manage) && <Link className="btn" to={`/messages?chat=${g.chat_id}`}><I.Message size={16} /> Чат группы</Link>}
            {can_manage && <Btn onClick={() => setAdding(true)}><I.UserPlus size={16} /> Добавить участников</Btn>}
            {can_manage && <Btn onClick={() => setEdit(true)}><I.Settings size={16} /> Настройки</Btn>}
            {!g.my_role && !secret && <Btn kind="pri" onClick={() => act(async () => { const r = await api.post(`/api/groups/${id}/join`); toast({ title: r.role === 'pending' ? 'Заявка отправлена администратору группы' : 'Вы вступили в группу', kind: 'success' }); })}><I.UserPlus size={16} /> {joinLabel}</Btn>}
            {g.my_role === 'pending' && <Badge kind="warn">Заявка на рассмотрении</Badge>}
            {g.my_role === 'pending' && <Btn size="sm" onClick={() => act(() => api.del(`/api/groups/${id}/members/${me.id}`))}>Отозвать заявку</Btn>}
            {isMember && g.my_role !== 'owner' && <Btn onClick={async () => { if (await confirm('Покинуть группу?', { ok: 'Покинуть', text: 'Вы перестанете видеть ленту и чат группы.' })) act(() => api.post(`/api/groups/${id}/leave`)); }}>Выйти</Btn>}
            {is_owner && <Btn kind="dng" icon title="Удалить группу" onClick={async () => { if (await confirm('Удалить группу?', { text: 'Все публикации и чат группы будут удалены безвозвратно.', ok: 'Удалить' })) { try { await api.del('/api/groups/' + id); invalidate('group'); invalidate('chats'); navigate('/groups'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } } }}><I.Trash size={16} /></Btn>}
          </div>
          {g.description && <p className="muted" style={{ whiteSpace: 'pre-wrap' }}>{g.description}</p>}
          <div className="tiny faint row" style={{ gap: 14, flexWrap: 'wrap' }}><span>{VIS[g.visibility as Vis]?.desc}</span></div>
        </div>
      </div>
      {!can_read ? (
        <div className="card"><Empty icon={I.Lock} title="Группа закрыта">
          {g.my_role === 'pending' ? 'Ваша заявка ожидает решения администратора группы.' : 'Лента, участники и чат доступны только участникам. Подайте заявку — её рассмотрит администратор группы.'}
        </Empty></div>
      ) : (
        <>
          <Tabs value={curTab} onChange={setTab} items={tabs} />
          {curTab === 'feed' ? (
            <div className="stack">
              {(isMember || isAdmin(me)) && (
                <div className="card pad stackS">
                  <EmojiTextarea rows={3} value={text} onChange={setText} scope="group" id={id} mentions placeholder="Поделитесь новостью с группой…" maxLength={5000} />
                  {image && <img src={thumb(image)} alt="" style={{ maxHeight: 140, borderRadius: 10, justifySelf: 'start' }} />}
                  <div className="row"><ImageButton onUploaded={setImage} />{image && <Btn size="sm" kind="ghost" onClick={() => setImage('')}>Убрать фото</Btn>}<div className="sp" /><Btn kind="pri" busy={busy} disabled={!text.trim()} onClick={post}><I.Send size={16} /> Опубликовать</Btn></div>
                </div>
              )}
              {posts.loading && !posts.data ? <Loading /> : all.length === 0 ? <div className="card"><Empty icon={I.Newspaper} title="Публикаций пока нет">{isMember ? 'Напишите первую запись для участников группы' : undefined}</Empty></div> : all.map((p) => (
                <PostCard key={p.id} p={p} canDel={p.user_id === me.id || can_manage} hl={hl === p.id} openComments={wantPost === p.id && !!wantComment} focusComment={wantPost === p.id ? wantComment : 0}
                  onDeleted={() => { setMore([]); if (wantPost === p.id) setSp({ post: null }); posts.refetch(); invalidate('groups'); }} />
              ))}
              {all.length >= 20 && all.length % 20 === 0 && <div style={{ textAlign: 'center' }}><Btn onClick={loadMore}>Показать ещё</Btn></div>}
            </div>
          ) : curTab === 'chat' ? (
            <div className="card pad stackS" style={{ alignItems: 'flex-start' }}>
              <div className="row"><I.Message size={22} /><b>Чат группы</b></div>
              <div className="muted">Общий чат участников: сообщения, файлы и голосования. Сюда автоматически попадают все, кто вступил в группу.</div>
              <Link className="btn pri" to={`/messages?chat=${g.chat_id}`}><I.Message size={16} /> Открыть чат</Link>
            </div>
          ) : curTab === 'requests' ? (
            <div className="card">
              <h4 style={{ padding: '14px 18px 0' }}>Заявки на вступление · {pending.length}</h4>
              {pending.map((m: any) => (
                <div key={m.id} className="fileRow mRow"><Avatar name={m.name} src={m.avatar} size={40} /><div className="sp"><Link to={`/people/${m.id}`} className="bold">{m.name}</Link><div className="small muted">{m.job_title}</div></div>
                  <div className="acts"><Btn kind="pri" size="sm" onClick={() => act(() => api.post(`/api/groups/${id}/members/${m.id}/approve`))}><I.Check size={15} /> Принять</Btn><Btn size="sm" onClick={() => act(() => api.del(`/api/groups/${id}/members/${m.id}`))}>Отклонить</Btn></div></div>
              ))}
            </div>
          ) : (
            <div className="stack">
              {can_manage && pending.length > 0 && <div className="gNote"><I.UserPlus size={18} /><div>Есть заявки на вступление: {pending.length}. <button className="lnk" onClick={() => setTab('requests')}>Рассмотреть</button></div></div>}
              <div className="card">
                {can_manage && <div className="row" style={{ padding: '12px 18px', borderBottom: '1px solid var(--line)' }}><span className="sp small muted">{secret ? 'В закрытую невидимую группу участников добавляет только администратор.' : 'Участников можно добавить вручную.'}</span><Btn size="sm" kind="pri" onClick={() => setAdding(true)}><I.UserPlus size={15} /> Добавить участников</Btn></div>}
                {real.map((m: any) => (
                  <div key={m.id} className="fileRow mRow"><Avatar name={m.name} src={m.avatar} size={42} userId={m.id} /><div className="sp"><Link to={`/people/${m.id}`} className="bold">{m.name}</Link><div className="small muted">{m.job_title}</div></div>
                    {roleBadge(m.role)}
                    <div className="acts">
                      {is_owner && (m.role === 'member' || m.role === 'admin') && (
                        <Select style={{ width: 160, minHeight: 34, padding: '4px 30px 4px 10px', fontSize: 13 }} aria-label="Роль" value={m.role} onChange={(e) => act(() => api.put(`/api/groups/${id}/members/${m.id}`, { role: e.target.value }))}>
                          <option value="member">Участник</option><option value="admin">Администратор</option>
                        </Select>
                      )}
                      {can_manage && m.role !== 'owner' && m.id !== me.id && (m.role !== 'admin' || is_owner) && <Btn kind="ghost" size="sm" icon title="Исключить" onClick={async () => { if (await confirm('Исключить участника?', { text: m.name, ok: 'Исключить' })) act(() => api.del(`/api/groups/${id}/members/${m.id}`)); }}><I.X size={16} /></Btn>}
                    </div>
                  </div>
                ))}
              </div>
              {is_owner && <div className="tiny faint">Назначать и снимать администраторов может владелец группы. Администраторы одобряют заявки, добавляют и исключают участников.</div>}
            </div>
          )}
        </>
      )}
      {edit && <GroupModal g={g} onClose={() => setEdit(false)} />}
      {adding && <AddMembersModal gid={id} secret={secret} existing={members.map((m: any) => m.id)} onClose={() => setAdding(false)} />}
      {node}
    </div>
  );
}

function ImageButton({ onUploaded }: { onUploaded: (u: string) => void }) {
  const ref = React.useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  return (
    <>
      <Btn size="sm" kind="ghost" busy={busy} onClick={() => ref.current?.click()}><I.Image size={16} /> Фото</Btn>
      <input ref={ref} type="file" accept="image/*" hidden onChange={async (e) => {
        const f = e.target.files?.[0]; e.target.value = '';
        if (!f) return;
        setBusy(true);
        try { onUploaded((await api.upload<{ url: string }>('/api/uploads/public', f)).url); } catch (er) { toast({ title: errMsg(er), kind: 'error' }); }
        setBusy(false);
      }} />
    </>
  );
}
