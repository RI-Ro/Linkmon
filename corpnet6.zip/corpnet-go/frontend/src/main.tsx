import React, { Component, Suspense, lazy, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';
import { api, setUnauthorizedHandler } from './lib/api';
import { clearQueries } from './lib/query';
import { matchPath, navigate, safeNext, useLocation } from './lib/router';
import { applyTheme, getState, loadUserTheme, setState, useStore } from './lib/store';
import { realtime } from './lib/ws';
import { Shell } from './layout/Shell';
import { Login } from './pages/login';
import { NewsEditor, NewsList, NewsView } from './pages/news';
import { CompanyPage, DepartmentPage, DepartmentsPage, DirectionsPage, PeoplePage, ProfilePage, ResourcesPage, SearchPage, SettingsPage } from './pages/people';
import { GroupPage, GroupsPage } from './pages/groups';
import { IdeasPage, IdeaView } from './pages/ideas';
import { VacationsPage } from './pages/vacations';
import { LearningPage } from './pages/learning';
import { VerifyPage } from './pages/learning/lms-certs';
import { NotificationsPage } from './pages/notifications';
import { BookmarksPage } from './pages/bookmarks';
import { MessengerPage } from './pages/messenger';
import { CalendarPage } from './pages/calendar';
import { FilesPage } from './pages/files';
import { Empty, Loading, Toasts } from './ui';
import { Link } from './lib/router';
import * as I from './lib/icons';

const Admin = lazy(() => import('./admin'));
const RequestsPage = lazy(() => import('./pages/requests').then((m) => ({ default: m.RequestsPage })));

applyTheme(getState().theme);

async function boot() {
  try {
    const r = await api.get('/api/bootstrap');
    if (r.me?.id) loadUserTheme(r.me.id);
    setState({ me: r.me, company: r.company, categories: r.categories, unreadChats: r.unread?.chats || 0, unreadNotifications: r.unread?.notifications || 0, instance: r.instance || '', booted: true });
    realtime.start();
  } catch (e: any) {
    setState({ booted: true, me: null });
  }
}
setUnauthorizedHandler(() => {
  if (!getState().me) return;
  realtime.stop();
  clearQueries();
  setState({ me: null });
});
boot();

const NotFound = () => <div className="card"><Empty icon={I.Search} title="Страница не найдена">Возможно, ссылка устарела или в ней опечатка.<Link to="/" className="btn pri" style={{ marginTop: 10 }}>На главную</Link></Empty></div>;
/** Маршрут с числовым :id — нечисловой id (/news/abc) даёт «не найдено», а не запрос с NaN. */
const withId = (f: (id: number) => React.ReactNode) => (m: Record<string, string>) => (/^\d{1,15}$/.test(m.id) ? f(+m.id) : <NotFound />);

type R = { p: string; el: (m: Record<string, string>) => React.ReactNode; rail?: boolean; wide?: boolean };
const ROUTES: R[] = [
  { p: '/', el: () => <NewsList />, rail: true },
  { p: '/news/new', el: () => <NewsEditor /> },
  { p: '/news/:id/edit', el: withId((id) => <NewsEditor key={id} id={id} />) },
  { p: '/news/:id', el: withId((id) => <NewsView key={id} id={id} />) },
  { p: '/people', el: () => <PeoplePage /> },
  { p: '/people/:id', el: withId((id) => <ProfilePage key={id} id={id} />) },
  { p: '/departments', el: () => <DepartmentsPage /> },
  { p: '/departments/:id', el: withId((id) => <DepartmentPage key={id} id={id} />) },
  { p: '/directions', el: () => <DirectionsPage /> },
  { p: '/learning', el: () => <LearningPage /> },
  { p: '/learning/*', el: () => <LearningPage /> },
  { p: '/requests', el: () => <Suspense fallback={<Loading />}><RequestsPage /></Suspense> },
  { p: '/requests/*', el: () => <Suspense fallback={<Loading />}><RequestsPage /></Suspense> },
  { p: '/ideas', el: () => <IdeasPage /> },
  { p: '/ideas/:id', el: withId((id) => <IdeaView key={id} id={id} />) },
  { p: '/vacations', el: () => <VacationsPage /> },
  { p: '/notifications', el: () => <NotificationsPage /> },
  { p: '/bookmarks', el: () => <BookmarksPage /> },
  { p: '/groups', el: () => <GroupsPage /> },
  { p: '/groups/:id', el: withId((id) => <GroupPage key={id} id={id} />) },
  { p: '/messages', el: () => <MessengerPage /> },
  { p: '/calendar', el: () => <CalendarPage /> },
  { p: '/documents', el: () => <FilesPage kind="documents" /> },
  { p: '/photos', el: () => <FilesPage kind="photos" /> },
  { p: '/videos', el: () => <FilesPage kind="videos" /> },
  { p: '/company', el: () => <CompanyPage /> },
  { p: '/resources', el: () => <ResourcesPage /> },
  { p: '/search', el: () => <SearchPage /> },
  { p: '/settings', el: () => <SettingsPage /> },
  { p: '/admin', el: () => <Suspense fallback={<Loading />}><Admin sub="" /></Suspense> },
  { p: '/admin/:sub', el: (m) => <Suspense fallback={<Loading />}><Admin sub={m.sub} /></Suspense> },
];

class Boundary extends Component<{ children: React.ReactNode; resetKey: string }, { err: any; key: string }> {
  state = { err: null as any, key: this.props.resetKey };
  static getDerivedStateFromError(err: any) { return { err }; }
  static getDerivedStateFromProps(p: any, s: any) { return p.resetKey !== s.key ? { err: null, key: p.resetKey } : null; }
  componentDidCatch(e: any) { console.error(e); }
  render() {
    return this.state.err ? <div className="card"><Empty icon={I.Alert} title="Не удалось отобразить страницу"><button className="btn" onClick={() => location.reload()}>Обновить</button></Empty></div> : this.props.children;
  }
}

function App() {
  const { path, full, hash } = useLocation();
  const booted = useStore((s) => s.booted);
  const me = useStore((s) => s.me);
  const isVerify = path === '/verify' || path.startsWith('/verify/'); // публичная проверка сертификата (без входа)
  // не вошли → /login?next=<путь+query+#hash>; вошли, а открыт /login → на ?next= (только внутренний путь) или на главную
  useEffect(() => {
    if (booted && !me && path !== '/login' && !isVerify) navigate('/login?next=' + encodeURIComponent(full + hash), { replace: true });
    if (me && path === '/login') navigate(safeNext(new URLSearchParams(location.search).get('next')), { replace: true });
  }, [booted, me, path]);
  if (!booted) return null;
  if (isVerify) return <><VerifyPage code={(() => { try { return decodeURIComponent(path.slice('/verify/'.length)); } catch { return ''; } })()} /><Toasts /></>;
  if (!me) return <><Login /><Toasts /></>;
  let hit: { r: R; m: Record<string, string> } | null = null;
  for (const r of ROUTES) { const m = matchPath(r.p, path); if (m) { hit = { r, m }; break; } }
  return (
    <Shell rail={hit?.r.rail} wide={hit?.r.wide}>
      <Boundary resetKey={path}>
        {hit ? hit.r.el(hit.m) : <NotFound />}
      </Boundary>
    </Shell>
  );
}

createRoot(document.getElementById('root')!).render(<App />);
