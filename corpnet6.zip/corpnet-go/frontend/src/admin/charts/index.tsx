// Лёгкие SVG-графики без внешних библиотек: адаптивные (ResizeObserver), с подсказками, легендой-переключателем,
// управлением с клавиатуры (Tab → ←/→/Home/End), таблицей-альтернативой и экспортом CSV. Цвета — var(--chart-N).
import React, { useMemo, useState } from 'react';
import { ChartFrame, Tip, colorOf, fmtCompact, fmtN, niceTicks, useActive, useWidth, type Series } from './core';
export { ChartFrame, fmtN, fmtCompact, fmtPct, fmtDay, downloadCsv, colorOf } from './core';
export type { Series } from './core';

interface Common { labels: string[]; series: Series[]; height?: number; title?: React.ReactNode; sub?: React.ReactNode; csvName?: string; fmt?: (v: number) => string; labelFmt?: (l: string) => string; empty?: string }

function useVisible(series: Series[]) {
  const [hidden, setHidden] = useState<Set<string>>(new Set());
  const toggle = (id: string) => setHidden((h) => { const n = new Set(h); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const vis = series.filter((s) => !hidden.has(s.id));
  return { hidden, toggle, vis };
}

const colorFor = (s: Series, all: Series[]) => s.color || colorOf(all.indexOf(s));

function tableOf(c: Common) {
  return { head: ['', ...c.series.map((s) => s.name)], rows: c.labels.map((l, i) => [c.labelFmt ? c.labelFmt(l) : l, ...c.series.map((s) => s.values[i] ?? 0)]) };
}

function xTicks(labels: string[], w: number, step: (i: number) => number) {
  const every = Math.max(1, Math.ceil(labels.length / Math.max(1, Math.floor(w / 58))));
  return labels.map((l, i) => ({ l, i, x: step(i) })).filter((t) => t.i % every === 0);
}

/** Линия / область (в т.ч. с накоплением). */
export function LineChart(c: Common & { area?: boolean; stacked?: boolean }) {
  const [ref, w] = useWidth<HTMLDivElement>();
  const { hidden, toggle, vis } = useVisible(c.series);
  const n = c.labels.length, H = c.height || 240, L = 44, R = 10, T = 8, B = 24;
  const { i: act, setI, onKey } = useActive(n);
  const fmt = c.fmt || fmtN;
  const stackTotals = useMemo(() => c.labels.map((_, i) => vis.reduce((a, s) => a + (s.values[i] || 0), 0)), [c.labels, vis]);
  const max = c.stacked ? Math.max(0, ...stackTotals) : Math.max(0, ...vis.flatMap((s) => s.values));
  const ticks = niceTicks(max, 4), top = ticks[ticks.length - 1] || 1;
  const pw = Math.max(10, w - L - R), ph = H - T - B;
  const X = (i: number) => L + (n <= 1 ? pw / 2 : (i * pw) / (n - 1));
  const Y = (v: number) => T + ph - (v / top) * ph;
  const paths = useMemo(() => {
    const base = new Array(n).fill(0);
    return vis.map((s) => {
      const lo = c.stacked ? [...base] : new Array(n).fill(0);
      const hi = s.values.map((v, i) => (c.stacked ? base[i] : 0) + (v || 0));
      if (c.stacked) hi.forEach((v, i) => (base[i] = v));
      const line = hi.map((v, i) => `${i ? 'L' : 'M'}${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join('');
      const area = line + lo.map((_, k) => { const i = n - 1 - k; return `L${X(i).toFixed(1)},${Y(lo[i]).toFixed(1)}`; }).join('') + 'Z';
      return { s, hi, line, area };
    });
  }, [vis, n, w, top, c.stacked]); // eslint-disable-line
  const legend = c.series.map((s) => ({ id: s.id, name: s.name, color: colorFor(s, c.series) }));
  const move = (e: React.MouseEvent) => {
    const r = (e.currentTarget as Element).getBoundingClientRect();
    const x = e.clientX - r.left - L;
    setI(Math.max(0, Math.min(n - 1, Math.round(n <= 1 ? 0 : (x / pw) * (n - 1)))));
  };
  const empty = n === 0 || max === 0;
  return (
    <ChartFrame title={c.title} sub={c.sub} legend={legend} hidden={hidden} onToggle={toggle} table={tableOf(c)} csvName={c.csvName}>
      <div className="cfBody" ref={ref} tabIndex={0} onKeyDown={onKey} onBlur={() => setI(null)} onMouseLeave={() => setI(null)}
        aria-label={`${typeof c.title === 'string' ? c.title : 'График'}: ${c.series.map((s) => s.name).join(', ')}. Стрелки влево и вправо переключают точки.`}>
        {w > 0 && (
          <svg width={w} height={H} role="img" aria-hidden={false}>
            {ticks.map((t) => <g key={t}><line className="cfGrid" x1={L} x2={w - R} y1={Y(t)} y2={Y(t)} /><text x={L - 6} y={Y(t) + 4} textAnchor="end">{fmtCompact(t)}</text></g>)}
            {xTicks(c.labels, pw, X).map((t) => <text key={t.i} x={t.x} y={H - 6} textAnchor="middle">{c.labelFmt ? c.labelFmt(t.l) : t.l}</text>)}
            {paths.map(({ s, area, line, hi }) => {
              const col = colorFor(s, c.series);
              return (
                <g key={s.id}>
                  {(c.area || c.stacked) && <path d={area} fill={col} fillOpacity={c.stacked ? 0.85 : 0.14} stroke={c.stacked ? 'var(--surface)' : 'none'} strokeWidth={c.stacked ? 1 : 0} />}
                  {!c.stacked && <path d={line} fill="none" stroke={col} strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />}
                  {n === 1 && <circle cx={X(0)} cy={Y(hi[0])} r={4} fill={col} />}
                  {act !== null && !c.stacked && <circle cx={X(act)} cy={Y(hi[act])} r={4.5} fill={col} stroke="var(--surface)" strokeWidth={2} />}
                </g>
              );
            })}
            {act !== null && <line x1={X(act)} x2={X(act)} y1={T} y2={T + ph} stroke="var(--faint)" strokeDasharray="3 3" />}
            <rect x={L} y={T} width={pw} height={ph} fill="transparent" onMouseMove={move} />
          </svg>
        )}
        {empty && w > 0 && <div className="cfEmpty" style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center' }}>{c.empty || 'Нет данных за период'}</div>}
        {act !== null && !empty && <Tip x={X(act)} y={T + 4} w={w} title={c.labelFmt ? c.labelFmt(c.labels[act]) : c.labels[act]}
          rows={[...vis.map((s) => ({ name: s.name, value: fmt(s.values[act] || 0), color: colorFor(s, c.series) })), ...(c.stacked && vis.length > 1 ? [{ name: 'Всего', value: fmt(stackTotals[act]) }] : [])]} />}
      </div>
    </ChartFrame>
  );
}

/** Столбики: группированные или с накоплением. */
export function BarChart(c: Common & { stacked?: boolean }) {
  const [ref, w] = useWidth<HTMLDivElement>();
  const { hidden, toggle, vis } = useVisible(c.series);
  const n = c.labels.length, H = c.height || 240, L = 44, R = 10, T = 8, B = 24;
  const { i: act, setI, onKey } = useActive(n);
  const fmt = c.fmt || fmtN;
  const totals = c.labels.map((_, i) => vis.reduce((a, s) => a + (s.values[i] || 0), 0));
  const max = c.stacked ? Math.max(0, ...totals) : Math.max(0, ...vis.flatMap((s) => s.values));
  const ticks = niceTicks(max, 4), top = ticks[ticks.length - 1] || 1;
  const pw = Math.max(10, w - L - R), ph = H - T - B, band = pw / Math.max(1, n);
  const Y = (v: number) => T + ph - (v / top) * ph;
  const gw = Math.max(1, band * 0.72), bw = c.stacked ? gw : Math.max(1, gw / Math.max(1, vis.length) - 2);
  const legend = c.series.map((s) => ({ id: s.id, name: s.name, color: colorFor(s, c.series) }));
  const move = (e: React.MouseEvent) => { const r = (e.currentTarget as Element).getBoundingClientRect(); setI(Math.max(0, Math.min(n - 1, Math.floor((e.clientX - r.left - L) / band)))); };
  const bx = (i: number) => L + i * band + (band - gw) / 2;
  const topRound = (x: number, y: number, wd: number, h: number, r = 4) => {
    r = Math.min(r, wd / 2, h);
    return h <= 0 ? '' : `M${x},${y + h}V${y + r}Q${x},${y} ${x + r},${y}H${x + wd - r}Q${x + wd},${y} ${x + wd},${y + r}V${y + h}Z`;
  };
  const empty = n === 0 || max === 0;
  return (
    <ChartFrame title={c.title} sub={c.sub} legend={legend} hidden={hidden} onToggle={toggle} table={tableOf(c)} csvName={c.csvName}>
      <div className="cfBody" ref={ref} tabIndex={0} onKeyDown={onKey} onBlur={() => setI(null)} onMouseLeave={() => setI(null)}
        aria-label={`${typeof c.title === 'string' ? c.title : 'Диаграмма'}: ${c.series.map((s) => s.name).join(', ')}. Стрелки влево и вправо переключают столбики.`}>
        {w > 0 && (
          <svg width={w} height={H} role="img">
            {ticks.map((t) => <g key={t}><line className="cfGrid" x1={L} x2={w - R} y1={Y(t)} y2={Y(t)} /><text x={L - 6} y={Y(t) + 4} textAnchor="end">{fmtCompact(t)}</text></g>)}
            {xTicks(c.labels, pw, (i) => L + i * band + band / 2).map((t) => <text key={t.i} x={t.x} y={H - 6} textAnchor="middle">{c.labelFmt ? c.labelFmt(t.l) : t.l}</text>)}
            {act !== null && <rect x={L + act * band} y={T} width={band} height={ph} fill="var(--surface3)" opacity={0.55} />}
            {c.labels.map((_, i) => {
              let acc = 0;
              return vis.map((s, k) => {
                const v = s.values[i] || 0, col = colorFor(s, c.series);
                if (c.stacked) {
                  const y1 = Y(acc + v), h = Y(acc) - y1; acc += v;
                  const last = k === vis.length - 1 || vis.slice(k + 1).every((q) => !(q.values[i] || 0));
                  return h > 0 ? (last ? <path key={s.id + i} d={topRound(bx(i), y1, bw, h - 2 > 0 ? h - 2 : h)} fill={col} />
                    : <rect key={s.id + i} x={bx(i)} y={y1} width={bw} height={Math.max(0, h - 2)} fill={col} />) : null;
                }
                const x = bx(i) + k * (bw + 2), h = Y(0) - Y(v);
                return h > 0 ? <path key={s.id + i} d={topRound(x, Y(v), bw, h)} fill={col} /> : null;
              });
            })}
            <line className="cfAxis" x1={L} x2={w - R} y1={Y(0)} y2={Y(0)} />
            <rect x={L} y={T} width={pw} height={ph} fill="transparent" onMouseMove={move} />
          </svg>
        )}
        {empty && w > 0 && <div className="cfEmpty" style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center' }}>{c.empty || 'Нет данных за период'}</div>}
        {act !== null && !empty && <Tip x={L + act * band + band / 2} y={T + 4} w={w} title={c.labelFmt ? c.labelFmt(c.labels[act]) : c.labels[act]}
          rows={[...vis.map((s) => ({ name: s.name, value: fmt(s.values[act] || 0), color: colorFor(s, c.series) })), ...(c.stacked && vis.length > 1 ? [{ name: 'Всего', value: fmt(totals[act]) }] : [])]} />}
      </div>
    </ChartFrame>
  );
}

export interface HItem { id?: string | number; label: string; value: number; sub?: string; color?: string; extra?: string }
/** Горизонтальные полосы (рейтинги). onPick — клик/Enter по строке. */
export function HBars({ items, title, sub, fmt = fmtN, csvName, onPick, empty, max }: { items: HItem[]; title?: React.ReactNode; sub?: React.ReactNode; fmt?: (v: number) => string; csvName?: string; onPick?: (it: HItem) => void; empty?: string; max?: number }) {
  const m = max ?? Math.max(0, ...items.map((i) => i.value));
  return (
    <ChartFrame title={title} sub={sub} table={{ head: ['', 'Значение'], rows: items.map((i) => [i.label, i.value]) }} csvName={csvName}>
      {items.length === 0 ? <div className="cfEmpty">{empty || 'Нет данных за период'}</div> : (
        <div className="hb" role="list">
          {items.map((it, k) => (
            <React.Fragment key={(it.id ?? it.label) + ':' + k}>
              <div className={'lb' + (onPick ? ' lk' : '')} role="listitem" title={it.label} tabIndex={onPick ? 0 : undefined}
                onClick={() => onPick?.(it)} onKeyDown={(e) => onPick && (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), onPick(it))}>{it.label}{it.sub && <span className="cfSub"> · {it.sub}</span>}</div>
              <div className="tr"><i style={{ width: (m ? (it.value / m) * 100 : 0) + '%', background: it.color || colorOf(0) }} /></div>
              <div className="vl">{fmt(it.value)}{it.extra && <span className="cfSub"> {it.extra}</span>}</div>
            </React.Fragment>
          ))}
        </div>
      )}
    </ChartFrame>
  );
}

/** Тепловая карта: строки × столбцы (день недели × час). */
export function Heatmap({ rows, cols, data, title, sub, csvName, fmt = fmtN, unit = '' }: { rows: string[]; cols: string[]; data: number[][]; title?: React.ReactNode; sub?: React.ReactNode; csvName?: string; fmt?: (v: number) => string; unit?: string }) {
  const max = Math.max(0, ...data.flat());
  const [tip, setTip] = useState<{ r: number; c: number } | null>(null);
  const [ref, w] = useWidth<HTMLDivElement>();
  const everyH = w < 560 ? 3 : 1;
  return (
    <ChartFrame title={title} sub={sub} table={{ head: ['', ...cols], rows: rows.map((r, i) => [r, ...data[i]]) }} csvName={csvName}>
      <div className="cfBody" ref={ref} style={{ position: 'relative' }} onMouseLeave={() => setTip(null)}>
        {max === 0 ? <div className="cfEmpty">Нет данных за период</div> : (
          <div className="hm" role="grid" aria-label={typeof title === 'string' ? title : 'Тепловая карта'} style={{ gridTemplateColumns: `34px repeat(${cols.length}, minmax(0, 1fr))` }}>
            <div />{cols.map((c, j) => <div className="h" key={j} aria-hidden>{j % everyH === 0 ? c : ''}</div>)}
            {rows.map((r, i) => (
              <React.Fragment key={i}>
                <div className="d" role="rowheader">{r}</div>
                {cols.map((c, j) => {
                  const v = data[i][j] || 0;
                  return <div key={j} className="c" role="gridcell" tabIndex={v > 0 ? 0 : -1} aria-label={`${r}, ${c}: ${fmt(v)} ${unit}`} style={{ ['--k' as any]: Math.min(1, v / max) }}
                    onMouseEnter={() => setTip({ r: i, c: j })} onFocus={() => setTip({ r: i, c: j })} onBlur={() => setTip(null)} />;
                })}
              </React.Fragment>
            ))}
          </div>
        )}
        {tip && <div className="cfTip" role="status" style={{ top: 0, right: 0 }}><b>{rows[tip.r]}, {cols[tip.c]}:00</b><div className="r"><span>{unit || 'Значение'}</span><span className="v">{fmt(data[tip.r][tip.c] || 0)}</span></div></div>}
      </div>
    </ChartFrame>
  );
}

/** Кольцевая диаграмма с подписями-списком (не более 8 долей; остальное сворачивайте в «Прочее»). */
export function Donut({ items, title, sub, csvName, fmt = fmtN, size = 150 }: { items: { id: string; label: string; value: number }[]; title?: React.ReactNode; sub?: React.ReactNode; csvName?: string; fmt?: (v: number) => string; size?: number }) {
  const total = items.reduce((a, b) => a + b.value, 0);
  const [act, setAct] = useState<number | null>(null);
  const R = size / 2 - 6, r = R * 0.62, cx = size / 2;
  let a0 = -Math.PI / 2;
  const arcs = items.map((it, k) => {
    const frac = total ? it.value / total : 0, a1 = a0 + frac * Math.PI * 2 - (frac > 0.999 ? 0.0001 : 0);
    const big = a1 - a0 > Math.PI ? 1 : 0;
    const p = (rad: number, a: number) => `${(cx + rad * Math.cos(a)).toFixed(2)},${(cx + rad * Math.sin(a)).toFixed(2)}`;
    const d = frac > 0 ? `M${p(R, a0)}A${R},${R} 0 ${big} 1 ${p(R, a1)}L${p(r, a1)}A${r},${r} 0 ${big} 0 ${p(r, a0)}Z` : '';
    a0 += frac * Math.PI * 2;
    return { it, d, k };
  });
  return (
    <ChartFrame title={title} sub={sub} table={{ head: ['', 'Значение', 'Доля'], rows: items.map((i) => [i.label, i.value, total ? Math.round((i.value / total) * 1000) / 10 + '%' : '0%']) }} csvName={csvName}>
      {total === 0 ? <div className="cfEmpty">Нет данных за период</div> : (
        <div className="donutW">
          <svg width={size} height={size} role="img" aria-label={`${typeof title === 'string' ? title : 'Доли'}: ${items.map((i) => `${i.label} ${total ? Math.round((i.value / total) * 100) : 0}%`).join(', ')}`}>
            {arcs.map(({ it, d, k }) => d && <path key={it.id} d={d} fill={colorOf(k)} stroke="var(--surface)" strokeWidth={2} opacity={act === null || act === k ? 1 : 0.4} onMouseEnter={() => setAct(k)} onMouseLeave={() => setAct(null)} />)}
            <text x={cx} y={cx - 2} textAnchor="middle" style={{ fill: 'var(--text)', fontSize: 18, fontWeight: 700 }}>{act !== null ? Math.round((items[act].value / total) * 100) + '%' : fmtCompact(total)}</text>
            <text x={cx} y={cx + 14} textAnchor="middle">{act !== null ? items[act].label : 'всего'}</text>
          </svg>
          <div className="donutL">
            {items.map((it, k) => <button key={it.id} type="button" className="r" style={{ background: 'none', border: 0, padding: 0, color: 'inherit', textAlign: 'left' }} onFocus={() => setAct(k)} onBlur={() => setAct(null)} onMouseEnter={() => setAct(k)} onMouseLeave={() => setAct(null)}>
              <i style={{ background: colorOf(k) }} /><span>{it.label}</span><span className="n">{fmt(it.value)} · {Math.round((it.value / total) * 100)}%</span></button>)}
          </div>
        </div>
      )}
    </ChartFrame>
  );
}

/** Спарклайн для KPI-плиток (декоративный: значение дублируется текстом плитки). */
export function Sparkline({ values, color = 'var(--chart-1)', height = 34 }: { values: number[]; color?: string; height?: number }) {
  const n = values.length;
  if (n < 2 || Math.max(...values) === 0) return <div style={{ height }} aria-hidden />;
  const max = Math.max(...values), min = Math.min(...values), W = 100, rng = max - min || 1;
  const pts = values.map((v, i) => [(i / (n - 1)) * W, height - 3 - ((v - min) / rng) * (height - 8)]);
  const line = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join('');
  return (
    <svg className="spark" viewBox={`0 0 ${W} ${height}`} preserveAspectRatio="none" style={{ height }} aria-hidden>
      <path d={`${line}L${W},${height}L0,${height}Z`} fill={color} fillOpacity={0.12} />
      <path d={line} fill="none" stroke={color} strokeWidth={1.8} vectorEffect="non-scaling-stroke" strokeLinejoin="round" />
      <circle cx={pts[n - 1][0]} cy={pts[n - 1][1]} r={2.2} fill={color} vectorEffect="non-scaling-stroke" />
    </svg>
  );
}
