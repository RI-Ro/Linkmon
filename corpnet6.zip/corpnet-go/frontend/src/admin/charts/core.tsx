import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import './charts.css';

export const COLORS = Array.from({ length: 8 }, (_, i) => `var(--chart-${i + 1})`);
export const colorOf = (i: number) => COLORS[i % COLORS.length];

/** Ширина контейнера (ResizeObserver): графики перерисовываются под размер и не выходят за карточку. */
export function useWidth<T extends HTMLElement>(): [React.RefObject<T>, number] {
  const ref = useRef<T>(null);
  const [w, setW] = useState(0);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    setW(el.clientWidth);
    const ro = new ResizeObserver((e) => setW(Math.floor(e[0].contentRect.width)));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return [ref, w];
}

const nf = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 1 });
export const fmtN = (v: number) => nf.format(Math.round(v * 10) / 10);
export const fmtCompact = (v: number) => {
  const a = Math.abs(v);
  if (a >= 1e6) return nf.format(v / 1e6) + ' млн';
  if (a >= 1e4) return nf.format(v / 1e3) + ' тыс.';
  return nf.format(Math.round(v * 10) / 10);
};
export const fmtPct = (v: number, d = 1) => (v * 100).toLocaleString('ru-RU', { maximumFractionDigits: d }) + '%';
export const fmtDay = (d: string) => (d ? d.slice(8, 10) + '.' + d.slice(5, 7) : '');

/** «Красивые» деления оси от 0 до max. */
export function niceTicks(max: number, n = 4): number[] {
  if (!(max > 0)) return [0, 1];
  const raw = max / n, p = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / p;
  const step = (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p;
  const out: number[] = [];
  for (let v = 0; v < max + step * 0.999; v += step) out.push(+v.toFixed(10));
  return out;
}

export function toCsv(head: string[], rows: (string | number)[][]): string {
  const q = (v: string | number) => {
    let s = String(v);
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // защита от CSV-инъекции в Excel
    return /[;"\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  return '﻿' + [head, ...rows].map((r) => r.map(q).join(';')).join('\r\n');
}
export function downloadCsv(name: string, head: string[], rows: (string | number)[][]) {
  const url = URL.createObjectURL(new Blob([toCsv(head, rows)], { type: 'text/csv;charset=utf-8' }));
  const a = document.createElement('a');
  a.href = url; a.download = name.replace(/[^\w\-а-яё.]+/gi, '_') + '.csv';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export interface Series { id: string; name: string; values: number[]; color?: string }

/** Обёртка графика: заголовок, легенда (переключает серии), «Данные» (таблица-альтернатива), экспорт CSV. */
export function ChartFrame(p: {
  title?: React.ReactNode; sub?: React.ReactNode; legend?: { id: string; name: string; color: string }[]; hidden?: Set<string>; onToggle?: (id: string) => void;
  table?: { head: string[]; rows: (string | number)[][] }; csvName?: string; children: React.ReactNode; actions?: React.ReactNode;
}) {
  const [data, setData] = useState(false);
  return (
    <div className="cf">
      {(p.title || p.table) && (
        <div className="cfHead">
          {p.title && <h3>{p.title}</h3>}
          {p.sub && <span className="cfSub">{p.sub}</span>}
          <div className="cfTools">
            {p.actions}
            {p.table && <button type="button" aria-pressed={data} onClick={() => setData(!data)} title="Показать данные таблицей">Данные</button>}
            {p.table && <button type="button" onClick={() => downloadCsv(p.csvName || String(p.title || 'chart'), p.table!.head, p.table!.rows)} title="Скачать CSV">CSV</button>}
          </div>
        </div>
      )}
      {p.legend && p.legend.length > 1 && (
        <div className="cfLegend">
          {p.legend.map((l) => (
            <button key={l.id} type="button" aria-pressed={!p.hidden?.has(l.id)} onClick={() => p.onToggle?.(l.id)}><i style={{ background: l.color }} />{l.name}</button>
          ))}
        </div>
      )}
      {data && p.table ? <DataTable {...p.table} /> : p.children}
    </div>
  );
}

export function DataTable({ head, rows }: { head: string[]; rows: (string | number)[][] }) {
  return (
    <div className="cfTable" tabIndex={0} role="region" aria-label="Данные графика">
      <table><thead><tr>{head.map((h, i) => <th key={i} scope="col">{h}</th>)}</tr></thead>
        <tbody>{rows.map((r, i) => <tr key={i}>{r.map((c, j) => (j === 0 ? <th key={j} scope="row" style={{ fontWeight: 500 }}>{c}</th> : <td key={j}>{typeof c === 'number' ? fmtN(c) : c}</td>))}</tr>)}</tbody></table>
    </div>
  );
}

export function Tip({ x, y, w, title, rows }: { x: number; y: number; w: number; title: string; rows: { name: string; value: string; color?: string }[] }) {
  const left = x > w * 0.6;
  return (
    <div className="cfTip" role="status" style={{ top: Math.max(0, y), [left ? 'right' : 'left']: left ? w - x + 12 : x + 12 } as React.CSSProperties}>
      <b>{title}</b>
      {rows.map((r, i) => <div className="r" key={i}><span>{r.color && <i style={{ background: r.color }} />}{r.name}</span><span className="v">{r.value}</span></div>)}
    </div>
  );
}

/** Хук активного индекса: наведение мыши и стрелки на клавиатуре. */
export function useActive(n: number) {
  const [i, setI] = useState<number | null>(null);
  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowRight') { e.preventDefault(); setI((v) => Math.min(n - 1, (v ?? -1) + 1)); }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); setI((v) => Math.max(0, (v ?? n) - 1)); }
    else if (e.key === 'Home') setI(0);
    else if (e.key === 'End') setI(n - 1);
    else if (e.key === 'Escape') setI(null);
  };
  useEffect(() => { setI((v) => (v !== null && v >= n ? null : v)); }, [n]);
  return { i, setI, onKey };
}
