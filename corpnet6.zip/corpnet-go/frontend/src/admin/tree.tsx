import React, { useMemo, useRef, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { useStore, isAdmin, toast } from '../lib/store';
import { cx, plural } from '../lib/util';
import { usePersistSet } from '../lib/persist';
import { Badge, Btn, Empty, Field, Input, ImageUpload, Loading, Modal, Textarea, UserPicker, useConfirm } from '../ui';
import { MdEditor } from '../ui/MdEditor';
import { DeptSelect } from '../ui/DeptSelect';
import { NodeSelect, QueryView, TNode, buildTree, inSubtree, nodeCmp } from './common';

type Kind = 'departments' | 'directions';
const CFG = {
  departments: { url: '/api/departments', key: 'departments', one: 'подразделение', Icon: I.Building },
  directions: { url: '/api/directions', key: 'admin:directions', one: 'направление', Icon: I.Layers },
};
type Zone = 'before' | 'inside' | 'after';
interface Target { parent: number | null; index: number }

export function TreeAdmin({ kind }: { kind: Kind }) {
  const cfg = CFG[kind];
  const me = useStore((s) => s.me)!;
  const admin = isAdmin(me);
  const isDept = kind === 'departments';
  const q = useQuery<TNode[]>(cfg.key, () => api.get(cfg.url), { stale: 0 });
  // раскрытые узлы — предпочтение пользователя (по умолчанию всё свёрнуто)
  const [opened, updOpen] = usePersistSet('admin.' + kind + '.open');
  const [dragId, setDragId] = useState<number | null>(null);
  const [over, setOver] = useState<{ id: number | null; zone: Zone | 'root' } | null>(null);
  const [edit, setEdit] = useState<any | null>(null);
  const [confirm, node] = useConfirm();
  const hoverTimer = useRef<{ id: number; t: any } | null>(null);
  const items = q.data || [];
  const { byId, kids } = useMemo(() => buildTree(items), [items]);

  const rows = useMemo(() => {
    const out: { n: TNode; depth: number }[] = [];
    const walk = (p: number | null, depth: number) => {
      for (const n of kids.get(p) || []) {
        out.push({ n, depth });
        if (opened.has(n.id)) walk(n.id, depth + 1);
      }
    };
    walk(null, 0);
    return out;
  }, [kids, opened]);

  // ближайшее направление-предок с подразделением (права наследуются вниз)
  const effDept = (n: TNode): { id: number; name: string; own: boolean } | null => {
    let cur: TNode | undefined = n, own = true, g = 0;
    while (cur && g++ < 100) {
      if (cur.department_id) return { id: cur.department_id, name: cur.department || '#' + cur.department_id, own };
      own = false;
      cur = cur.parent_id != null ? byId.get(cur.parent_id) : undefined;
    }
    return null;
  };

  const scopeRoots = items.filter((n) => n.can_manage && !(n.parent_id != null && byId.get(n.parent_id)?.can_manage));

  const toggle = (id: number) => updOpen((o) => { const n = new Set(o); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const expandAll = () => updOpen(() => new Set(items.filter((n) => kids.has(n.id)).map((n) => n.id)));

  // ---------------- drag & drop
  const sibsWithout = (parent: number | null, skip: number) => (kids.get(parent) || []).filter((x) => x.id !== skip);

  function resolve(n: TNode, zone: Zone, drag: number): Target {
    if (zone === 'inside') return { parent: n.id, index: sibsWithout(n.id, drag).length };
    if (zone === 'after' && opened.has(n.id) && (kids.get(n.id) || []).some((k) => k.id !== drag)) return { parent: n.id, index: 0 };
    const sibs = sibsWithout(n.parent_id, drag);
    const i = sibs.findIndex((s) => s.id === n.id);
    return { parent: n.parent_id, index: zone === 'before' ? i : i + 1 };
  }

  /** null — можно; строка — почему нельзя (для подсказки). '' — просто ничего не меняется. */
  function why(drag: number, t: Target): string | null {
    const d = byId.get(drag);
    if (!d || !d.can_manage) return 'Нет прав';
    if (t.parent === null && !admin) return 'Корневой уровень — только для администратора';
    if (t.parent !== null) {
      if (t.parent === drag || inSubtree(byId, drag, t.parent)) return 'Нельзя вложить в себя';
      if (!byId.get(t.parent)?.can_manage) return 'Целевой узел вне вашей области';
    }
    if (t.parent === (d.parent_id ?? null)) {
      const old = (kids.get(d.parent_id) || []).findIndex((s) => s.id === drag);
      if (old === t.index) return '';
    }
    return null;
  }

  function onOver(e: React.DragEvent, n: TNode) {
    if (dragId == null) return;
    const r = e.currentTarget.getBoundingClientRect();
    const y = (e.clientY - r.top) / r.height;
    const zone: Zone = y < 0.25 ? 'before' : y > 0.75 ? 'after' : 'inside';
    if (n.id === dragId || why(dragId, resolve(n, zone, dragId)) !== null) {
      if (over) setOver(null);
      return;
    }
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (over?.id !== n.id || over.zone !== zone) setOver({ id: n.id, zone });
    if (zone === 'inside' && kids.has(n.id) && !opened.has(n.id)) {
      if (hoverTimer.current?.id !== n.id) {
        clearTimeout(hoverTimer.current?.t);
        hoverTimer.current = { id: n.id, t: setTimeout(() => updOpen((o) => new Set([...o, n.id])), 600) };
      }
    }
  }
  function endDrag() {
    clearTimeout(hoverTimer.current?.t); hoverTimer.current = null;
    setDragId(null); setOver(null);
  }
  function onDrop(e: React.DragEvent, n: TNode | null) {
    e.preventDefault();
    const drag = dragId;
    const zone = over?.zone;
    endDrag();
    if (drag == null || !zone) return;
    const t: Target = n === null ? { parent: null, index: (kids.get(null) || []).filter((x) => x.id !== drag).length } : resolve(n, zone as Zone, drag);
    if (why(drag, t) !== null) return;
    move(drag, t);
  }

  async function move(id: number, t: Target) {
    const n = byId.get(id)!;
    const where = t.parent == null ? 'в корень' : `внутрь «${byId.get(t.parent)!.name}»`;
    const ok = await confirm(`Переместить «${n.name}»?`, { text: t.parent === n.parent_id ? 'Изменится порядок среди соседей.' : `Новое расположение: ${where}.${isDept ? ' Сотрудники и новости останутся в подразделении.' : ' Права доступа будут наследоваться от нового родителя.'}`, ok: 'Переместить', danger: false });
    if (!ok) return;
    const snapshot = items;
    const order = sibsWithout(t.parent, id).map((x) => x.id);
    order.splice(Math.min(t.index, order.length), 0, id);
    const sorts = new Map(order.map((x, i) => [x, (i + 1) * 10]));
    q.mutate((old) => (old || []).map((x) => (x.id === id ? { ...x, parent_id: t.parent, sort: sorts.get(x.id)! } : sorts.has(x.id) ? { ...x, sort: sorts.get(x.id)! } : x)));
    if (t.parent != null) updOpen((o) => new Set([...o, t.parent!]));
    try {
      await api.post(`${cfg.url}/${id}/move`, { parent_id: t.parent, index: t.index });
      toast({ title: 'Перемещено', kind: 'success' }, 1800);
      afterChange();
    } catch (e) {
      q.mutate(() => snapshot);
      toast({ title: 'Не удалось переместить', body: errMsg(e), kind: 'error' });
    }
  }

  function afterChange() {
    q.refetch();
    invalidate('departments'); invalidate('directions'); invalidate('admin:directions'); invalidate('news'); invalidate('users');
  }

  async function remove(n: TNode) {
    if (!(await confirm(`Удалить ${cfg.one} «${n.name}»?`, { text: isDept ? 'Удаление возможно, только если в подразделении нет сотрудников, дочерних подразделений и привязанных направлений.' : 'Вложенные направления нужно сначала удалить или перенести.', ok: 'Удалить' }))) return;
    try { await api.del(`${cfg.url}/${n.id}`); toast({ title: 'Удалено', kind: 'success' }, 1800); afterChange(); }
    catch (e) { toast({ title: 'Не удалось удалить', body: errMsg(e), kind: 'error' }); }
  }

  const canAddRoot = isDept ? admin : true;
  return (
    <QueryView q={q}>
      {() => (
        <div className="stack">
          <div className={cx('adminScope', !admin && !scopeRoots.length && 'warn')}>
            <I.Shield size={17} />
            <div>
              {admin ? <><b>Вы управляете: всеми {isDept ? 'подразделениями' : 'направлениями'}.</b> </> : scopeRoots.length ? <><b>Вы управляете: {scopeRoots.map((n) => n.name).join(', ')}</b> и всеми вложенными. Остальные узлы показаны серым и недоступны. </> : <b>Вам не назначено ни одного {isDept ? 'подразделения' : 'направления'} для управления. </b>}
              {isDept
                ? <>Корневые подразделения создаёт и переносит только администратор. Нельзя удалить подразделение с сотрудниками или дочерними узлами.</>
                : <>Права на направление задаются через подразделение и <b>наследуются вниз</b> по дереву направлений.</>}
            </div>
          </div>
          <div className="card">
            <div className="tbar">
              <div className="grow muted small">{plural(items.length, isDept ? ['подразделение', 'подразделения', 'подразделений'] : ['направление', 'направления', 'направлений'])} · перетаскивайте <span className="hideS">мышью</span>, чтобы менять вложенность и порядок</div>
              <Btn size="sm" onClick={expandAll}><I.ChevronDown size={15} /> Развернуть все</Btn>
              <Btn size="sm" onClick={() => updOpen(() => new Set())}><I.ChevronRight size={15} /> Свернуть все</Btn>
              {canAddRoot && <Btn size="sm" kind="pri" onClick={() => setEdit({ parent_id: null })}><I.Plus size={16} /> {isDept ? 'Корневое подразделение' : 'Добавить направление'}</Btn>}
            </div>
            {!items.length ? <Empty icon={cfg.Icon} title={isDept ? 'Подразделений пока нет' : 'Направлений пока нет'} /> : (
              <div className="tree" onDragLeave={(e) => { if (!e.currentTarget.contains(e.relatedTarget as Node)) setOver(null); }}>
                {rows.map(({ n, depth }) => {
                  const hasKids = kids.has(n.id);
                  const eff = !isDept ? effDept(n) : null;
                  return (
                    <div key={n.id} className={cx('tnode', !n.can_manage && 'ro', dragId === n.id && 'dragging', over?.id === n.id && 'over-' + over.zone)}
                      style={{ marginLeft: depth * 22 }} draggable={!!n.can_manage}
                      onDragStart={(e) => { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', String(n.id)); setDragId(n.id); }}
                      onDragEnd={endDrag} onDragOver={(e) => onOver(e, n)} onDrop={(e) => onDrop(e, n)}>
                      <button type="button" className={cx('tchev', !hasKids && 'sp0')} onClick={() => hasKids && toggle(n.id)} aria-label={opened.has(n.id) ? 'Свернуть' : 'Развернуть'} tabIndex={hasKids ? 0 : -1}>
                        {hasKids && (opened.has(n.id) ? <I.ChevronDown size={17} /> : <I.ChevronRight size={17} />)}
                      </button>
                      <span className="tico"><cfg.Icon size={16} /></span>
                      <div className="tbody">
                        <div className="tname" title={n.name}>{n.name}</div>
                        <div className="tmeta">
                          {isDept ? (
                            <>
                              <span title="Сотрудников в подразделении"><I.Users size={13} /> {n.employees ?? 0}</span>
                              {n.head && <span className="hideS"><I.UserCheck size={13} /> {n.head}</span>}
                              {n.children_count > 0 && <span className="hideS">вложено: {n.children_count}</span>}
                            </>
                          ) : (
                            <>
                              {eff ? <span title={eff.own ? 'Подразделение направления' : 'Права унаследованы от родителя'}><I.Key size={13} /> {eff.name}{!eff.own && <span className="faint"> (наследует)</span>}</span> : <span className="faint"><I.Key size={13} /> права: только администратор</span>}
                            </>
                          )}
                        </div>
                      </div>
                      {!n.can_manage && <span className="lockNote hideS"><I.Lock size={13} /> вне вашей области</span>}
                      {n.can_manage && (
                        <div className="tact">
                          <Btn kind="ghost" size="sm" icon title={`Добавить дочернее ${cfg.one}`} onClick={() => setEdit({ parent_id: n.id })}><I.Plus size={16} /></Btn>
                          <Btn kind="ghost" size="sm" icon title="Изменить" onClick={() => setEdit(n)}><I.Edit size={16} /></Btn>
                          <Btn kind="ghost" size="sm" icon title="Удалить" onClick={() => remove(n)}><I.Trash size={16} /></Btn>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
            {dragId != null && admin && (
              <div className={cx('tdrop', over?.zone === 'root' && 'over')}
                onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; if (over?.zone !== 'root') setOver({ id: null, zone: 'root' }); }}
                onDrop={(e) => onDrop(e, null)}>
                Перетащите сюда, чтобы сделать узел корневым (последним на верхнем уровне)
              </div>
            )}
          </div>
          {node}
          {edit && (isDept
            ? <DeptModal item={edit} items={items} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); afterChange(); }} />
            : <DirModal item={edit} items={items} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); afterChange(); }} />)}
        </div>
      )}
    </QueryView>
  );
}

// ---------------------------------------------------------------- department editor
function DeptModal({ item, items, onClose, onSaved }: { item: any; items: TNode[]; onClose: () => void; onSaved: () => void }) {
  const id: number | undefined = item.id;
  const full = useQuery<any>(id ? 'admin:dept:' + id : null, () => api.get('/api/departments/' + id), { stale: 0 });
  if (id && !full.data) {
    return <Modal title="Подразделение" onClose={onClose}>{full.error ? <div className="err">{errMsg(full.error)}</div> : <Loading />}</Modal>;
  }
  return <DeptForm init={id ? full.data.department : item} items={items} onClose={onClose} onSaved={() => { if (id) invalidate('admin:dept:'); onSaved(); }} />;
}

function DeptForm({ init, items, onClose, onSaved }: { init: any; items: TNode[]; onClose: () => void; onSaved: () => void }) {
  const admin = isAdmin(useStore((s) => s.me));
  const isNew = !init.id;
  const [f, setF] = useState({ name: init.name || '', description: init.description || '', image: init.image || '', parent_id: (init.parent_id ?? null) as number | null, head_id: (init.head_id ?? null) as number | null, sort: init.sort ?? 0 });
  const [head, setHead] = useState<{ id: number; name: string }[]>(init.head_id ? [{ id: init.head_id, name: init.head || '#' + init.head_id }] : []);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const set = (k: string, v: any) => setF((x) => ({ ...x, [k]: v }));
  const { byId } = useMemo(() => buildTree(items), [items]);
  async function save() {
    setBusy(true); setErr('');
    try {
      if (isNew) await api.post('/api/departments', f); else await api.put('/api/departments/' + init.id, f);
      onSaved();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal size="lg" title={isNew ? (f.parent_id ? `Новое подразделение в «${byId.get(f.parent_id)?.name}»` : 'Новое корневое подразделение') : 'Подразделение: ' + init.name} onClose={onClose}
      footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={!f.name.trim() || (!admin && f.parent_id == null && (isNew || init.parent_id != null))} onClick={save}>Сохранить</Btn></>}>
      <div className="formGrid">
        <Field label="Название"><Input value={f.name} onChange={(e) => set('name', e.target.value)} maxLength={200} /></Field>
        <Field label="Родительское подразделение" hint={admin ? 'Пусто — корневое подразделение' : 'Доступны только узлы вашей области'}>
          <NodeSelect items={items} value={f.parent_id} onChange={(v) => set('parent_id', v)} allowEmpty={admin} emptyLabel="— корневое подразделение —"
            disabled={(n) => (!!init.id && inSubtree(byId, init.id, n.id)) || !n.can_manage} />
        </Field>
        <Field label="Руководитель"><UserPicker single value={head} onChange={(v) => { setHead(v); set('head_id', v[0]?.id ?? null); }} /></Field>
        <Field label="Индекс сортировки" hint="Подразделения выводятся по индексу, при равенстве — по алфавиту"><Input type="number" value={f.sort} onChange={(e) => set('sort', +e.target.value || 0)} /></Field>
        <div className="full"><ImageUpload label="Изображение" value={f.image} onChange={(v) => set('image', v)} /></div>
        <Field label="Описание (Markdown)" className="full"><MdEditor value={f.description} onChange={(v) => set('description', v)} rows={8} images /></Field>
      </div>
      {err && <div className="err" style={{ marginTop: 12 }}>{err}</div>}
    </Modal>
  );
}

// ---------------------------------------------------------------- direction editor
function DirModal({ item, items, onClose, onSaved }: { item: any; items: TNode[]; onClose: () => void; onSaved: () => void }) {
  const admin = isAdmin(useStore((s) => s.me));
  const isNew = !item.id;
  const [f, setF] = useState({ name: item.name || '', description: item.description || '', cover: item.cover || '', parent_id: (item.parent_id ?? null) as number | null, department_id: (item.department_id ?? null) as number | null, sort: item.sort ?? 0 });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const set = (k: string, v: any) => setF((x) => ({ ...x, [k]: v }));
  const { byId } = useMemo(() => buildTree(items), [items]);
  const needDept = !admin && f.parent_id == null && f.department_id == null;
  async function save() {
    setBusy(true); setErr('');
    try {
      if (isNew) await api.post('/api/directions', f); else await api.put('/api/directions/' + item.id, f);
      onSaved();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal size="lg" title={isNew ? 'Новое направление деятельности' : 'Направление: ' + item.name} onClose={onClose}
      footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={!f.name.trim() || needDept} onClick={save}>Сохранить</Btn></>}>
      <div className="formGrid">
        <Field label="Название"><Input value={f.name} onChange={(e) => set('name', e.target.value)} maxLength={200} /></Field>
        <Field label="Родительское направление" hint="Пусто — направление верхнего уровня">
          <NodeSelect items={items} value={f.parent_id} onChange={(v) => set('parent_id', v)} emptyLabel="— верхний уровень —"
            disabled={(n) => (!!item.id && inSubtree(byId, item.id, n.id)) || (!admin && !n.can_manage)} />
        </Field>
        <Field label="Подразделение (для прав доступа)" hint={needDept ? 'Для направления верхнего уровня укажите подразделение из вашей области' : 'Сотрудники подразделения (и вышестоящие редакторы) управляют направлением и всеми вложенными. Пусто — права наследуются от родителя'}>
          <DeptSelect value={f.department_id} onChange={(v) => set('department_id', v)} emptyLabel="— не привязано (наследуется) —" onlyManageable={!admin} />
        </Field>
        <Field label="Индекс сортировки" hint="По возрастанию, при равенстве — по алфавиту"><Input type="number" value={f.sort} onChange={(e) => set('sort', +e.target.value || 0)} /></Field>
        <div className="full"><ImageUpload label="Обложка" value={f.cover} onChange={(v) => set('cover', v)} /></div>
        <Field label="Описание" className="full"><Textarea rows={3} value={f.description} onChange={(e) => set('description', e.target.value)} /></Field>
      </div>
      {err && <div className="err" style={{ marginTop: 12 }}>{err}</div>}
    </Modal>
  );
}
