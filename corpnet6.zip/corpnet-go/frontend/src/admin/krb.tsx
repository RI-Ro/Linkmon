import React, { useEffect, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { toast } from '../lib/store';
import { fmtDate } from '../lib/util';
import { Badge, Btn, Field, Input, Select } from '../ui';
import { QueryView } from './common';

const MAPS: Record<string, string> = {
  sam: 'sam — ivanov@CORP.LOCAL → логин «ivanov» (sAMAccountName)',
  upn: 'upn — логин или email «ivanov@corp.local»',
  auto: 'auto — сначала upn, затем sam',
};

type Check = { name: string; level: 'ok' | 'warn' | 'fail'; detail: string };

/** Админка → Kerberos: статус, переопределения env, «Проверить конфигурацию». */
export function KerberosAdmin() {
  const q = useQuery<any>('admin:kerberos', () => api.get('/api/admin/kerberos'), { stale: 0 });
  return <QueryView q={q}>{(st) => <Body st={st} />}</QueryView>;
}

// 'env' = не переопределять (брать значение из переменной окружения)
const tri = (v: boolean | null | undefined) => (v == null ? 'env' : v ? 'on' : 'off');

function Body({ st }: { st: any }) {
  const [enabled, setEnabled] = useState('env');
  const [userMap, setUserMap] = useState('env');
  const [autoCreate, setAutoCreate] = useState('env');
  const [skew, setSkew] = useState('');
  const [busy, setBusy] = useState(false);
  const [checking, setChecking] = useState(false);
  const [res, setRes] = useState<{ level: string; checks: Check[]; report: any } | null>(null);
  const [err, setErr] = useState('');
  useEffect(() => {
    const s = st.sources || {};
    setEnabled(s.enabled === 'admin' ? tri(st.enabled) : 'env');
    setUserMap(s.user_map === 'admin' ? st.user_map : 'env');
    setAutoCreate(s.auto_create === 'admin' ? tri(st.auto_create) : 'env');
    setSkew(s.clock_skew_sec === 'admin' ? String(st.clock_skew_sec) : '');
  }, [st]);

  async function save() {
    setBusy(true); setErr('');
    try {
      const body = {
        enabled: enabled === 'env' ? null : enabled === 'on',
        user_map: userMap === 'env' ? null : userMap,
        auto_create: autoCreate === 'env' ? null : autoCreate === 'on',
        clock_skew_sec: skew.trim() === '' ? null : Math.round(+skew),
      };
      await api.put('/api/admin/kerberos', body);
      invalidate('admin:kerberos');
      toast({ title: 'Настройки Kerberos сохранены' });
    } catch (e) { setErr(errMsg(e)); }
    setBusy(false);
  }
  async function check() {
    setChecking(true); setRes(null);
    try { setRes(await api.post('/api/admin/kerberos/check')); invalidate('admin:kerberos'); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setChecking(false);
  }
  const ov = (k: string) => st.sources?.[k] === 'admin';
  const envHint = (k: 'enabled' | 'auto_create', v: boolean) => `из окружения: ${v ? 'включено' : 'выключено'}`;
  const ready = st.enabled && st.keytab_found && st.principal;
  return (
    <div className="stack">
      <div className="adminScope"><I.Info size={16} /><div>Вход через Kerberos (SPNEGO): доменный сотрудник попадает в портал без ввода пароля. Если Kerberos выключен, у браузера нет билета или пользователь не найден, показывается обычная форма пароля (локальный/LDAP). Путь к keytab и принципал задаются переменными окружения <code>KRB5_KEYTAB</code>, <code>KRB5_SERVICE_PRINCIPAL</code> (файл монтируется в контейнер), остальные параметры можно переопределить ниже.</div></div>

      <div className="card ldapCard">
        <div className="row" style={{ flexWrap: 'wrap' }}>
          <div className="tico"><I.Key size={17} /></div>
          <div className="sp" style={{ minWidth: 0 }}><div className="bold">Состояние</div><div className="tiny muted">{st.principal || 'сервисный принципал не задан'}</div></div>
          {st.enabled ? <Badge kind={ready ? 'ok' : 'warn'}>{ready ? 'включён' : 'включён, но не настроен'}</Badge> : <Badge>выключен</Badge>}
        </div>
        <dl className="kv">
          <div><dt>Keytab</dt><dd>{st.keytab || 'не задан'} {st.keytab && (st.keytab_found ? <Badge kind="ok">найден</Badge> : <Badge kind="dng">не найден</Badge>)}</dd></div>
          <div><dt>Сервисный принципал</dt><dd>{st.principal || '—'}</dd></div>
          <div><dt>Разрешённые realm клиентов</dt><dd>{st.realms?.length ? st.realms.join(', ') : 'из keytab'}</dd></div>
          <div><dt>krb5.conf</dt><dd>{st.conf || 'не задан (необязателен)'}</dd></div>
          <div><dt>Успешных входов</dt><dd>{st.ok_count}</dd></div>
          <div><dt>Последний успешный вход</dt><dd>{st.last_ok_at ? <>{fmtDate(st.last_ok_at)}<div className="tiny muted">{st.last_ok_user}{st.last_ok_ip ? ' · ' + st.last_ok_ip : ''}</div></> : 'ещё не было'}</dd></div>
          <div><dt>Последний отказ</dt><dd>{st.last_error_at ? <>{fmtDate(st.last_error_at)}<div className="tiny muted" style={{ overflowWrap: 'anywhere' }}>{st.last_error}</div></> : 'нет'}</dd></div>
        </dl>
        <div className="row" style={{ flexWrap: 'wrap' }}>
          <Btn kind="pri" busy={checking} onClick={check}><I.Zap size={16} /> Проверить конфигурацию</Btn>
        </div>
        {res && (
          <div className={'testBox ' + (res.level === 'fail' ? 'bad' : 'ok')}>
            <div className="bold">{res.level === 'fail' ? 'Найдены ошибки' : res.level === 'warn' ? 'Работает, есть замечания' : 'Конфигурация в порядке'}</div>
            {res.checks.map((c, i) => (
              <div key={i} className="small" style={{ display: 'flex', gap: 8, alignItems: 'baseline' }}>
                <Badge kind={c.level === 'ok' ? 'ok' : c.level === 'warn' ? 'warn' : 'dng'}>{c.level === 'ok' ? 'ок' : c.level === 'warn' ? 'внимание' : 'ошибка'}</Badge>
                <span style={{ overflowWrap: 'anywhere' }}><b>{c.name}.</b> {c.detail}</span>
              </div>
            ))}
            {res.report?.keytab_entries?.length > 0 && (
              <div className="tiny muted" style={{ marginTop: 6 }}>
                Ключи в keytab: {res.report.keytab_entries.map((e: any) => `${e.principal} (kvno ${e.kvno}, ${e.etype_name})`).join('; ')}
              </div>
            )}
            <div className="tiny muted">Проверка не обращается к KDC: проверяются файл keytab, SPN, realm и имя сайта. Реальный билет проверяется при входе доменного пользователя.</div>
          </div>
        )}
      </div>

      <div className="card" style={{ padding: 16 }}>
        <div className="formGrid">
          <div className="fsec">Параметры <span className="hint muted small">«из окружения» — значение переменной KRB5_*; здесь его можно переопределить без перезапуска</span></div>
          <Field label="Вход через Kerberos" hint={envHint('enabled', st.env.enabled)}>
            <Select value={enabled} onChange={(e) => setEnabled(e.target.value)}><option value="env">из окружения</option><option value="on">включён</option><option value="off">выключен</option></Select>
          </Field>
          <Field label="Логин из principal" hint={`из окружения: ${st.env.user_map}`}>
            <Select value={userMap} onChange={(e) => setUserMap(e.target.value)}><option value="env">из окружения</option>{Object.entries(MAPS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select>
          </Field>
          <Field label="Создавать пользователя при первом входе" hint={(st.ldap_autocreate_servers ? `LDAP-серверов с автосозданием: ${st.ldap_autocreate_servers}. ` : 'Нет LDAP-серверов с автосозданием — войдут только существующие. ') + envHint('auto_create', st.env.auto_create)}>
            <Select value={autoCreate} onChange={(e) => setAutoCreate(e.target.value)}><option value="env">из окружения</option><option value="on">да, из LDAP</option><option value="off">нет, только существующие</option></Select>
          </Field>
          <Field label="Допустимое смещение часов, сек" hint={`30–3600; из окружения: ${st.env.clock_skew_sec}`}>
            <Input type="number" min={30} max={3600} placeholder="из окружения" value={skew} onChange={(e) => setSkew(e.target.value)} />
          </Field>
        </div>
        {err && <div className="err" style={{ marginTop: 12 }}>{err}</div>}
        <div className="row" style={{ marginTop: 14 }}><span className="sp" /><Btn kind="pri" busy={busy} onClick={save}>Сохранить</Btn></div>
      </div>
    </div>
  );
}
