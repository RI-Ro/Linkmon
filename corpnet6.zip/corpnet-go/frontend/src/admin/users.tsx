import React, { useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { useStore, toast, isAdmin } from '../lib/store';
import { useDebounced } from '../lib/util';
import { Avatar, Badge, Btn, Check, Empty, ErrorBox, Field, ImageUpload, Input, Loading, Modal, Pager, Select, Textarea, useConfirm } from '../ui';
import { DeptSelect } from '../ui/DeptSelect';
import { usePersist } from '../lib/persist';
import { DeptMulti, ROLES } from './common';

export function UsersAdmin() {
  const me = useStore((s) => s.me)!;
  const admin = isAdmin(me);
  const [q, setQ] = useState('');
  const dq = useDebounced(q, 300);
  const [dept, setDept] = usePersist<number | null>('admin.users.dept', null);
  const [role, setRole] = usePersist<string>('admin.users.role', '');
  const [heads, setHeads] = usePersist<boolean>('admin.users.heads', false);
  const [state, setState_] = usePersist<string>('admin.users.state', '');
  const [page, setPage] = useState(1);
  const [edit, setEdit] = useState<any | null>(null);
  const url = `/api/manage/users?per=20&page=${page}&q=${encodeURIComponent(dq)}${dept ? '&department=' + dept : ''}${role ? '&role=' + role : ''}${heads ? '&heads=1' : ''}${state ? '&state=' + state : ''}`;
  const { data, error, refetch } = useQuery<any>('admin:users:' + url, () => api.get(url), { stale: 5000, keepPrevious: true });
  const [confirm, node] = useConfirm();
  const reset = <T,>(set: (v: T) => void) => (v: T) => { set(v); setPage(1); };
  return (
    <div className="card">
      <div className="tbar">
        <div className="grow"><Input placeholder="Поиск: ФИО, логин, email, должность" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} /></div>
        <div className="w230"><DeptSelect value={dept} onChange={reset(setDept)} emptyLabel={admin ? 'Все подразделения' : 'Вся моя область'} onlyManageable={!admin} /></div>
        <div className="w160"><Select value={role} onChange={(e) => reset(setRole)(e.target.value)}><option value="">Все роли</option>{Object.entries(ROLES).filter(([k]) => admin || k !== 'admin').map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></div>
        <div className="w160"><Select value={state} onChange={(e) => reset(setState_)(e.target.value)}><option value="">Любой статус</option><option value="active">Активные</option><option value="blocked">Заблокированные</option></Select></div>
        <Check checked={heads} onChange={reset(setHeads)} label="Руководители" />
        <Btn kind="pri" onClick={() => setEdit({})}><I.UserPlus size={17} /> Добавить</Btn>
      </div>
      {error && !data ? <ErrorBox error={error} retry={refetch} /> : !data ? <Loading /> : (
        <>
          <div className="padS muted small">Найдено: {data.total}{dept ? ' (включая вложенные подразделения)' : ''}. Сортировка по фамилии.</div>
          {!data.items.length ? <Empty icon={I.Users} title="Никого не найдено" /> : (
            <div className="tblW"><table className="tbl"><thead><tr><th>Сотрудник</th><th>Подразделение</th><th>Роль и пометки</th><th>Статус</th><th /></tr></thead><tbody>
              {data.items.map((u: any) => (
                <tr key={u.id}>
                  <td><div className="row"><Avatar name={u.name} src={u.avatar} size={36} userId={u.id} /><div style={{ minWidth: 0 }}><div className="bold">{u.name}</div><div className="tiny muted">{u.login}{u.email ? ' · ' + u.email : ''}</div></div></div></td>
                  <td className="small">{u.department || '—'}{u.is_head && <> <Badge kind="lime">руководитель</Badge></>}<div className="tiny muted">{u.job_title}</div></td>
                  <td><div className="row" style={{ flexWrap: 'wrap', gap: 4 }}>
                    <Badge kind={u.role === 'admin' ? 'accent' : u.role === 'editor' ? 'ok' : undefined}>{ROLES[u.role]}</Badge>
                    {u.can_vacations && <Badge kind="warn">отпуска</Badge>}
                    {u.company_news && <Badge kind="accent">новости компании</Badge>}
                    {u.learning_manager && <Badge kind="lime">обучение</Badge>}
                  </div></td>
                  <td><div className="row" style={{ flexWrap: 'wrap', gap: 4 }}>{u.blocked ? <Badge kind="dng">заблокирован</Badge> : <Badge kind="ok">активен</Badge>}{u.ldap && <Badge>LDAP</Badge>}</div></td>
                  <td className="act">
                    {admin && <Btn kind="ghost" size="sm" icon title="Завершить все сессии" onClick={async () => { try { await api.post(`/api/admin/users/${u.id}/logout`); toast({ title: 'Сессии завершены', kind: 'success' }, 2000); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }}><I.Logout size={16} /></Btn>}
                    {u.manageable ? <Btn kind="ghost" size="sm" icon title="Изменить" onClick={() => setEdit(u)}><I.Edit size={16} /></Btn>
                      : <span className="faint" title={u.id === me.id ? 'Свою учётную запись редактируйте в профиле' : 'Вне вашей области управления'}><I.Lock size={15} /></span>}
                    {u.manageable && u.id !== me.id && <Btn kind="ghost" size="sm" icon title="Удалить" onClick={async () => { if (await confirm('Удалить сотрудника?', { text: u.name + '. Учётная запись будет закрыта и скрыта из списков; авторство его новостей и комментариев сохранится. Действие записывается в журнал.' + (u.ldap ? ' Пользователь из LDAP остаётся заблокированным при синхронизации.' : ''), ok: 'Удалить' })) { try { await api.del('/api/users/' + u.id); toast({ title: 'Пользователь удалён', kind: 'success' }, 2000); invalidate('admin:users'); invalidate('users'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } } }}><I.Trash size={16} /></Btn>}
                  </td>
                </tr>
              ))}
            </tbody></table></div>
          )}
          <div className="padS"><Pager page={page} total={data.total} per={data.per} onChange={setPage} /></div>
        </>
      )}
      {edit && <UserModal u={edit} onClose={() => setEdit(null)} />}
      {node}
    </div>
  );
}

const LOGIN_RE = /^[a-z0-9][a-z0-9._@-]{1,63}$/;

function UserModal({ u, onClose }: { u: any; onClose: () => void }) {
  const isNew = !u.id;
  const me = useStore((s) => s.me)!;
  const isMe = u.id === me.id;
  const admin = isAdmin(me);
  // для LDAP-пользователя нужны атрибуты сервера: поле заблокировано, если сопоставлено с атрибутом каталога
  const ldapQ = useQuery<any[]>(u.ldap_server_id ? 'admin:ldap' : null, () => api.get('/api/admin/ldap'), { stale: 30000 });
  const srv = u.ldap_server_id ? (ldapQ.data || []).find((s) => s.id === u.ldap_server_id) : null;
  const lock: Record<string, boolean> = u.ldap ? {
    login: true, last_name: true, first_name: true,
    middle_name: !!srv?.attr_middle_name, email: !!srv?.attr_email, job_title: !!srv?.attr_title,
    phone1: !!srv?.attr_phone1, phone2: !!srv?.attr_phone2, phone3: !!srv?.attr_phone3, phone4: !!srv?.attr_phone4, birthday: !!srv?.attr_birthday,
  } : {};
  const [f, setF] = useState({
    login: u.login || '', password: '', last_name: u.last_name || '', first_name: u.first_name || '', middle_name: u.middle_name || '',
    job_title: u.job_title || '', extra_info: u.extra_info || '', email: u.email || '', phone1: u.phone1 || '', phone2: u.phone2 || '', phone3: u.phone3 || '', phone4: u.phone4 || '',
    birthday: u.birthday || '', avatar: u.avatar || '', department_id: (u.department_id ?? null) as number | null, is_head: !!u.is_head, role: u.role || 'user',
    can_vacations: !!u.can_vacations, company_news: !!u.company_news, learning_manager: !!u.learning_manager, learning_departments: (u.learning_departments || []) as number[], editor_departments: (u.editor_departments || []) as number[], blocked: !!u.blocked,
  });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const set = (k: string, v: any) => setF((x) => ({ ...x, [k]: v }));
  const L = (k: string) => !!lock[k];
  const lk = (k: string) => (L(k) ? <span className="lockNote"><I.Lock size={12} /> задаётся в LDAP</span> : null);
  const txt = (k: string & keyof typeof f, label: string, extra: any = {}) => <Field label={label} hint={L(k) ? 'Управляется LDAP — только чтение' : extra.hint}><Input {...extra} hint={undefined} value={f[k] as string} disabled={L(k)} onChange={(e) => set(k, e.target.value)} /></Field>;
  const pwBad = !u.ldap && (isNew ? f.password.length < 8 : f.password !== '' && f.password.length < 8);
  const invalid = !LOGIN_RE.test(f.login.trim().toLowerCase()) || !f.first_name.trim() || !f.last_name.trim() || pwBad;
  const [pwBusy, setPwBusy] = useState(false);
  const [newPw, setNewPw] = useState('');
  async function resetPw() {
    if (!window.confirm('Сгенерировать новый пароль? Все сессии пользователя будут завершены.')) return;
    setPwBusy(true); setErr('');
    try { const r: any = await api.post(`/api/users/${u.id}/password`, {}); setNewPw(r.password || ''); } catch (e) { setErr(errMsg(e)); }
    setPwBusy(false);
  }
  async function save() {
    setBusy(true); setErr('');
    try {
      const body: any = { ...f, login: f.login.trim().toLowerCase(), editor_departments: f.role === 'editor' ? f.editor_departments : [] };
      if (!body.password) delete body.password;
      if (isNew) await api.post('/api/users', body); else await api.put('/api/users/' + u.id, body);
      invalidate('admin:users'); invalidate('users'); invalidate('user:'); invalidate('departments'); onClose();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal size="lg" title={isNew ? 'Новый сотрудник' : <>{u.name} {u.ldap && <Badge>LDAP</Badge>}</>} onClose={onClose}
      footer={<>{!isNew && !u.ldap && !isMe && <Btn onClick={resetPw} busy={pwBusy} style={{ marginRight: 'auto' }}><I.Key size={15} /> Сбросить пароль</Btn>}<Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} onClick={save} disabled={invalid}>Сохранить</Btn></>}>
      {u.ldap && <div className="adminScope" style={{ marginBottom: 14 }}><I.Info size={16} /><div>Сотрудник загружен из LDAP{srv ? ` («${srv.name}»)` : ''}. Источник правды — каталог: поля, сопоставленные с атрибутами, перезаписываются при входе и синхронизации и здесь недоступны для правки. Пароль задаётся в каталоге.</div></div>}
      <div className="formGrid">
        <div className="fsec">Учётная запись</div>
        <Field label="Логин" hint={L('login') ? 'Управляется LDAP — только чтение' : 'Латиница, цифры и . _ - @, 2–64 символа'}><Input value={f.login} disabled={L('login')} autoComplete="off" onChange={(e) => set('login', e.target.value)} /></Field>
        {!u.ldap ? <Field label={isNew ? 'Пароль' : 'Новый пароль'} hint={isNew ? 'Не короче 8 символов' : 'Оставьте пустым, чтобы не менять (сессии сотрудника будут завершены при смене)'}><Input type="password" autoComplete="new-password" value={f.password} onChange={(e) => set('password', e.target.value)} /></Field> : <div />}
        <div className="full"><div className="field"><label>Аватар</label>{lk('avatar')}<ImageUpload avatar label="" value={f.avatar} onChange={(v) => set('avatar', v)} /></div></div>

        <div className="fsec">Личные данные</div>
        {txt('last_name', 'Фамилия')}
        {txt('first_name', 'Имя')}
        {txt('middle_name', 'Отчество')}
        {txt('birthday', 'Дата рождения', { type: 'date' })}
        {txt('email', 'Email', { type: 'email', placeholder: 'необязательно' })}
        {txt('phone1', 'Телефон 1')}
        {txt('phone2', 'Телефон 2')}
        {txt('phone3', 'Телефон 3')}
        {txt('phone4', 'Видеотелефон')}

        <div className="fsec">Работа</div>
        {txt('job_title', 'Должность')}
        <Field label="Подразделение" hint={srv?.attr_department ? 'Подразделение сопоставляется из LDAP при синхронизации' : undefined}><DeptSelect value={f.department_id} onChange={(v) => set('department_id', v)} emptyLabel="— не указано —" allowEmpty={admin} onlyManageable={!admin} /></Field>
        <div className="full"><Check checked={f.is_head} onChange={(v) => set('is_head', v)} label="Руководитель подразделения" /></div>
        <Field label="Дополнительная информация" className="full" hint="До 4000 символов, показывается в карточке сотрудника"><Textarea rows={3} maxLength={4000} value={f.extra_info} onChange={(e) => set('extra_info', e.target.value)} /></Field>

        <div className="fsec">Права и доступ</div>
        <Field label="Роль" hint={isMe ? 'Вы не можете снять с себя права администратора' : f.role === 'editor' ? 'Редактор управляет своим подразделением и вложенными, а также подразделениями ниже' : undefined}>
          <Select value={f.role} disabled={isMe} onChange={(e) => set('role', e.target.value)}>{Object.entries(ROLES).filter(([k]) => admin || k !== 'admin').map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select>
        </Field>
        <div className="field" style={{ alignSelf: 'end' }}><div className="checks" style={{ flexDirection: 'column', gap: 10 }}>
          {admin && <Check checked={f.can_vacations} onChange={(v) => set('can_vacations', v)} label="Может вести график отпусков" />}
          {admin && <Check checked={f.company_news} onChange={(v) => set('company_news', v)} label="Может публиковать новости на всю компанию" />}
          {admin && <Check checked={f.learning_manager} onChange={(v) => set('learning_manager', v)} label="Ответственный за обучение" />}
          <Check checked={f.blocked} onChange={(v) => set('blocked', v)} label={isMe ? 'Заблокирован (нельзя для себя)' : 'Заблокирован (вход запрещён)'} />
        </div></div>
        {admin && f.learning_manager && (
          <Field label="Область обучения" className="full" hint="Видит статистику, назначает обучение и отзывает сертификаты в своём подразделении и всех дочерних. Дополнительные подразделения (необязательно) расширяют область.">
            <DeptMulti value={f.learning_departments} onChange={(v) => set('learning_departments', v)} />
          </Field>
        )}
        {f.role === 'editor' && (
          <Field label="Подразделения редактирования" className="full" hint="Дополнительно к своему подразделению: редактор управляет выбранными подразделениями вместе со всеми вложенными">
            <DeptMulti value={f.editor_departments} onChange={(v) => set('editor_departments', v)} onlyManageable={!admin} />
          </Field>
        )}
      </div>
      {newPw && <div className="adminScope" style={{ marginTop: 12 }}><I.Key size={16} /><div>Новый пароль (показывается один раз, передайте сотруднику): <code style={{ userSelect: 'all', fontSize: 16 }}>{newPw}</code></div></div>}
      {err && <div className="err" style={{ marginTop: 12 }}>{err}</div>}
    </Modal>
  );
}
