import React, { useEffect, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery } from '../lib/query';
import { toast } from '../lib/store';
import { fmtDate, fmtSize, plural } from '../lib/util';
import { Badge, Btn, useConfirm } from '../ui';
import { QueryView } from './common';

interface Idx {
  counts: Record<'pending' | 'done' | 'failed' | 'unsupported', number>;
  not_queued: number; done_last_hour: number; last_extracted_at: string | null; text_bytes: number; pdftotext: boolean;
  failures: { id: number; name: string; mime: string; file_size: number; error: string; attempts: number; extracted_at: string | null; context: string }[];
  unsupported_reasons: { reason: string; n: number }[];
  reindex: { state?: string; scope?: string; queued?: string; started?: string; finished?: string };
}

const CTX: Record<string, string> = { folder: 'Документы', news: 'Новость', comment: 'Комментарий', chat: 'Чат', learning: 'Обучение' };

/** Раздел «Индекс файлов»: состояние извлечения текста для поиска по содержимому, переиндексация, ошибки. */
export function FileIndexAdmin() {
  const key = 'admin:fileindex';
  const q = useQuery<Idx>(key, () => api.get('/api/admin/file-index'), { stale: 0 });
  const [confirm, node] = useConfirm();
  const [busy, setBusy] = useState(false);
  const d = q.data;
  const running = d?.reindex?.state === 'running';
  const pending = d ? d.counts.pending + d.not_queued : 0;
  // пока идёт переиндексация или есть очередь — обновляем прогресс каждые 3 секунды
  useEffect(() => {
    if (!running && !pending) return;
    const t = setInterval(() => q.refetch(), 3000);
    return () => clearInterval(t);
  }, [running, pending > 0]);

  async function reindex(scope: 'all' | 'failed' | 'unsupported') {
    const label = { all: 'Переиндексировать все файлы?', failed: 'Повторить обработку файлов с ошибками?', unsupported: 'Повторить обработку неподдерживаемых файлов?' }[scope];
    if (!(await confirm(label, { text: 'Файлы вернутся в очередь и будут обработаны в фоне. Найденный ранее текст остаётся доступным для поиска, пока файл не обработан заново.', ok: 'Запустить', danger: false }))) return;
    setBusy(true);
    try { await api.post('/api/admin/file-index/reindex', { scope }); toast({ title: 'Переиндексация запущена', kind: 'success' }, 2500); q.refetch(); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }

  return (
    <QueryView q={q}>
      {(d) => {
        const c = d.counts, total = c.pending + c.done + c.failed + c.unsupported;
        const processed = c.done + c.failed + c.unsupported;
        const pct = total ? Math.round((processed / total) * 100) : 100;
        return (
          <div className="stack">
            <div className="card pad stack">
              <div className="row" style={{ gap: 10, flexWrap: 'wrap' }}>
                <h3 style={{ margin: 0 }}>Индекс файлов</h3>
                <span className="muted small">Поиск по содержимому: txt, md, csv, json, html, xml, rtf, docx, xlsx, pptx, odt/ods/odp, pdf</span>
                <div className="sp" />
                <Btn onClick={() => q.refetch()} size="sm"><I.Refresh size={15} /> Обновить</Btn>
                <Btn kind="pri" size="sm" busy={busy || running} onClick={() => reindex('all')}><I.Refresh size={15} /> Переиндексировать всё</Btn>
              </div>
              {!d.pdftotext && <div className="err"><I.Alert size={15} /> Утилита <b>pdftotext</b> (poppler-utils) не найдена на сервере: PDF помечаются как «не поддерживается». Установите её и нажмите «Повторить» у неподдерживаемых.</div>}
              <div className="idxStats">
                {([['pending', 'В очереди', c.pending + d.not_queued], ['done', 'Проиндексировано', c.done], ['failed', 'Ошибки', c.failed], ['unsupported', 'Не поддерживается', c.unsupported]] as const).map(([k, label, n]) => (
                  <div key={k} className={'idxStat ' + k}><div className="n">{n.toLocaleString('ru-RU')}</div><div className="small muted">{label}</div></div>
                ))}
              </div>
              <div className="prog"><i style={{ width: pct + '%' }} /></div>
              <div className="small muted">
                Обработано {processed.toLocaleString('ru-RU')} из {total.toLocaleString('ru-RU')} ({pct}%)
                {d.not_queued > 0 && <> · ещё не поставлено в очередь: {d.not_queued.toLocaleString('ru-RU')} (воркер добавит автоматически)</>}
                {' · '}за последний час: {d.done_last_hour.toLocaleString('ru-RU')}
                {d.last_extracted_at && <> · последний: {fmtDate(d.last_extracted_at)}</>}
                {' · '}текст: {fmtSize(d.text_bytes)}
              </div>
              {d.reindex?.state && (
                <div className="small">
                  Переиндексация ({d.reindex.scope}): {d.reindex.state === 'running' ? <Badge><I.Refresh size={11} /> идёт, поставлено в очередь {d.reindex.queued || 0}</Badge> : d.reindex.state === 'done' ? <Badge>завершена: поставлено {d.reindex.queued || 0}</Badge> : <Badge>ошибка</Badge>}
                </div>
              )}
            </div>

            {d.unsupported_reasons.length > 0 && (
              <div className="card pad stack">
                <div className="row"><h3 style={{ margin: 0 }}>Не поддерживается</h3><div className="sp" /><Btn size="sm" onClick={() => reindex('unsupported')}>Повторить</Btn></div>
                {d.unsupported_reasons.map((r) => <div key={r.reason} className="row small"><span className="sp clip">{r.reason}</span><b>{r.n.toLocaleString('ru-RU')}</b></div>)}
              </div>
            )}

            <div className="card pad stack">
              <div className="row" style={{ gap: 10 }}>
                <h3 style={{ margin: 0 }}>Ошибки извлечения</h3>
                <span className="muted small">{c.failed ? plural(c.failed, ['файл', 'файла', 'файлов']) + (c.failed > d.failures.length ? `, показаны последние ${d.failures.length}` : '') : 'нет'}</span>
                <div className="sp" />
                {c.failed > 0 && <Btn size="sm" busy={busy} onClick={() => reindex('failed')}><I.Refresh size={15} /> Повторить все</Btn>}
              </div>
              {d.failures.map((f) => (
                <div key={f.id} className="idxFail">
                  <div className="row" style={{ gap: 8 }}>
                    <a className="bold clip sp" href={`/files/${f.id}`} target="_blank" rel="noopener noreferrer">{f.name}</a>
                    <Badge>{CTX[f.context] || f.context}</Badge>
                    <span className="tiny muted">{fmtSize(f.file_size)} · попыток: {f.attempts}</span>
                  </div>
                  <div className="small" style={{ color: 'var(--danger)' }}>{f.error || 'Неизвестная ошибка'}</div>
                </div>
              ))}
            </div>
            {node}
          </div>
        );
      }}
    </QueryView>
  );
}
