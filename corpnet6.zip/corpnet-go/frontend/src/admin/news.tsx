import { usePersist } from '../lib/persist';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { Link } from '../lib/router';
import { useStore, isAdmin, toast } from '../lib/store';
import { cx, fmtDate, useDebounced } from '../lib/util';
import { Badge, Btn, Empty, ErrorBox, Input, Loading, useConfirm } from '../ui';
import { DeptSelect } from '../ui/DeptSelect';

const STATES: { id: string; label: string }[] = [
  { id: '', label: 'Все' },
  { id: 'live', label: 'Опубликованы' },
  { id: 'draft', label: 'Черновики' },
  { id: 'scheduled', label: 'Запланированы' },
  { id: 'hidden', label: 'Скрыты' },
  { id: 'expired', label: 'Срок показа истёк' },
];
const STATE_BADGE: Record<string, { label: string; kind?: 'accent' | 'ok' | 'warn' | 'dng' }> = {
  live: { label: 'опубликована', kind: 'ok' },
  draft: { label: 'черновик' },
  scheduled: { label: 'запланирована', kind: 'accent' },
  hidden: { label: 'скрыта', kind: 'dng' },
  expired: { label: 'срок истёк', kind: 'warn' },
};

/** Состояние новости так же, как его считает сервер (для локального обновления после «скрыть/показать»). */
function calcState(n: any): string {
  const now = Date.now();
  if (n.status === 'draft') return 'draft';
  if (n.hidden) return 'hidden';
  if (new Date(n.published_at).getTime() > now) return 'scheduled';
  if (n.visible_until && new Date(n.visible_until).getTime() <= now) return 'expired';
  return 'live';
}

/** Keyset-пагинация: курсор — id последней записи, has_more — есть ли ещё. */
function useCursorList(base: string) {
  const [items, setItems] = useState<any[]>([]);
  const [more, setMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<any>(null);
  const seq = useRef(0);
  const load = useCallback(async (cursor: number | null) => {
    const my = ++seq.current;
    setLoading(true); setError(null);
    try {
      const r = await api.get<{ items: any[]; has_more: boolean }>(base + (cursor ? `&cursor=${cursor}` : ''));
      if (my !== seq.current) return;
      setItems((o) => (cursor ? [...o, ...r.items] : r.items));
      setMore(!!r.has_more && r.items.length > 0);
    } catch (e) { if (my === seq.current) setError(e); }
    if (my === seq.current) setLoading(false);
  }, [base]);
  useEffect(() => { setItems([]); load(null); }, [load]);
  return { items, setItems, more, loading, error, reload: () => load(null), loadMore: () => items.length && load(items[items.length - 1].id) };
}

export function NewsAdmin() {
  const me = useStore((s) => s.me)!;
  const admin = isAdmin(me);
  const [q, setQ] = useState('');
  const dq = useDebounced(q.trim(), 300);
  const [state, setState] = usePersist<string>('admin.news.state', '');
  const [dept, setDept] = usePersist<number | null>('admin.news.dept', null);
  const base = `/api/admin/news?per=30${state ? '&state=' + state : ''}${dept ? '&department=' + dept : ''}${dq.length >= 2 ? '&q=' + encodeURIComponent(dq) : ''}`;
  const list = useCursorList(base);
  const dirs = useQuery<any[]>('directions', () => api.get('/api/directions'), { stale: 120000 });
  const dirName = useMemo(() => new Map((dirs.data || []).map((d) => [d.id, d.name])), [dirs.data]);
  const [confirm, node] = useConfirm();
  const [busyId, setBusyId] = useState<number | null>(null);

  async function toggleHidden(n: any) {
    setBusyId(n.id);
    try {
      await api.post(`/api/news/${n.id}/hidden`, { hidden: !n.hidden });
      list.setItems((l) => l.map((x) => { if (x.id !== n.id) return x; const y = { ...x, hidden: !n.hidden }; y.state = calcState(y); return y; }));
      invalidate('news');
      toast({ title: n.hidden ? 'Публикация снова показывается' : 'Публикация скрыта', kind: 'success' }, 2000);
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusyId(null);
  }
  async function remove(n: any) {
    if (!(await confirm('Удалить публикацию?', { text: n.title + '. Вместе с ней будут удалены комментарии и отметки «нравится».', ok: 'Удалить' }))) return;
    try { await api.del('/api/news/' + n.id); list.setItems((l) => l.filter((x) => x.id !== n.id)); invalidate('news'); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }

  return (
    <div className="card">
      {!admin && <div className="padS" style={{ paddingBottom: 0 }}><div className="adminScope"><I.Info size={16} /><div>Показаны ваши публикации и публикации подразделений вашей области управления (ваше подразделение, дочерние и добавленные администратором).</div></div></div>}
      <div className="tbar">
        <div className="grow"><Input placeholder="Поиск по заголовку (от 2 символов)" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <div className="w230"><DeptSelect value={dept} onChange={setDept} emptyLabel="Все подразделения" /></div>
        <Link to="/news/new" className="btn pri"><I.Plus size={17} /> Новая публикация</Link>
      </div>
      <div className="chips">{STATES.map((s) => <button key={s.id} type="button" className={cx('chip', state === s.id && 'on')} onClick={() => setState(s.id)}>{s.label}</button>)}</div>
      {list.error && !list.items.length ? <div className="padS"><ErrorBox error={list.error} retry={list.reload} /></div> : !list.items.length && list.loading ? <Loading /> : !list.items.length ? (
        <Empty icon={I.Newspaper} title="Публикаций не найдено">Измените фильтры или создайте новую публикацию.</Empty>
      ) : (
        <>
          <div className="tblW"><table className="tbl"><thead><tr><th>Заголовок</th><th>Состояние</th><th>Видимость</th><th>Автор</th><th>Подразделение / направление</th><th /></tr></thead><tbody>
            {list.items.map((n) => {
              const st = STATE_BADGE[n.state] || STATE_BADGE.live;
              return (
                <tr key={n.id} style={n.state !== 'live' ? { opacity: n.state === 'hidden' || n.state === 'expired' ? 0.75 : 1 } : undefined}>
                  <td style={{ maxWidth: 360, minWidth: 220 }}>
                    <Link to={`/news/${n.id}`} className="bold clamp2">{n.title}</Link>
                    <div className="row" style={{ flexWrap: 'wrap', gap: 4, marginTop: 4 }}>
                      {n.important && <Badge kind="warn">важное</Badge>}{n.pinned && <Badge>закреплено</Badge>}
                      {n.category && <span className="tiny muted">{n.category}</span>}
                      <span className="tiny faint"><I.Eye size={12} /> {n.views_count}</span>
                    </div>
                  </td>
                  <td><Badge kind={st.kind}>{st.label}</Badge></td>
                  <td className="small" style={{ whiteSpace: 'nowrap' }}>
                    <div>с {fmtDate(n.published_at)}</div>
                    <div className={n.state === 'expired' ? '' : 'muted'}>{n.visible_until ? 'до ' + fmtDate(n.visible_until) : 'бессрочно'}</div>
                  </td>
                  <td className="small">{n.author}</td>
                  <td className="small">{n.department || <span className="muted">Вся компания</span>}{n.direction_id && <div className="tiny muted">{dirName.get(n.direction_id) || 'Направление #' + n.direction_id}</div>}</td>
                  <td className="act">
                    <Link to={`/news/${n.id}/edit`} className="btn ghost sm icon" title="Редактировать"><I.Edit size={16} /></Link>
                    <Btn kind="ghost" size="sm" icon title={n.hidden ? 'Показывать' : 'Скрыть с публикации'} disabled={busyId === n.id || n.status === 'draft'} onClick={() => toggleHidden(n)}>{n.hidden ? <I.Eye size={16} /> : <I.EyeOff size={16} />}</Btn>
                    <Btn kind="ghost" size="sm" icon title="Удалить" onClick={() => remove(n)}><I.Trash size={16} /></Btn>
                  </td>
                </tr>
              );
            })}
          </tbody></table></div>
          <div className="padS row" style={{ justifyContent: 'center' }}>
            {list.more ? <Btn busy={list.loading} onClick={list.loadMore}>Показать ещё</Btn> : <span className="tiny muted">Показано: {list.items.length}</span>}
          </div>
        </>
      )}
      {node}
    </div>
  );
}
