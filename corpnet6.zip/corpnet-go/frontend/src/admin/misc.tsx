import React, { useEffect, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { Link } from '../lib/router';
import { setState, toast } from '../lib/store';
import { fmtDate, fmtSize, plural } from '../lib/util';
import { Badge, Btn, Empty, ErrorBox, Field, ImageUpload, Input, Loading, Modal, Select, Textarea, useConfirm } from '../ui';
import { QueryView, useMore } from './common';
import { useStore } from '../lib/store';

// ---------------------------------------------------------------- dashboard
export function Dashboard() {
  const { data, error, refetch } = useQuery<any>('admin:stats', () => api.get('/api/admin/stats'), { stale: 0 });
  useEffect(() => { const t = setInterval(refetch, 10000); return () => clearInterval(t); }, []);
  if (error && !data) return <ErrorBox error={error} retry={refetch} />;
  if (!data) return <Loading />;
  const t = data.totals;
  const kpis = [
    { n: data.online, l: 'Сейчас онлайн', i: I.Wifi }, { n: `${t.active_users}/${t.users}`, l: 'Активных сотрудников', i: I.Users },
    { n: t.news, l: `Публикаций${t.drafts ? ` (+${t.drafts} черн.)` : ''}`, i: I.Newspaper }, { n: t.views, l: 'Просмотров', i: I.Eye },
    { n: t.comments, l: 'Комментариев', i: I.Comment }, { n: t.messages_24h, l: 'Сообщений за 24 ч', i: I.Message },
    { n: t.chats, l: 'Чатов', i: I.Hash }, { n: t.files, l: `Файлов · ${fmtSize(t.files_size)}`, i: I.Folder },
    { n: t.groups, l: 'Групп', i: I.Users }, { n: t.departments, l: 'Подразделений', i: I.Building },
  ];
  const series = data.series as any[];
  const max = Math.max(1, ...series.map((d) => d.news + d.comments + d.messages));
  const maxDept = Math.max(1, ...data.by_department.map((d: any) => d.employees));
  return (
    <div className="stack">
      <div className="kpis">{kpis.map((k, i) => <div key={i} className="card kpi"><div className="ic"><k.i size={19} /></div><div className="n">{k.n}</div><div className="l">{k.l}</div></div>)}</div>
      <div className="card pad stack">
        <div className="row"><h3 className="sp">Экземпляры приложения</h3><Badge kind="ok">этот ответ: {data.served_by}</Badge></div>
        <p className="small muted">Состояние хранится в Redis, поэтому любой запрос и любой WebSocket может обслуживать любой экземпляр.</p>
        <div className="tblW"><table className="tbl"><thead><tr><th>Экземпляр</th><th>Время работы</th><th>WebSocket</th><th /></tr></thead><tbody>
          {data.instances.map((x: any) => <tr key={x.id}><td className="bold">{x.id}</td><td>{x.since ? uptime(x.since) : '—'}</td><td>{x.ws ?? '—'}</td><td>{x.self && <Badge kind="accent">вы здесь</Badge>}</td></tr>)}
        </tbody></table></div>
      </div>
      <div className="card pad stack">
        <div className="row"><h3 className="sp">Активность за 14 дней</h3><span className="tiny muted"><span style={{ color: 'var(--accent)' }}>■</span> новости <span style={{ color: '#7c5cff' }}>■</span> комментарии <span style={{ color: 'var(--ok)' }}>■</span> сообщения</span></div>
        <div className="bars" style={{ paddingBottom: 22 }}>{series.map((d) => (
          <div key={d.day} className="b" title={`${d.day}: новости ${d.news}, комментарии ${d.comments}, сообщения ${d.messages}`}>
            <i style={{ height: (d.messages / max) * 100 + '%', background: 'var(--ok)' }} /><i style={{ height: (d.comments / max) * 100 + '%', background: '#7c5cff' }} /><i style={{ height: (d.news / max) * 100 + '%', background: 'var(--accent)' }} /><span>{d.day.slice(8)}</span>
          </div>
        ))}</div>
      </div>
      <div className="formGrid">
        <div className="card pad stack"><h3>Популярные публикации</h3>{data.top_news.map((n: any) => <Link key={n.id} to={`/news/${n.id}`} className="row"><span className="sp clip small">{n.title}</span><span className="stat tiny muted"><I.Eye size={13} />{n.views_count}</span><span className="stat tiny muted"><I.Heart size={13} />{n.likes_count}</span></Link>)}</div>
        <div className="card pad stack"><h3>Сотрудники по подразделениям</h3>{data.by_department.map((d: any) => <div key={d.name} className="hbar"><span className="clip">{d.name}</span><div className="t"><i style={{ width: (d.employees / maxDept) * 100 + '%' }} /></div><b>{d.employees}</b></div>)}</div>
      </div>
    </div>
  );
}
function uptime(since: number) {
  const s = Math.max(0, Math.floor(Date.now() / 1000 - since));
  const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
  return d ? `${d} д ${h} ч` : h ? `${h} ч ${m} мин` : `${m} мин ${s % 60} с`;
}

// ---------------------------------------------------------------- comments & audit
function MoreBtn({ l }: { l: { more: boolean; loading: boolean; loadMore: () => void; items: any[] } }) {
  return <div className="padS row" style={{ justifyContent: 'center' }}>{l.more ? <Btn busy={l.loading} onClick={l.loadMore}>Показать ещё</Btn> : <span className="tiny muted">Показано: {l.items.length}</span>}</div>;
}

export function CommentsAdmin() {
  const l = useMore<any>('/api/admin/comments', 50);
  const [confirm, node] = useConfirm();
  if (l.error && !l.items.length) return <ErrorBox error={l.error} retry={l.reload} />;
  if (!l.items.length) return l.loading ? <Loading /> : <div className="card"><Empty icon={I.Comment} title="Комментариев нет" /></div>;
  return (
    <div className="card">
      <div className="padS muted small">Модерация: удаление скрывает комментарий у всех. Показаны последние комментарии ко всем публикациям.</div>
      <div className="tblW"><table className="tbl"><thead><tr><th>Комментарий</th><th>Автор</th><th>Публикация</th><th>Дата</th><th /></tr></thead><tbody>
        {l.items.map((c) => (
          <tr key={c.id}>
            <td style={{ maxWidth: 380 }} className={c.deleted ? 'faint' : ''}>{c.deleted ? <i>удалён</i> : <span className="clamp2">{c.body}</span>}</td>
            <td className="small">{c.author}</td>
            <td>{c.entity_type === 'news' || c.entity_type === 'idea' ? <Link to={`/${c.entity_type === 'idea' ? 'ideas' : 'news'}/${c.entity_id}#comment-${c.id}`} className="small clamp2" style={{ color: 'var(--accent)' }}>{c.news_title || '#' + c.entity_id}</Link> : <span className="small muted">{c.entity_type} #{c.entity_id}</span>}</td>
            <td className="small">{fmtDate(c.created_at)}</td>
            <td className="act">{!c.deleted && <Btn kind="ghost" size="sm" icon title="Удалить" onClick={async () => { if (await confirm('Удалить комментарий?', { text: c.body?.slice(0, 120), ok: 'Удалить' })) { try { await api.del('/api/comments/' + c.id); l.setItems((o) => o.map((x) => (x.id === c.id ? { ...x, deleted: true } : x))); invalidate('news'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } } }}><I.Trash size={16} /></Btn>}</td>
          </tr>
        ))}
      </tbody></table></div>
      <MoreBtn l={l} />
      {node}
    </div>
  );
}

const AUDIT_GROUPS: [string, string][] = [['', 'Все действия'], ['user.', 'Пользователи'], ['news.', 'Новости'], ['department.', 'Подразделения'], ['direction.', 'Направления'],
  ['ldap.', 'LDAP'], ['banner.', 'Баннеры'], ['learning.', 'Обучение'], ['requests.', 'Заявки'], ['wiki.', 'Wiki']];
const AUDIT_ACTIONS: Record<string, string> = { 'user.create': 'создание пользователя', 'user.update': 'изменение пользователя', 'user.delete': 'удаление пользователя', 'user.block': 'блокировка',
  'user.unblock': 'разблокировка', 'user.role_change': 'смена роли', 'user.password_reset': 'сброс пароля', 'user.logout': 'завершение сессий' };
const AUDIT_FIELDS: Record<string, string> = { login: 'логин', email: 'email', first_name: 'имя', last_name: 'фамилия', middle_name: 'отчество', job_title: 'должность', extra_info: 'доп. информация',
  department_id: 'подразделение (id)', role: 'роль', phone1: 'телефон 1', phone2: 'телефон 2', phone3: 'телефон 3', phone4: 'видеотелефон', birthday: 'дата рождения', avatar: 'аватар',
  is_head: 'руководитель', can_vacations: 'график отпусков', company_news: 'новости компании', learning_manager: 'ответственный за обучение', blocked: 'заблокирован', deleted: 'удалён',
  editor_departments: 'подразделения редактирования', learning_departments: 'подразделения обучения' };
const showVal = (v: any) => (v == null || v === '' ? '—' : Array.isArray(v) ? (v.length ? v.join(', ') : '—') : typeof v === 'boolean' ? (v ? 'да' : 'нет') : String(v).length > 80 ? String(v).slice(0, 80) + '…' : String(v));

function AuditDetails({ a }: { a: any }) {
  const d = a.data && typeof a.data === 'object' ? a.data : {};
  const ch = d.changes && typeof d.changes === 'object' ? Object.entries(d.changes) : [];
  const snap = d.after || d.before;
  return (
    <div className="stackS small">
      {d.target && <div>Объект: <b>{d.target}</b></div>}
      {d.password_reset && <div>Пароль был сброшен (значение не сохраняется).</div>}
      {d.generated && <div>Пароль сгенерирован сервером (значение не сохраняется).</div>}
      {ch.length > 0 && <table className="tbl"><thead><tr><th>Поле</th><th>Было</th><th>Стало</th></tr></thead><tbody>
        {ch.map(([k, v]: any) => <tr key={k}><td>{AUDIT_FIELDS[k] || k}</td><td>{showVal(v.from)}</td><td>{showVal(v.to)}</td></tr>)}</tbody></table>}
      {snap && <details><summary>{d.after ? 'Состояние после' : 'Состояние до удаления'}</summary><div className="tiny muted" style={{ columns: 2 }}>{Object.entries(snap).map(([k, v]) => <div key={k}>{AUDIT_FIELDS[k] || k}: {showVal(v)}</div>)}</div></details>}
      {!d.target && !ch.length && !snap && <pre className="tiny" style={{ whiteSpace: 'pre-wrap', margin: 0 }}>{JSON.stringify(d, null, 1)}</pre>}
      <div className="tiny muted">Request ID: <code>{a.request_id || '—'}</code>{a.actor_role ? ` · роль исполнителя: ${a.actor_role}` : ''}</div>
    </div>
  );
}

export function AuditAdmin() {
  const [f, setF] = useState({ group: '', q: '', from: '', to: '', ip: '', role: '' });
  const [open, setOpen] = useState<number | null>(null);
  const set = (k: string, v: string) => setF((x) => ({ ...x, [k]: v }));
  const qs = new URLSearchParams();
  if (f.group) qs.set('action', f.group);
  if (f.q.trim()) qs.set('q', f.q.trim());
  if (f.from) qs.set('from', f.from);
  if (f.to) qs.set('to', f.to);
  if (f.ip.trim()) qs.set('ip', f.ip.trim());
  if (f.role) qs.set('role', f.role);
  const qstr = qs.toString();
  const l = useMore<any>('/api/admin/audit' + (qstr ? '?' + qstr : ''), 50);
  const bar = (
    <div className="tbar">
      <div className="w160"><Select value={f.group} onChange={(e) => set('group', e.target.value)}>{AUDIT_GROUPS.map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></div>
      <div className="grow"><Input placeholder="Поиск по данным (имя, логин, поле…)" value={f.q} onChange={(e) => set('q', e.target.value)} /></div>
      <div className="w160"><Input type="date" aria-label="С даты" value={f.from} onChange={(e) => set('from', e.target.value)} /></div>
      <div className="w160"><Input type="date" aria-label="По дату" value={f.to} onChange={(e) => set('to', e.target.value)} /></div>
      <div className="w160"><Select value={f.role} onChange={(e) => set('role', e.target.value)}><option value="">Любая роль</option><option value="admin">Администратор</option><option value="editor">Редактор</option></Select></div>
      <div className="w160"><Input placeholder="IP" value={f.ip} onChange={(e) => set('ip', e.target.value)} /></div>
      <a className="btn" href={'/api/admin/audit/export' + (qstr ? '?' + qstr : '')} download><I.Download size={16} /> CSV</a>
    </div>
  );
  if (l.error && !l.items.length) return <ErrorBox error={l.error} retry={l.reload} />;
  return (
    <div className="card">
      {bar}
      {!l.items.length ? (l.loading ? <Loading /> : <Empty icon={I.ScrollText} title="Записей нет">Попробуйте изменить фильтры.</Empty>) : (
        <div className="tblW"><table className="tbl"><thead><tr><th>Время</th><th>Исполнитель</th><th>Действие</th><th>Объект</th><th>IP</th><th /></tr></thead><tbody>
          {l.items.map((a) => {
            const d = a.data && typeof a.data === 'object' ? (a.data.title || a.data.name || a.data.target || '') : '';
            const obj = a.target_name || d;
            return (
              <React.Fragment key={a.id}>
                <tr onClick={() => setOpen(open === a.id ? null : a.id)} style={{ cursor: 'pointer' }}>
                  <td className="small" style={{ whiteSpace: 'nowrap' }}>{fmtDate(a.created_at)}</td>
                  <td className="small">{a.user_name || '—'}{a.actor_role === 'editor' && <> <Badge kind="ok">редактор</Badge></>}</td>
                  <td><code>{a.action}</code>{AUDIT_ACTIONS[a.action] && <div className="tiny muted">{AUDIT_ACTIONS[a.action]}</div>}</td>
                  <td className="small">{a.entity}{a.entity_id ? ' #' + a.entity_id : ''}{obj ? ` · ${obj}` : ''}</td>
                  <td className="tiny muted">{a.ip}</td>
                  <td className="tiny muted">{open === a.id ? '▲' : '▼'}</td>
                </tr>
                {open === a.id && <tr><td colSpan={6} style={{ background: 'var(--surface2)' }}><AuditDetails a={a} /></td></tr>}
              </React.Fragment>
            );
          })}
        </tbody></table></div>
      )}
      <MoreBtn l={l} />
    </div>
  );
}

// ---------------------------------------------------------------- company
export function CompanyAdmin() {
  const c = useStore((s) => s.company);
  const [f, setF] = useState<any>(c || {});
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const set = (k: string, v: any) => setF((x: any) => ({ ...x, [k]: v }));
  return (
    <div className="card pad stack" style={{ maxWidth: 780 }}>
      <div className="formGrid">
        <Field label="Название"><Input value={f.name || ''} onChange={(e) => set('name', e.target.value)} /></Field>
        <Field label="Слоган"><Input value={f.tagline || ''} onChange={(e) => set('tagline', e.target.value)} /></Field>
        <Field label="Телефон"><Input value={f.phone || ''} onChange={(e) => set('phone', e.target.value)} /></Field>
        <Field label="Email"><Input value={f.email || ''} onChange={(e) => set('email', e.target.value)} /></Field>
        <Field label="Адрес"><Input value={f.address || ''} onChange={(e) => set('address', e.target.value)} /></Field>
        <Field label="Год основания"><Input type="number" value={f.founded || ''} onChange={(e) => set('founded', +e.target.value || 0)} /></Field>
        <Field label="О компании" className="full"><Textarea rows={4} value={f.about || ''} onChange={(e) => set('about', e.target.value)} /></Field>
        <div className="full"><ImageUpload label="Логотип (в шапке)" value={f.logo || ''} onChange={(v) => set('logo', v)} /></div>
      </div>
      {err && <div className="err">{err}</div>}
      <div><Btn kind="pri" busy={busy} disabled={!(f.name || '').trim()} onClick={async () => { setBusy(true); setErr(''); try { const r = await api.put('/api/company', f); setState({ company: r || { ...f } }); toast({ title: 'Сохранено', kind: 'success' }, 2000); } catch (e) { setErr(errMsg(e)); } setBusy(false); }}>Сохранить</Btn></div>
    </div>
  );
}

// ---------------------------------------------------------------- categories & resources
const ICON_CHOICES = ['link', 'book', 'mail', 'globe', 'briefcase', 'calendar', 'file', 'server', 'chart', 'database', 'key', 'star'];

export function CategoriesAdmin() {
  const q = useQuery<any[]>('admin:categories', () => api.get('/api/categories'), { stale: 0 });
  const [edit, setEdit] = useState<any | null>(null);
  const [confirm, node] = useConfirm();
  const reload = async () => { const l = await api.get('/api/categories'); setState({ categories: l }); invalidate('admin:categories'); invalidate('news'); };
  return (
    <QueryView q={q}>{(list) => (
      <div className="card">
        <div className="tbar"><div className="grow muted small">{plural(list.length, ['категория', 'категории', 'категорий'])}</div><Btn kind="pri" onClick={() => setEdit({ name: '', color: '#286b9e', sort: 0 })}><I.Plus size={17} /> Добавить категорию</Btn></div>
        {!list.length ? <Empty icon={I.Tag} title="Категорий нет" /> : (
          <div className="tblW"><table className="tbl"><thead><tr><th>Название</th><th>Цвет</th><th>Новостей</th><th>Порядок</th><th /></tr></thead><tbody>
            {list.map((r) => (
              <tr key={r.id}><td className="bold">{r.name}</td><td><span className="badge" style={{ background: r.color + '26', color: r.color }}>{r.color}</span></td><td>{r.news_count}</td><td>{r.sort}</td>
                <td className="act"><Btn kind="ghost" size="sm" icon title="Изменить" onClick={() => setEdit({ ...r })}><I.Edit size={16} /></Btn>
                  <Btn kind="ghost" size="sm" icon title="Удалить" onClick={async () => { if (await confirm('Удалить категорию?', { text: r.name + (r.news_count ? `. У ${r.news_count} публикаций категория будет сброшена.` : ''), ok: 'Удалить' })) { try { await api.del('/api/categories/' + r.id); reload(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } } }}><I.Trash size={16} /></Btn></td></tr>
            ))}
          </tbody></table></div>
        )}
        {edit && (
          <SimpleModal title={edit.id ? 'Категория: ' + edit.name : 'Новая категория'} item={edit} url="/api/categories" onClose={() => setEdit(null)} onSaved={() => { setEdit(null); reload(); }}>
            {(f, set) => <>
              <Field label="Название"><Input value={f.name} onChange={(e) => set('name', e.target.value)} /></Field>
              <Field label="Цвет"><input type="color" className="inp" style={{ padding: 4, height: 42 }} value={f.color} onChange={(e) => set('color', e.target.value)} /></Field>
              <Field label="Порядок"><Input type="number" value={f.sort} onChange={(e) => set('sort', +e.target.value || 0)} /></Field>
            </>}
          </SimpleModal>
        )}
        {node}
      </div>
    )}</QueryView>
  );
}

export function ResourcesAdmin() {
  const q = useQuery<any[]>('admin:resources', () => api.get('/api/resources'), { stale: 0 });
  const [edit, setEdit] = useState<any | null>(null);
  const [confirm, node] = useConfirm();
  const reload = () => { invalidate('admin:resources'); invalidate('resources'); };
  return (
    <QueryView q={q}>{(list) => (
      <div className="card">
        <div className="tbar"><div className="grow muted small">{plural(list.length, ['ресурс', 'ресурса', 'ресурсов'])}</div><Btn kind="pri" onClick={() => setEdit({ name: '', description: '', url: 'https://', icon: 'link', sort: 0 })}><I.Plus size={17} /> Добавить ресурс</Btn></div>
        {!list.length ? <Empty icon={I.Link} title="Ресурсов нет" /> : (
          <div className="tblW"><table className="tbl"><thead><tr><th>Название</th><th>Ссылка</th><th>Порядок</th><th /></tr></thead><tbody>
            {list.map((r) => (
              <tr key={r.id}><td><div className="bold">{r.name}</div><div className="tiny muted">{r.description}</div></td><td><a href={r.url} target="_blank" rel="noopener noreferrer" className="small" style={{ color: 'var(--accent)' }}>{r.url}</a></td><td>{r.sort}</td>
                <td className="act"><Btn kind="ghost" size="sm" icon title="Изменить" onClick={() => setEdit({ ...r })}><I.Edit size={16} /></Btn>
                  <Btn kind="ghost" size="sm" icon title="Удалить" onClick={async () => { if (await confirm('Удалить ресурс?', { text: r.name, ok: 'Удалить' })) { try { await api.del('/api/resources/' + r.id); reload(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } } }}><I.Trash size={16} /></Btn></td></tr>
            ))}
          </tbody></table></div>
        )}
        {edit && (
          <SimpleModal title={edit.id ? 'Ресурс: ' + edit.name : 'Новый ресурс'} item={edit} url="/api/resources" valid={(f) => /^https?:\/\/./.test(f.url)} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); reload(); }}>
            {(f, set) => <>
              <Field label="Название"><Input value={f.name} onChange={(e) => set('name', e.target.value)} /></Field>
              <Field label="Описание"><Input value={f.description} onChange={(e) => set('description', e.target.value)} /></Field>
              <Field label="Ссылка" hint="http:// или https://"><Input value={f.url} onChange={(e) => set('url', e.target.value)} /></Field>
              <div className="formGrid">
                <Field label="Иконка"><Select value={f.icon} onChange={(e) => set('icon', e.target.value)}>{ICON_CHOICES.map((i) => <option key={i}>{i}</option>)}</Select></Field>
                <Field label="Порядок"><Input type="number" value={f.sort} onChange={(e) => set('sort', +e.target.value || 0)} /></Field>
              </div>
            </>}
          </SimpleModal>
        )}
        {node}
      </div>
    )}</QueryView>
  );
}

function SimpleModal({ title, item, url, valid, children, onClose, onSaved }: { title: string; item: any; url: string; valid?: (f: any) => boolean; children: (f: any, set: (k: string, v: any) => void) => React.ReactNode; onClose: () => void; onSaved: () => void }) {
  const [f, setF] = useState(item);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const set = (k: string, v: any) => setF((x: any) => ({ ...x, [k]: v }));
  async function save() {
    setBusy(true); setErr('');
    try { if (f.id) await api.put(`${url}/${f.id}`, f); else await api.post(url, f); onSaved(); } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title={title} onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={!f.name?.trim() || (valid ? !valid(f) : false)} onClick={save}>Сохранить</Btn></>}>
      <div className="stack">{children(f, set)}</div>
      {err && <div className="err" style={{ marginTop: 12 }}>{err}</div>}
    </Modal>
  );
}
