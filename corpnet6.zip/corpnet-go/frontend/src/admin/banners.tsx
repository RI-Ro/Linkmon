import React, { useMemo, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { toast } from '../lib/store';
import { fmtDate, thumb } from '../lib/util';
import { Badge, Btn, Check, Empty, Field, ImageUpload, Input, Modal, Select, Textarea, useConfirm } from '../ui';
import { useDepartments } from '../ui/DeptSelect';
import { QueryView, fromRFC, toRFC } from './common';

type LinkKind = 'none' | 'news' | 'group' | 'department' | 'direction' | 'custom';
const KINDS: { id: LinkKind; label: string }[] = [
  { id: 'none', label: 'Без ссылки' }, { id: 'news', label: 'Новость' }, { id: 'group', label: 'Группа' },
  { id: 'department', label: 'Подразделение' }, { id: 'direction', label: 'Направление деятельности' }, { id: 'custom', label: 'Свой адрес' },
];
function parseLink(l: string): { kind: LinkKind; id: number | null } {
  if (!l) return { kind: 'none', id: null };
  let m = l.match(/^\/news\/(\d+)$/); if (m) return { kind: 'news', id: +m[1] };
  m = l.match(/^\/groups\/(\d+)$/); if (m) return { kind: 'group', id: +m[1] };
  m = l.match(/^\/departments\/(\d+)$/); if (m) return { kind: 'department', id: +m[1] };
  m = l.match(/^\/\?direction=(\d+)$/); if (m) return { kind: 'direction', id: +m[1] };
  return { kind: 'custom', id: null };
}
const buildLink = (k: LinkKind, id: number) => (k === 'news' ? `/news/${id}` : k === 'group' ? `/groups/${id}` : k === 'department' ? `/departments/${id}` : `/?direction=${id}`);

/** Выбор «важного события», на которое ведёт баннер: новость, группа, подразделение, направление или произвольный адрес. */
function LinkPicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const init = useMemo(() => parseLink(value), []); // eslint-disable-line
  const [kind, setKind] = useState<LinkKind>(init.kind);
  const news = useQuery<any>(kind === 'news' ? 'admin:banner:news' : null, () => api.get('/api/news?per=50'), { stale: 30000 });
  const groups = useQuery<any[]>(kind === 'group' ? 'admin:banner:groups' : null, () => api.get('/api/groups'), { stale: 30000 });
  const dirs = useQuery<any[]>(kind === 'direction' ? 'directions' : null, () => api.get('/api/directions'), { stale: 120000 });
  const depts = useDepartments();
  const cur = parseLink(value);
  let opts: { id: number; name: string }[] = [];
  if (kind === 'news') opts = (news.data?.items || []).map((n: any) => ({ id: n.id, name: n.title }));
  if (kind === 'group') opts = (groups.data || []).map((g: any) => ({ id: g.id, name: g.name }));
  if (kind === 'direction') opts = (dirs.data || []).map((g: any) => ({ id: g.id, name: g.name }));
  if (kind === 'department') opts = (depts.data || []).map((g) => ({ id: g.id, name: g.name }));
  const selId = cur.kind === kind ? cur.id : null;
  // если выбранный объект не попал в загруженный список — показываем его как «#id»
  if (selId && !opts.some((o) => o.id === selId)) opts = [{ id: selId, name: '#' + selId }, ...opts];
  return (
    <div className="stackS">
      <Select value={kind} onChange={(e) => { const k = e.target.value as LinkKind; setKind(k); if (k === 'none') onChange(''); else if (k === 'custom') onChange(cur.kind === 'custom' ? value : ''); else onChange(''); }}>
        {KINDS.map((k) => <option key={k.id} value={k.id}>{k.label}</option>)}
      </Select>
      {kind === 'custom' && <Input placeholder="/news/5, /groups/3 или https://…" value={value} onChange={(e) => onChange(e.target.value)} />}
      {kind !== 'none' && kind !== 'custom' && (
        <Select value={selId ?? ''} onChange={(e) => onChange(e.target.value ? buildLink(kind, +e.target.value) : '')}>
          <option value="">— выберите —</option>
          {opts.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
        </Select>
      )}
    </div>
  );
}

function bannerState(b: any): { label: string; kind?: 'ok' | 'warn' | 'accent' } {
  const now = Date.now();
  if (!b.active) return { label: 'выключен' };
  if (b.starts_at && new Date(b.starts_at).getTime() > now) return { label: 'ещё не начался', kind: 'accent' };
  if (b.ends_at && new Date(b.ends_at).getTime() <= now) return { label: 'период истёк', kind: 'warn' };
  return { label: 'показывается', kind: 'ok' };
}

export function BannersAdmin() {
  const q = useQuery<any[]>('admin:banners', () => api.get('/api/admin/banners'), { stale: 0 });
  const [edit, setEdit] = useState<any | null>(null);
  const [confirm, node] = useConfirm();
  const done = () => { invalidate('admin:banners'); invalidate('banners'); };
  async function toggle(b: any) {
    try { const { id, created_at, ...body } = b; await api.put('/api/admin/banners/' + id, { ...body, active: !b.active }); done(); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  return (
    <QueryView q={q}>{(list) => (
      <div className="card">
        <div className="tbar">
          <div className="grow muted small">Баннеры показываются над важными новостями на главной странице (не более 10 одновременно, в порядке индекса).</div>
          <Btn kind="pri" onClick={() => setEdit({})}><I.Plus size={17} /> Добавить баннер</Btn>
        </div>
        {!list.length ? <Empty icon={I.Image} title="Баннеров пока нет">Добавьте баннер с фото или видео и ссылкой на важное событие.</Empty> : (
          <div className="tblW"><table className="tbl"><thead><tr><th>Баннер</th><th>Ссылка</th><th>Период показа</th><th>Порядок</th><th>Статус</th><th /></tr></thead><tbody>
            {list.map((b) => {
              const st = bannerState(b);
              return (
                <tr key={b.id}>
                  <td><div className="row"><div className="bnThumb" style={b.image ? { backgroundImage: `url("${thumb(b.image)}")` } : undefined}>{!b.image && (b.video_url ? <I.Video size={18} /> : <I.Image size={18} />)}</div>
                    <div style={{ minWidth: 0 }}><div className="bold clamp2">{b.title}</div>{b.text && <div className="tiny muted clamp2">{b.text}</div>}</div></div></td>
                  <td className="small">{b.link ? <><code>{b.link}</code><div className="tiny muted">{b.link_label}</div></> : <span className="muted">—</span>}</td>
                  <td className="small" style={{ whiteSpace: 'nowrap' }}>{b.starts_at ? 'с ' + fmtDate(b.starts_at) : 'сразу'}<div className="muted">{b.ends_at ? 'до ' + fmtDate(b.ends_at) : 'бессрочно'}</div></td>
                  <td>{b.sort}</td>
                  <td><Badge kind={st.kind}>{st.label}</Badge></td>
                  <td className="act">
                    <Btn kind="ghost" size="sm" icon title={b.active ? 'Выключить' : 'Включить'} onClick={() => toggle(b)}>{b.active ? <I.EyeOff size={16} /> : <I.Eye size={16} />}</Btn>
                    <Btn kind="ghost" size="sm" icon title="Изменить" onClick={() => setEdit(b)}><I.Edit size={16} /></Btn>
                    <Btn kind="ghost" size="sm" icon title="Удалить" onClick={async () => { if (await confirm('Удалить баннер?', { text: b.title, ok: 'Удалить' })) { try { await api.del('/api/admin/banners/' + b.id); done(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } } }}><I.Trash size={16} /></Btn>
                  </td>
                </tr>
              );
            })}
          </tbody></table></div>
        )}
        {edit && <BannerModal b={edit} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); done(); }} />}
        {node}
      </div>
    )}</QueryView>
  );
}

function BannerModal({ b, onClose, onSaved }: { b: any; onClose: () => void; onSaved: () => void }) {
  const isNew = !b.id;
  const [f, setF] = useState({
    title: b.title || '', text: b.text || '', image: b.image || '', video_url: b.video_url || '', link: b.link || '', link_label: b.link_label || 'Подробнее',
    sort: b.sort ?? 0, active: b.id ? !!b.active : true, starts_at: fromRFC(b.starts_at), ends_at: fromRFC(b.ends_at),
  });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const set = (k: string, v: any) => setF((x) => ({ ...x, [k]: v }));
  const badPeriod = !!f.starts_at && !!f.ends_at && new Date(f.ends_at) <= new Date(f.starts_at);
  async function save() {
    setBusy(true); setErr('');
    try {
      const body = { ...f, title: f.title.trim(), starts_at: toRFC(f.starts_at), ends_at: toRFC(f.ends_at) };
      if (isNew) await api.post('/api/admin/banners', body); else await api.put('/api/admin/banners/' + b.id, body);
      onSaved();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal size="lg" title={isNew ? 'Новый баннер' : 'Баннер: ' + b.title} onClose={onClose}
      footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={!f.title.trim() || badPeriod} onClick={save}>Сохранить</Btn></>}>
      <div className="formGrid">
        <Field label="Заголовок" className="full"><Input value={f.title} maxLength={200} onChange={(e) => set('title', e.target.value)} /></Field>
        <Field label="Текст" className="full"><Textarea rows={3} value={f.text} onChange={(e) => set('text', e.target.value)} /></Field>
        <div className="full"><ImageUpload label="Фото" value={f.image} onChange={(v) => set('image', v)} /></div>
        <Field label="Видео (ссылка https://)" className="full" hint="Необязательно: ролик, который показывается в баннере"><Input value={f.video_url} placeholder="https://…" onChange={(e) => set('video_url', e.target.value)} /></Field>
        <Field label="Куда ведёт баннер" hint="Любое важное событие: новость, группа, подразделение, направление или свой адрес"><LinkPicker value={f.link} onChange={(v) => set('link', v)} /></Field>
        <Field label="Текст кнопки"><Input value={f.link_label} onChange={(e) => set('link_label', e.target.value)} /></Field>
        <Field label="Показывать с" hint="Пусто — сразу"><Input type="datetime-local" value={f.starts_at} onChange={(e) => set('starts_at', e.target.value)} /></Field>
        <Field label="Показывать до" hint={badPeriod ? 'Конец периода раньше начала' : 'Пусто — бессрочно'}><Input type="datetime-local" value={f.ends_at} onChange={(e) => set('ends_at', e.target.value)} /></Field>
        <Field label="Порядок" hint="По возрастанию"><Input type="number" value={f.sort} onChange={(e) => set('sort', +e.target.value || 0)} /></Field>
        <div className="field" style={{ alignSelf: 'end' }}><Check checked={f.active} onChange={(v) => set('active', v)} label="Баннер активен" /></div>
      </div>
      {err && <div className="err" style={{ marginTop: 12 }}>{err}</div>}
    </Modal>
  );
}
