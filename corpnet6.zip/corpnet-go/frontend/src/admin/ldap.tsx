import React, { useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { toast } from '../lib/store';
import { fmtDate } from '../lib/util';
import { Badge, Btn, Check, Empty, Field, Input, Modal, Select, useConfirm } from '../ui';
import { QueryView } from './common';

const EMPTY = {
  name: '', url: 'ldap://', start_tls: false, skip_verify: false, bind_dn: '', bind_password: '', base_dn: '', user_filter: '(uid=%s)', sync_filter: '(objectClass=person)',
  attr_login: 'uid', attr_uid: '', attr_first_name: 'givenName', attr_last_name: 'sn', attr_middle_name: '', attr_email: 'mail', attr_title: 'title',
  attr_phone1: 'telephoneNumber', attr_phone2: 'mobile', attr_phone3: '', attr_phone4: '', attr_birthday: '', attr_department: '', attr_disabled: '',
  default_role: 'user', auto_create: true, deactivate_missing: false, sync_minutes: 0, sort: 0, enabled: true,
};
type Form = typeof EMPTY;

export function LdapAdmin() {
  const q = useQuery<any[]>('admin:ldap', () => api.get('/api/admin/ldap'), { stale: 0 });
  const [edit, setEdit] = useState<any | null>(null);
  return (
    <QueryView q={q}>{(list) => (
      <div className="stack">
        <div className="adminScope"><I.Info size={16} /><div>LDAP — источник правды о сотрудниках. Профиль (ФИО, почта, телефоны, должность) перезаписывается из каталога при каждом входе и при синхронизации; поля, для которых указан атрибут, в портале не редактируются. Серверов может быть несколько: на странице входа сотрудник выбирает источник (локальный или каталог).</div></div>
        <div className="row"><div className="sp muted small">Серверов: {list.length}</div><Btn kind="pri" onClick={() => setEdit({})}><I.Plus size={17} /> Добавить сервер</Btn></div>
        {!list.length ? <div className="card"><Empty icon={I.Server} title="LDAP-серверы не настроены">Пока сотрудники входят только с локальным паролем.</Empty></div> : (
          <div className="ldapGrid">{list.map((s) => <ServerCard key={s.id} s={s} onEdit={() => setEdit(s)} />)}</div>
        )}
        {edit && <LdapModal s={edit} onClose={() => setEdit(null)} />}
      </div>
    )}</QueryView>
  );
}

function ServerCard({ s, onEdit }: { s: any; onEdit: () => void }) {
  const [confirm, node] = useConfirm();
  const [busy, setBusy] = useState<'' | 'test' | 'sync'>('');
  const [res, setRes] = useState<{ kind: 'test' | 'sync'; data: any } | null>(null);
  async function run(kind: 'test' | 'sync') {
    setBusy(kind); setRes(null);
    try {
      const data = await api.post(`/api/admin/ldap/${s.id}/${kind}`);
      setRes({ kind, data });
      if (kind === 'sync') { invalidate('admin:ldap'); invalidate('admin:users'); invalidate('users'); }
    } catch (e) { setRes({ kind, data: { ok: false, error: errMsg(e) } }); }
    setBusy('');
  }
  async function remove() {
    if (!(await confirm('Удалить LDAP-сервер?', { text: s.name, ok: 'Удалить' }))) return;
    try { await api.del('/api/admin/ldap/' + s.id); }
    catch (e: any) {
      if (e?.status !== 409) { toast({ title: errMsg(e), kind: 'error' }); return; }
      if (!(await confirm('Удалить вместе с привязкой пользователей?', { text: errMsg(e), ok: 'Всё равно удалить' }))) return;
      try { await api.del(`/api/admin/ldap/${s.id}?force=1`); } catch (e2) { toast({ title: errMsg(e2), kind: 'error' }); return; }
    }
    invalidate('admin:ldap'); invalidate('admin:users');
  }
  const status: string = s.last_sync_status || '';
  const failed = /ошибк|error|fail/i.test(status);
  return (
    <div className="card ldapCard">
      <div className="row" style={{ flexWrap: 'wrap' }}>
        <div className="tico"><I.Server size={17} /></div>
        <div className="sp" style={{ minWidth: 0 }}><div className="bold">{s.name}</div><div className="tiny muted">{s.url}</div></div>
        {s.enabled ? <Badge kind="ok">включён</Badge> : <Badge kind="dng">выключен</Badge>}
        <Badge>{s.users} польз.</Badge>
      </div>
      <dl className="kv">
        <div><dt>Base DN</dt><dd>{s.base_dn}</dd></div>
        <div><dt>Служебная учётка</dt><dd>{s.bind_dn || 'анонимно'}{s.bind_dn && <span className="tiny muted"> · пароль {s.password_set ? 'задан' : 'не задан'}</span>}</dd></div>
        <div><dt>Роль новых пользователей</dt><dd>{s.default_role === 'editor' ? 'Редактор' : 'Сотрудник'}{s.auto_create ? ', создаются при входе' : ', без автосоздания'}</dd></div>
        <div><dt>Автосинхронизация</dt><dd>{s.sync_minutes > 0 ? `каждые ${s.sync_minutes} мин` : 'выключена'}{s.deactivate_missing && ' · блокирует отсутствующих'}</dd></div>
        <div><dt>TLS</dt><dd>{s.start_tls ? 'StartTLS' : s.url.startsWith('ldaps') ? 'LDAPS' : 'нет'}{s.skip_verify && ' · без проверки сертификата'}</dd></div>
        <div><dt>Последняя синхронизация</dt><dd>{s.last_sync_at ? fmtDate(s.last_sync_at) : 'ещё не выполнялась'}{status && <div className={failed ? 'err' : 'tiny muted'}>{status}</div>}</dd></div>
      </dl>
      <div className="row" style={{ flexWrap: 'wrap' }}>
        <Btn busy={busy === 'test'} disabled={!!busy} onClick={() => run('test')}><I.Zap size={16} /> Проверить подключение</Btn>
        <Btn busy={busy === 'sync'} disabled={!!busy} onClick={() => run('sync')}><I.Refresh size={16} /> Синхронизировать сейчас</Btn>
        <span className="sp" />
        <Btn kind="ghost" size="sm" icon title="Изменить" onClick={onEdit}><I.Edit size={16} /></Btn>
        <Btn kind="ghost" size="sm" icon title="Удалить" onClick={remove}><I.Trash size={16} /></Btn>
      </div>
      {res?.kind === 'test' && (
        <div className={'testBox ' + (res.data.ok ? 'ok' : 'bad')}>
          <div className="bold">{res.data.ok ? 'Подключение успешно, фильтр синхронизации работает' : 'Не удалось подключиться'}</div>
          {res.data.error && <div className="small" style={{ overflowWrap: 'anywhere' }}>{res.data.error}</div>}
          {res.data.ok && (res.data.sample?.length ? <><div className="tiny muted">Пример записей каталога:</div>{res.data.sample.map((p: any, i: number) => <div key={i} className="small">{p.name || '—'} <span className="muted">· {p.login}{p.email ? ' · ' + p.email : ''}</span></div>)}</> : <div className="small muted">Записей по фильтру не найдено — проверьте Base DN и фильтр.</div>)}
        </div>
      )}
      {res?.kind === 'sync' && (
        <div className={'testBox ' + (res.data.ok && !res.data.errors ? 'ok' : 'bad')}>
          <div className="bold">{res.data.ok ? 'Синхронизация завершена' : 'Синхронизация завершилась с ошибкой'}</div>
          {res.data.message && <div className="small" style={{ overflowWrap: 'anywhere' }}>{res.data.message}</div>}
          {res.data.error && <div className="small">{res.data.error}</div>}
          {res.data.seen != null && <div className="small muted">Обработано записей: {res.data.seen}; заблокировано: {res.data.blocked ?? 0}; ошибок: {res.data.errors ?? 0}</div>}
        </div>
      )}
      {node}
    </div>
  );
}

function LdapModal({ s, onClose }: { s: any; onClose: () => void }) {
  const isNew = !s.id;
  const [f, setF] = useState<Form>(() => {
    const o: any = { ...EMPTY };
    if (!isNew) for (const k of Object.keys(EMPTY)) if (s[k] != null) o[k] = s[k];
    o.bind_password = '';
    return o;
  });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const set = (k: keyof Form, v: any) => setF((x) => ({ ...x, [k]: v }));
  const txt = (k: keyof Form, label: string, hint?: string, extra: any = {}) => <Field label={label} hint={hint}><Input value={f[k] as string} onChange={(e) => set(k, e.target.value)} {...extra} /></Field>;
  const bad = !f.name.trim() || !f.base_dn.trim() || !/^ldaps?:\/\/./.test(f.url.trim()) || !f.user_filter.includes('%s');
  async function save() {
    setBusy(true); setErr('');
    try {
      const body: any = { ...f, name: f.name.trim(), url: f.url.trim(), base_dn: f.base_dn.trim() };
      if (isNew) await api.post('/api/admin/ldap', body); else await api.put('/api/admin/ldap/' + s.id, body);
      invalidate('admin:ldap'); onClose();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal size="lg" title={isNew ? 'Новый LDAP-сервер' : 'LDAP: ' + s.name} onClose={onClose}
      footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={bad} onClick={save}>Сохранить</Btn></>}>
      <div className="formGrid">
        <div className="fsec">Подключение</div>
        {txt('name', 'Название', 'Показывается на странице входа')}
        {txt('url', 'Адрес', 'ldap://host:389 или ldaps://host:636', { placeholder: 'ldap://dc.example.com:389' })}
        <div className="full"><div className="checks">
          <Check checked={f.enabled} onChange={(v) => set('enabled', v)} label="Включён (доступен при входе)" />
          <Check checked={f.start_tls} onChange={(v) => set('start_tls', v)} label="StartTLS" />
          <Check checked={f.skip_verify} onChange={(v) => set('skip_verify', v)} label="Не проверять сертификат (небезопасно)" />
        </div></div>
        {txt('bind_dn', 'Служебная учётная запись (Bind DN)', 'Пусто — анонимное подключение', { autoComplete: 'off' })}
        <Field label="Пароль служебной учётки" hint={isNew ? undefined : `Сейчас пароль ${s.password_set ? 'задан' : 'не задан'}. Пусто — не менять`}><Input type="password" autoComplete="new-password" value={f.bind_password} onChange={(e) => set('bind_password', e.target.value)} /></Field>
        {txt('base_dn', 'Base DN', 'Например dc=example,dc=com')}
        {txt('user_filter', 'Фильтр пользователя при входе', 'Должен содержать %s на месте логина, например (uid=%s) или (sAMAccountName=%s)')}
        {txt('sync_filter', 'Фильтр для синхронизации', 'Какие записи каталога загружать, например (objectClass=person)')}

        <div className="fsec">Атрибуты каталога <span className="hint muted small">пустой атрибут — поле не сопоставляется и редактируется в портале</span></div>
        {txt('attr_login', 'Логин')}
        {txt('attr_uid', 'Уникальный идентификатор', 'Например entryUUID или objectGUID')}
        {txt('attr_last_name', 'Фамилия')}
        {txt('attr_first_name', 'Имя')}
        {txt('attr_middle_name', 'Отчество')}
        {txt('attr_email', 'Email')}
        {txt('attr_title', 'Должность')}
        {txt('attr_department', 'Подразделение', 'Сопоставляется с подразделением по названию')}
        {txt('attr_phone1', 'Телефон 1')}
        {txt('attr_phone2', 'Телефон 2')}
        {txt('attr_phone3', 'Телефон 3')}
        {txt('attr_phone4', 'Видеотелефон')}
        {txt('attr_birthday', 'Дата рождения')}
        {txt('attr_disabled', 'Признак блокировки', 'Например userAccountControl')}

        <div className="fsec">Синхронизация</div>
        <Field label="Роль новых пользователей"><Select value={f.default_role} onChange={(e) => set('default_role', e.target.value)}><option value="user">Сотрудник</option><option value="editor">Редактор</option></Select></Field>
        <Field label="Автосинхронизация, минут" hint="0 — только вручную"><Input type="number" min={0} value={f.sync_minutes} onChange={(e) => set('sync_minutes', Math.max(0, +e.target.value || 0))} /></Field>
        <div className="full"><div className="checks">
          <Check checked={f.auto_create} onChange={(v) => set('auto_create', v)} label="Создавать пользователей при первом входе" />
          <Check checked={f.deactivate_missing} onChange={(v) => set('deactivate_missing', v)} label="Блокировать сотрудников, пропавших из каталога" />
        </div></div>
        <Field label="Порядок в списке"><Input type="number" value={f.sort} onChange={(e) => set('sort', +e.target.value || 0)} /></Field>
      </div>
      {err && <div className="err" style={{ marginTop: 12 }}>{err}</div>}
    </Modal>
  );
}
