import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { cx } from '../lib/util';
import { Empty, ErrorBox, Loading, usePopover } from '../ui';
import { DeptSelect, flattenDepts, useDepartments } from '../ui/DeptSelect';

export const ROLES: Record<string, string> = { admin: 'Администратор', editor: 'Редактор', user: 'Сотрудник' };

/** Состояние запроса: 403 — понятное сообщение, прочие ошибки — с кнопкой «Повторить». */
export function QueryView<T>({ q, children }: { q: { data: T | undefined; error: any; refetch: () => any }; children: (d: T) => React.ReactNode }) {
  if (q.error && !q.data) {
    if (q.error.status === 403) return <div className="card"><Empty icon={I.Lock} title="Недостаточно прав">{errMsg(q.error)}</Empty></div>;
    return <div className="card"><ErrorBox error={q.error} retry={q.refetch} /></div>;
  }
  if (!q.data) return <Loading />;
  return <>{children(q.data)}</>;
}

/** Накопительная загрузка страниц (page/per): «Показать ещё». */
export function useMore<T = any>(base: string, per = 50) {
  const [items, setItems] = useState<T[]>([]);
  const [page, setPage] = useState(0);
  const [more, setMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<any>(null);
  const seq = useRef(0);
  const load = useCallback(async (p: number, reset: boolean) => {
    const my = ++seq.current;
    setLoading(true); setError(null);
    try {
      const r = await api.get<T[]>(`${base}${base.includes('?') ? '&' : '?'}per=${per}&page=${p}`);
      if (my !== seq.current) return;
      setItems((o) => (reset ? r : [...o, ...r]));
      setPage(p); setMore(r.length >= per);
    } catch (e) { if (my === seq.current) setError(e); }
    if (my === seq.current) setLoading(false);
  }, [base, per]);
  useEffect(() => { setItems([]); load(1, true); }, [load]);
  return { items, more, loading, error, loadMore: () => load(page + 1, false), reload: () => load(1, true), setItems };
}

/** Мульти-выбор подразделений: выбранные + иерархический DeptSelect для добавления. */
export function DeptMulti({ value, onChange, onlyManageable }: { value: number[]; onChange: (v: number[]) => void; onlyManageable?: boolean }) {
  const { data } = useDepartments();
  const byId = useMemo(() => new Map((data || []).map((d) => [d.id, d])), [data]);
  return (
    <div className="stackS">
      {value.length > 0 && (
        <div className="tokens">
          {value.map((id) => (
            <span className="token" key={id}>{byId.get(id)?.name || '#' + id}
              <button type="button" onClick={() => onChange(value.filter((x) => x !== id))} aria-label="Убрать"><I.X size={14} /></button>
            </span>
          ))}
        </div>
      )}
      <DeptSelect value={null} allowEmpty={false} onlyManageable={onlyManageable} onChange={(id) => { if (id != null && !value.includes(id)) onChange([...value, id]); }} />
    </div>
  );
}

export interface TNode { id: number; parent_id: number | null; name: string; sort?: number; can_manage?: boolean; [k: string]: any }

export const nodeCmp = (a: TNode, b: TNode) => (a.sort ?? 0) - (b.sort ?? 0) || a.name.toLowerCase().localeCompare(b.name.toLowerCase()) || a.id - b.id;

export function buildTree(items: TNode[]) {
  const byId = new Map<number, TNode>(items.map((n) => [n.id, n]));
  const kids = new Map<number | null, TNode[]>();
  for (const n of items) {
    const p = n.parent_id != null && byId.has(n.parent_id) ? n.parent_id : null;
    if (!kids.has(p)) kids.set(p, []);
    kids.get(p)!.push(n);
  }
  for (const l of kids.values()) l.sort(nodeCmp);
  return { byId, kids };
}

/** node лежит в поддереве root (включая сам root) */
export function inSubtree(byId: Map<number, TNode>, root: number, node: number | null): boolean {
  let cur = node, guard = 0;
  while (cur != null && guard++ < 1000) {
    if (cur === root) return true;
    cur = byId.get(cur)?.parent_id ?? null;
  }
  return false;
}

/** Иерархический выпадающий список для произвольного дерева (направления, подразделения при выборе родителя). */
export function NodeSelect({ items, value, onChange, allowEmpty = true, emptyLabel = '— верхний уровень —', disabled, placeholder = 'Выберите…' }: {
  items: TNode[]; value: number | null; onChange: (id: number | null) => void; allowEmpty?: boolean; emptyLabel?: string; disabled?: (n: TNode) => boolean; placeholder?: string;
}) {
  const { open, setOpen, ref } = usePopover();
  const [collapsed, setCollapsed] = useState<Set<number>>(new Set());
  const rows = useMemo(() => flattenDepts(items as any) as (TNode & { depth: number; hasKids: boolean })[], [items]);
  const byId = useMemo(() => new Map(items.map((d) => [d.id, d])), [items]);
  const hidden = useMemo(() => {
    const h = new Set<number>();
    for (const r of rows) if (r.parent_id != null && (collapsed.has(r.parent_id) || h.has(r.parent_id))) h.add(r.id);
    return h;
  }, [rows, collapsed]);
  const label = value != null ? byId.get(value)?.name || '…' : allowEmpty ? emptyLabel : placeholder;
  return (
    <div style={{ position: 'relative' }} ref={ref}>
      <button type="button" className="sel" style={{ textAlign: 'left', width: '100%' }} onClick={() => setOpen(!open)}>{label}</button>
      {open && (
        <div className="treeSel" style={{ position: 'absolute', zIndex: 30, left: 0, right: 0, top: 'calc(100% + 4px)', boxShadow: 'var(--shadow)' }}>
          {allowEmpty && <div className={cx('treeRow', value == null && 'on')} onClick={() => { onChange(null); setOpen(false); }}>{emptyLabel}</div>}
          {rows.filter((r) => !hidden.has(r.id)).map((r) => {
            const off = disabled?.(r);
            return (
              <div key={r.id} className={cx('treeRow', value === r.id && 'on')} style={{ paddingLeft: 8 + r.depth * 18, opacity: off ? 0.45 : 1, cursor: off ? 'default' : 'pointer' }}
                onClick={() => { if (off) return; onChange(r.id); setOpen(false); }}>
                {r.hasKids ? (
                  <span onClick={(e) => { e.stopPropagation(); setCollapsed((c) => { const n = new Set(c); n.has(r.id) ? n.delete(r.id) : n.add(r.id); return n; }); }} style={{ display: 'inline-flex' }}>
                    {collapsed.has(r.id) ? <I.ChevronRight size={15} /> : <I.ChevronDown size={15} />}
                  </span>
                ) : <span style={{ width: 15 }} />}
                {r.name}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/** Локальное время (datetime-local) ↔ RFC3339, которое ждёт сервер. */
export const toRFC = (local: string) => (local ? new Date(local).toISOString() : '');
export const fromRFC = (iso?: string | null) => {
  if (!iso) return '';
  const d = new Date(iso), p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
};
