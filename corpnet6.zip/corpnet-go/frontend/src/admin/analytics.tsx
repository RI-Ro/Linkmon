import React, { useState } from 'react';
import * as I from '../lib/icons';
import { api } from '../lib/api';
import { useQuery } from '../lib/query';
import { Link } from '../lib/router';
import { usePersist } from '../lib/persist';
import { fmtDate } from '../lib/util';
import { Badge, Empty, ErrorBox, Loading, Modal, Select, Tabs } from '../ui';
import { BarChart, Donut, HBars, Heatmap, LineChart, Sparkline, fmtCompact, fmtDay, fmtN, fmtPct, downloadCsv } from './charts';
import './analytics.css';

// ---------------------------------------------------------------- состояние: период и вкладка (на пользователя)
interface St { tab: string; days: number; from: string; to: string; compare: boolean; dept: number; category: number }
const DEF: St = { tab: 'overview', days: 30, from: '', to: '', compare: true, dept: 0, category: 0 };
const PERIODS = [[7, '7 дней'], [30, '30 дней'], [90, '90 дней'], [365, 'Год'], [0, 'Свой']] as const;

const qs = (st: St, extra: Record<string, any> = {}) => {
  const p = new URLSearchParams();
  if (st.days > 0) p.set('days', String(st.days)); else { if (st.from) p.set('from', st.from); if (st.to) p.set('to', st.to); }
  if (!st.compare) p.set('compare', '0');
  for (const [k, v] of Object.entries(extra)) if (v) p.set(k, String(v));
  return p.toString();
};

function useReport<T = any>(name: string, st: St, extra: Record<string, any> = {}, enabled = true) {
  const q = qs(st, extra);
  return useQuery<T>(enabled ? `analytics:${name}?${q}` : null, () => api.get(`/api/analytics/${name}?${q}`), { stale: 60000, keepPrevious: true });
}

const Wait = ({ r, children }: { r: { data: any; error: any; refetch: () => any }; children: (d: any) => React.ReactNode }) =>
  r.error && !r.data ? <ErrorBox error={r.error} retry={r.refetch} /> : !r.data ? <Loading /> : <>{children(r.data)}</>;

// ---------------------------------------------------------------- плитки
function Delta({ delta, pp, good = 'up' }: { delta?: number | null; pp?: number | null; good?: 'up' | 'down' }) {
  const v = pp ?? delta;
  if (v == null) return <span className="d flat">нет базы для сравнения</span>;
  const dir = v === 0 ? 'flat' : (v > 0) === (good === 'up') ? 'up' : 'down';
  return <span className={'d ' + dir}>{v > 0 ? '▲' : v < 0 ? '▼' : '='} {Math.abs(v).toLocaleString('ru-RU')}{pp != null ? ' п.п.' : '%'}<span className="sr"> к прошлому периоду</span></span>;
}

function Tile({ label, value, delta, pp, good, spark, title }: { label: string; value: string; delta?: number | null; pp?: number | null; good?: 'up' | 'down'; spark?: number[]; title?: string }) {
  return (
    <div className="card anTile" title={title}>
      <span className="l">{label}</span>
      <span className="v">{value}</span>
      <Delta delta={delta} pp={pp} good={good} />
      {spark && <div className="sp"><Sparkline values={spark} /></div>}
    </div>
  );
}

const TILE: Record<string, { l: string; good?: 'up' | 'down'; hint?: string }> = {
  dau: { l: 'Активных в день (в среднем)', hint: 'Среднее число уникальных сотрудников, открывавших портал за день' },
  mau: { l: 'MAU на конец периода', hint: 'Уникальные активные за последние 30 дней' },
  visits: { l: 'Визитов', hint: 'Визит — возвращение после 30 минут без активности' },
  pv: { l: 'Просмотров страниц' },
  news_views: { l: 'Просмотров новостей', hint: 'Не чаще раза в 30 минут на пользователя и новость' },
  reach: { l: 'Охват новостей', hint: 'Среднее по новостям периода: уникальные читатели / аудитория (подразделение с вложенными, для новостей всей компании — все сотрудники), не более 100%' },
  er: { l: 'Вовлечённость (ER)', hint: '(реакции + комментарии) / просмотры' },
  msgs: { l: 'Сообщений в чатах', hint: 'Только счётчик, содержимое не читается' },
  searches: { l: 'Поисковых запросов' },
  zero_rate: { l: 'Поиски без результата', good: 'down' },
  reactions: { l: 'Реакций и комментариев (новости)' },
};

const fmtTile = (t: any) => (t.unit === 'pct' ? fmtPct(t.value) : fmtCompact(t.value));

// ---------------------------------------------------------------- обзор
function Overview({ st }: { st: St }) {
  const r = useReport('overview', st);
  return <Wait r={r}>{(d) => (
    <div className="stack">
      {!d.has_data && <div className="card pad anNote">Данные только начинают собираться: графики наполняются по мере посещений (сброс счётчиков — каждые 20 секунд, пересчёт — раз в 5 минут).</div>}
      <div className="anGrid">
        {d.tiles.map((t: any) => { const m = TILE[t.id] || { l: t.id }; return <Tile key={t.id} label={m.l} title={m.hint} value={fmtTile(t)} delta={t.delta} pp={t.delta_pp} good={m.good} spark={t.spark} />; })}
      </div>
      <div className="anNote">Сейчас онлайн: <b>{d.online}</b> · сотрудников: <b>{fmtN(d.users_total)}</b> · новостей опубликовано за период: <b>{fmtN(d.published)}</b></div>
    </div>
  )}</Wait>;
}

// ---------------------------------------------------------------- аудитория
const DOW = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
const DEVICE: Record<string, string> = { desktop: 'Компьютер', mobile: 'Телефон', tablet: 'Планшет' };
const BROWSER: Record<string, string> = { chrome: 'Chrome', edge: 'Edge', firefox: 'Firefox', safari: 'Safari', yandex: 'Яндекс Браузер', opera: 'Opera', other: 'Другие' };

function Audience({ st }: { st: St }) {
  const r = useReport('audience', st);
  return <Wait r={r}>{(d) => {
    const k = d.kpi, p = d.prev;
    return (
      <div className="stack">
        <div className="anGrid">
          <Tile label="Активных в день (среднее)" value={fmtN(k.dau_avg)} delta={p && pctOf(k.dau_avg, p.dau_avg)} spark={d.dau} />
          <Tile label="Пик за день" value={fmtN(k.dau_peak)} />
          <Tile label="WAU на конец периода" value={fmtN(k.wau)} delta={p && pctOf(k.wau, p.wau)} />
          <Tile label="MAU на конец периода" value={fmtN(k.mau)} delta={p && pctOf(k.mau, p.mau)} />
          <Tile label="Залипание (DAU / MAU)" value={fmtPct(k.stickiness, 0)} title="Какая доля месячной аудитории заходит каждый день" />
          <Tile label="Охват сотрудников (MAU / все)" value={fmtPct(k.active_share, 0)} title={`Всего активных учётных записей: ${fmtN(k.users_total)}`} />
          <Tile label="Визитов" value={fmtCompact(k.visits)} delta={p && pctOf(k.visits, p.visits)} spark={d.visits} />
          <Tile label="Новых сотрудников" value={fmtN(k.new_users)} spark={d.new_users} />
        </div>
        <div className="card pad"><LineChart title="DAU, WAU, MAU" sub="уникальные пользователи" labels={d.days} labelFmt={fmtDay} csvName="audience-dau-wau-mau"
          series={[{ id: 'dau', name: 'DAU (день)', values: d.dau }, { id: 'wau', name: 'WAU (7 дней)', values: d.wau }, { id: 'mau', name: 'MAU (30 дней)', values: d.mau }]} /></div>
        <div className="anCols">
          <div className="card pad"><LineChart area title="Залипание" sub="DAU / MAU" labels={d.days} labelFmt={fmtDay} fmt={(v) => fmtPct(v, 1)} csvName="audience-stickiness" series={[{ id: 's', name: 'DAU / MAU', values: d.stickiness }]} /></div>
          <div className="card pad"><BarChart title="Визиты по дням" labels={d.days} labelFmt={fmtDay} csvName="audience-visits" series={[{ id: 'v', name: 'Визиты', values: d.visits }]} /></div>
        </div>
        <div className="card pad"><Heatmap title="Когда заходят" sub="визиты по дню недели и часу (часовой пояс портала)" rows={DOW} cols={Array.from({ length: 24 }, (_, i) => String(i))} data={d.heatmap} unit="визитов" csvName="audience-heatmap" /></div>
        <div className="anCols">
          <div className="card pad"><Donut title="Устройства" items={d.devices.map((x: any) => ({ id: x.id, label: DEVICE[x.id] || x.id, value: x.value }))} csvName="audience-devices" /></div>
          <div className="card pad"><Donut title="Браузеры" items={d.browsers.map((x: any) => ({ id: x.id, label: BROWSER[x.id] || x.id, value: x.value }))} csvName="audience-browsers" /></div>
        </div>
        <div className="anNote">Устройство и браузер определяются по User-Agent грубо (классы), сама строка и IP не сохраняются. Сейчас онлайн: {d.online}.</div>
      </div>
    );
  }}</Wait>;
}
const pctOf = (a: number, b: number) => (b ? Math.round(((a - b) / b) * 1000) / 10 : null);

// ---------------------------------------------------------------- контент
function NewsTable({ rows, cols }: { rows: any[]; cols: ('views' | 'reach' | 'er' | 'react')[] }) {
  if (!rows.length) return <div className="cfEmpty">Нет данных за период</div>;
  return (
    <div className="tblW"><table className="tbl anTbl"><thead><tr><th>Новость</th><th>Автор</th>
      {cols.includes('views') && <th className="n">Просм.</th>}{cols.includes('views') && <th className="n">Уник.</th>}
      {cols.includes('react') && <th className="n">Реакц.</th>}{cols.includes('react') && <th className="n">Коммент.</th>}
      {cols.includes('reach') && <th className="n">Охват</th>}{cols.includes('er') && <th className="n">ER</th>}</tr></thead><tbody>
      {rows.map((n) => (
        <tr key={n.id}><td style={{ maxWidth: 360 }}><Link to={`/news/${n.id}`} className="clamp2 bold" style={{ color: 'var(--accent)' }}>{n.title}</Link><div className="tiny muted">{n.dept} · {fmtDate(n.published_at)}</div></td>
          <td className="small">{n.author || '—'}</td>
          {cols.includes('views') && <td className="n">{fmtN(n.views ?? n.views_count)}</td>}{cols.includes('views') && <td className="n">{fmtN(n.uniq ?? n.uniq_views)}</td>}
          {cols.includes('react') && <td className="n">{fmtN(n.reactions)}</td>}{cols.includes('react') && <td className="n">{fmtN(n.comments)}</td>}
          {cols.includes('reach') && <td className="n">{n.reach}%</td>}{cols.includes('er') && <td className="n">{n.er}%</td>}</tr>
      ))}</tbody></table></div>
  );
}

function Content({ st, set, editor }: { st: St; set: (p: Partial<St>) => void; editor: boolean }) {
  const meta = useQuery<any>('analytics:meta', () => api.get('/api/analytics/meta'), { stale: 300000 });
  const r = useReport('content', st, { dept: st.dept, category: st.category });
  const eng = useReport('engagement', st, {}, !editor);
  return (
    <div className="stack">
      <div className="anBar">
        <Select aria-label="Подразделение" value={st.dept} onChange={(e) => set({ dept: +e.target.value })} style={{ maxWidth: 260 }}>
          <option value={0}>{editor ? 'Вся моя область' : 'Все подразделения'}</option>
          {(meta.data?.departments || []).map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </Select>
        <Select aria-label="Категория" value={st.category} onChange={(e) => set({ category: +e.target.value })} style={{ maxWidth: 220 }}>
          <option value={0}>Все категории</option>
          {(meta.data?.categories || []).map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </Select>
      </div>
      <Wait r={r}>{(d) => {
        const k = d.kpi, p = d.prev, days = d.series.map((x: any) => x.day);
        const col = (f: string) => d.series.map((x: any) => x[f]);
        const dl = (f: string) => (p ? pctOf(k[f], p[f]) : undefined);
        return (
          <>
            <div className="anGrid">
              <Tile label="Опубликовано" value={fmtN(k.published)} delta={dl('published')} spark={col('published')} />
              <Tile label="Просмотров" value={fmtCompact(k.views)} delta={dl('views')} spark={col('views')} />
              <Tile label="Уникальных читателей" value={fmtCompact(k.uniq)} delta={dl('uniq')} spark={col('uniq')} title="Новые уникальные читатели за период (суммарно по новостям)" />
              <Tile label="Средний охват" value={fmtPct(k.reach, 0)} pp={p ? Math.round((k.reach - p.reach) * 1000) / 10 : undefined} title={TILE.reach.hint} />
              <Tile label="Реакций" value={fmtCompact(k.reactions)} delta={dl('reactions')} spark={col('reactions')} />
              <Tile label="Комментариев" value={fmtCompact(k.comments)} delta={dl('comments')} spark={col('comments')} />
              <Tile label="Вовлечённость ER" value={fmtPct(k.er)} pp={p ? Math.round((k.er - p.er) * 1000) / 10 : undefined} title={TILE.er.hint} />
              <Tile label="Просмотров на новость" value={fmtN(k.views_per_news)} delta={dl('views_per_news')} />
            </div>
            <div className="anCols">
              <div className="card pad"><LineChart area title="Просмотры" labels={days} labelFmt={fmtDay} csvName="content-views" series={[{ id: 'v', name: 'Просмотры', values: col('views') }, { id: 'u', name: 'Новые уникальные', values: col('uniq') }]} /></div>
              <div className="card pad"><BarChart stacked title="Вовлечение" sub="реакции и комментарии" labels={days} labelFmt={fmtDay} csvName="content-engagement" series={[{ id: 'r', name: 'Реакции', values: col('reactions') }, { id: 'c', name: 'Комментарии', values: col('comments') }]} /></div>
            </div>
            <div className="card pad"><HBars title="Воронка вовлечения" sub="новости периода: аудитория → прочитали → реакции → комментарии" max={d.funnel?.[0]?.value || 1} csvName="content-funnel"
              items={(d.funnel || []).map((x: any, i: number) => ({ id: i, label: x.label, value: x.value, extra: d.funnel[0].value ? '· ' + fmtPct(x.value / d.funnel[0].value, 1) : '', color: 'var(--chart-' + (i + 1) + ')' }))} /></div>
            <div className="card pad stack"><h3>ТОП новостей по просмотрам</h3><NewsTable rows={d.top} cols={['views', 'react', 'reach', 'er']} /></div>
            <div className="card pad stack"><h3>Низкий охват</h3><div className="anNote">Новости периода старше двух суток с самой малой долей прочитавших из аудитории.</div><NewsTable rows={d.low_reach} cols={['views', 'reach']} /></div>
            {!editor && <div className="anCols">
              <div className="card pad"><HBars title="Охват по подразделениям-авторам" sub="средний охват новостей" fmt={(v) => fmtPct(v, 0)} max={1} csvName="content-reach-by-dept"
                items={d.by_dept.map((x: any) => ({ id: x.id, label: x.name, value: x.reach, extra: `· ${x.published} нов.` }))} /></div>
              <div className="card pad"><HBars title="Вовлечённость по подразделениям-авторам" sub="ER = (лайки + комментарии) / просмотры" fmt={(v) => fmtPct(v)} csvName="content-er-by-dept"
                items={d.by_dept.map((x: any) => ({ id: x.id, label: x.name, value: x.views ? x.engagement / x.views : 0, color: 'var(--chart-3)' }))} /></div>
            </div>}
            <div className="anCols">
              {!editor && <div className="card pad"><HBars title="Кто читает: подразделения читателей" sub={`доля сотрудников подразделения, открывших новость (по ${d.viewer_news} нов.)`} fmt={(v) => fmtPct(v, 0)} max={1} csvName="content-viewers-by-dept"
                items={d.viewer_depts.filter((x: any) => x.staff > 0).map((x: any) => ({ id: x.id, label: x.name, value: Math.min(1, x.share), extra: `· ${fmtCompact(x.viewers)}`, color: 'var(--chart-7)' }))} /></div>}
              <div className="card pad"><Donut title="Публикации по категориям" items={foldTop(d.by_category.map((x: any) => ({ id: String(x.id), label: x.name, value: x.published })))} csvName="content-by-category" /></div>
            </div>
          </>
        );
      }}</Wait>
      {!editor && <Wait r={eng}>{(e) => (
        <div className="stack">
          <h3>Вовлечение вне новостей</h3>
          <div className="anNote">Чаты и группы — только счётчики сообщений по дням, содержимое не читается.</div>
          <div className="anCols">
            <div className="card pad"><BarChart stacked title="Сообщения в чатах" labels={e.days} labelFmt={fmtDay} csvName="eng-messages" series={[{ id: 'd', name: 'Личные', values: e.m.msg_direct }, { id: 'g', name: 'Групповые', values: e.m.msg_group }]} /></div>
            <div className="card pad"><LineChart title="Активные чаты и отправители" labels={e.days} labelFmt={fmtDay} csvName="eng-chats" series={[{ id: 'c', name: 'Чатов с сообщениями', values: e.m.chats_active }, { id: 's', name: 'Отправителей', values: e.m.msg_senders }]} /></div>
            <div className="card pad"><BarChart stacked title="Комментарии и ответы" labels={e.days} labelFmt={fmtDay} csvName="eng-comments" series={[{ id: 'n', name: 'К новостям', values: e.m.comments_news }, { id: 'p', name: 'К постам групп', values: e.m.comments_post }, { id: 'i', name: 'К идеям', values: e.m.comments_idea }]} sub={`ответов (вложенных): ${fmtN(e.sum.replies || 0)}`} /></div>
            <div className="card pad"><BarChart title="Группы, идеи, голосования" labels={e.days} labelFmt={fmtDay} csvName="eng-misc" series={[{ id: 'g', name: 'Посты в группах', values: e.m.group_posts }, { id: 'i', name: 'Новые идеи', values: e.m.ideas_new }, { id: 'v', name: 'Голоса в опросах', values: e.m.poll_votes }]} /></div>
            {e.has_bookmarks && <div className="card pad"><LineChart title="Закладки и упоминания" labels={e.days} labelFmt={fmtDay} csvName="eng-bookmarks" series={[{ id: 'b', name: 'Закладки', values: e.m.bookmarks }, { id: 'm', name: 'Упоминания', values: e.m.mentions }]} /></div>}
            {e.has_reactions && e.emoji?.length > 0 && <div className="card pad"><HBars title="Реакции на новости по смайлам" items={e.emoji.map((x: any) => ({ id: x.id, label: x.id, value: x.value }))} csvName="eng-emoji" /></div>}
          </div>
        </div>
      )}</Wait>}
    </div>
  );
}

/** Не более 7 долей + «Прочее» (категориальная палитра — 8 цветов). */
function foldTop(items: { id: string; label: string; value: number }[]) {
  const s = [...items].sort((a, b) => b.value - a.value);
  if (s.length <= 8) return s;
  const rest = s.slice(7).reduce((a, b) => a + b.value, 0);
  return [...s.slice(0, 7), { id: 'rest', label: 'Прочее', value: rest }];
}

// ---------------------------------------------------------------- поиск
const SCOPE: Record<string, string> = { global: 'Общий поиск', news: 'Новости', people: 'Сотрудники', groups: 'Группы', ideas: 'Идеи', photos: 'Фото', videos: 'Видео', vacations: 'Отпуска', learning: 'Обучение: материалы', learning_tests: 'Обучение: тесты', admin_news: 'Админка новостей', documents: 'Документы', wiki: 'Wiki', requests: 'Заявки' };

function Who({ q, st, onClose }: { q: string; st: St; onClose: () => void }) {
  const r = useQuery<any>(`analytics:who:${q}:${qs(st)}`, () => api.get(`/api/analytics/search/users?q=${encodeURIComponent(q)}&${qs(st)}`), { stale: 0 });
  return (
    <Modal title={`Кто искал: «${q}»`} onClose={onClose} size="lg">
      <div className="stack">
        <div className="anPriv"><I.Lock size={15} /> Персональные данные. Просмотр фиксируется в журнале аудита; используйте только для улучшения поиска.</div>
        {r.error ? <ErrorBox error={r.error} retry={r.refetch} /> : !r.data ? <Loading /> : r.data.items.length === 0 ? <div className="cfEmpty">Нет записей (возможно, срок хранения истёк)</div> : (
          <div className="tblW"><table className="tbl anTbl"><thead><tr><th>Сотрудник</th><th>Подразделение</th><th className="n">Запросов</th><th className="n">Без рез.</th><th className="n">Переходов</th><th>Последний</th></tr></thead><tbody>
            {r.data.items.map((u: any) => <tr key={u.id ?? u.name}><td>{u.id ? <Link to={`/people/${u.id}`} style={{ color: 'var(--accent)' }}>{u.name}</Link> : u.name}</td><td className="small">{u.dept}</td><td className="n">{u.searches}</td><td className="n">{u.zero}</td><td className="n">{u.clicks}</td><td className="small">{fmtDate(u.last_at)}</td></tr>)}
          </tbody></table></div>
        )}
      </div>
    </Modal>
  );
}

function QueryTable({ rows, cols, onWho, onResolve }: { rows: any[]; cols: ('zero' | 'noclick' | 'clicks')[]; onWho: (q: string) => void; onResolve?: (q: string, done: boolean) => void }) {
  if (!rows?.length) return <div className="cfEmpty">Нет данных за период</div>;
  return (
    <div className="tblW"><table className="tbl anTbl"><thead><tr><th>Запрос</th><th className="n">Поисков</th>
      {cols.includes('zero') && <th className="n">Без рез.</th>}{cols.includes('noclick') && <th className="n">Без клика</th>}{cols.includes('clicks') && <th className="n">Переходов</th>}
      <th className="n" title="Сумма различных пользователей по дням">Польз.</th>{onResolve && <th>Статус</th>}</tr></thead><tbody>
      {rows.map((x) => (
        <tr key={x.q}><td><button type="button" className="linkBtn" style={{ background: 'none', border: 0, padding: 0, color: 'var(--accent)', textAlign: 'left' }} title="Кто искал (персональные данные)" onClick={() => onWho(x.q)}>{x.sample || x.q}</button></td>
          <td className="n">{x.searches}</td>{cols.includes('zero') && <td className="n">{x.zero}</td>}{cols.includes('noclick') && <td className="n">{x.noclick}</td>}{cols.includes('clicks') && <td className="n">{x.clicks}</td>}<td className="n">{x.users}</td>{onResolve && <td>{x.resolved_at ? <button type="button" className="btn sm" title={x.note || 'Снять отметку'} onClick={() => onResolve(x.q, false)}>Обработан ✕</button> : <button type="button" className="btn sm" onClick={() => onResolve(x.q, true)}>Отметить обработанным</button>}</td>}</tr>
      ))}</tbody></table></div>
  );
}

function Search({ st }: { st: St }) {
  const [scope, setScope] = useState('all');
  const [who, setWho] = useState('');
  const [resolved, setResolved] = useState('open');
  const r = useReport('search', st, { scope: scope === 'all' ? '' : scope, resolved });
  const resolve = async (q: string, done: boolean) => {
    try { await api.post('/api/analytics/search/resolve', { q, resolved: done }); r.refetch(); } catch {}
  };
  const exp = (kind: string) => `/api/analytics/search/export?kind=${kind}&${qs(st, { scope: scope === 'all' ? '' : scope })}`;
  return (
    <div className="stack">
      <div className="anBar">
        <Select aria-label="Раздел поиска" value={scope} onChange={(e) => setScope(e.target.value)} style={{ maxWidth: 260 }}>
          <option value="all">Все разделы</option>
          {Object.entries(SCOPE).filter(([k]) => k !== 'admin_news').map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>
        <span className="anNote">Список «кто искал» открывается по клику на запрос и пишется в журнал аудита.</span>
      </div>
      <Wait r={r}>{(d) => {
        const k = d.kpi, p = d.prev;
        const days = d.series.map((x: any) => x.day);
        return (
          <>
            <div className="anGrid">
              <Tile label="Запросов" value={fmtCompact(k.total)} delta={p && pctOf(k.total, p.total)} spark={d.series.map((x: any) => x.total)} />
              <Tile label="Без результатов" value={fmtCompact(k.zero)} delta={p && pctOf(k.zero, p.zero)} good="down" />
              <Tile label="Доля пустых" value={fmtPct(k.zero_rate)} pp={p ? Math.round((k.zero_rate - p.zero_rate) * 1000) / 10 : undefined} good="down" spark={d.series.map((x: any) => x.zero_rate)} />
              <Tile label="Переходов по результату" value={fmtPct(k.ctr, 0)} pp={p ? Math.round((k.ctr - p.ctr) * 1000) / 10 : undefined} title="CTR: только общий поиск (там отслеживаются клики)" />
              <Tile label="Среднее время ответа" value={Math.round(k.avg_ms) + ' мс'} />
            </div>
            <div className="anCols">
              <div className="card pad"><BarChart title="Запросы по дням" labels={days} labelFmt={fmtDay} csvName="search-volume" series={[{ id: 'ok', name: 'С результатом', values: d.series.map((x: any) => x.total - x.zero) }, { id: 'z', name: 'Без результата', values: d.series.map((x: any) => x.zero), color: 'var(--chart-2)' }]} stacked /></div>
              <div className="card pad"><LineChart area title="Динамика доли пустых" labels={days} labelFmt={fmtDay} fmt={(v) => fmtPct(v)} csvName="search-zero-rate" series={[{ id: 'r', name: 'Доля без результата', values: d.series.map((x: any) => x.zero_rate), color: 'var(--chart-2)' }]} /></div>
            </div>
            <div className="anCols">
              <div className="card pad"><HBars title="По разделам" sub="запросов · доля пустых" csvName="search-by-scope" items={d.by_scope.map((x: any) => ({ id: x.scope, label: SCOPE[x.scope] || x.scope, value: x.total, extra: `· ${fmtPct(x.zero_rate, 0)} пустых` }))} /></div>
              <div className="card pad stack"><h3>Облако запросов</h3>
                <div className="anCloud">{(d.top || []).slice(0, 40).map((x: any) => { const m = d.top[0]?.searches || 1; return <button type="button" key={x.q} style={{ fontSize: 12 + Math.round((x.searches / m) * 16), opacity: 0.55 + 0.45 * (x.searches / m) }} onClick={() => setWho(x.q)} title={`${x.searches} поисков`}>{x.sample || x.q}</button>; })}
                  {!d.top?.length && <div className="cfEmpty" style={{ width: '100%' }}>Нет данных за период</div>}</div></div>
            </div>
            <div className="card pad stack"><div className="row"><h3 className="sp">ТОП запросов</h3><a className="btn sm" href={exp('top')}>CSV</a></div><QueryTable rows={d.top} cols={['zero', 'clicks']} onWho={setWho} /></div>
            <div className="card pad stack"><div className="row"><h3 className="sp">Запросы без результатов</h3><a className="btn sm" href={exp('zero')}>CSV</a></div><div className="anNote">Здесь не хватает контента, синонимов или названий — кандидаты на новые материалы.</div><div className="anBar"><Select aria-label="Статус" value={resolved} onChange={(e) => setResolved(e.target.value)} style={{ maxWidth: 220 }}><option value="open">Необработанные</option><option value="done">Обработанные</option><option value="all">Все</option></Select></div><QueryTable rows={d.zero_queries} cols={['zero']} onWho={setWho} onResolve={resolve} /></div>
            <div className="card pad stack"><div className="row"><h3 className="sp">Результаты есть, но не открывают</h3><a className="btn sm" href={exp('noclick')}>CSV</a></div><div className="anNote">Общий поиск: запросы, после которых почти никогда не открывают результат — выдача нерелевантна.</div><QueryTable rows={d.noclick_queries} cols={['noclick', 'clicks']} onWho={setWho} /></div>
          </>
        );
      }}</Wait>
      {who && <Who q={who} st={st} onClose={() => setWho('')} />}
    </div>
  );
}

// ---------------------------------------------------------------- разделы
const SECTION: Record<string, string> = { news: 'Новости', chat: 'Сообщения', groups: 'Группы', learning: 'Обучение', documents: 'Документы', photos: 'Фото', videos: 'Видео', calendar: 'Календарь', people: 'Сотрудники', departments: 'Подразделения', directions: 'Направления', ideas: 'Идеи', requests: 'Заявки', wiki: 'Wiki', vacations: 'Отпуска', search: 'Поиск', notifications: 'Уведомления', admin: 'Администрирование', settings: 'Настройки', company: 'О компании и ресурсы', other: 'Прочее' };

function Sections({ st }: { st: St }) {
  const r = useReport('sections', st);
  return <Wait r={r}>{(d) => {
    const top = d.sections.slice(0, 7).map((x: any) => x.id);
    const rest = d.days.map((_: string, i: number) => d.sections.filter((x: any) => !top.includes(x.id)).reduce((a: number, x: any) => a + (d.series[x.id]?.[i] || 0), 0));
    const series = [...top.map((id: string) => ({ id, name: SECTION[id] || id, values: d.series[id] || [] })), ...(d.sections.length > 7 ? [{ id: 'rest', name: 'Остальные', values: rest }] : [])];
    return (
      <div className="stack">
        <div className="anCols">
          <div className="card pad"><HBars title="Трафик по разделам" sub="просмотры страниц" csvName="sections-pv" items={d.sections.map((x: any) => ({ id: x.id, label: SECTION[x.id] || x.id, value: x.pv, extra: x.delta != null ? `${x.delta > 0 ? '▲' : '▼'}${Math.abs(x.delta)}%` : '' }))} /></div>
          <div className="card pad"><Donut title="Доли разделов" items={foldTop(d.sections.map((x: any) => ({ id: x.id, label: SECTION[x.id] || x.id, value: x.pv })))} csvName="sections-share" /></div>
        </div>
        <div className="card pad"><BarChart stacked title="Просмотры по дням" labels={d.days} labelFmt={fmtDay} series={series} csvName="sections-daily" /></div>
        <div className="card pad stack"><h3>Посетители разделов</h3>
          <div className="tblW"><table className="tbl anTbl"><thead><tr><th>Раздел</th><th className="n">Просмотров</th><th className="n">Прошлый период</th><th className="n">Δ</th><th className="n" title="Среднее число уникальных посетителей в день">Посетителей/день</th></tr></thead><tbody>
            {d.sections.map((x: any) => <tr key={x.id}><td>{SECTION[x.id] || x.id}</td><td className="n">{fmtN(x.pv)}</td><td className="n">{fmtN(x.prev)}</td><td className="n">{x.delta != null ? (x.delta > 0 ? '+' : '') + x.delta + '%' : '—'}</td><td className="n">{fmtN(x.users_avg)}</td></tr>)}
          </tbody></table></div></div>
      </div>
    );
  }}</Wait>;
}

// ---------------------------------------------------------------- редакторы
function Editors({ st }: { st: St }) {
  const r = useReport('editors', st);
  return <Wait r={r}>{(d) => (
    <div className="stack">
      <div className="card pad"><HBars title="Публикации по авторам" csvName="editors-published" items={d.items.slice(0, 15).map((x: any) => ({ id: x.id, label: x.name, sub: x.dept, value: x.published }))} /></div>
      <div className="card pad stack"><div className="row"><h3 className="sp">Редакторы</h3>
        <button className="btn sm" onClick={() => downloadCsv('editors', ['Автор', 'Подразделение', 'Публикаций', 'Просмотров', 'Уникальных', 'Средний охват %', 'ER %'],
          d.items.map((x: any) => [x.name, x.dept, x.published, x.views, x.uniq, Math.round(x.reach * 100), x.views ? Math.round((x.engagement / x.views) * 1000) / 10 : 0]))}>CSV</button></div>
        {d.items.length === 0 ? <div className="cfEmpty">Нет публикаций за период</div> : (
          <div className="tblW"><table className="tbl anTbl"><thead><tr><th>Автор</th><th>Подразделение</th><th className="n">Публикаций</th><th className="n">Просмотров</th><th className="n">Ср. охват</th><th className="n">ER</th><th>Последняя</th></tr></thead><tbody>
            {d.items.map((x: any) => <tr key={x.id}><td><Link to={`/people/${x.id}`} style={{ color: 'var(--accent)' }}>{x.name}</Link></td><td className="small">{x.dept}</td><td className="n">{x.published}</td><td className="n">{fmtN(x.views)}</td><td className="n">{fmtPct(x.reach, 0)}</td><td className="n">{fmtPct(x.views ? x.engagement / x.views : 0)}</td><td className="small">{fmtDate(x.last_at)}</td></tr>)}
          </tbody></table></div>)}
      </div>
    </div>
  )}</Wait>;
}

// ---------------------------------------------------------------- обучение, заявки, wiki
function Modules({ st }: { st: St }) {
  const r = useReport('modules', st);
  return <Wait r={r}>{(d) => {
    const L = d.learning, Q = d.requests, W = d.wiki;
    if (!L && !Q && !W) return <div className="card"><Empty icon={I.Info} title="Нет данных">Разделы «Обучение», «Заявки» и «Wiki» не подключены или ещё не использовались.</Empty></div>;
    const hrs = (v: number | null | undefined) => (v == null ? '—' : v < 48 ? Math.round(v * 10) / 10 + ' ч' : Math.round(v / 2.4) / 10 + ' дн');
    return (
      <div className="stack">
        {L && <div className="stack"><h3>Обучение</h3>
          <div className="anGrid">
            <Tile label="Назначено" value={fmtN(L.sum.learn_assigned || 0)} delta={L.prev && pctOf(L.sum.learn_assigned, L.prev.learn_assigned)} spark={L.m.learn_assigned} />
            <Tile label="Выполнено" value={fmtN(L.sum.learn_done || 0)} delta={L.prev && pctOf(L.sum.learn_done, L.prev.learn_done)} spark={L.m.learn_done} />
            <Tile label="В работе сейчас" value={L.open != null ? fmtN(L.open) : '—'} />
            <Tile label="Просрочено сейчас" value={L.overdue != null ? fmtN(L.overdue) : '—'} good="down" />
            <Tile label="Попыток тестов" value={fmtN(L.sum.learn_att_started || 0)} spark={L.m.learn_att_started} />
            <Tile label="Зачёт" value={fmtPct((L.sum.learn_att_passed || 0) / Math.max(1, L.sum.learn_att_finished || 0), 0)} title="Доля сданных среди завершённых попыток" />
          </div>
          <div className="anCols">
            <div className="card pad"><LineChart title="Назначения и выполнение" labels={L.days} labelFmt={fmtDay} csvName="learning-assign" series={[{ id: 'a', name: 'Назначено', values: L.m.learn_assigned }, { id: 'd', name: 'Выполнено', values: L.m.learn_done }]} /></div>
            <div className="card pad"><BarChart title="Тесты" labels={L.days} labelFmt={fmtDay} csvName="learning-tests" series={[{ id: 's', name: 'Начато', values: L.m.learn_att_started }, { id: 'f', name: 'Завершено', values: L.m.learn_att_finished }, { id: 'p', name: 'Сдано', values: L.m.learn_att_passed }]} /></div>
            {L.overdue_by_dept?.length > 0 && <div className="card pad"><HBars title="Просрочено по подразделениям" csvName="learning-overdue" items={L.overdue_by_dept.map((x: any) => ({ label: x.name, value: x.overdue, color: 'var(--chart-8)' }))} /></div>}
            {L.top_courses?.length > 0 && <div className="card pad"><HBars title="Курсы: завершения за период" csvName="learning-courses" items={L.top_courses.map((x: any) => ({ label: x.title, value: x.completed }))} /></div>}
          </div></div>}
        {Q && <div className="stack"><h3>Заявки</h3>
          <div className="anGrid">
            <Tile label="Подано" value={fmtN(Q.sum.req_submitted || 0)} delta={Q.prev && pctOf(Q.sum.req_submitted, Q.prev.req_submitted)} spark={Q.m.req_submitted} />
            <Tile label="В работе сейчас" value={Q.open != null ? fmtN(Q.open) : '—'} />
            <Tile label="Просрочено сейчас" value={Q.overdue != null ? fmtN(Q.overdue) : '—'} good="down" />
            <Tile label="Среднее время согласования" value={hrs(Q.avg_hours)} title="От подачи до закрытия (одобрены и выполнены)" />
            <Tile label="Медиана" value={hrs(Q.median_hours)} />
          </div>
          <div className="anCols">
            <div className="card pad"><BarChart title="Подано заявок" labels={Q.days} labelFmt={fmtDay} csvName="requests-submitted" series={[{ id: 's', name: 'Подано', values: Q.m.req_submitted }]} /></div>
            <div className="card pad"><Donut title="Статусы поданных за период" items={foldTop((Q.by_status || []).map((x: any) => ({ id: x.status, label: x.status, value: x.n })))} csvName="requests-status" /></div>
            {Q.by_type?.length > 0 && <div className="card pad"><HBars title="По типам заявок" csvName="requests-types" items={Q.by_type.map((x: any) => ({ label: x.name, value: x.n, extra: `· одобрено ${x.ok}` }))} /></div>}
          </div></div>}
        {W && <div className="stack"><h3>Wiki</h3>
          <div className="anGrid">
            <Tile label="Страниц всего" value={fmtN(W.pages || 0)} />
            <Tile label="Устарели (срок пересмотра)" value={fmtN(W.stale || 0)} good="down" />
            <Tile label="Создано страниц" value={fmtN(W.sum.wiki_created || 0)} spark={W.m.wiki_created} />
            <Tile label="Правок" value={fmtN(W.sum.wiki_edits || 0)} spark={W.m.wiki_edits} />
          </div>
          <div className="anCols">
            <div className="card pad"><BarChart title="Активность в Wiki" labels={W.days} labelFmt={fmtDay} csvName="wiki-activity" series={[{ id: 'c', name: 'Создано', values: W.m.wiki_created }, { id: 'e', name: 'Правки', values: W.m.wiki_edits }, { id: 'm', name: 'Комментарии', values: W.m.wiki_comments }]} /></div>
            {W.top_pages?.length > 0 && <div className="card pad"><HBars title="Самые читаемые страницы" csvName="wiki-top" onPick={(it) => { location.href = '/wiki/' + it.id; }} items={W.top_pages.map((x: any) => ({ id: x.id, label: x.title, value: x.views_count }))} /></div>}
          </div></div>}
      </div>
    );
  }}</Wait>;
}

// ---------------------------------------------------------------- страница
const TABS_ADMIN = [{ id: 'overview', label: 'Обзор' }, { id: 'audience', label: 'Аудитория' }, { id: 'content', label: 'Контент' }, { id: 'search', label: 'Поиск' },
  { id: 'sections', label: 'Разделы' }, { id: 'editors', label: 'Редакторы' }, { id: 'modules', label: 'Обучение и заявки' }];

export function AnalyticsAdmin({ admin }: { admin: boolean }) {
  const [st, setSt] = usePersist<St>('analytics.state', DEF);
  const set = (p: Partial<St>) => setSt((o) => ({ ...DEF, ...o, ...p }));
  const s: St = { ...DEF, ...st };
  const tab = admin ? (TABS_ADMIN.some((t) => t.id === s.tab) ? s.tab : 'overview') : 'content';
  const today = new Date().toISOString().slice(0, 10);
  return (
    <div className="stack">
      {!admin && <div><h2>Статистика моих новостей</h2><div className="anNote">Охват и вовлечение новостей вашего подразделения и вложенных подразделений, а также ваших публикаций.</div></div>}
      {admin && <Tabs value={tab} onChange={(v) => set({ tab: v })} items={TABS_ADMIN} />}
      <div className="anBar">
        <div className="seg" role="group" aria-label="Период">
          {PERIODS.map(([d, l]) => <button key={d} type="button" aria-pressed={s.days === d} onClick={() => set({ days: d, ...(d === 0 && !s.from ? { from: new Date(Date.now() - 29 * 864e5).toISOString().slice(0, 10), to: today } : {}) })}>{l}</button>)}
        </div>
        {s.days === 0 && <>
          <input className="inp" type="date" aria-label="С даты" value={s.from} max={s.to || today} onChange={(e) => set({ from: e.target.value })} />
          <span className="muted">—</span>
          <input className="inp" type="date" aria-label="По дату" value={s.to} min={s.from} max={today} onChange={(e) => set({ to: e.target.value })} />
        </>}
        <label className="row" style={{ gap: 6, fontSize: 13 }}><input type="checkbox" checked={s.compare} onChange={(e) => set({ compare: e.target.checked })} /> Сравнить с предыдущим периодом</label>
      </div>
      {tab === 'overview' && <Overview st={s} />}
      {tab === 'audience' && <Audience st={s} />}
      {tab === 'content' && <Content st={s} set={set} editor={!admin} />}
      {tab === 'search' && <Search st={s} />}
      {tab === 'sections' && <Sections st={s} />}
      {tab === 'editors' && <Editors st={s} />}
      {tab === 'modules' && <Modules st={s} />}
    </div>
  );
}
