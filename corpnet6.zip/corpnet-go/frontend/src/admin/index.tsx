import React from 'react';
import * as I from '../lib/icons';
import { Link, useTitle } from '../lib/router';
import { useStore, isAdmin, isEditor } from '../lib/store';
import { cx } from '../lib/util';
import { usePersist } from '../lib/persist';
import { Empty } from '../ui';
import './admin.css';
import { UsersAdmin } from './users';
import { TreeAdmin } from './tree';
import { NewsAdmin } from './news';
import { BannersAdmin } from './banners';
import { LdapAdmin } from './ldap';
import { KerberosAdmin } from './krb';
import { AnalyticsAdmin } from './analytics';
import { FileIndexAdmin } from './fileindex';
import { AuditAdmin, CategoriesAdmin, CommentsAdmin, CompanyAdmin, Dashboard, ResourcesAdmin } from './misc';

// Права: «admin» — суперадминистратор (всё); «editor» — редактор подразделения. Вкладки совпадают с обёртками маршрутов на бэке:
// banners/ldap/stats/comments/audit/company — только admin (A); news/users/departments/directions — editor и admin (E),
// область редактора (его подразделения и поддеревья) ограничивает сам сервер.
const TABS: { id: string; label: string; icon: any; admin?: boolean }[] = [
  { id: 'dashboard', label: 'Дашборд', icon: I.Dashboard, admin: true },
  { id: 'analytics', label: 'Аналитика', icon: I.Chart },
  { id: 'news', label: 'Новости', icon: I.Newspaper },
  { id: 'banners', label: 'Баннеры', icon: I.Image, admin: true },
  { id: 'users', label: 'Пользователи', icon: I.Users },
  { id: 'departments', label: 'Подразделения', icon: I.Building },
  { id: 'directions', label: 'Направления', icon: I.Layers },
  { id: 'categories', label: 'Категории', icon: I.Tag, admin: true },
  { id: 'resources', label: 'Ресурсы', icon: I.Link, admin: true },
  { id: 'ldap', label: 'LDAP', icon: I.Server, admin: true },
  { id: 'kerberos', label: 'Kerberos', icon: I.Key, admin: true },
  { id: 'comments', label: 'Комментарии', icon: I.Comment, admin: true },
  { id: 'company', label: 'Компания', icon: I.Briefcase, admin: true },
  { id: 'fileindex', label: 'Индекс файлов', icon: I.Database, admin: true },
  { id: 'audit', label: 'Журнал', icon: I.ScrollText, admin: true },
];

export default function Admin({ sub }: { sub: string }) {
  const me = useStore((s) => s.me)!;
  useTitle('Администрирование');
  const admin = isAdmin(me);
  const tabs = TABS.filter((t) => admin || !t.admin);
  // /admin без раздела открывает последний выбранный (если он доступен)
  const [last, setLast] = usePersist<string>('admin.tab', '');
  const cur = sub || (tabs.some((t) => t.id === last) ? last : admin ? 'dashboard' : 'news');
  const allowed = tabs.some((t) => t.id === cur);
  React.useEffect(() => { if (sub && allowed && sub !== last) setLast(sub); }, [sub, allowed]); // eslint-disable-line
  if (!isEditor(me)) return <div className="card"><Empty icon={I.Lock} title="Нет доступа">Раздел управления доступен редакторам и администраторам.</Empty></div>;
  const body = () => {
    switch (cur) {
      case 'dashboard': return <Dashboard />;
      case 'analytics': return <AnalyticsAdmin admin={admin} />;
      case 'news': return <NewsAdmin />;
      case 'banners': return <BannersAdmin />;
      case 'users': return <UsersAdmin />;
      case 'departments': return <TreeAdmin kind="departments" />;
      case 'directions': return <TreeAdmin kind="directions" />;
      case 'categories': return <CategoriesAdmin />;
      case 'resources': return <ResourcesAdmin />;
      case 'ldap': return <LdapAdmin />;
      case 'kerberos': return <KerberosAdmin />;
      case 'comments': return <CommentsAdmin />;
      case 'company': return <CompanyAdmin />;
      case 'fileindex': return <FileIndexAdmin />;
      case 'audit': return <AuditAdmin />;
      default: return null;
    }
  };
  return (
    <div className="stack">
      <div className="pageH"><h1>{admin ? 'Администрирование' : 'Управление контентом'}</h1></div>
      <div className="adminNav">{tabs.map((t) => <Link key={t.id} to={'/admin/' + t.id} className={cx('chip', cur === t.id && 'on')}><t.icon size={15} /> {t.id === 'analytics' && !admin ? 'Статистика моих новостей' : t.label}</Link>)}</div>
      {!allowed ? <div className="card"><Empty icon={I.Lock} title="Нет доступа">Этот раздел доступен только суперадминистратору.</Empty></div> : body()}
    </div>
  );
}
