import * as I from '../lib/icons';
import { useStore, setTheme } from '../lib/store';
import { THEMES, SYSTEM_THEME } from '../lib/themes';
import { cx } from '../lib/util';

/** Кружок-превью темы: половина — фон страницы, половина — акцентный цвет. */
export function ThemeDot({ swatch, system }: { swatch?: [string, string]; system?: boolean }) {
  if (system) return <span className="themeDot" style={{ ['--b' as any]: '#e3e9f1', ['--a' as any]: '#19232f' }}><I.Settings size={12} /></span>;
  return <span className="themeDot" style={{ ['--b' as any]: swatch![0], ['--a' as any]: swatch![1] }} />;
}

/** Список тем в меню профиля (меню не закрывается по выбору, чтобы можно было сравнить). */
export function ThemeMenu() {
  const theme = useStore((s) => s.theme);
  return (
    <div onClick={(e) => e.stopPropagation()} role="group" aria-label="Тема оформления">
      <div className="themeHead">Тема оформления</div>
      {[...THEMES, SYSTEM_THEME].map((t) => (
        <button key={t.id} className={cx('themeOpt', theme === t.id && 'on')} onClick={() => setTheme(t.id)} aria-pressed={theme === t.id}>
          <ThemeDot swatch={'swatch' in t ? t.swatch : undefined} system={t.id === 'system'} />
          {t.label}
          {theme === t.id && <I.Check size={16} className="ck" />}
        </button>
      ))}
    </div>
  );
}

/** Выбор темы чипами (страница «Настройки»). */
export function ThemeChips() {
  const theme = useStore((s) => s.theme);
  return (
    <div className="chips">
      {[...THEMES, SYSTEM_THEME].map((t) => (
        <button key={t.id} className={cx('chip', theme === t.id && 'on')} onClick={() => setTheme(t.id)} aria-pressed={theme === t.id}>
          <ThemeDot swatch={'swatch' in t ? t.swatch : undefined} system={t.id === 'system'} /> {t.label}
        </button>
      ))}
    </div>
  );
}
