import React, { useEffect, useRef, useState } from 'react';
import * as I from '../lib/icons';
import { Link, navigate, useLocation } from '../lib/router';
import { useStore, setState, getState, toast, isEditor, isAdmin } from '../lib/store';
import { api } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { realtime, useRealtime } from '../lib/ws';
import { cx, fmtDate, useDebounced, thumb, plural } from '../lib/util';
import { Avatar, Img, Loading, usePopover, Toasts } from '../ui';
import { Banners } from '../ui/Banners';
import { stripMd } from '../lib/markdown';
import { usePersist } from '../lib/persist';
import { trackPageview, trackSearchClick, resetPageview } from '../lib/analytics';
import { NotifRow, useNotifications, type NotifFilter } from '../pages/notifications';
import { ThemeMenu } from './ThemePicker';
import { wikiLink } from '../pages/wiki/lib';
import { ReqIcon } from '../pages/requests/icons';
import { FileHitRow, type FileHit } from '../ui/FileHit';
import { usePdfPreview } from '../ui/PdfViewer';
import * as X from '../lib/social-icons';
import './shell.css';

const NAV: { to: string; label: string; icon: any; badge?: 'chats'; match?: (p: string) => boolean }[] = [
  { to: '/', label: 'Новости', icon: I.Newspaper, match: (p) => p === '/' || p.startsWith('/news') },
  { to: '/directions', label: 'Направления деятельности', icon: I.Layers },
  { to: '/messages', label: 'Сообщения', icon: I.Message, badge: 'chats' },
  { to: '/calendar', label: 'Календарь', icon: I.Calendar },
  { to: '/groups', label: 'Группы', icon: I.Users },
  { to: '/ideas', label: 'Есть идея', icon: I.Lightbulb },
  { to: '/bookmarks', label: 'Закладки', icon: X.Bookmark },
];
const NAV2 = [
  { to: '/people', label: 'Сотрудники', icon: I.UserCheck },
  { to: '/departments', label: 'Подразделения', icon: I.Building },
  { to: '/vacations', label: 'График отпусков', icon: I.Clock },
];
const NAV3 = [
  { to: '/documents', label: 'Документы', icon: I.FileText },
  { to: '/photos', label: 'Фотогалерея', icon: I.Image },
  { to: '/videos', label: 'Видео', icon: I.Video },
  { to: '/resources', label: 'Ресурсы', icon: I.Link },
  { to: '/company', label: 'О компании', icon: I.Briefcase },
];

function GlobalSearch() {
  const pdf = usePdfPreview();
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const dq = useDebounced(q.trim(), 250);
  const ref = useRef<HTMLDivElement>(null);
  const { data } = useQuery<any>(dq.length >= 2 ? 'search:' + dq : null, () => api.get('/api/search?q=' + encodeURIComponent(dq)), { stale: 60000 });
  useEffect(() => {
    const d = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    addEventListener('mousedown', d);
    return () => removeEventListener('mousedown', d);
  }, []);
  const go = (to: string) => { setOpen(false); setQ(''); navigate(to); };
  const A = ({ to, children }: { to: string; children: React.ReactNode }) => <a href={to} onClick={(e) => { e.preventDefault(); trackSearchClick(dq, 'global', to.replace(/^\//, '').replace(/\?.*$/, '')); go(to); }}>{children}</a>;
  const g = (k: string): any[] => (dq.length >= 2 && data?.[k]) || [];
  const none = data && ['news', 'users', 'departments', 'files', 'file_content', 'groups', 'ideas', 'wiki'].every((k) => !g(k).length);
  const typing = q.trim().length >= 2 && q.trim() !== dq;
  return (
    <div className="searchBox" ref={ref}>
      <I.Search size={18} />
      <input
        value={q}
        placeholder="Поиск новостей, людей, файлов, идей…"
        aria-label="Поиск"
        onFocus={() => setOpen(true)}
        onChange={(e) => { setQ(e.target.value); setOpen(true); }}
        onKeyDown={(e) => { if (e.key === 'Enter' && q.trim().length >= 2) go('/search?q=' + encodeURIComponent(q.trim())); if (e.key === 'Escape') setOpen(false); }}
      />
      {open && q.trim().length > 0 && (
        <div className="sugg">
          {q.trim().length < 2 && <div className="muted small" style={{ padding: 14 }}>Введите минимум 2 символа</div>}
          {q.trim().length >= 2 && (!data || typing) && <Loading />}
          {q.trim().length >= 2 && !typing && none && <div className="muted" style={{ padding: 16 }}>Ничего не найдено</div>}
          {!typing && g('news').length > 0 && <div className="sh">Новости</div>}
          {!typing && g('news').map((n: any) => <A key={'n' + n.id} to={`/news/${n.id}`}><Img className="thumbS" style={{ width: 40, height: 40 }} src={thumb(n.cover)} /><span className="clamp2 small">{n.title}</span></A>)}
          {!typing && g('users').length > 0 && <div className="sh">Сотрудники</div>}
          {!typing && g('users').map((u: any) => <A key={'u' + u.id} to={`/people/${u.id}`}><Avatar name={u.name} src={u.avatar} size={34} /><span style={{ minWidth: 0 }}><div className="small bold clip">{u.name}</div><div className="tiny muted clip">{[u.job_title, u.department].filter(Boolean).join(' · ')}</div></span></A>)}
          {!typing && g('departments').length > 0 && <div className="sh">Подразделения</div>}
          {!typing && g('departments').map((d: any) => <A key={'d' + d.id} to={`/departments/${d.id}`}><I.Building size={18} /><span className="small">{d.name}</span></A>)}
          {!typing && g('groups').length > 0 && <div className="sh">Группы</div>}
          {!typing && g('groups').map((x: any) => <A key={'g' + x.id} to={`/groups/${x.id}`}><I.Users size={18} /><span className="small">{x.name}</span></A>)}
          {!typing && g('ideas').length > 0 && <div className="sh">Идеи</div>}
          {!typing && g('ideas').map((x: any) => <A key={'i' + x.id} to={`/ideas/${x.id}`}><I.Lightbulb size={18} /><span className="small clamp2">{x.title}</span></A>)}
          {!typing && g('wiki').length > 0 && <div className="sh">Базы знаний</div>}
          {!typing && g('wiki').map((w: any) => <A key={'w' + w.id} to={wikiLink(w)}><span style={{ fontSize: 18, width: 24, textAlign: 'center' }}>{w.space_icon || '📘'}</span><span style={{ minWidth: 0 }}><div className="small bold clip">{w.title}</div><div className="tiny muted clip">{w.space_title}</div></span></A>)}
          {!typing && g('files').length > 0 && <div className="sh">Файлы</div>}
          {!typing && g('files').map((f: any) => <A key={'f' + f.id} to={`/${f.kind}?folder=${f.folder_id}`}><I.File size={18} /><span className="small clip">{f.name} <span className="muted">· {f.folder}</span></span></A>)}
          {!typing && g('file_content').length > 0 && <div className="sh">В содержимом файлов</div>}
          {!typing && g('file_content').map((h: FileHit) => <FileHitRow key={'c' + h.id} h={h} q={dq} compact pdf={pdf} onNavigate={() => { setOpen(false); setQ(''); }} />)}
          {data && !typing && !none && q.trim().length >= 2 && <a href={'/search?q=' + encodeURIComponent(q.trim())} onClick={(e) => { e.preventDefault(); go('/search?q=' + encodeURIComponent(q.trim())); }} style={{ borderTop: '1px solid var(--line)', color: 'var(--accent)', fontWeight: 600 }}>Все результаты →</a>}
        </div>
      )}
      {pdf.node}
    </div>
  );
}

function Notifications() {
  const { open, setOpen, ref } = usePopover();
  const unread = useStore((s) => s.unreadNotifications);
  const [tab, setTab] = usePersist<NotifFilter>('notif.tab', 'unread');
  const L = useNotifications(tab, 8);
  // useNotifications подписан на realtime 'refresh' и обновляет счётчик, даже когда окно закрыто
  const close = () => setOpen(false);
  return (
    <div style={{ position: 'relative' }} ref={ref}>
      <button className="iconBtn" aria-label={unread > 0 ? `Уведомления, непрочитанных: ${unread}` : 'Уведомления'} aria-expanded={open} onClick={() => setOpen(!open)}>
        <I.Bell size={21} />
        {unread > 0 && <span className="dot">{unread > 99 ? '99+' : unread}</span>}
      </button>
      {open && (
        <div className="pop">
          <div className="ph">
            <span className="sp">Уведомления</span>
            {tab === 'unread' && unread > 0 && <button className="btn ghost sm" onClick={L.markAll}><I.CheckCheck size={15} /> Прочитать все</button>}
          </div>
          <div className="popTabs">
            <button className={cx(tab === 'unread' && 'on')} onClick={() => setTab('unread')}>Непрочитанные{unread > 0 ? ` · ${unread}` : ''}</button>
            <button className={cx(tab === 'read' && 'on')} onClick={() => setTab('read')}>Прочитанные</button>
          </div>
          <div className="pb">
            {L.loading && !L.items.length ? <Loading /> : L.items.length === 0 ? (
              <div className="empty"><I.Bell size={32} />{tab === 'unread' ? 'Новых уведомлений нет' : 'Прочитанных нет'}</div>
            ) : L.items.map((n) => <NotifRow key={n.id} n={n} onOpen={() => L.open(n, close)} onRead={() => L.markRead([n.id])} />)}
          </div>
          <Link to="/notifications" className="popFoot" onClick={close}>
            {L.hasMore ? 'Показать все уведомления →' : 'Все уведомления →'}
          </Link>
        </div>
      )}
    </div>
  );
}

function ProfileMenu() {
  const me = useStore((s) => s.me)!;
  const { open, setOpen, ref } = usePopover();
  async function logout() {
    await api.post('/api/auth/logout').catch(() => {});
    try { sessionStorage.setItem('krb_off', '1'); } catch {} // после выхода не входить автоматически по Kerberos (login.tsx)
    realtime.stop();
    location.href = '/login';
  }
  return (
    <div style={{ position: 'relative' }} ref={ref}>
      <button className="profBtn" onClick={() => setOpen(!open)} aria-label="Профиль">
        <Avatar name={me.name} src={me.avatar} size={38} />
        <span className="pt"><div className="pn">{me.first_name}</div><div className="pr">{me.job_title || (me.role === 'admin' ? 'Администратор' : me.role === 'editor' ? 'Редактор' : '')}</div></span>
      </button>
      {open && (
        <div className="menu" onClick={() => setOpen(false)}>
          <Link to={`/people/${me.id}`}><I.UserCheck size={18} /> Мой профиль</Link>
          <Link to="/settings"><I.Settings size={18} /> Настройки</Link>
          <hr />
          <ThemeMenu />
          {isEditor(me) && <><hr /><Link to="/admin"><I.Dashboard size={18} /> {isAdmin(me) ? 'Администрирование' : 'Управление новостями'}</Link></>}
          <hr />
          <button onClick={logout}><I.Logout size={18} /> Выйти</button>
        </div>
      )}
    </div>
  );
}

function RightRail() {
  const imp = useQuery<any>('rail:important', () => api.get('/api/news?important=1&per=4'), { stale: 60000 });
  const ev = useQuery<any[]>('rail:events', () => api.get('/api/events/upcoming'), { stale: 60000 });
  const res = useQuery<any[]>('resources', () => api.get('/api/resources'), { stale: 300000 });
  const birthdays = (ev.data || []).filter((e) => e.id < 0);
  const events = (ev.data || []).filter((e) => e.id > 0).slice(0, 6);
  const dm = (iso: string) => { const d = new Date(iso); return [d.getDate(), d.toLocaleDateString('ru', { month: 'short' }).replace('.', '')]; };
  return (
    <aside className="rail">
      <Banners />
      {imp.data?.items?.length > 0 && (
        <div className="card railC">
          <h4><I.Zap size={17} style={{ color: 'var(--warn)' }} /> Важное</h4>
          {imp.data.items.map((n: any) => (
            <Link key={n.id} to={`/news/${n.id}`} className="it">
              <Img className="thumbS" src={thumb(n.cover)} />
              <div style={{ minWidth: 0 }}><div className="small bold clamp2">{n.title}</div><div className="tiny faint">{fmtDate(n.published_at)}</div></div>
            </Link>
          ))}
        </div>
      )}
      <div className="card railC">
        <h4><I.Calendar size={17} style={{ color: 'var(--accent)' }} /> Ближайшие 5 дней</h4>
        {ev.data && events.length === 0 && <div className="small muted" style={{ padding: '0 18px 16px' }}>Нет запланированных событий</div>}
        {events.map((e) => { const [d, m] = dm(e.starts_at); return (
          <Link key={e.id + e.starts_at} to={`/calendar?event=${e.id}`} className="it">
            <div className="dateBox"><b>{d}</b><span>{m}</span></div>
            <div style={{ minWidth: 0 }}><div className="small bold clamp2">{e.title}</div><div className="tiny faint">{e.all_day ? 'Весь день' : new Date(e.starts_at).toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' })}{e.location ? ' · ' + e.location : ''}</div></div>
          </Link>
        ); })}
      </div>
      {birthdays.length > 0 && (
        <div className="card railC">
          <h4><I.Cake size={17} style={{ color: 'var(--danger)' }} /> Дни рождения</h4>
          {birthdays.slice(0, 6).map((e) => { const [d, m] = dm(e.starts_at); const nm = String(e.title).replace('День рождения: ', ''); const Tag: any = e.user_id ? Link : 'div'; return (
            <Tag key={e.id} {...(e.user_id ? { to: `/people/${e.user_id}` } : {})} className="it">
              <div className="dateBox" style={{ background: 'var(--danger-soft)', color: 'var(--danger)' }}><b>{d}</b><span>{m}</span></div>
              <div style={{ minWidth: 0 }}>
                <div className="small bold">{nm}</div>
                <div className="tiny faint clip">{[e.age ? plural(e.age, ['год', 'года', 'лет']) : '', e.description].filter(Boolean).join(' · ')}</div>
              </div>
            </Tag>
          ); })}
        </div>
      )}
      {res.data && res.data.length > 0 && (
        <div className="card railC" style={{ paddingBottom: 8 }}>
          <h4><I.Link size={17} /> Быстрые ссылки</h4>
          {res.data.slice(0, 5).map((r) => <a key={r.id} className="qlink" href={r.url} target="_blank" rel="noopener noreferrer"><I.External size={16} />{r.name}</a>)}
        </div>
      )}
    </aside>
  );
}

export function Shell({ children, rail, wide }: { children: React.ReactNode; rail?: boolean; wide?: boolean }) {
  const { path, search } = useLocation();
  const company = useStore((s) => s.company);
  const unreadChats = useStore((s) => s.unreadChats);
  const wsOnline = useStore((s) => s.wsOnline);
  const me = useStore((s) => s.me)!;
  const [menu, setMenu] = useState(false);
  useEffect(() => setMenu(false), [path]);
  useEffect(() => { trackPageview(path); }, [path]); // аналитика посещений разделов
  useEffect(() => resetPageview, []);

  // --- global realtime wiring (works identically whichever instance serves the socket)
  const chats = useQuery<any[]>('chats', () => api.get('/api/chats'), { stale: 20000 });
  useEffect(() => { if (chats.data) setState({ unreadChats: chats.data.reduce((a, c) => a + (c.unread || 0), 0) }); }, [chats.data]);
  useRealtime('presence', (d) => setState((s) => { const n = new Set(s.online); d.online ? n.add(d.user_id) : n.delete(d.user_id); return { online: n }; }));
  useRealtime('message', (d) => {
    invalidate('chats');
    const m = d.message;
    if (m.user_id !== me.id && !(location.pathname === '/messages' && new URLSearchParams(location.search).get('chat') === String(d.chat_id) && document.visibilityState === 'visible')) {
      toast({ title: m.author, body: m.body ? stripMd(m.body) : '📎 Вложение', link: `/messages?chat=${d.chat_id}`, kind: 'message' });
    }
  });
  const reqCnt = useQuery<{ inbox: number; rework: number }>('req:counts', () => api.get('/api/requests/counts'), { stale: 30000 });
  useRealtime('req', () => invalidate('req:'));
  useRealtime('chat', () => invalidate('chats'));
  useRealtime('read', (d) => d.user_id === me.id && invalidate('chats'));
  useRealtime('message.update', () => invalidate('chats'));
  useRealtime('news.new', (d) => {
    invalidate('news'); invalidate('rail:');
    if (d.author_id !== me.id) toast({ title: d.important ? '⚡ Важная новость' : 'Новая публикация', body: d.title, link: `/news/${d.id}`, kind: 'news' });
  });
  useRealtime('reconnected', () => { invalidate(() => true); api.get('/api/presence').then((r) => setState({ online: new Set<number>(r.online) })).catch(() => {}); });
  useEffect(() => { api.get('/api/presence').then((r) => setState({ online: new Set<number>(r.online) })).catch(() => {}); }, []);

  return (
    <>
      <header className="hdr">
        <div className="hdrIn">
          <button className="iconBtn menuBtn" onClick={() => setMenu(true)} aria-label="Меню"><I.Menu size={22} /></button>
          <Link to="/" className="logo">
            {company?.logo ? <img className="logoImg" src={company.logo} alt="" /> : <span className="logoMark"><I.Newspaper size={20} /></span>}
            <span className="lt">{company?.name?.replace(/[«»"]/g, '').replace(/^ООО\s*/, '') || 'CorpNet'}</span>
          </Link>
          <GlobalSearch />
          <div className="hdrSp" />
          {!wsOnline && <span className="badge warn hide-m" title="Переподключение…"><span className="wsDot off" /> offline</span>}
          <Link to="/messages" className="iconBtn" aria-label="Сообщения">
            <I.Message size={21} />
            {unreadChats > 0 && <span className="dot">{unreadChats > 99 ? '99+' : unreadChats}</span>}
          </Link>
          <Notifications />
          <ProfileMenu />
        </div>
      </header>
      <div className={cx('scrim', menu && 'open')} onClick={() => setMenu(false)} />
      <div className={cx('layout', rail && 'rail', wide && 'wide')}>
        {!wide && (
          <aside className={cx('side', menu && 'open')}>
            <nav className="nav" aria-label="Основная навигация">
              {NAV.map((n) => <NavLink key={n.to} n={n} path={path} cnt={n.badge === 'chats' ? unreadChats : 0} />)}
              <div className="navH">Люди</div>
              {NAV2.map((n) => <NavLink key={n.to} n={n} path={path} />)}
              <NavLink n={{ to: '/learning', label: 'Обучение', icon: I.GradCap }} path={path} />
              <NavLink n={{ to: '/requests', label: 'Заявки', icon: ReqIcon }} path={path} cnt={(reqCnt.data?.inbox || 0) + (reqCnt.data?.rework || 0)} />
              <div className="navH">Материалы</div>
              {NAV3.map((n) => <NavLink key={n.to} n={n} path={path} />)}
              {isEditor(me) && <><div className="navH">Управление</div><NavLink n={{ to: '/admin', label: isAdmin(me) ? 'Админ-панель' : 'Редактор', icon: I.Dashboard }} path={path} /></>}
            </nav>
            <div className="sideFoot">© {new Date().getFullYear()} {company?.name || 'CorpNet'}</div>
          </aside>
        )}
        <main style={{ minWidth: 0 }}>{children}</main>
        {rail && <RightRail />}
      </div>
      <Toasts />
    </>
  );
}

function NavLink({ n, path, cnt }: { n: { to: string; label: string; icon: any; match?: (p: string) => boolean }; path: string; cnt?: number }) {
  const on = n.match ? n.match(path) : n.to === '/' ? path === '/' : path === n.to || path.startsWith(n.to + '/');
  const Ic = n.icon;
  return (
    <Link to={n.to} className={cx('navA', on && 'on')} aria-current={on ? 'page' : undefined}>
      <Ic size={19} />{n.label}{cnt ? <span className="cnt">{cnt}</span> : null}
    </Link>
  );
}
