// Production build (and dev server with --watch) powered by esbuild.
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import http from 'node:http';
import net from 'node:net';
import crypto from 'node:crypto';

const watch = process.argv.includes('--watch');
const dist = process.env.DIST_DIR || path.join('..', 'backend', 'internal', 'web', 'dist'); // собранный фронтенд встраивается в Go-бинарник

// pdf.js (просмотр PDF): воркер — отдельный файл с хэшем в имени (тот же origin), cmaps/шрифты/wasm — dist/pdfjs/ (грузятся по требованию)
const pdfRoot = 'node_modules/pdfjs-dist';
const pdfWorkerFile = path.join(pdfRoot, 'build/pdf.worker.min.mjs');
const pdfWorkerName = fs.existsSync(pdfWorkerFile) ? `pdf.worker-${crypto.createHash('sha1').update(fs.readFileSync(pdfWorkerFile)).update(fs.readFileSync('src/lib/polyfill-map.ts')).digest('hex').slice(0, 8)}.js` : '';
function emitPdfjs() {
  if (!pdfWorkerName) return;
  // воркеру нужен тот же полифил Map.getOrInsertComputed (см. src/lib/polyfill-map.ts)
  const poly = fs.readFileSync('src/lib/polyfill-map.ts', 'utf8').match(/MAP_POLYFILL = `([^`]*)`/)[1].replace(/\\n/g, '\n');
  fs.writeFileSync(path.join(dist, 'assets', pdfWorkerName), poly + fs.readFileSync(pdfWorkerFile, 'utf8'));
  for (const d of ['cmaps', 'standard_fonts', 'wasm', 'iccs']) fs.cpSync(path.join(pdfRoot, d), path.join(dist, 'pdfjs', d), { recursive: true });
}

const options = {
  entryPoints: ['src/main.tsx'],
  bundle: true,
  splitting: true,
  format: 'esm',
  outdir: path.join(dist, 'assets'),
  entryNames: '[name]-[hash]',
  chunkNames: 'chunks/[name]-[hash]',
  assetNames: '[name]-[hash]',
  minify: !watch,
  sourcemap: watch,
  target: 'es2022',
  jsx: 'automatic',
  metafile: true,
  legalComments: 'none',
  logLevel: 'info',
  define: { 'process.env.NODE_ENV': watch ? '"development"' : '"production"', __PDF_WORKER__: JSON.stringify('/assets/' + pdfWorkerName) },
};

function emitHtml(meta) {
  let js = '', css = '';
  const preload = [];
  for (const [file, info] of Object.entries(meta.outputs)) {
    const url = '/' + path.relative(dist, file).split(path.sep).join('/');
    if (info.entryPoint === 'src/main.tsx') js = url;
    if (file.endsWith('.css') && path.basename(file).startsWith('main-')) css = url;
  }
  // chunks statically imported by the entry are preloaded; lazy ones are fetched on navigation
  const entry = Object.entries(meta.outputs).find(([, i]) => i.entryPoint === 'src/main.tsx');
  for (const imp of entry[1].imports) {
    if (imp.kind === 'import-statement') preload.push('/' + path.relative(dist, imp.path).split(path.sep).join('/'));
  }
  const tags = [
    css && `<link rel="stylesheet" href="${css}">`,
    ...preload.map((p) => `<link rel="modulepreload" href="${p}">`),
    `<script type="module" src="${js}"></script>`,
  ].filter(Boolean).join('\n');
  fs.writeFileSync(path.join(dist, 'index.html'), fs.readFileSync('index.html', 'utf8').replace('<!--ASSETS-->', tags));
}

function copyPublic() {
  if (!fs.existsSync('public')) return;
  for (const f of fs.readdirSync('public')) fs.copyFileSync(path.join('public', f), path.join(dist, f));
}

function precompress() {
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]));
  let n = 0;
  for (const f of walk(dist)) {
    if (!/\.(js|css|html|svg|json|txt|map)$/.test(f)) continue;
    fs.writeFileSync(f + '.gz', zlib.gzipSync(fs.readFileSync(f), { level: 9 }));
    n++;
  }
  console.log(`precompressed ${n} files (.gz — Go-сервер отдаёт их предсжатыми)`);
}

fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(path.join(dist, 'assets'), { recursive: true });
emitPdfjs();

if (!watch) {
  const res = await esbuild.build(options);
  emitHtml(res.metafile);
  copyPublic();
  precompress();
  const sizes = Object.entries(res.metafile.outputs).filter(([f]) => /\.(js|css)$/.test(f)).map(([f, i]) => [f.replace(dist + '/', ''), i.bytes]);
  sizes.sort((a, b) => b[1] - a[1]);
  console.log(sizes.slice(0, 12).map(([f, b]) => `${(b / 1024).toFixed(1).padStart(7)} KB  ${f}`).join('\n'));
} else {
  // ---- dev: rebuild on change + serve dist + proxy API to the Go backend
  const backend = new URL(process.env.BACKEND_URL || 'http://127.0.0.1:8080');
  const port = Number(process.env.PORT || 5173);
  const ctx = await esbuild.context({
    ...options,
    plugins: [{ name: 'html', setup(b) { b.onEnd((r) => { if (r.metafile) { emitHtml(r.metafile); copyPublic(); } }); } }],
  });
  await ctx.watch();
  const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.map': 'application/json' };
  const proxied = (u) => /^\/(api|media|files|healthz)(\/|$|\?)/.test(u);
  const server = http.createServer((req, res) => {
    if (proxied(req.url)) {
      const p = http.request({ host: backend.hostname, port: backend.port, path: req.url, method: req.method, headers: req.headers }, (r) => {
        res.writeHead(r.statusCode, r.headers);
        r.pipe(res);
      });
      p.on('error', () => { res.writeHead(502); res.end('backend unavailable'); });
      return req.pipe(p);
    }
    let f = path.join(dist, decodeURIComponent(req.url.split('?')[0]));
    if (!f.startsWith(dist) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) f = path.join(dist, 'index.html');
    res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    fs.createReadStream(f).pipe(res);
  });
  server.on('upgrade', (req, socket, head) => {
    const t = net.connect(backend.port, backend.hostname, () => {
      t.write(`${req.method} ${req.url} HTTP/1.1\r\n` + Object.entries(req.headers).map(([k, v]) => `${k}: ${v}`).join('\r\n') + '\r\n\r\n');
      t.write(head);
      socket.pipe(t);
      t.pipe(socket);
    });
    t.on('error', () => socket.destroy());
    socket.on('error', () => t.destroy());
  });
  server.listen(port, () => console.log(`dev server: http://localhost:${port}  (backend: ${backend.origin})`));
}
