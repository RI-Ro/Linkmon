package main

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	_ "time/tzdata"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"

	"corpnet/internal/migrate"
	"corpnet/internal/server"
)

func main() {
	loadDotEnv(".env") // необязательный файл KEY=VALUE в текущем каталоге; реальные переменные окружения приоритетнее
	cfg := server.LoadConfig()
	if len(os.Args) > 1 && os.Args[1] == "healthcheck" { // used by Docker HEALTHCHECK
		addr := cfg.Addr
		if addr[0] == ':' {
			addr = "127.0.0.1" + addr
		}
		cl := http.Client{Timeout: 3 * time.Second}
		resp, err := cl.Get("http://" + addr + "/healthz")
		if err != nil || resp.StatusCode != 200 {
			os.Exit(1)
		}
		return
	}

	log := server.NewLogger(os.Stdout, cfg) // JSON: ts, level, service, instance, dc (+ request_id в запросах)
	slog.SetDefault(log)
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	if err := run(ctx, cfg, log); err != nil {
		log.Error("fatal", "err", err)
		os.Exit(1)
	}
}

func run(ctx context.Context, cfg server.Config, log *slog.Logger) error {
	pcfg, err := pgxpool.ParseConfig(cfg.DatabaseURL)
	if err != nil {
		return fmt.Errorf("DATABASE_URL: %w", err)
	}
	pcfg.MaxConns = int32(cfg.PGPoolMax)
	pcfg.ConnConfig.Tracer = server.NewPGTracer("primary", cfg, log)                    // время SQL на запрос, /metrics
	pcfg.ConnConfig.RuntimeParams["application_name"] = "corpnet-app-" + cfg.InstanceID // виден в логах и pg_stat_activity
	pcfg.MinConns = 2
	pcfg.MaxConnLifetime = time.Hour
	pcfg.MaxConnIdleTime = 10 * time.Minute

	var db *pgxpool.Pool
	for i := 0; ; i++ { // wait for Postgres to come up
		db, err = pgxpool.NewWithConfig(ctx, pcfg)
		if err == nil {
			if err = db.Ping(ctx); err == nil {
				break
			}
			db.Close()
		}
		if i >= 60 || ctx.Err() != nil {
			return fmt.Errorf("postgres: %w", err)
		}
		log.Info("waiting for postgres", "err", err)
		time.Sleep(time.Second)
	}
	defer db.Close()

	// Локальная read-реплика (необязательно): тяжёлое чтение — ленты, поиск, списки — идёт на неё.
	var ro *pgxpool.Pool
	if cfg.ReplicaURL != "" {
		rcfg, err := pgxpool.ParseConfig(cfg.ReplicaURL)
		if err != nil {
			return fmt.Errorf("DATABASE_REPLICA_URL: %w", err)
		}
		rcfg.MaxConns = int32(cfg.PGPoolMax)
		rcfg.ConnConfig.Tracer = server.NewPGTracer("replica", cfg, log)
		rcfg.ConnConfig.RuntimeParams["application_name"] = "corpnet-app-ro-" + cfg.InstanceID
		rcfg.MinConns = 1
		rcfg.MaxConnLifetime = time.Hour
		rcfg.MaxConnIdleTime = 10 * time.Minute
		if ro, err = pgxpool.NewWithConfig(ctx, rcfg); err != nil {
			return fmt.Errorf("replica: %w", err)
		}
		defer ro.Close()
		log.Info("read replica enabled")
	}

	ropt, err := redis.ParseURL(cfg.RedisURL)
	if err != nil {
		return fmt.Errorf("REDIS_URL: %w", err)
	}
	ropt.PoolSize = 64
	rdb := redis.NewClient(ropt)
	defer rdb.Close()
	for i := 0; ; i++ {
		if err = rdb.Ping(ctx).Err(); err == nil {
			break
		}
		if i >= 60 || ctx.Err() != nil {
			return fmt.Errorf("redis: %w", err)
		}
		log.Info("waiting for redis", "err", err)
		time.Sleep(time.Second)
	}

	if err := migrate.Run(ctx, db, log); err != nil {
		return err
	}
	srv, err := server.New(cfg, db, ro, rdb, log)
	if err != nil {
		return err
	}
	if err := srv.Seed(ctx); err != nil {
		return fmt.Errorf("seed: %w", err)
	}
	srv.Run(ctx)

	hs := &http.Server{
		Addr:              cfg.Addr,
		Handler:           srv.Handler(),
		ReadHeaderTimeout: 10 * time.Second,
		IdleTimeout:       120 * time.Second,
	}
	errc := make(chan error, 1)
	go func() { errc <- hs.ListenAndServe() }()
	log.Info("listening", "addr", cfg.Addr, "instance", cfg.InstanceID)
	select {
	case err := <-errc:
		if !errors.Is(err, http.ErrServerClosed) {
			return err
		}
	case <-ctx.Done():
		sctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		return hs.Shutdown(sctx)
	}
	return nil
}

// loadDotEnv читает простой .env (KEY=VALUE, # комментарии, значения можно брать в кавычки) и не перезаписывает уже заданные переменные.
func loadDotEnv(file string) {
	b, err := os.ReadFile(file)
	if err != nil {
		return
	}
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(line), "export "))
		if line == "" || line[0] == '#' {
			continue
		}
		k, v, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		k, v = strings.TrimSpace(k), strings.TrimSpace(v)
		if len(v) >= 2 && (v[0] == '"' && v[len(v)-1] == '"' || v[0] == '\'' && v[len(v)-1] == '\'') {
			v = v[1 : len(v)-1]
		} else if i := strings.Index(v, " #"); i >= 0 {
			v = strings.TrimSpace(v[:i])
		}
		if _, set := os.LookupEnv(k); !set && k != "" {
			os.Setenv(k, v)
		}
	}
}
