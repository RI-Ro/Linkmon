// Package krb проверяет SPNEGO/Kerberos-билеты (HTTP Negotiate) и ничего не знает ни о БД, ни о HTTP-сервере портала.
//
// Криптография и разбор AP-REQ — в github.com/jcmturner/gokrb5/v8: расшифровка билета ключом из keytab, проверка
// аутентификатора, допустимого смещения часов и повтора (replay-кэш внутри gokrb5). Сам пакет отвечает за:
//   - разбор заголовка «Authorization: Negotiate <base64>»;
//   - перезагрузку keytab при его замене (ротация пароля сервисной учётки);
//   - проверку realm клиента;
//   - сопоставление principal → логин портала (MapLogin) — чистая функция;
//   - диагностику конфигурации для админки (Inspect).
//
// NTLM-токены (в том числе обёрнутые в SPNEGO) намеренно не поддерживаются: такой вход закончится ErrBadToken/ErrRejected,
// и портал откатится на форму пароля.
package krb

import (
	"context"
	"encoding/base64"
	"errors"
	"fmt"
	"net"
	"os"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/jcmturner/gofork/encoding/asn1"
	"github.com/jcmturner/gokrb5/v8/config"
	"github.com/jcmturner/gokrb5/v8/credentials"
	"github.com/jcmturner/gokrb5/v8/keytab"
	"github.com/jcmturner/gokrb5/v8/service"
	"github.com/jcmturner/gokrb5/v8/spnego"
	"github.com/jcmturner/gokrb5/v8/types"
)

// Ошибки верхнего уровня. Подробности (для журнала) завёрнуты через %w; клиенту их не показываем.
var (
	ErrNoToken  = errors.New("krb: нет заголовка Authorization: Negotiate")
	ErrBadToken = errors.New("krb: некорректный токен")
	ErrRejected = errors.New("krb: билет отклонён")
	ErrRealm    = errors.New("krb: realm клиента не разрешён")
)

// Config — параметры проверки билетов.
type Config struct {
	Keytab           string        // путь к keytab с ключом сервисной учётки
	ServicePrincipal string        // HTTP/portal.corp.local (допустим суффикс @REALM)
	Realms           []string      // разрешённые realm клиентов (регистр не важен); пусто — realm из keytab для SPN
	ConfPath         string        // krb5.conf (необязателен: для проверки билета не нужен, используется в диагностике)
	ClockSkew        time.Duration // допустимое смещение часов, по умолчанию 5 минут
}

// Identity — подтверждённая личность клиента.
type Identity struct {
	User     string    // имя клиента без realm, как в билете (ivanov)
	Realm    string    // realm клиента, как в билете (CORP.LOCAL)
	AuthTime time.Time // момент проверки
}

// Principal возвращает user@REALM.
func (i *Identity) Principal() string { return i.User + "@" + i.Realm }

// Validator проверяет токены. Безопасен для конкурентного использования.
type Validator struct {
	cfg Config

	mu    sync.RWMutex
	kt    *keytab.Keytab
	mtime time.Time
	size  int64
	chk   time.Time // последняя проверка mtime
}

// New загружает keytab. Ошибка — keytab нет/нечитаем/пуст/в нём нет ключа для SPN.
func New(cfg Config) (*Validator, error) {
	if cfg.ClockSkew <= 0 {
		cfg.ClockSkew = 5 * time.Minute
	}
	cfg.ServicePrincipal = strings.TrimSpace(cfg.ServicePrincipal)
	if cfg.ServicePrincipal == "" {
		return nil, errors.New("не задан сервисный принципал (KRB5_SERVICE_PRINCIPAL, например HTTP/portal.corp.local)")
	}
	v := &Validator{cfg: cfg}
	if err := v.reload(); err != nil {
		return nil, err
	}
	if len(cfg.Realms) == 0 {
		v.cfg.Realms = v.keytabRealms()
	}
	return v, nil
}

func (v *Validator) reload() error {
	st, err := os.Stat(v.cfg.Keytab)
	if err != nil {
		return fmt.Errorf("keytab недоступен: %w", err)
	}
	kt, err := keytab.Load(v.cfg.Keytab)
	if err != nil {
		return fmt.Errorf("keytab не читается: %w", err)
	}
	if len(kt.Entries) == 0 {
		return errors.New("keytab пуст")
	}
	spn, _ := splitSPN(v.cfg.ServicePrincipal)
	found := false
	for _, e := range kt.Entries {
		if strings.EqualFold(strings.Join(e.Principal.Components, "/"), spn) {
			found = true
			break
		}
	}
	if !found {
		return fmt.Errorf("в keytab нет ключа для %s", spn)
	}
	v.mu.Lock()
	v.kt, v.mtime, v.size, v.chk = kt, st.ModTime(), st.Size(), time.Now()
	v.mu.Unlock()
	return nil
}

// refresh подхватывает заменённый keytab (проверка mtime не чаще раза в 15 секунд). Ошибка перезагрузки не критична:
// остаётся прежний ключ.
func (v *Validator) refresh() {
	v.mu.RLock()
	recent := time.Since(v.chk) < 15*time.Second
	v.mu.RUnlock()
	if recent {
		return
	}
	v.mu.Lock()
	v.chk = time.Now()
	v.mu.Unlock()
	if st, err := os.Stat(v.cfg.Keytab); err == nil && (!st.ModTime().Equal(v.mtime) || st.Size() != v.size) {
		_ = v.reload()
	}
}

func (v *Validator) keytabRealms() []string {
	v.mu.RLock()
	defer v.mu.RUnlock()
	spn, realm := splitSPN(v.cfg.ServicePrincipal)
	seen := map[string]bool{}
	var out []string
	if realm != "" {
		out = append(out, realm)
		seen[strings.ToUpper(realm)] = true
	}
	for _, e := range v.kt.Entries {
		if strings.EqualFold(strings.Join(e.Principal.Components, "/"), spn) && !seen[strings.ToUpper(e.Principal.Realm)] {
			seen[strings.ToUpper(e.Principal.Realm)] = true
			out = append(out, e.Principal.Realm)
		}
	}
	return out
}

// splitSPN отделяет необязательный @REALM от принципала.
func splitSPN(p string) (name, realm string) {
	if i := strings.LastIndex(p, "@"); i > 0 {
		return p[:i], p[i+1:]
	}
	return p, ""
}

// ParseHeader достаёт сырой токен из значения заголовка Authorization.
// Возвращает ErrNoToken, если схема не Negotiate, и ErrBadToken при мусоре вместо base64.
func ParseHeader(h string) ([]byte, error) {
	h = strings.TrimSpace(h)
	if len(h) < 9 || !strings.EqualFold(h[:9], "negotiate") || (len(h) > 9 && h[9] != ' ' && h[9] != '\t') {
		return nil, ErrNoToken
	}
	s := strings.TrimSpace(h[9:])
	if s == "" {
		return nil, ErrNoToken // «Negotiate» без токена — клиент просит начать обмен
	}
	if len(s) > 64<<10 {
		return nil, fmt.Errorf("%w: слишком длинный", ErrBadToken)
	}
	b, err := base64.StdEncoding.DecodeString(s)
	if err != nil || len(b) < 2 {
		return nil, fmt.Errorf("%w: не base64", ErrBadToken)
	}
	return b, nil
}

// Validate проверяет SPNEGO-токен (или «голый» KRB5-токен). clientIP нужен только для билетов с привязкой к адресу.
func (v *Validator) Validate(token []byte, clientIP string) (id *Identity, err error) {
	defer func() { // разбор ASN.1 недоверенных данных: любая паника библиотеки — это просто плохой токен
		if r := recover(); r != nil {
			id, err = nil, fmt.Errorf("%w: %v", ErrBadToken, r)
		}
	}()
	v.refresh()
	v.mu.RLock()
	kt := v.kt
	v.mu.RUnlock()

	opts := []func(*service.Settings){
		service.DecodePAC(false), // группы/SID из PAC не нужны; меньше поверхность разбора и сбоев на больших PAC
		service.MaxClockSkew(v.cfg.ClockSkew),
		service.KeytabPrincipal(v.cfg.ServicePrincipal),
	}
	if ip := parseIP(clientIP); ip != nil {
		opts = append(opts, service.ClientAddress(types.HostAddressFromNetIP(ip)))
	}

	var st spnego.SPNEGOToken
	if err := st.Unmarshal(token); err != nil {
		var k5 spnego.KRB5Token
		if k5.Unmarshal(token) != nil {
			return nil, fmt.Errorf("%w: %v", ErrBadToken, err)
		}
		st.Init = true
		st.NegTokenInit = spnego.NegTokenInit{MechTypes: []asn1.ObjectIdentifier{k5.OID}, MechTokenBytes: token}
	}
	ok, ctx, status := spnego.SPNEGOService(kt, opts...).AcceptSecContext(&st)
	if !ok {
		return nil, fmt.Errorf("%w: %s", ErrRejected, status.Message)
	}
	creds := credsFrom(ctx)
	if creds == nil || creds.UserName() == "" {
		return nil, fmt.Errorf("%w: в контексте нет учётных данных", ErrRejected)
	}
	realm := creds.Domain()
	if !v.realmAllowed(realm) {
		return nil, fmt.Errorf("%w: %s", ErrRealm, realm)
	}
	return &Identity{User: creds.UserName(), Realm: realm, AuthTime: time.Now()}, nil
}

func (v *Validator) realmAllowed(r string) bool {
	if len(v.cfg.Realms) == 0 {
		return true
	}
	for _, a := range v.cfg.Realms {
		if strings.EqualFold(a, r) {
			return true
		}
	}
	return false
}

// ctxCredentials — ключ, под которым gokrb5 кладёт credentials в контекст SPNEGO (константа не экспортируется).
const ctxCredentials = "github.com/jcmturner/gokrb5/v8/ctxCredentials"

func credsFrom(ctx context.Context) *credentials.Credentials {
	if ctx == nil {
		return nil
	}
	c, _ := ctx.Value(ctxCredentials).(*credentials.Credentials)
	return c
}

// ---------------------------------------------------------------- сопоставление principal → логин

// Режимы KRB5_USER_MAP.
const (
	MapSAM  = "sam"  // ivanov@CORP.LOCAL → «ivanov» (sAMAccountName)
	MapUPN  = "upn"  // ivanov@CORP.LOCAL → «ivanov@corp.local» (логин/почта в портале записаны как UPN)
	MapAuto = "auto" // сначала UPN (логин или почта), затем sAMAccountName
)

// NormalizeMap приводит значение настройки к известному режиму (по умолчанию sam).
func NormalizeMap(m string) string {
	switch strings.ToLower(strings.TrimSpace(m)) {
	case MapUPN:
		return MapUPN
	case MapAuto:
		return MapAuto
	}
	return MapSAM
}

// MapLogin возвращает кандидатов логина портала (в нижнем регистре, по порядку проверки). Пустой результат — нельзя
// сопоставить. Имена вида «host/…» (машинные/сервисные принципалы) и DOMAIN\user не принимаются.
func MapLogin(user, realm, mode string) []string {
	user = strings.ToLower(strings.TrimSpace(user))
	realm = strings.ToLower(strings.TrimSpace(realm))
	if user == "" || strings.ContainsAny(user, "/\\") || strings.HasSuffix(user, "$") {
		return nil
	}
	if i := strings.Index(user, "@"); i > 0 { // UPN-имя в компоненте principal (enterprise name type)
		user = user[:i]
	}
	upn := user
	if realm != "" {
		upn = user + "@" + realm
	}
	switch NormalizeMap(mode) {
	case MapUPN:
		return []string{upn}
	case MapAuto:
		if upn != user {
			return []string{upn, user}
		}
	}
	return []string{user}
}

// ---------------------------------------------------------------- диагностика

// Report — результат проверки конфигурации для админки (без секретов).
type Report struct {
	KeytabPath    string        `json:"keytab_path"`
	KeytabOK      bool          `json:"keytab_ok"`
	KeytabEntries []KeytabEntry `json:"keytab_entries"`
	Principal     string        `json:"principal"`
	PrincipalOK   bool          `json:"principal_ok"`
	Realms        []string      `json:"realms"`
	ConfPath      string        `json:"conf_path"`
	ConfOK        *bool         `json:"conf_ok"` // nil — krb5.conf не задан
	DefaultRealm  string        `json:"default_realm,omitempty"`
	Problems      []string      `json:"problems"`
	Warnings      []string      `json:"warnings"`
}

// KeytabEntry — запись keytab без ключа.
type KeytabEntry struct {
	Principal string `json:"principal"`
	KVNO      uint32 `json:"kvno"`
	EType     int32  `json:"etype"`
	EName     string `json:"etype_name"`
	Time      string `json:"time"`
}

var etypeNames = map[int32]string{17: "aes128-cts-hmac-sha1-96", 18: "aes256-cts-hmac-sha1-96", 19: "aes128-cts-hmac-sha256-128",
	20: "aes256-cts-hmac-sha384-192", 23: "rc4-hmac", 3: "des-cbc-md5", 1: "des-cbc-crc", 2: "des-cbc-md4"}

// Inspect проверяет конфигурацию без обращения к сети (KDC не нужен).
func Inspect(cfg Config) *Report {
	r := &Report{KeytabPath: cfg.Keytab, Principal: cfg.ServicePrincipal, ConfPath: cfg.ConfPath, Realms: cfg.Realms,
		KeytabEntries: []KeytabEntry{}, Problems: []string{}, Warnings: []string{}}
	if r.Realms == nil {
		r.Realms = []string{}
	}
	if cfg.ServicePrincipal == "" {
		r.Problems = append(r.Problems, "Не задан сервисный принципал (KRB5_SERVICE_PRINCIPAL)")
	} else if !strings.Contains(cfg.ServicePrincipal, "/") {
		r.Problems = append(r.Problems, "Принципал должен иметь вид HTTP/имя-сервера.домен (SPN службы)")
	} else if !strings.HasPrefix(strings.ToUpper(cfg.ServicePrincipal), "HTTP/") {
		r.Warnings = append(r.Warnings, "Браузеры запрашивают билет на службу HTTP/…; принципал с другим префиксом не будет работать")
	}
	if cfg.Keytab == "" {
		r.Problems = append(r.Problems, "Не задан путь к keytab (KRB5_KEYTAB)")
	} else if st, err := os.Stat(cfg.Keytab); err != nil {
		r.Problems = append(r.Problems, "Keytab не найден или недоступен: "+cfg.Keytab+" (проверьте монтирование тома и права)")
	} else if st.IsDir() {
		r.Problems = append(r.Problems, "Путь к keytab указывает на каталог")
	} else if kt, err := keytab.Load(cfg.Keytab); err != nil {
		r.Problems = append(r.Problems, "Keytab не читается: "+err.Error())
	} else {
		r.KeytabOK = true
		spn, spnRealm := splitSPN(cfg.ServicePrincipal)
		realms := map[string]bool{}
		for _, e := range kt.Entries {
			name := strings.Join(e.Principal.Components, "/")
			kv := e.KVNO
			if kv == 0 {
				kv = uint32(e.KVNO8)
			}
			en := etypeNames[e.Key.KeyType]
			if en == "" {
				en = fmt.Sprint(e.Key.KeyType)
			}
			r.KeytabEntries = append(r.KeytabEntries, KeytabEntry{Principal: name + "@" + e.Principal.Realm, KVNO: kv, EType: e.Key.KeyType, EName: en,
				Time: e.Timestamp.UTC().Format(time.RFC3339)})
			if strings.EqualFold(name, spn) && (spnRealm == "" || strings.EqualFold(spnRealm, e.Principal.Realm)) {
				r.PrincipalOK = true
				realms[e.Principal.Realm] = true
			}
		}
		sort.Slice(r.KeytabEntries, func(i, j int) bool { return r.KeytabEntries[i].Principal < r.KeytabEntries[j].Principal })
		if len(kt.Entries) == 0 {
			r.Problems = append(r.Problems, "Keytab пуст")
		} else if cfg.ServicePrincipal != "" && !r.PrincipalOK {
			r.Problems = append(r.Problems, "В keytab нет ключа для "+cfg.ServicePrincipal+" — проверьте регистр и FQDN (SPN должен совпадать с адресом, по которому открывают портал)")
		}
		if len(r.Realms) == 0 {
			for k := range realms {
				r.Realms = append(r.Realms, k)
			}
			sort.Strings(r.Realms)
		}
		hasAES := false
		for _, e := range kt.Entries {
			if e.Key.KeyType == 17 || e.Key.KeyType == 18 {
				hasAES = true
			}
		}
		if r.PrincipalOK && !hasAES {
			r.Warnings = append(r.Warnings, "В keytab нет AES-ключей (только RC4/DES): современные домены выдают AES-билеты — пересоздайте keytab с -crypto AES256-SHA1")
		}
	}
	if cfg.ConfPath != "" {
		ok := false
		if c, err := config.Load(cfg.ConfPath); err != nil {
			r.Problems = append(r.Problems, "krb5.conf не читается: "+err.Error())
		} else {
			ok = true
			r.DefaultRealm = c.LibDefaults.DefaultRealm
		}
		r.ConfOK = &ok
	}
	return r
}

// Ok — конфигурация пригодна для приёма билетов.
func (r *Report) Ok() bool { return len(r.Problems) == 0 && r.KeytabOK && r.PrincipalOK }

// Reload принудительно перечитывает keytab (для кнопки «Проверить конфигурацию» после замены файла).
func (v *Validator) Reload() error { return v.reload() }

func parseIP(s string) net.IP {
	if h, _, err := net.SplitHostPort(s); err == nil {
		s = h
	}
	return net.ParseIP(strings.TrimSpace(s))
}
