package krb

import (
	"encoding/base64"
	"errors"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/jcmturner/gofork/encoding/asn1"
	"github.com/jcmturner/gokrb5/v8/client"
	"github.com/jcmturner/gokrb5/v8/config"
	"github.com/jcmturner/gokrb5/v8/iana/etypeID"
	"github.com/jcmturner/gokrb5/v8/iana/flags"
	"github.com/jcmturner/gokrb5/v8/iana/nametype"
	"github.com/jcmturner/gokrb5/v8/keytab"
	"github.com/jcmturner/gokrb5/v8/messages"
	"github.com/jcmturner/gokrb5/v8/spnego"
	"github.com/jcmturner/gokrb5/v8/types"
)

const (
	testSPN   = "HTTP/portal.corp.local"
	testRealm = "CORP.LOCAL"
)

func writeKeytab(t *testing.T, dir, name, spn, realm, pass string) (string, *keytab.Keytab) {
	t.Helper()
	kt := keytab.New()
	for _, et := range []int32{etypeID.AES256_CTS_HMAC_SHA1_96, etypeID.AES128_CTS_HMAC_SHA1_96} {
		if err := kt.AddEntry(spn, realm, pass, time.Now(), 3, et); err != nil {
			t.Fatal(err)
		}
	}
	b, err := kt.Marshal()
	if err != nil {
		t.Fatal(err)
	}
	p := filepath.Join(dir, name)
	if err := os.WriteFile(p, b, 0o600); err != nil {
		t.Fatal(err)
	}
	return p, kt
}

// mkToken собирает настоящий SPNEGO NegTokenInit с AP-REQ: билет зашифрован ключом из kt (как это делает KDC).
func mkToken(t *testing.T, kt *keytab.Keytab, sname, user, urealm string, start, end time.Time) []byte {
	t.Helper()
	now := time.Now().UTC()
	var fl asn1.BitString
	types.SetFlag(&fl, flags.Forwardable)
	tkt, key, err := messages.NewTicket(types.NewPrincipalName(nametype.KRB_NT_PRINCIPAL, user), urealm,
		types.NewPrincipalName(nametype.KRB_NT_SRV_INST, sname), testRealm, fl, kt, etypeID.AES256_CTS_HMAC_SHA1_96, 3, now, start, end, end)
	if err != nil {
		t.Fatal(err)
	}
	cl := client.NewWithPassword(user, urealm, "x", config.New())
	nt, err := spnego.NewNegTokenInitKRB5(cl, tkt, key)
	if err != nil {
		t.Fatal(err)
	}
	st := spnego.SPNEGOToken{Init: true, NegTokenInit: nt}
	b, err := st.Marshal()
	if err != nil {
		t.Fatal(err)
	}
	return b
}

func valid() (time.Time, time.Time) {
	n := time.Now().UTC()
	return n.Add(-time.Minute), n.Add(8 * time.Hour)
}

func TestValidate(t *testing.T) {
	dir := t.TempDir()
	path, kt := writeKeytab(t, dir, "krb5.keytab", testSPN, testRealm, "svc-pass")
	v, err := New(Config{Keytab: path, ServicePrincipal: testSPN, ClockSkew: 5 * time.Minute})
	if err != nil {
		t.Fatal(err)
	}
	s, e := valid()

	// 1. нормальный билет
	tok := mkToken(t, kt, "HTTP/portal.corp.local", "ivanov", testRealm, s, e)
	id, err := v.Validate(tok, "10.0.0.5")
	if err != nil || id.User != "ivanov" || id.Realm != testRealm || id.Principal() != "ivanov@"+testRealm {
		t.Fatalf("valid ticket: %+v %v", id, err)
	}
	// 2. тот же токен ещё раз — replay
	if _, err := v.Validate(tok, "10.0.0.5"); !errors.Is(err, ErrRejected) {
		t.Fatalf("replay must be rejected, got %v", err)
	}
	// 3. билет, выданный на псевдоним SPN (клиент просил HTTP/portal), но зашифрованный тем же ключом: принимаем (override по SPN)
	if _, err := v.Validate(mkToken(t, kt, "HTTP/portal.corp.local", "petrov", testRealm, s, e), ""); err != nil {
		t.Fatalf("second user: %v", err)
	}
	// 4. чужой ключ (другой пароль сервисной учётки / устаревший kvno)
	_, other := writeKeytab(t, dir, "other.keytab", testSPN, testRealm, "another-pass")
	if _, err := v.Validate(mkToken(t, other, "HTTP/portal.corp.local", "sidorov", testRealm, s, e), ""); !errors.Is(err, ErrRejected) {
		t.Fatalf("wrong key: %v", err)
	}
	// 5. билет ещё не действует / истёк
	n := time.Now().UTC()
	if _, err := v.Validate(mkToken(t, kt, testSPN, "a1", testRealm, n.Add(time.Hour), n.Add(2*time.Hour)), ""); !errors.Is(err, ErrRejected) {
		t.Fatalf("future ticket: %v", err)
	}
	if _, err := v.Validate(mkToken(t, kt, testSPN, "a2", testRealm, n.Add(-3*time.Hour), n.Add(-time.Hour)), ""); !errors.Is(err, ErrRejected) {
		t.Fatalf("expired ticket: %v", err)
	}
	// 6. чужой realm клиента
	if _, err := v.Validate(mkToken(t, kt, testSPN, "evil", "OTHER.LOCAL", s, e), ""); !errors.Is(err, ErrRealm) {
		t.Fatalf("foreign realm: %v", err)
	}
	// 7. мусор / NTLM / обрезанный токен
	for name, b := range map[string][]byte{
		"garbage": []byte("hello world, not asn1"),
		"ntlm":    []byte("NTLMSSP\x00\x01\x00\x00\x00\x07\x82\x08\xa2"),
		"empty":   {},
		"trunc":   tok[:len(tok)/2],
		"zeros":   make([]byte, 64),
	} {
		if _, err := v.Validate(b, ""); err == nil || (!errors.Is(err, ErrBadToken) && !errors.Is(err, ErrRejected)) {
			t.Fatalf("%s: expected rejection, got %v", name, err)
		}
	}
}

func TestKeytabReloadAndErrors(t *testing.T) {
	dir := t.TempDir()
	if _, err := New(Config{Keytab: filepath.Join(dir, "none"), ServicePrincipal: testSPN}); err == nil {
		t.Fatal("missing keytab must fail")
	}
	path, _ := writeKeytab(t, dir, "a.keytab", "HTTP/other.corp.local", testRealm, "p")
	if _, err := New(Config{Keytab: path, ServicePrincipal: testSPN}); err == nil {
		t.Fatal("keytab without SPN must fail")
	}
	if _, err := New(Config{Keytab: path}); err == nil {
		t.Fatal("empty SPN must fail")
	}
	// ротация: после замены файла новый ключ подхватывается без перезапуска
	p2, kt1 := writeKeytab(t, dir, "rot.keytab", testSPN, testRealm, "pass-1")
	v, err := New(Config{Keytab: p2, ServicePrincipal: testSPN})
	if err != nil {
		t.Fatal(err)
	}
	s, e := valid()
	if _, err := v.Validate(mkToken(t, kt1, testSPN, "u1", testRealm, s, e), ""); err != nil {
		t.Fatal(err)
	}
	_, kt2 := writeKeytab(t, dir, "rot.keytab", testSPN, testRealm, "pass-2")
	tok2 := mkToken(t, kt2, testSPN, "u2", testRealm, s, e)
	if _, err := v.Validate(tok2, ""); err == nil {
		t.Log("(reload happened immediately)")
	}
	v.chk = time.Time{}
	os.Chtimes(p2, time.Now().Add(time.Minute), time.Now().Add(time.Minute))
	if _, err := v.Validate(mkToken(t, kt2, testSPN, "u3", testRealm, s, e), ""); err != nil {
		t.Fatalf("after rotation: %v", err)
	}
}

func TestParseHeader(t *testing.T) {
	good := base64.StdEncoding.EncodeToString([]byte("abc"))
	cases := []struct {
		h   string
		err error
		ok  bool
	}{
		{"", ErrNoToken, false}, {"Bearer xyz", ErrNoToken, false}, {"Negotiate", ErrNoToken, false}, {"Negotiate ", ErrNoToken, false},
		{"NegotiateX abc", ErrNoToken, false}, {"Negotiate !!!", ErrBadToken, false}, {"Basic " + good, ErrNoToken, false},
		{"Negotiate " + good, nil, true}, {"negotiate   " + good, nil, true},
	}
	for _, c := range cases {
		b, err := ParseHeader(c.h)
		if c.ok && (err != nil || string(b) != "abc") {
			t.Errorf("%q: %v %q", c.h, err, b)
		}
		if !c.ok && !errors.Is(err, c.err) {
			t.Errorf("%q: want %v got %v", c.h, c.err, err)
		}
	}
}

func TestMapLogin(t *testing.T) {
	eq := func(got []string, want ...string) bool {
		if len(got) != len(want) {
			return false
		}
		for i := range got {
			if got[i] != want[i] {
				return false
			}
		}
		return true
	}
	if g := MapLogin("Ivanov", "CORP.LOCAL", "sam"); !eq(g, "ivanov") {
		t.Error(g)
	}
	if g := MapLogin("Ivanov", "CORP.LOCAL", ""); !eq(g, "ivanov") {
		t.Error(g)
	}
	if g := MapLogin("Ivanov", "CORP.LOCAL", "upn"); !eq(g, "ivanov@corp.local") {
		t.Error(g)
	}
	if g := MapLogin("Ivanov", "CORP.LOCAL", "auto"); !eq(g, "ivanov@corp.local", "ivanov") {
		t.Error(g)
	}
	if g := MapLogin("ivanov@alt.corp", "CORP.LOCAL", "sam"); !eq(g, "ivanov") {
		t.Error(g)
	}
	for _, bad := range []string{"", "host/pc", `CORP\ivanov`, "pc01$"} {
		if g := MapLogin(bad, "CORP.LOCAL", "sam"); g != nil {
			t.Errorf("%q → %v", bad, g)
		}
	}
}

func TestInspect(t *testing.T) {
	dir := t.TempDir()
	path, _ := writeKeytab(t, dir, "k", testSPN, testRealm, "p")
	r := Inspect(Config{Keytab: path, ServicePrincipal: testSPN})
	if !r.Ok() || len(r.KeytabEntries) != 2 || len(r.Realms) != 1 || r.Realms[0] != testRealm {
		t.Fatalf("%+v", r)
	}
	r = Inspect(Config{Keytab: path, ServicePrincipal: "HTTP/nope.corp.local"})
	if r.Ok() || len(r.Problems) == 0 {
		t.Fatalf("%+v", r)
	}
	r = Inspect(Config{Keytab: filepath.Join(dir, "x"), ServicePrincipal: "portal"})
	if r.Ok() || len(r.Problems) < 2 {
		t.Fatalf("%+v", r)
	}
	conf := filepath.Join(dir, "krb5.conf")
	os.WriteFile(conf, []byte("[libdefaults]\n default_realm = CORP.LOCAL\n"), 0o600)
	r = Inspect(Config{Keytab: path, ServicePrincipal: testSPN, ConfPath: conf})
	if r.ConfOK == nil || !*r.ConfOK || r.DefaultRealm != "CORP.LOCAL" {
		t.Fatalf("%+v", r)
	}
}
