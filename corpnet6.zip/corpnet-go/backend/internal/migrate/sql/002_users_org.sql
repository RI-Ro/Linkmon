-- 002: пользователи (ФИО, логин, телефоны, руководитель), подразделения, направления, права редакторов

-- ---- users ---------------------------------------------------------------
ALTER TABLE users
    ADD COLUMN login          text,
    ADD COLUMN middle_name    text    NOT NULL DEFAULT '',
    ADD COLUMN extra_info     text    NOT NULL DEFAULT '',
    ADD COLUMN phone2         text    NOT NULL DEFAULT '',
    ADD COLUMN phone3         text    NOT NULL DEFAULT '',
    ADD COLUMN phone4         text    NOT NULL DEFAULT '',
    ADD COLUMN is_head        boolean NOT NULL DEFAULT false,   -- руководитель подразделения
    ADD COLUMN can_vacations  boolean NOT NULL DEFAULT false,   -- может вести график отпусков
    ADD COLUMN company_news   boolean NOT NULL DEFAULT false,   -- редактор может публиковать новости «для всей компании»
    ADD COLUMN ldap_server_id bigint,                           -- источник правды (FK добавляется в 005)
    ADD COLUMN ldap_dn        text    NOT NULL DEFAULT '',
    ADD COLUMN ldap_uid       text    NOT NULL DEFAULT '';
ALTER TABLE users RENAME COLUMN phone TO phone1;
ALTER TABLE users DROP COLUMN about;

UPDATE users u SET login = x.l FROM (
    SELECT id, lower(split_part(email, '@', 1)) ||
           CASE WHEN row_number() OVER (PARTITION BY lower(split_part(email, '@', 1)) ORDER BY id) > 1
                THEN '.' || id::text ELSE '' END AS l
    FROM users) x WHERE x.id = u.id;
ALTER TABLE users ALTER COLUMN login SET NOT NULL;
CREATE UNIQUE INDEX users_login_uq ON users (lower(login));

-- email необязателен (LDAP-пользователи могут быть без почты)
ALTER TABLE users ALTER COLUMN email SET DEFAULT '';
DROP INDEX users_email_uq;
CREATE UNIQUE INDEX users_email_uq ON users (lower(email)) WHERE email <> '';

-- Фамилия Имя Отчество одной строкой + строка для поиска (триграммы)
ALTER TABLE users
    ADD COLUMN full_name text GENERATED ALWAYS AS (
        last_name || ' ' || first_name || CASE WHEN middle_name <> '' THEN ' ' || middle_name ELSE '' END) STORED,
    ADD COLUMN search_text text GENERATED ALWAYS AS (
        lower(last_name || ' ' || first_name || ' ' || middle_name || ' ' || login || ' ' || email || ' ' || job_title)) STORED;
DROP INDEX users_name_trgm;
CREATE INDEX users_search_trgm ON users USING gin (search_text gin_trgm_ops);
-- алфавитный порядок: фамилия, имя, отчество
CREATE INDEX users_alpha ON users (lower(last_name), lower(first_name), lower(middle_name), id);
CREATE INDEX users_dept_alpha ON users (department_id, lower(last_name), lower(first_name), id) WHERE NOT blocked;
CREATE INDEX users_last_prefix ON users (lower(last_name) text_pattern_ops);
CREATE INDEX users_ldap ON users (ldap_server_id, ldap_uid) WHERE ldap_server_id IS NOT NULL;
CREATE INDEX users_heads ON users (id) WHERE is_head AND NOT blocked;

-- ---- departments -----------------------------------------------------------
-- description хранит markdown; sort — индекс сортировки (при равенстве — по алфавиту)
CREATE INDEX departments_tree ON departments (parent_id, sort, lower(name), id);

-- Дополнительные подразделения, которыми может управлять редактор (помимо своего).
-- Область управления редактора = поддерево своего подразделения + поддеревья этих.
CREATE TABLE editor_departments (
    user_id       bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id bigint NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, department_id)
);
CREATE INDEX editor_departments_dept ON editor_departments (department_id);

-- ---- directions (направления деятельности) ---------------------------------
-- department_id — подразделение-владелец: его редакторы управляют направлением и всеми дочерними.
ALTER TABLE directions ADD COLUMN department_id bigint REFERENCES departments(id) ON DELETE SET NULL;
CREATE INDEX directions_tree ON directions (parent_id, sort, lower(name), id);
CREATE INDEX directions_dept ON directions (department_id) WHERE department_id IS NOT NULL;
