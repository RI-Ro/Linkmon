-- 008: «Есть идея» без статусов. Колонка ideas.status оставлена для совместимости, но нигде не используется.
DROP INDEX IF EXISTS ideas_status;
-- «Телефон 4» → «Видеотелефон»: колонка users.phone4 не переименовывается (внутреннее имя), меняются только подписи.

-- Поиск людей: в строку поиска добавляются телефоны (в т. ч. «Видеотелефон»).
DROP INDEX IF EXISTS users_search_trgm;
ALTER TABLE users DROP COLUMN search_text;
ALTER TABLE users ADD COLUMN search_text text GENERATED ALWAYS AS (
    lower(last_name || ' ' || first_name || ' ' || middle_name || ' ' || login || ' ' || email || ' ' || job_title || ' ' ||
          phone1 || ' ' || phone2 || ' ' || phone3 || ' ' || phone4)) STORED;
CREATE INDEX users_search_trgm ON users USING gin (search_text gin_trgm_ops);
