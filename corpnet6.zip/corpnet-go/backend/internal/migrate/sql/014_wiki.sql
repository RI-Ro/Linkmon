-- 014: базы знаний (Wiki) в разделе «Обучение → Материалы»
--   wiki_spaces      — база знаний (корневой раздел), привязана к папке материалов (learn_folders) или лежит в корне;
--   wiki_pages       — страницы любой вложенности (parent_id, sort), markdown, версия для оптимистичной блокировки;
--   wiki_acl         — права на базу (page_id IS NULL) и на отдельные страницы/ветки;
--   wiki_versions    — полные снимки страниц; wiki_page_files — вложения; wiki_comments — комментарии.

-- файлы вложений хранятся в files с context = 'wiki'
DO $$
DECLARE d text;
BEGIN
    SELECT pg_get_constraintdef(oid) INTO d FROM pg_constraint WHERE conrelid = 'files'::regclass AND conname = 'files_context_check';
    IF d IS NOT NULL AND d NOT LIKE '%''wiki''%' THEN
        ALTER TABLE files DROP CONSTRAINT files_context_check;
        EXECUTE 'ALTER TABLE files ADD CONSTRAINT files_context_check ' || replace(d, '''comment''::text', '''comment''::text, ''wiki''::text');
    END IF;
END $$;

CREATE TABLE wiki_spaces (
    id          bigserial PRIMARY KEY,
    folder_id   bigint REFERENCES learn_folders(id) ON DELETE CASCADE,   -- NULL — в корне вкладки «Материалы»
    title       text   NOT NULL,
    slug        text   NOT NULL DEFAULT '',
    description text   NOT NULL DEFAULT '',
    icon        text   NOT NULL DEFAULT '',     -- эмодзи / короткий символ
    cover       text   NOT NULL DEFAULT '',     -- адрес картинки или ключ цветовой схемы (c1..c8)
    visibility  text   NOT NULL DEFAULT 'company' CHECK (visibility IN ('company', 'restricted')),
    owner_id    bigint REFERENCES users(id) ON DELETE SET NULL,
    sort        int    NOT NULL DEFAULT 0,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX wiki_spaces_folder ON wiki_spaces (folder_id, sort, lower(title));

CREATE TABLE wiki_pages (
    id             bigserial PRIMARY KEY,
    space_id       bigint NOT NULL REFERENCES wiki_spaces(id) ON DELETE CASCADE,
    parent_id      bigint REFERENCES wiki_pages(id) ON DELETE CASCADE,
    title          text   NOT NULL,
    slug           text   NOT NULL DEFAULT '',
    body           text   NOT NULL DEFAULT '',
    sort           int    NOT NULL DEFAULT 0,
    visibility     text   NOT NULL DEFAULT 'inherit' CHECK (visibility IN ('inherit', 'restricted')),
    owner_id       bigint REFERENCES users(id) ON DELETE SET NULL,
    responsible_id bigint REFERENCES users(id) ON DELETE SET NULL,
    review_until   date,
    tags           text[] NOT NULL DEFAULT '{}',
    icon           text   NOT NULL DEFAULT '',
    version        int    NOT NULL DEFAULT 1,
    views_count    int    NOT NULL DEFAULT 0,
    created_by     bigint REFERENCES users(id) ON DELETE SET NULL,
    updated_by     bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at     timestamptz NOT NULL DEFAULT now(),
    updated_at     timestamptz NOT NULL DEFAULT now(),
    search         tsvector GENERATED ALWAYS AS (
        setweight(to_tsvector('simple', title), 'A') || setweight(to_tsvector('simple', left(body, 200000)), 'B')) STORED
);
CREATE INDEX wiki_pages_tree ON wiki_pages (space_id, parent_id, sort, id);
CREATE INDEX wiki_pages_parent ON wiki_pages (parent_id);
CREATE INDEX wiki_pages_fts ON wiki_pages USING gin (search);
CREATE INDEX wiki_pages_title_trgm ON wiki_pages USING gin (lower(title) gin_trgm_ops);
CREATE INDEX wiki_pages_recent ON wiki_pages (space_id, updated_at DESC);
CREATE INDEX wiki_pages_review ON wiki_pages (review_until) WHERE review_until IS NOT NULL;
CREATE INDEX wiki_pages_resp ON wiki_pages (responsible_id) WHERE responsible_id IS NOT NULL;
CREATE INDEX wiki_pages_tags ON wiki_pages USING gin (tags);

-- права: page_id NULL — на всю базу; subject_type: user | department (с дочерними) | group | role | all
-- role: user (любой сотрудник) | editor | head (руководитель подразделения) | admin
-- level: 1 чтение, 3 редактирование, 4 управление (права, удаление)
CREATE TABLE wiki_acl (
    id           bigserial PRIMARY KEY,
    space_id     bigint   NOT NULL REFERENCES wiki_spaces(id) ON DELETE CASCADE,
    page_id      bigint   REFERENCES wiki_pages(id) ON DELETE CASCADE,
    subject_type text     NOT NULL CHECK (subject_type IN ('user', 'department', 'group', 'role', 'all')),
    subject_id   bigint   NOT NULL DEFAULT 0,
    subject_key  text     NOT NULL DEFAULT '',
    level        smallint NOT NULL CHECK (level IN (1, 3, 4))
);
CREATE UNIQUE INDEX wiki_acl_uq ON wiki_acl (space_id, coalesce(page_id, 0), subject_type, subject_id, subject_key);
CREATE INDEX wiki_acl_page ON wiki_acl (page_id) WHERE page_id IS NOT NULL;

CREATE TABLE wiki_versions (
    id         bigserial PRIMARY KEY,
    page_id    bigint NOT NULL REFERENCES wiki_pages(id) ON DELETE CASCADE,
    version    int    NOT NULL,
    title      text   NOT NULL,
    body       text   NOT NULL,
    author_id  bigint REFERENCES users(id) ON DELETE SET NULL,
    comment    text   NOT NULL DEFAULT '',
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (page_id, version)
);

CREATE TABLE wiki_page_files (
    page_id bigint NOT NULL REFERENCES wiki_pages(id) ON DELETE CASCADE,
    file_id bigint NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    sort    int    NOT NULL DEFAULT 0,
    PRIMARY KEY (page_id, file_id)
);
CREATE INDEX wiki_page_files_file ON wiki_page_files (file_id);

CREATE TABLE wiki_comments (
    id         bigserial PRIMARY KEY,
    page_id    bigint NOT NULL REFERENCES wiki_pages(id) ON DELETE CASCADE,
    user_id    bigint REFERENCES users(id) ON DELETE SET NULL,
    body       text   NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX wiki_comments_page ON wiki_comments (page_id, id);

-- ---- права ---------------------------------------------------------------------------------------
-- Подходит ли запись ACL пользователю (подразделения: своё и вышестоящие; группы: подтверждённые участники).
CREATE FUNCTION wiki_acl_match(st text, sid bigint, sk text, uid bigint, depts bigint[], groups bigint[], roles text[]) RETURNS boolean
LANGUAGE sql IMMUTABLE AS $$
SELECT st = 'all'
    OR (st = 'user' AND sid = uid)
    OR (st = 'department' AND sid = ANY(depts))
    OR (st = 'group' AND sid = ANY(groups))
    OR (st = 'role' AND sk = ANY(roles))
$$;

-- Уровень пользователя на корне базы знаний (0 — нет доступа). Администратор — 4; база в папке материалов
-- недоступна тому, кто не видит папку (learn_level = 0). «Ограниченная» база видна только по списку.
CREATE FUNCTION wiki_space_level(sid bigint, uid bigint, dept bigint, depts bigint[], groups bigint[], roles text[], adm boolean) RETURNS int
LANGUAGE plpgsql STABLE AS $$
DECLARE s wiki_spaces; acl int;
BEGIN
    SELECT * INTO s FROM wiki_spaces WHERE id = sid;
    IF NOT FOUND THEN RETURN 0; END IF;
    IF adm THEN RETURN 4; END IF;
    IF s.folder_id IS NOT NULL AND learn_level(s.folder_id, uid, dept, false) = 0 THEN RETURN 0; END IF;
    SELECT coalesce(max(a.level), 0) INTO acl FROM wiki_acl a
        WHERE a.space_id = sid AND a.page_id IS NULL AND wiki_acl_match(a.subject_type, a.subject_id, a.subject_key, uid, depts, groups, roles);
    IF s.owner_id = uid THEN acl := 4; END IF;
    IF s.visibility = 'restricted' THEN RETURN acl; END IF;
    RETURN greatest(acl, 1);
END $$;

-- Уровень пользователя на странице. Правила:
--   • администратор и управляющие базой (4) видят и правят всё;
--   • «ограниченная» страница/ветка (visibility = 'restricted') заменяет список доступа: права чтения/редактирования
--     от базы и от вышестоящих страниц на неё не распространяются (кроме управляющих базой);
--   • права редактирования/управления, выданные на странице, и владение страницей действуют на всю ветку вниз;
--   • страница доступна, только если доступны все её предки.
CREATE FUNCTION wiki_level(pid bigint, uid bigint, dept bigint, depts bigint[], groups bigint[], roles text[], adm boolean) RETURNS int
LANGUAGE plpgsql STABLE AS $$
DECLARE sid bigint; sl int; vis int; mng int; own int; lvl int := 0; n record;
BEGIN
    SELECT space_id INTO sid FROM wiki_pages WHERE id = pid;
    IF sid IS NULL THEN RETURN 0; END IF;
    sl := wiki_space_level(sid, uid, dept, depts, groups, roles, adm);
    IF sl = 0 THEN RETURN 0; END IF;
    IF sl >= 4 THEN RETURN 4; END IF;
    vis := sl; mng := CASE WHEN sl >= 3 THEN sl ELSE 0 END;
    FOR n IN
        WITH RECURSIVE up AS (
            SELECT id, parent_id, visibility, owner_id, 0 AS d FROM wiki_pages WHERE id = pid
            UNION ALL
            SELECT p.id, p.parent_id, p.visibility, p.owner_id, up.d + 1 FROM wiki_pages p JOIN up ON p.id = up.parent_id WHERE up.d < 60)
        SELECT up.*, coalesce((SELECT max(a.level) FROM wiki_acl a WHERE a.page_id = up.id
                AND wiki_acl_match(a.subject_type, a.subject_id, a.subject_key, uid, depts, groups, roles)), 0) AS acl
        FROM up ORDER BY d DESC
    LOOP
        own := greatest(n.acl, CASE WHEN n.owner_id = uid THEN 3 ELSE 0 END);
        IF n.visibility = 'restricted' THEN
            vis := own; mng := CASE WHEN own >= 3 THEN own ELSE 0 END;
        ELSE
            mng := greatest(mng, CASE WHEN own >= 3 THEN own ELSE 0 END);
        END IF;
        lvl := greatest(vis, mng);
        IF lvl = 0 THEN RETURN 0; END IF;
    END LOOP;
    RETURN lvl;
END $$;

-- То же по одному пользователю: субъекты (подразделения, группы, роли) берутся из БД. Для доступа к файлам и т. п.
CREATE FUNCTION wiki_level_u(pid bigint, uid bigint, adm boolean) RETURNS int
LANGUAGE plpgsql STABLE AS $$
DECLARE u record; depts bigint[]; groups bigint[]; roles text[];
BEGIN
    SELECT department_id, role, is_head INTO u FROM users WHERE id = uid;
    IF NOT FOUND THEN RETURN 0; END IF;
    WITH RECURSIVE dc AS (SELECT id, parent_id FROM departments WHERE id = u.department_id
        UNION ALL SELECT x.id, x.parent_id FROM departments x JOIN dc ON x.id = dc.parent_id)
    SELECT coalesce(array_agg(id), '{}') INTO depts FROM dc;
    SELECT coalesce(array_agg(group_id), '{}') INTO groups FROM group_members WHERE user_id = uid AND role <> 'pending';
    roles := ARRAY['user'];
    IF u.role IN ('editor', 'admin') THEN roles := roles || 'editor'; END IF;
    IF u.role = 'admin' THEN roles := roles || 'admin'; END IF;
    IF u.is_head THEN roles := roles || 'head'; END IF;
    RETURN wiki_level(pid, uid, coalesce(u.department_id, 0), depts, groups, roles, adm OR u.role = 'admin');
END $$;

-- доступ к файлу вложения: загрузивший или читатель страницы, к которой он прикреплён
CREATE FUNCTION wiki_file_ok(fid bigint, uid bigint, adm boolean) RETURNS boolean
LANGUAGE sql STABLE AS $$
SELECT adm
    OR EXISTS (SELECT 1 FROM files f WHERE f.id = fid AND f.owner_id = uid)
    OR EXISTS (SELECT 1 FROM wiki_page_files wf WHERE wf.file_id = fid AND wiki_level_u(wf.page_id, uid, false) > 0)
$$;
