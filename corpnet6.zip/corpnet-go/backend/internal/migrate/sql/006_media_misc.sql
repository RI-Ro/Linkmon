-- 006: размеры изображений (оригинал / просмотр / превью), идеи без статуса «рассмотрение», индексы для доступа к фото из новостей

-- имя файла «просмотра» (<имя>.v.jpg, ширина 1728 px); пусто — отдаётся оригинал
ALTER TABLE files ADD COLUMN view text NOT NULL DEFAULT '';

-- статус идеи «review» убран
ALTER TABLE ideas DROP CONSTRAINT IF EXISTS ideas_status_check;
UPDATE ideas SET status = 'new' WHERE status = 'review';
ALTER TABLE ideas ADD CONSTRAINT ideas_status_check CHECK (status IN ('new','accepted','done','declined'));
