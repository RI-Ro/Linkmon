-- 009: смайлы/реакции, закладки, упоминания @.

-- ---- реакции -----------------------------------------------------------------
-- entity_type: news | idea | post | comment | message (список расширяемый: registerReactionTarget в Go; CHECK не ставим).
-- emoji: юникод-эмодзи либо шорткод анимированного стикера «:имя:».
CREATE TABLE reactions (
    entity_type text   NOT NULL,
    entity_id   bigint NOT NULL,
    user_id     bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    emoji       text   NOT NULL CHECK (char_length(emoji) BETWEEN 1 AND 48),
    created_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (entity_type, entity_id, user_id, emoji)
);
-- агрегаты страницы списка (count по emoji + «моя») читаются index-only; PK ведёт список «кто поставил»
CREATE INDEX reactions_entity ON reactions (entity_type, entity_id) INCLUDE (emoji, user_id);
CREATE INDEX reactions_user ON reactions (user_id);

-- Лайки становятся реакцией 👍. Счётчики likes_count (новости/идеи/посты) остаются денормализованным числом именно 👍:
-- по нему сортируется «популярные идеи» (keyset), а карточки ленты не делают агрегат на каждую новость.
INSERT INTO reactions (entity_type, entity_id, user_id, emoji, created_at)
    SELECT entity_type, entity_id, user_id, '👍', created_at FROM likes ON CONFLICT DO NOTHING;
UPDATE news n SET likes_count = c.n FROM (SELECT entity_id, count(*)::int AS n FROM reactions WHERE entity_type = 'news' AND emoji = '👍' GROUP BY 1) c
    WHERE c.entity_id = n.id AND n.likes_count <> c.n;
UPDATE ideas n SET likes_count = c.n FROM (SELECT entity_id, count(*)::int AS n FROM reactions WHERE entity_type = 'idea' AND emoji = '👍' GROUP BY 1) c
    WHERE c.entity_id = n.id AND n.likes_count <> c.n;
UPDATE group_posts n SET likes_count = c.n FROM (SELECT entity_id, count(*)::int AS n FROM reactions WHERE entity_type = 'post' AND emoji = '👍' GROUP BY 1) c
    WHERE c.entity_id = n.id AND n.likes_count <> c.n;
DROP TABLE likes;

-- ---- закладки -----------------------------------------------------------------
-- entity_type: news | idea | file | post | event | message | learn_item | wiki_page | … (резолверы регистрируются в Go)
CREATE TABLE bookmarks (
    user_id     bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    entity_type text   NOT NULL,
    entity_id   bigint NOT NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    note        text NOT NULL DEFAULT '' CHECK (char_length(note) <= 500),
    PRIMARY KEY (user_id, entity_type, entity_id)
);
CREATE INDEX bookmarks_user_time ON bookmarks (user_id, created_at DESC);
CREATE INDEX bookmarks_entity ON bookmarks (entity_type, entity_id);

-- ---- упоминания @логин ----------------------------------------------------------
-- entity_type: comment | message | post | idea. Строка = «пользователь уже уведомлён об упоминании в этом объекте» (без дублей при правке).
CREATE TABLE mentions (
    entity_type text   NOT NULL,
    entity_id   bigint NOT NULL,
    user_id     bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (entity_type, entity_id, user_id)
);
CREATE INDEX mentions_user ON mentions (user_id, created_at DESC);

-- быстрый префиксный поиск логина/имени для автодополнения (lower(...) LIKE 'abc%' при любой локали)
CREATE INDEX users_login_prefix ON users (lower(login) text_pattern_ops);
CREATE INDEX users_first_prefix ON users (lower(first_name) text_pattern_ops);

-- ---- уборка при удалении объектов (в т.ч. каскадом) ----------------------------------
CREATE FUNCTION social_cleanup() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM reactions WHERE entity_type = TG_ARGV[0] AND entity_id = OLD.id;
    DELETE FROM bookmarks WHERE entity_type = TG_ARGV[0] AND entity_id = OLD.id;
    DELETE FROM mentions  WHERE entity_type = TG_ARGV[0] AND entity_id = OLD.id;
    RETURN NULL;
END $$;
CREATE FUNCTION social_cleanup_bm() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM bookmarks WHERE entity_type = TG_ARGV[0] AND entity_id = OLD.id;
    RETURN NULL;
END $$;
CREATE TRIGGER news_social_del     AFTER DELETE ON news        FOR EACH ROW EXECUTE FUNCTION social_cleanup('news');
CREATE TRIGGER ideas_social_del    AFTER DELETE ON ideas       FOR EACH ROW EXECUTE FUNCTION social_cleanup('idea');
CREATE TRIGGER posts_social_del    AFTER DELETE ON group_posts FOR EACH ROW EXECUTE FUNCTION social_cleanup('post');
CREATE TRIGGER comments_social_del AFTER DELETE ON comments    FOR EACH ROW EXECUTE FUNCTION social_cleanup('comment');
CREATE TRIGGER messages_social_del AFTER DELETE ON messages    FOR EACH ROW EXECUTE FUNCTION social_cleanup('message');
CREATE TRIGGER events_social_del   AFTER DELETE ON events      FOR EACH ROW EXECUTE FUNCTION social_cleanup_bm('event');
CREATE TRIGGER files_social_del    AFTER DELETE ON files       FOR EACH ROW EXECUTE FUNCTION social_cleanup_bm('file');
CREATE TRIGGER learn_items_social_del AFTER DELETE ON learn_items FOR EACH ROW EXECUTE FUNCTION social_cleanup_bm('learn_item');
