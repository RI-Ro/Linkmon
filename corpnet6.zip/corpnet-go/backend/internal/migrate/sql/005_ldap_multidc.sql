-- 005: LDAP-источники, сессии и блокировки в PostgreSQL, outbox для realtime между ЦОДами

CREATE TABLE ldap_servers (
    id               bigserial PRIMARY KEY,
    name             text    NOT NULL,                 -- название в выпадающем списке на странице входа
    enabled          boolean NOT NULL DEFAULT true,
    url              text    NOT NULL,                 -- ldap://host:389 | ldaps://host:636
    start_tls        boolean NOT NULL DEFAULT false,
    skip_verify      boolean NOT NULL DEFAULT false,
    bind_dn          text    NOT NULL DEFAULT '',      -- сервисная учётка для поиска
    bind_password    text    NOT NULL DEFAULT '',      -- AES-GCM (ключ SECRET_KEY), в API не отдаётся
    base_dn          text    NOT NULL,
    user_filter      text    NOT NULL DEFAULT '(&(objectClass=person)(sAMAccountName=%s))', -- %s — логин
    sync_filter      text    NOT NULL DEFAULT '(&(objectClass=person)(sAMAccountName=*))',  -- кого загружать при синхронизации
    attr_login       text    NOT NULL DEFAULT 'sAMAccountName',
    attr_uid         text    NOT NULL DEFAULT 'objectGUID', -- неизменяемый идентификатор (для переименований)
    attr_first_name  text    NOT NULL DEFAULT 'givenName',
    attr_last_name   text    NOT NULL DEFAULT 'sn',
    attr_middle_name text    NOT NULL DEFAULT '',
    attr_email       text    NOT NULL DEFAULT 'mail',
    attr_title       text    NOT NULL DEFAULT 'title',
    attr_phone1      text    NOT NULL DEFAULT 'telephoneNumber',
    attr_phone2      text    NOT NULL DEFAULT 'mobile',
    attr_phone3      text    NOT NULL DEFAULT '',
    attr_phone4      text    NOT NULL DEFAULT '',
    attr_birthday    text    NOT NULL DEFAULT '',
    attr_department  text    NOT NULL DEFAULT 'department', -- сопоставляется с названием подразделения
    attr_disabled    text    NOT NULL DEFAULT 'userAccountControl', -- AD: бит 2 = учётка отключена
    default_role     text    NOT NULL DEFAULT 'user' CHECK (default_role IN ('user','editor')),
    auto_create      boolean NOT NULL DEFAULT true,     -- создавать пользователя при первом входе
    deactivate_missing boolean NOT NULL DEFAULT true,   -- блокировать тех, кого больше нет в каталоге
    sync_minutes     int     NOT NULL DEFAULT 0 CHECK (sync_minutes >= 0), -- 0 = только вручную
    sort             int     NOT NULL DEFAULT 0,
    last_sync_at     timestamptz,
    last_sync_status text    NOT NULL DEFAULT '',
    created_at       timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE users ADD COLUMN ldap_blocked boolean NOT NULL DEFAULT false; -- заблокирован синхронизацией (а не вручную)
ALTER TABLE users ADD CONSTRAINT users_ldap_fk FOREIGN KEY (ldap_server_id) REFERENCES ldap_servers(id) ON DELETE SET NULL;

-- Сессии в БД: работают между ЦОДами (Redis остаётся локальным кэшем каждого ЦОДа)
CREATE TABLE sessions (
    token      text PRIMARY KEY,
    user_id    bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL,
    ip         text NOT NULL DEFAULT ''
);
CREATE INDEX sessions_user ON sessions (user_id);
CREATE INDEX sessions_expires ON sessions (expires_at);

-- Глобальные блокировки фоновых задач (работают в любом числе ЦОДов, т.к. живут в основной БД)
CREATE TABLE job_locks (
    name       text PRIMARY KEY,
    holder     text NOT NULL,
    locked_until timestamptz NOT NULL
);

-- Outbox для событий реального времени между ЦОДами.
-- Пишется в основную БД; читается каждым экземпляром со своей реплики.
-- xid — номер транзакции: читаем только строки, чьи транзакции уже завершены (см. hub_pg.go).
CREATE TABLE realtime_events (
    id         bigserial PRIMARY KEY,
    xid        bigint NOT NULL DEFAULT (pg_current_xact_id()::text::bigint),
    topic      text   NOT NULL,
    payload    text   NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX realtime_events_pos ON realtime_events (xid, id);
CREATE INDEX realtime_events_created ON realtime_events (created_at);
