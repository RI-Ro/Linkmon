-- 015: управление пользователями редакторами + расширенный журнал аудита.
-- Мягкое удаление: строка остаётся (авторство новостей, комментариев и т. п. сохраняется), вход закрыт, из списков скрыта.
ALTER TABLE users ADD COLUMN deleted_at timestamptz;
CREATE INDEX users_dept_active ON users (department_id) WHERE deleted_at IS NULL;

-- Журнал: идентификатор запроса и роль исполнителя на момент действия; индексы под фильтры раздела «Журнал».
ALTER TABLE audit_log ADD COLUMN request_id text NOT NULL DEFAULT '';
ALTER TABLE audit_log ADD COLUMN actor_role text NOT NULL DEFAULT '';
CREATE INDEX audit_action ON audit_log (action, id DESC);
CREATE INDEX audit_actor ON audit_log (user_id, id DESC);
CREATE INDEX audit_entity ON audit_log (entity, entity_id, id DESC);
