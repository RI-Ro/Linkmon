-- 013: LMS — курсы с прогрессом, назначения и напоминания, сертификаты, роль «ответственный за обучение»,
--      расширение тестов (пул вопросов, matching/ordering, снимки вопросов в попытках)

-- ---- роль «ответственный за обучение» -------------------------------------------------------------
ALTER TABLE users
    ADD COLUMN learning_manager boolean     NOT NULL DEFAULT false,
    ADD COLUMN department_since timestamptz NOT NULL DEFAULT now();   -- когда сотрудник попал в текущее подразделение (приём/перевод)

-- Область ответственного = его подразделение и все дочерние + эти подразделения (с поддеревьями). Админ видит всё.
CREATE TABLE learning_manager_departments (
    user_id       bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id bigint NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, department_id)
);
CREATE INDEX learning_manager_departments_dept ON learning_manager_departments (department_id);
CREATE INDEX users_learning_manager ON users (id) WHERE learning_manager AND NOT blocked;
CREATE INDEX users_dept_since ON users (department_since) WHERE department_id IS NOT NULL;

CREATE FUNCTION lms_user_dept_bi() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP = 'INSERT' OR NEW.department_id IS DISTINCT FROM OLD.department_id THEN NEW.department_since := now(); END IF;
    RETURN NEW;
END $$;
CREATE TRIGGER lms_user_dept_bi BEFORE INSERT OR UPDATE OF department_id ON users FOR EACH ROW EXECUTE FUNCTION lms_user_dept_bi();

-- ---- папки курсов (тот же механизм ACL, что у материалов и тестов) -----------------------------------
DO $$
DECLARE c record; vals text[];
BEGIN
    FOR c IN SELECT conname, pg_get_constraintdef(oid) AS d FROM pg_constraint
             WHERE conrelid = 'learn_folders'::regclass AND contype = 'c' AND pg_get_constraintdef(oid) LIKE '%kind%' LOOP
        SELECT array_agg(DISTINCT m[1]) INTO vals FROM regexp_matches(c.d, '''([a-z_]+)''', 'g') m;
        EXECUTE format('ALTER TABLE learn_folders DROP CONSTRAINT %I', c.conname);
    END LOOP;
    SELECT array_agg(DISTINCT x) INTO vals FROM unnest(coalesce(vals, '{}') || ARRAY['materials', 'tests', 'courses']) x;
    EXECUTE format('ALTER TABLE learn_folders ADD CONSTRAINT learn_folders_kind_check CHECK (kind = ANY (%L::text[]))', vals);
END $$;

-- ---- шаблоны сертификатов ----------------------------------------------------------------------------
CREATE TABLE learn_cert_templates (
    id           bigserial PRIMARY KEY,
    name         text   NOT NULL,
    title        text   NOT NULL DEFAULT 'Сертификат',
    body         text   NOT NULL DEFAULT 'Настоящим подтверждается, что {ФИО} успешно прошёл(ла) обучение по программе «{курс}» {дата} с результатом {балл}.',
    color        text   NOT NULL DEFAULT '#1f5fa8',
    border       text   NOT NULL DEFAULT 'double' CHECK (border IN ('none', 'simple', 'double', 'ornate')),
    logo         text   NOT NULL DEFAULT '',
    signer_name  text   NOT NULL DEFAULT '',
    signer_title text   NOT NULL DEFAULT '',
    number_mask  text   NOT NULL DEFAULT 'CN-{YYYY}-{N:5}',
    expire_remind_days int NOT NULL DEFAULT 30 CHECK (expire_remind_days >= 0),   -- за сколько дней напомнить об окончании срока
    counter      bigint NOT NULL DEFAULT 0,          -- счётчик без дыр: увеличивается в транзакции выдачи
    created_by   bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at   timestamptz NOT NULL DEFAULT now(),
    updated_at   timestamptz NOT NULL DEFAULT now()
);

-- ---- курсы ------------------------------------------------------------------------------------------
CREATE TABLE learn_courses (
    id               bigserial PRIMARY KEY,
    folder_id        bigint NOT NULL REFERENCES learn_folders(id) ON DELETE CASCADE,
    title            text   NOT NULL,
    description      text   NOT NULL DEFAULT '',
    cover            text   NOT NULL DEFAULT '',
    tags             text[] NOT NULL DEFAULT '{}',
    status           text   NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
    est_minutes      int    NOT NULL DEFAULT 0,
    order_mode       text   NOT NULL DEFAULT 'free' CHECK (order_mode IN ('free', 'sequential')),
    pass_percent     int    NOT NULL DEFAULT 70 CHECK (pass_percent BETWEEN 0 AND 100),   -- порог теста внутри курса
    validity_months  int    NOT NULL DEFAULT 0 CHECK (validity_months >= 0),               -- 0 — бессрочно
    max_attempts     int    CHECK (max_attempts IS NULL OR max_attempts > 0),              -- попыток теста внутри курса
    version          int    NOT NULL DEFAULT 1,
    cert_template_id bigint REFERENCES learn_cert_templates(id) ON DELETE SET NULL,
    steps_count      int    NOT NULL DEFAULT 0,
    required_count   int    NOT NULL DEFAULT 0,
    sort             int    NOT NULL DEFAULT 0,
    author_id        bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX learn_courses_folder ON learn_courses (folder_id, sort, id);
CREATE INDEX learn_courses_title_trgm ON learn_courses USING gin (lower(title || ' ' || description) gin_trgm_ops);
CREATE INDEX learn_courses_tags ON learn_courses USING gin (tags);
CREATE INDEX learn_courses_tpl ON learn_courses (cert_template_id) WHERE cert_template_id IS NOT NULL;

CREATE TABLE learn_course_prereq (
    course_id bigint NOT NULL REFERENCES learn_courses(id) ON DELETE CASCADE,
    req_id    bigint NOT NULL REFERENCES learn_courses(id) ON DELETE CASCADE,
    PRIMARY KEY (course_id, req_id),
    CHECK (course_id <> req_id)
);
CREATE INDEX learn_course_prereq_req ON learn_course_prereq (req_id);

CREATE TABLE learn_course_sections (
    id        bigserial PRIMARY KEY,
    course_id bigint NOT NULL REFERENCES learn_courses(id) ON DELETE CASCADE,
    title     text   NOT NULL,
    sort      int    NOT NULL DEFAULT 0
);
CREATE INDEX learn_course_sections_course ON learn_course_sections (course_id, sort, id);

CREATE TABLE learn_course_steps (
    id           bigserial PRIMARY KEY,
    course_id    bigint NOT NULL REFERENCES learn_courses(id) ON DELETE CASCADE,
    section_id   bigint REFERENCES learn_course_sections(id) ON DELETE SET NULL,
    sort         int    NOT NULL DEFAULT 0,
    kind         text   NOT NULL CHECK (kind IN ('item', 'test', 'link', 'video', 'wiki', 'ack')),
    ref_id       bigint,                              -- материал (item) / тест (test)
    title        text   NOT NULL,
    body         text   NOT NULL DEFAULT '',          -- текст ознакомления (ack)
    url          text   NOT NULL DEFAULT '',          -- link / video / wiki
    required     boolean NOT NULL DEFAULT true,
    pass_percent int    CHECK (pass_percent IS NULL OR pass_percent BETWEEN 0 AND 100),
    est_minutes  int    NOT NULL DEFAULT 0
);
CREATE INDEX learn_course_steps_course ON learn_course_steps (course_id, sort, id);
CREATE INDEX learn_course_steps_ref ON learn_course_steps (kind, ref_id) WHERE ref_id IS NOT NULL;

-- ---- прогресс ---------------------------------------------------------------------------------------
-- запись одного шага: единственный upsert по первичному ключу, без блокировок соседей
CREATE TABLE learn_step_progress (
    user_id   bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    step_id   bigint NOT NULL REFERENCES learn_course_steps(id) ON DELETE CASCADE,
    course_id bigint NOT NULL,
    status    smallint NOT NULL DEFAULT 1,            -- 0 не начат, 1 в процессе, 2 завершён
    first_at  timestamptz NOT NULL DEFAULT now(),
    last_at   timestamptz NOT NULL DEFAULT now(),
    done_at   timestamptz,
    time_sec  int NOT NULL DEFAULT 0,
    beat_at   timestamptz,
    score     numeric(5,1),                           -- результат теста, %
    attempt_id bigint,
    PRIMARY KEY (user_id, step_id)
);
CREATE INDEX learn_step_progress_course ON learn_step_progress (course_id, step_id, status);
CREATE INDEX learn_step_progress_user ON learn_step_progress (user_id, course_id);

-- прохождение курса пользователем (денормализовано: подразделение, % и время — отчёты читают только эту таблицу)
CREATE TABLE learn_enrollments (
    user_id           bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    course_id         bigint NOT NULL REFERENCES learn_courses(id) ON DELETE CASCADE,
    dept_id           bigint,
    status            smallint NOT NULL DEFAULT 0,    -- 0 не начат, 1 в процессе, 2 завершён
    cycle             int NOT NULL DEFAULT 1,
    started_at        timestamptz,
    last_at           timestamptz,
    completed_at      timestamptz,
    expires_at        timestamptz,
    started_version   int NOT NULL DEFAULT 1,
    completed_version int,
    steps_done        int NOT NULL DEFAULT 0,
    steps_total       int NOT NULL DEFAULT 0,
    percent           smallint NOT NULL DEFAULT 0,
    time_sec          int NOT NULL DEFAULT 0,
    score             numeric(5,1),
    cert_id           bigint,
    soon_notified     boolean NOT NULL DEFAULT false,
    PRIMARY KEY (user_id, course_id)
);
CREATE INDEX learn_enrollments_course ON learn_enrollments (course_id, status);
CREATE INDEX learn_enrollments_dept ON learn_enrollments (dept_id, course_id, status);
CREATE INDEX learn_enrollments_recent ON learn_enrollments (user_id, last_at DESC);
CREATE INDEX learn_enrollments_done ON learn_enrollments (course_id, completed_at) WHERE status = 2;
CREATE INDEX learn_enrollments_exp ON learn_enrollments (expires_at) WHERE status = 2 AND expires_at IS NOT NULL;

-- история завершений (рекертификация не стирает прошлые результаты)
CREATE TABLE learn_completions (
    id           bigserial PRIMARY KEY,
    user_id      bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    course_id    bigint NOT NULL REFERENCES learn_courses(id) ON DELETE CASCADE,
    cycle        int NOT NULL,
    version      int NOT NULL,
    completed_at timestamptz NOT NULL DEFAULT now(),
    expires_at   timestamptz,
    score        numeric(5,1),
    time_sec     int NOT NULL DEFAULT 0,
    cert_id      bigint
);
CREATE INDEX learn_completions_user ON learn_completions (user_id, completed_at DESC);
CREATE INDEX learn_completions_course ON learn_completions (course_id, completed_at);

-- ---- сертификаты ------------------------------------------------------------------------------------
CREATE TABLE learn_certs (
    id          bigserial PRIMARY KEY,
    number      text   NOT NULL,
    code        text   NOT NULL,                      -- проверочный код (публичная страница проверки)
    user_id     bigint REFERENCES users(id) ON DELETE SET NULL,
    dept_id     bigint,
    course_id   bigint REFERENCES learn_courses(id) ON DELETE SET NULL,
    test_id     bigint REFERENCES learn_tests(id) ON DELETE SET NULL,
    template_id bigint REFERENCES learn_cert_templates(id) ON DELETE SET NULL,
    title       text   NOT NULL,                      -- название курса/теста на момент выдачи
    user_name   text   NOT NULL,
    score       numeric(5,1),
    issued_at   timestamptz NOT NULL DEFAULT now(),
    expires_at  timestamptz,
    status      text   NOT NULL DEFAULT 'valid' CHECK (status IN ('valid', 'revoked')),
    revoked_at  timestamptz,
    revoked_by  bigint REFERENCES users(id) ON DELETE SET NULL,
    revoke_reason text NOT NULL DEFAULT '',
    soon_notified boolean NOT NULL DEFAULT false,
    look        jsonb  NOT NULL DEFAULT '{}'          -- снимок оформления и текста (шаблон можно менять — выданные не меняются)
);
CREATE UNIQUE INDEX learn_certs_number ON learn_certs (number);
CREATE UNIQUE INDEX learn_certs_code ON learn_certs (code);
CREATE INDEX learn_certs_user ON learn_certs (user_id, issued_at DESC);
CREATE INDEX learn_certs_dept ON learn_certs (dept_id, issued_at DESC);
CREATE INDEX learn_certs_course ON learn_certs (course_id, issued_at DESC);
CREATE INDEX learn_certs_exp ON learn_certs (expires_at) WHERE status = 'valid' AND expires_at IS NOT NULL;
ALTER TABLE learn_enrollments ADD CONSTRAINT learn_enrollments_cert_fk FOREIGN KEY (cert_id) REFERENCES learn_certs(id) ON DELETE SET NULL;

-- ---- назначения -------------------------------------------------------------------------------------
CREATE TABLE learn_assignments (
    id                  bigserial PRIMARY KEY,
    target_type         text   NOT NULL CHECK (target_type IN ('course', 'test')),
    target_id           bigint NOT NULL,
    created_by          bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at          timestamptz NOT NULL DEFAULT now(),
    priority            text   NOT NULL DEFAULT 'normal' CHECK (priority IN ('normal', 'high')),
    mandatory           boolean NOT NULL DEFAULT true,
    due_mode            text   NOT NULL DEFAULT 'days' CHECK (due_mode IN ('none', 'date', 'days')),
    due_date            timestamptz,
    due_days            int    CHECK (due_days IS NULL OR due_days > 0),     -- срок: N дней с момента назначения
    remind_days         int[]  NOT NULL DEFAULT '{7,3,1,0}',                  -- за сколько дней до срока напоминать (0 — в день срока)
    remind_overdue_days int    NOT NULL DEFAULT 3 CHECK (remind_overdue_days >= 0),   -- после просрочки — каждые N дней, 0 — не напоминать
    recur_months        int    NOT NULL DEFAULT 0 CHECK (recur_months >= 0),  -- периодическое переназначение
    follow              boolean NOT NULL DEFAULT false,                       -- правило: назначать и новым сотрудникам цели
    new_within_days     int    CHECK (new_within_days IS NULL OR new_within_days > 0),   -- ... появившимся в подразделении за последние N дней
    limit_depts         bigint[],                                             -- область создателя-ответственного (NULL — без ограничений)
    note                text   NOT NULL DEFAULT '',
    status              text   NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cancelled'))
);
CREATE INDEX learn_assignments_target ON learn_assignments (target_type, target_id);
CREATE INDEX learn_assignments_follow ON learn_assignments (id) WHERE status = 'active' AND follow;
CREATE INDEX learn_assignments_recur ON learn_assignments (id) WHERE status = 'active' AND recur_months > 0;

CREATE TABLE learn_assign_targets (
    id            bigserial PRIMARY KEY,
    assignment_id bigint NOT NULL REFERENCES learn_assignments(id) ON DELETE CASCADE,
    subject_type  text   NOT NULL CHECK (subject_type IN ('user', 'department', 'group', 'role', 'all')),
    subject_id    bigint NOT NULL DEFAULT 0,
    subject_key   text   NOT NULL DEFAULT ''           -- для role: user | editor | admin | head | learning_manager
);
CREATE UNIQUE INDEX learn_assign_targets_uq ON learn_assign_targets (assignment_id, subject_type, subject_id, subject_key);

-- кто и что должен пройти (по строке на пользователя и цикл переназначения)
CREATE TABLE learn_assignees (
    id             bigserial PRIMARY KEY,
    assignment_id  bigint NOT NULL REFERENCES learn_assignments(id) ON DELETE CASCADE,
    user_id        bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    dept_id        bigint,
    target_type    text   NOT NULL,
    target_id      bigint NOT NULL,
    cycle          int    NOT NULL DEFAULT 1,
    assigned_at    timestamptz NOT NULL DEFAULT now(),
    due_at         timestamptz,
    status         smallint NOT NULL DEFAULT 0,          -- 0 назначено, 1 в процессе, 2 выполнено, 3 отозвано
    started_at     timestamptz,
    done_at        timestamptz,
    score          numeric(5,1),
    high           boolean NOT NULL DEFAULT false,
    mandatory      boolean NOT NULL DEFAULT true,
    manual_remind_at timestamptz
);
CREATE UNIQUE INDEX learn_assignees_uq ON learn_assignees (assignment_id, user_id, cycle);
CREATE INDEX learn_assignees_user ON learn_assignees (user_id, status, due_at);
CREATE INDEX learn_assignees_dept ON learn_assignees (dept_id, status, due_at);
CREATE INDEX learn_assignees_target ON learn_assignees (target_type, target_id, status);
CREATE INDEX learn_assignees_due ON learn_assignees (due_at) WHERE status < 2 AND due_at IS NOT NULL;
CREATE INDEX learn_assignees_done ON learn_assignees (done_at) WHERE status = 2;

-- идемпотентные ключи напоминаний: повторный запуск джоба не создаёт дубль
CREATE TABLE learn_reminders (
    assignee_id bigint NOT NULL REFERENCES learn_assignees(id) ON DELETE CASCADE,
    key         text   NOT NULL,
    sent_at     timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (assignee_id, key)
);
CREATE TABLE learn_digests (
    user_id bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    day     date   NOT NULL,
    PRIMARY KEY (user_id, day)
);
CREATE TABLE learn_assign_log (
    id            bigserial PRIMARY KEY,
    assignee_id   bigint REFERENCES learn_assignees(id) ON DELETE CASCADE,
    assignment_id bigint REFERENCES learn_assignments(id) ON DELETE CASCADE,
    actor_id      bigint REFERENCES users(id) ON DELETE SET NULL,
    action        text   NOT NULL,                         -- create | extend | revoke | restore | remind | cancel
    data          jsonb  NOT NULL DEFAULT '{}',
    at            timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX learn_assign_log_assignee ON learn_assign_log (assignee_id, at DESC);
CREATE INDEX learn_assign_log_assignment ON learn_assign_log (assignment_id, at DESC);

-- подразделение пользователя продублировано в отчётных таблицах
CREATE FUNCTION lms_user_dept_ai() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    UPDATE learn_assignees SET dept_id = NEW.department_id WHERE user_id = NEW.id;
    UPDATE learn_enrollments SET dept_id = NEW.department_id WHERE user_id = NEW.id;
    UPDATE learn_certs SET dept_id = NEW.department_id WHERE user_id = NEW.id;
    RETURN NULL;
END $$;
CREATE TRIGGER lms_user_dept_ai AFTER UPDATE OF department_id ON users FOR EACH ROW
    WHEN (OLD.department_id IS DISTINCT FROM NEW.department_id) EXECUTE FUNCTION lms_user_dept_ai();

-- ---- тесты: пул вопросов, новые типы, снимки -------------------------------------------------------------
ALTER TABLE learn_tests
    ADD COLUMN pool_size int CHECK (pool_size IS NULL OR pool_size > 0),            -- N вопросов из M случайно
    ADD COLUMN cert_template_id bigint REFERENCES learn_cert_templates(id) ON DELETE SET NULL,   -- сертификат за сдачу теста
    ADD COLUMN cert_validity_months int NOT NULL DEFAULT 0 CHECK (cert_validity_months >= 0);

DO $$
DECLARE c record;
BEGIN
    FOR c IN SELECT conname FROM pg_constraint WHERE conrelid = 'learn_questions'::regclass AND contype = 'c' AND pg_get_constraintdef(oid) LIKE '%single%' LOOP
        EXECUTE format('ALTER TABLE learn_questions DROP CONSTRAINT %I', c.conname);
    END LOOP;
    ALTER TABLE learn_questions ADD CONSTRAINT learn_questions_type_check CHECK (type IN ('single', 'multiple', 'text', 'matching', 'ordering'));
END $$;

-- версии набора вопросов теста (содержимое хэшируется; попытка ссылается на версию, а не копирует вопросы)
CREATE TABLE learn_test_versions (
    id         bigserial PRIMARY KEY,
    test_id    bigint NOT NULL REFERENCES learn_tests(id) ON DELETE CASCADE,
    hash       text   NOT NULL,
    questions  jsonb  NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX learn_test_versions_uq ON learn_test_versions (test_id, hash);

ALTER TABLE learn_attempts
    ADD COLUMN version_id bigint REFERENCES learn_test_versions(id) ON DELETE SET NULL,
    ADD COLUMN qids       bigint[],                    -- выбранные вопросы (пул N из M) в порядке показа
    ADD COLUMN course_id  bigint,
    ADD COLUMN step_id    bigint;
CREATE INDEX learn_attempts_step ON learn_attempts (user_id, step_id) WHERE step_id IS NOT NULL;
CREATE INDEX learn_attempts_course ON learn_attempts (course_id, finished_at) WHERE course_id IS NOT NULL;
CREATE INDEX learn_attempts_version ON learn_attempts (version_id) WHERE version_id IS NOT NULL;
CREATE INDEX learn_attempts_fin ON learn_attempts (finished_at DESC) WHERE finished_at IS NOT NULL;

-- ---- доступ к материалам/тестам через курс или назначение -------------------------------------------------------
-- курс доступен: опубликован и папка видна, либо назначен; администратор — всегда
CREATE FUNCTION lms_course_ok(cid bigint, uid bigint, dept bigint, adm boolean) RETURNS boolean
LANGUAGE sql STABLE AS $$
SELECT EXISTS (SELECT 1 FROM learn_courses c WHERE c.id = cid AND (adm OR (c.status = 'published' AND (
        learn_level(c.folder_id, uid, dept, adm) > 0
        OR EXISTS (SELECT 1 FROM learn_assignees a WHERE a.user_id = uid AND a.target_type = 'course' AND a.target_id = c.id AND a.status < 3)))))
$$;

-- материал/тест доступен как шаг доступного курса (или тест назначен напрямую)
CREATE FUNCTION lms_ref_ok(k text, rid bigint, uid bigint, dept bigint, adm boolean) RETURNS boolean
LANGUAGE sql STABLE AS $$
SELECT EXISTS (SELECT 1 FROM learn_course_steps s JOIN learn_courses c ON c.id = s.course_id
               WHERE s.kind = k AND s.ref_id = rid AND c.status = 'published' AND lms_course_ok(c.id, uid, dept, adm))
    OR (k = 'test' AND EXISTS (SELECT 1 FROM learn_assignees a WHERE a.user_id = uid AND a.target_type = 'test' AND a.target_id = rid AND a.status < 3))
$$;

CREATE OR REPLACE FUNCTION learn_file_ok(fid bigint, uid bigint, dept bigint, adm boolean) RETURNS boolean
LANGUAGE sql STABLE AS $$
SELECT adm
    OR EXISTS (SELECT 1 FROM files f WHERE f.id = fid AND f.owner_id = uid)
    OR EXISTS (SELECT 1 FROM learn_item_files lf JOIN learn_items i ON i.id = lf.item_id
               WHERE lf.file_id = fid AND (learn_level(i.folder_id, uid, dept, adm) > 0 OR lms_ref_ok('item', i.id, uid, dept, adm)))
    OR EXISTS (SELECT 1 FROM learn_questions q JOIN learn_tests t ON t.id = q.test_id
               WHERE q.file_id = fid AND (learn_level(t.folder_id, uid, dept, adm) >= 3
                  OR (t.status = 'published' AND (learn_level(t.folder_id, uid, dept, adm) > 0 OR lms_ref_ok('test', t.id, uid, dept, adm)))))
$$;

-- счётчики курсов в папке (как для тестов: items_count — всего, pub_count — опубликованных)
CREATE FUNCTION learn_count_courses() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE pn int := 0; po int := 0;
BEGIN
    IF TG_OP IN ('INSERT', 'UPDATE') AND NEW.status = 'published' THEN pn := 1; END IF;
    IF TG_OP IN ('DELETE', 'UPDATE') AND OLD.status = 'published' THEN po := 1; END IF;
    IF TG_OP = 'UPDATE' AND OLD.folder_id = NEW.folder_id AND pn = po THEN RETURN NULL; END IF;
    IF TG_OP IN ('DELETE', 'UPDATE') THEN
        UPDATE learn_folders SET items_count = items_count - 1, pub_count = pub_count - po WHERE id = OLD.folder_id;
    END IF;
    IF TG_OP IN ('INSERT', 'UPDATE') THEN
        UPDATE learn_folders SET items_count = items_count + 1, pub_count = pub_count + pn WHERE id = NEW.folder_id;
    END IF;
    RETURN NULL;
END $$;
CREATE TRIGGER learn_courses_cnt AFTER INSERT OR DELETE OR UPDATE OF folder_id, status ON learn_courses FOR EACH ROW EXECUTE FUNCTION learn_count_courses();
