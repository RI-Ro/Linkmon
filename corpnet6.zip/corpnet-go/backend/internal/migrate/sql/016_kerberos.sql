-- 040: Kerberos (SPNEGO) — переопределения настроек из админки и статус последних входов.
-- Одна строка (id = 1). NULL в настройке означает «взять значение из переменной окружения KRB5_*».
-- Секреты (keytab) в БД не хранятся: файл монтируется в контейнер, путь задаётся в KRB5_KEYTAB.
CREATE TABLE krb_settings (
    id             int PRIMARY KEY CHECK (id = 1),
    enabled        boolean,
    user_map       text CHECK (user_map IS NULL OR user_map IN ('sam', 'upn', 'auto')),
    auto_create    boolean,
    clock_skew_sec int CHECK (clock_skew_sec IS NULL OR clock_skew_sec BETWEEN 30 AND 3600),
    ok_count       bigint      NOT NULL DEFAULT 0,
    last_ok_at     timestamptz,
    last_ok_user   text        NOT NULL DEFAULT '',   -- principal последнего успешного входа
    last_ok_ip     text        NOT NULL DEFAULT '',
    last_error_at  timestamptz,
    last_error     text        NOT NULL DEFAULT '',   -- причина последнего отказа (для диагностики; клиенту не показывается)
    updated_at     timestamptz NOT NULL DEFAULT now()
);
INSERT INTO krb_settings (id) VALUES (1);
