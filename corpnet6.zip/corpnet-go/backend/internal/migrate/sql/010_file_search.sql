-- 010: полнотекстовый поиск по содержимому файлов.
-- file_texts — очередь извлечения текста и сам индекс: одна строка на файл (files.id). Воркер (filesearch.go) берёт
-- пачки через FOR UPDATE SKIP LOCKED, поэтому любое число экземпляров/ЦОДов работает без дублей.
-- Конфигурация 'simple' (без стемминга), как и поиск по новостям; запросы — префиксные (слово:*).
CREATE TABLE file_texts (
    file_id      bigint PRIMARY KEY REFERENCES files(id) ON DELETE CASCADE,
    status       text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','done','failed','unsupported')),
    text         text NOT NULL DEFAULT '',            -- извлечённый текст (до ~1 МБ), нужен для сниппетов ts_headline
    tsv          tsvector,                            -- to_tsvector('simple', text); NULL, пока текста нет
    size         int NOT NULL DEFAULT 0,              -- длина text в байтах
    attempts     int NOT NULL DEFAULT 0,
    next_try_at  timestamptz NOT NULL DEFAULT now(),  -- не раньше (ретраи с backoff)
    locked_until timestamptz,                         -- аренда задачи воркером (защита от падения посреди работы)
    extracted_at timestamptz,
    error        text NOT NULL DEFAULT ''
);
CREATE INDEX file_texts_tsv ON file_texts USING gin (tsv);
CREATE INDEX file_texts_queue ON file_texts (next_try_at, file_id) WHERE status = 'pending';
CREATE INDEX file_texts_failed ON file_texts (file_id DESC) WHERE status = 'failed';

-- любой новый файл (документы, вложения новостей/комментариев/чатов, обучение, галереи …) попадает в очередь;
-- изображения/видео/аудио сразу помечаются как не поддерживаемые (в них нечего извлекать)
CREATE FUNCTION file_texts_enqueue() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF NEW.storage <> '' AND NEW.external_url = '' THEN
        INSERT INTO file_texts (file_id, status)
        VALUES (NEW.id, CASE WHEN NEW.mime LIKE 'image/%' OR NEW.mime LIKE 'video/%' OR NEW.mime LIKE 'audio/%' THEN 'unsupported' ELSE 'pending' END)
        ON CONFLICT (file_id) DO NOTHING;
    END IF;
    RETURN NULL;
END $$;
CREATE TRIGGER files_enqueue_text AFTER INSERT ON files FOR EACH ROW EXECUTE FUNCTION file_texts_enqueue();
