-- 012: аналитика для администратора — охват и вовлечение, поиск, аудитория, разделы.
-- Принцип: горячие пути (просмотр новости, поиск, переходы по страницам) пишут только в Redis или в буферизованную
-- очередь процесса; в PostgreSQL данные попадают пачками из фоновых задач (analytics.go). Отчёты читают rollup-таблицы.

-- ---- поиск -----------------------------------------------------------------------------------------------
-- Сырой журнал запросов. id генерирует приложение (монотонный, без обращения к sequence в горячем пути).
-- Хранится analytics_retention_days дней (ANALYTICS_RETENTION_DAYS, по умолчанию 400), чистится пакетами.
CREATE TABLE search_log (
    id            bigint PRIMARY KEY,
    user_id       bigint,                                   -- без FK: запись должна быть дешёвой; удалённые пользователи остаются в агрегатах
    scope         text   NOT NULL,                          -- global | news | people | groups | ideas | photos | videos | vacations | learning | …
    query         text   NOT NULL,                          -- как ввёл пользователь (обрезан до 200 символов)
    normalized    text   NOT NULL,                          -- нижний регистр, ё→е, схлопнутые пробелы
    results_count int    NOT NULL DEFAULT 0,
    took_ms       int    NOT NULL DEFAULT 0,
    clicked       boolean NOT NULL DEFAULT false,           -- был переход по результату
    click_entity  text   NOT NULL DEFAULT '',               -- например news:12, user:7
    created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX search_log_time ON search_log (created_at);
CREATE INDEX search_log_norm ON search_log (normalized, created_at);          -- «кто искал» по запросу (только админ)
CREATE INDEX search_log_open ON search_log (user_id, created_at DESC) WHERE NOT clicked;  -- привязка клика к запросу

-- Дневной rollup по запросам. Хранятся только повторяющиеся (searches >= 2) и нулевые запросы дня: одиночные запросы
-- с результатом — шум «длинного хвоста», на топы не влияют. Полные счётчики дня (с хвостом) — в stats_daily (search_*).
CREATE TABLE search_daily (
    day        date   NOT NULL,
    scope      text   NOT NULL,
    normalized text   NOT NULL,
    searches   int    NOT NULL,
    zero       int    NOT NULL DEFAULT 0,                   -- запросов без результатов
    noclick    int    NOT NULL DEFAULT 0,                   -- с результатами, но без перехода
    clicks     int    NOT NULL DEFAULT 0,
    users      int    NOT NULL DEFAULT 0,                   -- различных пользователей за день
    took_ms    bigint NOT NULL DEFAULT 0,                   -- сумма времени ответа
    sample     text   NOT NULL DEFAULT '',                  -- как запрос писали чаще всего (для показа)
    PRIMARY KEY (day, scope, normalized)
);
CREATE INDEX search_daily_zero ON search_daily (day) WHERE zero > 0;

-- Отметка администратора «обработано» для запросов без результатов (добавлен контент / синоним).
CREATE TABLE search_resolved (
    normalized  text PRIMARY KEY,
    resolved_by bigint,
    resolved_at timestamptz NOT NULL DEFAULT now(),
    note        text NOT NULL DEFAULT ''
);

-- ---- активность ------------------------------------------------------------------------------------------
-- Кто был активен в день (upsert не чаще раза в несколько минут на пользователя — дедуп в Redis).
CREATE TABLE user_daily_activity (
    day        date   NOT NULL,
    user_id    bigint NOT NULL,
    first_seen timestamptz NOT NULL DEFAULT now(),
    hits       int    NOT NULL DEFAULT 1,
    PRIMARY KEY (day, user_id)
);

-- Универсальные дневные метрики. dc — ЦОД, записавший счётчик: каждый ЦОД прибавляет только к своей строке
-- (никаких конфликтов между ЦОДами и повторов), при чтении значения суммируются по dc. Абсолютные значения,
-- пересчитываемые из PG (dau, wau, mau, лайки, комментарии, сообщения…), пишутся с dc = ''.
CREATE TABLE stats_daily (
    day    date   NOT NULL,
    metric text   NOT NULL,
    dim    text   NOT NULL DEFAULT '',
    dc     text   NOT NULL DEFAULT '',
    value  bigint NOT NULL DEFAULT 0,
    PRIMARY KEY (day, metric, dim, dc)
);
CREATE INDEX stats_daily_metric ON stats_daily (metric, day);

-- ---- новости ---------------------------------------------------------------------------------------------
ALTER TABLE news ADD COLUMN uniq_views int NOT NULL DEFAULT 0;   -- уникальные просмотревшие (сумма news_views)

-- Кто хоть раз открывал новость. Нужна, чтобы считать именно уникальных читателей; пишется пачкой из Redis-множества.
CREATE TABLE news_views (
    news_id   bigint NOT NULL REFERENCES news(id) ON DELETE CASCADE,
    user_id   bigint NOT NULL,
    viewed_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (news_id, user_id)
);
-- Читатели новости по подразделениям (dept_id = 0 — без подразделения).
CREATE TABLE news_dept_views (
    news_id bigint NOT NULL REFERENCES news(id) ON DELETE CASCADE,
    dept_id bigint NOT NULL,
    viewers int    NOT NULL DEFAULT 0,
    PRIMARY KEY (news_id, dept_id)
);
CREATE INDEX news_dept_views_dept ON news_dept_views (dept_id);

CREATE TABLE news_stats_daily (
    news_id    bigint NOT NULL REFERENCES news(id) ON DELETE CASCADE,
    day        date   NOT NULL,
    views      int    NOT NULL DEFAULT 0,    -- просмотры (с дедупликацией 30 минут на пользователя)
    uniq_views int    NOT NULL DEFAULT 0,    -- новые уникальные читатели за день
    likes      int    NOT NULL DEFAULT 0,
    comments   int    NOT NULL DEFAULT 0,
    PRIMARY KEY (news_id, day)
);
CREATE INDEX news_stats_daily_day ON news_stats_daily (day, news_id);

-- Индексы под пересчёт «сегодня/вчера» из первичных таблиц: BRIN крошечные и почти не стоят записи.
-- «лайки» живут в likes (до миграции 009) или в reactions (после): индексируем то, что есть; остальное (закладки,
-- упоминания, заявки, обучение, wiki) создаёт фоновая задача аналитики, когда эти таблицы появятся.
DO $$
BEGIN
    IF to_regclass('public.reactions') IS NOT NULL THEN
        CREATE INDEX IF NOT EXISTS reactions_created_brin ON reactions USING brin (created_at);
    ELSIF to_regclass('public.likes') IS NOT NULL THEN
        CREATE INDEX IF NOT EXISTS likes_created_brin ON likes USING brin (created_at);
    END IF;
END $$;
CREATE INDEX IF NOT EXISTS comments_created_brin ON comments USING brin (created_at);
CREATE INDEX IF NOT EXISTS messages_created_brin ON messages USING brin (created_at);
CREATE INDEX IF NOT EXISTS poll_votes_voted_brin ON poll_votes USING brin (voted_at);
CREATE INDEX IF NOT EXISTS group_posts_created_brin ON group_posts USING brin (created_at);
CREATE INDEX IF NOT EXISTS ideas_created_brin ON ideas USING brin (created_at);
CREATE INDEX IF NOT EXISTS users_created_brin ON users USING brin (created_at);
