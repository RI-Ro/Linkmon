-- 003: новости — окно показа, скрытие, галереи, поиск без стемминга, индексы под миллионы записей

ALTER TABLE news
    ADD COLUMN visible_until timestamptz,                    -- NULL = показывать бессрочно
    ADD COLUMN hidden        boolean NOT NULL DEFAULT false, -- «скрыть с публикации»
    ADD COLUMN announced     boolean NOT NULL DEFAULT true;  -- разослано ли уведомление о публикации

-- Старый индекс по русской морфологии давал ложные совпадения («иии» находил что угодно).
-- Новый: конфигурация 'simple' (без стемминга и стоп-слов) + триграммы по заголовку.
ALTER TABLE news DROP COLUMN search;
ALTER TABLE news ADD COLUMN search_simple tsvector GENERATED ALWAYS AS (
    to_tsvector('simple', coalesce(title, '') || ' ' || coalesce(summary, '') || ' ' || coalesce(body, ''))) STORED;

DROP INDEX IF EXISTS news_feed, news_important, news_category, news_direction, news_department;
CREATE INDEX news_stream    ON news (published_at DESC, id DESC) WHERE status = 'published' AND NOT hidden;
CREATE INDEX news_pinned    ON news (published_at DESC, id DESC) WHERE pinned AND status = 'published' AND NOT hidden;
CREATE INDEX news_important ON news (published_at DESC, id DESC) WHERE important AND status = 'published' AND NOT hidden;
CREATE INDEX news_cat       ON news (category_id, published_at DESC, id DESC) WHERE status = 'published' AND NOT hidden;
CREATE INDEX news_dir       ON news (direction_id, published_at DESC, id DESC) WHERE direction_id IS NOT NULL;
CREATE INDEX news_dept      ON news (department_id, published_at DESC, id DESC);
CREATE INDEX news_author    ON news (author_id, id DESC);
CREATE INDEX news_announce  ON news (published_at) WHERE NOT announced AND status = 'published' AND NOT hidden;
CREATE INDEX news_title_trgm ON news USING gin (lower(title) gin_trgm_ops);
CREATE INDEX news_fts       ON news USING gin (search_simple);

-- ссылки на фото/видео галереи внутри новости
CREATE TABLE news_galleries (
    id        bigserial PRIMARY KEY,
    news_id   bigint NOT NULL REFERENCES news(id) ON DELETE CASCADE,
    folder_id bigint NOT NULL REFERENCES folders(id) ON DELETE CASCADE,
    title     text   NOT NULL DEFAULT '',
    sort      int    NOT NULL DEFAULT 0
);
CREATE INDEX news_galleries_news ON news_galleries (news_id, sort, id);
CREATE INDEX news_galleries_folder ON news_galleries (folder_id);

-- ---- комментарии: вложенность до 5 уровней и вложения ------------------------
ALTER TABLE comments DROP CONSTRAINT comments_entity_type_check;
ALTER TABLE comments ADD CONSTRAINT comments_entity_type_check CHECK (entity_type IN ('news','post','idea'));
ALTER TABLE likes DROP CONSTRAINT likes_entity_type_check;
ALTER TABLE likes ADD CONSTRAINT likes_entity_type_check CHECK (entity_type IN ('news','post','idea'));
ALTER TABLE comments
    ADD COLUMN depth   smallint NOT NULL DEFAULT 0 CHECK (depth BETWEEN 0 AND 5),
    ADD COLUMN root_id bigint;
UPDATE comments SET root_id = id WHERE parent_id IS NULL;
UPDATE comments SET root_id = parent_id WHERE parent_id IS NOT NULL AND root_id IS NULL;
DROP INDEX comments_entity;
CREATE INDEX comments_roots ON comments (entity_type, entity_id, id) WHERE parent_id IS NULL;
CREATE INDEX comments_root  ON comments (root_id, id);
CREATE INDEX comments_user  ON comments (user_id, id DESC);

ALTER TABLE files DROP CONSTRAINT files_context_check;
ALTER TABLE files ADD CONSTRAINT files_context_check CHECK (context IN ('folder','chat','news','comment'));
CREATE TABLE comment_files (
    comment_id bigint NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
    file_id    bigint NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    PRIMARY KEY (comment_id, file_id)
);
CREATE INDEX comment_files_file ON comment_files (file_id);
CREATE INDEX files_owner_ctx ON files (owner_id, context, id DESC) WHERE context <> 'folder';

-- ---- уведомления: страницы по непрочитанным / прочитанным ---------------------
DROP INDEX notifications_user, notifications_unread;
CREATE INDEX notifications_unread ON notifications (user_id, id DESC) WHERE read_at IS NULL;
CREATE INDEX notifications_read   ON notifications (user_id, id DESC) WHERE read_at IS NOT NULL;
CREATE INDEX notifications_old    ON notifications (created_at) WHERE read_at IS NOT NULL;
