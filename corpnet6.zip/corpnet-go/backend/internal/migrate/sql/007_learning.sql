-- 007: раздел «Обучение» — материалы (папки, права, файлы, прогресс) и тесты (вопросы, попытки)

-- вложения материалов и картинки вопросов хранятся в files с context = 'learning'
DO $$
DECLARE d text;
BEGIN
    SELECT pg_get_constraintdef(oid) INTO d FROM pg_constraint WHERE conrelid = 'files'::regclass AND conname = 'files_context_check';
    IF d IS NOT NULL AND d NOT LIKE '%''learning''%' THEN
        ALTER TABLE files DROP CONSTRAINT files_context_check;
        EXECUTE 'ALTER TABLE files ADD CONSTRAINT files_context_check ' || replace(d, '''comment''::text', '''comment''::text, ''learning''::text');
    END IF;
END $$;

-- ---- папки (общие для материалов и тестов; дерево любой вложенности) ------------------------------
CREATE TABLE learn_folders (
    id          bigserial PRIMARY KEY,
    kind        text   NOT NULL CHECK (kind IN ('materials', 'tests')),
    parent_id   bigint REFERENCES learn_folders(id) ON DELETE CASCADE,
    name        text   NOT NULL,
    description text   NOT NULL DEFAULT '',
    visibility  text   NOT NULL DEFAULT 'company' CHECK (visibility IN ('company', 'restricted')),
    owner_id    bigint REFERENCES users(id) ON DELETE SET NULL,
    sort        int    NOT NULL DEFAULT 0,
    items_count int    NOT NULL DEFAULT 0,   -- материалов / тестов прямо в папке (поддерживается триггером)
    pub_count   int    NOT NULL DEFAULT 0,   -- из них видимых всем (опубликованные тесты)
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX learn_folders_parent ON learn_folders (kind, parent_id, sort, lower(name));
CREATE INDEX learn_folders_parent_id ON learn_folders (parent_id);
CREATE INDEX learn_folders_owner ON learn_folders (owner_id) WHERE owner_id IS NOT NULL;

-- права на папку: уровень 1 просмотр, 3 редактирование (материалы, тесты, результаты), 4 управление (права, удаление)
-- действуют на всю поддерево; для подразделений — на сотрудников подразделения и всех дочерних
CREATE TABLE learn_acl (
    folder_id    bigint   NOT NULL REFERENCES learn_folders(id) ON DELETE CASCADE,
    subject_type text     NOT NULL CHECK (subject_type IN ('user', 'department')),
    subject_id   bigint   NOT NULL,
    level        smallint NOT NULL CHECK (level BETWEEN 1 AND 4),
    PRIMARY KEY (folder_id, subject_type, subject_id)
);
CREATE INDEX learn_acl_subject ON learn_acl (subject_type, subject_id);

-- Эффективный уровень доступа пользователя к папке (0 — нет доступа).
--   • администратор — 4;
--   • «ограниченная» папка задаёт свой список доступа для себя и всех вложенных «общих» папок
--     (ближайшая ограниченная папка вверх по цепочке); если такой нет — видно всем (уровень 1);
--   • права редактирования/управления (>=3) и владение папкой передаются вниз по всему поддереву.
CREATE FUNCTION learn_level(fid bigint, uid bigint, dept bigint, adm boolean) RETURNS int
LANGUAGE sql STABLE AS $$
WITH RECURSIVE up AS (
    SELECT id, parent_id, visibility, owner_id, 0 AS d FROM learn_folders WHERE id = fid
    UNION ALL
    SELECT p.id, p.parent_id, p.visibility, p.owner_id, up.d + 1 FROM learn_folders p JOIN up ON p.id = up.parent_id
), dc AS (
    SELECT id, parent_id FROM departments WHERE id = dept
    UNION ALL
    SELECT x.id, x.parent_id FROM departments x JOIN dc ON x.id = dc.parent_id
), n AS (
    SELECT up.d, up.visibility, greatest(
        coalesce((SELECT max(a.level) FROM learn_acl a WHERE a.folder_id = up.id AND
            ((a.subject_type = 'user' AND a.subject_id = uid) OR (a.subject_type = 'department' AND a.subject_id IN (SELECT id FROM dc)))), 0),
        CASE WHEN up.owner_id = uid THEN 4 ELSE 0 END) AS own
    FROM up
)
SELECT CASE WHEN NOT EXISTS (SELECT 1 FROM up) THEN 0
            WHEN adm THEN 4
            ELSE greatest(coalesce((SELECT max(own) FROM n WHERE own >= 3), 0),
                          coalesce((SELECT own FROM n WHERE visibility = 'restricted' ORDER BY d LIMIT 1), 1)) END
$$;

-- ---- материалы -----------------------------------------------------------------------------------
CREATE TABLE learn_items (
    id          bigserial PRIMARY KEY,
    folder_id   bigint NOT NULL REFERENCES learn_folders(id) ON DELETE CASCADE,
    kind        text   NOT NULL DEFAULT 'text' CHECK (kind IN ('text', 'file', 'video', 'link')),
    title       text   NOT NULL,
    description text   NOT NULL DEFAULT '',
    body        text   NOT NULL DEFAULT '',       -- markdown
    url         text   NOT NULL DEFAULT '',       -- внешняя ссылка / видео по ссылке
    tags        text[] NOT NULL DEFAULT '{}',
    sort        int    NOT NULL DEFAULT 0,
    views_count int    NOT NULL DEFAULT 0,
    author_id   bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX learn_items_folder ON learn_items (folder_id, sort, id);
CREATE INDEX learn_items_folder_new ON learn_items (folder_id, id DESC);
CREATE INDEX learn_items_folder_title ON learn_items (folder_id, lower(title), id);
CREATE INDEX learn_items_title_trgm ON learn_items USING gin (lower(title) gin_trgm_ops);
CREATE INDEX learn_items_title_c ON learn_items ((lower(title) COLLATE "C"), id);   -- короткий поиск: префикс + порядок по индексу
CREATE INDEX learn_items_tags ON learn_items USING gin (tags);

CREATE TABLE learn_item_files (
    item_id bigint NOT NULL REFERENCES learn_items(id) ON DELETE CASCADE,
    file_id bigint NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    sort    int    NOT NULL DEFAULT 0,
    PRIMARY KEY (item_id, file_id)
);
CREATE INDEX learn_item_files_file ON learn_item_files (file_id);

-- прогресс пользователя: когда открывал, когда отметил «изучено»
CREATE TABLE learn_progress (
    user_id   bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    item_id   bigint NOT NULL REFERENCES learn_items(id) ON DELETE CASCADE,
    folder_id bigint NOT NULL,
    opened_at timestamptz NOT NULL DEFAULT now(),
    done_at   timestamptz,
    PRIMARY KEY (user_id, item_id)
);
CREATE INDEX learn_progress_recent ON learn_progress (user_id, opened_at DESC);
CREATE INDEX learn_progress_done ON learn_progress (user_id, folder_id) WHERE done_at IS NOT NULL;
CREATE INDEX learn_progress_item ON learn_progress (item_id);

-- ---- тесты ---------------------------------------------------------------------------------------
CREATE TABLE learn_tests (
    id                bigserial PRIMARY KEY,
    folder_id         bigint NOT NULL REFERENCES learn_folders(id) ON DELETE CASCADE,
    title             text   NOT NULL,
    description       text   NOT NULL DEFAULT '',
    status            text   NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
    pass_percent      int    NOT NULL DEFAULT 70 CHECK (pass_percent BETWEEN 0 AND 100),
    time_limit_min    int    CHECK (time_limit_min IS NULL OR time_limit_min > 0),
    max_attempts      int    CHECK (max_attempts IS NULL OR max_attempts > 0),
    shuffle_questions boolean NOT NULL DEFAULT false,
    shuffle_answers   boolean NOT NULL DEFAULT false,
    partial_credit    boolean NOT NULL DEFAULT false,   -- частичные баллы в вопросах с несколькими ответами
    show_answers      text   NOT NULL DEFAULT 'after_attempt' CHECK (show_answers IN ('never', 'after_attempt', 'after_finish')),
    available_from    timestamptz,
    available_to      timestamptz,
    sort              int    NOT NULL DEFAULT 0,
    questions_count   int    NOT NULL DEFAULT 0,
    max_score         numeric(8,2) NOT NULL DEFAULT 0,
    attempts_count    int    NOT NULL DEFAULT 0,        -- завершённых попыток
    passed_count      int    NOT NULL DEFAULT 0,
    sum_percent       double precision NOT NULL DEFAULT 0,
    author_id         bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX learn_tests_folder ON learn_tests (folder_id, sort, id);
CREATE INDEX learn_tests_title_trgm ON learn_tests USING gin (lower(title) gin_trgm_ops);
CREATE INDEX learn_tests_title_c ON learn_tests ((lower(title) COLLATE "C"), id);

CREATE TABLE learn_questions (
    id          bigserial PRIMARY KEY,
    test_id     bigint NOT NULL REFERENCES learn_tests(id) ON DELETE CASCADE,
    sort        int    NOT NULL DEFAULT 0,
    type        text   NOT NULL CHECK (type IN ('single', 'multiple', 'text')),
    text        text   NOT NULL,
    file_id     bigint REFERENCES files(id) ON DELETE SET NULL,
    data        jsonb  NOT NULL DEFAULT '{}',    -- {"options":[{"id":1,"text":"…","correct":true}]} | {"answers":["…"]}
    weight      numeric(6,2) NOT NULL DEFAULT 1 CHECK (weight > 0),
    explanation text   NOT NULL DEFAULT ''
);
CREATE INDEX learn_questions_test ON learn_questions (test_id, sort, id);
CREATE INDEX learn_questions_file ON learn_questions (file_id) WHERE file_id IS NOT NULL;

-- попытка: ответы и результат по вопросам лежат компактно в jsonb одной строки
CREATE TABLE learn_attempts (
    id           bigserial PRIMARY KEY,
    test_id      bigint NOT NULL REFERENCES learn_tests(id) ON DELETE CASCADE,
    user_id      bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    dept_id      bigint,                              -- подразделение пользователя на момент попытки
    no           int    NOT NULL,                     -- номер попытки пользователя в тесте
    seed         bigint NOT NULL,                     -- из него детерминированно строится порядок вопросов/ответов
    started_at   timestamptz NOT NULL DEFAULT now(),
    deadline     timestamptz,
    finished_at  timestamptz,
    expired      boolean NOT NULL DEFAULT false,      -- завершена по истечении времени
    answers      jsonb  NOT NULL DEFAULT '{}',        -- {"<id вопроса>": 3 | [1,2] | "текст"}
    details      jsonb,                               -- {"<id вопроса>": {"p": баллы, "m": максимум, "s": 0|1|2}}
    score        numeric(8,2),
    max_score    numeric(8,2),
    percent      numeric(5,1),
    passed       boolean,
    duration_sec int
);
CREATE UNIQUE INDEX learn_attempts_no ON learn_attempts (test_id, user_id, no);
CREATE UNIQUE INDEX learn_attempts_open ON learn_attempts (test_id, user_id) WHERE finished_at IS NULL;
CREATE INDEX learn_attempts_user ON learn_attempts (user_id, started_at DESC);
CREATE INDEX learn_attempts_test_done ON learn_attempts (test_id, finished_at DESC) WHERE finished_at IS NOT NULL;
CREATE INDEX learn_attempts_deadline ON learn_attempts (deadline) WHERE finished_at IS NULL AND deadline IS NOT NULL;

-- счётчики материалов/тестов в папке (items_count — всего, pub_count — видимых всем)
CREATE FUNCTION learn_count_items() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP = 'UPDATE' AND OLD.folder_id = NEW.folder_id THEN RETURN NULL; END IF;
    IF TG_OP IN ('DELETE', 'UPDATE') THEN
        UPDATE learn_folders SET items_count = items_count - 1, pub_count = pub_count - 1 WHERE id = OLD.folder_id;
    END IF;
    IF TG_OP IN ('INSERT', 'UPDATE') THEN
        UPDATE learn_folders SET items_count = items_count + 1, pub_count = pub_count + 1 WHERE id = NEW.folder_id;
    END IF;
    RETURN NULL;
END $$;
CREATE TRIGGER learn_items_cnt AFTER INSERT OR DELETE OR UPDATE OF folder_id ON learn_items FOR EACH ROW EXECUTE FUNCTION learn_count_items();

CREATE FUNCTION learn_count_tests() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE pn int := 0; po int := 0;
BEGIN
    IF TG_OP IN ('INSERT', 'UPDATE') AND NEW.status = 'published' THEN pn := 1; END IF;
    IF TG_OP IN ('DELETE', 'UPDATE') AND OLD.status = 'published' THEN po := 1; END IF;
    IF TG_OP = 'UPDATE' AND OLD.folder_id = NEW.folder_id AND pn = po THEN RETURN NULL; END IF;
    IF TG_OP IN ('DELETE', 'UPDATE') THEN
        UPDATE learn_folders SET items_count = items_count - 1, pub_count = pub_count - po WHERE id = OLD.folder_id;
    END IF;
    IF TG_OP IN ('INSERT', 'UPDATE') THEN
        UPDATE learn_folders SET items_count = items_count + 1, pub_count = pub_count + pn WHERE id = NEW.folder_id;
    END IF;
    RETURN NULL;
END $$;
CREATE TRIGGER learn_tests_cnt AFTER INSERT OR DELETE OR UPDATE OF folder_id, status ON learn_tests FOR EACH ROW EXECUTE FUNCTION learn_count_tests();

-- доступ к файлу обучения: владелец загрузки, вложение видимого материала, картинка вопроса доступного теста
CREATE FUNCTION learn_file_ok(fid bigint, uid bigint, dept bigint, adm boolean) RETURNS boolean
LANGUAGE sql STABLE AS $$
SELECT adm
    OR EXISTS (SELECT 1 FROM files f WHERE f.id = fid AND f.owner_id = uid)
    OR EXISTS (SELECT 1 FROM learn_item_files lf JOIN learn_items i ON i.id = lf.item_id
               WHERE lf.file_id = fid AND learn_level(i.folder_id, uid, dept, adm) > 0)
    OR EXISTS (SELECT 1 FROM learn_questions q JOIN learn_tests t ON t.id = q.test_id
               WHERE q.file_id = fid AND (learn_level(t.folder_id, uid, dept, adm) >= 3
                  OR (t.status = 'published' AND learn_level(t.folder_id, uid, dept, adm) > 0)))
$$;
