-- CorpNet: initial schema
CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TABLE departments (
    id          bigserial PRIMARY KEY,
    parent_id   bigint REFERENCES departments(id) ON DELETE SET NULL,
    name        text NOT NULL,
    description text NOT NULL DEFAULT '',
    image       text NOT NULL DEFAULT '',
    head_id     bigint,
    sort        int NOT NULL DEFAULT 0,
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX departments_parent ON departments(parent_id);

CREATE TABLE users (
    id            bigserial PRIMARY KEY,
    email         text NOT NULL,
    password_hash text NOT NULL,
    first_name    text NOT NULL,
    last_name     text NOT NULL,
    job_title     text NOT NULL DEFAULT '',
    department_id bigint REFERENCES departments(id) ON DELETE SET NULL,
    role          text NOT NULL DEFAULT 'user' CHECK (role IN ('admin','editor','user')),
    avatar        text NOT NULL DEFAULT '',
    phone         text NOT NULL DEFAULT '',
    birthday      date,
    about         text NOT NULL DEFAULT '',
    blocked       boolean NOT NULL DEFAULT false,
    last_seen     timestamptz,
    settings      jsonb NOT NULL DEFAULT '{}',
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX users_email_uq ON users (lower(email));
CREATE INDEX users_dept ON users(department_id);
CREATE INDEX users_name_trgm ON users USING gin (lower(first_name || ' ' || last_name) gin_trgm_ops);
CREATE INDEX users_bday ON users ((extract(month FROM birthday)::int), (extract(day FROM birthday)::int)) WHERE birthday IS NOT NULL;
ALTER TABLE departments ADD CONSTRAINT departments_head_fk FOREIGN KEY (head_id) REFERENCES users(id) ON DELETE SET NULL;

CREATE TABLE categories (
    id    serial PRIMARY KEY,
    name  text NOT NULL,
    color text NOT NULL DEFAULT '#286b9e',
    sort  int NOT NULL DEFAULT 0
);

CREATE TABLE directions (
    id          bigserial PRIMARY KEY,
    parent_id   bigint REFERENCES directions(id) ON DELETE CASCADE,
    name        text NOT NULL,
    description text NOT NULL DEFAULT '',
    cover       text NOT NULL DEFAULT '',
    sort        int NOT NULL DEFAULT 0,
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX directions_parent ON directions(parent_id);

CREATE TABLE news (
    id            bigserial PRIMARY KEY,
    title         text NOT NULL,
    summary       text NOT NULL DEFAULT '',
    body          text NOT NULL DEFAULT '',
    category_id   int REFERENCES categories(id) ON DELETE SET NULL,
    author_id     bigint REFERENCES users(id) ON DELETE SET NULL,
    cover         text NOT NULL DEFAULT '',
    important     boolean NOT NULL DEFAULT false,
    pinned        boolean NOT NULL DEFAULT false,
    status        text NOT NULL DEFAULT 'published' CHECK (status IN ('draft','published')),
    department_id bigint REFERENCES departments(id) ON DELETE SET NULL,
    direction_id  bigint REFERENCES directions(id) ON DELETE SET NULL,
    likes_count    int NOT NULL DEFAULT 0,
    comments_count int NOT NULL DEFAULT 0,
    views_count    int NOT NULL DEFAULT 0,
    published_at  timestamptz NOT NULL DEFAULT now(),
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now(),
    search        tsvector GENERATED ALWAYS AS (
        setweight(to_tsvector('russian', coalesce(title, '')), 'A') ||
        setweight(to_tsvector('russian', coalesce(summary, '')), 'B') ||
        setweight(to_tsvector('russian', coalesce(body, '')), 'C')
    ) STORED
);
CREATE INDEX news_feed ON news (status, pinned DESC, published_at DESC);
CREATE INDEX news_important ON news (published_at DESC) WHERE important AND status = 'published';
CREATE INDEX news_category ON news (category_id, published_at DESC);
CREATE INDEX news_direction ON news (direction_id) WHERE direction_id IS NOT NULL;
CREATE INDEX news_department ON news (department_id) WHERE department_id IS NOT NULL;
CREATE INDEX news_search ON news USING gin (search);

CREATE TABLE folders (
    id          bigserial PRIMARY KEY,
    kind        text NOT NULL CHECK (kind IN ('documents','photos','videos')),
    parent_id   bigint REFERENCES folders(id) ON DELETE CASCADE,
    name        text NOT NULL,
    description text NOT NULL DEFAULT '',
    cover       text NOT NULL DEFAULT '',
    visibility  text NOT NULL DEFAULT 'company' CHECK (visibility IN ('company','restricted')),
    owner_id    bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX folders_parent ON folders (kind, parent_id);

CREATE TABLE files (
    id           bigserial PRIMARY KEY,
    folder_id    bigint REFERENCES folders(id) ON DELETE CASCADE,
    owner_id     bigint REFERENCES users(id) ON DELETE SET NULL,
    name         text NOT NULL,
    mime         text NOT NULL DEFAULT 'application/octet-stream',
    size         bigint NOT NULL DEFAULT 0,
    storage      text NOT NULL DEFAULT '',
    thumb        text NOT NULL DEFAULT '',
    external_url text NOT NULL DEFAULT '',
    width        int NOT NULL DEFAULT 0,
    height       int NOT NULL DEFAULT 0,
    context      text NOT NULL DEFAULT 'folder' CHECK (context IN ('folder','chat','news')),
    created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX files_folder ON files (folder_id, id DESC) WHERE folder_id IS NOT NULL;
CREATE INDEX files_name_trgm ON files USING gin (lower(name) gin_trgm_ops);

CREATE TABLE news_files (
    news_id bigint NOT NULL REFERENCES news(id) ON DELETE CASCADE,
    file_id bigint NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    PRIMARY KEY (news_id, file_id)
);

-- Generic ACL for folders and calendars. level: 1=view 2=add 3=edit 4=owner
CREATE TABLE acl (
    resource_type text NOT NULL CHECK (resource_type IN ('folder','calendar')),
    resource_id   bigint NOT NULL,
    subject_type  text NOT NULL CHECK (subject_type IN ('user','department')),
    subject_id    bigint NOT NULL,
    level         smallint NOT NULL CHECK (level BETWEEN 1 AND 4),
    PRIMARY KEY (resource_type, resource_id, subject_type, subject_id)
);
CREATE INDEX acl_subject ON acl (subject_type, subject_id);

CREATE TABLE likes (
    entity_type text NOT NULL CHECK (entity_type IN ('news','post')),
    entity_id   bigint NOT NULL,
    user_id     bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (entity_type, entity_id, user_id)
);
CREATE INDEX likes_user ON likes (user_id, entity_type);

CREATE TABLE comments (
    id          bigserial PRIMARY KEY,
    entity_type text NOT NULL CHECK (entity_type IN ('news','post')),
    entity_id   bigint NOT NULL,
    user_id     bigint REFERENCES users(id) ON DELETE SET NULL,
    parent_id   bigint REFERENCES comments(id) ON DELETE CASCADE,
    body        text NOT NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    deleted_at  timestamptz
);
CREATE INDEX comments_entity ON comments (entity_type, entity_id, id);

CREATE TABLE chats (
    id              bigserial PRIMARY KEY,
    kind            text NOT NULL CHECK (kind IN ('direct','group')),
    title           text NOT NULL DEFAULT '',
    avatar          text NOT NULL DEFAULT '',
    created_by      bigint REFERENCES users(id) ON DELETE SET NULL,
    group_id        bigint,
    direct_key      text UNIQUE,
    last_message_id bigint,
    last_message_at timestamptz NOT NULL DEFAULT now(),
    created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE chat_members (
    chat_id      bigint NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    user_id      bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    last_read_id bigint NOT NULL DEFAULT 0,
    muted        boolean NOT NULL DEFAULT false,
    joined_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (chat_id, user_id)
);
CREATE INDEX chat_members_user ON chat_members (user_id);

CREATE TABLE messages (
    id         bigserial PRIMARY KEY,
    chat_id    bigint NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    user_id    bigint REFERENCES users(id) ON DELETE SET NULL,
    body       text NOT NULL DEFAULT '',
    file_id    bigint REFERENCES files(id) ON DELETE SET NULL,
    reply_to   bigint,
    client_id  text,
    created_at timestamptz NOT NULL DEFAULT now(),
    edited_at  timestamptz,
    deleted_at timestamptz
);
CREATE INDEX messages_chat ON messages (chat_id, id DESC);
CREATE UNIQUE INDEX messages_client ON messages (chat_id, user_id, client_id) WHERE client_id IS NOT NULL;
ALTER TABLE chats ADD CONSTRAINT chats_last_msg_fk FOREIGN KEY (last_message_id) REFERENCES messages(id) ON DELETE SET NULL;

CREATE TABLE user_groups (
    id          bigserial PRIMARY KEY,
    name        text NOT NULL,
    description text NOT NULL DEFAULT '',
    cover       text NOT NULL DEFAULT '',
    visibility  text NOT NULL DEFAULT 'public' CHECK (visibility IN ('public','closed')),
    owner_id    bigint REFERENCES users(id) ON DELETE SET NULL,
    chat_id     bigint REFERENCES chats(id) ON DELETE SET NULL,
    created_at  timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE chats ADD CONSTRAINT chats_group_fk FOREIGN KEY (group_id) REFERENCES user_groups(id) ON DELETE CASCADE;

CREATE TABLE group_members (
    group_id  bigint NOT NULL REFERENCES user_groups(id) ON DELETE CASCADE,
    user_id   bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role      text NOT NULL DEFAULT 'member' CHECK (role IN ('owner','member','pending')),
    joined_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (group_id, user_id)
);
CREATE INDEX group_members_user ON group_members (user_id);

CREATE TABLE group_posts (
    id             bigserial PRIMARY KEY,
    group_id       bigint NOT NULL REFERENCES user_groups(id) ON DELETE CASCADE,
    user_id        bigint REFERENCES users(id) ON DELETE SET NULL,
    body           text NOT NULL,
    image          text NOT NULL DEFAULT '',
    likes_count    int NOT NULL DEFAULT 0,
    comments_count int NOT NULL DEFAULT 0,
    created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX group_posts_group ON group_posts (group_id, id DESC);

CREATE TABLE calendars (
    id          bigserial PRIMARY KEY,
    name        text NOT NULL,
    description text NOT NULL DEFAULT '',
    kind        text NOT NULL DEFAULT 'custom' CHECK (kind IN ('personal','birthdays','conference','rooms','custom')),
    color       text NOT NULL DEFAULT '#286b9e',
    owner_id    bigint REFERENCES users(id) ON DELETE CASCADE,
    visibility  text NOT NULL DEFAULT 'company' CHECK (visibility IN ('company','restricted')),
    open_add    boolean NOT NULL DEFAULT false,
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX calendars_owner ON calendars (owner_id);

CREATE TABLE events (
    id          bigserial PRIMARY KEY,
    calendar_id bigint NOT NULL REFERENCES calendars(id) ON DELETE CASCADE,
    title       text NOT NULL,
    description text NOT NULL DEFAULT '',
    location    text NOT NULL DEFAULT '',
    starts_at   timestamptz NOT NULL,
    ends_at     timestamptz NOT NULL,
    all_day     boolean NOT NULL DEFAULT false,
    video_url   text NOT NULL DEFAULT '',
    creator_id  bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    CHECK (ends_at >= starts_at)
);
CREATE INDEX events_cal_time ON events (calendar_id, starts_at);
CREATE INDEX events_time ON events (starts_at);

CREATE TABLE event_attendees (
    event_id bigint NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    user_id  bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status   text NOT NULL DEFAULT 'invited' CHECK (status IN ('invited','accepted','declined')),
    PRIMARY KEY (event_id, user_id)
);
CREATE INDEX event_attendees_user ON event_attendees (user_id);

CREATE TABLE notifications (
    id         bigserial PRIMARY KEY,
    user_id    bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind       text NOT NULL,
    title      text NOT NULL,
    body       text NOT NULL DEFAULT '',
    link       text NOT NULL DEFAULT '',
    created_at timestamptz NOT NULL DEFAULT now(),
    read_at    timestamptz
);
CREATE INDEX notifications_user ON notifications (user_id, id DESC);
CREATE INDEX notifications_unread ON notifications (user_id) WHERE read_at IS NULL;

CREATE TABLE resources (
    id          bigserial PRIMARY KEY,
    name        text NOT NULL,
    description text NOT NULL DEFAULT '',
    url         text NOT NULL,
    icon        text NOT NULL DEFAULT 'link',
    sort        int NOT NULL DEFAULT 0
);

CREATE TABLE company (
    id         int PRIMARY KEY CHECK (id = 1),
    name       text NOT NULL DEFAULT 'ООО «КорпНэт»',
    tagline    text NOT NULL DEFAULT 'Корпоративная информационная система',
    about      text NOT NULL DEFAULT '',
    address    text NOT NULL DEFAULT '',
    phone      text NOT NULL DEFAULT '',
    email      text NOT NULL DEFAULT '',
    logo       text NOT NULL DEFAULT '',
    founded    int NOT NULL DEFAULT 2026
);
INSERT INTO company (id) VALUES (1);

CREATE TABLE audit_log (
    id         bigserial PRIMARY KEY,
    user_id    bigint REFERENCES users(id) ON DELETE SET NULL,
    action     text NOT NULL,
    entity     text NOT NULL DEFAULT '',
    entity_id  bigint,
    data       jsonb NOT NULL DEFAULT '{}',
    ip         text NOT NULL DEFAULT '',
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_created ON audit_log (id DESC);
