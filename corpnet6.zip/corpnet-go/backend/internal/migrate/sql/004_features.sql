-- 004: группы (открытые/закрытые/скрытые), чаты (очистка «для себя», голосования), календари (повторы),
--      баннеры, график отпусков, «Есть идея»

-- ---- группы --------------------------------------------------------------------
ALTER TABLE user_groups DROP CONSTRAINT user_groups_visibility_check;
ALTER TABLE user_groups ADD CONSTRAINT user_groups_visibility_check CHECK (visibility IN ('public','closed','secret'));
ALTER TABLE group_members DROP CONSTRAINT group_members_role_check;
ALTER TABLE group_members ADD CONSTRAINT group_members_role_check CHECK (role IN ('owner','admin','member','pending'));
CREATE INDEX user_groups_name ON user_groups (lower(name), id);
CREATE INDEX user_groups_listed ON user_groups (lower(name)) WHERE visibility <> 'secret';
CREATE INDEX group_members_role ON group_members (group_id, role);
CREATE INDEX group_posts_user ON group_posts (user_id);

-- ---- чаты ------------------------------------------------------------------------
-- cleared_before_id: «очистить у меня» (сообщения с id <= значения скрыты только для этого участника)
-- hidden: «удалить у меня» (чат исчезает из списка до следующего сообщения)
ALTER TABLE chat_members
    ADD COLUMN cleared_before_id bigint  NOT NULL DEFAULT 0,
    ADD COLUMN hidden            boolean NOT NULL DEFAULT false;
CREATE INDEX chat_members_visible ON chat_members (user_id) WHERE NOT hidden;

ALTER TABLE messages ADD COLUMN kind text NOT NULL DEFAULT 'text' CHECK (kind IN ('text','poll'));
CREATE TABLE polls (
    id         bigserial PRIMARY KEY,
    chat_id    bigint NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    message_id bigint REFERENCES messages(id) ON DELETE CASCADE,
    question   text   NOT NULL,
    multiple   boolean NOT NULL DEFAULT false,
    created_by bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    closed_at  timestamptz,
    closed_by  bigint REFERENCES users(id) ON DELETE SET NULL
);
CREATE UNIQUE INDEX polls_message ON polls (message_id);
CREATE INDEX polls_chat ON polls (chat_id);
CREATE TABLE poll_options (
    id      bigserial PRIMARY KEY,
    poll_id bigint NOT NULL REFERENCES polls(id) ON DELETE CASCADE,
    text    text   NOT NULL,
    sort    int    NOT NULL DEFAULT 0
);
CREATE INDEX poll_options_poll ON poll_options (poll_id, sort, id);
CREATE TABLE poll_votes (
    poll_id   bigint NOT NULL REFERENCES polls(id) ON DELETE CASCADE,
    option_id bigint NOT NULL REFERENCES poll_options(id) ON DELETE CASCADE,
    user_id   bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    voted_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (poll_id, option_id, user_id)
);
CREATE INDEX poll_votes_user ON poll_votes (poll_id, user_id);

-- ---- календари --------------------------------------------------------------------
DELETE FROM calendars WHERE kind = 'rooms';
ALTER TABLE calendars DROP CONSTRAINT calendars_kind_check;
ALTER TABLE calendars ADD CONSTRAINT calendars_kind_check CHECK (kind IN ('personal','birthdays','conference','custom'));
CREATE UNIQUE INDEX calendars_personal_uq ON calendars (owner_id) WHERE kind = 'personal';
UPDATE calendars SET name = 'Мероприятия' WHERE name = 'Корпоративные мероприятия';
UPDATE categories SET name = 'Мероприятия' WHERE name = 'Корпоративные мероприятия';

-- повторяющиеся события (день города, день Победы и т.п.)
ALTER TABLE events
    ADD COLUMN rec_freq     text NOT NULL DEFAULT 'none' CHECK (rec_freq IN ('none','daily','weekly','monthly','yearly')),
    ADD COLUMN rec_interval int  NOT NULL DEFAULT 1 CHECK (rec_interval BETWEEN 1 AND 100),
    ADD COLUMN rec_until    timestamptz;
CREATE INDEX events_recurring ON events (starts_at) WHERE rec_freq <> 'none';
CREATE INDEX events_ends ON events (ends_at) WHERE rec_freq = 'none';

-- ---- баннеры на главной --------------------------------------------------------------
CREATE TABLE banners (
    id         bigserial PRIMARY KEY,
    title      text NOT NULL,
    text       text NOT NULL DEFAULT '',
    image      text NOT NULL DEFAULT '',
    video_url  text NOT NULL DEFAULT '',
    link       text NOT NULL DEFAULT '',      -- внутренний путь (/news/5, /groups/2 …) или https://…
    link_label text NOT NULL DEFAULT 'Подробнее',
    sort       int  NOT NULL DEFAULT 0,
    active     boolean NOT NULL DEFAULT true,
    starts_at  timestamptz,
    ends_at    timestamptz,
    created_by bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX banners_active ON banners (sort, id) WHERE active;

-- ---- график отпусков руководящего состава ----------------------------------------------
CREATE TABLE vacations (
    id         bigserial PRIMARY KEY,
    user_id    bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    starts_on  date   NOT NULL,
    ends_on    date   NOT NULL,
    deputy_id  bigint REFERENCES users(id) ON DELETE SET NULL,
    city       text   NOT NULL DEFAULT '',
    note       text   NOT NULL DEFAULT '',
    created_by bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK (ends_on >= starts_on)
);
CREATE INDEX vacations_period ON vacations (ends_on, starts_on);
CREATE INDEX vacations_user ON vacations (user_id, starts_on DESC);

-- ---- «Есть идея» -----------------------------------------------------------------------
CREATE TABLE ideas (
    id             bigserial PRIMARY KEY,
    title          text NOT NULL,
    body           text NOT NULL DEFAULT '',
    author_id      bigint REFERENCES users(id) ON DELETE SET NULL,
    status         text NOT NULL DEFAULT 'new' CHECK (status IN ('new','review','accepted','done','declined')),
    likes_count    int NOT NULL DEFAULT 0,
    comments_count int NOT NULL DEFAULT 0,
    views_count    int NOT NULL DEFAULT 0,
    created_at     timestamptz NOT NULL DEFAULT now(),
    updated_at     timestamptz NOT NULL DEFAULT now(),
    search_simple  tsvector GENERATED ALWAYS AS (to_tsvector('simple', coalesce(title, '') || ' ' || coalesce(body, ''))) STORED
);
CREATE INDEX ideas_stream ON ideas (id DESC);
CREATE INDEX ideas_status ON ideas (status, id DESC);
CREATE INDEX ideas_popular ON ideas (likes_count DESC, id DESC);
CREATE INDEX ideas_author ON ideas (author_id, id DESC);
CREATE INDEX ideas_fts ON ideas USING gin (search_simple);
CREATE INDEX ideas_title_trgm ON ideas USING gin (lower(title) gin_trgm_ops);
CREATE INDEX departments_name_trgm ON departments USING gin (lower(name) gin_trgm_ops);
CREATE INDEX user_groups_name_trgm ON user_groups USING gin (lower(name) gin_trgm_ops);
