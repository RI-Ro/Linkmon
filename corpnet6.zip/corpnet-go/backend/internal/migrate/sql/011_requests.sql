-- 011: раздел «Заявки» — конструктор форм (типы, версии схем, маршруты согласования), заявки, шаги, исполнители, журнал.
--
-- Модель:
--   req_types          тип заявки (метаданные, маска нумерации, SLA по умолчанию, область: подразделение-владелец)
--   req_type_versions  НЕИЗМЕНЯЕМЫЕ версии схемы формы и маршрута; заявка ссылается на версию, на которую подана (снимок)
--   req_acl            кто подаёт / владеет (редактирует тип) / ответственные / наблюдатели (subject: все, пользователь, подразделение
--                      с наследованием вниз, группа, роль)
--   req_counters       независимые счётчики нумерации (type_id, период) — инкремент атомарным UPDATE … RETURNING
--   req_requests       заявки; req_steps — активированные шаги маршрута; req_assignees — исполнители шагов («на мне»)
--   req_events         журнал: решения, комментарии, переходы; req_files — вложения заявки и комментариев

-- вложения заявок хранятся в files с context = 'request'
DO $$
DECLARE d text;
BEGIN
    SELECT pg_get_constraintdef(oid) INTO d FROM pg_constraint WHERE conrelid = 'files'::regclass AND conname = 'files_context_check';
    IF d IS NOT NULL AND d NOT LIKE '%''request''%' THEN
        ALTER TABLE files DROP CONSTRAINT files_context_check;
        EXECUTE 'ALTER TABLE files ADD CONSTRAINT files_context_check ' || replace(d, '''comment''::text', '''comment''::text, ''request''::text');
    END IF;
END $$;

CREATE TABLE req_categories (
    id         bigserial PRIMARY KEY,
    name       text NOT NULL,
    icon       text NOT NULL DEFAULT 'file',
    color      text NOT NULL DEFAULT '#286b9e',
    sort       int  NOT NULL DEFAULT 0,
    created_by bigint REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE req_types (
    id            bigserial PRIMARY KEY,
    category_id   bigint REFERENCES req_categories(id) ON DELETE SET NULL,
    code          text   NOT NULL DEFAULT '',
    name          text   NOT NULL,
    description   text   NOT NULL DEFAULT '',        -- markdown
    icon          text   NOT NULL DEFAULT 'file',
    color         text   NOT NULL DEFAULT '#286b9e',
    number_mask   text   NOT NULL DEFAULT 'ЗАЯ-{YYYY}-{NNNNNN}',
    sla_value     int    NOT NULL DEFAULT 0 CHECK (sla_value >= 0),     -- SLA шага по умолчанию (0 — без срока)
    sla_unit      text   NOT NULL DEFAULT 'wd' CHECK (sla_unit IN ('h', 'wh', 'd', 'wd')),
    remind_before_h int  NOT NULL DEFAULT 4 CHECK (remind_before_h >= 0),
    active        boolean NOT NULL DEFAULT true,      -- опубликован: можно подавать
    archived      boolean NOT NULL DEFAULT false,
    department_id bigint REFERENCES departments(id) ON DELETE SET NULL,   -- область редакторов (scope.go)
    created_by    bigint REFERENCES users(id) ON DELETE SET NULL,
    cur_version   bigint,
    sort          int    NOT NULL DEFAULT 0,
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX req_types_cat ON req_types (category_id, sort, lower(name)) WHERE NOT archived;
CREATE INDEX req_types_dept ON req_types (department_id) WHERE department_id IS NOT NULL;
CREATE INDEX req_types_creator ON req_types (created_by);

CREATE TABLE req_type_versions (
    id         bigserial PRIMARY KEY,
    type_id    bigint NOT NULL REFERENCES req_types(id) ON DELETE CASCADE,
    version    int    NOT NULL,
    schema     jsonb  NOT NULL,
    workflow   jsonb  NOT NULL,
    note       text   NOT NULL DEFAULT '',
    created_by bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (type_id, version)
);
ALTER TABLE req_types ADD CONSTRAINT req_types_cur_version_fk FOREIGN KEY (cur_version) REFERENCES req_type_versions(id) DEFERRABLE INITIALLY DEFERRED;

-- kind: submit — кто подаёт; owner — кто редактирует тип; responsible — ответственные (видят все заявки, исполнители шагов
-- «ответственные типа»); watcher — наблюдатели (видят все заявки типа).
-- subject_type: all | user | department (со всеми дочерними) | group | role (subject_key: admin|editor|user|head)
CREATE TABLE req_acl (
    type_id      bigint NOT NULL REFERENCES req_types(id) ON DELETE CASCADE,
    kind         text   NOT NULL CHECK (kind IN ('submit', 'owner', 'responsible', 'watcher')),
    subject_type text   NOT NULL CHECK (subject_type IN ('all', 'user', 'department', 'group', 'role')),
    subject_id   bigint NOT NULL DEFAULT 0,
    subject_key  text   NOT NULL DEFAULT '',
    PRIMARY KEY (type_id, kind, subject_type, subject_id, subject_key)
);
CREATE INDEX req_acl_user ON req_acl (subject_type, subject_id) WHERE subject_type <> 'all';

CREATE TABLE req_counters (
    type_id bigint NOT NULL REFERENCES req_types(id) ON DELETE CASCADE,
    period  text   NOT NULL DEFAULT '',
    value   bigint NOT NULL DEFAULT 0,
    PRIMARY KEY (type_id, period)
);

CREATE TABLE req_requests (
    id           bigserial PRIMARY KEY,
    type_id      bigint NOT NULL REFERENCES req_types(id) ON DELETE RESTRICT,
    version_id   bigint NOT NULL REFERENCES req_type_versions(id) ON DELETE RESTRICT,
    number       text,                         -- присваивается при подаче (у черновика нет)
    client_id    text,                         -- идемпотентность подачи (двойной клик)
    author_id    bigint REFERENCES users(id) ON DELETE SET NULL,
    dept_id      bigint,                       -- подразделение заявителя на момент подачи
    status       text   NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'pending', 'rework', 'rejected', 'approved', 'in_progress', 'done', 'cancelled')),
    title        text   NOT NULL DEFAULT '',
    search_text  text   NOT NULL DEFAULT '',
    data         jsonb  NOT NULL DEFAULT '{}',
    cur_step     int    NOT NULL DEFAULT -1,   -- индекс шага маршрута (по версии)
    round        int    NOT NULL DEFAULT 1,    -- номер круга согласования (растёт после доработки)
    decisions    int    NOT NULL DEFAULT 0,    -- решений согласующих/исполнителей (отмена заявителем — только при 0)
    info_by      bigint,                       -- кто запросил информацию у заявителя (ожидается ответ)
    due_at       timestamptz,
    created_at   timestamptz NOT NULL DEFAULT now(),
    submitted_at timestamptz,
    updated_at   timestamptz NOT NULL DEFAULT now(),
    closed_at    timestamptz
);
CREATE UNIQUE INDEX req_requests_number ON req_requests (number) WHERE number IS NOT NULL;
CREATE UNIQUE INDEX req_requests_client ON req_requests (author_id, client_id) WHERE client_id IS NOT NULL;
CREATE INDEX req_requests_type_status ON req_requests (type_id, status, created_at DESC, id DESC);
CREATE INDEX req_requests_type_created ON req_requests (type_id, created_at DESC, id DESC);
CREATE INDEX req_requests_author ON req_requests (author_id, created_at DESC, id DESC) INCLUDE (status, type_id);
CREATE INDEX req_requests_version ON req_requests (version_id);
CREATE INDEX req_requests_search ON req_requests USING gin (search_text gin_trgm_ops);

CREATE TABLE req_steps (
    id          bigserial PRIMARY KEY,
    request_id  bigint NOT NULL REFERENCES req_requests(id) ON DELETE CASCADE,
    idx         int    NOT NULL,
    round       int    NOT NULL DEFAULT 1,
    key         text   NOT NULL DEFAULT '',
    name        text   NOT NULL,
    kind        text   NOT NULL CHECK (kind IN ('approve', 'execute', 'inform')),
    state       text   NOT NULL DEFAULT 'active' CHECK (state IN ('active', 'done', 'rejected', 'returned', 'skipped')),
    started_at  timestamptz NOT NULL DEFAULT now(),
    finished_at timestamptz
);
CREATE INDEX req_steps_req ON req_steps (request_id, round, idx);

CREATE TABLE req_assignees (
    id              bigserial PRIMARY KEY,
    request_id      bigint NOT NULL REFERENCES req_requests(id) ON DELETE CASCADE,
    step_id         bigint NOT NULL REFERENCES req_steps(id) ON DELETE CASCADE,
    branch          smallint NOT NULL DEFAULT 0,
    mode            text   NOT NULL DEFAULT 'any' CHECK (mode IN ('any', 'all', 'majority')),
    user_id         bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    state           text   NOT NULL DEFAULT 'pending' CHECK (state IN ('pending', 'approved', 'rejected', 'done', 'acked', 'returned', 'skipped', 'delegated')),
    via             text   NOT NULL DEFAULT 'direct',     -- direct | deputy | fallback | delegate | escalation | assigned
    orig_user_id    bigint,                                -- кого замещает / кто передал
    due_at          timestamptz,
    remind_at       timestamptz,
    remind_sent_at  timestamptz,
    overdue_sent_at timestamptz,
    escalated_at    timestamptz,
    esc_to          jsonb,                                 -- правило эскалации шага (копия)
    decided_at      timestamptz,
    comment         text   NOT NULL DEFAULT '',
    created_at      timestamptz NOT NULL DEFAULT now(),
    UNIQUE (step_id, user_id)
);
-- «На мне»: только ожидающие решения — индекс крошечный даже при миллионах заявок
CREATE INDEX req_assignees_inbox ON req_assignees (user_id, due_at NULLS LAST, request_id) WHERE state = 'pending';
CREATE INDEX req_assignees_user ON req_assignees (user_id, request_id DESC);
CREATE INDEX req_assignees_req ON req_assignees (request_id);
CREATE INDEX req_assignees_step ON req_assignees (step_id);
CREATE INDEX req_assignees_remind ON req_assignees (remind_at) WHERE state = 'pending' AND remind_sent_at IS NULL AND remind_at IS NOT NULL;
CREATE INDEX req_assignees_overdue ON req_assignees (due_at) WHERE state = 'pending' AND overdue_sent_at IS NULL AND due_at IS NOT NULL;

CREATE TABLE req_events (
    id         bigserial PRIMARY KEY,
    request_id bigint NOT NULL REFERENCES req_requests(id) ON DELETE CASCADE,
    step_id    bigint,
    actor_id   bigint REFERENCES users(id) ON DELETE SET NULL,
    kind       text   NOT NULL,
    text       text   NOT NULL DEFAULT '',
    data       jsonb  NOT NULL DEFAULT '{}',
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX req_events_req ON req_events (request_id, id);

CREATE TABLE req_files (
    file_id    bigint PRIMARY KEY REFERENCES files(id) ON DELETE CASCADE,
    request_id bigint NOT NULL REFERENCES req_requests(id) ON DELETE CASCADE,
    event_id   bigint REFERENCES req_events(id) ON DELETE CASCADE,
    field_key  text   NOT NULL DEFAULT ''
);
CREATE INDEX req_files_req ON req_files (request_id);

-- ---- права ----------------------------------------------------------------------------------------------------

-- пользователь uid входит в список k типа tid (подразделения — с наследованием вниз: достаточно, чтобы подразделение
-- пользователя лежало в поддереве указанного)
CREATE FUNCTION req_in_acl(tid bigint, k text, uid bigint) RETURNS boolean
LANGUAGE sql STABLE AS $$
SELECT EXISTS (
    SELECT 1 FROM req_acl a, users u
    WHERE a.type_id = tid AND a.kind = k AND u.id = uid AND NOT u.blocked AND (
        a.subject_type = 'all'
        OR (a.subject_type = 'user' AND a.subject_id = uid)
        OR (a.subject_type = 'role' AND (a.subject_key = u.role OR (a.subject_key = 'head' AND u.is_head)))
        OR (a.subject_type = 'group' AND EXISTS (SELECT 1 FROM group_members m WHERE m.group_id = a.subject_id AND m.user_id = uid AND m.role <> 'pending'))
        OR (a.subject_type = 'department' AND u.department_id IS NOT NULL AND EXISTS (
            WITH RECURSIVE up AS (SELECT id, parent_id FROM departments WHERE id = u.department_id
                                  UNION ALL SELECT d.id, d.parent_id FROM departments d JOIN up ON d.id = up.parent_id)
            SELECT 1 FROM up WHERE up.id = a.subject_id))
    ))
$$;

-- заявку видит: автор; ответственные и наблюдатели типа; исполнители, на чей шаг она приходила; администратор (кроме чужих черновиков)
CREATE FUNCTION req_can_view(rid bigint, uid bigint, adm boolean) RETURNS boolean
LANGUAGE sql STABLE AS $$
SELECT EXISTS (SELECT 1 FROM req_requests r WHERE r.id = rid AND (
    r.author_id = uid
    OR (r.status <> 'draft' AND (adm
        OR EXISTS (SELECT 1 FROM req_assignees a WHERE a.request_id = r.id AND a.user_id = uid)
        OR req_in_acl(r.type_id, 'responsible', uid) OR req_in_acl(r.type_id, 'watcher', uid)))))
$$;

-- доступ к файлу заявки: загрузивший; либо файл привязан к заявке, которую пользователь вправе видеть
CREATE FUNCTION req_file_ok(fid bigint, uid bigint, dept bigint, adm boolean) RETURNS boolean
LANGUAGE sql STABLE AS $$
SELECT EXISTS (SELECT 1 FROM files f WHERE f.id = fid AND f.owner_id = uid)
    OR EXISTS (SELECT 1 FROM req_files rf WHERE rf.file_id = fid AND req_can_view(rf.request_id, uid, adm))
$$;
