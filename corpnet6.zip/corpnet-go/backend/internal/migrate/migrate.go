// Package migrate applies embedded SQL migrations. It is safe to run from many
// app instances at once: every run is serialised with a Postgres advisory lock.
package migrate

import (
	"context"
	"embed"
	"fmt"
	"log/slog"
	"sort"
	"strings"

	"github.com/jackc/pgx/v5/pgxpool"
)

//go:embed sql/*.sql
var files embed.FS

const lockKey = 7243901

func Run(ctx context.Context, db *pgxpool.Pool, log *slog.Logger) error {
	tx, err := db.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	// Transaction-level advisory lock: other instances wait here until we commit.
	if _, err := tx.Exec(ctx, "SELECT pg_advisory_xact_lock($1)", int64(lockKey)); err != nil {
		return err
	}
	if _, err := tx.Exec(ctx, `CREATE TABLE IF NOT EXISTS schema_migrations (
		version text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())`); err != nil {
		return err
	}
	entries, err := files.ReadDir("sql")
	if err != nil {
		return err
	}
	names := make([]string, 0, len(entries))
	for _, e := range entries {
		names = append(names, e.Name())
	}
	sort.Strings(names)
	for _, n := range names {
		ver := strings.TrimSuffix(n, ".sql")
		var done bool
		if err := tx.QueryRow(ctx, "SELECT EXISTS(SELECT 1 FROM schema_migrations WHERE version=$1)", ver).Scan(&done); err != nil {
			return err
		}
		if done {
			continue
		}
		b, err := files.ReadFile("sql/" + n)
		if err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, string(b)); err != nil {
			return fmt.Errorf("migration %s: %w", n, err)
		}
		if _, err := tx.Exec(ctx, "INSERT INTO schema_migrations(version) VALUES($1)", ver); err != nil {
			return err
		}
		log.Info("migration applied", "version", ver)
	}
	return tx.Commit(ctx)
}
