package server

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

// ---------------------------------------------------------------- модель

type lcourse struct {
	ID             int64     `json:"id"`
	FolderID       int64     `json:"folder_id"`
	Title          string    `json:"title"`
	Description    string    `json:"description"`
	Cover          string    `json:"cover"`
	Tags           []string  `json:"tags"`
	Status         string    `json:"status"`
	EstMinutes     int       `json:"est_minutes"`
	OrderMode      string    `json:"order_mode"`
	PassPercent    int       `json:"pass_percent"`
	ValidityMonths int       `json:"validity_months"`
	MaxAttempts    *int      `json:"max_attempts"`
	Version        int       `json:"version"`
	CertTemplateID *int64    `json:"cert_template_id"`
	StepsCount     int       `json:"steps_count"`
	RequiredCount  int       `json:"required_count"`
	Sort           int       `json:"sort"`
	AuthorID       *int64    `json:"author_id"`
	CreatedAt      time.Time `json:"created_at"`
	UpdatedAt      time.Time `json:"updated_at"`
}

const courseCols = `c.id, c.folder_id, c.title, c.description, c.cover, c.tags, c.status, c.est_minutes, c.order_mode, c.pass_percent, c.validity_months, c.max_attempts,
	c.version, c.cert_template_id, c.steps_count, c.required_count, c.sort, c.author_id, c.created_at, c.updated_at`

func (s *Server) lmsLoadCourse(ctx context.Context, id int64) (*lcourse, error) {
	var c lcourse
	err := s.db.QueryRow(ctx, `SELECT `+courseCols+` FROM learn_courses c WHERE c.id = $1`, id).Scan(&c.ID, &c.FolderID, &c.Title, &c.Description, &c.Cover, &c.Tags, &c.Status,
		&c.EstMinutes, &c.OrderMode, &c.PassPercent, &c.ValidityMonths, &c.MaxAttempts, &c.Version, &c.CertTemplateID, &c.StepsCount, &c.RequiredCount, &c.Sort, &c.AuthorID,
		&c.CreatedAt, &c.UpdatedAt)
	if c.Tags == nil {
		c.Tags = []string{}
	}
	return &c, err
}

// lmsCourseAccess: курс и уровень доступа (папка курса; назначенный курс открывается на просмотр). Черновики видят только редакторы папки.
func (s *Server) lmsCourseAccess(c *Ctx, id int64, min int) (*lcourse, int, error) {
	ctx := c.Context()
	co, err := s.lmsLoadCourse(ctx, id)
	if err != nil {
		return nil, 0, err
	}
	var lvl int
	var assigned bool
	if err := s.db.QueryRow(ctx, `SELECT learn_level($1, $2, $3, $4), EXISTS (SELECT 1 FROM learn_assignees WHERE user_id = $2 AND target_type = 'course' AND target_id = $5 AND status < 3)`,
		co.FolderID, c.U.ID, c.U.Dept, c.U.IsAdmin(), id).Scan(&lvl, &assigned); err != nil {
		return nil, 0, err
	}
	if lvl == 0 && assigned {
		lvl = lvView
	}
	if lvl < lvView || lvl < min || (co.Status != "published" && lvl < lvEdit) {
		return nil, 0, errForbidden
	}
	return co, lvl, nil
}

// lmsVisible — предикат «курс виден пользователю» (b — параметры запроса, c — алиас таблицы курсов).
func (s *Server) lmsVisible(c *Ctx, b *qb) (string, []treeNode, error) {
	all, mng, nodes, err := s.learnTreeIDs(c.Context(), c.U, "courses")
	if err != nil {
		return "", nil, err
	}
	uid := b.add(c.U.ID)
	return `((c.folder_id = ANY(` + b.add(all) + `::bigint[]) AND (c.status = 'published' OR c.folder_id = ANY(` + b.add(mng) + `::bigint[])))
		OR EXISTS (SELECT 1 FROM learn_assignees xa WHERE xa.user_id = ` + uid + `::bigint AND xa.target_type = 'course' AND xa.target_id = c.id AND xa.status < 3 AND c.status = 'published'))`, nodes, nil
}

// ---------------------------------------------------------------- каталог

func (s *Server) lmsCatalog(c *Ctx) error {
	ctx := c.Context()
	page, per, off := c.Page(24, 60)
	b := &qb{}
	vis, nodes, err := s.lmsVisible(c, b)
	if err != nil {
		return err
	}
	me := b.add(c.U.ID)
	base := []string{vis}
	if f := c.QInt64("folder"); f > 0 {
		kids := map[int64][]int64{}
		have := false
		for _, n := range nodes {
			if n.ID == f {
				have = true
			}
			if n.Pid != nil {
				kids[*n.Pid] = append(kids[*n.Pid], n.ID)
			}
		}
		if !have {
			return errForbidden
		}
		ids := []int64{}
		var walk func(id int64)
		walk = func(id int64) {
			ids = append(ids, id)
			for _, k := range kids[id] {
				walk(k)
			}
		}
		walk(f)
		base = append(base, "c.folder_id = ANY("+b.add(ids)+"::bigint[])")
	}
	if q := strings.ToLower(c.Q("q")); q != "" {
		base = append(base, "lower(c.title || ' ' || c.description) LIKE "+b.add("%"+likeEscape(q)+"%")+" ESCAPE '\\'")
	}
	if t := strings.ToLower(strings.TrimPrefix(c.Q("tag"), "#")); t != "" {
		base = append(base, "c.tags @> ARRAY["+b.add(t)+"]::text[]")
	}
	asg := `EXISTS (SELECT 1 FROM learn_assignees a WHERE a.user_id = ` + me + `::bigint AND a.target_type = 'course' AND a.target_id = c.id AND a.status < 3)`
	overdue := `EXISTS (SELECT 1 FROM learn_assignees a WHERE a.user_id = ` + me + `::bigint AND a.target_type = 'course' AND a.target_id = c.id AND a.status < 2 AND a.due_at < now())`
	filter := []string{}
	order := "c.sort, lower(c.title), c.id"
	switch c.Q("filter") {
	case "mine":
		filter = append(filter, "e.user_id IS NOT NULL AND e.status > 0")
		order = "e.last_at DESC NULLS LAST, c.id"
	case "assigned":
		filter = append(filter, asg+" AND coalesce(e.status, 0) < 2")
		order = "(SELECT min(a.due_at) FROM learn_assignees a WHERE a.user_id = " + me + "::bigint AND a.target_type = 'course' AND a.target_id = c.id AND a.status < 2) NULLS LAST, c.id"
	case "progress":
		filter = append(filter, "e.status = 1")
		order = "e.last_at DESC NULLS LAST, c.id"
	case "done":
		filter = append(filter, "e.status = 2")
		order = "e.completed_at DESC NULLS LAST, c.id"
	case "overdue":
		filter = append(filter, overdue)
	case "drafts":
		filter = append(filter, "c.status = 'draft'")
	}
	where := strings.Join(append(append([]string{}, base...), filter...), " AND ")
	from := ` FROM learn_courses c JOIN learn_folders f ON f.id = c.folder_id LEFT JOIN learn_enrollments e ON e.course_id = c.id AND e.user_id = ` + me + `::bigint`
	n := len(b.args)
	lim, offs := b.add(per+1), b.add(off)
	items, err := s.arr(ctx, `SELECT c.id, c.folder_id, f.name AS folder_name, c.title, c.description, c.cover, c.tags, c.status, c.est_minutes, c.order_mode, c.steps_count, c.required_count,
			c.validity_months, c.version, e.status AS e_status, e.percent, e.completed_at, e.expires_at, e.last_at,
			(SELECT min(a.due_at) FROM learn_assignees a WHERE a.user_id = `+me+`::bigint AND a.target_type = 'course' AND a.target_id = c.id AND a.status < 2) AS due_at,
			`+asg+` AS assigned, `+overdue+` AS overdue`+from+` WHERE `+where+` ORDER BY `+order+` LIMIT `+lim+` OFFSET `+offs, b.args...)
	if err != nil {
		return err
	}
	var rows []json.RawMessage
	json.Unmarshal(items, &rows)
	more := len(rows) > per
	if more {
		rows = rows[:per]
	}
	if rows == nil {
		rows = []json.RawMessage{}
	}
	out := map[string]any{"items": rows, "has_more": more, "page": page, "per": per}
	if page == 1 {
		cb := &qb{args: append([]any{}, b.args[:n]...)}
		counts, err := s.one(ctx, `SELECT count(*) AS "all", count(*) FILTER (WHERE e.user_id IS NOT NULL AND e.status > 0) AS mine,
				count(*) FILTER (WHERE `+asg+` AND coalesce(e.status, 0) < 2) AS assigned, count(*) FILTER (WHERE e.status = 1) AS progress,
				count(*) FILTER (WHERE e.status = 2) AS done, count(*) FILTER (WHERE `+overdue+`) AS overdue
			`+from+` WHERE `+strings.Join(base, " AND "), cb.args...)
		if err != nil {
			return err
		}
		out["counts"] = json.RawMessage(counts)
		tb := &qb{}
		tv, _, _ := s.lmsVisible(c, tb)
		tags, err := s.arr(ctx, `SELECT tag, count(*) AS n FROM learn_courses c, unnest(c.tags) tag WHERE `+tv+` GROUP BY tag ORDER BY n DESC, tag LIMIT 24`, tb.args...)
		if err != nil {
			return err
		}
		out["tags"] = json.RawMessage(tags)
	}
	return c.JSON(200, out)
}

// lmsCoursePick — поиск опубликованных курсов для выбора (предпосылки, назначения).
func (s *Server) lmsCoursePick(c *Ctx) error {
	b := &qb{}
	vis, _, err := s.lmsVisible(c, b)
	if err != nil {
		return err
	}
	where := vis + " AND c.status = 'published'"
	if q := strings.ToLower(c.Q("q")); q != "" {
		where += " AND lower(c.title) LIKE " + b.add("%"+likeEscape(q)+"%") + " ESCAPE '\\'"
	}
	if ex := c.QInt64("exclude"); ex > 0 {
		where += " AND c.id <> " + b.add(ex) + "::bigint"
	}
	out, err := s.arr(c.Context(), `SELECT c.id, c.title, c.est_minutes, c.validity_months FROM learn_courses c WHERE `+where+` ORDER BY lower(c.title) LIMIT 30`, b.args...)
	if err != nil {
		return err
	}
	return c.Raw(200, out)
}

// ---------------------------------------------------------------- карточка

func (s *Server) lmsCourseGet(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	co, lvl, err := s.lmsCourseAccess(c, id, lvView)
	if err != nil {
		return err
	}
	steps, err := s.lmsSteps(ctx, id)
	if err != nil {
		return err
	}
	if err := s.lmsApplyProgress(ctx, c.U.ID, co, steps); err != nil {
		return err
	}
	prereqs, prereqOK, err := s.lmsPrereqs(ctx, c.U.ID, id)
	if err != nil {
		return err
	}
	sections, err := s.arr(ctx, `SELECT id, title, sort FROM learn_course_sections WHERE course_id = $1 ORDER BY sort, id`, id)
	if err != nil {
		return err
	}
	var enr json.RawMessage
	if e, err := s.one(ctx, `SELECT status, cycle, started_at, last_at, completed_at, expires_at, steps_done, steps_total, percent, time_sec, score::float8 AS score, cert_id, started_version, completed_version
		FROM learn_enrollments WHERE user_id = $1 AND course_id = $2`, c.U.ID, id); err == nil {
		enr = e
	}
	var cert json.RawMessage
	if cb, err := s.one(ctx, `SELECT id, number, status, issued_at, expires_at FROM learn_certs WHERE user_id = $1 AND course_id = $2 ORDER BY issued_at DESC LIMIT 1`, c.U.ID, id); err == nil {
		cert = cb
	}
	var asg json.RawMessage
	if ab, err := s.one(ctx, `SELECT a.id, a.due_at, a.status, a.high, a.mandatory, a.assigned_at, (a.due_at < now() AND a.status < 2) AS overdue
		FROM learn_assignees a WHERE a.user_id = $1 AND a.target_type = 'course' AND a.target_id = $2 AND a.status < 3 ORDER BY a.status, a.due_at NULLS LAST LIMIT 1`, c.U.ID, id); err == nil {
		asg = ab
	}
	var next int64
	for _, x := range steps {
		if x.Status != 2 && x.Available {
			next = x.ID
			break
		}
	}
	var folderName string
	var author *string
	s.db.QueryRow(ctx, `SELECT f.name, (SELECT full_name FROM users WHERE id = $2) FROM learn_folders f WHERE f.id = $1`, co.FolderID, co.AuthorID).Scan(&folderName, &author)
	out := map[string]any{"course": co, "level": lvl, "folder_name": folderName, "author": author, "sections": json.RawMessage(sections), "steps": steps,
		"prereqs": prereqs, "prereqs_ok": prereqOK, "next_step_id": nil, "can_edit": lvl >= lvEdit}
	if next > 0 && prereqOK {
		out["next_step_id"] = next
	}
	if enr != nil {
		out["enrollment"] = enr
	}
	if cert != nil {
		out["cert"] = cert
	}
	if asg != nil {
		out["assignment"] = asg
	}
	if lvl >= lvEdit {
		ids := []int64{}
		rows, err := s.db.Query(ctx, `SELECT req_id FROM learn_course_prereq WHERE course_id = $1`, id)
		if err == nil {
			for rows.Next() {
				var x int64
				rows.Scan(&x)
				ids = append(ids, x)
			}
			rows.Close()
		}
		out["prereq_ids"] = ids
	}
	return c.JSON(200, out)
}

// ---------------------------------------------------------------- сохранение

type stepIn struct {
	ID          int64  `json:"id"`
	Section     *int   `json:"section"`
	Kind        string `json:"kind"`
	RefID       *int64 `json:"ref_id"`
	Title       string `json:"title"`
	Body        string `json:"body"`
	URL         string `json:"url"`
	Required    *bool  `json:"required"`
	PassPercent *int   `json:"pass_percent"`
	EstMinutes  int    `json:"est_minutes"`
}

type courseIn struct {
	FolderID       int64    `json:"folder_id"`
	Title          string   `json:"title"`
	Description    string   `json:"description"`
	Cover          string   `json:"cover"`
	Tags           []string `json:"tags"`
	Status         string   `json:"status"`
	EstMinutes     int      `json:"est_minutes"`
	OrderMode      string   `json:"order_mode"`
	PassPercent    *int     `json:"pass_percent"`
	ValidityMonths int      `json:"validity_months"`
	MaxAttempts    *int     `json:"max_attempts"`
	CertTemplateID *int64   `json:"cert_template_id"`
	Prereqs        []int64  `json:"prereqs"`
	Sections       []struct {
		Title string `json:"title"`
	} `json:"sections"`
	Steps []stepIn `json:"steps"`
}

func (in *courseIn) validate() error {
	in.Title = strings.TrimSpace(in.Title)
	if in.Title == "" || len([]rune(in.Title)) > 300 {
		return badReq("Укажите название курса (до 300 символов)")
	}
	if len(in.Description) > 10000 {
		return badReq("Слишком длинное описание")
	}
	if in.Cover != "" && (len(in.Cover) > 600 || !(strings.HasPrefix(in.Cover, "/") || urlOK(in.Cover)) || strings.HasPrefix(in.Cover, "//")) {
		return badReq("Некорректная обложка")
	}
	in.Tags = cleanTags(in.Tags)
	if in.Status != "published" {
		in.Status = "draft"
	}
	if in.OrderMode != "sequential" {
		in.OrderMode = "free"
	}
	if in.PassPercent == nil {
		v := 70
		in.PassPercent = &v
	}
	if *in.PassPercent < 0 || *in.PassPercent > 100 {
		return badReq("Порог теста — от 0 до 100%")
	}
	if in.ValidityMonths < 0 || in.ValidityMonths > 600 {
		return badReq("Срок действия — от 0 до 600 месяцев")
	}
	if in.MaxAttempts != nil && (*in.MaxAttempts < 1 || *in.MaxAttempts > 100) {
		return badReq("Число попыток — от 1 до 100")
	}
	if in.EstMinutes < 0 || in.EstMinutes > 100000 {
		return badReq("Некорректная длительность")
	}
	if len(in.Steps) > 200 || len(in.Sections) > 50 || len(in.Prereqs) > 30 {
		return badReq("Слишком много шагов, разделов или предпосылок")
	}
	for i := range in.Sections {
		in.Sections[i].Title = trimTo(in.Sections[i].Title, 200)
		if in.Sections[i].Title == "" {
			return badReq(fmt.Sprintf("Раздел %d: укажите название", i+1))
		}
	}
	for i := range in.Steps {
		x := &in.Steps[i]
		x.Title, x.Body, x.URL = trimTo(x.Title, 300), strings.TrimSpace(x.Body), strings.TrimSpace(x.URL)
		bad := func(m string) error { return badReq(fmt.Sprintf("Шаг %d: %s", i+1, m)) }
		if len(x.Body) > 20000 {
			return bad("слишком длинный текст")
		}
		if x.Section != nil && (*x.Section < 0 || *x.Section >= len(in.Sections)) {
			x.Section = nil
		}
		if x.PassPercent != nil && (*x.PassPercent < 0 || *x.PassPercent > 100) {
			return bad("порог теста — от 0 до 100%")
		}
		if x.EstMinutes < 0 || x.EstMinutes > 10000 {
			x.EstMinutes = 0
		}
		switch x.Kind {
		case "item", "test":
			if x.RefID == nil || *x.RefID <= 0 {
				return bad("не выбран " + map[string]string{"item": "материал", "test": "тест"}[x.Kind])
			}
			x.URL, x.Body = "", ""
		case "link", "video":
			if !urlOK(x.URL) || len(x.URL) > 2000 {
				return bad("ссылка должна начинаться с http:// или https://")
			}
			if x.Title == "" {
				return bad("укажите название")
			}
			x.RefID, x.Body = nil, ""
		case "wiki":
			if !(strings.HasPrefix(x.URL, "/") && !strings.HasPrefix(x.URL, "//")) && !urlOK(x.URL) {
				return bad("укажите ссылку на страницу базы знаний")
			}
			if x.Title == "" {
				return bad("укажите название")
			}
			x.RefID, x.Body = nil, ""
		case "ack":
			if x.Title == "" {
				return bad("укажите название")
			}
			x.RefID, x.URL = nil, ""
		default:
			return bad("неизвестный тип шага")
		}
	}
	return nil
}

func (s *Server) lmsCourseSave(c *Ctx) error {
	var in courseIn
	if err := c.Decode(&in); err != nil {
		return err
	}
	if err := in.validate(); err != nil {
		return err
	}
	ctx := c.Context()
	var id int64
	editing := c.R.PathValue("id") != ""
	var old *lcourse
	if editing {
		var err error
		if id, err = c.ID("id"); err != nil {
			return err
		}
		if old, _, err = s.lmsCourseAccess(c, id, lvEdit); err != nil {
			return err
		}
		if in.FolderID == 0 {
			in.FolderID = old.FolderID
		}
		if in.FolderID != old.FolderID {
			if f, err := s.learnFolder(c, in.FolderID, lvEdit); err != nil {
				return err
			} else if f.Kind != "courses" {
				return badReq("Курсы добавляются в папки курсов")
			}
		}
	} else {
		f, err := s.learnFolder(c, in.FolderID, lvEdit)
		if err != nil {
			return err
		}
		if f.Kind != "courses" {
			return badReq("Курсы добавляются в папки курсов")
		}
	}
	// предпосылки: без циклов, только существующие курсы
	reqs := []int64{}
	seen := map[int64]bool{}
	for _, r := range in.Prereqs {
		if r > 0 && r != id && !seen[r] {
			seen[r] = true
			reqs = append(reqs, r)
		}
	}
	if editing && len(reqs) > 0 {
		var cyc bool
		if err := s.db.QueryRow(ctx, `WITH RECURSIVE r AS (SELECT unnest($1::bigint[]) AS id UNION SELECT p.req_id FROM learn_course_prereq p JOIN r ON p.course_id = r.id WHERE p.course_id <> $2)
			SELECT EXISTS (SELECT 1 FROM r WHERE id = $2)`, reqs, id).Scan(&cyc); err != nil {
			return err
		}
		if cyc {
			return badReq("Предпосылки образуют цикл")
		}
	}
	if in.CertTemplateID != nil {
		var ok bool
		if err := s.db.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM learn_cert_templates WHERE id = $1)`, *in.CertTemplateID).Scan(&ok); err != nil || !ok {
			return badReq("Шаблон сертификата не найден")
		}
	}
	// ссылки на материалы и тесты: автор должен их видеть (уже имеющиеся шаги не перепроверяем)
	existing := map[int64][2]any{}
	if editing {
		rows, err := s.db.Query(ctx, `SELECT id, kind, ref_id FROM learn_course_steps WHERE course_id = $1`, id)
		if err != nil {
			return err
		}
		for rows.Next() {
			var sid int64
			var k string
			var r *int64
			rows.Scan(&sid, &k, &r)
			existing[sid] = [2]any{k, r}
		}
		rows.Close()
	}
	for i, x := range in.Steps {
		if x.Kind != "item" && x.Kind != "test" {
			continue
		}
		if e, ok := existing[x.ID]; ok && x.ID > 0 && e[0] == x.Kind && e[1].(*int64) != nil && *e[1].(*int64) == *x.RefID {
			continue
		}
		tbl := "learn_items"
		if x.Kind == "test" {
			tbl = "learn_tests"
		}
		_, lvl, err := s.learnLevelOf(c, tbl, *x.RefID)
		if err != nil || lvl < lvView {
			return badReq(fmt.Sprintf("Шаг %d: материал или тест недоступен", i+1))
		}
		if x.Title == "" {
			var t string
			s.db.QueryRow(ctx, `SELECT title FROM `+tbl+` WHERE id = $1`, *x.RefID).Scan(&t)
			in.Steps[i].Title = trimTo(t, 300)
		}
	}
	if in.Status == "published" {
		req := 0
		for i, x := range in.Steps {
			if x.Required == nil || *x.Required {
				req++
			}
			if x.Kind == "test" {
				var st string
				if err := s.db.QueryRow(ctx, `SELECT status FROM learn_tests WHERE id = $1`, *x.RefID).Scan(&st); err != nil || st != "published" {
					return badReq(fmt.Sprintf("Шаг %d: тест не опубликован", i+1))
				}
			}
		}
		if req == 0 {
			return badReq("Для публикации нужен хотя бы один обязательный шаг")
		}
	}
	est := in.EstMinutes
	if est == 0 {
		for _, x := range in.Steps {
			est += x.EstMinutes
		}
	}
	var structChanged bool
	err := s.tx(ctx, func(tx pgx.Tx) error {
		if editing {
			if _, err := tx.Exec(ctx, `UPDATE learn_courses SET folder_id = $2, title = $3, description = $4, cover = $5, tags = $6, status = $7, est_minutes = $8, order_mode = $9,
				pass_percent = $10, validity_months = $11, max_attempts = $12, cert_template_id = $13, updated_at = now() WHERE id = $1`,
				id, in.FolderID, in.Title, in.Description, in.Cover, in.Tags, in.Status, est, in.OrderMode, *in.PassPercent, in.ValidityMonths, in.MaxAttempts, in.CertTemplateID); err != nil {
				return err
			}
		} else if err := tx.QueryRow(ctx, `INSERT INTO learn_courses (folder_id, title, description, cover, tags, status, est_minutes, order_mode, pass_percent, validity_months, max_attempts,
				cert_template_id, author_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING id`,
			in.FolderID, in.Title, in.Description, in.Cover, in.Tags, in.Status, est, in.OrderMode, *in.PassPercent, in.ValidityMonths, in.MaxAttempts, in.CertTemplateID, c.U.ID).Scan(&id); err != nil {
			return err
		}
		// разделы: пересоздаём (шаги получают новые section_id)
		if _, err := tx.Exec(ctx, `DELETE FROM learn_course_sections WHERE course_id = $1`, id); err != nil {
			return err
		}
		secIDs := make([]int64, len(in.Sections))
		for i, sc := range in.Sections {
			if err := tx.QueryRow(ctx, `INSERT INTO learn_course_sections (course_id, title, sort) VALUES ($1, $2, $3) RETURNING id`, id, sc.Title, i).Scan(&secIDs[i]); err != nil {
				return err
			}
		}
		// шаги: id сохраняются (прогресс пользователей привязан к шагу)
		oldSig := map[int64]string{}
		rows, err := tx.Query(ctx, `SELECT id, kind || ':' || coalesce(ref_id, 0) || ':' || required || ':' || coalesce(pass_percent, -1) FROM learn_course_steps WHERE course_id = $1`, id)
		if err != nil {
			return err
		}
		for rows.Next() {
			var sid int64
			var sig string
			rows.Scan(&sid, &sig)
			oldSig[sid] = sig
		}
		rows.Close()
		keep := map[int64]bool{}
		required := 0
		for i := range in.Steps {
			x := &in.Steps[i]
			req := x.Required == nil || *x.Required
			if req {
				required++
			}
			var sec any
			if x.Section != nil {
				sec = secIDs[*x.Section]
			}
			sig := fmt.Sprintf("%s:%d:%v:%d", x.Kind, deref(x.RefID), req, derefInt(x.PassPercent, -1))
			if _, ok := oldSig[x.ID]; ok && x.ID > 0 && !keep[x.ID] {
				keep[x.ID] = true
				if oldSig[x.ID] != sig {
					structChanged = true
				}
				if _, err := tx.Exec(ctx, `UPDATE learn_course_steps SET section_id = $2, sort = $3, kind = $4, ref_id = $5, title = $6, body = $7, url = $8, required = $9, pass_percent = $10, est_minutes = $11 WHERE id = $1`,
					x.ID, sec, i, x.Kind, x.RefID, x.Title, x.Body, x.URL, req, x.PassPercent, x.EstMinutes); err != nil {
					return err
				}
			} else {
				structChanged = true
				if err := tx.QueryRow(ctx, `INSERT INTO learn_course_steps (course_id, section_id, sort, kind, ref_id, title, body, url, required, pass_percent, est_minutes)
					VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING id`, id, sec, i, x.Kind, x.RefID, x.Title, x.Body, x.URL, req, x.PassPercent, x.EstMinutes).Scan(&x.ID); err != nil {
					return err
				}
				keep[x.ID] = true
			}
		}
		for sid := range oldSig {
			if !keep[sid] {
				structChanged = true
				if _, err := tx.Exec(ctx, `DELETE FROM learn_course_steps WHERE id = $1`, sid); err != nil {
					return err
				}
			}
		}
		if _, err := tx.Exec(ctx, `UPDATE learn_courses SET steps_count = $2, required_count = $3, version = version + CASE WHEN $4::boolean AND $5::boolean THEN 1 ELSE 0 END WHERE id = $1`,
			id, len(in.Steps), required, structChanged, editing); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `DELETE FROM learn_course_prereq WHERE course_id = $1`, id); err != nil {
			return err
		}
		if len(reqs) > 0 {
			if _, err := tx.Exec(ctx, `INSERT INTO learn_course_prereq (course_id, req_id) SELECT $1, x.id FROM learn_courses x WHERE x.id = ANY($2::bigint[]) ON CONFLICT DO NOTHING`, id, reqs); err != nil {
				return err
			}
		}
		return nil
	})
	if err != nil {
		return err
	}
	if editing && structChanged {
		s.lmsRecalcCourse(ctx, id)
	}
	s.learnBump(ctx)
	s.audit(c, "learning.course.save", "learn_course", id, map[string]any{"status": in.Status, "steps": len(in.Steps)})
	return c.JSON(200, map[string]int64{"id": id})
}

func deref(p *int64) int64 {
	if p == nil {
		return 0
	}
	return *p
}

func derefInt(p *int, def int) int {
	if p == nil {
		return def
	}
	return *p
}

func (s *Server) lmsCourseDelete(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, _, err = s.lmsCourseAccess(c, id, lvEdit); err != nil {
		return err
	}
	if _, err := s.db.Exec(c.Context(), `DELETE FROM learn_assignments WHERE target_type = 'course' AND target_id = $1`, id); err != nil {
		return err
	}
	if _, err := s.db.Exec(c.Context(), `DELETE FROM learn_courses WHERE id = $1`, id); err != nil {
		return err
	}
	s.learnBump(c.Context())
	s.audit(c, "learning.course.delete", "learn_course", id, nil)
	return c.OK()
}

func (s *Server) lmsCourseStatus(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Status string `json:"status"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	co, _, err := s.lmsCourseAccess(c, id, lvEdit)
	if err != nil {
		return err
	}
	if in.Status != "published" && in.Status != "draft" {
		return badReq("Некорректный статус")
	}
	if in.Status == "published" {
		if co.RequiredCount == 0 {
			return badReq("Для публикации нужен хотя бы один обязательный шаг")
		}
		var bad int
		s.db.QueryRow(c.Context(), `SELECT count(*) FROM learn_course_steps st JOIN learn_tests t ON t.id = st.ref_id WHERE st.course_id = $1 AND st.kind = 'test' AND t.status <> 'published'`, id).Scan(&bad)
		if bad > 0 {
			return badReq("В курсе есть неопубликованные тесты")
		}
	}
	if _, err := s.db.Exec(c.Context(), `UPDATE learn_courses SET status = $2, updated_at = now() WHERE id = $1`, id, in.Status); err != nil {
		return err
	}
	s.learnBump(c.Context())
	return c.OK()
}

func (s *Server) lmsCourseCopy(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, _, err = s.lmsCourseAccess(c, id, lvEdit); err != nil {
		return err
	}
	ctx := c.Context()
	var nid int64
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if err := tx.QueryRow(ctx, `INSERT INTO learn_courses (folder_id, title, description, cover, tags, status, est_minutes, order_mode, pass_percent, validity_months, max_attempts,
				cert_template_id, steps_count, required_count, sort, author_id)
			SELECT folder_id, left(title, 280) || ' (копия)', description, cover, tags, 'draft', est_minutes, order_mode, pass_percent, validity_months, max_attempts,
				cert_template_id, steps_count, required_count, sort, $2 FROM learn_courses WHERE id = $1 RETURNING id`, id, c.U.ID).Scan(&nid); err != nil {
			return err
		}
		secs := map[int64]int64{}
		rows, err := tx.Query(ctx, `SELECT id, title, sort FROM learn_course_sections WHERE course_id = $1 ORDER BY sort, id`, id)
		if err != nil {
			return err
		}
		type sec struct {
			id    int64
			title string
			sort  int
		}
		var list []sec
		for rows.Next() {
			var x sec
			rows.Scan(&x.id, &x.title, &x.sort)
			list = append(list, x)
		}
		rows.Close()
		for _, x := range list {
			var n int64
			if err := tx.QueryRow(ctx, `INSERT INTO learn_course_sections (course_id, title, sort) VALUES ($1, $2, $3) RETURNING id`, nid, x.title, x.sort).Scan(&n); err != nil {
				return err
			}
			secs[x.id] = n
		}
		rows, err = tx.Query(ctx, `SELECT section_id, sort, kind, ref_id, title, body, url, required, pass_percent, est_minutes FROM learn_course_steps WHERE course_id = $1 ORDER BY sort, id`, id)
		if err != nil {
			return err
		}
		type stp struct {
			sec         *int64
			sort        int
			kind        string
			ref         *int64
			title, body string
			url         string
			req         bool
			pass        *int
			est         int
		}
		var st []stp
		for rows.Next() {
			var x stp
			rows.Scan(&x.sec, &x.sort, &x.kind, &x.ref, &x.title, &x.body, &x.url, &x.req, &x.pass, &x.est)
			st = append(st, x)
		}
		rows.Close()
		for _, x := range st {
			var sec any
			if x.sec != nil {
				sec = secs[*x.sec]
			}
			if _, err := tx.Exec(ctx, `INSERT INTO learn_course_steps (course_id, section_id, sort, kind, ref_id, title, body, url, required, pass_percent, est_minutes)
				VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`, nid, sec, x.sort, x.kind, x.ref, x.title, x.body, x.url, x.req, x.pass, x.est); err != nil {
				return err
			}
		}
		_, err = tx.Exec(ctx, `INSERT INTO learn_course_prereq (course_id, req_id) SELECT $2, req_id FROM learn_course_prereq WHERE course_id = $1`, id, nid)
		return err
	})
	if err != nil {
		return err
	}
	s.learnBump(ctx)
	return c.JSON(200, map[string]int64{"id": nid})
}
