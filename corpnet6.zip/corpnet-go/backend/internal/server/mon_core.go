package server

// Мониторинг и логи: контекст запроса (request_id, счётчики БД/Redis), JSON-логгер.
// Остальное: mon_access.go (access-лог), mon_metrics.go (/metrics), mon_trace.go (pgx tracer, Redis hook).

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"io"
	"log/slog"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

type monCtxKey struct{}

// monReq — сведения об одном HTTP-запросе, доступные из context (в т.ч. из pgx tracer и Redis hook).
type monReq struct {
	ID    string
	Start time.Time

	dbN, dbNs atomic.Int64 // число SQL-запросов и суммарное время (нс)
	uid       atomic.Int64

	mu   sync.Mutex
	role string
	err  string
}

func monFrom(ctx context.Context) *monReq {
	m, _ := ctx.Value(monCtxKey{}).(*monReq)
	return m
}

// RequestID возвращает идентификатор текущего запроса ("" вне HTTP-запроса).
func RequestID(ctx context.Context) string {
	if m := monFrom(ctx); m != nil {
		return m.ID
	}
	return ""
}

func (m *monReq) setUser(id int64, role string) {
	m.uid.Store(id)
	m.mu.Lock()
	m.role = role
	m.mu.Unlock()
}

func (m *monReq) setErr(e string) {
	m.mu.Lock()
	if m.err == "" {
		m.err = e
	}
	m.mu.Unlock()
}

func (m *monReq) snapshot() (role, err string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.role, m.err
}

// validRequestID — принимаем X-Request-ID от nginx/haproxy (hex/uuid), остальное заменяем своим.
func validRequestID(s string) bool {
	if len(s) < 8 || len(s) > 64 {
		return false
	}
	for i := 0; i < len(s); i++ {
		c := s[i]
		if !(c >= '0' && c <= '9' || c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c == '-' || c == '_' || c == '.' || c == ':') {
			return false
		}
	}
	return true
}

func newRequestID() string {
	var b [16]byte
	if _, err := io.ReadFull(rand.Reader, b[:]); err != nil {
		return strings.Repeat("0", 32)
	}
	return hex.EncodeToString(b[:])
}

// NewLogger — slog JSON в stdout: ts (RFC3339Nano), level в нижнем регистре, service/instance/dc во всех строках.
// Эти ключи разбирает pipeline Promtail (deploy/monitoring/promtail).
func NewLogger(w io.Writer, cfg Config) *slog.Logger {
	h := slog.NewJSONHandler(w, &slog.HandlerOptions{
		Level: slog.LevelInfo,
		ReplaceAttr: func(groups []string, a slog.Attr) slog.Attr {
			if len(groups) > 0 {
				return a
			}
			switch a.Key {
			case slog.TimeKey:
				a.Key = "ts"
				a.Value = slog.StringValue(a.Value.Time().UTC().Format(time.RFC3339Nano))
			case slog.LevelKey:
				a.Value = slog.StringValue(strings.ToLower(a.Value.String()))
			}
			return a
		},
	})
	return slog.New(h).With("service", "app", "instance", cfg.InstanceID, "dc", cfg.DCID)
}
