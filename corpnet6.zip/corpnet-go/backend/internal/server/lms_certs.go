package server

import (
	"context"
	"crypto/rand"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

// ---------------------------------------------------------------- выдача

type certParams struct {
	UserID     int64
	CourseID   *int64
	TestID     *int64
	TemplateID int64
	Title      string
	Score      *float64
	Expires    *time.Time
}

var numTokenRe = regexp.MustCompile(`\{N(?::(\d{1,2}))?\}`)

// certNumber строит номер по маске: {YYYY} {YY} {MM} {DD} {N} {N:5}. Если в маске нет {N}, счётчик дописывается в конец.
func certNumber(mask string, n int64, now time.Time) string {
	if !numTokenRe.MatchString(mask) {
		mask += "-{N:5}"
	}
	out := strings.NewReplacer("{YYYY}", now.Format("2006"), "{YY}", now.Format("06"), "{MM}", now.Format("01"), "{DD}", now.Format("02")).Replace(mask)
	return numTokenRe.ReplaceAllStringFunc(out, func(m string) string {
		w := 0
		if sm := numTokenRe.FindStringSubmatch(m); sm[1] != "" {
			w, _ = strconv.Atoi(sm[1])
		}
		return fmt.Sprintf("%0*d", w, n)
	})
}

const codeAlphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

func certCode() string {
	b := make([]byte, 10)
	rand.Read(b)
	for i := range b {
		b[i] = codeAlphabet[int(b[i])%len(codeAlphabet)]
	}
	return string(b[:5]) + "-" + string(b[5:])
}

func normCode(c string) string {
	c = strings.ToUpper(strings.NewReplacer(" ", "", "_", "").Replace(strings.TrimSpace(c)))
	if len(c) == 10 {
		c = c[:5] + "-" + c[5:]
	}
	return c
}

func (s *Server) fmtScore(v *float64) string {
	if v == nil {
		return "—"
	}
	return strings.Replace(strconv.FormatFloat(*v, 'f', -1, 64), ".", ",", 1) + "%"
}

// lmsIssueCert выдаёт сертификат в транзакции: счётчик шаблона увеличивается вместе с вставкой (номера без дыр).
func (s *Server) lmsIssueCert(ctx context.Context, tx pgx.Tx, p certParams) (int64, error) {
	var name string
	var dept *int64
	if err := tx.QueryRow(ctx, `SELECT full_name, department_id FROM users WHERE id = $1`, p.UserID).Scan(&name, &dept); err != nil {
		return 0, err
	}
	var counter int64
	var mask, title, body, color, border, logo, signer, signerTitle string
	if err := tx.QueryRow(ctx, `UPDATE learn_cert_templates SET counter = counter + 1 WHERE id = $1 RETURNING counter, number_mask, title, body, color, border, logo, signer_name, signer_title`,
		p.TemplateID).Scan(&counter, &mask, &title, &body, &color, &border, &logo, &signer, &signerTitle); err != nil {
		return 0, err
	}
	now := time.Now()
	loc := s.loc()
	number := certNumber(mask, counter, now.In(loc))
	until := "бессрочно"
	if p.Expires != nil {
		until = p.Expires.In(loc).Format("02.01.2006")
	}
	text := strings.NewReplacer("{ФИО}", name, "{курс}", p.Title, "{дата}", now.In(loc).Format("02.01.2006"), "{балл}", s.fmtScore(p.Score),
		"{номер}", number, "{срок_действия}", until).Replace(body)
	look, _ := json.Marshal(map[string]any{"title": title, "body": text, "color": color, "border": border, "logo": logo, "signer_name": signer, "signer_title": signerTitle,
		"user_name": name, "course": p.Title, "date": now.In(loc).Format("02.01.2006"), "score": s.fmtScore(p.Score), "valid_until": until})
	var id int64
	err := tx.QueryRow(ctx, `INSERT INTO learn_certs (number, code, user_id, dept_id, course_id, test_id, template_id, title, user_name, score, issued_at, expires_at, look)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10::numeric, $11, $12, $13::jsonb) RETURNING id`,
		number, certCode(), p.UserID, dept, p.CourseID, p.TestID, p.TemplateID, p.Title, name, p.Score, now, p.Expires, string(look)).Scan(&id)
	return id, err
}

// lmsIssueForTest — сертификат за сдачу теста (если у теста выбран шаблон); действующий сертификат повторно не выдаётся.
func (s *Server) lmsIssueForTest(ctx context.Context, a *lattempt, t *ltest, dept int64) error {
	var has bool
	if err := s.db.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM learn_certs WHERE user_id = $1 AND test_id = $2 AND status = 'valid' AND (expires_at IS NULL OR expires_at > now()))`, a.UserID, t.ID).Scan(&has); err != nil || has {
		return err
	}
	var exp *time.Time
	if t.CertValidity > 0 {
		e := time.Now().AddDate(0, t.CertValidity, 0)
		exp = &e
	}
	var cid int64
	err := s.tx(ctx, func(tx pgx.Tx) (err error) {
		cid, err = s.lmsIssueCert(ctx, tx, certParams{UserID: a.UserID, TestID: &t.ID, TemplateID: *t.CertTemplateID, Title: t.Title, Score: a.Percent, Expires: exp})
		return
	})
	if err == nil {
		s.notify(ctx, []int64{a.UserID}, "learning", "Выдан сертификат: "+t.Title, "", "/learning/certificates/"+strconv.FormatInt(cid, 10))
	}
	return err
}

// ---------------------------------------------------------------- шаблоны

var (
	hexColorRe = regexp.MustCompile(`^#[0-9a-fA-F]{6}$`)
	maskRe     = regexp.MustCompile(`^[\p{L}\p{N}\-_./ {}:]{1,60}$`)
)

func (s *Server) lmsTplList(c *Ctx) error {
	b, err := s.arr(c.Context(), `SELECT id, name, title, body, color, border, logo, signer_name, signer_title, number_mask, expire_remind_days, counter,
		(SELECT count(*) FROM learn_courses WHERE cert_template_id = t.id) + (SELECT count(*) FROM learn_tests WHERE cert_template_id = t.id) AS used
		FROM learn_cert_templates t ORDER BY lower(name), id`)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) lmsTplSave(c *Ctx) error {
	var in struct {
		Name             string `json:"name"`
		Title            string `json:"title"`
		Body             string `json:"body"`
		Color            string `json:"color"`
		Border           string `json:"border"`
		Logo             string `json:"logo"`
		SignerName       string `json:"signer_name"`
		SignerTitle      string `json:"signer_title"`
		NumberMask       string `json:"number_mask"`
		ExpireRemindDays int    `json:"expire_remind_days"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Name, in.Title = trimTo(in.Name, 200), trimTo(in.Title, 200)
	in.Body = strings.TrimSpace(in.Body)
	in.SignerName, in.SignerTitle = trimTo(in.SignerName, 200), trimTo(in.SignerTitle, 200)
	if in.Name == "" || in.Title == "" || in.Body == "" || len([]rune(in.Body)) > 3000 {
		return badReq("Укажите название, заголовок и текст сертификата (до 3000 символов)")
	}
	if !hexColorRe.MatchString(in.Color) {
		in.Color = "#1f5fa8"
	}
	switch in.Border {
	case "none", "simple", "double", "ornate":
	default:
		in.Border = "double"
	}
	if in.Logo != "" && (len(in.Logo) > 600 || strings.HasPrefix(in.Logo, "//") || !(strings.HasPrefix(in.Logo, "/") || urlOK(in.Logo))) {
		return badReq("Некорректный логотип")
	}
	if in.NumberMask = strings.TrimSpace(in.NumberMask); in.NumberMask == "" {
		in.NumberMask = "CN-{YYYY}-{N:5}"
	}
	if !maskRe.MatchString(in.NumberMask) {
		return badReq("Маска номера: буквы, цифры, - _ . / и поля {YYYY} {YY} {MM} {DD} {N} {N:5}")
	}
	if in.ExpireRemindDays < 0 || in.ExpireRemindDays > 365 {
		return badReq("Напоминание об окончании срока — от 0 до 365 дней")
	}
	ctx := c.Context()
	var id int64
	if c.R.PathValue("id") != "" {
		var err error
		if id, err = c.ID("id"); err != nil {
			return err
		}
		tag, err := s.db.Exec(ctx, `UPDATE learn_cert_templates SET name = $2, title = $3, body = $4, color = $5, border = $6, logo = $7, signer_name = $8, signer_title = $9,
			number_mask = $10, expire_remind_days = $11, updated_at = now() WHERE id = $1`, id, in.Name, in.Title, in.Body, in.Color, in.Border, in.Logo, in.SignerName, in.SignerTitle, in.NumberMask, in.ExpireRemindDays)
		if err != nil {
			return err
		}
		if tag.RowsAffected() == 0 {
			return errNotFound
		}
	} else if err := s.db.QueryRow(ctx, `INSERT INTO learn_cert_templates (name, title, body, color, border, logo, signer_name, signer_title, number_mask, expire_remind_days, created_by)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING id`, in.Name, in.Title, in.Body, in.Color, in.Border, in.Logo, in.SignerName, in.SignerTitle, in.NumberMask, in.ExpireRemindDays, c.U.ID).Scan(&id); err != nil {
		return err
	}
	return c.JSON(200, map[string]int64{"id": id})
}

func (s *Server) lmsTplDelete(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, err := s.db.Exec(c.Context(), `DELETE FROM learn_cert_templates WHERE id = $1`, id); err != nil {
		return err
	}
	return c.OK()
}

// ---------------------------------------------------------------- реестр и просмотр

const certState = `CASE WHEN k.status = 'revoked' THEN 'revoked' WHEN k.expires_at IS NOT NULL AND k.expires_at < now() THEN 'expired' ELSE 'valid' END`

func (s *Server) lmsCertFilters(c *Ctx, sc *scope, b *qb) []string {
	w := []string{sc.cond(b, "k.dept_id")}
	if sc.All {
		w = []string{"true"}
	}
	if q := strings.ToLower(c.Q("q")); q != "" {
		p := b.add("%" + likeEscape(q) + "%")
		w = append(w, "(lower(k.user_name) LIKE "+p+" ESCAPE '\\' OR lower(k.number) LIKE "+p+" ESCAPE '\\' OR lower(k.title) LIKE "+p+" ESCAPE '\\')")
	}
	if v := c.QInt64("course"); v > 0 {
		w = append(w, "k.course_id = "+b.add(v)+"::bigint")
	}
	if v := c.QInt64("dept"); v > 0 {
		w = append(w, "k.dept_id IN "+deptSubtree(b.add(v)+"::bigint"))
	}
	switch c.Q("status") {
	case "valid":
		w = append(w, "k.status = 'valid' AND (k.expires_at IS NULL OR k.expires_at >= now())")
	case "revoked":
		w = append(w, "k.status = 'revoked'")
	case "expired":
		w = append(w, "k.status = 'valid' AND k.expires_at < now()")
	case "soon":
		w = append(w, "k.status = 'valid' AND k.expires_at >= now() AND k.expires_at < now() + interval '30 days'")
	}
	if v := c.Q("from"); v != "" {
		if t, err := time.ParseInLocation("2006-01-02", v, s.loc()); err == nil {
			w = append(w, "k.issued_at >= "+b.add(t)+"::timestamptz")
		}
	}
	if v := c.Q("to"); v != "" {
		if t, err := time.ParseInLocation("2006-01-02", v, s.loc()); err == nil {
			w = append(w, "k.issued_at < "+b.add(t.AddDate(0, 0, 1))+"::timestamptz")
		}
	}
	return w
}

func (s *Server) lmsCertList(c *Ctx) error {
	ctx := c.Context()
	if c.Q("all") != "1" { // «Мои сертификаты»
		b, err := s.arr(ctx, `SELECT k.id, k.number, k.title, k.issued_at, k.expires_at, k.score::float8 AS score, `+certState+` AS state, k.course_id,
				(k.status = 'valid' AND k.expires_at >= now() AND k.expires_at < now() + interval '30 days') AS soon
			FROM learn_certs k WHERE k.user_id = $1 ORDER BY k.issued_at DESC LIMIT 200`, c.U.ID)
		if err != nil {
			return err
		}
		return c.JSON(200, map[string]any{"items": json.RawMessage(b)})
	}
	sc, err := s.lmsManager(c)
	if err != nil {
		return err
	}
	page, per, off := c.Page(30, 200)
	b := &qb{}
	where := strings.Join(s.lmsCertFilters(c, sc, b), " AND ")
	var total int
	if err := s.db.QueryRow(ctx, `SELECT count(*) FROM learn_certs k WHERE `+where, b.args...).Scan(&total); err != nil {
		return err
	}
	lim, offs := b.add(per), b.add(off)
	items, err := s.arr(ctx, `SELECT k.id, k.number, k.title, k.user_id, k.user_name, d.name AS department, k.issued_at, k.expires_at, k.score::float8 AS score, `+certState+` AS state, k.revoke_reason
		FROM learn_certs k LEFT JOIN departments d ON d.id = k.dept_id WHERE `+where+` ORDER BY k.issued_at DESC, k.id DESC LIMIT `+lim+` OFFSET `+offs, b.args...)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"items": json.RawMessage(items), "total": total, "page": page, "per": per})
}

func (s *Server) lmsCertExport(c *Ctx) error {
	sc, err := s.lmsManager(c)
	if err != nil {
		return err
	}
	b := &qb{}
	where := strings.Join(s.lmsCertFilters(c, sc, b), " AND ")
	rows, err := s.db.Query(c.Context(), `SELECT k.number, k.user_name, coalesce(d.name, ''), k.title, k.issued_at, k.expires_at, k.score::float8, `+certState+`, k.revoke_reason
		FROM learn_certs k LEFT JOIN departments d ON d.id = k.dept_id WHERE `+where+` ORDER BY k.issued_at DESC, k.id DESC`, b.args...)
	if err != nil {
		return err
	}
	defer rows.Close()
	w := s.csvStart(c, "certificates-"+time.Now().In(s.loc()).Format("20060102")+".csv")
	w.Write([]string{"Номер", "Сотрудник", "Подразделение", "Курс / тест", "Выдан", "Действителен до", "Балл, %", "Статус", "Причина отзыва"})
	loc := s.loc()
	names := map[string]string{"valid": "Действителен", "revoked": "Отозван", "expired": "Истёк"}
	for rows.Next() {
		var num, name, dept, title, state, reason string
		var issued time.Time
		var exp *time.Time
		var score *float64
		if err := rows.Scan(&num, &name, &dept, &title, &issued, &exp, &score, &state, &reason); err != nil {
			return err
		}
		e := "бессрочно"
		if exp != nil {
			e = exp.In(loc).Format("02.01.2006")
		}
		w.Write([]string{csvCell(num), csvCell(name), csvCell(dept), csvCell(title), issued.In(loc).Format("02.01.2006"), e, fnum(score), names[state], csvCell(reason)})
	}
	w.Flush()
	return rows.Err()
}

// csvStart пишет заголовки CSV (UTF-8 с BOM, разделитель «;») и возвращает писатель.
func (s *Server) csvStart(c *Ctx, filename string) *csv.Writer {
	h := c.W.Header()
	h.Set("Content-Type", "text/csv; charset=utf-8")
	h.Set("Content-Disposition", "attachment; filename*=UTF-8''"+url.PathEscape(filename))
	h.Set("Cache-Control", "no-store")
	c.W.Write([]byte{0xEF, 0xBB, 0xBF})
	w := csv.NewWriter(c.W)
	w.Comma = ';'
	return w
}

type certRow struct {
	ID     int64
	UserID *int64
	Status string
}

// lmsCertAccess: владелец, администратор или ответственный за обучение, в чьей области сотрудник.
func (s *Server) lmsCertAccess(c *Ctx, id int64, manage bool) (*certRow, error) {
	var r certRow
	var dept *int64
	if err := s.db.QueryRow(c.Context(), `SELECT id, user_id, status, dept_id FROM learn_certs WHERE id = $1`, id).Scan(&r.ID, &r.UserID, &r.Status, &dept); err != nil {
		return nil, err
	}
	if !manage && r.UserID != nil && *r.UserID == c.U.ID {
		return &r, nil
	}
	sc, err := s.lmsManager(c)
	if err != nil {
		return nil, err
	}
	if !sc.All {
		if r.UserID != nil {
			if dept, err = s.userDept(c.Context(), *r.UserID); err != nil {
				return nil, err
			}
		}
		if !sc.HasPtr(dept) {
			return nil, errForbidden
		}
	}
	return &r, nil
}

func (s *Server) userDept(ctx context.Context, uid int64) (*int64, error) {
	var d *int64
	err := s.db.QueryRow(ctx, `SELECT department_id FROM users WHERE id = $1`, uid).Scan(&d)
	return d, err
}

func (s *Server) lmsCertGet(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, err = s.lmsCertAccess(c, id, false); err != nil {
		return err
	}
	b, err := s.one(c.Context(), `SELECT k.id, k.number, k.code, k.user_id, k.user_name, k.title, k.course_id, k.test_id, k.issued_at, k.expires_at, k.score::float8 AS score,
		`+certState+` AS state, k.revoke_reason, k.revoked_at, k.look FROM learn_certs k WHERE k.id = $1`, id)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) lmsCertRevoke(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Reason string `json:"reason"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	r, err := s.lmsCertAccess(c, id, true)
	if err != nil {
		return err
	}
	in.Reason = trimTo(in.Reason, 500)
	if _, err := s.db.Exec(c.Context(), `UPDATE learn_certs SET status = 'revoked', revoked_at = now(), revoked_by = $2, revoke_reason = $3 WHERE id = $1`, id, c.U.ID, in.Reason); err != nil {
		return err
	}
	s.audit(c, "learning.cert.revoke", "learn_cert", id, map[string]string{"reason": in.Reason})
	if r.UserID != nil {
		s.notify(c.Context(), []int64{*r.UserID}, "learning", "Сертификат отозван", in.Reason, "/learning/certificates/"+strconv.FormatInt(id, 10))
	}
	return c.OK()
}

func (s *Server) lmsCertRestore(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, err = s.lmsCertAccess(c, id, true); err != nil {
		return err
	}
	if _, err := s.db.Exec(c.Context(), `UPDATE learn_certs SET status = 'valid', revoked_at = NULL, revoked_by = NULL, revoke_reason = '' WHERE id = $1`, id); err != nil {
		return err
	}
	s.audit(c, "learning.cert.restore", "learn_cert", id, nil)
	return c.OK()
}

// lmsCertVerify — публичная проверка по коду: только ФИО, название, даты и статус.
func (s *Server) lmsCertVerify(c *Ctx) error {
	if !s.rateOK(c.Context(), "vfc:"+c.IP(), 60, time.Minute) {
		return &apiError{429, "Слишком много запросов, попробуйте позже"}
	}
	raw := strings.TrimSpace(c.R.PathValue("code"))
	code := normCode(raw)
	if len(raw) > 60 || raw == "" {
		return c.JSON(200, map[string]any{"state": "not_found"})
	}
	// проверка по коду из QR или по номеру сертификата (регистр номера не важен)
	b, err := s.one(c.Context(), `SELECT k.number, k.user_name AS name, k.title, k.issued_at, k.expires_at, `+certState+` AS state FROM learn_certs k
		WHERE k.code = $1 OR upper(k.number) = upper($2) ORDER BY (k.code = $1) DESC LIMIT 1`, code, raw)
	if err != nil {
		if errIsNoRows(err) {
			return c.JSON(200, map[string]any{"state": "not_found"})
		}
		return err
	}
	return c.Raw(200, b)
}
