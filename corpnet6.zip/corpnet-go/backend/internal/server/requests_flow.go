package server

import (
	"context"
	"encoding/json"
	"fmt"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

// Движок маршрута согласования. Все переходы выполняются в транзакции под SELECT … FOR UPDATE заявки, поэтому двойной
// клик и параллельные решения не ломают состояние: второй запрос видит уже изменённые строки и получает 409.

type reqSLA struct {
	Value int    `json:"value"`
	Unit  string `json:"unit"` // h | wh | d | wd
}

type reqEsc struct {
	To     string `json:"to"` // manager | manager_up | user
	N      int    `json:"n,omitempty"`
	UserID int64  `json:"user_id,omitempty"`
}

type reqAssignee struct {
	T    string `json:"t"` // user | manager | manager_up | dept_head | group | dept | responsible | field
	ID   int64  `json:"id,omitempty"`
	N    int    `json:"n,omitempty"`
	Key  string `json:"key,omitempty"`
	Name string `json:"name,omitempty"` // подпись для конструктора (не используется движком)
}

type reqBranch struct {
	Name      string        `json:"name,omitempty"`
	Mode      string        `json:"mode"` // any | all | majority
	Assignees []reqAssignee `json:"assignees"`
}

type reqStep struct {
	ID       string        `json:"id"`
	Name     string        `json:"name"`
	Kind     string        `json:"kind"` // approve | execute | inform
	Cond     *reqCond      `json:"cond,omitempty"`
	Branches []reqBranch   `json:"branches"`
	SLA      *reqSLA       `json:"sla,omitempty"`
	RemindH  *int          `json:"remind_before_h,omitempty"`
	Escalate *reqEsc       `json:"escalate,omitempty"`
	Fallback []reqAssignee `json:"fallback,omitempty"`
}

type reqHook struct {
	Action string `json:"action"` // vacation — добавить отпуск в график руководителей
	Period string `json:"period"` // ключ поля-периода
	Deputy string `json:"deputy"` // ключ поля «пользователь» (заместитель), необязательно
	Flag   string `json:"flag"`   // ключ поля-переключателя «добавить в график»; пусто — всегда
}

type reqWF struct {
	Steps []reqStep `json:"steps"`
	Hooks []reqHook `json:"hooks,omitempty"`
}

// reqState — заявка, загруженная под блокировкой вместе со снимком схемы и маршрута.
type reqState struct {
	ID, TypeID, VersionID int64
	AuthorID              int64
	AuthorName            string
	DeptID                *int64
	Status                string
	Number, Title         string
	Data                  map[string]any
	CurStep, Round        int
	Decisions             int
	InfoBy                *int64
	Schema                *reqSchema
	WF                    *reqWF
	TypeName              string
	TypeCode, Mask        string
	SLAValue              int
	SLAUnit               string
	RemindBefore          int
	Created               time.Time
}

const reqStateSQL = `SELECT r.id, r.type_id, r.version_id, coalesce(r.author_id, 0), coalesce(u.full_name, 'Удалённый пользователь'), r.dept_id, r.status,
	coalesce(r.number, ''), r.title, r.data::text, r.cur_step, r.round, r.decisions, r.info_by, v.schema::text, v.workflow::text,
	t.name, t.code, t.number_mask, t.sla_value, t.sla_unit, t.remind_before_h, r.created_at
	FROM req_requests r JOIN req_type_versions v ON v.id = r.version_id JOIN req_types t ON t.id = r.type_id LEFT JOIN users u ON u.id = r.author_id
	WHERE r.id = $1`

func (s *Server) reqLoad(ctx context.Context, tx pgx.Tx, id int64, lock bool) (*reqState, error) {
	q := reqStateSQL
	if lock {
		q += ` FOR UPDATE OF r`
	}
	r := &reqState{}
	var data, schema, wf string
	err := tx.QueryRow(ctx, q, id).Scan(&r.ID, &r.TypeID, &r.VersionID, &r.AuthorID, &r.AuthorName, &r.DeptID, &r.Status, &r.Number, &r.Title, &data,
		&r.CurStep, &r.Round, &r.Decisions, &r.InfoBy, &schema, &wf, &r.TypeName, &r.TypeCode, &r.Mask, &r.SLAValue, &r.SLAUnit, &r.RemindBefore, &r.Created)
	if err != nil {
		return nil, err
	}
	r.Data = map[string]any{}
	if err := json.Unmarshal([]byte(data), &r.Data); err != nil {
		return nil, err
	}
	if r.Schema, err = parseSchema([]byte(schema)); err != nil {
		return nil, err
	}
	r.WF = &reqWF{}
	if err := json.Unmarshal([]byte(wf), r.WF); err != nil {
		return nil, err
	}
	return r, nil
}

// ---------------------------------------------------------------- уведомления после коммита

type reqNote struct {
	uids              []int64
	title, body, link string
}

type reqOut struct {
	id    int64
	notes []reqNote
	touch map[int64]bool
}

func newReqOut(id int64) *reqOut { return &reqOut{id: id, touch: map[int64]bool{}} }

func (o *reqOut) note(uids []int64, title, body, link string) {
	if len(uids) == 0 {
		return
	}
	o.notes = append(o.notes, reqNote{uids, title, body, link})
	for _, u := range uids {
		o.touch[u] = true
	}
}

func (o *reqOut) touchUsers(uids ...int64) {
	for _, u := range uids {
		if u > 0 {
			o.touch[u] = true
		}
	}
}

// reqFlush рассылает уведомления и событие обновления интерфейса (WS). Вызывается после COMMIT.
func (s *Server) reqFlush(ctx context.Context, o *reqOut) {
	for _, n := range o.notes {
		s.notify(ctx, n.uids, "request", n.title, n.body, n.link)
	}
	if len(o.touch) > 0 {
		ids := make([]int64, 0, len(o.touch))
		for u := range o.touch {
			ids = append(ids, u)
		}
		s.hub.EmitUsers(ctx, ids, "req", map[string]any{"id": o.id})
	}
}

func reqLink(id int64, step int64) string {
	if step > 0 {
		return fmt.Sprintf("/requests/%d#step-%d", id, step)
	}
	return fmt.Sprintf("/requests/%d", id)
}

func (r *reqState) label() string {
	if r.Number != "" {
		return r.Number
	}
	return "#" + strconv.FormatInt(r.ID, 10)
}

func (s *Server) reqEvent(ctx context.Context, tx pgx.Tx, rid int64, step int64, actor int64, kind, text string, data any) (int64, error) {
	var st, ac any
	if step > 0 {
		st = step
	}
	if actor > 0 {
		ac = actor
	}
	b := []byte("{}")
	if data != nil {
		b, _ = json.Marshal(data)
	}
	var id int64
	err := tx.QueryRow(ctx, `INSERT INTO req_events (request_id, step_id, actor_id, kind, text, data) VALUES ($1, $2, $3, $4, $5, $6::jsonb) RETURNING id`,
		rid, st, ac, kind, text, string(b)).Scan(&id)
	return id, err
}

// ---------------------------------------------------------------- нумерация

var (
	reqMaskTokRe = regexp.MustCompile(`\{(YYYY|YY|MM|DD|CODE|N+)\}`)
)

// reqNextNumber — следующий номер заявки типа. Счётчик (type_id, период) увеличивается атомарным UPDATE … RETURNING внутри
// транзакции подачи: строка счётчика блокируется до COMMIT, поэтому параллельные подачи получают подряд идущие номера,
// а откат транзакции откатывает и счётчик — дыр не бывает.
func (s *Server) reqNextNumber(ctx context.Context, tx pgx.Tx, typeID int64, mask, code string, now time.Time) (string, error) {
	now = now.In(s.reqLoc())
	period := ""
	switch {
	case strings.Contains(mask, "{DD}"):
		period = now.Format("2006-01-02")
	case strings.Contains(mask, "{MM}"):
		period = now.Format("2006-01")
	case strings.Contains(mask, "{YYYY}"), strings.Contains(mask, "{YY}"):
		period = now.Format("2006")
	}
	var n int64
	if err := tx.QueryRow(ctx, `INSERT INTO req_counters (type_id, period, value) VALUES ($1, $2, 1)
		ON CONFLICT (type_id, period) DO UPDATE SET value = req_counters.value + 1 RETURNING value`, typeID, period).Scan(&n); err != nil {
		return "", err
	}
	return reqRenderMask(mask, code, now, n), nil
}

func reqRenderMask(mask, code string, now time.Time, n int64) string {
	return reqMaskTokRe.ReplaceAllStringFunc(mask, func(tok string) string {
		switch t := strings.Trim(tok, "{}"); {
		case t == "YYYY":
			return now.Format("2006")
		case t == "YY":
			return now.Format("06")
		case t == "MM":
			return now.Format("01")
		case t == "DD":
			return now.Format("02")
		case t == "CODE":
			return code
		default:
			return fmt.Sprintf("%0*d", len(t), n)
		}
	})
}

// ---------------------------------------------------------------- исполнители

type reqPick struct {
	User int64
	Via  string
	Orig int64
}

// reqHeads — руководители по цепочке подразделений заявителя снизу вверх (без самого заявителя и дублей).
// heads[0] — непосредственный руководитель; если заявитель сам руководитель — это руководитель родительского подразделения.
func (s *Server) reqHeads(ctx context.Context, q pgx.Tx, dept *int64, author int64) ([]int64, error) {
	if dept == nil {
		return nil, nil
	}
	rows, err := q.Query(ctx, `WITH RECURSIVE up(id, parent_id, lvl) AS (
			SELECT id, parent_id, 0 FROM departments WHERE id = $1
			UNION ALL SELECT d.id, d.parent_id, up.lvl + 1 FROM departments d JOIN up ON d.id = up.parent_id WHERE up.lvl < 30)
		SELECT h.id FROM up JOIN LATERAL (
			SELECT u.id FROM users u WHERE NOT u.blocked AND u.id <> $2 AND
				u.id = coalesce((SELECT head_id FROM departments WHERE id = up.id), (SELECT x.id FROM users x WHERE x.department_id = up.id AND x.is_head AND NOT x.blocked ORDER BY x.id LIMIT 1))
		) h ON true ORDER BY up.lvl`, *dept, author)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []int64
	seen := map[int64]bool{}
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		if !seen[id] {
			seen[id] = true
			out = append(out, id)
		}
	}
	return out, rows.Err()
}

func reqScanIDs(rows pgx.Rows, err error) ([]int64, error) {
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		out = append(out, id)
	}
	return out, rows.Err()
}

const reqMaxAssignees = 200

// reqSubjectUsers раскрывает список доступа типа (ответственные / владельцы) в сотрудников.
func (s *Server) reqSubjectUsers(ctx context.Context, q pgx.Tx, typeID int64, kind string) ([]int64, error) {
	var out []int64
	add := func(rows pgx.Rows, err error) error {
		ids, e := reqScanIDs(rows, err)
		out = append(out, ids...)
		return e
	}
	if err := add(q.Query(ctx, `SELECT u.id FROM req_acl a JOIN users u ON u.id = a.subject_id WHERE a.type_id = $1 AND a.kind = $2 AND a.subject_type = 'user' AND NOT u.blocked`, typeID, kind)); err != nil {
		return nil, err
	}
	if err := add(q.Query(ctx, `SELECT DISTINCT u.id FROM req_acl a JOIN group_members m ON m.group_id = a.subject_id AND m.role <> 'pending' JOIN users u ON u.id = m.user_id
		WHERE a.type_id = $1 AND a.kind = $2 AND a.subject_type = 'group' AND NOT u.blocked LIMIT $3`, typeID, kind, reqMaxAssignees)); err != nil {
		return nil, err
	}
	if err := add(q.Query(ctx, `WITH RECURSIVE t(id) AS (SELECT subject_id FROM req_acl WHERE type_id = $1 AND kind = $2 AND subject_type = 'department'
			UNION SELECT d.id FROM departments d JOIN t ON d.parent_id = t.id)
		SELECT u.id FROM users u WHERE u.department_id IN (SELECT id FROM t) AND NOT u.blocked ORDER BY u.id LIMIT $3`, typeID, kind, reqMaxAssignees)); err != nil {
		return nil, err
	}
	if err := add(q.Query(ctx, `SELECT u.id FROM req_acl a JOIN users u ON (a.subject_key = u.role OR (a.subject_key = 'head' AND u.is_head)) AND NOT u.blocked
		WHERE a.type_id = $1 AND a.kind = $2 AND a.subject_type = 'role' ORDER BY u.id LIMIT $3`, typeID, kind, reqMaxAssignees)); err != nil {
		return nil, err
	}
	return out, nil
}

// reqUsersOf — кого означает один «исполнитель» маршрута для данной заявки.
func (s *Server) reqUsersOf(ctx context.Context, q pgx.Tx, r *reqState, a reqAssignee, heads *[]int64, headsLoaded *bool) ([]int64, error) {
	getHeads := func() ([]int64, error) {
		if !*headsLoaded {
			h, err := s.reqHeads(ctx, q, r.DeptID, r.AuthorID)
			if err != nil {
				return nil, err
			}
			*heads, *headsLoaded = h, true
		}
		return *heads, nil
	}
	switch a.T {
	case "user":
		return []int64{a.ID}, nil
	case "manager":
		h, err := getHeads()
		if err != nil || len(h) == 0 {
			return nil, err
		}
		return h[:1], nil
	case "manager_up":
		h, err := getHeads()
		n := max(a.N, 1)
		if err != nil || len(h) <= n {
			return nil, err
		}
		return h[n : n+1], nil
	case "dept_head":
		return reqScanIDs(q.Query(ctx, `SELECT u.id FROM departments d JOIN users u ON u.id = d.head_id WHERE d.id = $1 AND NOT u.blocked`, a.ID))
	case "group":
		return reqScanIDs(q.Query(ctx, `SELECT u.id FROM group_members m JOIN users u ON u.id = m.user_id WHERE m.group_id = $1 AND m.role <> 'pending' AND NOT u.blocked ORDER BY u.id LIMIT $2`, a.ID, reqMaxAssignees))
	case "dept":
		return reqScanIDs(q.Query(ctx, `SELECT u.id FROM users u WHERE u.department_id IN `+deptSubtree("$1")+` AND NOT u.blocked ORDER BY u.id LIMIT $2`, a.ID, reqMaxAssignees))
	case "responsible":
		return s.reqSubjectUsers(ctx, q, r.TypeID, "responsible")
	case "field":
		var ids []int64
		switch x := r.Data[a.Key].(type) {
		case []any:
			for _, e := range x {
				ids = append(ids, reqRefID(e))
			}
		case map[string]any:
			ids = append(ids, reqRefID(x))
		}
		return ids, nil
	}
	return nil, nil
}

// reqSubstitute заменяет сотрудников, которые сейчас в отпуске, на заместителей из графика отпусков (vacations.deputy_id).
// Заместитель в отпуске — следующий по цепочке (до 3 переходов). Нет заместителя / цепочка зациклилась — в unavailable.
func (s *Server) reqSubstitute(ctx context.Context, q pgx.Tx, ids []int64, exclude int64) (picks []reqPick, unavailable []int64, err error) {
	today := time.Now().In(s.reqLoc()).Format("2006-01-02")
	cur := make([]int64, len(ids)) // текущий кандидат для каждого исходного
	copy(cur, ids)
	dead := make([]bool, len(ids))
	for hop := 0; hop < 3; hop++ {
		var ask []int64
		for i, c := range cur {
			if !dead[i] {
				ask = append(ask, c)
			}
		}
		if len(ask) == 0 {
			break
		}
		rows, err := q.Query(ctx, `SELECT DISTINCT ON (user_id) user_id, deputy_id FROM vacations
			WHERE user_id = ANY($1::bigint[]) AND $2::date BETWEEN starts_on AND ends_on ORDER BY user_id, (deputy_id IS NULL), id DESC`, ask, today)
		if err != nil {
			return nil, nil, err
		}
		vac := map[int64]*int64{}
		for rows.Next() {
			var u int64
			var d *int64
			if err := rows.Scan(&u, &d); err != nil {
				rows.Close()
				return nil, nil, err
			}
			vac[u] = d
		}
		rows.Close()
		// заместители должны быть действующими сотрудниками
		var deps []int64
		for _, d := range vac {
			if d != nil {
				deps = append(deps, *d)
			}
		}
		ok := map[int64]bool{}
		if len(deps) > 0 {
			good, err := reqScanIDs(q.Query(ctx, `SELECT id FROM users WHERE id = ANY($1::bigint[]) AND NOT blocked`, deps))
			if err != nil {
				return nil, nil, err
			}
			for _, g := range good {
				ok[g] = true
			}
		}
		changed := false
		for i, c := range cur {
			if dead[i] {
				continue
			}
			d, onVac := vac[c]
			if !onVac {
				continue
			}
			if d != nil && ok[*d] && *d != exclude {
				cur[i] = *d
				changed = true
			} else {
				dead[i] = true
			}
		}
		if !changed {
			break
		}
	}
	// после трёх переходов заместитель мог оказаться тоже в отпуске — проверим ещё раз
	if left := func() []int64 {
		var l []int64
		for i, c := range cur {
			if !dead[i] {
				l = append(l, c)
			}
		}
		return l
	}(); len(left) > 0 {
		busy, err := reqScanIDs(q.Query(ctx, `SELECT DISTINCT user_id FROM vacations WHERE user_id = ANY($1::bigint[]) AND $2::date BETWEEN starts_on AND ends_on`, left, today))
		if err != nil {
			return nil, nil, err
		}
		bs := map[int64]bool{}
		for _, b := range busy {
			bs[b] = true
		}
		for i, c := range cur {
			if !dead[i] && bs[c] {
				dead[i] = true
			}
		}
	}
	for i, id := range ids {
		switch {
		case dead[i]:
			unavailable = append(unavailable, id)
		case cur[i] != id:
			picks = append(picks, reqPick{User: cur[i], Via: "deputy", Orig: id})
		default:
			picks = append(picks, reqPick{User: id, Via: "direct"})
		}
	}
	return picks, unavailable, nil
}

// reqResolveBranch возвращает исполнителей ветки. onlyAuthor — единственный кандидат был сам заявитель (шаг можно пропустить).
func (s *Server) reqResolveBranch(ctx context.Context, q pgx.Tx, r *reqState, specs []reqAssignee, fallback []reqAssignee) (picks []reqPick, onlyAuthor bool, err error) {
	var heads []int64
	loaded := false
	expand := func(list []reqAssignee) ([]int64, error) {
		var out []int64
		seen := map[int64]bool{}
		for _, a := range list {
			ids, err := s.reqUsersOf(ctx, q, r, a, &heads, &loaded)
			if err != nil {
				return nil, err
			}
			for _, id := range ids {
				if id > 0 && !seen[id] {
					seen[id] = true
					out = append(out, id)
				}
			}
		}
		if len(out) == 0 {
			return nil, nil
		}
		// только действующие сотрудники
		good, err := reqScanIDs(q.Query(ctx, `SELECT id FROM users WHERE id = ANY($1::bigint[]) AND NOT blocked`, out))
		if err != nil {
			return nil, err
		}
		gs := map[int64]bool{}
		for _, g := range good {
			gs[g] = true
		}
		res := out[:0]
		for _, id := range out {
			if gs[id] {
				res = append(res, id)
			}
		}
		return res, nil
	}
	cands, err := expand(specs)
	if err != nil {
		return nil, false, err
	}
	hadAuthor := false
	nonAuthor := cands[:0:0]
	for _, c := range cands {
		if c == r.AuthorID {
			hadAuthor = true
		} else {
			nonAuthor = append(nonAuthor, c)
		}
	}
	if len(cands) > reqMaxAssignees {
		nonAuthor = nonAuthor[:min(len(nonAuthor), reqMaxAssignees)]
	}
	ps, unavailable, err := s.reqSubstitute(ctx, q, nonAuthor, r.AuthorID)
	if err != nil {
		return nil, false, err
	}
	picks = ps
	if len(unavailable) > 0 { // в отпуске без заместителя — резервные согласующие шага
		fb, err := expand(fallback)
		if err != nil {
			return nil, false, err
		}
		var fbIDs []int64
		for _, f := range fb {
			if f != r.AuthorID {
				fbIDs = append(fbIDs, f)
			}
		}
		fps, fun, err := s.reqSubstitute(ctx, q, fbIDs, r.AuthorID)
		if err != nil {
			return nil, false, err
		}
		if len(fps) > 0 {
			for _, p := range fps {
				picks = append(picks, reqPick{User: p.User, Via: "fallback", Orig: unavailable[0]})
			}
		} else {
			_ = fun
			for _, u := range unavailable { // никого другого нет — остаётся тот, кто в отпуске
				picks = append(picks, reqPick{User: u, Via: "direct"})
			}
		}
	}
	// дубли
	seen := map[int64]bool{}
	out := picks[:0]
	for _, p := range picks {
		if !seen[p.User] {
			seen[p.User] = true
			out = append(out, p)
		}
	}
	return out, len(out) == 0 && hadAuthor, nil
}

// ---------------------------------------------------------------- активация шага

func reqKindVerb(kind string) string {
	switch kind {
	case "execute":
		return "требуется исполнение"
	case "inform":
		return "для ознакомления"
	}
	return "требуется ваше решение"
}

func (r *reqState) summary() string {
	if r.Title != "" {
		return r.Title
	}
	return r.TypeName
}

// reqActivate создаёт шаг маршрута и его исполнителей. active=false — шаг пропущен (исполнителем был только заявитель).
func (s *Server) reqActivate(ctx context.Context, tx pgx.Tx, r *reqState, idx int, o *reqOut) (stepID int64, active bool, err error) {
	st := &r.WF.Steps[idx]
	now := time.Now()
	type brPicks struct {
		mode  string
		picks []reqPick
	}
	var brs []brPicks
	allAuthor, anyCand := true, false
	for _, b := range st.Branches {
		picks, onlyAuthor, err := s.reqResolveBranch(ctx, tx, r, b.Assignees, st.Fallback)
		if err != nil {
			return 0, false, err
		}
		if len(picks) > 0 {
			anyCand = true
			allAuthor = false
		} else if !onlyAuthor {
			allAuthor = false
		}
		brs = append(brs, brPicks{mode: b.Mode, picks: picks})
	}
	if !anyCand && !allAuthor { // исполнителя не нашли: резерв шага → ответственные типа → владельцы
		fb, _, err := s.reqResolveBranch(ctx, tx, r, st.Fallback, nil)
		if err != nil {
			return 0, false, err
		}
		for _, kind := range []string{"responsible", "owner"} {
			if len(fb) > 0 {
				break
			}
			ids, err := s.reqSubjectUsers(ctx, tx, r.TypeID, kind)
			if err != nil {
				return 0, false, err
			}
			for _, id := range ids {
				if id != r.AuthorID {
					fb = append(fb, reqPick{User: id, Via: "fallback"})
				}
			}
		}
		if len(fb) > 0 {
			brs = []brPicks{{mode: "any", picks: fb}}
			anyCand = true
		}
	}
	state := "active"
	if allAuthor && !anyCand {
		state = "skipped"
	}
	var sid int64
	if err := tx.QueryRow(ctx, `INSERT INTO req_steps (request_id, idx, round, key, name, kind, state, finished_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, CASE WHEN $7 = 'skipped' THEN now() END) RETURNING id`,
		r.ID, idx, r.Round, st.ID, st.Name, st.Kind, state).Scan(&sid); err != nil {
		return 0, false, err
	}
	if state == "skipped" {
		_, err := s.reqEvent(ctx, tx, r.ID, sid, 0, "step_skipped", "Шаг «"+st.Name+"» пропущен: исполнителем мог быть только сам заявитель", nil)
		return sid, false, err
	}
	// срок
	sla := st.SLA
	if sla == nil && r.SLAValue > 0 {
		sla = &reqSLA{Value: r.SLAValue, Unit: r.SLAUnit}
	}
	var due, remind *time.Time
	if sla != nil {
		due = s.slaDue(now, sla.Value, sla.Unit)
	}
	rb := r.RemindBefore
	if st.RemindH != nil {
		rb = *st.RemindH
	}
	if due != nil && rb > 0 {
		t := due.Add(-time.Duration(rb) * time.Hour)
		if t.After(now) {
			remind = &t
		}
	}
	var esc any
	if st.Escalate != nil && st.Escalate.To != "" {
		b, _ := json.Marshal(st.Escalate)
		esc = string(b)
	}
	var notify, subsNote []int64
	for bi, b := range brs {
		for _, p := range b.picks {
			var orig any
			if p.Orig > 0 {
				orig = p.Orig
			}
			tag, err := tx.Exec(ctx, `INSERT INTO req_assignees (request_id, step_id, branch, mode, user_id, via, orig_user_id, due_at, remind_at, esc_to)
				VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10::jsonb) ON CONFLICT (step_id, user_id) DO NOTHING`,
				r.ID, sid, bi, b.mode, p.User, p.Via, orig, due, remind, esc)
			if err != nil {
				return 0, false, err
			}
			if tag.RowsAffected() == 0 {
				continue
			}
			notify = append(notify, p.User)
			if p.Orig > 0 {
				subsNote = append(subsNote, p.Orig)
				who := s.userName(ctx, tx, p.User)
				orig := s.userName(ctx, tx, p.Orig)
				text := fmt.Sprintf("%s в отпуске — шаг передан заместителю: %s", orig, who)
				if p.Via == "fallback" {
					text = fmt.Sprintf("%s недоступен(а) — шаг передан резервному исполнителю: %s", orig, who)
				}
				if _, err := s.reqEvent(ctx, tx, r.ID, sid, 0, "substituted", text, map[string]any{"user": p.User, "orig": p.Orig, "via": p.Via}); err != nil {
					return 0, false, err
				}
			}
		}
	}
	if _, err := s.reqEvent(ctx, tx, r.ID, sid, 0, "step_started", "Шаг «"+st.Name+"»", nil); err != nil {
		return 0, false, err
	}
	title := "Заявка " + r.label() + ": " + reqKindVerb(st.Kind)
	body := r.TypeName + " — " + r.AuthorName
	if len(notify) == 0 {
		// некому исполнять: сообщаем владельцам типа и ответственным, админ/ответственный назначит вручную
		ids, _ := s.reqSubjectUsers(ctx, tx, r.TypeID, "owner")
		var cb *int64
		_ = tx.QueryRow(ctx, `SELECT created_by FROM req_types WHERE id = $1`, r.TypeID).Scan(&cb)
		if cb != nil {
			ids = append(ids, *cb)
		}
		if _, err := s.reqEvent(ctx, tx, r.ID, sid, 0, "stuck", "Не найден исполнитель шага «"+st.Name+"» — требуется назначение вручную", nil); err != nil {
			return 0, false, err
		}
		o.note(ids, "Заявка "+r.label()+": не найден исполнитель шага «"+st.Name+"»", body, reqLink(r.ID, sid))
	}
	o.note(notify, title, body, reqLink(r.ID, sid))
	o.note(subsNote, "Заявка "+r.label()+": передана заместителю", body, reqLink(r.ID, 0))
	if due != nil {
		if _, err := tx.Exec(ctx, `UPDATE req_requests SET due_at = $2 WHERE id = $1`, r.ID, due); err != nil {
			return 0, false, err
		}
	}
	return sid, true, nil
}

func (s *Server) userName(ctx context.Context, q pgx.Tx, id int64) string {
	var n string
	_ = q.QueryRow(ctx, `SELECT full_name FROM users WHERE id = $1`, id).Scan(&n)
	return n
}

// reqRoute запускает маршрут с шага from: пропускает шаги, чьё условие не выполнено; завершает заявку, когда шаги кончились.
func (s *Server) reqRoute(ctx context.Context, tx pgx.Tx, r *reqState, from int, o *reqOut) error {
	for i := from; i < len(r.WF.Steps); i++ {
		st := &r.WF.Steps[i]
		if !st.Cond.eval(r.Data) {
			continue
		}
		sid, active, err := s.reqActivate(ctx, tx, r, i, o)
		if err != nil {
			return err
		}
		if !active {
			continue
		}
		status := "pending"
		if st.Kind == "execute" {
			status = "in_progress"
		}
		r.CurStep, r.Status = i, status
		_, err = tx.Exec(ctx, `UPDATE req_requests SET status = $2, cur_step = $3, updated_at = now() WHERE id = $1`, r.ID, status, i)
		_ = sid
		return err
	}
	return s.reqFinish(ctx, tx, r, o)
}

func (s *Server) reqFinish(ctx context.Context, tx pgx.Tx, r *reqState, o *reqOut) error {
	var executed bool
	if err := tx.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM req_steps WHERE request_id = $1 AND round = $2 AND kind = 'execute' AND state = 'done')`, r.ID, r.Round).Scan(&executed); err != nil {
		return err
	}
	status, word := "approved", "согласована"
	if executed {
		status, word = "done", "выполнена"
	}
	r.Status, r.CurStep = status, len(r.WF.Steps)
	if _, err := tx.Exec(ctx, `UPDATE req_requests SET status = $2, cur_step = $3, due_at = NULL, closed_at = now(), updated_at = now() WHERE id = $1`, r.ID, status, r.CurStep); err != nil {
		return err
	}
	if _, err := s.reqEvent(ctx, tx, r.ID, 0, 0, "status", "Заявка "+word, map[string]any{"status": status}); err != nil {
		return err
	}
	if err := s.reqHooks(ctx, tx, r, o); err != nil {
		return err
	}
	o.note([]int64{r.AuthorID}, "Заявка "+r.label()+": "+word, r.summary(), reqLink(r.ID, 0))
	return nil
}

// reqHooks — действия по завершении. Сейчас одно: добавить отпуск в график руководителей (vacations).
func (s *Server) reqHooks(ctx context.Context, tx pgx.Tx, r *reqState, o *reqOut) error {
	for _, h := range r.WF.Hooks {
		if h.Action != "vacation" {
			continue
		}
		if h.Flag != "" {
			if on, _ := r.Data[h.Flag].(bool); !on {
				continue
			}
		}
		per, ok := r.Data[h.Period].(map[string]any)
		if !ok {
			continue
		}
		from, to := reqValKey(per["from"]), reqValKey(per["to"])
		var head bool
		_ = tx.QueryRow(ctx, `SELECT is_head FROM users WHERE id = $1`, r.AuthorID).Scan(&head)
		if !head {
			if _, err := s.reqEvent(ctx, tx, r.ID, 0, 0, "note", "В график отпусков не добавлено: график ведётся только для руководителей подразделений", nil); err != nil {
				return err
			}
			continue
		}
		var dep any
		if h.Deputy != "" {
			if d := reqRefID(r.Data[h.Deputy]); d > 0 && d != r.AuthorID {
				dep = d
			}
		}
		tag, err := tx.Exec(ctx, `INSERT INTO vacations (user_id, starts_on, ends_on, deputy_id, note, created_by)
			SELECT $1, $2::date, $3::date, $4, $5, $1
			WHERE NOT EXISTS (SELECT 1 FROM vacations WHERE user_id = $1 AND starts_on = $2::date AND ends_on = $3::date)`,
			r.AuthorID, from, to, dep, "По заявке "+r.label())
		if err != nil {
			return err
		}
		if tag.RowsAffected() > 0 {
			if _, err := s.reqEvent(ctx, tx, r.ID, 0, 0, "note", "Отпуск добавлен в график отпусков руководителей", nil); err != nil {
				return err
			}
			if d, ok := dep.(int64); ok {
				o.note([]int64{d}, "Вы замещаете: "+r.AuthorName, from+" — "+to, "/vacations")
			}
		}
	}
	return nil
}

// ---------------------------------------------------------------- решения

type reqAsg struct {
	ID, StepID int64
	Branch     int
	Mode       string
	User       int64
	State      string
	Via        string
	Orig       *int64
	Kind       string
	StepName   string
	StepIdx    int
}

func reqOKState(st string) bool  { return st == "approved" || st == "done" || st == "acked" }
func reqBadState(st string) bool { return st == "rejected" }

// reqEvalStep пересчитывает состояние шага после изменения исполнителей. Возвращает true, если заявка переведена дальше.
func (s *Server) reqEvalStep(ctx context.Context, tx pgx.Tx, r *reqState, stepID int64, lastActor int64, o *reqOut) error {
	rows, err := tx.Query(ctx, `SELECT a.id, a.branch, a.mode, a.user_id, a.state, a.via, a.orig_user_id, s.idx, s.name, s.kind
		FROM req_assignees a JOIN req_steps s ON s.id = a.step_id WHERE a.step_id = $1 ORDER BY a.id`, stepID)
	if err != nil {
		return err
	}
	var list []reqAsg
	for rows.Next() {
		var a reqAsg
		a.StepID = stepID
		if err := rows.Scan(&a.ID, &a.Branch, &a.Mode, &a.User, &a.State, &a.Via, &a.Orig, &a.StepIdx, &a.StepName, &a.Kind); err != nil {
			rows.Close()
			return err
		}
		list = append(list, a)
	}
	rows.Close()
	if len(list) == 0 {
		return nil
	}
	byBranch := map[int][]reqAsg{}
	for _, a := range list {
		byBranch[a.Branch] = append(byBranch[a.Branch], a)
	}
	allOK, anyBad := true, false
	var badBy int64
	for _, rowsB := range byBranch {
		total, ok, bad := 0, 0, 0
		mode := "any"
		for _, a := range rowsB {
			if a.Via != "escalation" {
				mode = a.Mode
			}
			switch {
			case a.State == "delegated" || a.State == "skipped" || a.State == "returned":
				continue
			case a.Via == "escalation" && a.State == "pending":
				continue // запасной исполнитель не увеличивает требуемое число решений
			}
			total++
			if reqOKState(a.State) {
				ok++
			} else if reqBadState(a.State) {
				bad++
				badBy = a.User
			}
		}
		var res string // ok | bad | wait
		switch mode {
		case "all":
			switch {
			case bad > 0:
				res = "bad"
			case ok == total && total > 0:
				res = "ok"
			}
		case "majority":
			switch {
			case total > 0 && ok*2 > total:
				res = "ok"
			case total > 0 && bad*2 >= total:
				res = "bad"
			}
		default:
			switch {
			case ok > 0:
				res = "ok"
			case bad > 0:
				res = "bad"
			}
		}
		switch res {
		case "bad":
			anyBad = true
		case "ok":
		default:
			allOK = false
		}
	}
	if anyBad {
		_, err := tx.Exec(ctx, `UPDATE req_assignees SET state = 'skipped' WHERE step_id = $1 AND state = 'pending'`, stepID)
		if err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE req_steps SET state = 'rejected', finished_at = now() WHERE id = $1`, stepID); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE req_requests SET status = 'rejected', due_at = NULL, closed_at = now(), updated_at = now() WHERE id = $1`, r.ID); err != nil {
			return err
		}
		r.Status = "rejected"
		if _, err := s.reqEvent(ctx, tx, r.ID, 0, 0, "status", "Заявка отклонена", map[string]any{"status": "rejected"}); err != nil {
			return err
		}
		var cmt string
		_ = tx.QueryRow(ctx, `SELECT comment FROM req_assignees WHERE step_id = $1 AND user_id = $2`, stepID, badBy).Scan(&cmt)
		o.note([]int64{r.AuthorID}, "Заявка "+r.label()+": отклонена", strings.TrimSpace(r.summary()+"\n"+cmt), reqLink(r.ID, stepID))
		return nil
	}
	if !allOK {
		// ветка завершилась, но другие ещё ждут: оставшиеся «ожидающие» этой ветки снимаются в блоке ниже
		return s.reqSkipResolvedBranches(ctx, tx, stepID, byBranch)
	}
	if _, err := tx.Exec(ctx, `UPDATE req_assignees SET state = 'skipped' WHERE step_id = $1 AND state = 'pending'`, stepID); err != nil {
		return err
	}
	if _, err := tx.Exec(ctx, `UPDATE req_steps SET state = 'done', finished_at = now() WHERE id = $1`, stepID); err != nil {
		return err
	}
	return s.reqRoute(ctx, tx, r, r.CurStep+1, o)
}

// reqSkipResolvedBranches: в ветке режима «достаточно одного» после решения остальные «ожидающие» снимаются с «На мне».
func (s *Server) reqSkipResolvedBranches(ctx context.Context, tx pgx.Tx, stepID int64, byBranch map[int][]reqAsg) error {
	for br, rowsB := range byBranch {
		mode, ok, bad := "any", 0, 0
		for _, a := range rowsB {
			if a.Via != "escalation" {
				mode = a.Mode
			}
			if reqOKState(a.State) {
				ok++
			}
			if reqBadState(a.State) {
				bad++
			}
		}
		if mode == "any" && ok > 0 {
			if _, err := tx.Exec(ctx, `UPDATE req_assignees SET state = 'skipped' WHERE step_id = $1 AND branch = $2 AND state = 'pending'`, stepID, br); err != nil {
				return err
			}
		}
	}
	return nil
}

var reqActionsByKind = map[string]map[string]bool{
	"approve": {"approve": true, "reject": true, "return": true, "ask": true, "delegate": true},
	"execute": {"execute": true, "reject": true, "return": true, "ask": true, "delegate": true},
	"inform":  {"ack": true, "ask": true, "delegate": true},
}

var reqActionState = map[string]string{"approve": "approved", "execute": "done", "ack": "acked", "reject": "rejected", "return": "returned"}

var reqActionEvent = map[string]string{"approve": "approved", "execute": "executed", "ack": "acked", "reject": "rejected", "return": "returned", "ask": "question", "delegate": "delegated"}

var reqActionWord = map[string]string{"approve": "согласовано", "execute": "исполнено", "ack": "ознакомлен(а)", "reject": "отклонено", "return": "возвращено на доработку", "ask": "запрошена информация", "delegate": "передано"}

type reqActIn struct {
	Action  string         `json:"action"`
	Comment string         `json:"comment"`
	StepID  int64          `json:"step_id"`
	To      int64          `json:"to"`
	Files   []int64        `json:"files"`
	Data    map[string]any `json:"data"`
}

// reqAct выполняет действие исполнителя над своей позицией на активном шаге.
func (s *Server) reqAct(ctx context.Context, tx pgx.Tx, r *reqState, uid int64, in *reqActIn, o *reqOut) error {
	if r.Status != "pending" && r.Status != "in_progress" {
		return conflict("Заявка уже не на согласовании")
	}
	var a reqAsg
	err := tx.QueryRow(ctx, `SELECT a.id, a.step_id, a.branch, a.mode, a.user_id, a.state, a.via, a.orig_user_id, s.kind, s.name, s.idx
		FROM req_assignees a JOIN req_steps s ON s.id = a.step_id
		WHERE a.request_id = $1 AND a.user_id = $2 AND a.state = 'pending' AND s.state = 'active' AND ($3::bigint = 0 OR a.step_id = $3)
		ORDER BY a.id LIMIT 1 FOR UPDATE OF a`, r.ID, uid, in.StepID).
		Scan(&a.ID, &a.StepID, &a.Branch, &a.Mode, &a.User, &a.State, &a.Via, &a.Orig, &a.Kind, &a.StepName, &a.StepIdx)
	if err == pgx.ErrNoRows {
		return conflict("Решение уже принято или шаг сейчас не ожидает вашего решения")
	}
	if err != nil {
		return err
	}
	if !reqActionsByKind[a.Kind][in.Action] {
		return badReq("Это действие недоступно на данном шаге")
	}
	in.Comment = strings.TrimSpace(in.Comment)
	if reqRuneLen(in.Comment) > 5000 {
		return badReq("Комментарий слишком длинный")
	}
	if (in.Action == "reject" || in.Action == "return" || in.Action == "ask") && in.Comment == "" {
		return badReq(map[string]string{"reject": "Укажите причину отказа", "return": "Укажите, что нужно доработать", "ask": "Напишите вопрос заявителю"}[in.Action])
	}
	actor := s.userName(ctx, tx, uid)
	evKind := reqActionEvent[in.Action]
	evText := in.Comment
	data := map[string]any{"action": in.Action, "step": a.StepName}

	switch in.Action {
	case "ask":
		if _, err := tx.Exec(ctx, `UPDATE req_requests SET info_by = $2, updated_at = now() WHERE id = $1`, r.ID, uid); err != nil {
			return err
		}
		eid, err := s.reqEvent(ctx, tx, r.ID, a.StepID, uid, evKind, evText, data)
		if err != nil {
			return err
		}
		if err := s.reqLinkFiles(ctx, tx, r.ID, eid, uid, in.Files); err != nil {
			return err
		}
		o.note([]int64{r.AuthorID}, "Заявка "+r.label()+": "+actor+" запрашивает информацию", in.Comment, reqLink(r.ID, a.StepID))
		o.touchUsers(uid)
		return nil
	case "delegate":
		if in.To <= 0 || in.To == uid {
			return badReq("Выберите сотрудника, которому передать")
		}
		if in.To == r.AuthorID {
			return badReq("Нельзя передать заявителю")
		}
		var okU bool
		if err := tx.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM users WHERE id = $1 AND NOT blocked)`, in.To).Scan(&okU); err != nil || !okU {
			return badReq("Сотрудник не найден")
		}
		var exists bool
		if err := tx.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM req_assignees WHERE step_id = $1 AND user_id = $2 AND state = 'pending')`, a.StepID, in.To).Scan(&exists); err != nil {
			return err
		}
		if exists {
			return conflict("Этот сотрудник уже участвует в шаге")
		}
		if _, err := tx.Exec(ctx, `UPDATE req_assignees SET state = 'delegated', decided_at = now(), comment = $2 WHERE id = $1`, a.ID, in.Comment); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `INSERT INTO req_assignees (request_id, step_id, branch, mode, user_id, via, orig_user_id, due_at, remind_at, esc_to)
			SELECT request_id, step_id, branch, mode, $2, 'delegate', $3, due_at, remind_at, esc_to FROM req_assignees WHERE id = $1
			ON CONFLICT (step_id, user_id) DO UPDATE SET state = 'pending', via = 'delegate', orig_user_id = $3, decided_at = NULL`, a.ID, in.To, uid); err != nil {
			return err
		}
		to := s.userName(ctx, tx, in.To)
		data["to"] = in.To
		if _, err := s.reqEvent(ctx, tx, r.ID, a.StepID, uid, evKind, fmt.Sprintf("Передано: %s%s", to, map[bool]string{true: " — " + in.Comment}[in.Comment != ""]), data); err != nil {
			return err
		}
		o.note([]int64{in.To}, "Заявка "+r.label()+": "+actor+" передал(а) вам шаг", r.TypeName+" — "+r.AuthorName, reqLink(r.ID, a.StepID))
		o.touchUsers(uid, r.AuthorID)
		return nil
	}

	// решение: approve | reject | return | execute | ack
	newState := reqActionState[in.Action]
	if _, err := tx.Exec(ctx, `UPDATE req_assignees SET state = $2, decided_at = now(), comment = $3 WHERE id = $1`, a.ID, newState, in.Comment); err != nil {
		return err
	}
	// запасные исполнители (эскалация) и исходный исполнитель, которого заменил эскалированный
	if a.Via == "escalation" && a.Orig != nil {
		if _, err := tx.Exec(ctx, `UPDATE req_assignees SET state = 'skipped' WHERE step_id = $1 AND user_id = $2 AND state = 'pending'`, a.StepID, *a.Orig); err != nil {
			return err
		}
	}
	if _, err := tx.Exec(ctx, `UPDATE req_assignees SET state = 'skipped' WHERE step_id = $1 AND via = 'escalation' AND orig_user_id = $2 AND state = 'pending'`, a.StepID, uid); err != nil {
		return err
	}
	if _, err := tx.Exec(ctx, `UPDATE req_requests SET decisions = decisions + 1, info_by = NULL, updated_at = now() WHERE id = $1`, r.ID); err != nil {
		return err
	}
	r.Decisions++
	if in.Action == "execute" && len(in.Files) > 0 {
		data["files"] = len(in.Files)
	}
	eid, err := s.reqEvent(ctx, tx, r.ID, a.StepID, uid, evKind, evText, data)
	if err != nil {
		return err
	}
	if err := s.reqLinkFiles(ctx, tx, r.ID, eid, uid, in.Files); err != nil {
		return err
	}
	o.touchUsers(uid)
	if in.Action == "return" {
		if _, err := tx.Exec(ctx, `UPDATE req_assignees SET state = 'skipped' WHERE step_id = $1 AND state = 'pending'`, a.StepID); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE req_steps SET state = 'returned', finished_at = now() WHERE id = $1`, a.StepID); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE req_requests SET status = 'rework', due_at = NULL, updated_at = now() WHERE id = $1`, r.ID); err != nil {
			return err
		}
		r.Status = "rework"
		if _, err := s.reqEvent(ctx, tx, r.ID, 0, 0, "status", "Заявка возвращена на доработку", map[string]any{"status": "rework"}); err != nil {
			return err
		}
		o.note([]int64{r.AuthorID}, "Заявка "+r.label()+": возвращена на доработку", in.Comment, reqLink(r.ID, a.StepID))
		return nil
	}
	if in.Action == "execute" && in.Data != nil {
		_ = in.Data
	}
	if in.Action == "execute" || in.Action == "ack" || in.Action == "approve" {
		if in.Action == "execute" {
			o.note([]int64{r.AuthorID}, "Заявка "+r.label()+": "+actor+" исполнил(а) шаг «"+a.StepName+"»", reqFirst(in.Comment, r.summary()), reqLink(r.ID, a.StepID))
		}
	}
	if in.Action == "reject" {
		// уведомление автору отправит reqEvalStep вместе с итоговым статусом
	}
	return s.reqEvalStep(ctx, tx, r, a.StepID, uid, o)
}

func reqFirst(a ...string) string {
	for _, x := range a {
		if strings.TrimSpace(x) != "" {
			return x
		}
	}
	return ""
}

// reqLinkFiles привязывает загруженные пользователем файлы к событию журнала (комментарий / результат исполнения).
func (s *Server) reqLinkFiles(ctx context.Context, tx pgx.Tx, rid, eid, uid int64, ids []int64) error {
	if len(ids) == 0 {
		return nil
	}
	if len(ids) > 10 {
		return badReq("Не более 10 файлов")
	}
	tag, err := tx.Exec(ctx, `INSERT INTO req_files (file_id, request_id, event_id, field_key)
		SELECT f.id, $1, $2, '' FROM files f WHERE f.id = ANY($3::bigint[]) AND f.context = 'request' AND f.owner_id = $4
		AND NOT EXISTS (SELECT 1 FROM req_files x WHERE x.file_id = f.id)`, rid, eid, ids, uid)
	if err != nil {
		return err
	}
	if int(tag.RowsAffected()) != len(reqUniqueIDs(ids)) {
		return badReq("Один из файлов недоступен")
	}
	return nil
}

func reqUniqueIDs(ids []int64) []int64 {
	seen := map[int64]bool{}
	out := make([]int64, 0, len(ids))
	for _, i := range ids {
		if !seen[i] {
			seen[i] = true
			out = append(out, i)
		}
	}
	sort.Slice(out, func(a, b int) bool { return out[a] < out[b] })
	return out
}

// reqResubmit — повторная отправка после доработки: новый круг согласования с первого шага.
func (s *Server) reqRestart(ctx context.Context, tx pgx.Tx, r *reqState, o *reqOut) error {
	r.Round++
	if _, err := tx.Exec(ctx, `UPDATE req_requests SET round = $2, info_by = NULL, status = 'pending', updated_at = now() WHERE id = $1`, r.ID, r.Round); err != nil {
		return err
	}
	return s.reqRoute(ctx, tx, r, 0, o)
}
