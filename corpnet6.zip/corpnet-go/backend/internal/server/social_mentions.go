package server

import (
	"context"
	"regexp"
	"strconv"
	"strings"

	"github.com/jackc/pgx/v5"
)

// Упоминания @логин: в тексте хранится «@логин»; при сохранении комментария/сообщения/поста/идеи текст разбирается,
// в таблицу mentions попадают только те, кто видит объект (строка = «уже уведомлён», поэтому правка не даёт дублей),
// и каждому новому адресату уходит уведомление kind="mention" со ссылкой-якорем на конкретный объект.
//
// Подключить в новом типе текста: после INSERT/UPDATE вызвать
//
//	s.syncMentions(ctx, mentionSrc{Type: "wiki_comment", ID: id, Actor: c.U, Body: body, Link: "/wiki/5#c-"+id, Where: "в комментарии", Title: title, Audience: audienceAll})
//
// (Audience ограничивает круг тех, кто может получить уведомление: весь портал, участники чата или читатели группы.)

// @ после границы слова (не часть e-mail: перед @ не может быть буква/цифра/._%+-), логин — буквы, цифры, _ . -
var mentionRe = regexp.MustCompile(`(?:^|[^\p{L}\p{N}_@.+%-])@([\p{L}\p{N}_][\p{L}\p{N}_.-]{0,62})`)

const maxMentions = 20

// parseMentions — уникальные логины (нижний регистр) в порядке появления.
func parseMentions(body string) []string {
	var out []string
	seen := map[string]bool{}
	for _, m := range mentionRe.FindAllStringSubmatch(body, -1) {
		l := strings.ToLower(strings.TrimRight(m[1], ".-"))
		if l == "" || seen[l] {
			continue
		}
		seen[l] = true
		out = append(out, l)
		if len(out) >= maxMentions {
			break
		}
	}
	return out
}

// mentionAudience ограничивает адресатов: chat — участники чата, group — читатели группы, иначе — любой активный сотрудник.
type mentionAudience struct{ Chat, Group int64 }

var audienceAll = mentionAudience{}

func (s *Server) audienceFilter(ctx context.Context, a mentionAudience, ids []int64) ([]int64, error) {
	var q string
	var args []any
	switch {
	case a.Chat > 0:
		q, args = `SELECT cm.user_id FROM chat_members cm JOIN users u ON u.id = cm.user_id WHERE cm.chat_id = $1 AND cm.user_id = ANY($2) AND NOT u.blocked`, []any{a.Chat, ids}
	case a.Group > 0:
		q, args = `SELECT u.id FROM users u JOIN user_groups g ON g.id = $1 WHERE u.id = ANY($2) AND NOT u.blocked AND (g.visibility = 'public' OR u.role = 'admin'
			OR EXISTS (SELECT 1 FROM group_members m WHERE m.group_id = g.id AND m.user_id = u.id AND m.role <> 'pending'))`, []any{a.Group, ids}
	default:
		q, args = `SELECT id FROM users WHERE id = ANY($1) AND NOT blocked`, []any{ids}
	}
	rows, err := s.db.Query(ctx, q, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []int64{}
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		out = append(out, id)
	}
	return out, rows.Err()
}

type mentionSrc struct {
	Type     string // comment | message | post | idea
	ID       int64
	Actor    *User
	Body     string
	Link     string // абсолютный путь SPA с якорем: /news/5#comment-9, /messages?chat=2&msg=7, /groups/3?post=4
	Where    string // «в комментарии», «в сообщении», «в публикации группы», «в идее»
	Title    string // заголовок объекта (новость, чат, группа) — в тексте уведомления
	Audience mentionAudience
	Exclude  []int64 // уже уведомлённые другим способом (автор новости, автор родительского комментария)
}

// syncMentions приводит mentions объекта в соответствие с текстом и уведомляет только новых адресатов.
func (s *Server) syncMentions(ctx context.Context, m mentionSrc) {
	logins := parseMentions(m.Body)
	var ids []int64
	if len(logins) > 0 {
		rows, err := s.db.Query(ctx, `SELECT id FROM users WHERE lower(login) = ANY($1) AND id <> $2 AND NOT blocked`, logins, m.Actor.ID)
		if err != nil {
			s.log.Warn("mentions: lookup failed", "err", err)
			return
		}
		for rows.Next() {
			var id int64
			if rows.Scan(&id) == nil {
				ids = append(ids, id)
			}
		}
		rows.Close()
	}
	if len(ids) > 0 {
		var err error
		if ids, err = s.audienceFilter(ctx, m.Audience, ids); err != nil {
			s.log.Warn("mentions: audience failed", "err", err)
			return
		}
	}
	if ids == nil {
		ids = []int64{}
	}
	var fresh []int64
	err := s.tx(ctx, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `DELETE FROM mentions WHERE entity_type = $1 AND entity_id = $2 AND NOT (user_id = ANY($3))`, m.Type, m.ID, ids); err != nil {
			return err
		}
		if len(ids) == 0 {
			return nil
		}
		rows, err := tx.Query(ctx, `INSERT INTO mentions (entity_type, entity_id, user_id) SELECT $1, $2, x FROM unnest($3::bigint[]) x
			ON CONFLICT DO NOTHING RETURNING user_id`, m.Type, m.ID, ids)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var id int64
			if err := rows.Scan(&id); err != nil {
				return err
			}
			fresh = append(fresh, id)
		}
		return rows.Err()
	})
	if err != nil {
		s.log.Warn("mentions: sync failed", "err", err)
		return
	}
	skip := map[int64]bool{}
	for _, id := range m.Exclude {
		skip[id] = true
	}
	var to []int64
	for _, id := range fresh {
		if !skip[id] {
			to = append(to, id)
		}
	}
	if len(to) == 0 {
		return
	}
	title := m.Actor.Name + " упомянул(а) вас " + m.Where
	if m.Title != "" {
		title += ": " + m.Title
	}
	s.notify(ctx, to, "mention", title, snippet(m.Body, 140), m.Link)
}

func snippet(body string, n int) string {
	body = socialOneLine(body)
	if r := []rune(body); len(r) > n {
		return string(r[:n]) + "…"
	}
	return body
}

// ---------------------------------------------------------------- автодополнение

// GET /api/mentions/suggest?q=&scope=chat|group|post|news|idea&id= — до 8 сотрудников; сначала участники чата/группы/обсуждения.
func (s *Server) mentionSuggest(c *Ctx) error {
	ctx := c.Context()
	q := strings.ToLower(strings.TrimSpace(strings.TrimPrefix(c.Q("q"), "@")))
	if len([]rune(q)) > 40 {
		q = string([]rune(q)[:40])
	}
	id := c.QInt64("id")
	near := []int64{}
	switch c.Q("scope") {
	case "chat":
		if ok, err := s.isMember(ctx, id, c.U.ID); err != nil {
			return err
		} else if ok {
			near, _ = s.chatMembers(ctx, id)
		}
	case "group", "post":
		gid := id
		if c.Q("scope") == "post" {
			if err := s.db.QueryRow(ctx, `SELECT group_id FROM group_posts WHERE id = $1`, id).Scan(&gid); err != nil {
				return errNotFound
			}
		}
		g, err := s.groupInfo(ctx, gid, c.U)
		if err != nil {
			return err
		}
		if !g.canRead(c.U) {
			return errForbidden
		}
		rows, err := s.db.Query(ctx, `SELECT user_id FROM group_members WHERE group_id = $1 AND role <> 'pending' LIMIT 300`, gid)
		if err != nil {
			return err
		}
		for rows.Next() {
			var u int64
			if rows.Scan(&u) == nil {
				near = append(near, u)
			}
		}
		rows.Close()
	case "news", "idea":
		typ := c.Q("scope")
		author, _, _, err := s.entityAccess(ctx, c.U, typ, id)
		if err != nil {
			return err
		}
		// автор и участники обсуждения (последние комментаторы)
		rows, err := s.db.Query(ctx, `SELECT x FROM (SELECT DISTINCT user_id AS x FROM (SELECT user_id FROM comments WHERE entity_type = $1 AND entity_id = $2 AND user_id IS NOT NULL
			ORDER BY id DESC LIMIT 200) c) t LIMIT 100`, typ, id)
		if err != nil {
			return err
		}
		for rows.Next() {
			var u int64
			if rows.Scan(&u) == nil {
				near = append(near, u)
			}
		}
		rows.Close()
		if author != 0 {
			near = append(near, author)
		}
	}
	var pre, sub any
	if q != "" {
		pre = likeEscape(q) + "%"
		if len([]rune(q)) >= 3 {
			sub = "%" + likeEscape(q) + "%"
		}
	}
	rows, err := s.db.Query(ctx, `SELECT u.id, u.login, u.full_name, u.avatar, u.job_title, u.id = ANY($2) AS near
		FROM users u
		WHERE NOT u.blocked AND u.id <> $3 AND (
			($1::text IS NULL AND u.id = ANY($2))
			OR ($1::text IS NOT NULL AND (lower(u.login) LIKE $1 ESCAPE '\' OR lower(u.last_name) LIKE $1 ESCAPE '\' OR lower(u.first_name) LIKE $1 ESCAPE '\'
				OR ($4::text IS NOT NULL AND u.search_text LIKE $4 ESCAPE '\')))
		)
		ORDER BY near DESC, ($1::text IS NOT NULL AND lower(u.login) LIKE $1 ESCAPE '\') DESC, lower(u.last_name), lower(u.first_name), u.id LIMIT 8`,
		pre, near, c.U.ID, sub)
	if err != nil {
		return err
	}
	defer rows.Close()
	type row struct {
		ID     int64  `json:"id"`
		Login  string `json:"login"`
		Name   string `json:"name"`
		Avatar string `json:"avatar"`
		Title  string `json:"job_title"`
		Near   bool   `json:"near"`
	}
	out := []row{}
	for rows.Next() {
		var r row
		if err := rows.Scan(&r.ID, &r.Login, &r.Name, &r.Avatar, &r.Title, &r.Near); err != nil {
			return err
		}
		out = append(out, r)
	}
	return c.JSON(200, out)
}

// GET /api/mentions/resolve?logins=a,b,c — для отрисовки @логин ссылкой на профиль (пакетно, клиент кэширует).
func (s *Server) mentionResolve(c *Ctx) error {
	var logins []string
	for _, l := range strings.Split(c.Q("logins"), ",") {
		if l = strings.ToLower(strings.TrimSpace(l)); l != "" && len(l) <= 64 {
			logins = append(logins, l)
		}
		if len(logins) >= 40 {
			break
		}
	}
	if logins == nil {
		logins = []string{}
	}
	rows, err := s.db.Query(c.Context(), `SELECT lower(login), id, full_name, avatar FROM users WHERE lower(login) = ANY($1)`, logins)
	if err != nil {
		return err
	}
	defer rows.Close()
	type u struct {
		ID     int64  `json:"id"`
		Name   string `json:"name"`
		Avatar string `json:"avatar"`
	}
	out := map[string]u{}
	for rows.Next() {
		var l string
		var x u
		if err := rows.Scan(&l, &x.ID, &x.Name, &x.Avatar); err != nil {
			return err
		}
		out[l] = x
	}
	return c.JSON(200, out)
}

// messageMentions — упоминания в сообщении чата (адресаты — только участники чата, личный чат не раскрывается посторонним).
func (s *Server) messageMentions(ctx context.Context, u *User, mid, chat int64, body string) {
	if !strings.Contains(body, "@") && body != "" {
		// без «@» новых упоминаний нет, но при правке старые нужно снять
		s.db.Exec(ctx, `DELETE FROM mentions WHERE entity_type = 'message' AND entity_id = $1`, mid)
		return
	}
	var title string
	s.db.QueryRow(ctx, `SELECT CASE WHEN kind = 'group' THEN title ELSE '' END FROM chats WHERE id = $1`, chat).Scan(&title)
	s.syncMentions(ctx, mentionSrc{Type: "message", ID: mid, Actor: u, Body: body, Where: "в сообщении", Title: title,
		Link: "/messages?chat=" + strconv.FormatInt(chat, 10) + "&msg=" + strconv.FormatInt(mid, 10), Audience: mentionAudience{Chat: chat}})
}
