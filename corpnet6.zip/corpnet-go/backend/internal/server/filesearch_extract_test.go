package server

import (
	"archive/zip"
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func mkZip(t *testing.T, files map[string]string) string {
	t.Helper()
	p := filepath.Join(t.TempDir(), "x.zip")
	f, _ := os.Create(p)
	zw := zip.NewWriter(f)
	for n, c := range files {
		w, _ := zw.Create(n)
		w.Write([]byte(c))
	}
	zw.Close()
	f.Close()
	return p
}

func TestExtractOffice(t *testing.T) {
	ctx := context.Background()
	cases := []struct {
		name  string
		files map[string]string
		want  string
	}{
		{"a.docx", map[string]string{"word/document.xml": `<w:document xmlns:w="x"><w:body><w:p><w:r><w:t>При</w:t></w:r><w:r><w:t>вет</w:t></w:r></w:p><w:p><w:r><w:t>мир</w:t></w:r></w:p></w:body></w:document>`}, "Привет мир"},
		{"a.xlsx", map[string]string{"xl/sharedStrings.xml": `<sst><si><t>Бюджет</t></si><si><r><t>План</t></r></si></sst>`}, "Бюджет План"},
		{"a.pptx", map[string]string{"ppt/slides/slide2.xml": `<p:sld><a:p><a:r><a:t>второй</a:t></a:r></a:p></p:sld>`, "ppt/slides/slide1.xml": `<p:sld><a:p><a:r><a:t>первый</a:t></a:r></a:p></p:sld>`}, "первый второй"},
		{"a.odt", map[string]string{"content.xml": `<office:document-content><office:automatic-styles><style:style name="skipme"/></office:automatic-styles><office:body><text:p>Абзац <text:span>один</text:span></text:p><text:p>два</text:p></office:body></office:document-content>`}, "Абзац один два"},
	}
	for _, c := range cases {
		got, err := extractText(ctx, mkZip(t, c.files), c.name, "application/zip", 1000)
		if err != nil || got != c.want {
			t.Errorf("%s: got %q err %v, want %q", c.name, got, err, c.want)
		}
	}
}

func TestZipBomb(t *testing.T) {
	big := strings.Repeat("<w:t>a</w:t>", 40<<20/12*4) // ~160 МБ в xml, сжимается в крошку
	p := mkZip(t, map[string]string{"word/document.xml": "<w:document><w:p>" + big + "</w:p></w:document>"})
	got, err := extractText(context.Background(), p, "bomb.docx", "", 1000)
	if err == nil && len(got) > idxMaxText {
		t.Fatalf("text not limited: %d", len(got))
	}
	// текст ограничен 1 МБ даже без ошибки
	if err == nil && len(got) == 0 {
		t.Fatal("empty")
	}
}

func TestPlainAndEncodings(t *testing.T) {
	d := t.TempDir()
	w := func(n string, b []byte) string { p := filepath.Join(d, n); os.WriteFile(p, b, 0o644); return p }
	ctx := context.Background()
	got, _ := extractText(ctx, w("a.txt", []byte{0xCF, 0xF0, 0xE8, 0xE2, 0xE5, 0xF2, ' ', 0xEC, 0xE8, 0xF0}), "a.txt", "text/plain", 10)
	if got != "Привет мир" {
		t.Errorf("cp1251: %q", got)
	}
	got, _ = extractText(ctx, w("b.html", []byte(`<html><head><title>x</title></head><body><script>var a=1</script><p>Hello&nbsp;<b>мир</b></p></body></html>`)), "b.html", "text/html", 10)
	if !strings.Contains(got, "мир") || strings.Contains(got, "var") || strings.Contains(got, "title") {
		t.Errorf("html: %q", got)
	}
	got, _ = extractText(ctx, w("c.rtf", []byte("{\\rtf1\\ansi{\\fonttbl{\\f0 Arial;}}\\f0 Hello "+u("1055")+u("1088")+u("1080")+u("1074")+u("1077")+u("1090")+" \\'ec\\'e8\\'f0\\par next}")), "c.rtf", "", 10)
	if !strings.Contains(got, "Hello Привет мир") || strings.Contains(got, "Arial") {
		t.Errorf("rtf: %q", got)
	}
	if _, err := extractText(ctx, w("d.bin", []byte("x")), "d.bin", "application/octet-stream", 1); err != errUnsupported {
		t.Errorf("unsupported: %v", err)
	}
	got, _ = extractText(ctx, w("e.xml", []byte(`<a><b>один</b><c>два</c></a>`)), "e.xml", "", 10)
	if got != "один два" && got != "одиндва" {
		t.Errorf("xml: %q", got)
	}
}

// u — RTF-эскейп \uN? (замена ASCII — «?»)
func u(n string) string { return "\\u" + n + "?" }
