package server

// Метрики Prometheus в text-формате без внешних модулей.

import (
	"bufio"
	"context"
	"crypto/subtle"
	"fmt"
	"net"
	"net/http"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

var (
	// секунды; подходит и для HTTP, и для SQL, и для Redis
	monBuckets = []float64{.001, .005, .01, .025, .05, .1, .25, .5, 1, 2.5, 5, 10, 30}
	appVersion = env("APP_VERSION", "dev")
)

type monHist struct {
	mu     sync.Mutex
	counts []uint64 // кумулятивно считаем при выводе
	sum    float64
	n      uint64
}

func newHist() *monHist { return &monHist{counts: make([]uint64, len(monBuckets))} }

func (h *monHist) observe(sec float64) {
	h.mu.Lock()
	for i, b := range monBuckets {
		if sec <= b {
			h.counts[i]++
			break
		}
	}
	h.sum += sec
	h.n++
	h.mu.Unlock()
}

func (h *monHist) write(w *bufio.Writer, name, labels string) {
	h.mu.Lock()
	counts, sum, n := append([]uint64(nil), h.counts...), h.sum, h.n
	h.mu.Unlock()
	var cum uint64
	sep := ""
	if labels != "" {
		sep = ","
	}
	for i, b := range monBuckets {
		cum += counts[i]
		fmt.Fprintf(w, "%s_bucket{%s%sle=\"%s\"} %d\n", name, labels, sep, strconv.FormatFloat(b, 'f', -1, 64), cum)
	}
	fmt.Fprintf(w, "%s_bucket{%s%sle=\"+Inf\"} %d\n", name, labels, sep, n)
	fmt.Fprintf(w, "%s_sum{%s} %g\n%s_count{%s} %d\n", name, labels, sum, name, labels, n)
}

// monSet — именованный набор гистограмм/счётчиков по ключу-лейблам.
type monSet[T any] struct {
	mu sync.RWMutex
	m  map[string]*T
}

func (s *monSet[T]) get(key string, mk func() *T) *T {
	s.mu.RLock()
	v := s.m[key]
	s.mu.RUnlock()
	if v != nil {
		return v
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.m == nil {
		s.m = map[string]*T{}
	}
	if v = s.m[key]; v == nil {
		v = mk()
		s.m[key] = v
	}
	return v
}

func (s *monSet[T]) keys() []string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	ks := make([]string, 0, len(s.m))
	for k := range s.m {
		ks = append(ks, k)
	}
	sort.Strings(ks)
	return ks
}

type monCounter struct {
	mu sync.Mutex
	v  float64
}

func (c *monCounter) add(d float64) { c.mu.Lock(); c.v += d; c.mu.Unlock() }
func (c *monCounter) get() float64  { c.mu.Lock(); defer c.mu.Unlock(); return c.v }

type monGauge struct {
	mu sync.Mutex
	v  float64
}

func (c *monGauge) set(d float64) { c.mu.Lock(); c.v = d; c.mu.Unlock() }
func (c *monGauge) get() float64  { c.mu.Lock(); defer c.mu.Unlock(); return c.v }

// mon — глобальный реестр процесса (один app = один процесс).
var mon struct {
	inflight  monGauge
	reqs      monSet[monCounter] // method|route|status
	reqDur    monSet[monHist]    // method|route
	bytesOut  monSet[monCounter] // route
	bytesIn   monSet[monCounter]
	panics    monCounter
	slowReqs  monSet[monCounter] // route
	dbDur     monSet[monHist]    // pool
	dbErrs    monSet[monCounter] // pool
	dbSlow    monSet[monCounter]
	redisDur  monSet[monHist] // команда
	redisErrs monSet[monCounter]
	jobDur    monSet[monHist]    // job
	jobRuns   monSet[monCounter] // job
	jobLast   monSet[monGauge]   // job -> unix time окончания
}

func monLabel(s string) string {
	if !strings.ContainsAny(s, "\\\"\n") {
		return s
	}
	return strings.NewReplacer(`\`, `\\`, `"`, `\"`, "\n", `\n`).Replace(s)
}

func monCnt(set *monSet[monCounter], key string, d float64) {
	set.get(key, func() *monCounter { return &monCounter{} }).add(d)
}

func monObs(set *monSet[monHist], key string, d time.Duration) {
	set.get(key, newHist).observe(d.Seconds())
}

// routeLabel — шаблон маршрута без метода: низкая кардинальность вместо сырого пути.
func routeLabel(pattern string) string {
	if pattern == "" {
		return "unmatched"
	}
	if i := strings.IndexByte(pattern, ' '); i >= 0 {
		return pattern[i+1:]
	}
	return pattern
}

func monRecordRequest(method, route string, status int, dur time.Duration, in, out int64, slow bool) {
	monCnt(&mon.reqs, method+"|"+route+"|"+strconv.Itoa(status), 1)
	if route != "/api/ws" { // долгоживущие соединения испортили бы гистограмму
		monObs(&mon.reqDur, method+"|"+route, dur)
	}
	if out > 0 {
		monCnt(&mon.bytesOut, route, float64(out))
	}
	if in > 0 {
		monCnt(&mon.bytesIn, route, float64(in))
	}
	if slow {
		monCnt(&mon.slowReqs, route, 1)
	}
}

// monitorAllowed: /metrics отдаём только из внутренней сети (без X-Forwarded-For, т.е. не через публичный
// фронт) либо по токену INTERNAL_TOKEN (Authorization: Bearer … или X-Internal-Token).
func (s *Server) monitorAllowed(r *http.Request) bool {
	if t := s.cfg.InternalToken; t != "" {
		got := r.Header.Get("X-Internal-Token")
		if got == "" {
			got = strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
		}
		if got != "" && subtle.ConstantTimeCompare([]byte(got), []byte(t)) == 1 {
			return true
		}
	}
	if r.Header.Get("X-Forwarded-For") != "" || r.Header.Get("Forwarded") != "" || r.Header.Get("X-Real-IP") != "" {
		return false
	}
	h, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return false
	}
	ip := net.ParseIP(h)
	return ip != nil && (ip.IsLoopback() || ip.IsPrivate() || ip.IsLinkLocalUnicast())
}

func (s *Server) metrics(w http.ResponseWriter, r *http.Request) {
	if !s.monitorAllowed(r) {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
	bw := bufio.NewWriterSize(w, 32<<10)
	defer bw.Flush()
	typ := func(name, kind, help string) { fmt.Fprintf(bw, "# HELP %s %s\n# TYPE %s %s\n", name, help, name, kind) }

	typ("corpnet_build_info", "gauge", "Версия приложения; значение всегда 1")
	fmt.Fprintf(bw, "corpnet_build_info{version=\"%s\",go_version=\"%s\",instance_id=\"%s\",datacenter=\"%s\"} 1\n",
		monLabel(appVersion), runtime.Version(), monLabel(s.cfg.InstanceID), monLabel(s.cfg.DCID))
	typ("corpnet_start_time_seconds", "gauge", "Время старта процесса (unix)")
	fmt.Fprintf(bw, "corpnet_start_time_seconds %d\n", s.up.Unix())

	typ("http_requests_in_flight", "gauge", "Запросов в обработке прямо сейчас")
	fmt.Fprintf(bw, "http_requests_in_flight %g\n", mon.inflight.get())

	typ("http_requests_total", "counter", "HTTP-запросы по методу, шаблону маршрута и статусу")
	for _, k := range mon.reqs.keys() {
		p := strings.SplitN(k, "|", 3)
		fmt.Fprintf(bw, "http_requests_total{method=\"%s\",route=\"%s\",status=\"%s\"} %g\n", p[0], monLabel(p[1]), p[2], mon.reqs.get(k, nil).get())
	}
	typ("http_request_duration_seconds", "histogram", "Время обработки HTTP-запроса (без WebSocket)")
	for _, k := range mon.reqDur.keys() {
		p := strings.SplitN(k, "|", 2)
		mon.reqDur.get(k, nil).write(bw, "http_request_duration_seconds", fmt.Sprintf("method=\"%s\",route=\"%s\"", p[0], monLabel(p[1])))
	}
	for _, c := range []struct {
		name, help string
		set        *monSet[monCounter]
	}{
		{"http_response_bytes_total", "Отправлено байт ответа по маршрутам", &mon.bytesOut},
		{"http_request_bytes_total", "Получено байт тела запроса по маршрутам", &mon.bytesIn},
		{"http_slow_requests_total", "Запросы медленнее SLOW_REQUEST_MS", &mon.slowReqs},
	} {
		typ(c.name, "counter", c.help)
		for _, k := range c.set.keys() {
			fmt.Fprintf(bw, "%s{route=\"%s\"} %g\n", c.name, monLabel(k), c.set.get(k, nil).get())
		}
	}
	typ("http_panics_total", "counter", "Паники в обработчиках")
	fmt.Fprintf(bw, "http_panics_total %g\n", mon.panics.get())

	typ("corpnet_ws_connections", "gauge", "Открытых WebSocket-соединений на этом экземпляре")
	fmt.Fprintf(bw, "corpnet_ws_connections %d\n", s.hub.conns.Load())

	// --- БД
	pools := map[string]*pgxpool.Pool{"primary": s.db}
	if s.ro != s.db {
		pools["replica"] = s.ro
	}
	names := make([]string, 0, 2)
	for n := range pools {
		names = append(names, n)
	}
	sort.Strings(names)
	type pg struct {
		name, kind, help string
		f                func(st *pgxpool.Stat) float64
	}
	for _, g := range []pg{
		{"corpnet_db_pool_acquired_conns", "gauge", "Занятых соединений пула", func(st *pgxpool.Stat) float64 { return float64(st.AcquiredConns()) }},
		{"corpnet_db_pool_idle_conns", "gauge", "Свободных соединений пула", func(st *pgxpool.Stat) float64 { return float64(st.IdleConns()) }},
		{"corpnet_db_pool_total_conns", "gauge", "Всего соединений пула", func(st *pgxpool.Stat) float64 { return float64(st.TotalConns()) }},
		{"corpnet_db_pool_max_conns", "gauge", "Максимум соединений пула (PG_POOL_MAX)", func(st *pgxpool.Stat) float64 { return float64(st.MaxConns()) }},
		{"corpnet_db_pool_acquire_total", "counter", "Выдач соединения", func(st *pgxpool.Stat) float64 { return float64(st.AcquireCount()) }},
		{"corpnet_db_pool_acquire_wait_seconds_total", "counter", "Суммарное ожидание соединения", func(st *pgxpool.Stat) float64 { return st.AcquireDuration().Seconds() }},
		{"corpnet_db_pool_empty_acquire_total", "counter", "Выдач, когда свободных соединений не было (ждали)", func(st *pgxpool.Stat) float64 { return float64(st.EmptyAcquireCount()) }},
		{"corpnet_db_pool_canceled_acquire_total", "counter", "Отменённых ожиданий соединения", func(st *pgxpool.Stat) float64 { return float64(st.CanceledAcquireCount()) }},
		{"corpnet_db_pool_new_conns_total", "counter", "Открытых новых соединений", func(st *pgxpool.Stat) float64 { return float64(st.NewConnsCount()) }},
	} {
		typ(g.name, g.kind, g.help)
		for _, n := range names {
			fmt.Fprintf(bw, "%s{pool=\"%s\"} %g\n", g.name, n, g.f(pools[n].Stat()))
		}
	}
	typ("corpnet_db_query_duration_seconds", "histogram", "Время SQL-запроса (до получения ответа, pgx tracer)")
	for _, k := range mon.dbDur.keys() {
		mon.dbDur.get(k, nil).write(bw, "corpnet_db_query_duration_seconds", fmt.Sprintf("pool=\"%s\"", k))
	}
	for _, c := range []struct {
		name, help string
		set        *monSet[monCounter]
	}{
		{"corpnet_db_query_errors_total", "SQL-запросы с ошибкой (кроме no rows)", &mon.dbErrs},
		{"corpnet_db_slow_queries_total", "SQL-запросы медленнее SLOW_SQL_MS", &mon.dbSlow},
		{"corpnet_redis_errors_total", "Ошибки проверки Redis", &mon.redisErrs},
	} {
		typ(c.name, "counter", c.help)
		for _, k := range c.set.keys() {
			lbl := "pool"
			if strings.HasPrefix(c.name, "corpnet_redis") {
				lbl = "command"
			}
			fmt.Fprintf(bw, "%s{%s=\"%s\"} %g\n", c.name, lbl, monLabel(k), c.set.get(k, nil).get())
		}
	}
	typ("corpnet_redis_ping_seconds", "histogram", "Задержка Redis (PING раз в 5 с)")
	for _, k := range mon.redisDur.keys() {
		mon.redisDur.get(k, nil).write(bw, "corpnet_redis_ping_seconds", fmt.Sprintf("command=\"%s\"", monLabel(k)))
	}
	// --- фоновые задачи
	typ("corpnet_job_runs_total", "counter", "Запусков фоновых задач")
	for _, k := range mon.jobRuns.keys() {
		fmt.Fprintf(bw, "corpnet_job_runs_total{job=\"%s\"} %g\n", k, mon.jobRuns.get(k, nil).get())
	}
	typ("corpnet_job_last_run_timestamp_seconds", "gauge", "Когда задача завершилась в последний раз (unix)")
	for _, k := range mon.jobLast.keys() {
		fmt.Fprintf(bw, "corpnet_job_last_run_timestamp_seconds{job=\"%s\"} %g\n", k, mon.jobLast.get(k, nil).get())
	}
	typ("corpnet_job_duration_seconds", "histogram", "Длительность фоновых задач")
	for _, k := range mon.jobDur.keys() {
		mon.jobDur.get(k, nil).write(bw, "corpnet_job_duration_seconds", fmt.Sprintf("job=\"%s\"", k))
	}

	// --- рантайм
	var ms runtime.MemStats
	runtime.ReadMemStats(&ms)
	typ("go_goroutines", "gauge", "Горутин")
	fmt.Fprintf(bw, "go_goroutines %d\n", runtime.NumGoroutine())
	typ("go_memstats_heap_alloc_bytes", "gauge", "Занято кучей")
	fmt.Fprintf(bw, "go_memstats_heap_alloc_bytes %d\n", ms.HeapAlloc)
	typ("go_memstats_sys_bytes", "gauge", "Память, полученная от ОС")
	fmt.Fprintf(bw, "go_memstats_sys_bytes %d\n", ms.Sys)
	typ("go_gc_pause_seconds_total", "counter", "Суммарная пауза GC")
	fmt.Fprintf(bw, "go_gc_pause_seconds_total %g\n", float64(ms.PauseTotalNs)/1e9)
	typ("go_gc_cycles_total", "counter", "Циклов GC")
	fmt.Fprintf(bw, "go_gc_cycles_total %d\n", ms.NumGC)
}

// monJob оборачивает фоновую задачу замером времени.
func monJob(name string, fn func(context.Context)) func(context.Context) {
	return func(ctx context.Context) {
		t := time.Now()
		defer func() {
			monCnt(&mon.jobRuns, name, 1)
			monObs(&mon.jobDur, name, time.Since(t))
			mon.jobLast.get(name, func() *monGauge { return &monGauge{} }).set(float64(time.Now().Unix()))
		}()
		fn(ctx)
	}
}
