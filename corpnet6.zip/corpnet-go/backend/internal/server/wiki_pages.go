package server

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

const (
	wikiMaxBody   = 200000
	wikiMaxDepth  = 30
	wikiKeepVers  = 200
	wikiMaxBranch = 3000
)

// ---------------------------------------------------------------- обход дерева с правами (в Go)
//
// Те же правила, что у SQL-функции wiki_level (migrate/sql/014_wiki.sql): состояние (vis, mng) спускается от корня базы
// вниз, «ограниченная» страница обнуляет vis и права редактирования, пришедшие сверху. Здесь это нужно, чтобы одним проходом
// отфильтровать дерево на 20 000 страниц, не вызывая SQL-функцию для каждой.

type wst struct{ vis, mng int }

func wikiFold(st wst, restricted bool, acl int, mine bool) (wst, int) {
	own := acl
	if mine && own < 3 {
		own = 3
	}
	if restricted {
		st.vis = own
		st.mng = 0
		if own >= 3 {
			st.mng = own
		}
	} else if own >= 3 && own > st.mng {
		st.mng = own
	}
	return st, max(st.vis, st.mng)
}

func wikiSpaceState(sl int) wst {
	st := wst{vis: sl}
	if sl >= 3 {
		st.mng = sl
	}
	return st
}

type wrow struct {
	ID, PID int64
	Owner   int64
	Restr   bool
	ACL     int
	Overdue bool
	Title   string
}

type wvis struct {
	row *wrow
	Lvl int
}

// wikiWalk обходит поддеревья начиная с start (индексы в rows) с начальным состоянием st0 и возвращает видимые узлы в
// порядке «родитель → дети по sort». Невидимая страница отсекает всю свою ветку (страница доступна, только если доступны предки).
func wikiWalk(rows []wrow, kids map[int64][]int, start []int, st0 wst, uid int64, sup bool) []wvis {
	out := make([]wvis, 0, len(rows))
	var rec func(idx int, st wst, depth int)
	rec = func(idx int, st wst, depth int) {
		r := &rows[idx]
		ns, lvl := wikiFold(st, r.Restr, r.ACL, r.Owner == uid)
		if sup {
			lvl = 4
		}
		if lvl == 0 || depth > 64 {
			return
		}
		out = append(out, wvis{r, lvl})
		for _, k := range kids[r.ID] {
			rec(k, ns, depth+1)
		}
	}
	for _, i := range start {
		rec(i, st0, 0)
	}
	return out
}

func wikiKidsIndex(rows []wrow) map[int64][]int {
	kids := make(map[int64][]int, len(rows)/2+1)
	for i := range rows {
		kids[rows[i].PID] = append(kids[rows[i].PID], i)
	}
	return kids
}

// wikiACLJoin — подзапрос «максимальный уровень, выданный текущему пользователю на страницу» по всем страницам базы ($7 — id базы).
const wikiACLJoin = `LEFT JOIN (SELECT a.page_id, max(a.level) AS lvl FROM wiki_acl a WHERE a.space_id = $7::bigint AND a.page_id IS NOT NULL
		AND wiki_acl_match(a.subject_type, a.subject_id, a.subject_key, $1::bigint, $3::bigint[], $4::bigint[], $5::text[]) GROUP BY a.page_id) ga ON ga.page_id = p.id`

func (s *Server) wikiRows(ctx context.Context, sj *wsubj, space int64, where string, extra ...any) ([]wrow, error) {
	args := append(sj.args(), space)
	args = append(args, extra...)
	rs, err := s.db.Query(ctx, `SELECT p.id, coalesce(p.parent_id, 0), coalesce(p.owner_id, 0), p.visibility = 'restricted', coalesce(ga.lvl, 0)::int,
		p.review_until IS NOT NULL AND p.review_until < current_date, p.title
		FROM wiki_pages p `+wikiACLJoin+` WHERE p.space_id = $7::bigint AND $2::bigint IS NOT NULL AND $6::boolean IS NOT NULL `+where+` ORDER BY p.sort, p.id`, args...)
	if err != nil {
		return nil, err
	}
	defer rs.Close()
	var rows []wrow
	for rs.Next() {
		var r wrow
		if err := rs.Scan(&r.ID, &r.PID, &r.Owner, &r.Restr, &r.ACL, &r.Overdue, &r.Title); err != nil {
			return nil, err
		}
		rows = append(rows, r)
	}
	return rows, rs.Err()
}

// ---------------------------------------------------------------- дерево базы

// wikiTree — плоский список видимых страниц одним запросом: [[id, parent_id|0, title, flags], ...] в порядке обхода
// (родитель → дети). flags: младшие 3 бита — уровень (1/3/4), 8 — ограниченная, 16 — просрочена проверка.
func (s *Server) wikiTree(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	sp, sj, err := s.wikiSpace(c, id, wvView)
	if err != nil {
		return err
	}
	rows, err := s.wikiRows(c.Context(), sj, id, "")
	if err != nil {
		return err
	}
	kids := wikiKidsIndex(rows)
	vis := wikiWalk(rows, kids, kids[0], wikiSpaceState(sp.Level), c.U.ID, sp.Level >= 4)
	var b strings.Builder
	b.Grow(len(vis)*48 + 256)
	b.WriteString(`{"space":`)
	sb, _ := json.Marshal(s.wikiSpaceJSON(c, sp))
	b.Write(sb)
	b.WriteString(`,"pages":[`)
	for i, v := range vis {
		if i > 0 {
			b.WriteByte(',')
		}
		fl := v.Lvl
		if v.row.Restr {
			fl |= 8
		}
		if v.row.Overdue {
			fl |= 16
		}
		t, _ := json.Marshal(v.row.Title)
		b.WriteByte('[')
		b.WriteString(strconv.FormatInt(v.row.ID, 10))
		b.WriteByte(',')
		b.WriteString(strconv.FormatInt(v.row.PID, 10))
		b.WriteByte(',')
		b.Write(t)
		b.WriteByte(',')
		b.WriteString(strconv.Itoa(fl))
		b.WriteByte(']')
	}
	b.WriteString(`]}`)
	return c.Raw(200, []byte(b.String()))
}

// ---------------------------------------------------------------- цепочка предков

type wcrumb struct {
	ID    int64  `json:"id"`
	Title string `json:"title"`
	Slug  string `json:"slug"`
}

// wikiChain возвращает уровень пользователя на странице, состояние прав перед ней (для детей) и хлебные крошки.
// Крошки строятся только из доступных страниц (доступность предков — условие доступа к странице).
func (s *Server) wikiChain(ctx context.Context, sj *wsubj, sl int, pid int64) (lvl int, before, after wst, crumbs []wcrumb, err error) {
	rs, err := s.db.Query(ctx, `WITH RECURSIVE up AS (
			SELECT id, parent_id, 0 AS d FROM wiki_pages WHERE id = $7::bigint AND $2::bigint IS NOT NULL AND $6::boolean IS NOT NULL
			UNION ALL SELECT p.id, p.parent_id, up.d + 1 FROM wiki_pages p JOIN up ON p.id = up.parent_id WHERE up.d < 64)
		SELECT p.id, p.title, p.slug, p.visibility = 'restricted', coalesce(p.owner_id, 0),
			coalesce((SELECT max(a.level) FROM wiki_acl a WHERE a.page_id = p.id
				AND wiki_acl_match(a.subject_type, a.subject_id, a.subject_key, $1::bigint, $3::bigint[], $4::bigint[], $5::text[])), 0)::int
		FROM up JOIN wiki_pages p ON p.id = up.id ORDER BY up.d DESC`, append(sj.args(), pid)...)
	if err != nil {
		return 0, wst{}, wst{}, nil, err
	}
	defer rs.Close()
	st := wikiSpaceState(sl)
	crumbs = []wcrumb{}
	for rs.Next() {
		var cr wcrumb
		var restr bool
		var owner int64
		var acl int
		if err := rs.Scan(&cr.ID, &cr.Title, &cr.Slug, &restr, &owner, &acl); err != nil {
			return 0, wst{}, wst{}, nil, err
		}
		before = st
		st, lvl = wikiFold(st, restr, acl, owner == sj.UID)
		if sl >= 4 {
			lvl = 4
		}
		if lvl == 0 {
			return 0, wst{}, wst{}, nil, rs.Err()
		}
		crumbs = append(crumbs, cr)
	}
	return lvl, before, st, crumbs, rs.Err()
}

type wkid struct {
	ID    int64  `json:"id"`
	Title string `json:"title"`
	Slug  string `json:"slug"`
	Icon  string `json:"icon"`
	Restr bool   `json:"restricted"`
	Lvl   int    `json:"-"`
}

// wikiKids — видимые дети страницы (или корневые страницы, если parent == 0) в порядке sort.
func (s *Server) wikiKids(ctx context.Context, sj *wsubj, space, parent int64, st wst, sup bool, limit int) ([]wkid, error) {
	rs, err := s.db.Query(ctx, `SELECT p.id, p.title, p.slug, p.icon, p.visibility = 'restricted', coalesce(p.owner_id, 0), coalesce(ga.lvl, 0)::int
		FROM wiki_pages p `+wikiACLJoin+` WHERE p.space_id = $7::bigint AND $2::bigint IS NOT NULL AND $6::boolean IS NOT NULL AND p.parent_id IS NOT DISTINCT FROM NULLIF($8::bigint, 0) ORDER BY p.sort, p.id`, append(sj.args(), space, parent)...)
	if err != nil {
		return nil, err
	}
	defer rs.Close()
	out := []wkid{}
	for rs.Next() {
		var k wkid
		var owner int64
		var acl int
		if err := rs.Scan(&k.ID, &k.Title, &k.Slug, &k.Icon, &k.Restr, &owner, &acl); err != nil {
			return nil, err
		}
		_, lvl := wikiFold(st, k.Restr, acl, owner == sj.UID)
		if sup {
			lvl = 4
		}
		if lvl == 0 {
			continue
		}
		k.Lvl = lvl
		if len(out) < limit {
			out = append(out, k)
		}
	}
	return out, rs.Err()
}

// ---------------------------------------------------------------- страница

func (s *Server) wikiPageGet(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	var space int64
	if err := s.db.QueryRow(ctx, `SELECT space_id FROM wiki_pages WHERE id = $1`, id).Scan(&space); err != nil {
		return err
	}
	sp, sj, err := s.wikiSpace(c, space, wvView)
	if err != nil {
		return err
	}
	sup := sp.Level >= 4
	lvl, pst, after, crumbs, err := s.wikiChain(ctx, sj, sp.Level, id)
	if err != nil {
		return err
	}
	if lvl == 0 {
		return errNotFound
	}
	// соседние страницы (prev/next) — среди видимых детей того же родителя; дети — видимые дети этой страницы
	var parent int64
	if len(crumbs) > 1 {
		parent = crumbs[len(crumbs)-2].ID
	}
	sibs, err := s.wikiKids(ctx, sj, space, parent, pst, sup, 100000)
	if err != nil {
		return err
	}
	var prev, next *wkid
	for i := range sibs {
		if sibs[i].ID == id {
			if i > 0 {
				prev = &sibs[i-1]
			}
			if i+1 < len(sibs) {
				next = &sibs[i+1]
			}
			break
		}
	}
	children, err := s.wikiKids(ctx, sj, space, id, after, sup, 500)
	if err != nil {
		return err
	}
	pj, err := s.one(ctx, `SELECT p.id, p.space_id, p.parent_id, p.title, p.slug, p.icon, p.body, p.tags, p.version, p.views_count,
		p.visibility = 'restricted' AS restricted, p.owner_id, (SELECT full_name FROM users WHERE id = p.owner_id) AS owner,
		p.responsible_id, (SELECT full_name FROM users WHERE id = p.responsible_id) AS responsible,
		to_char(p.review_until, 'YYYY-MM-DD') AS review_until, p.review_until IS NOT NULL AND p.review_until < current_date AS overdue,
		p.created_at, p.updated_at, p.updated_by, (SELECT full_name FROM users WHERE id = p.updated_by) AS updated_by_name,
		(SELECT count(*) FROM wiki_comments WHERE page_id = p.id) AS comments_count, $2::int AS level
		FROM wiki_pages p WHERE p.id = $1`, id, lvl)
	if err != nil {
		return err
	}
	files, err := s.arr(ctx, `SELECT x.id, x.name, x.mime, x.size, x.width, x.height, x.thumb <> '' AS has_thumb FROM wiki_page_files wf JOIN files x ON x.id = wf.file_id
		WHERE wf.page_id = $1 ORDER BY wf.sort, x.id`, id)
	if err != nil {
		return err
	}
	// просмотры: не чаще раза в 30 минут от одного пользователя
	if s.rdb.SetNX(ctx, fmt.Sprintf("wk:v:%d:%d", id, c.U.ID), 1, 30*time.Minute).Val() {
		s.db.Exec(ctx, `UPDATE wiki_pages SET views_count = views_count + 1 WHERE id = $1`, id)
	}
	out := map[string]any{
		"page": json.RawMessage(pj), "files": json.RawMessage(files), "crumbs": crumbs, "prev": prev, "next": next, "children": children,
		"space": s.wikiSpaceJSON(c, sp),
	}
	return c.JSON(200, out)
}

func cleanBody(b string) (string, error) {
	b = strings.ReplaceAll(b, "\r\n", "\n")
	b = strings.ReplaceAll(b, "\x00", "")
	if len(b) > wikiMaxBody {
		return "", badReq("Страница слишком большая (не более 200 000 символов)")
	}
	return b, nil
}

func (s *Server) wikiDepth(ctx context.Context, id int64) (int, error) {
	var d int
	err := s.db.QueryRow(ctx, `WITH RECURSIVE up AS (SELECT id, parent_id, 1 AS d FROM wiki_pages WHERE id = $1
		UNION ALL SELECT p.id, p.parent_id, up.d + 1 FROM wiki_pages p JOIN up ON p.id = up.parent_id WHERE up.d < 100) SELECT coalesce(max(d), 0) FROM up`, id).Scan(&d)
	return d, err
}

func (s *Server) wikiPageCreate(c *Ctx) error {
	var in struct {
		SpaceID  int64    `json:"space_id"`
		ParentID *int64   `json:"parent_id"`
		Title    string   `json:"title"`
		Body     string   `json:"body"`
		Icon     string   `json:"icon"`
		Tags     []string `json:"tags"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Title = cleanTitle(in.Title)
	if in.Title == "" {
		return badReq("Укажите название страницы")
	}
	body, err := cleanBody(in.Body)
	if err != nil {
		return err
	}
	ctx := c.Context()
	space := in.SpaceID
	if in.ParentID != nil {
		p, _, err := s.wikiPageAt(c, *in.ParentID, wvEdit)
		if err != nil {
			return err
		}
		space = p.SpaceID
		if d, err := s.wikiDepth(ctx, p.ID); err != nil {
			return err
		} else if d >= wikiMaxDepth {
			return badReq("Слишком глубокая вложенность страниц")
		}
	} else if _, _, err := s.wikiSpace(c, space, wvEdit); err != nil {
		return err
	}
	var id int64
	err = s.tx(ctx, func(tx pgx.Tx) error {
		var sortv int
		if err := tx.QueryRow(ctx, `SELECT coalesce(max(sort), 0) + 1000 FROM wiki_pages WHERE space_id = $1 AND parent_id IS NOT DISTINCT FROM $2::bigint`, space, in.ParentID).Scan(&sortv); err != nil {
			return err
		}
		if err := tx.QueryRow(ctx, `INSERT INTO wiki_pages (space_id, parent_id, title, slug, body, sort, owner_id, responsible_id, icon, tags, created_by, updated_by)
			VALUES ($1, $2, $3, $4, $5, $6, $7, $7, $8, $9, $7, $7) RETURNING id`,
			space, in.ParentID, in.Title, wikiSlug(in.Title), body, sortv, c.U.ID, in.Icon, cleanTags(in.Tags)).Scan(&id); err != nil {
			return err
		}
		_, err := tx.Exec(ctx, `INSERT INTO wiki_versions (page_id, version, title, body, author_id, comment) VALUES ($1, 1, $2, $3, $4, 'Создание страницы')`, id, in.Title, body, c.U.ID)
		return err
	})
	if err != nil {
		return err
	}
	s.audit(c, "wiki.page.create", "wiki_page", id, map[string]any{"title": in.Title})
	return c.JSON(201, map[string]any{"id": id, "slug": wikiSlug(in.Title), "space_id": space})
}

func (s *Server) wikiPageSave(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Title         *string   `json:"title"`
		Body          *string   `json:"body"`
		BaseVersion   int       `json:"base_version"`
		Comment       string    `json:"comment"`
		Tags          *[]string `json:"tags"`
		Icon          *string   `json:"icon"`
		ResponsibleID *int64    `json:"responsible_id"`
		ClearResp     bool      `json:"clear_responsible"`
		ReviewUntil   *string   `json:"review_until"` // YYYY-MM-DD, "" — снять
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	p, _, err := s.wikiPageAt(c, id, wvEdit)
	if err != nil {
		return err
	}
	ctx := c.Context()
	var newVer int
	var conflict map[string]any
	err = s.tx(ctx, func(tx pgx.Tx) error {
		var cur struct {
			title, body string
			version     int
			by          *string
			at          time.Time
		}
		if err := tx.QueryRow(ctx, `SELECT p.title, p.body, p.version, (SELECT full_name FROM users WHERE id = p.updated_by), p.updated_at FROM wiki_pages p WHERE p.id = $1 FOR UPDATE`, id).
			Scan(&cur.title, &cur.body, &cur.version, &cur.by, &cur.at); err != nil {
			return err
		}
		title, body := cur.title, cur.body
		if in.Title != nil {
			if title = cleanTitle(*in.Title); title == "" {
				return badReq("Укажите название страницы")
			}
		}
		if in.Body != nil {
			b, err := cleanBody(*in.Body)
			if err != nil {
				return err
			}
			body = b
		}
		changed := title != cur.title || body != cur.body
		if changed && in.BaseVersion != cur.version {
			conflict = map[string]any{"error": "Страницу уже изменили. Сравните версии и объедините правки", "conflict": true,
				"current": map[string]any{"version": cur.version, "title": cur.title, "body": cur.body, "updated_by_name": cur.by, "updated_at": cur.at}}
			return nil
		}
		set := []string{"updated_at = now()", "updated_by = $2"}
		args := []any{id, c.U.ID}
		add := func(col string, v any) { args = append(args, v); set = append(set, col+" = $"+strconv.Itoa(len(args))) }
		if changed {
			add("title", title)
			add("slug", wikiSlug(title))
			add("body", body)
			set = append(set, "version = version + 1")
		}
		if in.Tags != nil {
			add("tags", cleanTags(*in.Tags))
		}
		if in.Icon != nil {
			if len([]rune(*in.Icon)) > 8 {
				return badReq("Некорректная иконка")
			}
			add("icon", *in.Icon)
		}
		if in.ClearResp {
			set = append(set, "responsible_id = NULL")
		} else if in.ResponsibleID != nil {
			add("responsible_id", *in.ResponsibleID)
		}
		if in.ReviewUntil != nil {
			if *in.ReviewUntil == "" {
				set = append(set, "review_until = NULL")
			} else {
				d, err := time.Parse("2006-01-02", *in.ReviewUntil)
				if err != nil {
					return badReq("Некорректная дата")
				}
				add("review_until", d)
			}
		}
		if err := tx.QueryRow(ctx, `UPDATE wiki_pages SET `+strings.Join(set, ", ")+` WHERE id = $1 RETURNING version`, args...).Scan(&newVer); err != nil {
			return err
		}
		if changed {
			cm := strings.TrimSpace(in.Comment)
			if r := []rune(cm); len(r) > 300 {
				cm = string(r[:300])
			}
			if _, err := tx.Exec(ctx, `INSERT INTO wiki_versions (page_id, version, title, body, author_id, comment) VALUES ($1, $2, $3, $4, $5, $6)`, id, newVer, title, body, c.U.ID, cm); err != nil {
				return err
			}
			_, err := tx.Exec(ctx, `DELETE FROM wiki_versions WHERE page_id = $1 AND version <= $2`, id, newVer-wikiKeepVers)
			return err
		}
		return nil
	})
	if err != nil {
		return err
	}
	if conflict != nil {
		return c.JSON(409, conflict)
	}
	_ = p
	return c.JSON(200, map[string]any{"ok": true, "version": newVer})
}

func (s *Server) wikiMarkReviewed(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Days int `json:"days"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if in.Days < 1 || in.Days > 1100 {
		in.Days = 180
	}
	if _, _, err = s.wikiPageAt(c, id, wvEdit); err != nil {
		return err
	}
	var d string
	if err := s.db.QueryRow(c.Context(), `UPDATE wiki_pages SET review_until = current_date + $2::int, updated_at = now() WHERE id = $1 RETURNING to_char(review_until, 'YYYY-MM-DD')`, id, in.Days).Scan(&d); err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"ok": true, "review_until": d})
}

func (s *Server) wikiPageDelete(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	p, sj, err := s.wikiPageAt(c, id, wvEdit)
	if err != nil {
		return err
	}
	if !canManagePage(p, c.U.ID) {
		return errForbidden
	}
	ctx := c.Context()
	// ветку нельзя удалить, если в ней есть ограниченные страницы, которые пользователь не вправе править
	if p.Level < 4 {
		rs, err := s.db.Query(ctx, `WITH RECURSIVE t AS (SELECT id, visibility FROM wiki_pages WHERE id = $7::bigint
			UNION ALL SELECT c.id, c.visibility FROM wiki_pages c JOIN t ON c.parent_id = t.id)
			SELECT id FROM t WHERE visibility = 'restricted' AND id <> $7::bigint AND wiki_level(id, `+wA+`) < 3`, append(sj.args(), id)...)
		if err != nil {
			return err
		}
		blocked := rs.Next()
		rs.Close()
		if blocked {
			return &apiError{403, "В ветке есть страницы с ограниченным доступом, которые вы не можете удалять"}
		}
	}
	fids, err := s.wikiFileIDs(ctx, `WITH RECURSIVE t AS (SELECT id FROM wiki_pages WHERE id = $1 UNION ALL SELECT c.id FROM wiki_pages c JOIN t ON c.parent_id = t.id)
		SELECT wf.file_id FROM wiki_page_files wf WHERE wf.page_id IN (SELECT id FROM t)`, id)
	if err != nil {
		return err
	}
	if _, err := s.db.Exec(ctx, `DELETE FROM wiki_pages WHERE id = $1`, id); err != nil {
		return err
	}
	s.wikiPurgeFiles(ctx, fids)
	s.audit(c, "wiki.page.delete", "wiki_page", id, map[string]any{"title": p.Title})
	return c.OK()
}

// ---------------------------------------------------------------- перемещение и копирование

func (s *Server) wikiPageMove(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		ParentID *int64 `json:"parent_id"`
		BeforeID int64  `json:"before_id"` // 0 — в конец
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	p, _, err := s.wikiPageAt(c, id, wvEdit)
	if err != nil {
		return err
	}
	ctx := c.Context()
	if in.ParentID != nil {
		tp, _, err := s.wikiPageAt(c, *in.ParentID, wvEdit)
		if err != nil {
			return err
		}
		if tp.SpaceID != p.SpaceID {
			return badReq("Перемещение возможно только внутри базы знаний. Для другой базы используйте «Копировать»")
		}
		var cyc bool
		if err := s.db.QueryRow(ctx, `WITH RECURSIVE t AS (SELECT id FROM wiki_pages WHERE id = $1 UNION ALL SELECT x.id FROM wiki_pages x JOIN t ON x.parent_id = t.id)
			SELECT EXISTS (SELECT 1 FROM t WHERE id = $2)`, id, *in.ParentID).Scan(&cyc); err != nil {
			return err
		}
		if cyc {
			return badReq("Нельзя переместить страницу внутрь самой себя")
		}
		pd, err := s.wikiDepth(ctx, *in.ParentID)
		if err != nil {
			return err
		}
		var h int
		if err := s.db.QueryRow(ctx, `WITH RECURSIVE t AS (SELECT id, 1 AS d FROM wiki_pages WHERE id = $1 UNION ALL SELECT x.id, t.d + 1 FROM wiki_pages x JOIN t ON x.parent_id = t.id WHERE t.d < 64) SELECT max(d) FROM t`, id).Scan(&h); err != nil {
			return err
		}
		if pd+h > wikiMaxDepth {
			return badReq("Слишком глубокая вложенность страниц")
		}
	} else if _, _, err := s.wikiSpace(c, p.SpaceID, wvEdit); err != nil {
		return err
	}
	err = s.tx(ctx, func(tx pgx.Tx) error {
		rs, err := tx.Query(ctx, `SELECT id FROM wiki_pages WHERE space_id = $1 AND parent_id IS NOT DISTINCT FROM $2::bigint AND id <> $3 ORDER BY sort, id FOR UPDATE`, p.SpaceID, in.ParentID, id)
		if err != nil {
			return err
		}
		var ids []int64
		for rs.Next() {
			var x int64
			rs.Scan(&x)
			ids = append(ids, x)
		}
		rs.Close()
		pos := len(ids)
		if in.BeforeID > 0 {
			found := false
			for i, x := range ids {
				if x == in.BeforeID {
					pos, found = i, true
					break
				}
			}
			if !found {
				return badReq("Страница-ориентир не найдена среди соседних")
			}
		}
		ids = append(ids[:pos], append([]int64{id}, ids[pos:]...)...)
		sorts := make([]int32, len(ids))
		for i := range ids {
			sorts[i] = int32((i + 1) * 1000)
		}
		if _, err := tx.Exec(ctx, `UPDATE wiki_pages SET parent_id = $2 WHERE id = $1`, id, in.ParentID); err != nil {
			return err
		}
		_, err = tx.Exec(ctx, `UPDATE wiki_pages p SET sort = x.s FROM unnest($1::bigint[], $2::int[]) AS x(i, s) WHERE p.id = x.i AND p.sort <> x.s`, ids, sorts)
		return err
	})
	if err != nil {
		return err
	}
	return c.OK()
}

var filesRefRe = regexp.MustCompile(`/files/(\d+)`)

func (s *Server) wikiPageCopy(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		SpaceID      int64  `json:"space_id"`
		ParentID     *int64 `json:"parent_id"`
		WithChildren bool   `json:"with_children"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	src, sj, err := s.wikiPageAt(c, id, wvView)
	if err != nil {
		return err
	}
	ctx := c.Context()
	target := in.SpaceID
	if in.ParentID != nil {
		tp, _, err := s.wikiPageAt(c, *in.ParentID, wvEdit)
		if err != nil {
			return err
		}
		target = tp.SpaceID
		if d, err := s.wikiDepth(ctx, tp.ID); err != nil || d >= wikiMaxDepth-1 {
			if err != nil {
				return err
			}
			return badReq("Слишком глубокая вложенность страниц")
		}
	} else if _, _, err := s.wikiSpace(c, target, wvEdit); err != nil {
		return err
	}
	sp, _, err := s.wikiSpace(c, src.SpaceID, wvView)
	if err != nil {
		return err
	}
	nodes, err := s.wikiBranch(ctx, sj, sp.Level, src.SpaceID, src, in.WithChildren)
	if err != nil {
		return err
	}
	if len(nodes) > wikiMaxBranch {
		return badReq("Слишком большая ветка для копирования")
	}
	ids := make([]int64, len(nodes))
	for i, n := range nodes {
		ids[i] = n.ID
	}
	idMap := map[int64]int64{}
	err = s.tx(ctx, func(tx pgx.Tx) error {
		// вложения: дубликаты записей files с теми же байтами; id в тексте переписываются
		fileMap := map[int64]int64{}
		type pf struct{ page, file int64 }
		var links []pf
		rs, err := tx.Query(ctx, `SELECT page_id, file_id FROM wiki_page_files WHERE page_id = ANY($1::bigint[]) ORDER BY page_id, sort, file_id`, ids)
		if err != nil {
			return err
		}
		for rs.Next() {
			var l pf
			rs.Scan(&l.page, &l.file)
			links = append(links, l)
		}
		rs.Close()
		newFile := map[[2]int64]int64{}
		for _, l := range links {
			var nid int64
			if err := tx.QueryRow(ctx, `INSERT INTO files (owner_id, name, mime, size, storage, thumb, view, width, height, context)
				SELECT $2, name, mime, size, storage, thumb, view, width, height, 'wiki' FROM files WHERE id = $1 RETURNING id`, l.file, c.U.ID).Scan(&nid); err != nil {
				return err
			}
			newFile[[2]int64{l.page, l.file}] = nid
			fileMap[l.file] = nid
		}
		for _, n := range nodes {
			var parent any
			if n.ID == src.ID {
				if in.ParentID != nil {
					parent = *in.ParentID
				}
			} else {
				parent = idMap[n.PID]
			}
			title := n.Title
			if n.ID == src.ID && target == src.SpaceID && (in.ParentID == nil && src.ParentID == nil || in.ParentID != nil && src.ParentID != nil && *in.ParentID == *src.ParentID) {
				title = cleanTitle("Копия — " + title)
			}
			body := filesRefRe.ReplaceAllStringFunc(n.Body, func(m string) string {
				old, _ := strconv.ParseInt(m[len("/files/"):], 10, 64)
				if nf, ok := newFile[[2]int64{n.ID, old}]; ok {
					return "/files/" + strconv.FormatInt(nf, 10)
				}
				return m
			})
			var sortv int
			if err := tx.QueryRow(ctx, `SELECT coalesce(max(sort), 0) + 1000 FROM wiki_pages WHERE space_id = $1 AND parent_id IS NOT DISTINCT FROM $2::bigint`, target, parent).Scan(&sortv); err != nil {
				return err
			}
			if n.ID != src.ID {
				sortv = n.Sort
			}
			var nid int64
			if err := tx.QueryRow(ctx, `INSERT INTO wiki_pages (space_id, parent_id, title, slug, body, sort, visibility, owner_id, responsible_id, review_until, tags, icon, created_by, updated_by)
				VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $8, $9, $10, $11, $8, $8) RETURNING id`,
				target, parent, title, wikiSlug(title), body, sortv, n.Vis, c.U.ID, n.Review, n.Tags, n.Icon).Scan(&nid); err != nil {
				return err
			}
			idMap[n.ID] = nid
			if _, err := tx.Exec(ctx, `INSERT INTO wiki_versions (page_id, version, title, body, author_id, comment) VALUES ($1, 1, $2, $3, $4, $5)`,
				nid, title, body, c.U.ID, "Копия страницы #"+strconv.FormatInt(n.ID, 10)); err != nil {
				return err
			}
			if n.Vis == "restricted" {
				if _, err := tx.Exec(ctx, `INSERT INTO wiki_acl (space_id, page_id, subject_type, subject_id, subject_key, level)
					SELECT $1, $2, subject_type, subject_id, subject_key, level FROM wiki_acl WHERE page_id = $3`, target, nid, n.ID); err != nil {
					return err
				}
			}
		}
		for _, l := range links {
			if _, err := tx.Exec(ctx, `INSERT INTO wiki_page_files (page_id, file_id) VALUES ($1, $2)`, idMap[l.page], newFile[[2]int64{l.page, l.file}]); err != nil {
				return err
			}
		}
		return nil
	})
	if err != nil {
		return err
	}
	s.audit(c, "wiki.page.copy", "wiki_page", id, map[string]any{"copied": len(nodes), "space": target})
	return c.JSON(201, map[string]any{"id": idMap[src.ID], "space_id": target, "count": len(nodes)})
}

type wbranchNode struct {
	ID, PID int64
	Title   string
	Body    string
	Sort    int
	Vis     string
	Review  *time.Time
	Tags    []string
	Icon    string
	Lvl     int
}

// wikiBranch возвращает видимые пользователю страницы ветки (корень + потомки, если withKids) с текстом.
// root == nil — вся база. Невидимые ветки пропускаются целиком.
func (s *Server) wikiBranch(ctx context.Context, sj *wsubj, sl int, space int64, root *wpage, withKids bool) ([]wbranchNode, error) {
	st := wikiSpaceState(sl)
	var rows []wrow
	var err error
	var start []int
	var kids map[int64][]int
	if root == nil {
		if rows, err = s.wikiRows(ctx, sj, space, ""); err != nil {
			return nil, err
		}
		kids = wikiKidsIndex(rows)
		start = kids[0]
	} else {
		if _, st, _, _, err = s.wikiChain(ctx, sj, sl, root.ID); err != nil {
			return nil, err
		}
		cond := `AND p.id = $8::bigint`
		if withKids {
			cond = `AND p.id IN (WITH RECURSIVE t AS (SELECT id, 0 AS d FROM wiki_pages WHERE id = $8::bigint
				UNION ALL SELECT c.id, t.d + 1 FROM wiki_pages c JOIN t ON c.parent_id = t.id WHERE t.d < 64) SELECT id FROM t)`
		}
		if rows, err = s.wikiRows(ctx, sj, space, cond, root.ID); err != nil {
			return nil, err
		}
		kids = wikiKidsIndex(rows)
		for i := range rows {
			if rows[i].ID == root.ID {
				start = append(start, i)
			}
		}
	}
	vis := wikiWalk(rows, kids, start, st, sj.UID, sl >= 4)
	byID := make(map[int64]*wbranchNode, len(vis))
	order := make([]int64, 0, len(vis))
	for _, v := range vis {
		order = append(order, v.row.ID)
		byID[v.row.ID] = &wbranchNode{ID: v.row.ID, PID: v.row.PID, Title: v.row.Title, Lvl: v.Lvl}
	}
	rs, err := s.db.Query(ctx, `SELECT id, body, sort, visibility, review_until, tags, icon FROM wiki_pages WHERE id = ANY($1::bigint[])`, order)
	if err != nil {
		return nil, err
	}
	for rs.Next() {
		var id int64
		var n wbranchNode
		if err := rs.Scan(&id, &n.Body, &n.Sort, &n.Vis, &n.Review, &n.Tags, &n.Icon); err != nil {
			rs.Close()
			return nil, err
		}
		b := byID[id]
		b.Body, b.Sort, b.Vis, b.Review, b.Tags, b.Icon = n.Body, n.Sort, n.Vis, n.Review, n.Tags, n.Icon
	}
	rs.Close()
	out := make([]wbranchNode, 0, len(order))
	for _, id := range order {
		out = append(out, *byID[id])
	}
	return out, nil
}

// ---------------------------------------------------------------- версии

func (s *Server) wikiVersions(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, _, err = s.wikiPageAt(c, id, wvEdit); err != nil {
		return err
	}
	b, err := s.arr(c.Context(), `SELECT v.version, v.title, v.comment, v.created_at, v.author_id, (SELECT full_name FROM users WHERE id = v.author_id) AS author, length(v.body) AS size
		FROM wiki_versions v WHERE v.page_id = $1 ORDER BY v.version DESC LIMIT 200`, id)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) wikiVersionGet(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	v, err := strconv.Atoi(c.R.PathValue("v"))
	if err != nil || v < 1 {
		return badReq("Некорректная версия")
	}
	if _, _, err = s.wikiPageAt(c, id, wvEdit); err != nil {
		return err
	}
	b, err := s.one(c.Context(), `SELECT v.version, v.title, v.body, v.comment, v.created_at, (SELECT full_name FROM users WHERE id = v.author_id) AS author
		FROM wiki_versions v WHERE v.page_id = $1 AND v.version = $2`, id, v)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) wikiRestore(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Version int `json:"version"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if _, _, err = s.wikiPageAt(c, id, wvEdit); err != nil {
		return err
	}
	ctx := c.Context()
	var newVer int
	err = s.tx(ctx, func(tx pgx.Tx) error {
		var title, body string
		if err := tx.QueryRow(ctx, `SELECT title, body FROM wiki_versions WHERE page_id = $1 AND version = $2`, id, in.Version).Scan(&title, &body); err != nil {
			return err
		}
		if err := tx.QueryRow(ctx, `UPDATE wiki_pages SET title = $2, slug = $3, body = $4, version = version + 1, updated_at = now(), updated_by = $5 WHERE id = $1 RETURNING version`,
			id, title, wikiSlug(title), body, c.U.ID).Scan(&newVer); err != nil {
			return err
		}
		_, err := tx.Exec(ctx, `INSERT INTO wiki_versions (page_id, version, title, body, author_id, comment) VALUES ($1, $2, $3, $4, $5, $6)`,
			id, newVer, title, body, c.U.ID, fmt.Sprintf("Восстановлена версия %d", in.Version))
		return err
	})
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"ok": true, "version": newVer})
}

// ---------------------------------------------------------------- вложения

func (s *Server) wikiFileUpload(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, _, err = s.wikiPageAt(c, id, wvEdit); err != nil {
		return err
	}
	if !s.rateOK(c.Context(), fmt.Sprintf("wfile:%d", c.U.ID), 120, time.Minute) {
		return &apiError{429, "Слишком много файлов. Подождите немного"}
	}
	ctx := c.Context()
	var ids []int64
	err = s.readParts(c, 20, func(name string, r io.Reader) error {
		st, err := s.storeUpload(r, name, false)
		if err != nil {
			return err
		}
		var fid int64
		err = s.tx(ctx, func(tx pgx.Tx) error {
			var err error
			if fid, err = s.insertFile(ctx, tx, st, nil, c.U.ID, "wiki"); err != nil {
				return err
			}
			_, err = tx.Exec(ctx, `INSERT INTO wiki_page_files (page_id, file_id, sort) VALUES ($1, $2, (SELECT coalesce(max(sort), 0) + 1 FROM wiki_page_files WHERE page_id = $1))`, id, fid)
			return err
		})
		if err != nil {
			s.removeStored(false, st.Storage, st.Thumb, st.View)
			return err
		}
		ids = append(ids, fid)
		return nil
	})
	if err != nil && len(ids) == 0 {
		return err
	}
	b, qerr := s.arr(ctx, `SELECT id, name, mime, size, width, height, thumb <> '' AS has_thumb FROM files WHERE id = ANY($1::bigint[]) ORDER BY id`, ids)
	if qerr != nil {
		return qerr
	}
	return c.Raw(201, b)
}

func (s *Server) wikiFileDelete(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	fid, err := strconv.ParseInt(c.R.PathValue("fid"), 10, 64)
	if err != nil {
		return badReq("Некорректный идентификатор")
	}
	if _, _, err = s.wikiPageAt(c, id, wvEdit); err != nil {
		return err
	}
	ctx := c.Context()
	tag, err := s.db.Exec(ctx, `DELETE FROM wiki_page_files WHERE page_id = $1 AND file_id = $2`, id, fid)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return errNotFound
	}
	s.wikiPurgeFiles(ctx, []int64{fid})
	return c.OK()
}

func (s *Server) wikiFileIDs(ctx context.Context, q string, args ...any) ([]int64, error) {
	rs, err := s.db.Query(ctx, q, args...)
	if err != nil {
		return nil, err
	}
	defer rs.Close()
	var out []int64
	for rs.Next() {
		var f int64
		rs.Scan(&f)
		out = append(out, f)
	}
	return out, rs.Err()
}

// wikiPurgeFiles удаляет записи files (context = wiki), на которые больше никто не ссылается, и байты на диске,
// если ими не делятся копии страниц.
func (s *Server) wikiPurgeFiles(ctx context.Context, ids []int64) {
	if len(ids) == 0 {
		return
	}
	rows, err := s.db.Query(ctx, `DELETE FROM files d WHERE d.id = ANY($1::bigint[]) AND d.context = 'wiki'
		AND NOT EXISTS (SELECT 1 FROM wiki_page_files w WHERE w.file_id = d.id)
		RETURNING d.storage, d.thumb, d.view, EXISTS (SELECT 1 FROM files o WHERE o.storage = d.storage AND o.id <> d.id)`, ids)
	if err != nil {
		s.log.Warn("wiki purge files", "err", err)
		return
	}
	var names []string
	for rows.Next() {
		var a, b, v string
		var shared bool
		rows.Scan(&a, &b, &v, &shared)
		if !shared {
			names = append(names, a, b, v)
		}
	}
	rows.Close()
	s.removeStored(false, names...)
}

// wikiSweeper раз в 30 минут удаляет «осиротевшие» файлы wiki (страница удалена каскадом вместе с папкой/базой).
func (s *Server) wikiSweeper() {
	t := time.NewTicker(30 * time.Minute)
	defer t.Stop()
	for range t.C {
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
		if s.rdb.SetNX(ctx, "lock:wiki-sweep", s.cfg.InstanceID, 25*time.Minute).Val() {
			ids, err := s.wikiFileIDs(ctx, `SELECT f.id FROM files f WHERE f.context = 'wiki' AND f.created_at < now() - interval '1 hour'
				AND NOT EXISTS (SELECT 1 FROM wiki_page_files w WHERE w.file_id = f.id) LIMIT 500`)
			if err == nil {
				s.wikiPurgeFiles(ctx, ids)
			}
		}
		cancel()
	}
}

// ---------------------------------------------------------------- комментарии

func (s *Server) wikiComments(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, _, err = s.wikiPageAt(c, id, wvView); err != nil {
		return err
	}
	b, err := s.arr(c.Context(), `SELECT c.id, c.user_id, c.body, c.created_at, u.full_name AS author, u.avatar AS author_avatar
		FROM wiki_comments c LEFT JOIN users u ON u.id = c.user_id WHERE c.page_id = $1 ORDER BY c.id LIMIT 500`, id)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) wikiCommentAdd(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Body string `json:"body"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Body = strings.TrimSpace(in.Body)
	if in.Body == "" || len([]rune(in.Body)) > 4000 {
		return badReq("Введите комментарий (до 4000 символов)")
	}
	if _, _, err = s.wikiPageAt(c, id, wvView); err != nil {
		return err
	}
	if !s.rateOK(c.Context(), fmt.Sprintf("wcm:%d", c.U.ID), 20, time.Minute) {
		return &apiError{429, "Слишком часто. Подождите немного"}
	}
	var cid int64
	if err := s.db.QueryRow(c.Context(), `INSERT INTO wiki_comments (page_id, user_id, body) VALUES ($1::bigint, $2::bigint, $3::text) RETURNING id`, id, c.U.ID, in.Body).Scan(&cid); err != nil {
		return err
	}
	b, err := s.one(c.Context(), `SELECT i.id, i.user_id, i.body, i.created_at, u.full_name AS author, u.avatar AS author_avatar FROM wiki_comments i LEFT JOIN users u ON u.id = i.user_id WHERE i.id = $1::bigint`, cid)
	if err != nil {
		return err
	}
	return c.Raw(201, b)
}

func (s *Server) wikiCommentDelete(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var page int64
	var author *int64
	if err := s.db.QueryRow(c.Context(), `SELECT page_id, user_id FROM wiki_comments WHERE id = $1`, id).Scan(&page, &author); err != nil {
		return err
	}
	p, _, err := s.wikiPageAt(c, page, wvView)
	if err != nil {
		return err
	}
	if !(author != nil && *author == c.U.ID) && p.Level < wvEdit {
		return errForbidden
	}
	if _, err := s.db.Exec(c.Context(), `DELETE FROM wiki_comments WHERE id = $1`, id); err != nil {
		return err
	}
	return c.OK()
}

// ---------------------------------------------------------------- последние изменения и «требуют обновления»

func (s *Server) wikiRecent(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	sp, sj, err := s.wikiSpace(c, id, wvView)
	if err != nil {
		return err
	}
	limit := min(max(c.QInt("limit", 15), 1), 50)
	b, err := s.arr(c.Context(), `SELECT * FROM (
		SELECT p.id, p.title, p.slug, p.icon, p.updated_at, p.version, (SELECT full_name FROM users WHERE id = p.updated_by) AS updated_by_name
		FROM wiki_pages p WHERE p.space_id = $7::bigint AND ($8::int >= 4 OR wiki_level(p.id, `+wA+`) > 0)
		ORDER BY p.updated_at DESC, p.id DESC LIMIT $9::int) x`, append(sj.args(), id, sp.Level, limit)...)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

const reviewCols = `p.id, p.space_id, (SELECT title FROM wiki_spaces WHERE id = p.space_id) AS space_title, p.title, p.slug, p.icon,
	to_char(p.review_until, 'YYYY-MM-DD') AS review_until, current_date - p.review_until AS days_over,
	p.responsible_id, (SELECT full_name FROM users WHERE id = p.responsible_id) AS responsible`

// wikiReviewSpace — страницы базы с истёкшим сроком актуальности: свои (ответственный / владелец); редакторы базы — все (?all=1).
func (s *Server) wikiReviewSpace(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	sp, sj, err := s.wikiSpace(c, id, wvView)
	if err != nil {
		return err
	}
	all := c.Q("all") == "1" && sp.Level >= wvEdit
	b, err := s.arr(c.Context(), `SELECT * FROM (SELECT `+reviewCols+`, wiki_level(p.id, `+wA+`) AS lv FROM wiki_pages p
		WHERE p.space_id = $7::bigint AND p.review_until < current_date AND ($8::boolean OR p.responsible_id = $1 OR p.owner_id = $1)
		ORDER BY p.review_until LIMIT 300) x WHERE lv >= 1 LIMIT 100`, append(sj.args(), id, all)...)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) wikiReviewMine(c *Ctx) error {
	sj, err := s.wikiSubj(c.Context(), c.U)
	if err != nil {
		return err
	}
	b, err := s.arr(c.Context(), `SELECT * FROM (SELECT `+reviewCols+`, wiki_level(p.id, `+wA+`) AS lv FROM wiki_pages p
		WHERE p.review_until < current_date AND (p.responsible_id = $1 OR p.owner_id = $1) ORDER BY p.review_until LIMIT 300) x WHERE lv >= 1 LIMIT 100`, sj.args()...)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}
