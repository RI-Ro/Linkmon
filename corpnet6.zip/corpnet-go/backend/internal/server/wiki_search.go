package server

import (
	"context"
	"encoding/json"
	"strings"
)

// Поиск по страницам баз знаний. Порядок работы:
//  1. кандидаты — по GIN-индексу tsvector 'simple' (префиксы слов) и по подстроке названия (триграммы), без чтения текста страниц;
//  2. права проверяются в SQL (wiki_space_level / wiki_level) ДО формирования сниппетов: ts_headline считается
//     только для уже разрешённых строк результата (внешний запрос над подзапросом с LIMIT);
//  3. скрытые страницы не попадают в выдачу никогда, даже названием.

const wikiSearchCands = 300

func (s *Server) wikiSearchRows(ctx context.Context, sj *wsubj, q string, space int64, limit int) (json.RawMessage, error) {
	ts := tsPrefixQuery(q)
	if ts == "" {
		return json.RawMessage(`[]`), nil
	}
	phrase := strings.Join(searchTokens(q), " ")
	cond := `p.search @@ tq.q`
	args := append(sj.args(), ts, space, limit, "%"+likeEscape(phrase)+"%")
	if len([]rune(phrase)) >= 3 {
		cond = `(p.search @@ tq.q OR lower(p.title) LIKE $10 ESCAPE '\')`
	}
	return s.arr(ctx, `SELECT x.id, x.space_id, x.space_title, x.space_icon, x.title, x.slug, x.icon, x.updated_at,
			ts_headline('simple', left(p.body, 20000), tq.q, 'MaxFragments=1, MaxWords=26, MinWords=10, StartSel=<<, StopSel=>>') AS snippet
		FROM (
			SELECT c.id, c.space_id, so.title AS space_title, so.icon AS space_icon, c.title, c.slug, c.icon, c.updated_at, c.prio
			FROM (
				SELECT p.id, p.space_id, p.title, p.slug, p.icon, p.updated_at,
					(lower(p.title) LIKE $10 ESCAPE '\') AS prio
				FROM wiki_pages p, (SELECT to_tsquery('simple', $7::text) AS q) tq
				WHERE `+cond+` AND ($8::bigint = 0 OR p.space_id = $8::bigint)
				ORDER BY (lower(p.title) LIKE $10 ESCAPE '\') DESC, p.updated_at DESC LIMIT `+itoa(wikiSearchCands)+`
			) c
			JOIN (SELECT s.id, s.title, s.icon, wiki_space_level(s.id, `+wA+`) AS lvl FROM wiki_spaces s) so ON so.id = c.space_id
			WHERE so.lvl >= 4 OR (so.lvl > 0 AND wiki_level(c.id, `+wA+`) > 0)
			ORDER BY c.prio DESC, c.updated_at DESC LIMIT $9::int
		) x
		JOIN wiki_pages p ON p.id = x.id, (SELECT to_tsquery('simple', $7::text) AS q) tq
		ORDER BY x.prio DESC, x.updated_at DESC`, args...)
}

func (s *Server) wikiSearch(c *Ctx) error {
	q := c.Q("q")
	if len([]rune(q)) < 2 || len(searchTokens(q)) == 0 {
		return c.Raw(200, []byte(`[]`))
	}
	sj, err := s.wikiSubj(c.Context(), c.U)
	if err != nil {
		return err
	}
	b, err := s.wikiSearchRows(c.Context(), sj, q, c.QInt64("space"), min(max(c.QInt("limit", 20), 1), 50))
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// wikiSearchBrief — секция «Wiki» общего поиска (/api/search): до n страниц; при ошибке — пустой список.
func (s *Server) wikiSearchBrief(c *Ctx, q string, n int) json.RawMessage {
	sj, err := s.wikiSubj(c.Context(), c.U)
	if err != nil {
		return json.RawMessage(`[]`)
	}
	b, err := s.wikiSearchRows(c.Context(), sj, q, 0, n)
	if err != nil {
		s.log.Warn("wiki search", "err", err)
		return json.RawMessage(`[]`)
	}
	return b
}
