package server

import (
	"encoding/json"
	"strconv"
)

// seedRequests — шаблоны раздела «Заявки» из коробки: справка, отпуск, ИТ, командировка, АХО.
// Идемпотентно: типы определяются по коду; если тип с таким кодом уже есть, он не создаётся повторно.
func (s *Server) seedRequests(d sd, uid []int64, dep map[string]int64) {
	type M = map[string]any
	type L = []any
	cat := func(name, icon, color string, sort int) int64 {
		var id int64
		if err := d.tx.QueryRow(d.ctx, `SELECT id FROM req_categories WHERE name = $1`, name).Scan(&id); err == nil {
			return id
		}
		return d.id(`INSERT INTO req_categories (name, icon, color, sort) VALUES ($1, $2, $3, $4) RETURNING id`, name, icon, color, sort)
	}
	cDocs := cat("Справки", "file", "#286b9e", 10)
	cLeave := cat("Отпуск и отсутствия", "calendar", "#2f9e44", 20)
	cIT := cat("ИТ", "cpu", "#7c5cff", 30)
	cAHO := cat("АХО", "building", "#e8590c", 40)

	profile := func(k string) M { return M{"profile": k} }
	opts := func(v ...string) L {
		out := L{}
		for _, x := range v {
			out = append(out, M{"value": x, "label": x})
		}
		return out
	}
	kv := func(pairs ...string) L {
		out := L{}
		for i := 0; i+1 < len(pairs); i += 2 {
			out = append(out, M{"value": pairs[i], "label": pairs[i+1]})
		}
		return out
	}
	eq := func(f string, v any) M { return M{"op": "and", "items": L{M{"field": f, "cmp": "eq", "value": v}}} }
	user := func(id int64) M { return M{"t": "user", "id": id} }

	type tdef struct {
		code, name, desc, icon, color, mask string
		cat                                 int64
		dept                                string
		owner                               int64
		sla                                 int
		slaUnit                             string
		sections                            L
		layout                              string
		steps                               L
		hooks                               L
		resp                                []string // подразделения-ответственные
		watchers                            []int64
	}
	defs := []tdef{
		{
			code: "СПР", name: "Справка с места работы", icon: "file", color: "#286b9e", mask: "{CODE}-{YYYY}-{NNNN}", cat: cDocs, dept: "hr", owner: uid[1], sla: 3, slaUnit: "wd",
			desc: "Закажите справку, подтверждающую ваше место работы, должность или доход.\n\nСрок изготовления — **до 3 рабочих дней**. Готовую справку (PDF) вы получите вложением к заявке.",
			sections: L{M{"id": "s1", "title": "Справка", "fields": L{
				M{"key": "fio", "type": "text", "label": "ФИО", "default": profile("full_name"), "required": true, "width": "1/2"},
				M{"key": "position", "type": "text", "label": "Должность", "default": profile("job_title"), "width": "1/2"},
				M{"key": "kind", "type": "select", "label": "Вид справки", "required": true, "options": kv("work", "С места работы (должность, стаж)", "ndfl", "Справка 2-НДФЛ", "salary", "С указанием заработной платы", "leave", "О нахождении в отпуске по уходу за ребёнком", "other", "Другая"), "width": "1/2"},
				M{"key": "copies", "type": "number", "label": "Количество экземпляров", "default": 1, "min": 1, "max": 10, "required": true, "width": "1/2"},
				M{"key": "purpose", "type": "text", "label": "Для предъявления в", "placeholder": "Например: в банк, посольство, по месту требования", "required": true, "max_len": 200},
				M{"key": "receive", "type": "radio", "label": "Способ получения", "required": true, "default": "pdf", "options": kv("pdf", "Электронная копия (PDF) в заявке", "hr", "Лично в отделе кадров", "courier", "Курьером в офис")},
				M{"key": "address", "type": "text", "label": "Адрес доставки / офис", "visible_if": eq("receive", "courier"), "required_if": eq("receive", "courier")},
				M{"key": "other", "type": "text", "label": "Что должно быть указано", "visible_if": eq("kind", "other"), "required_if": eq("kind", "other")},
				M{"key": "comment", "type": "textarea", "label": "Комментарий", "max_len": 1000},
			}}},
			steps: L{M{"id": "prepare", "name": "Подготовка справки (кадры)", "kind": "execute", "branches": L{M{"mode": "any", "assignees": L{M{"t": "responsible"}}}},
				"sla": M{"value": 3, "unit": "wd"}, "remind_before_h": 4, "escalate": M{"to": "user", "user_id": uid[9]}}},
			resp: []string{"hrs"}, watchers: []int64{uid[9]},
		},
		{
			code: "ОТП", name: "Заявление на ежегодный оплачиваемый отпуск", icon: "calendar", color: "#2f9e44", mask: "{CODE}-{YYYY}-{NNNN}", cat: cLeave, dept: "hr", owner: uid[1], sla: 2, slaUnit: "wd",
			desc:   "Заявление на **ежегодный оплачиваемый отпуск**. Подайте не позднее чем за 14 дней до начала.\n\n1. Согласует непосредственный руководитель (если он в отпуске — его заместитель по графику)\n2. При отпуске **дольше 14 календарных дней** — руководитель следующего уровня\n3. Кадры оформляют приказ",
			layout: "single",
			sections: L{
				M{"id": "who", "title": "Сотрудник", "fields": L{
					M{"key": "fio", "type": "text", "label": "ФИО", "default": profile("full_name"), "required": true, "width": "1/2"},
					M{"key": "position", "type": "text", "label": "Должность", "default": profile("job_title"), "width": "1/2"},
					M{"key": "department", "type": "department", "label": "Подразделение", "default": profile("department"), "width": "1/2"},
					M{"key": "phone", "type": "phone", "label": "Контактный телефон на время отпуска", "default": profile("phone"), "width": "1/2"},
				}},
				M{"id": "period", "title": "Отпуск", "fields": L{
					M{"key": "kind", "type": "select", "label": "Вид отпуска", "required": true, "default": "annual", "options": kv("annual", "Ежегодный основной", "extra", "Ежегодный дополнительный", "part", "Часть отпуска")},
					M{"key": "period", "type": "period", "label": "Период отпуска", "required": true, "min": "today", "hint": "Автоматически считаются календарные и рабочие дни"},
					M{"key": "long_note", "type": "note", "label": "Отпуск более 14 календарных дней дополнительно согласует руководитель следующего уровня.", "visible_if": M{"op": "and", "items": L{M{"field": "period.days", "cmp": "gt", "value": 14}}}},
					M{"key": "deputy", "type": "user", "label": "Заместитель на период отпуска", "hint": "Кто будет выполнять ваши обязанности"},
					M{"key": "comment", "type": "textarea", "label": "Комментарий", "max_len": 1000},
					M{"key": "add_schedule", "type": "switch", "label": "После согласования добавить в график отпусков", "hint": "Доступно руководителям подразделений: отпуск появится в общем графике"},
				}},
			},
			steps: L{
				M{"id": "mgr", "name": "Согласование руководителя", "kind": "approve", "branches": L{M{"mode": "any", "assignees": L{M{"t": "manager"}}}},
					"fallback": L{M{"t": "manager_up", "n": 1}}, "sla": M{"value": 2, "unit": "wd"}, "remind_before_h": 4, "escalate": M{"to": "manager_up", "n": 1}},
				M{"id": "mgr2", "name": "Согласование руководителя следующего уровня", "kind": "approve", "cond": M{"op": "and", "items": L{M{"field": "period.days", "cmp": "gt", "value": 14}}},
					"branches": L{M{"mode": "any", "assignees": L{M{"t": "manager_up", "n": 1}}}}, "sla": M{"value": 2, "unit": "wd"}},
				M{"id": "hr", "name": "Оформление приказа (кадры)", "kind": "execute", "branches": L{M{"mode": "any", "assignees": L{M{"t": "responsible"}}}}, "sla": M{"value": 3, "unit": "wd"}},
			},
			hooks: L{M{"action": "vacation", "period": "period", "deputy": "deputy", "flag": "add_schedule"}},
			resp:  []string{"hrs"}, watchers: []int64{uid[9]},
		},
		{
			code: "ИТ", name: "Заявка в ИТ: доступ, оборудование, проблема", icon: "cpu", color: "#7c5cff", mask: "{CODE}-{YYYY}-{NNNNNN}", cat: cIT, dept: "it", owner: uid[6], sla: 1, slaUnit: "wd",
			desc: "Единая заявка в службу ИТ.\n\n- **Доступ** — к системам, папкам, VPN (согласует руководитель и информационная безопасность)\n- **Оборудование** — ноутбук, монитор, периферия (согласует руководитель)\n- **Проблема** — что-то сломалось или не работает (сразу в работу)",
			sections: L{
				M{"id": "main", "title": "Что нужно", "fields": L{
					M{"key": "kind", "type": "radio", "label": "Тип обращения", "required": true, "default": "problem", "options": kv("access", "Доступ", "hardware", "Оборудование", "problem", "Проблема")},
					M{"key": "priority", "type": "select", "label": "Приоритет", "required": true, "default": "normal", "options": kv("low", "Низкий", "normal", "Обычный", "high", "Высокий", "critical", "Критичный — работа остановлена"), "width": "1/2"},
					M{"key": "phone", "type": "phone", "label": "Телефон для связи", "default": profile("phone"), "width": "1/2"},
				}},
				M{"id": "details", "title": "Подробности", "fields": L{
					M{"key": "system", "type": "text", "label": "Система / ресурс", "placeholder": "Например: CRM, 1С, VPN, общая папка «Продажи»", "visible_if": eq("kind", "access"), "required_if": eq("kind", "access")},
					M{"key": "access_level", "type": "radio", "label": "Уровень доступа", "options": kv("read", "Чтение", "write", "Чтение и запись", "admin", "Администрирование"), "visible_if": eq("kind", "access")},
					M{"key": "equipment", "type": "table", "label": "Оборудование", "visible_if": eq("kind", "hardware"), "required_if": eq("kind", "hardware"), "min_rows": 1, "max_rows": 20, "columns": L{
						M{"key": "name", "type": "text", "label": "Наименование", "required": true},
						M{"key": "qty", "type": "number", "label": "Кол-во", "min": 1, "max": 100, "required": true},
						M{"key": "note", "type": "text", "label": "Комментарий"},
					}},
					M{"key": "why", "type": "textarea", "label": "Обоснование", "visible_if": M{"op": "or", "items": L{M{"field": "kind", "cmp": "eq", "value": "access"}, M{"field": "kind", "cmp": "eq", "value": "hardware"}}}, "required_if": eq("kind", "hardware")},
					M{"key": "problem", "type": "textarea", "label": "Опишите проблему", "visible_if": eq("kind", "problem"), "required_if": eq("kind", "problem"), "min_len": 10, "max_len": 3000},
					M{"key": "files", "type": "file", "label": "Скриншоты и файлы", "multiple": true, "max_files": 5},
				}},
			},
			steps: L{
				M{"id": "mgr", "name": "Согласование руководителя", "kind": "approve", "cond": eq("kind", "hardware"), "branches": L{M{"mode": "any", "assignees": L{M{"t": "manager"}}}}, "sla": M{"value": 2, "unit": "wd"}},
				M{"id": "acc", "name": "Согласование доступа: руководитель и ИБ", "kind": "approve", "cond": eq("kind", "access"),
					"branches": L{M{"name": "Руководитель", "mode": "any", "assignees": L{M{"t": "manager"}}}, M{"name": "Информационная безопасность", "mode": "any", "assignees": L{user(uid[31])}}},
					"sla":      M{"value": 2, "unit": "wd"}},
				M{"id": "run", "name": "Исполнение (служба ИТ)", "kind": "execute", "branches": L{M{"mode": "any", "assignees": L{M{"t": "responsible"}}}},
					"sla": M{"value": 8, "unit": "wh"}, "remind_before_h": 2, "escalate": M{"to": "user", "user_id": uid[0]}},
			},
			resp: []string{"infra"}, watchers: []int64{uid[0]},
		},
		{
			code: "КМД", name: "Командировка", icon: "briefcase", color: "#e8590c", mask: "{CODE}-{YYYY}-{NNNN}", cat: cLeave, dept: "hr", owner: uid[1], sla: 2, slaUnit: "wd",
			desc: "Заявка на служебную командировку. При бюджете **свыше 100 000 ₽** дополнительно согласует финансовый директор.",
			sections: L{M{"id": "s1", "title": "Командировка", "fields": L{
				M{"key": "city", "type": "text", "label": "Город назначения", "required": true, "width": "1/2"},
				M{"key": "org", "type": "text", "label": "Принимающая организация", "width": "1/2"},
				M{"key": "period", "type": "period", "label": "Период командировки", "required": true, "min": "today"},
				M{"key": "goal", "type": "textarea", "label": "Цель командировки", "required": true, "max_len": 1000},
				M{"key": "transport", "type": "checkboxes", "label": "Транспорт", "options": opts("Поезд", "Самолёт", "Автомобиль"), "width": "1/2"},
				M{"key": "budget", "type": "money", "label": "Ориентировочный бюджет", "required": true, "min": 0, "width": "1/2"},
				M{"key": "advance", "type": "switch", "label": "Нужен аванс"},
				M{"key": "advance_sum", "type": "money", "label": "Сумма аванса", "visible_if": eq("advance", true), "required_if": eq("advance", true), "min": 0},
			}}},
			steps: L{
				M{"id": "mgr", "name": "Согласование руководителя", "kind": "approve", "branches": L{M{"mode": "any", "assignees": L{M{"t": "manager"}}}}, "fallback": L{M{"t": "manager_up", "n": 1}}, "sla": M{"value": 2, "unit": "wd"}},
				M{"id": "fin", "name": "Согласование финансового директора", "kind": "approve", "cond": M{"op": "and", "items": L{M{"field": "budget", "cmp": "gt", "value": 100000}}},
					"branches": L{M{"mode": "any", "assignees": L{user(uid[3])}}}, "sla": M{"value": 2, "unit": "wd"}},
				M{"id": "acc", "name": "Оформление приказа и аванса (бухгалтерия)", "kind": "execute", "branches": L{M{"mode": "any", "assignees": L{M{"t": "dept", "id": dep["acc"]}}}}, "sla": M{"value": 3, "unit": "wd"}},
			},
			resp: []string{"acc"}, watchers: []int64{uid[9]},
		},
		{
			code: "АХО", name: "АХО: пропуск, канцелярия, ремонт", icon: "building", color: "#d6336c", mask: "{CODE}-{YYYY}-{NNNN}", cat: cAHO, dept: "adm", owner: 0, sla: 2, slaUnit: "wd",
			desc: "Административно-хозяйственные вопросы: **гостевой пропуск**, **канцелярские товары**, **мелкий ремонт** в офисе.",
			sections: L{
				M{"id": "s1", "title": "Что нужно", "fields": L{
					M{"key": "kind", "type": "radio", "label": "Вид заявки", "required": true, "default": "pass", "options": kv("pass", "Гостевой пропуск", "stationery", "Канцелярия", "repair", "Ремонт и обслуживание")},
				}},
				M{"id": "pass", "title": "Гость", "visible_if": eq("kind", "pass"), "fields": L{
					M{"key": "guest", "type": "text", "label": "ФИО гостя", "required": true, "width": "1/2"},
					M{"key": "guest_org", "type": "text", "label": "Организация гостя", "width": "1/2"},
					M{"key": "date", "type": "date", "label": "Дата визита", "required": true, "min": "today", "width": "1/2"},
					M{"key": "time", "type": "time", "label": "Время прихода", "width": "1/2"},
					M{"key": "guest_email", "type": "email", "label": "Email гостя (для отправки пропуска)"},
				}},
				M{"id": "stat", "title": "Канцелярия", "visible_if": eq("kind", "stationery"), "fields": L{
					M{"key": "items", "type": "table", "label": "Список", "required": true, "min_rows": 1, "max_rows": 50, "columns": L{
						M{"key": "name", "type": "text", "label": "Позиция", "required": true},
						M{"key": "qty", "type": "number", "label": "Кол-во", "min": 1, "required": true},
					}},
				}},
				M{"id": "rep", "title": "Ремонт", "visible_if": eq("kind", "repair"), "fields": L{
					M{"key": "place", "type": "text", "label": "Где (этаж, кабинет)", "required": true, "width": "1/2"},
					M{"key": "urgency", "type": "select", "label": "Срочность", "default": "normal", "options": kv("normal", "Обычная", "high", "Срочно"), "width": "1/2"},
					M{"key": "descr", "type": "textarea", "label": "Что случилось", "required": true},
					M{"key": "photo", "type": "file", "label": "Фото", "multiple": true, "accept": "image/*", "max_files": 3},
				}},
			},
			steps: L{M{"id": "run", "name": "Исполнение (АХО)", "kind": "execute", "branches": L{M{"mode": "any", "assignees": L{M{"t": "responsible"}}}}, "sla": M{"value": 2, "unit": "wd"}, "remind_before_h": 4,
				"escalate": M{"to": "manager"}}},
			resp: []string{"adm"},
		},
	}
	for i, t := range defs {
		var exist bool
		if err := d.tx.QueryRow(d.ctx, `SELECT EXISTS (SELECT 1 FROM req_types WHERE code = $1 AND created_by IS NOT DISTINCT FROM $2)`, t.code, uid[0]).Scan(&exist); err != nil || exist {
			continue
		}
		layout := t.layout
		if layout == "" {
			layout = "single"
		}
		schema, _ := json.Marshal(M{"layout": layout, "sections": t.sections})
		wf := M{"steps": t.steps}
		if t.hooks != nil {
			wf["hooks"] = t.hooks
		}
		wfj, _ := json.Marshal(wf)
		tid := d.id(`INSERT INTO req_types (category_id, code, name, description, icon, color, number_mask, sla_value, sla_unit, remind_before_h, active, department_id, created_by, sort)
			VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 4, true, $10, $11, $12) RETURNING id`,
			t.cat, t.code, t.name, t.desc, t.icon, t.color, t.mask, t.sla, t.slaUnit, dep[t.dept], uid[0], (i+1)*10)
		vid := d.id(`INSERT INTO req_type_versions (type_id, version, schema, workflow, note, created_by) VALUES ($1, 1, $2::jsonb, $3::jsonb, 'Шаблон из коробки', $4) RETURNING id`, tid, string(schema), string(wfj), uid[0])
		d.exec(`UPDATE req_types SET cur_version = $2 WHERE id = $1`, tid, vid)
		d.exec(`INSERT INTO req_acl (type_id, kind, subject_type) VALUES ($1, 'submit', 'all')`, tid)
		if t.owner > 0 {
			d.exec(`INSERT INTO req_acl (type_id, kind, subject_type, subject_id) VALUES ($1, 'owner', 'user', $2)`, tid, t.owner)
		}
		for _, r := range t.resp {
			d.exec(`INSERT INTO req_acl (type_id, kind, subject_type, subject_id) VALUES ($1, 'responsible', 'department', $2)`, tid, dep[r])
		}
		for _, w := range t.watchers {
			d.exec(`INSERT INTO req_acl (type_id, kind, subject_type, subject_id) VALUES ($1, 'watcher', 'user', $2) ON CONFLICT DO NOTHING`, tid, w)
		}
	}
	_ = strconv.Itoa
}
