package server

import (
	"context"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
)

// Раздел «Заявки» (см. requests_schema.go — перечень файлов).
//
// Права:
//   подавать        — req_acl kind=submit (все / пользователи / подразделения с наследованием вниз / группы / роли); админ — любой активный тип
//   редактировать   — админ; создатель типа; владельцы типа (kind=owner); редактор, если подразделение типа в его области (scope.go)
//   видеть все      — ответственные (responsible) и наблюдатели (watcher) типа; админ (кроме чужих черновиков)
//   заявитель       — свои заявки; исполнители — заявки, которые приходили на их шаг (в том числе пройденные).
// Каждый эндпоинт и каждый список/поиск/экспорт проверяют права на сервере.

func (s *Server) registerRequests(m *http.ServeMux) {
	const U = "user"
	p := "/api/requests"
	m.HandleFunc("GET "+p+"/catalog", s.h(U, s.reqCatalog))
	m.HandleFunc("GET "+p+"/counts", s.h(U, s.reqCounts))
	m.HandleFunc("GET "+p+"/types/{id}/form", s.h(U, s.reqTypeForm))
	m.HandleFunc("POST "+p+"/files", s.h(U, s.reqUploadFile))
	m.HandleFunc("GET "+p+"/export.csv", s.h(U, s.reqExportCSV))
	m.HandleFunc("POST "+p+"/bulk", s.h(U, s.reqBulk))
	m.HandleFunc("GET "+p, s.h(U, s.reqList))
	m.HandleFunc("POST "+p, s.h(U, s.reqCreate))
	m.HandleFunc("GET "+p+"/{id}", s.h(U, s.reqGet))
	m.HandleFunc("PUT "+p+"/{id}", s.h(U, s.reqUpdate))
	m.HandleFunc("DELETE "+p+"/{id}", s.h(U, s.reqDeleteDraft))
	m.HandleFunc("POST "+p+"/{id}/action", s.h(U, s.reqActionH))
	m.HandleFunc("POST "+p+"/{id}/comments", s.h(U, s.reqComment))

	// конструктор (requests_manage.go)
	s.registerRequestsManage(m)
}

// ---------------------------------------------------------------- права

func (s *Server) reqCanSubmit(ctx context.Context, u *User, typeID int64) (bool, error) {
	var ok bool
	err := s.db.QueryRow(ctx, `SELECT active AND NOT archived AND ($2 OR req_in_acl(id, 'submit', $3)) FROM req_types WHERE id = $1`, typeID, u.IsAdmin(), u.ID).Scan(&ok)
	if err == pgx.ErrNoRows {
		return false, nil
	}
	return ok, err
}

// reqViewTypes — типы, все заявки которых видит пользователь (ответственный / наблюдатель). all=true для администратора.
func (s *Server) reqViewTypes(ctx context.Context, u *User) (ids []int64, all bool, err error) {
	if u.IsAdmin() {
		return []int64{}, true, nil
	}
	rows, err := s.db.Query(ctx, `SELECT id FROM req_types WHERE req_in_acl(id, 'responsible', $1) OR req_in_acl(id, 'watcher', $1)`, u.ID)
	ids, err = reqScanIDs(rows, err)
	if ids == nil {
		ids = []int64{}
	}
	return ids, false, err
}

// reqIsManagerOf: ответственный типа / владелец / админ — может назначать исполнителей вручную.
func (s *Server) reqIsManagerOf(ctx context.Context, u *User, typeID int64) bool {
	if u.IsAdmin() {
		return true
	}
	var ok bool
	_ = s.db.QueryRow(ctx, `SELECT req_in_acl($1, 'responsible', $2) OR req_in_acl($1, 'owner', $2)`, typeID, u.ID).Scan(&ok)
	return ok
}

// ---------------------------------------------------------------- каталог и форма

func (s *Server) reqCatalog(c *Ctx) error {
	ctx := c.Context()
	u := c.U
	types, err := s.arr(ctx, `SELECT t.id, t.category_id, t.name, t.description, t.icon, t.color, t.sla_value, t.sla_unit, t.sort
		FROM req_types t WHERE t.active AND NOT t.archived AND ($2 OR req_in_acl(t.id, 'submit', $1))
		ORDER BY t.sort, lower(t.name), t.id`, u.ID, u.IsAdmin())
	if err != nil {
		return err
	}
	cats, err := s.arr(ctx, `SELECT id, name, icon, color, sort FROM req_categories ORDER BY sort, lower(name), id`)
	if err != nil {
		return err
	}
	freq, err := s.arr(ctx, `SELECT type_id, count(*) AS n, max(created_at) AS last FROM req_requests
		WHERE author_id = $1 AND created_at > now() - interval '180 days' AND status <> 'draft' GROUP BY type_id ORDER BY n DESC, last DESC LIMIT 6`, u.ID)
	if err != nil {
		return err
	}
	viewTypes, all, err := s.reqViewTypes(ctx, u)
	if err != nil {
		return err
	}
	viewList, err := s.arr(ctx, `SELECT id, name, icon, color FROM req_types WHERE NOT archived AND ($1 OR id = ANY($2::bigint[])) ORDER BY lower(name)`, all, viewTypes)
	if err != nil {
		return err
	}
	var manage bool
	if u.CanEdit() {
		manage = true
	} else if err := s.db.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM req_types WHERE NOT archived AND (created_by = $1 OR req_in_acl(id, 'owner', $1)))`, u.ID).Scan(&manage); err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"types": types, "categories": cats, "frequent": freq, "view_types": json.RawMessage(viewList), "view_all": all, "can_manage": manage})
}

func (s *Server) reqCounts(c *Ctx) error {
	var inbox, approve, rework, active int64
	err := s.db.QueryRow(c.Context(), `SELECT
		(SELECT count(*) FROM (SELECT 1 FROM req_assignees WHERE user_id = $1 AND state = 'pending' LIMIT 100) q),
		(SELECT count(*) FROM (SELECT 1 FROM req_assignees a JOIN req_steps st ON st.id = a.step_id WHERE a.user_id = $1 AND a.state = 'pending' AND st.kind = 'approve' LIMIT 100) q),
		(SELECT count(*) FROM (SELECT 1 FROM req_requests WHERE author_id = $1 AND status = 'rework' LIMIT 100) q),
		(SELECT count(*) FROM (SELECT 1 FROM req_requests WHERE author_id = $1 AND status IN ('pending', 'in_progress') LIMIT 100) q)`, c.U.ID).Scan(&inbox, &approve, &rework, &active)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]int64{"inbox": inbox, "approve": approve, "assigned": inbox - approve, "rework": rework, "active": active})
}

func reqRouteNames(wf *reqWF) []map[string]any {
	out := []map[string]any{}
	for _, st := range wf.Steps {
		out = append(out, map[string]any{"name": st.Name, "kind": st.Kind, "conditional": st.Cond != nil && len(st.Cond.Items) > 0})
	}
	return out
}

func (s *Server) reqTypeForm(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	can, err := s.reqCanSubmit(ctx, c.U, id)
	if err != nil {
		return err
	}
	if !can {
		var exists bool
		_ = s.db.QueryRow(ctx, `SELECT true FROM req_types WHERE id = $1`, id).Scan(&exists)
		if !exists {
			return errNotFound
		}
		sc, err := s.scopeOf(ctx, c.U)
		if err != nil {
			return err
		}
		if ok, err := s.canManageType(ctx, c.U, sc, id); err != nil || !ok {
			return errForbidden // доступ к форме только подающим и редакторам типа (для предпросмотра)
		}
	}
	var name, desc, icon, color, schema, wf string
	var verID int64
	var ver int
	var active bool
	err = s.db.QueryRow(ctx, `SELECT t.name, t.description, t.icon, t.color, v.id, v.version, v.schema::text, v.workflow::text, t.active
		FROM req_types t JOIN req_type_versions v ON v.id = t.cur_version WHERE t.id = $1`, id).Scan(&name, &desc, &icon, &color, &verID, &ver, &schema, &wf, &active)
	if err != nil {
		return err
	}
	w := &reqWF{}
	_ = json.Unmarshal([]byte(wf), w)
	return c.JSON(200, map[string]any{"type": map[string]any{"id": id, "name": name, "description": desc, "icon": icon, "color": color, "active": active},
		"version_id": verID, "version": ver, "schema": json.RawMessage(schema), "route": reqRouteNames(w), "can_submit": can})
}

// ---------------------------------------------------------------- файлы

func (s *Server) reqUploadFile(c *Ctx) error {
	if !s.rateOK(c.Context(), fmt.Sprintf("rfile:%d", c.U.ID), 60, time.Minute) {
		return &apiError{429, "Слишком много файлов. Подождите немного"}
	}
	var out json.RawMessage
	err := s.readParts(c, 1, func(name string, r io.Reader) error {
		st, err := s.storeUpload(r, name, false)
		if err != nil {
			return err
		}
		id, err := s.insertFile(c.Context(), s.db, st, nil, c.U.ID, "request")
		if err != nil {
			s.removeStored(false, st.Storage, st.Thumb, st.View)
			return err
		}
		out, err = s.one(c.Context(), `SELECT `+fileJSON+` FROM files WHERE id = $1`, id)
		return err
	})
	if err != nil {
		return err
	}
	return c.Raw(201, out)
}

// ---------------------------------------------------------------- создание и правка

type reqSaveIn struct {
	TypeID   int64          `json:"type_id"`
	Data     map[string]any `json:"data"`
	Submit   bool           `json:"submit"`
	ClientID string         `json:"client_id"`
}

func reqFieldErr(c *Ctx, errs reqFieldErrors) error {
	return c.JSON(422, map[string]any{"error": errs.Error(), "fields": errs})
}

// reqSummary — короткая сводка заявки для списков: название типа + значения первых содержательных полей.
func reqSummary(typeName string, sc *reqSchema, data map[string]any) string {
	var parts []string
	for _, f := range sc.fields() {
		if len(parts) >= 2 {
			break
		}
		v, ok := data[f.Key]
		if !ok || reqIsEmpty(v) {
			continue
		}
		switch f.Type {
		case "select", "radio", "text", "period", "date", "number", "money", "phone", "email", "user", "department":
			t := reqFormatValue(f, v)
			if t != "" && reqRuneLen(t) <= 80 {
				parts = append(parts, t)
			}
		}
	}
	t := typeName
	if len(parts) > 0 {
		t += ": " + strings.Join(parts, ", ")
	}
	if reqRuneLen(t) > 200 {
		t = string([]rune(t)[:200])
	}
	return t
}

func reqFmtDate(s string) string {
	if t, err := time.Parse("2006-01-02", s); err == nil {
		return t.Format("02.01.2006")
	}
	return s
}

// reqFormatValue — человекочитаемое значение поля (журнал, CSV, сводка).
func reqFormatValue(f *reqField, v any) string {
	if reqIsEmpty(v) {
		return ""
	}
	label := func(val any) string {
		k := reqValKey(val)
		for _, o := range f.Options {
			if o.Value == k {
				return o.Label
			}
		}
		return k
	}
	switch f.Type {
	case "date":
		return reqFmtDate(reqValKey(v))
	case "period":
		m, _ := v.(map[string]any)
		d, _ := reqFloat(m["days"])
		w, _ := reqFloat(m["workdays"])
		return fmt.Sprintf("%s — %s (%d кал. дн., %d раб.)", reqFmtDate(reqValKey(m["from"])), reqFmtDate(reqValKey(m["to"])), int(d), int(w))
	case "select", "radio":
		return label(v)
	case "checkboxes":
		var out []string
		if arr, ok := v.([]any); ok {
			for _, e := range arr {
				out = append(out, label(e))
			}
		}
		return strings.Join(out, ", ")
	case "switch":
		if b, _ := v.(bool); b {
			return "Да"
		}
		return "Нет"
	case "user", "department":
		var out []string
		switch x := v.(type) {
		case []any:
			for _, e := range x {
				if m, ok := e.(map[string]any); ok {
					out = append(out, reqValKey(m["name"]))
				}
			}
		case map[string]any:
			out = append(out, reqValKey(x["name"]))
		}
		return strings.Join(out, ", ")
	case "file":
		var out []string
		if arr, ok := v.([]any); ok {
			for _, e := range arr {
				if m, ok := e.(map[string]any); ok {
					out = append(out, reqValKey(m["name"]))
				}
			}
		}
		return strings.Join(out, ", ")
	case "money", "number":
		n, _ := reqFloat(v)
		if f.Type == "money" {
			return strconv.FormatFloat(n, 'f', 2, 64) + " ₽"
		}
		t := strconv.FormatFloat(n, 'f', -1, 64)
		if f.Unit != "" {
			t += " " + f.Unit
		}
		return t
	case "table":
		var out []string
		if arr, ok := v.([]any); ok {
			for _, e := range arr {
				m, _ := e.(map[string]any)
				var cells []string
				for i := range f.Columns {
					c := &f.Columns[i]
					if t := reqFormatValue(c, m[c.Key]); t != "" {
						cells = append(cells, c.Label+": "+t)
					}
				}
				out = append(out, strings.Join(cells, ", "))
			}
		}
		return strings.Join(out, "; ")
	}
	return reqValKey(v)
}

func reqCollectFiles(sc *reqSchema, data map[string]any) map[int64]string {
	out := map[int64]string{}
	for _, f := range sc.fields() {
		if f.Type != "file" {
			continue
		}
		if arr, ok := data[f.Key].([]any); ok {
			for _, e := range arr {
				if id := reqRefID(e); id > 0 {
					out[id] = f.Key
				}
			}
		}
	}
	return out
}

func reqSearchText(number, title, author string) string {
	return strings.ToLower(number + " " + title + " " + author)
}

func (s *Server) reqCreate(c *Ctx) error {
	var in reqSaveIn
	if err := c.Decode(&in); err != nil {
		return err
	}
	ctx := c.Context()
	u := c.U
	if in.ClientID != "" {
		if len(in.ClientID) > 64 {
			return badReq("Некорректный идентификатор запроса")
		}
		if b, ok := s.reqExisting(ctx, u.ID, in.ClientID); ok {
			return c.Raw(200, b)
		}
	}
	if !s.rateOK(ctx, fmt.Sprintf("rcreate:%d", u.ID), 60, time.Minute) {
		return &apiError{429, "Слишком много заявок. Подождите немного"}
	}
	can, err := s.reqCanSubmit(ctx, u, in.TypeID)
	if err != nil {
		return err
	}
	if !can {
		return &apiError{403, "Этот тип заявки вам недоступен"}
	}
	var verID int64
	var schemaRaw string
	var tname string
	if err := s.db.QueryRow(ctx, `SELECT v.id, v.schema::text, t.name FROM req_types t JOIN req_type_versions v ON v.id = t.cur_version WHERE t.id = $1`, in.TypeID).Scan(&verID, &schemaRaw, &tname); err != nil {
		return err
	}
	sc, err := parseSchema([]byte(schemaRaw))
	if err != nil {
		return err
	}
	if in.Data == nil {
		in.Data = map[string]any{}
	}
	data, _, errs, err := s.validateReqData(ctx, sc, in.Data, u.ID, nil, !in.Submit)
	if err != nil {
		return err
	}
	if len(errs) > 0 {
		return reqFieldErr(c, errs)
	}
	db, _ := json.Marshal(data)
	title := reqSummary(tname, sc, data)
	var rid int64
	o := (*reqOut)(nil)
	var cid any
	if in.ClientID != "" {
		cid = in.ClientID
	}
	err = s.tx(ctx, func(tx pgx.Tx) error {
		var dept any
		if u.Dept > 0 {
			dept = u.Dept
		}
		if err := tx.QueryRow(ctx, `INSERT INTO req_requests (type_id, version_id, client_id, author_id, dept_id, status, title, data)
			VALUES ($1, $2, $3, $4, $5, 'draft', $6, $7::jsonb) RETURNING id`, in.TypeID, verID, cid, u.ID, dept, title, string(db)).Scan(&rid); err != nil {
			return err
		}
		if err := s.reqSyncFiles(ctx, tx, rid, sc, data); err != nil {
			return err
		}
		if _, err := s.reqEvent(ctx, tx, rid, 0, u.ID, "created", "Создан черновик", nil); err != nil {
			return err
		}
		if in.Submit {
			r, err := s.reqLoad(ctx, tx, rid, true)
			if err != nil {
				return err
			}
			o = newReqOut(rid)
			return s.reqSubmit(ctx, tx, r, o)
		}
		return nil
	})
	var pe *pgconn.PgError
	if errors.As(err, &pe) && pe.Code == "23505" && in.ClientID != "" { // параллельный повтор того же запроса
		if b, ok := s.reqExisting(ctx, u.ID, in.ClientID); ok {
			return c.Raw(200, b)
		}
	}
	if err != nil {
		return err
	}
	if o != nil {
		s.reqFlush(ctx, o)
	}
	b, _ := s.one(ctx, `SELECT id, coalesce(number, '') AS number, status FROM req_requests WHERE id = $1`, rid)
	return c.Raw(201, b)
}

func (s *Server) reqExisting(ctx context.Context, uid int64, cid string) (json.RawMessage, bool) {
	b, err := s.one(ctx, `SELECT id, coalesce(number, '') AS number, status, true AS duplicate FROM req_requests WHERE author_id = $1 AND client_id = $2`, uid, cid)
	return b, err == nil
}

// reqSyncFiles приводит привязки файлов полей формы в соответствие с данными.
func (s *Server) reqSyncFiles(ctx context.Context, tx pgx.Tx, rid int64, sc *reqSchema, data map[string]any) error {
	files := reqCollectFiles(sc, data)
	ids := make([]int64, 0, len(files))
	for id := range files {
		ids = append(ids, id)
	}
	if _, err := tx.Exec(ctx, `DELETE FROM req_files WHERE request_id = $1 AND event_id IS NULL AND NOT (file_id = ANY($2::bigint[]))`, rid, ids); err != nil {
		return err
	}
	for id, key := range files {
		if _, err := tx.Exec(ctx, `INSERT INTO req_files (file_id, request_id, field_key) VALUES ($1, $2, $3) ON CONFLICT (file_id) DO NOTHING`, id, rid, key); err != nil {
			return err
		}
	}
	return nil
}

// reqSubmit: нумерация и запуск маршрута для черновика.
func (s *Server) reqSubmit(ctx context.Context, tx pgx.Tx, r *reqState, o *reqOut) error {
	if r.Number == "" {
		n, err := s.reqNextNumber(ctx, tx, r.TypeID, r.Mask, r.TypeCode, time.Now())
		if err != nil {
			return err
		}
		r.Number = n
	}
	if _, err := tx.Exec(ctx, `UPDATE req_requests SET number = $2, status = 'pending', submitted_at = coalesce(submitted_at, now()), search_text = $3, updated_at = now() WHERE id = $1`,
		r.ID, r.Number, reqSearchText(r.Number, r.Title, r.AuthorName)); err != nil {
		return err
	}
	if _, err := s.reqEvent(ctx, tx, r.ID, 0, r.AuthorID, "submitted", "Заявка подана", nil); err != nil {
		return err
	}
	o.touchUsers(r.AuthorID)
	return s.reqRoute(ctx, tx, r, 0, o)
}

func (s *Server) reqUpdate(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in reqSaveIn
	if err := c.Decode(&in); err != nil {
		return err
	}
	ctx := c.Context()
	if in.Data == nil {
		in.Data = map[string]any{}
	}
	var out *reqOut
	var fieldErrs reqFieldErrors
	err = s.tx(ctx, func(tx pgx.Tx) error {
		r, err := s.reqLoad(ctx, tx, id, true)
		if err != nil {
			return err
		}
		if r.AuthorID != c.U.ID {
			return errNotFound
		}
		if r.Status != "draft" && r.Status != "rework" {
			return conflict("Заявку можно править только в статусе «Черновик» или «На доработке»")
		}
		existing := map[int64]bool{}
		rows, err := tx.Query(ctx, `SELECT file_id FROM req_files WHERE request_id = $1`, id)
		ids, err := reqScanIDs(rows, err)
		if err != nil {
			return err
		}
		for _, f := range ids {
			existing[f] = true
		}
		data, _, errs, err := s.validateReqData(ctx, r.Schema, in.Data, c.U.ID, existing, !in.Submit)
		if err != nil {
			return err
		}
		if len(errs) > 0 {
			fieldErrs = errs
			return nil
		}
		db, _ := json.Marshal(data)
		r.Data = data
		r.Title = reqSummary(r.TypeName, r.Schema, data)
		if _, err := tx.Exec(ctx, `UPDATE req_requests SET data = $2::jsonb, title = $3, updated_at = now() WHERE id = $1`, id, string(db), r.Title); err != nil {
			return err
		}
		if err := s.reqSyncFiles(ctx, tx, id, r.Schema, data); err != nil {
			return err
		}
		out = newReqOut(id)
		switch {
		case in.Submit && r.Status == "draft":
			return s.reqSubmit(ctx, tx, r, out)
		case in.Submit && r.Status == "rework":
			if _, err := s.reqEvent(ctx, tx, id, 0, c.U.ID, "resubmitted", "Заявка доработана и отправлена повторно", nil); err != nil {
				return err
			}
			if _, err := tx.Exec(ctx, `UPDATE req_requests SET search_text = $2 WHERE id = $1`, id, reqSearchText(r.Number, r.Title, r.AuthorName)); err != nil {
				return err
			}
			out.touchUsers(r.AuthorID)
			return s.reqRestart(ctx, tx, r, out)
		}
		_, err = s.reqEvent(ctx, tx, id, 0, c.U.ID, "edited", "Данные изменены", nil)
		return err
	})
	if err != nil {
		return err
	}
	if fieldErrs != nil {
		return reqFieldErr(c, fieldErrs)
	}
	s.reqFlush(ctx, out)
	b, _ := s.one(ctx, `SELECT id, coalesce(number, '') AS number, status FROM req_requests WHERE id = $1`, id)
	return c.Raw(200, b)
}

func (s *Server) reqDeleteDraft(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	tag, err := s.db.Exec(c.Context(), `DELETE FROM req_requests WHERE id = $1 AND author_id = $2 AND status = 'draft'`, id, c.U.ID)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return conflict("Удалить можно только свой черновик")
	}
	return c.OK()
}

// ---------------------------------------------------------------- действия

func (s *Server) reqActionH(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in reqActIn
	if err := c.Decode(&in); err != nil {
		return err
	}
	ctx := c.Context()
	var out *reqOut
	err = s.tx(ctx, func(tx pgx.Tx) error {
		var visible bool
		if err := tx.QueryRow(ctx, `SELECT req_can_view($1, $2, $3)`, id, c.U.ID, c.U.IsAdmin()).Scan(&visible); err != nil {
			return err
		}
		if !visible {
			return errNotFound
		}
		r, err := s.reqLoad(ctx, tx, id, true)
		if err != nil {
			return err
		}
		out = newReqOut(id)
		return s.reqDispatch(ctx, tx, r, c.U, &in, out)
	})
	if err != nil {
		return err
	}
	s.reqFlush(ctx, out)
	return c.OK()
}

func (s *Server) reqDispatch(ctx context.Context, tx pgx.Tx, r *reqState, u *User, in *reqActIn, o *reqOut) error {
	switch in.Action {
	case "cancel":
		if r.AuthorID != u.ID {
			return errForbidden
		}
		if r.Decisions > 0 || (r.Status != "pending" && r.Status != "in_progress" && r.Status != "rework") {
			return conflict("Отменить заявку можно только до первого решения")
		}
		var pending []int64
		rows, err := tx.Query(ctx, `SELECT user_id FROM req_assignees WHERE request_id = $1 AND state = 'pending'`, r.ID)
		if pending, err = reqScanIDs(rows, err); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE req_assignees SET state = 'skipped' WHERE request_id = $1 AND state = 'pending'`, r.ID); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE req_steps SET state = 'skipped', finished_at = now() WHERE request_id = $1 AND state = 'active'`, r.ID); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE req_requests SET status = 'cancelled', due_at = NULL, closed_at = now(), info_by = NULL, updated_at = now() WHERE id = $1`, r.ID); err != nil {
			return err
		}
		if _, err := s.reqEvent(ctx, tx, r.ID, 0, u.ID, "cancelled", strings.TrimSpace(in.Comment), map[string]any{"status": "cancelled"}); err != nil {
			return err
		}
		o.note(pending, "Заявка "+r.label()+": отозвана заявителем", r.summary(), reqLink(r.ID, 0))
		o.touchUsers(u.ID)
		return nil
	case "assign":
		if !s.reqIsManagerOf(ctx, u, r.TypeID) {
			return errForbidden
		}
		if r.Status != "pending" && r.Status != "in_progress" {
			return conflict("Заявка уже не на согласовании")
		}
		if in.To <= 0 {
			return badReq("Выберите сотрудника")
		}
		var stepID int64
		var kind string
		err := tx.QueryRow(ctx, `SELECT id, kind FROM req_steps WHERE request_id = $1 AND state = 'active' ORDER BY id DESC LIMIT 1`, r.ID).Scan(&stepID, &kind)
		if err == pgx.ErrNoRows {
			return conflict("Нет активного шага")
		}
		if err != nil {
			return err
		}
		var okU bool
		if err := tx.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM users WHERE id = $1 AND NOT blocked)`, in.To).Scan(&okU); err != nil || !okU {
			return badReq("Сотрудник не найден")
		}
		tag, err := tx.Exec(ctx, `INSERT INTO req_assignees (request_id, step_id, branch, mode, user_id, via, orig_user_id, due_at, remind_at, esc_to)
			SELECT $1, $2, coalesce((SELECT min(branch) FROM req_assignees WHERE step_id = $2), 0), 'any', $3, 'assigned', $4,
				(SELECT due_at FROM req_assignees WHERE step_id = $2 ORDER BY id LIMIT 1), NULL, NULL
			ON CONFLICT (step_id, user_id) DO UPDATE SET state = 'pending', via = 'assigned' WHERE req_assignees.state <> 'pending'`, r.ID, stepID, in.To, u.ID)
		if err != nil {
			return err
		}
		if tag.RowsAffected() == 0 {
			return conflict("Сотрудник уже участвует в шаге")
		}
		// назначенный вручную исполнитель решает за шаг («достаточно одного»), если шаг был без исполнителей
		if _, err := tx.Exec(ctx, `UPDATE req_assignees SET mode = 'any' WHERE step_id = $1 AND user_id = $2`, stepID, in.To); err != nil {
			return err
		}
		name := s.userName(ctx, tx, in.To)
		if _, err := s.reqEvent(ctx, tx, r.ID, stepID, u.ID, "assigned", "Назначен исполнитель: "+name, map[string]any{"user": in.To}); err != nil {
			return err
		}
		o.note([]int64{in.To}, "Заявка "+r.label()+": "+reqKindVerb(kind), r.TypeName+" — "+r.AuthorName, reqLink(r.ID, stepID))
		o.touchUsers(u.ID, r.AuthorID)
		return nil
	}
	return s.reqAct(ctx, tx, r, u.ID, in, o)
}

func (s *Server) reqComment(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Text  string  `json:"text"`
		Files []int64 `json:"files"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Text = strings.TrimSpace(in.Text)
	if (in.Text == "" && len(in.Files) == 0) || reqRuneLen(in.Text) > 5000 {
		return badReq("Введите текст комментария (до 5000 символов)")
	}
	ctx := c.Context()
	if !s.rateOK(ctx, fmt.Sprintf("rcomm:%d", c.U.ID), 30, time.Minute) {
		return &apiError{429, "Слишком много сообщений. Подождите немного"}
	}
	var out *reqOut
	err = s.tx(ctx, func(tx pgx.Tx) error {
		var visible bool
		if err := tx.QueryRow(ctx, `SELECT req_can_view($1, $2, $3)`, id, c.U.ID, c.U.IsAdmin()).Scan(&visible); err != nil {
			return err
		}
		if !visible {
			return errNotFound
		}
		r, err := s.reqLoad(ctx, tx, id, true)
		if err != nil {
			return err
		}
		if r.Status == "draft" {
			return conflict("Комментарии доступны после подачи заявки")
		}
		kind := "comment"
		out = newReqOut(id)
		var recipients []int64
		if r.AuthorID == c.U.ID && r.InfoBy != nil {
			kind = "answer"
			recipients = append(recipients, *r.InfoBy)
			if _, err := tx.Exec(ctx, `UPDATE req_requests SET info_by = NULL, updated_at = now() WHERE id = $1`, id); err != nil {
				return err
			}
		}
		eid, err := s.reqEvent(ctx, tx, id, 0, c.U.ID, kind, in.Text, nil)
		if err != nil {
			return err
		}
		if err := s.reqLinkFiles(ctx, tx, id, eid, c.U.ID, in.Files); err != nil {
			return err
		}
		if r.AuthorID != c.U.ID {
			recipients = append(recipients, r.AuthorID)
		}
		rows, err := tx.Query(ctx, `SELECT DISTINCT user_id FROM req_assignees WHERE request_id = $1 AND state = 'pending'`, id)
		pend, err := reqScanIDs(rows, err)
		if err != nil {
			return err
		}
		recipients = append(recipients, pend...)
		var rec []int64
		for _, x := range reqUniqueIDs(recipients) {
			if x != c.U.ID {
				rec = append(rec, x)
			}
		}
		title := "Заявка " + r.label() + ": новый комментарий"
		if kind == "answer" {
			title = "Заявка " + r.label() + ": заявитель ответил на вопрос"
		}
		out.note(rec, title, c.U.Name+": "+reqClip(in.Text, 200), reqLink(id, 0))
		out.touchUsers(c.U.ID)
		return nil
	})
	if err != nil {
		return err
	}
	s.reqFlush(ctx, out)
	return c.OK()
}

func reqClip(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	return string(r[:n]) + "…"
}

// reqBulk — массовые действия исполнителя (согласовать / исполнить / ознакомиться) над несколькими заявками «На мне».
func (s *Server) reqBulk(c *Ctx) error {
	var in struct {
		IDs     []int64 `json:"ids"`
		Action  string  `json:"action"`
		Comment string  `json:"comment"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if len(in.IDs) == 0 || len(in.IDs) > 100 {
		return badReq("Выберите от 1 до 100 заявок")
	}
	switch in.Action {
	case "approve", "execute", "ack":
	default:
		return badReq("Массово можно согласовать, исполнить или отметить ознакомление")
	}
	ctx := c.Context()
	type res struct {
		ID    int64  `json:"id"`
		OK    bool   `json:"ok"`
		Error string `json:"error,omitempty"`
	}
	results := []res{}
	for _, id := range reqUniqueIDs(in.IDs) {
		var out *reqOut
		err := s.tx(ctx, func(tx pgx.Tx) error {
			r, err := s.reqLoad(ctx, tx, id, true)
			if err != nil {
				return errNotFound
			}
			out = newReqOut(id)
			a := reqActIn{Action: in.Action, Comment: in.Comment}
			return s.reqAct(ctx, tx, r, c.U.ID, &a, out)
		})
		if err != nil {
			var ae *apiError
			msg := "Ошибка"
			if errors.As(err, &ae) {
				msg = ae.Msg
			}
			results = append(results, res{ID: id, Error: msg})
			continue
		}
		s.reqFlush(ctx, out)
		results = append(results, res{ID: id, OK: true})
	}
	return c.JSON(200, map[string]any{"results": results})
}

// ---------------------------------------------------------------- списки

const reqListCols = `r.id, coalesce(r.number, '') AS number, r.title, r.status, r.type_id, t.name AS type_name, t.icon AS type_icon, t.color AS type_color,
	r.author_id, u.full_name AS author, r.created_at, r.submitted_at, r.updated_at, r.due_at, r.info_by IS NOT NULL AS info_asked,
	(SELECT st.name FROM req_steps st WHERE st.request_id = r.id AND st.state = 'active' ORDER BY st.id DESC LIMIT 1) AS step_name,
	(SELECT coalesce(json_agg(x.name), '[]'::json) FROM (SELECT uu.full_name AS name FROM req_assignees a JOIN users uu ON uu.id = a.user_id
		WHERE a.request_id = r.id AND a.state = 'pending' ORDER BY a.id LIMIT 3) x) AS waiting`

type reqListQ struct {
	where string
	args  []any
	join  string
	order string
	extra string
}

// reqBuild собирает условие списка. Права: каждая область ограничена по пользователю на уровне SQL.
func (s *Server) reqBuild(c *Ctx, scopeName string) (*reqListQ, error) {
	ctx := c.Context()
	u := c.U
	w := &whereBuilder{}
	q := &reqListQ{order: "r.created_at DESC, r.id DESC"}
	switch scopeName {
	case "", "mine":
		w.add("r.author_id = ?", u.ID)
	case "inbox":
		q.join = ` JOIN req_assignees a ON a.request_id = r.id AND a.user_id = ` + strconv.FormatInt(u.ID, 10) + ` AND a.state = 'pending'`
		q.order = "a.due_at NULLS LAST, r.id"
		q.extra = ", a.due_at AS my_due_at, (a.due_at IS NOT NULL AND a.due_at < now()) AS overdue, a.step_id AS my_step_id, (SELECT st.kind FROM req_steps st WHERE st.id = a.step_id) AS my_kind"
	case "participated":
		w.add("r.status <> 'draft' AND EXISTS (SELECT 1 FROM req_assignees a WHERE a.request_id = r.id AND a.user_id = ?)", u.ID)
	case "type":
		ids, all, err := s.reqViewTypes(ctx, u)
		if err != nil {
			return nil, err
		}
		w.raw("r.status <> 'draft'")
		if tid := c.QInt64("type_id"); tid > 0 {
			if !all {
				ok := false
				for _, id := range ids {
					ok = ok || id == tid
				}
				if !ok {
					return nil, errForbidden
				}
			}
			w.add("r.type_id = ?", tid)
		} else if !all {
			w.add("r.type_id = ANY(?::bigint[])", ids)
		}
		if a := c.QInt64("author"); a > 0 {
			w.add("r.author_id = ?", a)
		}
	default:
		return nil, badReq("Неизвестный список")
	}
	if tid := c.QInt64("type_id"); tid > 0 && scopeName != "type" {
		w.add("r.type_id = ?", tid)
	}
	if st := c.Q("status"); st != "" {
		var list []string
		for _, x := range strings.Split(st, ",") {
			switch x = strings.TrimSpace(x); x {
			case "draft", "pending", "rework", "rejected", "approved", "in_progress", "done", "cancelled":
				list = append(list, x)
			}
		}
		if len(list) > 0 {
			w.add("r.status = ANY(?::text[])", list)
		}
	}
	if d := c.Q("from"); d != "" {
		if _, err := time.Parse("2006-01-02", d); err == nil {
			w.add("r.created_at >= ?::date", d)
		}
	}
	if d := c.Q("to"); d != "" {
		if _, err := time.Parse("2006-01-02", d); err == nil {
			w.add("r.created_at < (?::date + 1)", d)
		}
	}
	if scopeName == "inbox" {
		var kinds []string
		for _, k := range strings.Split(c.Q("kind"), ",") {
			if k = strings.TrimSpace(k); k == "approve" || k == "execute" || k == "inform" {
				kinds = append(kinds, k)
			}
		}
		if len(kinds) > 0 {
			w.add("EXISTS (SELECT 1 FROM req_steps st WHERE st.id = a.step_id AND st.kind = ANY(?::text[]))", kinds)
		}
	}
	if scopeName == "inbox" && c.Q("overdue") == "1" {
		w.raw("a.due_at < now()")
	}
	for _, t := range searchTokens(c.Q("q")) {
		w.add(`r.search_text LIKE ? ESCAPE '\'`, "%"+likeEscape(t)+"%")
	}
	q.where, q.args = w.String(), w.args
	return q, nil
}

func (s *Server) reqList(c *Ctx) error {
	ctx := c.Context()
	scopeName := c.Q("scope")
	q, err := s.reqBuild(c, scopeName)
	if err != nil {
		return err
	}
	page, per, off := c.Page(20, 100)
	const capN = 10000
	var total int
	if err := s.db.QueryRow(ctx, `SELECT count(*) FROM (SELECT 1 FROM req_requests r`+q.join+` WHERE `+q.where+` LIMIT `+strconv.Itoa(capN+1)+`) x`, q.args...).Scan(&total); err != nil {
		return err
	}
	n := len(q.args)
	items, err := s.arr(ctx, `SELECT `+reqListCols+q.extra+` FROM req_requests r JOIN req_types t ON t.id = r.type_id LEFT JOIN users u ON u.id = r.author_id`+q.join+
		` WHERE `+q.where+` ORDER BY `+q.order+fmt.Sprintf(` LIMIT $%d OFFSET $%d`, n+1, n+2), append(q.args, per, off)...)
	if err != nil {
		return err
	}
	capped := total > capN
	if capped {
		total = capN
	}
	return c.Raw(200, []byte(fmt.Sprintf(`{"items":%s,"total":%d,"capped":%t,"page":%d,"per":%d}`, items, total, capped, page, per)))
}

// ---------------------------------------------------------------- CSV

func reqCSVCell(s string) string {
	if s != "" && strings.ContainsRune("=+-@\t\r", rune(s[0])) {
		return "'" + s
	}
	return s
}

func (s *Server) reqExportCSV(c *Ctx) error {
	ctx := c.Context()
	tid := c.QInt64("type_id")
	if tid <= 0 {
		return badReq("Выберите тип заявки для выгрузки")
	}
	q, err := s.reqBuild(c, "type") // проверяет, что пользователь ответственный/наблюдатель типа или админ
	if err != nil {
		return err
	}
	var name, schemaRaw string
	if err := s.db.QueryRow(ctx, `SELECT t.name, v.schema::text FROM req_types t JOIN req_type_versions v ON v.id = t.cur_version WHERE t.id = $1`, tid).Scan(&name, &schemaRaw); err != nil {
		return err
	}
	sc, err := parseSchema([]byte(schemaRaw))
	if err != nil {
		return err
	}
	var flds []*reqField
	for _, f := range sc.fields() {
		if !f.isDisplay() {
			flds = append(flds, f)
		}
	}
	n := len(q.args)
	rows, err := s.db.Query(ctx, `SELECT coalesce(r.number, ''), r.status, coalesce(u.full_name, ''), coalesce(d.name, ''), r.created_at, r.submitted_at, r.closed_at, r.due_at,
			coalesce((SELECT st.name FROM req_steps st WHERE st.request_id = r.id AND st.state = 'active' ORDER BY st.id DESC LIMIT 1), ''),
			coalesce((SELECT string_agg(uu.full_name, ', ') FROM req_assignees a JOIN users uu ON uu.id = a.user_id WHERE a.request_id = r.id AND a.state = 'pending'), ''),
			r.data::text
		FROM req_requests r LEFT JOIN users u ON u.id = r.author_id LEFT JOIN departments d ON d.id = r.dept_id
		WHERE `+q.where+` ORDER BY r.created_at DESC, r.id DESC LIMIT `+fmt.Sprintf("%d", 50000), q.args[:n]...)
	if err != nil {
		return err
	}
	defer rows.Close()
	h := c.W.Header()
	h.Set("Content-Type", "text/csv; charset=utf-8")
	h.Set("Content-Disposition", "attachment; filename*=UTF-8''"+reqURLEsc("Заявки - "+name+".csv"))
	c.W.WriteHeader(200)
	c.W.Write([]byte("\xEF\xBB\xBF"))
	w := csv.NewWriter(c.W)
	w.Comma = ';'
	head := []string{"Номер", "Статус", "Заявитель", "Подразделение", "Создана", "Подана", "Закрыта", "Срок", "Текущий шаг", "Ожидают"}
	for _, f := range flds {
		head = append(head, f.Label)
	}
	w.Write(head)
	ft := func(t *time.Time) string {
		if t == nil {
			return ""
		}
		return t.In(s.reqLoc()).Format("02.01.2006 15:04")
	}
	for rows.Next() {
		var num, st, au, dp, step, wait, data string
		var cr time.Time
		var sub, clo, due *time.Time
		if err := rows.Scan(&num, &st, &au, &dp, &cr, &sub, &clo, &due, &step, &wait, &data); err != nil {
			break
		}
		m := map[string]any{}
		_ = json.Unmarshal([]byte(data), &m)
		rec := []string{num, reqStatusRu[st], au, dp, ft(&cr), ft(sub), ft(clo), ft(due), step, wait}
		for _, f := range flds {
			rec = append(rec, reqFormatValue(f, m[f.Key]))
		}
		for i := range rec {
			rec[i] = reqCSVCell(rec[i])
		}
		w.Write(rec)
	}
	w.Flush()
	return nil
}

var reqStatusRu = map[string]string{"draft": "Черновик", "pending": "На согласовании", "rework": "На доработке", "rejected": "Отклонена", "approved": "Согласована",
	"in_progress": "В работе", "done": "Выполнена", "cancelled": "Отменена"}

func reqURLEsc(s string) string {
	var b strings.Builder
	for _, c := range []byte(s) {
		if (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' {
			b.WriteByte(c)
		} else {
			fmt.Fprintf(&b, "%%%02X", c)
		}
	}
	return b.String()
}

// ---------------------------------------------------------------- карточка

func reqDescribe(a reqAssignee) string {
	switch a.T {
	case "manager":
		return "Непосредственный руководитель"
	case "manager_up":
		return fmt.Sprintf("Руководитель на %d ур. выше", max(a.N, 1))
	case "dept_head":
		return "Руководитель: " + reqFirst(a.Name, "подразделения")
	case "responsible":
		return "Ответственные за заявку"
	case "group":
		return "Группа: " + reqFirst(a.Name, "#"+strconv.FormatInt(a.ID, 10))
	case "dept":
		return "Подразделение: " + reqFirst(a.Name, "#"+strconv.FormatInt(a.ID, 10))
	case "field":
		return "Из заявки: " + a.Key
	}
	return reqFirst(a.Name, "Сотрудник #"+strconv.FormatInt(a.ID, 10))
}

func (s *Server) reqGet(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	u := c.U
	var visible bool
	if err := s.db.QueryRow(ctx, `SELECT req_can_view($1, $2, $3)`, id, u.ID, u.IsAdmin()).Scan(&visible); err != nil {
		return err
	}
	if !visible {
		return errNotFound
	}
	tx, err := s.db.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	r, err := s.reqLoad(ctx, tx, id, false)
	if err != nil {
		return err
	}
	head, err := s.one(ctx, `SELECT r.id, coalesce(r.number, '') AS number, r.title, r.status, r.type_id, r.version_id, v.version, r.author_id, r.dept_id, d.name AS department,
			u.full_name AS author, u.job_title AS author_title, u.avatar AS author_avatar, u.phone1 AS author_phone, u.email AS author_email,
			r.round, r.decisions, r.info_by, ib.full_name AS info_by_name, r.due_at, r.created_at, r.submitted_at, r.updated_at, r.closed_at,
			t.name AS type_name, t.icon AS type_icon, t.color AS type_color, t.description AS type_description
		FROM req_requests r JOIN req_types t ON t.id = r.type_id JOIN req_type_versions v ON v.id = r.version_id
		LEFT JOIN users u ON u.id = r.author_id LEFT JOIN departments d ON d.id = r.dept_id LEFT JOIN users ib ON ib.id = r.info_by WHERE r.id = $1`, id)
	if err != nil {
		return err
	}
	steps, err := s.arr(ctx, `SELECT id, idx, round, key, name, kind, state, started_at, finished_at FROM req_steps WHERE request_id = $1 ORDER BY id`, id)
	if err != nil {
		return err
	}
	asg, err := s.arr(ctx, `SELECT a.id, a.step_id, a.branch, a.mode, a.user_id, u.full_name AS name, u.job_title, u.avatar, a.state, a.via, a.orig_user_id,
			ou.full_name AS orig_name, a.due_at, a.decided_at, a.comment, (a.state = 'pending' AND a.due_at < now()) AS overdue
		FROM req_assignees a JOIN users u ON u.id = a.user_id LEFT JOIN users ou ON ou.id = a.orig_user_id WHERE a.request_id = $1 ORDER BY a.step_id, a.branch, a.id`, id)
	if err != nil {
		return err
	}
	events, err := s.arr(ctx, `SELECT e.id, e.step_id, e.actor_id, u.full_name AS actor, u.avatar AS actor_avatar, e.kind, e.text, e.data, e.created_at,
			(SELECT coalesce(json_agg(json_build_object('id', f.id, 'name', f.name, 'mime', f.mime, 'size', f.size) ORDER BY f.id), '[]'::json)
				FROM req_files rf JOIN files f ON f.id = rf.file_id WHERE rf.event_id = e.id) AS files
		FROM req_events e LEFT JOIN users u ON u.id = e.actor_id WHERE e.request_id = $1 ORDER BY e.id LIMIT 1000`, id)
	if err != nil {
		return err
	}
	// маршрут целиком: фактические шаги текущего круга + запланированные по условиям
	type routeStep struct {
		Idx     int      `json:"idx"`
		ID      string   `json:"id"`
		Name    string   `json:"name"`
		Kind    string   `json:"kind"`
		Applies bool     `json:"applies"`
		Who     []string `json:"who"`
		Mode    string   `json:"mode,omitempty"`
		SLA     string   `json:"sla,omitempty"`
		Cond    bool     `json:"cond"`
	}
	route := []routeStep{}
	for i, st := range r.WF.Steps {
		rs := routeStep{Idx: i, ID: st.ID, Name: st.Name, Kind: st.Kind, Applies: st.Cond.eval(r.Data), Cond: st.Cond != nil && len(st.Cond.Items) > 0, Who: []string{}}
		for _, b := range st.Branches {
			if rs.Mode == "" {
				rs.Mode = b.Mode
			}
			for _, a := range b.Assignees {
				rs.Who = append(rs.Who, reqDescribe(a))
			}
		}
		if st.SLA != nil {
			rs.SLA = fmt.Sprintf("%d %s", st.SLA.Value, st.SLA.Unit)
		}
		route = append(route, rs)
	}
	// действия, доступные мне
	can := map[string]any{}
	isAuthor := r.AuthorID == u.ID
	can["edit"] = isAuthor && (r.Status == "draft" || r.Status == "rework")
	can["cancel"] = isAuthor && r.Decisions == 0 && (r.Status == "pending" || r.Status == "in_progress" || r.Status == "rework")
	can["delete"] = isAuthor && r.Status == "draft"
	can["comment"] = r.Status != "draft"
	can["answer"] = isAuthor && r.InfoBy != nil
	var myStep int64
	var myKind string
	if err := s.db.QueryRow(ctx, `SELECT a.step_id, s.kind FROM req_assignees a JOIN req_steps s ON s.id = a.step_id
		WHERE a.request_id = $1 AND a.user_id = $2 AND a.state = 'pending' AND s.state = 'active' ORDER BY a.id LIMIT 1`, id, u.ID).Scan(&myStep, &myKind); err == nil {
		acts := []string{}
		for _, a := range []string{"approve", "execute", "ack", "reject", "return", "ask", "delegate"} {
			if reqActionsByKind[myKind][a] {
				acts = append(acts, a)
			}
		}
		can["my_actions"] = acts
		can["my_step"] = myStep
		can["my_kind"] = myKind
	}
	can["assign"] = (r.Status == "pending" || r.Status == "in_progress") && s.reqIsManagerOf(ctx, u, r.TypeID)
	viewAll := false
	if ids, all, err := s.reqViewTypes(ctx, u); err == nil {
		viewAll = all
		for _, t := range ids {
			viewAll = viewAll || t == r.TypeID
		}
	}
	can["view_all"] = viewAll
	return c.JSON(200, map[string]any{"request": json.RawMessage(head), "data": r.Data, "schema": r.Schema, "route": route, "steps": steps,
		"assignees": asg, "events": events, "can": can, "cur_step": r.CurStep, "round": r.Round})
}
