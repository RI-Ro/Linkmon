package server

import (
	"bufio"
	"encoding/binary"
	"image"
	"image/color"
	"image/jpeg"
	"io"
	"os"
	"path/filepath"
)

// Размеры изображений (требование заказчика):
//   - оригинал — для скачивания, без изменений;
//   - «просмотр» <имя>.v.jpg — ширина 90% от Full HD (1728 px), для просмотра в браузере;
//   - «превью» <имя>.t.jpg — ширина 320 px;
//   - аватар: оригинал + квадратное превью 160x160 (<имя>.t.jpg), без .v.jpg.
const (
	viewWidth     = 1728
	thumbWidth    = 320
	avatarSize    = 160
	viewQuality   = 82
	thumbQuality  = 78
	maxDecodeMpix = 60_000_000
)

type variants struct {
	Thumb, View string // имена файлов рядом с оригиналом ("" — варианта нет, используется оригинал)
	W, H        int    // размеры оригинала с учётом EXIF-ориентации (как его показывает браузер)
}

// ---------------------------------------------------------------- метаданные

// jpegOrientation читает EXIF Orientation (1..8) из начала JPEG; 1, если тега нет.
func jpegOrientation(f io.ReadSeeker) int {
	f.Seek(0, io.SeekStart)
	br := bufio.NewReaderSize(f, 64<<10)
	var soi [2]byte
	if _, err := io.ReadFull(br, soi[:]); err != nil || soi[0] != 0xFF || soi[1] != 0xD8 {
		return 1
	}
	for i := 0; i < 32; i++ {
		c, err := br.ReadByte()
		if err != nil || c != 0xFF {
			return 1
		}
		marker, err := br.ReadByte()
		for err == nil && marker == 0xFF { // заполняющие байты
			marker, err = br.ReadByte()
		}
		if err != nil {
			return 1
		}
		if marker == 0xDA || marker == 0xD9 || marker == 0x01 || (marker >= 0xD0 && marker <= 0xD8) {
			if marker == 0xDA || marker == 0xD9 {
				return 1
			}
			continue // маркеры без длины
		}
		var lb [2]byte
		if _, err := io.ReadFull(br, lb[:]); err != nil {
			return 1
		}
		ln := int(binary.BigEndian.Uint16(lb[:])) - 2
		if ln < 0 {
			return 1
		}
		if marker != 0xE1 || ln < 14 || ln > 64<<10 {
			if _, err := br.Discard(ln); err != nil {
				return 1
			}
			continue
		}
		seg := make([]byte, ln)
		if _, err := io.ReadFull(br, seg); err != nil {
			return 1
		}
		if string(seg[:6]) != "Exif\x00\x00" {
			continue
		}
		t := seg[6:]
		var bo binary.ByteOrder = binary.BigEndian
		switch string(t[:2]) {
		case "II":
			bo = binary.LittleEndian
		case "MM":
		default:
			return 1
		}
		off := int(bo.Uint32(t[4:8]))
		if off < 8 || off+2 > len(t) {
			return 1
		}
		n := int(bo.Uint16(t[off : off+2]))
		for k := 0; k < n; k++ {
			e := off + 2 + k*12
			if e+12 > len(t) {
				return 1
			}
			if bo.Uint16(t[e:e+2]) == 0x0112 {
				if v := int(bo.Uint16(t[e+8 : e+10])); v >= 1 && v <= 8 {
					return v
				}
				return 1
			}
		}
		return 1
	}
	return 1
}

// webpSize читает размеры из заголовка WebP (декодера в stdlib нет).
func webpSize(f io.ReadSeeker) (w, h int) {
	f.Seek(0, io.SeekStart)
	var b [32]byte
	if _, err := io.ReadFull(f, b[:]); err != nil || string(b[:4]) != "RIFF" || string(b[8:12]) != "WEBP" {
		return
	}
	switch string(b[12:16]) {
	case "VP8X":
		w = (int(b[24]) | int(b[25])<<8 | int(b[26])<<16) + 1
		h = (int(b[27]) | int(b[28])<<8 | int(b[29])<<16) + 1
	case "VP8L":
		if b[20] != 0x2f {
			return
		}
		v := binary.LittleEndian.Uint32(b[21:25])
		w, h = int(v&0x3fff)+1, int(v>>14&0x3fff)+1
	case "VP8 ":
		w, h = int(binary.LittleEndian.Uint16(b[26:28])&0x3fff), int(binary.LittleEndian.Uint16(b[28:30])&0x3fff)
	}
	return
}

// ---------------------------------------------------------------- построчное чтение пикселей

// rowReader заполняет dst (3 байта RGB на пиксель, прозрачность смешивается с белым) строкой y,
// начиная с колонки x0.
type rowReader func(y, x0, w int, dst []uint8)

func newRowReader(img image.Image) rowReader {
	b := img.Bounds()
	switch m := img.(type) {
	case *image.YCbCr:
		return func(y, x0, w int, dst []uint8) {
			yy := b.Min.Y + y
			for x := 0; x < w; x++ {
				xx := b.Min.X + x0 + x
				yi, ci := m.YOffset(xx, yy), m.COffset(xx, yy)
				r, g, bl := color.YCbCrToRGB(m.Y[yi], m.Cb[ci], m.Cr[ci])
				dst[3*x], dst[3*x+1], dst[3*x+2] = r, g, bl
			}
		}
	case *image.RGBA:
		return func(y, x0, w int, dst []uint8) {
			p := m.Pix[m.PixOffset(b.Min.X+x0, b.Min.Y+y):]
			for x := 0; x < w; x++ {
				a := p[4*x+3]
				k := 255 - a // премультиплицированный цвет поверх белого
				dst[3*x], dst[3*x+1], dst[3*x+2] = sat(p[4*x], k), sat(p[4*x+1], k), sat(p[4*x+2], k)
			}
		}
	case *image.NRGBA:
		return func(y, x0, w int, dst []uint8) {
			p := m.Pix[m.PixOffset(b.Min.X+x0, b.Min.Y+y):]
			for x := 0; x < w; x++ {
				a := uint32(p[4*x+3])
				for c := 0; c < 3; c++ {
					dst[3*x+c] = uint8((uint32(p[4*x+c])*a + 255*(255-a)) / 255)
				}
			}
		}
	case *image.Gray:
		return func(y, x0, w int, dst []uint8) {
			p := m.Pix[m.PixOffset(b.Min.X+x0, b.Min.Y+y):]
			for x := 0; x < w; x++ {
				dst[3*x], dst[3*x+1], dst[3*x+2] = p[x], p[x], p[x]
			}
		}
	}
	return func(y, x0, w int, dst []uint8) { // универсальный (палитровые GIF, 16-битные PNG и т. п.)
		for x := 0; x < w; x++ {
			r, g, bl, a := img.At(b.Min.X+x0+x, b.Min.Y+y).RGBA()
			k := 0xffff - a
			dst[3*x], dst[3*x+1], dst[3*x+2] = uint8((r+k)>>8), uint8((g+k)>>8), uint8((bl+k)>>8)
		}
	}
}

func sat(c, k uint8) uint8 {
	if v := int(c) + int(k); v < 255 {
		return uint8(v)
	}
	return 255
}

// ---------------------------------------------------------------- масштабирование «по площади»

// areaScaler уменьшает изображение, усредняя исходные пиксели с дробными весами (box-фильтр с точным покрытием:
// качественно для любых коэффициентов уменьшения, без алиасинга). Строки исходника подаются по порядку,
// поэтому один проход по оригиналу кормит сразу несколько получателей.
type areaScaler struct {
	sw, sh, ow, oh int
	xStart         []int
	xW             [][]float32
	acc            [2][]float32
	out            *image.RGBA
	next           int // следующая строка результата, которую нужно дописать
}

func newAreaScaler(sw, sh, ow, oh int) *areaScaler {
	a := &areaScaler{sw: sw, sh: sh, ow: ow, oh: oh, out: image.NewRGBA(image.Rect(0, 0, ow, oh))}
	a.xStart, a.xW = make([]int, ow), make([][]float32, ow)
	ratio := float64(sw) / float64(ow)
	for ox := 0; ox < ow; ox++ {
		lo, hi := float64(ox)*ratio, float64(ox+1)*ratio
		i0, i1 := int(lo), int(hi)
		if float64(i1) < hi {
			i1++
		}
		i1 = min(i1, sw)
		ws := make([]float32, 0, i1-i0)
		for i := i0; i < i1; i++ {
			ws = append(ws, float32((min(hi, float64(i+1))-max(lo, float64(i)))/ratio))
		}
		a.xStart[ox], a.xW[ox] = i0, ws
	}
	a.acc[0], a.acc[1] = make([]float32, ow*3), make([]float32, ow*3)
	return a
}

// feed принимает исходную строку sy (RGB, sw*3 байт).
func (a *areaScaler) feed(sy int, row []uint8, h []float32) {
	for ox := 0; ox < a.ow; ox++ {
		var r, g, b float32
		p := row[3*a.xStart[ox]:]
		for i, w := range a.xW[ox] {
			r += float32(p[3*i]) * w
			g += float32(p[3*i+1]) * w
			b += float32(p[3*i+2]) * w
		}
		h[3*ox], h[3*ox+1], h[3*ox+2] = r, g, b
	}
	ratio := float64(a.oh) / float64(a.sh)
	lo, hi := float64(sy)*ratio, float64(sy+1)*ratio
	for oy := int(lo); oy < a.oh && float64(oy) < hi; oy++ {
		w := float32(min(hi, float64(oy+1)) - max(lo, float64(oy)))
		acc := a.acc[oy&1]
		for i, v := range h[:3*a.ow] {
			acc[i] += v * w
		}
	}
	for a.next < a.oh && (hi >= float64(a.next+1)-1e-9 || sy == a.sh-1) {
		acc := a.acc[a.next&1]
		d := a.out.Pix[a.next*a.out.Stride:]
		for ox := 0; ox < a.ow; ox++ {
			for c := 0; c < 3; c++ {
				v := acc[3*ox+c] + 0.5
				if v > 255 {
					v = 255
				}
				d[4*ox+c] = uint8(v)
				acc[3*ox+c] = 0
			}
			d[4*ox+3] = 255
		}
		a.next++
	}
}

// scaleMany одним проходом по источнику (его область x0,y0,cw,ch) строит уменьшенные копии заданных размеров.
func scaleMany(rr rowReader, x0, y0, cw, ch int, sizes [][2]int) []*image.RGBA {
	sc := make([]*areaScaler, len(sizes))
	for i, s := range sizes {
		sc[i] = newAreaScaler(cw, ch, s[0], s[1])
	}
	row := make([]uint8, cw*3)
	hbuf := make([]float32, 3*cw)
	for y := 0; y < ch; y++ {
		rr(y0+y, x0, cw, row)
		for _, s := range sc {
			s.feed(y, row, hbuf)
		}
	}
	out := make([]*image.RGBA, len(sc))
	for i, s := range sc {
		out[i] = s.out
	}
	return out
}

// orient применяет EXIF-ориентацию (1..8) к готовому (маленькому) изображению.
func orient(src *image.RGBA, o int) *image.RGBA {
	if o <= 1 || o > 8 {
		return src
	}
	w, h := src.Bounds().Dx(), src.Bounds().Dy()
	dw, dh := w, h
	if o >= 5 {
		dw, dh = h, w
	}
	dst := image.NewRGBA(image.Rect(0, 0, dw, dh))
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			var nx, ny int
			switch o {
			case 2:
				nx, ny = w-1-x, y
			case 3:
				nx, ny = w-1-x, h-1-y
			case 4:
				nx, ny = x, h-1-y
			case 5:
				nx, ny = y, x
			case 6:
				nx, ny = h-1-y, x
			case 7:
				nx, ny = h-1-y, w-1-x
			case 8:
				nx, ny = y, w-1-x
			}
			copy(dst.Pix[ny*dst.Stride+4*nx:ny*dst.Stride+4*nx+4], src.Pix[y*src.Stride+4*x:y*src.Stride+4*x+4])
		}
	}
	return dst
}

func writeJPEG(p string, img image.Image, q int) error {
	f, err := os.Create(p)
	if err != nil {
		return err
	}
	if err := jpeg.Encode(f, img, &jpeg.Options{Quality: q}); err != nil {
		f.Close()
		os.Remove(p)
		return err
	}
	if err := f.Close(); err != nil {
		os.Remove(p)
		return err
	}
	return nil
}

// ---------------------------------------------------------------- вариант за вариантом

// makeVariants читает оригинал p один раз и пишет рядом <имя>.v.jpg и <имя>.t.jpg (или только квадратное
// превью аватара). mime — определённый по содержимому тип. Для WebP (нет декодера) возвращаются только размеры.
func makeVariants(p, mime string, avatar bool) variants {
	var v variants
	f, err := os.Open(p)
	if err != nil {
		return v
	}
	defer f.Close()
	if mime == "image/webp" {
		v.W, v.H = webpSize(f)
		return v
	}
	cfg, _, err := image.DecodeConfig(f)
	if err != nil {
		return v
	}
	sw, sh := cfg.Width, cfg.Height
	v.W, v.H = sw, sh
	ori := 1
	if mime == "image/jpeg" {
		ori = jpegOrientation(f)
		if ori >= 5 {
			v.W, v.H = sh, sw
		}
	}
	if sw*sh > maxDecodeMpix || sw < 1 || sh < 1 {
		return v
	}
	thumbSem <- struct{}{}
	defer func() { <-thumbSem }()
	f.Seek(0, io.SeekStart)
	img, _, err := image.Decode(f)
	if err != nil {
		return v
	}
	rr := newRowReader(img)
	base := p
	// размеры считаем в «показываемой» системе координат (после ориентации), масштабируем в исходной
	dispW := v.W
	fit := func(target int) (int, int) { // ширина target (не увеличиваем), в исходных осях
		if dispW <= target {
			return sw, sh
		}
		k := float64(target) / float64(dispW)
		return max(int(float64(sw)*k+0.5), 1), max(int(float64(sh)*k+0.5), 1)
	}
	if avatar {
		// 1) уменьшаем всё изображение (до 640 по ширине), 2) ориентируем, 3) вырезаем квадрат по центру
		mw, mh := fit(640)
		mid := orient(scaleMany(rr, 0, 0, sw, sh, [][2]int{{mw, mh}})[0], ori)
		bw, bh := mid.Bounds().Dx(), mid.Bounds().Dy()
		side := min(bw, bh)
		out := min(side, avatarSize)
		sq := scaleMany(newRowReader(mid), (bw-side)/2, (bh-side)/2, side, side, [][2]int{{out, out}})[0]
		name := filepath.Base(base) + ".t.jpg"
		if writeJPEG(filepath.Join(filepath.Dir(base), name), sq, thumbQuality) == nil {
			v.Thumb = name
		}
		return v
	}
	var sizes [][2]int
	needView := dispW > viewWidth && mime != "image/gif" // GIF оставляем как есть (анимация)
	if needView {
		w, h := fit(viewWidth)
		sizes = append(sizes, [2]int{w, h})
	}
	tw, th := fit(thumbWidth)
	sizes = append(sizes, [2]int{tw, th})
	res := scaleMany(rr, 0, 0, sw, sh, sizes)
	if needView {
		name := filepath.Base(base) + ".v.jpg"
		if writeJPEG(filepath.Join(filepath.Dir(base), name), orient(res[0], ori), viewQuality) == nil {
			v.View = name
		}
		res = res[1:]
	}
	name := filepath.Base(base) + ".t.jpg"
	if writeJPEG(filepath.Join(filepath.Dir(base), name), orient(res[0], ori), thumbQuality) == nil {
		v.Thumb = name
	}
	return v
}

var _ = bufio.NewReader
