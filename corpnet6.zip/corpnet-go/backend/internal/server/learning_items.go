package server

import (
	"context"
	"encoding/json"
	"io"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/jackc/pgx/v5"
)

// ---------------------------------------------------------------- файлы раздела

// learnUpload — загрузка файлов (вложения материалов, картинки вопросов); привязываются при сохранении материала/теста.
func (s *Server) learnUpload(c *Ctx) error {
	fid := c.QInt64("folder")
	if fid <= 0 {
		return badReq("Не указана папка")
	}
	if _, err := s.learnFolder(c, fid, lvEdit); err != nil {
		return err
	}
	var ids []int64
	err := s.readParts(c, 20, func(name string, r io.Reader) error {
		st, err := s.storeUpload(r, name, false)
		if err != nil {
			return err
		}
		id, err := s.insertFile(c.Context(), s.db, st, nil, c.U.ID, "learning")
		if err != nil {
			s.removeStored(false, st.Storage, st.Thumb)
			return err
		}
		ids = append(ids, id)
		return nil
	})
	if err != nil && len(ids) == 0 {
		return err
	}
	b, qerr := s.arr(c.Context(), `SELECT `+fileJSON+` FROM files WHERE id = ANY($1::bigint[]) ORDER BY id`, ids)
	if qerr != nil {
		return qerr
	}
	return c.Raw(201, b)
}

// learnBulkUpload — массовая загрузка: каждый файл становится отдельным материалом папки.
func (s *Server) learnBulkUpload(c *Ctx) error {
	fid, err := c.ID("id")
	if err != nil {
		return err
	}
	f, err := s.learnFolder(c, fid, lvEdit)
	if err != nil {
		return err
	}
	if f.Kind != "materials" {
		return badReq("Загрузка материалов возможна только в папки материалов")
	}
	ctx := c.Context()
	var ids []int64
	err = s.readParts(c, 50, func(name string, r io.Reader) error {
		st, err := s.storeUpload(r, name, false)
		if err != nil {
			return err
		}
		kind := "file"
		if strings.HasPrefix(st.Mime, "video/") {
			kind = "video"
		}
		title := strings.TrimSuffix(st.Name, filepath.Ext(st.Name))
		if strings.TrimSpace(title) == "" {
			title = st.Name
		}
		var item int64
		err = s.tx(ctx, func(tx pgx.Tx) error {
			fileID, err := s.insertFile(ctx, tx, st, nil, c.U.ID, "learning")
			if err != nil {
				return err
			}
			if err := tx.QueryRow(ctx, `INSERT INTO learn_items (folder_id, kind, title, author_id) VALUES ($1, $2, $3, $4) RETURNING id`,
				fid, kind, title, c.U.ID).Scan(&item); err != nil {
				return err
			}
			_, err = tx.Exec(ctx, `INSERT INTO learn_item_files (item_id, file_id) VALUES ($1, $2)`, item, fileID)
			return err
		})
		if err != nil {
			s.removeStored(false, st.Storage, st.Thumb)
			return err
		}
		ids = append(ids, item)
		return nil
	})
	s.learnBump(ctx)
	if err != nil && len(ids) == 0 {
		return err
	}
	return c.JSON(201, map[string]any{"ids": ids, "created": len(ids)})
}

// ---------------------------------------------------------------- список и поиск

const itemListCols = `i.id, i.folder_id, i.kind, i.title, i.description, i.tags, i.sort, i.views_count, i.created_at, i.updated_at,
	(SELECT count(*) FROM learn_item_files lf WHERE lf.item_id = i.id) AS files_count,
	(SELECT json_build_object('id', x.id, 'name', x.name, 'mime', x.mime, 'size', x.size, 'has_thumb', x.thumb <> '')
		FROM learn_item_files lf JOIN files x ON x.id = lf.file_id WHERE lf.item_id = i.id ORDER BY lf.sort, x.id LIMIT 1) AS first_file,
	p.done_at IS NOT NULL AS done`

func (s *Server) learnMaterials(c *Ctx) error {
	ctx := c.Context()
	q := strings.ToLower(strings.TrimSpace(c.Q("q")))
	folder := c.QInt64("folder")
	page, per, off := c.Page(30, 100)
	args := []any{c.U.ID}
	add := func(v any) string { args = append(args, v); return "$" + itoa(len(args)) }
	where := []string{}
	order := "i.sort, i.id"
	out := map[string]any{"page": page, "per": per}
	if q != "" {
		if !c.U.IsAdmin() {
			all, _, _, err := s.learnTreeIDs(ctx, c.U, "materials")
			if err != nil {
				return err
			}
			if len(all) == 0 {
				return c.JSON(200, map[string]any{"items": []any{}, "has_more": false})
			}
			where = append(where, "i.folder_id = ANY("+add(all)+"::bigint[])")
		}
		if len([]rune(q)) < 3 {
			where = append(where, `lower(i.title) COLLATE "C" LIKE `+add(likeEscape(q)+"%")+` ESCAPE '\'`)
		} else {
			where = append(where, "(lower(i.title) LIKE "+add("%"+likeEscape(q)+"%")+" ESCAPE '\\' OR i.tags @> ARRAY["+add(q)+"]::text[])")
		}
		if len([]rune(q)) < 3 {
			// короткий запрос: префиксный индекс по названию, порядок — по индексу (без сортировки всех совпадений)
			order = `lower(i.title) COLLATE "C", i.id`
		} else {
			order = "(lower(i.title) LIKE " + add(likeEscape(q)+"%") + " ESCAPE '\\') DESC, i.id DESC"
		}
		off = (page - 1) * per
	} else {
		if folder <= 0 {
			return badReq("Не указана папка")
		}
		f, err := s.learnFolder(c, folder, lvView)
		if err != nil {
			return err
		}
		if f.Kind != "materials" {
			return badReq("Это папка тестов")
		}
		where = append(where, "i.folder_id = "+add(folder))
		switch c.Q("order") {
		case "new":
			order = "i.id DESC"
		case "title":
			order = "lower(i.title), i.id"
		}
		if t := strings.ToLower(c.Q("tag")); t != "" {
			where = append(where, "i.tags @> ARRAY["+add(t)+"]::text[]")
		} else {
			var cnt int
			s.db.QueryRow(ctx, `SELECT items_count FROM learn_folders WHERE id = $1`, folder).Scan(&cnt)
			out["total"] = cnt
		}
		out["level"] = f.Level
	}
	lim, offs := add(per+1), add(off)
	items, err := s.arr(ctx, `SELECT `+itemListCols+` FROM learn_items i LEFT JOIN learn_progress p ON p.item_id = i.id AND p.user_id = $1
		WHERE `+strings.Join(where, " AND ")+` ORDER BY `+order+` LIMIT `+lim+` OFFSET `+offs, args...)
	if err != nil {
		return err
	}
	var rows []json.RawMessage
	json.Unmarshal(items, &rows)
	more := len(rows) > per
	if more {
		rows = rows[:per]
	}
	out["items"], out["has_more"] = rows, more
	if rows == nil {
		out["items"] = []any{}
	}
	if off == 0 {
		s.logSearch(c, "learning", q, len(rows)) // аналитика поиска
	}
	return c.JSON(200, out)
}

func (s *Server) learnRecent(c *Ctx) error {
	ctx := c.Context()
	args := []any{c.U.ID}
	cond := "TRUE"
	if !c.U.IsAdmin() {
		all, _, _, err := s.learnTreeIDs(ctx, c.U, "materials")
		if err != nil {
			return err
		}
		args = append(args, all)
		cond = "i.folder_id = ANY($2::bigint[])"
	}
	b, err := s.arr(ctx, `SELECT i.id, i.folder_id, i.kind, i.title, p.opened_at, p.done_at IS NOT NULL AS done
		FROM learn_progress p JOIN learn_items i ON i.id = p.item_id WHERE p.user_id = $1 AND `+cond+` ORDER BY p.opened_at DESC LIMIT 8`, args...)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// ---------------------------------------------------------------- материал

func (s *Server) learnItemGet(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	folder, lvl, err := s.learnLevelOf(c, "learn_items", id)
	if err != nil {
		return err
	}
	if lvl < lvView {
		return errForbidden
	}
	var fl int // доступ только через курс — соседние материалы папки не раскрываем
	s.db.QueryRow(ctx, `SELECT learn_level($1, $2, $3, $4)`, folder, c.U.ID, c.U.Dept, c.U.IsAdmin()).Scan(&fl)
	var inserted bool
	if err := s.db.QueryRow(ctx, `INSERT INTO learn_progress (user_id, item_id, folder_id) VALUES ($1, $2, $3)
		ON CONFLICT (user_id, item_id) DO UPDATE SET opened_at = now() RETURNING (xmax = 0)`, c.U.ID, id, folder).Scan(&inserted); err != nil {
		return err
	}
	if inserted {
		s.db.Exec(ctx, `UPDATE learn_items SET views_count = views_count + 1 WHERE id = $1`, id)
	}
	b, err := s.one(ctx, `SELECT i.id, i.folder_id, i.kind, i.title, i.description, i.body, i.url, i.tags, i.sort, i.views_count, i.created_at, i.updated_at, i.author_id,
		(SELECT full_name FROM users WHERE id = i.author_id) AS author, f.name AS folder_name,
		coalesce((SELECT json_agg(json_build_object('id', x.id, 'name', x.name, 'mime', x.mime, 'size', x.size, 'has_thumb', x.thumb <> '', 'width', x.width, 'height', x.height) ORDER BY lf.sort, x.id)
			FROM learn_item_files lf JOIN files x ON x.id = lf.file_id WHERE lf.item_id = i.id), '[]') AS files,
		p.done_at, $2::int AS level,
		CASE WHEN $4::int = 0 THEN NULL ELSE (SELECT json_build_object('id', n.id, 'title', n.title) FROM learn_items n WHERE n.folder_id = i.folder_id AND (n.sort, n.id) > (i.sort, i.id) ORDER BY n.sort, n.id LIMIT 1) END AS next,
		CASE WHEN $4::int = 0 THEN NULL ELSE (SELECT json_build_object('id', n.id, 'title', n.title) FROM learn_items n WHERE n.folder_id = i.folder_id AND (n.sort, n.id) < (i.sort, i.id) ORDER BY n.sort DESC, n.id DESC LIMIT 1) END AS prev
		FROM learn_items i JOIN learn_folders f ON f.id = i.folder_id LEFT JOIN learn_progress p ON p.item_id = i.id AND p.user_id = $3 WHERE i.id = $1`, id, lvl, c.U.ID, fl)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func urlOK(u string) bool {
	l := strings.ToLower(u)
	return strings.HasPrefix(l, "https://") || strings.HasPrefix(l, "http://")
}

func cleanTags(in []string) []string {
	out := []string{}
	seen := map[string]bool{}
	for _, t := range in {
		t = strings.ToLower(strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(t), "#")))
		if t == "" || len([]rune(t)) > 40 || seen[t] {
			continue
		}
		seen[t] = true
		out = append(out, t)
		if len(out) >= 12 {
			break
		}
	}
	return out
}

// learnLinkFiles привязывает загруженные файлы к материалу (в порядке ids) и отвязывает остальные.
func (s *Server) learnLinkFiles(ctx context.Context, tx pgx.Tx, item, uid int64, ids []int64) ([]int64, error) {
	uniq := []int64{}
	seen := map[int64]bool{}
	for _, id := range ids {
		if id > 0 && !seen[id] {
			seen[id] = true
			uniq = append(uniq, id)
		}
	}
	if len(uniq) > 0 {
		var n int
		if err := tx.QueryRow(ctx, `SELECT count(*) FROM files f WHERE f.id = ANY($1::bigint[]) AND f.context = 'learning'
			AND (f.owner_id = $2 OR EXISTS (SELECT 1 FROM learn_item_files x WHERE x.file_id = f.id AND x.item_id = $3))
			AND NOT EXISTS (SELECT 1 FROM learn_item_files x WHERE x.file_id = f.id AND x.item_id <> $3)`, uniq, uid, item).Scan(&n); err != nil {
			return nil, err
		}
		if n != len(uniq) {
			return nil, badReq("Файл не найден или уже используется")
		}
	}
	rows, err := tx.Query(ctx, `DELETE FROM learn_item_files WHERE item_id = $1 AND NOT (file_id = ANY($2::bigint[])) RETURNING file_id`, item, uniq)
	if err != nil {
		return nil, err
	}
	var removed []int64
	for rows.Next() {
		var f int64
		rows.Scan(&f)
		removed = append(removed, f)
	}
	rows.Close()
	if len(uniq) > 0 {
		if _, err := tx.Exec(ctx, `INSERT INTO learn_item_files (item_id, file_id, sort) SELECT $1, f, o::int FROM unnest($2::bigint[]) WITH ORDINALITY AS x(f, o)
			ON CONFLICT (item_id, file_id) DO UPDATE SET sort = EXCLUDED.sort`, item, uniq); err != nil {
			return nil, err
		}
	}
	return removed, nil
}

func itoa(n int) string { return strconv.Itoa(n) }

func (s *Server) learnItemSave(c *Ctx) error {
	var in struct {
		FolderID    int64    `json:"folder_id"`
		Kind        string   `json:"kind"`
		Title       string   `json:"title"`
		Description string   `json:"description"`
		Body        string   `json:"body"`
		URL         string   `json:"url"`
		Tags        []string `json:"tags"`
		Sort        int      `json:"sort"`
		FileIDs     []int64  `json:"file_ids"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Title = strings.TrimSpace(in.Title)
	in.URL = strings.TrimSpace(in.URL)
	if in.Title == "" || len([]rune(in.Title)) > 300 {
		return badReq("Укажите название материала (до 300 символов)")
	}
	switch in.Kind {
	case "text", "file", "video", "link":
	default:
		return badReq("Неизвестный тип материала")
	}
	if in.URL != "" && (!urlOK(in.URL) || len(in.URL) > 2000) {
		return badReq("Ссылка должна начинаться с http:// или https://")
	}
	if (in.Kind == "link") && in.URL == "" {
		return badReq("Укажите ссылку")
	}
	if len(in.Body) > 500_000 || len(in.Description) > 5000 || len(in.FileIDs) > 50 {
		return badReq("Слишком большой объём данных")
	}
	in.Tags = cleanTags(in.Tags)
	ctx := c.Context()
	var id int64
	var removed []int64
	if c.R.PathValue("id") != "" {
		var err error
		if id, err = c.ID("id"); err != nil {
			return err
		}
		_, lvl, err := s.learnLevelOf(c, "learn_items", id)
		if err != nil {
			return err
		}
		if lvl < lvEdit {
			return errForbidden
		}
		err = s.tx(ctx, func(tx pgx.Tx) error {
			if _, err := tx.Exec(ctx, `UPDATE learn_items SET kind = $2, title = $3, description = $4, body = $5, url = $6, tags = $7, sort = $8, updated_at = now() WHERE id = $1`,
				id, in.Kind, in.Title, in.Description, in.Body, in.URL, in.Tags, in.Sort); err != nil {
				return err
			}
			removed, err = s.learnLinkFiles(ctx, tx, id, c.U.ID, in.FileIDs)
			return err
		})
		if err != nil {
			return err
		}
	} else {
		f, err := s.learnFolder(c, in.FolderID, lvEdit)
		if err != nil {
			return err
		}
		if f.Kind != "materials" {
			return badReq("Материалы добавляются в папки материалов")
		}
		err = s.tx(ctx, func(tx pgx.Tx) error {
			if err := tx.QueryRow(ctx, `INSERT INTO learn_items (folder_id, kind, title, description, body, url, tags, sort, author_id)
				VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING id`, in.FolderID, in.Kind, in.Title, in.Description, in.Body, in.URL, in.Tags, in.Sort, c.U.ID).Scan(&id); err != nil {
				return err
			}
			_, err := s.learnLinkFiles(ctx, tx, id, c.U.ID, in.FileIDs)
			return err
		})
		if err != nil {
			return err
		}
	}
	s.learnPurgeFiles(ctx, removed)
	s.learnBump(ctx)
	return c.JSON(200, map[string]int64{"id": id})
}

func (s *Server) learnItemDelete(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	_, lvl, err := s.learnLevelOf(c, "learn_items", id)
	if err != nil {
		return err
	}
	if lvl < lvEdit {
		return errForbidden
	}
	ctx := c.Context()
	var fids []int64
	rows, err := s.db.Query(ctx, `SELECT file_id FROM learn_item_files WHERE item_id = $1`, id)
	if err != nil {
		return err
	}
	for rows.Next() {
		var f int64
		rows.Scan(&f)
		fids = append(fids, f)
	}
	rows.Close()
	if _, err := s.db.Exec(ctx, `DELETE FROM learn_items WHERE id = $1`, id); err != nil {
		return err
	}
	s.learnPurgeFiles(ctx, fids)
	s.learnBump(ctx)
	return c.OK()
}

func (s *Server) learnItemDone(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Done bool `json:"done"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	folder, lvl, err := s.learnLevelOf(c, "learn_items", id)
	if err != nil {
		return err
	}
	if lvl < lvView {
		return errForbidden
	}
	if _, err := s.db.Exec(c.Context(), `INSERT INTO learn_progress (user_id, item_id, folder_id, done_at) VALUES ($1, $2, $3, CASE WHEN $4::boolean THEN now() END)
		ON CONFLICT (user_id, item_id) DO UPDATE SET done_at = CASE WHEN $4::boolean THEN coalesce(learn_progress.done_at, now()) END`,
		c.U.ID, id, folder, in.Done); err != nil {
		return err
	}
	return c.JSON(200, map[string]bool{"done": in.Done})
}

// learnItemsMove переносит материалы в другую папку материалов (нужны права на исходные и целевую папки).
func (s *Server) learnItemsMove(c *Ctx) error {
	var in struct {
		IDs      []int64 `json:"ids"`
		FolderID int64   `json:"folder_id"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if len(in.IDs) == 0 || len(in.IDs) > 500 {
		return badReq("Выберите материалы")
	}
	ctx := c.Context()
	dst, err := s.learnFolder(c, in.FolderID, lvEdit)
	if err != nil {
		return err
	}
	if dst.Kind != "materials" {
		return badReq("Материалы можно переносить только в папки материалов")
	}
	if err := s.learnCheckSources(c, "learn_items", in.IDs); err != nil {
		return err
	}
	if _, err := s.db.Exec(ctx, `UPDATE learn_items SET folder_id = $2, updated_at = now() WHERE id = ANY($1::bigint[])`, in.IDs, in.FolderID); err != nil {
		return err
	}
	s.db.Exec(ctx, `UPDATE learn_progress SET folder_id = $2 WHERE item_id = ANY($1::bigint[])`, in.IDs, in.FolderID)
	s.learnBump(ctx)
	return c.OK()
}

// learnCheckSources: у вызывающего должны быть права редактирования на папки всех переносимых объектов.
func (s *Server) learnCheckSources(c *Ctx, table string, ids []int64) error {
	if table != "learn_items" && table != "learn_tests" {
		return errNotFound
	}
	rows, err := s.db.Query(c.Context(), `SELECT DISTINCT folder_id FROM `+table+` WHERE id = ANY($1::bigint[])`, ids)
	if err != nil {
		return err
	}
	var folders []int64
	for rows.Next() {
		var f int64
		rows.Scan(&f)
		folders = append(folders, f)
	}
	rows.Close()
	for _, f := range folders {
		if _, err := s.learnFolder(c, f, lvEdit); err != nil {
			return err
		}
	}
	return nil
}
