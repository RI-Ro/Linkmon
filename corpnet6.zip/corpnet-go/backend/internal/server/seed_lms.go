package server

import (
	"fmt"
	"time"
)

// seedLMS — демо-данные LMS: ответственный за обучение, шаблоны сертификатов, три курса с шагами из демо-материалов и тестов,
// прогресс сотрудников, выданные сертификаты, назначения с дедлайнами и правило автоназначения для новичков.
func (s *Server) seedLMS(d sd, uid []int64, dep map[string]int64) {
	admin, elena, tatiana, alina := uid[0], uid[1], uid[9], uid[28]
	find := func(table, title string) int64 {
		var id int64
		if err := d.tx.QueryRow(d.ctx, `SELECT id FROM `+table+` WHERE title = $1 ORDER BY id LIMIT 1`, title).Scan(&id); err != nil {
			panic(fmt.Errorf("seed lms: %s %q: %w", table, title, err))
		}
		return id
	}

	// ---- роль «ответственный за обучение»: HR-специалист по обучению; область — свой отдел и «Разработка»
	d.exec(`UPDATE users SET learning_manager = true WHERE id = $1`, alina)
	d.exec(`INSERT INTO learning_manager_departments (user_id, department_id) VALUES ($1, $2)`, alina, dep["dev"])
	// сотрудники работают давно; «новички» — трое, перешедшие/принятые недавно
	recent := []int64{uid[22], uid[23], uid[33]}
	d.exec(`UPDATE users SET department_since = now() - interval '400 days'`)
	d.exec(`UPDATE users SET department_since = now() - interval '5 days' WHERE id = ANY($1::bigint[])`, recent)

	// ---- шаблоны сертификатов
	tpl1 := d.id(`INSERT INTO learn_cert_templates (name, title, body, color, border, signer_name, signer_title, number_mask, created_by)
		VALUES ('Стандартный', 'Сертификат', 'Настоящим подтверждается, что {ФИО} успешно прошёл(ла) обучение по программе «{курс}» {дата}. Результат: {балл}. Сертификат действителен: {срок_действия}.',
			'#1f5fa8', 'double', 'Татьяна Лебедева', 'Директор по персоналу', 'CN-{YYYY}-{N:5}', $1) RETURNING id`, tatiana)
	tpl2 := d.id(`INSERT INTO learn_cert_templates (name, title, body, color, border, signer_name, signer_title, number_mask, expire_remind_days, created_by)
		VALUES ('Охрана труда', 'Удостоверение', '{ФИО} прошёл(ла) инструктаж и проверку знаний по программе «{курс}». Результат проверки: {балл}. Дата: {дата}. Действительно до: {срок_действия}.',
			'#b4531a', 'ornate', 'Алексей Морозов', 'Руководитель проектов', 'ОТ-{YY}{MM}-{N:4}', 14, $1) RETURNING id`, admin)

	// ---- папки курсов (общие права, как у материалов и тестов)
	cf := func(name, desc string, sort int) int64 {
		return d.id(`INSERT INTO learn_folders (kind, name, description, visibility, owner_id, sort) VALUES ('courses', $1, $2, 'company', $3, $4) RETURNING id`, name, desc, admin, sort)
	}
	fMand := cf("Обязательное обучение", "Курсы, которые обязаны пройти все сотрудники", 10)
	fOnb := cf("Адаптация", "Для новых сотрудников", 20)
	d.exec(`INSERT INTO learn_acl (folder_id, subject_type, subject_id, level) VALUES ($1, 'user', $2, 3), ($3, 'user', $2, 3), ($1, 'user', $4, 3)`, fMand, elena, fOnb, uid[6])

	type step struct {
		kind, title, body, url, ref string
		required                    bool
		est                         int
		sec                         int
	}
	type course struct {
		folder             int64
		title, desc, cover string
		tags               []string
		est, validity      int
		order              string
		pass               int
		maxAtt             any
		tpl                int64
		sections           []string
		steps              []step
	}
	courses := []course{
		{fMand, "Информационная безопасность", "Пароли, фишинг, безопасная работа с почтой и данными. Курс завершается тестом; результат действует год — затем нужно пройти его заново.", seedImgs[2], []string{"безопасность", "обязательное"},
			45, 12, "sequential", 75, nil, tpl1, []string{"Теория", "Проверка знаний"}, []step{
				{kind: "item", ref: "Пароли и двухфакторная аутентификация", required: true, est: 8, sec: 0},
				{kind: "item", ref: "Как распознать фишинг", required: true, est: 8, sec: 0},
				{kind: "item", ref: "Безопасность в интернете для сотрудников", required: false, est: 12, sec: 0},
				{kind: "ack", title: "Политика информационной безопасности", body: "Я ознакомился(лась) с политикой информационной безопасности компании и обязуюсь её соблюдать.", required: true, est: 2, sec: 0},
				{kind: "test", ref: "Основы кибербезопасности", required: true, est: 15, sec: 1},
			}},
		{fMand, "Охрана труда и пожарная безопасность", "Вводный инструктаж и проверка знаний. Тест ограничен по времени, попыток — три. Результат действует полгода.", seedImgs[3], []string{"охрана труда", "обязательное"},
			30, 6, "free", 80, 3, tpl2, nil, []step{
				{kind: "ack", title: "Инструктаж по охране труда", body: "Прослушал(а) вводный инструктаж по охране труда и пожарной безопасности, правила эвакуации мне понятны.", required: true, est: 5},
				{kind: "link", title: "Памятка: действия при пожаре", url: "https://example.com/fire-safety", required: false, est: 5},
				{kind: "test", ref: "Охрана труда и пожарная безопасность", required: true, est: 15},
			}},
		{fOnb, "Знакомство с компанией", "Первая неделя: что нужно знать новому сотруднику — ценности, доступы, команда. Проходите в удобном порядке.", seedImgs[0], []string{"онбординг", "новичку"},
			40, 0, "free", 70, nil, tpl1, []string{"Первые шаги", "Культура и ценности"}, []step{
				{kind: "item", ref: "Добро пожаловать в компанию!", required: true, est: 5, sec: 0},
				{kind: "item", ref: "Чек-лист первой недели", required: true, est: 5, sec: 0},
				{kind: "item", ref: "Экскурсия по офису (видео)", required: false, est: 10, sec: 0},
				{kind: "item", ref: "Наши ценности", required: true, est: 6, sec: 1},
				{kind: "item", ref: "Кодекс деловой этики", required: false, est: 10, sec: 1},
				{kind: "test", ref: "Знакомство с компанией", required: true, est: 10, sec: 1},
			}},
	}
	type cstep struct {
		id       int64
		kind     string
		required bool
	}
	cids := make([]int64, len(courses))
	csteps := make([][]cstep, len(courses))
	for ci, c := range courses {
		var maxAtt any = c.maxAtt
		cids[ci] = d.id(`INSERT INTO learn_courses (folder_id, title, description, cover, tags, status, est_minutes, order_mode, pass_percent, validity_months, max_attempts, cert_template_id, author_id)
			VALUES ($1, $2, $3, $4, $5, 'published', $6, $7, $8, $9, $10::int, $11, $12) RETURNING id`, c.folder, c.title, c.desc, c.cover, c.tags, c.est, c.order, c.pass, c.validity, maxAtt, c.tpl, admin)
		secs := make([]int64, len(c.sections))
		for i, sname := range c.sections {
			secs[i] = d.id(`INSERT INTO learn_course_sections (course_id, title, sort) VALUES ($1, $2, $3) RETURNING id`, cids[ci], sname, i)
		}
		req := 0
		for i, st := range c.steps {
			var ref any
			title := st.title
			switch st.kind {
			case "item":
				ref = find("learn_items", st.ref)
				title = st.ref
			case "test":
				ref = find("learn_tests", st.ref)
				title = st.ref
			}
			var sec any
			if len(secs) > 0 {
				sec = secs[st.sec]
			}
			id := d.id(`INSERT INTO learn_course_steps (course_id, section_id, sort, kind, ref_id, title, body, url, required, est_minutes) VALUES ($1, $2, $3, $4, $5::bigint, $6, $7, $8, $9, $10) RETURNING id`,
				cids[ci], sec, i, st.kind, ref, title, st.body, st.url, st.required, st.est)
			csteps[ci] = append(csteps[ci], cstep{id, st.kind, st.required})
			if st.required {
				req++
			}
		}
		d.exec(`UPDATE learn_courses SET steps_count = $2, required_count = $3 WHERE id = $1`, cids[ci], len(c.steps), req)
	}
	d.exec(`INSERT INTO learn_course_prereq (course_id, req_id) VALUES ($1, $2)`, cids[0], cids[2]) // ИБ — после знакомства с компанией

	// ---- прогресс сотрудников и сертификаты
	now := time.Now()
	soonDone := false
	for u := 2; u < len(uid); u++ {
		if u == 28 || u == 22 || u == 23 || u == 33 { // ответственный и «новички» начинают с нуля
			continue
		}
		var deptID any
		d.tx.QueryRow(d.ctx, `SELECT department_id FROM users WHERE id = $1`, uid[u]).Scan(&deptID)
		for ci, c := range courses {
			state := 0 // 0 — не начинал, 1 — в процессе, 2 — завершил
			switch ci {
			case 0:
				state = []int{2, 1, 0, 0}[u%4]
			case 1:
				state = []int{2, 1, 0, 0, 0}[u%5]
			case 2:
				state = []int{1, 2, 2}[u%3]
			}
			if ci == 0 && state > 0 && u%4 != 0 { // нельзя идти по ИБ без «Знакомства»: предпосылка выполнена
				d.exec(`UPDATE learn_enrollments SET status = status WHERE false`)
			}
			if state == 0 {
				continue
			}
			steps := csteps[ci]
			req, doneReq := 0, 0
			var scoreSum float64
			var scoreN int
			started := now.Add(-time.Duration(3+(u*2+ci*5)%40) * 24 * time.Hour)
			limit := len(steps)
			if state == 1 {
				limit = 1 + u%(max(len(steps)-1, 1))
			}
			for i, st := range steps {
				if st.required {
					req++
				}
				if i >= limit {
					continue
				}
				var score any
				if st.kind == "test" {
					sc := float64(70 + (u*7)%30)
					if sc < float64(c.pass) {
						sc = float64(c.pass) + 3
					}
					score = sc
					scoreSum += sc
					scoreN++
				}
				d.exec(`INSERT INTO learn_step_progress (user_id, step_id, course_id, status, first_at, last_at, done_at, time_sec, score)
					VALUES ($1::bigint, $2::bigint, $3::bigint, 2, $4::timestamptz, $4::timestamptz + interval '10 minutes', $4::timestamptz + interval '10 minutes', $5::int, $6::numeric)`, uid[u], st.id, cids[ci], started.Add(time.Duration(i)*time.Hour), 240+(u*37+i*61)%900, score)
				if st.required {
					doneReq++
				}
			}
			var avg any
			if scoreN > 0 {
				avg = scoreSum / float64(scoreN)
			}
			pct := 0
			if req > 0 {
				pct = doneReq * 100 / req
			}
			total := 300 + (u*53+ci*97)%2400
			if state == 2 {
				doneAt := now.Add(-time.Duration(1+(u*3+ci*7)%25) * 24 * time.Hour)
				var exp any
				if c.validity > 0 {
					exp = doneAt.AddDate(0, c.validity, 0)
				}
				// один сертификат «скоро истекает» (курс по охране труда, срок — через ~10 дней)
				if ci == 1 && !soonDone {
					soonDone = true
					doneAt = now.AddDate(0, -c.validity, -1).Add(10 * 24 * time.Hour).Add(-48 * time.Hour)
					exp = now.Add(10 * 24 * time.Hour)
				}
				d.exec(`INSERT INTO learn_enrollments (user_id, course_id, dept_id, status, started_at, last_at, completed_at, expires_at, started_version, completed_version, steps_done, steps_total, percent, time_sec, score)
					VALUES ($1, $2, $3::bigint, 2, $4, $5, $5, $6::timestamptz, 1, 1, $7, $7, 100, $8, $9::numeric)`, uid[u], cids[ci], deptID, started, doneAt, exp, req, total, avg)
				var certID any
				cid, err := s.lmsIssueCert(d.ctx, d.tx, certParams{UserID: uid[u], CourseID: &cids[ci], TemplateID: c.tpl, Title: c.title, Score: ptrF(avg), Expires: ptrT(exp)})
				if err != nil {
					panic(err)
				}
				certID = cid
				d.exec(`UPDATE learn_certs SET issued_at = $2 WHERE id = $1`, cid, doneAt)
				d.exec(`UPDATE learn_enrollments SET cert_id = $3 WHERE user_id = $1 AND course_id = $2`, uid[u], cids[ci], certID)
				d.exec(`INSERT INTO learn_completions (user_id, course_id, cycle, version, completed_at, expires_at, score, time_sec, cert_id) VALUES ($1, $2, 1, 1, $3, $4::timestamptz, $5::numeric, $6, $7)`,
					uid[u], cids[ci], doneAt, exp, avg, total, certID)
			} else {
				d.exec(`INSERT INTO learn_enrollments (user_id, course_id, dept_id, status, started_at, last_at, started_version, steps_done, steps_total, percent, time_sec)
					VALUES ($1, $2, $3::bigint, 1, $4, $5, 1, $6, $7, $8, $9)`, uid[u], cids[ci], deptID, started, now.Add(-time.Duration(u%72)*time.Hour), doneReq, req, pct, total)
			}
		}
	}
	// один сертификат отозван (для демонстрации реестра)
	d.exec(`UPDATE learn_certs SET status = 'revoked', revoked_at = now() - interval '2 days', revoked_by = $1, revoke_reason = 'Выдан ошибочно: не завершена проверка знаний'
		WHERE id = (SELECT id FROM learn_certs WHERE course_id = $2 ORDER BY id LIMIT 1 OFFSET 2)`, admin, cids[0])

	// ---- назначения с дедлайнами
	type asg struct {
		typ        string
		target     int64
		by         int64
		targets    [][3]any // type, id, key
		mode       string
		date       any
		days       any
		priority   string
		follow     bool
		within     any
		recur      int
		limit      any
		ageDays    int
		note       string
		remind     string
		remindOver int
	}
	trgSec := find("learn_tests", "Основы кибербезопасности")
	var devScope []int64
	{
		rows, _ := d.tx.Query(d.ctx, `WITH RECURSIVE t AS (SELECT $1::bigint AS id UNION SELECT d.id FROM departments d JOIN t ON d.parent_id = t.id) SELECT id FROM t
			UNION SELECT department_id FROM users WHERE id = $2 AND department_id IS NOT NULL`, dep["dev"], alina)
		for rows.Next() {
			var id int64
			rows.Scan(&id)
			devScope = append(devScope, id)
		}
		rows.Close()
		var hrs []int64
		rows, _ = d.tx.Query(d.ctx, `WITH RECURSIVE t AS (SELECT $1::bigint AS id UNION SELECT d.id FROM departments d JOIN t ON d.parent_id = t.id) SELECT id FROM t`, dep["hrs"])
		for rows.Next() {
			var id int64
			rows.Scan(&id)
			hrs = append(hrs, id)
		}
		rows.Close()
		devScope = append(devScope, hrs...)
	}
	list := []asg{
		{"course", cids[1], admin, [][3]any{{"all", 0, ""}}, "date", now.Add(-5 * 24 * time.Hour), nil, "high", false, nil, 6, nil, 30, "Обязательно для всех сотрудников. Ежегодная проверка знаний по охране труда.", "{7,3,1,0}", 3},
		{"course", cids[0], admin, [][3]any{{"department", dep["it"], ""}, {"department", dep["fin"], ""}}, "date", now.Add(9 * 24 * time.Hour), nil, "normal", false, nil, 0, nil, 12, "", "{7,3,1,0}", 3},
		{"course", cids[2], admin, [][3]any{{"all", 0, ""}}, "days", nil, 14, "normal", true, 30, 0, nil, 20, "Автоназначение: всем новым сотрудникам и переведённым в течение 30 дней.", "{7,3,1,0}", 2},
		{"test", trgSec, elena, [][3]any{{"department", dep["acc"], ""}, {"department", dep["fp"], ""}}, "date", now.Add(20 * 24 * time.Hour), nil, "normal", false, nil, 0, nil, 3, "Квартальная проверка знаний.", "{3,1,0}", 5},
		{"course", cids[0], alina, [][3]any{{"department", dep["dev"], ""}}, "date", now.Add(-2 * 24 * time.Hour), nil, "high", false, nil, 0, devScope, 14, "Разработчикам — до конца недели.", "{3,1,0}", 2},
	}
	for _, a := range list {
		var id int64
		id = d.id(`INSERT INTO learn_assignments (target_type, target_id, created_by, created_at, priority, due_mode, due_date, due_days, remind_days, remind_overdue_days, recur_months, follow, new_within_days, limit_depts, note)
			VALUES ($1, $2, $3, now() - make_interval(days => $4::int), $5, $6, $7::timestamptz, $8::int, $9::int[], $10, $11, $12, $13::int, $14::bigint[], $15) RETURNING id`,
			a.typ, a.target, a.by, a.ageDays, a.priority, a.mode, a.date, a.days, a.remind, a.remindOver, a.recur, a.follow, a.within, a.limit, a.note)
		for _, t := range a.targets {
			d.exec(`INSERT INTO learn_assign_targets (assignment_id, subject_type, subject_id, subject_key) VALUES ($1, $2, $3, $4)`, id, t[0], t[1], t[2])
		}
		if _, _, _, _, err := s.lmsMaterializeQ(d.ctx, d.tx, id, "", ""); err != nil {
			panic(err)
		}
		d.exec(`UPDATE learn_assignees SET assigned_at = assigned_at - make_interval(days => $2::int) WHERE assignment_id = $1`, id, a.ageDays)
		d.exec(`INSERT INTO learn_assign_log (assignment_id, actor_id, action, at) VALUES ($1, $2, 'create', now() - make_interval(days => $3::int))`, id, a.by, a.ageDays)
	}
	// назначения «в процессе» согласуем с прохождением курса
	d.exec(`UPDATE learn_assignees a SET status = 1, started_at = e.started_at FROM learn_enrollments e
		WHERE a.status = 0 AND a.target_type = 'course' AND e.course_id = a.target_id AND e.user_id = a.user_id AND e.status = 1`)
	d.exec(`UPDATE learn_assignees a SET status = 1 FROM (SELECT DISTINCT test_id, user_id FROM learn_attempts WHERE finished_at IS NULL) t WHERE a.status = 0 AND a.target_type = 'test' AND a.target_id = t.test_id AND a.user_id = t.user_id`)
	// сводка по тестам: сданные тесты закрывают назначение теста
	d.exec(`UPDATE learn_assignees a SET status = 2, done_at = x.fa, score = x.pc FROM (SELECT test_id, user_id, max(finished_at) fa, max(percent) pc FROM learn_attempts WHERE passed GROUP BY 1, 2) x
		WHERE a.target_type = 'test' AND a.status < 2 AND a.target_id = x.test_id AND a.user_id = x.user_id`)
}

func ptrF(v any) *float64 {
	if f, ok := v.(float64); ok {
		return &f
	}
	return nil
}

func ptrT(v any) *time.Time {
	if t, ok := v.(time.Time); ok {
		return &t
	}
	return nil
}
