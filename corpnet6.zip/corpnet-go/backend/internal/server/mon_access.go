package server

import (
	"bufio"
	"context"
	"errors"
	"io"
	"log/slog"
	"net"
	"net/http"
	"runtime/debug"
	"strings"
	"time"
)

// monWriter — обёртка ResponseWriter: статус, число байт; сохраняет Flusher/Hijacker/ReaderFrom (WebSocket, SSE, sendfile).
type monWriter struct {
	http.ResponseWriter
	status   int
	bytes    int64
	wrote    bool
	hijacked bool
}

func (w *monWriter) WriteHeader(c int) {
	if !w.wrote {
		w.status, w.wrote = c, true
	}
	w.ResponseWriter.WriteHeader(c)
}

func (w *monWriter) Write(b []byte) (int, error) {
	if !w.wrote {
		w.status, w.wrote = 200, true
	}
	n, err := w.ResponseWriter.Write(b)
	w.bytes += int64(n)
	return n, err
}

func (w *monWriter) ReadFrom(r io.Reader) (int64, error) {
	if !w.wrote {
		w.status, w.wrote = 200, true
	}
	var n int64
	var err error
	if rf, ok := w.ResponseWriter.(io.ReaderFrom); ok {
		n, err = rf.ReadFrom(r)
	} else {
		n, err = io.Copy(struct{ io.Writer }{w.ResponseWriter}, r)
	}
	w.bytes += n
	return n, err
}

func (w *monWriter) Unwrap() http.ResponseWriter { return w.ResponseWriter }

func (w *monWriter) Flush() {
	if !w.wrote {
		w.status, w.wrote = 200, true
	}
	if f, ok := w.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func (w *monWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	h, ok := w.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("hijack unsupported")
	}
	c, rw, err := h.Hijack()
	if err == nil {
		w.hijacked = true
		if !w.wrote {
			w.status, w.wrote = http.StatusSwitchingProtocols, true
		}
	}
	return c, rw, err
}

// countBody считает прочитанные байты тела запроса.
type countBody struct {
	io.ReadCloser
	n int64
}

func (b *countBody) Read(p []byte) (int, error) {
	n, err := b.ReadCloser.Read(p)
	b.n += int64(n)
	return n, err
}

// monSetUser вызывается после аутентификации (s.h): user_id и role попадают в access-лог.
func monSetUser(r *http.Request, u *User) {
	if m := monFrom(r.Context()); m != nil && u != nil {
		m.setUser(u.ID, u.Role)
	}
}

// monSetErr запоминает текст ошибки запроса для access-лога.
func monSetErr(r *http.Request, err error) {
	if m := monFrom(r.Context()); m != nil && err != nil {
		m.setErr(err.Error())
	}
}

func clientIP(r *http.Request) string {
	if xf := r.Header.Get("X-Forwarded-For"); xf != "" {
		return strings.TrimSpace(strings.Split(xf, ",")[0])
	}
	h, _, _ := net.SplitHostPort(r.RemoteAddr)
	return h
}

func trunc(s string, n int) string {
	if len(s) > n {
		return s[:n]
	}
	return s
}

// monitor — внешний middleware: request_id, замеры, паники, JSON access-лог, метрики.
func (s *Server) monitor(next http.Handler) http.Handler {
	slowMS := s.cfg.SlowRequestMS
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		t0 := time.Now()
		rid := r.Header.Get("X-Request-ID")
		if !validRequestID(rid) {
			rid = newRequestID()
		}
		mr := &monReq{ID: rid, Start: t0}
		r = r.WithContext(context.WithValue(r.Context(), monCtxKey{}, mr))
		r.Header.Set("X-Request-ID", rid)
		w.Header().Set("X-Request-ID", rid)

		mw := &monWriter{ResponseWriter: w}
		cb := &countBody{ReadCloser: r.Body}
		r.Body = cb
		mon.inflight.mu.Lock()
		mon.inflight.v++
		mon.inflight.mu.Unlock()

		var pv any
		var stack string
		func() {
			defer func() {
				if v := recover(); v != nil {
					if v == http.ErrAbortHandler {
						pv = v
						return
					}
					pv, stack = v, string(debug.Stack())
				}
			}()
			next.ServeHTTP(mw, r)
		}()

		mon.inflight.mu.Lock()
		mon.inflight.v--
		mon.inflight.mu.Unlock()

		if pv == http.ErrAbortHandler {
			panic(pv)
		}
		if pv != nil {
			mon.panics.add(1)
			mr.setErr("panic")
			if !mw.wrote {
				mw.Header().Set("Content-Type", "application/json; charset=utf-8")
				mw.WriteHeader(500)
				mw.Write([]byte(`{"error":"Внутренняя ошибка сервера"}`))
			}
		}
		status := mw.status
		if status == 0 {
			status = 200
		}
		dur := time.Since(t0)
		route := routeLabel(r.Pattern)
		inBytes := cb.n
		if inBytes == 0 && r.ContentLength > 0 {
			inBytes = r.ContentLength
		}
		ws := route == "/api/ws"
		slow := !ws && dur.Milliseconds() >= int64(slowMS)
		if r.URL.Path != "/metrics" {
			monRecordRequest(r.Method, route, status, dur, inBytes, mw.bytes, slow)
		}

		if r.URL.Path == "/healthz" && status < 500 || r.URL.Path == "/metrics" {
			return // пробы и скрейп не засоряют лог
		}
		role, merr := mr.snapshot()
		lvl := slog.LevelInfo
		switch {
		case status >= 500 || pv != nil:
			lvl = slog.LevelError
		case slow || status == 429:
			lvl = slog.LevelWarn
		}
		attrs := []slog.Attr{
			slog.String("request_id", rid),
			slog.String("method", r.Method),
			slog.String("route", route),
			slog.String("path", r.URL.Path),
			slog.Int("status", status),
			slog.Int64("bytes", mw.bytes),
			slog.Int64("bytes_in", inBytes),
			slog.Float64("duration_ms", float64(dur.Microseconds())/1000),
			slog.Float64("db_ms", float64(mr.dbNs.Load())/1e6),
			slog.Int64("db_queries", mr.dbN.Load()),
			slog.Int64("user_id", mr.uid.Load()),
			slog.String("role", role),
			slog.String("ip", clientIP(r)),
			slog.String("ua", trunc(r.UserAgent(), 200)),
			slog.String("referer", trunc(r.Referer(), 200)),
			slog.String("proto", r.Proto),
			slog.Bool("slow", slow),
		}
		if ws {
			attrs = append(attrs, slog.Bool("ws", true))
		}
		if merr != "" {
			attrs = append(attrs, slog.String("error", trunc(merr, 500)))
		}
		if pv != nil {
			attrs = append(attrs, slog.Any("panic", pv), slog.String("stack", trunc(stack, 4000)))
		}
		s.log.LogAttrs(r.Context(), lvl, "access", attrs...)
	})
}
