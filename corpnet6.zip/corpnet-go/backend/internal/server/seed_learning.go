package server

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"
)

// seedLearning — демо-данные раздела «Обучение»: папки материалов и тестов с разными правами, материалы, тесты, попытки.
func (s *Server) seedLearning(d sd, uid []int64, dep map[string]int64) {
	admin, elena, sergey := uid[0], uid[1], uid[6]
	folder := func(kind string, parent int64, name, desc, vis string, owner int64, sort int) int64 {
		var p any
		if parent > 0 {
			p = parent
		}
		return d.id(`INSERT INTO learn_folders (kind, parent_id, name, description, visibility, owner_id, sort) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
			kind, p, name, desc, vis, owner, sort)
	}
	grant := func(f int64, typ string, id int64, lvl int) {
		d.exec(`INSERT INTO learn_acl (folder_id, subject_type, subject_id, level) VALUES ($1, $2, $3, $4)`, f, typ, id, lvl)
	}
	item := func(f int64, kind, title, desc, body, url string, tags []string, sort int, author int64) int64 {
		return d.id(`INSERT INTO learn_items (folder_id, kind, title, description, body, url, tags, sort, author_id, views_count, created_at)
			VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, now() - interval '1 day' * $11::int) RETURNING id`,
			f, kind, title, desc, body, url, tags, sort, author, 5+sort*7%40, sort%20)
	}

	// ---- материалы
	adapt := folder("materials", 0, "Адаптация новых сотрудников", "Всё, что нужно знать в первые недели работы", "company", admin, 10)
	week1 := folder("materials", adapt, "Первая неделя", "", "company", admin, 10)
	culture := folder("materials", adapt, "Корпоративная культура", "Миссия, ценности и принятые правила общения", "company", admin, 20)
	it := folder("materials", 0, "ИТ и безопасность", "Работа с корпоративными системами и защита информации", "company", admin, 20)
	sec := folder("materials", it, "Информационная безопасность", "", "company", admin, 10)
	sys := folder("materials", it, "Корпоративные системы", "", "company", admin, 20)
	mgr := folder("materials", 0, "Руководителям", "Материалы для руководителей подразделений (ограниченный доступ)", "restricted", elena, 30)
	grant(mgr, "department", dep["hr"], 1)
	grant(mgr, "user", uid[8], 1)
	grant(mgr, "user", elena, 4)
	eval := folder("materials", mgr, "Оценка персонала", "", "company", elena, 10)
	devF := folder("materials", 0, "Отдел разработки", "Инженерные практики (виден подразделению «Разработка» и IT-руководителям)", "restricted", sergey, 40)
	grant(devF, "department", dep["dev"], 1)
	grant(devF, "user", sergey, 4)
	review := folder("materials", devF, "Code review", "", "company", sergey, 10)

	item(week1, "text", "Добро пожаловать в компанию!", "С чего начать первый рабочий день", "# Добро пожаловать!\n\nМы рады, что вы с нами. В первый день:\n\n1. Получите пропуск и рабочее место на ресепшене.\n2. Познакомьтесь с руководителем и командой.\n3. Настройте почту и корпоративный мессенджер.\n4. Пройдите вводный инструктаж.\n\n> Если что-то непонятно — спрашивайте наставника, это нормально.\n\n## Полезные контакты\n\n- Служба поддержки: **support@corpnet.local**\n- HR: **hr@corpnet.local**", "", []string{"онбординг", "новичку"}, 1, admin)
	item(week1, "text", "Чек-лист первой недели", "Что нужно успеть за 5 рабочих дней", "## Чек-лист\n\n- [ ] Знакомство с командой\n- [ ] Доступ ко всем системам\n- [ ] Вводный инструктаж по охране труда\n- [ ] Тест «Знакомство с компанией»\n- [ ] Первая встреча 1:1 с руководителем", "", []string{"онбординг", "чек-лист"}, 2, admin)
	item(week1, "video", "Экскурсия по офису (видео)", "Короткий видеотур: переговорные, столовая, зоны отдыха", "", "https://www.youtube.com/watch?v=aqz-KE-bpKQ", []string{"видео", "офис"}, 3, admin)
	item(culture, "text", "Наши ценности", "Пять принципов, по которым мы работаем", "## Ценности компании\n\n**Открытость.** Мы говорим прямо и уважительно.\n\n**Ответственность.** Доводим начатое до результата.\n\n**Командная работа.** Успех общий.\n\n**Развитие.** Учимся каждый день.\n\n**Клиент в центре.** Решения принимаем с оглядкой на пользу для клиента.", "", []string{"культура"}, 1, admin)
	item(culture, "link", "Кодекс деловой этики", "Полный текст на внутреннем портале", "", "https://example.com/ethics-code", []string{"культура", "документы"}, 2, admin)
	item(sec, "text", "Пароли и двухфакторная аутентификация", "Как придумать надёжный пароль и включить второй фактор", "## Надёжный пароль\n\n- Не менее **12 символов**\n- Не используйте одинаковые пароли в разных сервисах\n- Храните пароли в менеджере паролей\n\n## Двухфакторная аутентификация\n\nВключите подтверждение входа в настройках профиля — это защитит учётную запись, даже если пароль утёк.\n\n```\nНикогда не сообщайте коды из SMS и приложений — даже сотрудникам поддержки.\n```", "", []string{"безопасность", "пароли"}, 1, admin)
	item(sec, "text", "Как распознать фишинг", "Признаки поддельных писем и что делать", "## Признаки фишинга\n\n1. Срочность и угрозы («аккаунт будет заблокирован»)\n2. Незнакомый или подозрительный адрес отправителя\n3. Ссылки, ведущие на чужие домены\n4. Вложения с неожиданными расширениями\n\n## Что делать\n\nНе переходите по ссылкам, перешлите письмо в службу ИБ: **security@corpnet.local**.", "", []string{"безопасность", "фишинг"}, 2, admin)
	item(sec, "video", "Безопасность в интернете для сотрудников", "Видеолекция, 12 минут", "", "https://rutube.ru/video/", []string{"безопасность", "видео"}, 3, admin)
	item(sys, "text", "Как заказать доступ к системе", "Заявка в службу поддержки за 3 шага", "## Заявка на доступ\n\n1. Откройте портал заявок.\n2. Выберите систему и роль.\n3. Согласуйте с руководителем.\n\nСрок исполнения — до 2 рабочих дней.", "", []string{"доступы"}, 1, admin)
	item(sys, "link", "Портал заявок", "Единая точка входа для обращений в ИТ", "", "https://example.com/helpdesk", []string{"доступы", "ссылки"}, 2, admin)
	item(mgr, "text", "Проведение встреч 1:1", "Структура и частота встреч с сотрудником", "## Встреча 1:1\n\n- Раз в 2 недели, 30–45 минут\n- Сначала слушаем сотрудника\n- Фиксируем договорённости\n\nНе переносите встречи без крайней необходимости.", "", []string{"руководителям"}, 1, elena)
	item(eval, "text", "Шкала оценки результатов", "Как оцениваем результаты по итогам периода", "## Шкала\n\n| Оценка | Описание |\n|---|---|\n| 5 | Результат значительно превышает ожидания |\n| 4 | Результат выше ожиданий |\n| 3 | Соответствует ожиданиям |\n| 2 | Ниже ожиданий |", "", []string{"оценка"}, 1, elena)
	item(devF, "text", "Стандарты кодирования", "Единые правила оформления кода", "## Основное\n\n- Названия — на английском\n- Функции короче 50 строк\n- Любое изменение — через pull request", "", []string{"код", "стандарты"}, 1, sergey)
	item(review, "text", "Чек-лист ревьюера", "На что смотреть при проверке", "## Чек-лист\n\n1. Логика и граничные случаи\n2. Тесты\n3. Читаемость и названия\n4. Безопасность", "", []string{"код", "ревью"}, 1, sergey)

	// ---- тесты
	tAd := folder("tests", 0, "Адаптация", "Тесты для новых сотрудников", "company", admin, 10)
	tSec := folder("tests", 0, "Информационная безопасность", "Обязательные тесты по безопасности", "company", admin, 20)
	grant(tAd, "user", elena, 3)   // HR отвечает за тесты адаптации
	grant(tSec, "user", sergey, 3) // IT-редактор — за тесты по безопасности
	grant(it, "user", sergey, 3)   // и за материалы по ИТ
	grant(adapt, "user", elena, 3) // HR ведёт материалы адаптации
	tMgr := folder("tests", 0, "Для руководителей", "Ограниченный доступ", "restricted", elena, 30)
	grant(tMgr, "department", dep["hr"], 1)
	grant(tMgr, "user", elena, 4)

	type tdef struct {
		folder           int64
		title, desc      string
		status           string
		pass             int
		limit, attempts  any
		shuffle, partial bool
		show             string
		author           int64
		qs               []qIn
	}
	sq := func(typ, text string, w float64, expl string, opts ...string) qIn {
		q := qIn{Type: typ, Text: text, Weight: w, Explanation: expl}
		for _, o := range opts {
			if typ == "text" {
				q.Answers = append(q.Answers, o)
				continue
			}
			c := strings.HasPrefix(o, "*")
			q.Options = append(q.Options, qOpt{Text: strings.TrimPrefix(o, "*"), Correct: c})
		}
		return q
	}
	tests := []tdef{
		{tAd, "Знакомство с компанией", "Проверьте, как вы запомнили основную информацию о компании.", "published", 70, nil, nil, false, false, "after_attempt", admin, []qIn{
			sq("single", "Как называется корпоративный портал компании?", 1, "Портал называется CorpNet.", "*CorpNet", "WorkSpace", "InfoHub", "Intranet+"),
			sq("single", "Куда обращаться по вопросам доступа к системам?", 1, "Заявку подают через портал заявок в службу поддержки.", "В бухгалтерию", "*В службу поддержки", "К генеральному директору"),
			sq("multiple", "Какие из перечисленных — ценности компании?", 2, "Открытость, ответственность и командная работа — ценности компании.", "*Открытость", "*Ответственность", "Скрытность", "*Командная работа"),
			sq("multiple", "Что нужно сделать в первую неделю работы?", 2, "", "*Познакомиться с командой", "*Пройти вводный инструктаж", "Взять отпуск", "*Настроить рабочую почту"),
			sq("text", "Как называется встреча руководителя с сотрудником один на один (формат)?", 1, "Формат называется «1:1».", "1:1", "один на один", "one-on-one"),
			sq("single", "Сколько рабочих дней обычно занимает исполнение заявки на доступ?", 1, "Срок исполнения — до 2 рабочих дней.", "1 день", "*До 2 рабочих дней", "Неделю", "Месяц"),
			sq("text", "Сколько основных ценностей у компании? (число)", 1, "Пять ценностей.", "5", "пять"),
		}},
		{tAd, "Охрана труда и пожарная безопасность", "Обязательный вводный тест. Ограничение по времени — 15 минут, три попытки.", "published", 80, 15, 3, true, false, "after_finish", admin, []qIn{
			sq("single", "Что нужно сделать при обнаружении возгорания в первую очередь?", 1, "Сначала сообщают о пожаре по телефону 101 (112) и оповещают людей.", "Попытаться потушить самостоятельно", "*Сообщить в пожарную охрану и оповестить людей", "Открыть окна"),
			sq("single", "Каким лифтом можно пользоваться при пожаре?", 1, "При пожаре лифтами пользоваться нельзя.", "Любым", "Только грузовым", "*Никаким"),
			sq("multiple", "Какие действия запрещены при эвакуации?", 2, "", "*Пользоваться лифтом", "Идти по эвакуационным знакам", "*Возвращаться за вещами", "*Бежать, толкая других"),
			sq("text", "По какому номеру вызывают пожарную охрану из мобильного телефона (единый номер)?", 1, "Единый номер экстренных служб — 112.", "112", "101"),
			sq("single", "Как часто проводится повторный инструктаж по охране труда?", 1, "", "Раз в месяц", "*Не реже одного раза в 6 месяцев", "Один раз за всю работу"),
		}},
		{tSec, "Основы кибербезопасности", "Пароли, фишинг и безопасная работа с почтой. Вопросы и ответы перемешиваются, за неполный ответ в вопросах с несколькими вариантами начисляются частичные баллы.", "published", 75, 20, nil, true, true, "after_attempt", admin, []qIn{
			sq("single", "Какой пароль самый надёжный?", 1, "Длинные фразы надёжнее коротких слов с цифрами.", "Qwerty123", "*Длинная фраза из нескольких случайных слов", "Дата рождения", "Имя кошки"),
			sq("multiple", "Признаки фишингового письма:", 3, "Срочность, чужие домены и неожиданные вложения — типичные признаки.", "*Требует срочно перейти по ссылке", "Приходит от коллеги из вашего отдела по известной теме", "*Ссылка ведёт на незнакомый домен", "*Неожиданное вложение .exe"),
			sq("single", "Что делать с подозрительным письмом?", 1, "Подозрительные письма пересылают в службу ИБ.", "Открыть вложение и проверить антивирусом", "*Переслать в службу информационной безопасности", "Ответить отправителю"),
			sq("multiple", "Что нужно для двухфакторной аутентификации?", 2, "", "*Пароль", "*Второй фактор (код из приложения или SMS)", "Номер паспорта"),
			sq("text", "Как называется атака, при которой злоумышленник выдаёт себя за доверенное лицо, чтобы получить данные? (одно слово)", 1, "Фишинг.", "фишинг", "phishing"),
			sq("single", "Можно ли сообщать код из SMS сотруднику поддержки?", 1, "Нет, коды подтверждения не сообщают никому.", "Да, если он представился", "*Нет, никогда", "Только по телефону"),
			sq("text", "Сколько символов минимум рекомендуется для пароля? (число)", 1, "Рекомендуемый минимум — 12 символов.", "12"),
		}},
		{tMgr, "Оценка персонала: тест для руководителей", "Черновик: проверка знаний процедуры оценки.", "draft", 70, nil, nil, false, false, "never", elena, []qIn{
			sq("single", "Как часто проводятся встречи 1:1?", 1, "Раз в две недели.", "Раз в год", "*Раз в 2 недели", "Никогда"),
			sq("single", "Какая оценка соответствует ожиданиям?", 1, "", "5", "4", "*3", "2"),
		}},
	}

	type seeded struct {
		id  int64
		def *tdef
		qs  []qIn
	}
	var seededTests []seeded
	for i := range tests {
		t := &tests[i]
		for j := range t.qs {
			if e := t.qs[j].normalize(); e != "" {
				panic(fmt.Sprintf("seed learning: %s / вопрос %d: %s", t.title, j+1, e))
			}
		}
		var maxScore float64
		for _, q := range t.qs {
			maxScore += q.Weight
		}
		tid := d.id(`INSERT INTO learn_tests (folder_id, title, description, status, pass_percent, time_limit_min, max_attempts, shuffle_questions, shuffle_answers, partial_credit, show_answers,
				sort, questions_count, max_score, author_id)
			VALUES ($1, $2, $3, $4, $5, $6::int, $7::int, $8, $8, $9, $10, $11, $12, $13, $14) RETURNING id`,
			t.folder, t.title, t.desc, t.status, t.pass, t.limit, t.attempts, t.shuffle, t.partial, t.show, i*10, len(t.qs), maxScore, t.author)
		for j, q := range t.qs {
			d.exec(`INSERT INTO learn_questions (test_id, sort, type, text, data, weight, explanation) VALUES ($1, $2, $3, $4, $5::jsonb, $6, $7)`,
				tid, j, q.Type, q.Text, string(q.data()), q.Weight, q.Explanation)
		}
		seededTests = append(seededTests, seeded{tid, t, t.qs})
	}

	// ---- попытки сотрудников (детерминированно): каждый второй-третий сотрудник проходил тесты
	pass := func(pct float64, t *tdef) bool { return pct >= float64(t.pass) }
	for ti, st := range seededTests {
		if st.def.status != "published" {
			continue
		}
		var qids []int64
		rows, err := d.tx.Query(d.ctx, `SELECT id FROM learn_questions WHERE test_id = $1 ORDER BY sort, id`, st.id)
		if err != nil {
			panic(err)
		}
		for rows.Next() {
			var id int64
			rows.Scan(&id)
			qids = append(qids, id)
		}
		rows.Close()
		var cnt, passed int
		var sum float64
		for u := 2; u < len(uid); u++ {
			if (u+ti)%3 == 0 {
				continue
			}
			tries := 1 + (u+ti)%3
			if st.def.attempts != nil && tries > 3 {
				tries = 3
			}
			for no := 1; no <= tries; no++ {
				// качество растёт с номером попытки
				quality := float64((u*7+ti*13+no*29)%100) / 100
				quality = quality*0.6 + float64(no)*0.15
				answers := map[string]any{}
				lt := &ltest{PassPercent: st.def.pass, PartialCredit: st.def.partial}
				details := map[string]qres{}
				var score, mx float64
				for k, q := range st.qs {
					good := float64((u*31+k*17+no*11)%100)/100 < quality
					var ans any
					switch q.Type {
					case "single":
						for _, o := range q.Options {
							if o.Correct == good {
								ans = o.ID
								break
							}
						}
					case "multiple":
						var ids []int
						for _, o := range q.Options {
							if o.Correct {
								ids = append(ids, o.ID)
							}
						}
						if !good && len(ids) > 1 {
							ids = ids[:len(ids)-1]
						} else if !good {
							ids = []int{q.Options[0].ID + 100}
						}
						ans = ids
					case "text":
						if good {
							ans = q.Answers[0]
						} else {
							ans = "не знаю"
						}
					}
					if (u+k+no)%23 == 0 { // пропущенный вопрос
						ans = nil
					}
					key := strconv.FormatInt(qids[k], 10)
					lq1 := lq{ID: qids[k], Type: q.Type, Options: q.Options, Answers: q.Answers, Weight: q.Weight}
					var raw json.RawMessage
					if ans != nil {
						answers[key] = ans
						raw, _ = json.Marshal(ans)
					}
					r := scoreQuestion(lt, lq1, raw)
					details[key] = r
					score += r.P
					mx += r.M
				}
				pct := 0.0
				if mx > 0 {
					pct = float64(int(score/mx*1000+0.5)) / 10
				}
				ab, _ := json.Marshal(answers)
				db, _ := json.Marshal(details)
				dur := 120 + (u*53+no*97)%900
				started := time.Now().Add(-time.Duration(1+(u*5+no*3+ti)%60) * 24 * time.Hour).Add(-time.Duration(u%9) * time.Hour)
				ok := pass(pct, st.def)
				d.exec(`INSERT INTO learn_attempts (test_id, user_id, dept_id, no, seed, started_at, finished_at, answers, details, score, max_score, percent, passed, duration_sec)
					VALUES ($1, $2, (SELECT department_id FROM users WHERE id = $2), $3, $4, $5, $5::timestamptz + make_interval(secs => $6::int), $7::jsonb, $8::jsonb, $9, $10, $11, $12, $13)`,
					st.id, uid[u], no, int64(u*1000+no), started, dur, string(ab), string(db), score, mx, pct, ok, dur)
				cnt++
				sum += pct
				if ok {
					passed++
				}
				if ok && no > 0 {
					break // после зачёта повторно обычно не проходят
				}
			}
		}
		d.exec(`UPDATE learn_tests SET attempts_count = $2, passed_count = $3, sum_percent = $4 WHERE id = $1`, st.id, cnt, passed, sum)
	}
	// прогресс по материалам
	d.exec(`INSERT INTO learn_progress (user_id, item_id, folder_id, opened_at, done_at)
		SELECT u.id, i.id, i.folder_id, now() - interval '1 hour' * (i.id % 50), CASE WHEN (u.id + i.id) % 3 <> 0 THEN now() - interval '1 hour' * (i.id % 30) END
		FROM users u JOIN learn_items i ON i.folder_id IN ($1, $2, $3) WHERE u.id = ANY($4::bigint[]) AND (u.id + i.id) % 4 <> 0`, week1, culture, sec, uid[:12])
}
