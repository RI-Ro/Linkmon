package server

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"net/mail"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"
)

// Раздел «Заявки»: схема формы, условия, проверка введённых данных ПО СНИМКУ схемы (версии типа).
//
// Файлы раздела:
//   requests.go          — маршруты, права, каталог, списки, карточка, экспорт
//   requests_schema.go   — схема формы, условия, серверная валидация, рабочие дни/часы
//   requests_flow.go     — движок маршрута (шаги, исполнители, замещение, решения, SLA)
//   requests_manage.go   — конструктор: типы, категории, версии, доступ, импорт/экспорт
//   requests_jobs.go     — напоминания, просрочка, эскалация, замещение «на лету»
//   seed_requests.go     — шаблоны из коробки

// ---------------------------------------------------------------- схема

type reqOpt struct {
	Value string `json:"value"`
	Label string `json:"label"`
}

type reqField struct {
	Key         string     `json:"key"`
	Type        string     `json:"type"`
	Label       string     `json:"label"`
	Hint        string     `json:"hint,omitempty"`
	Placeholder string     `json:"placeholder,omitempty"`
	Required    bool       `json:"required,omitempty"`
	Default     any        `json:"default,omitempty"` // значение либо {"profile":"full_name|job_title|department|phone|email"}
	Width       string     `json:"width,omitempty"`   // 1 | 1/2 | 1/3
	Options     []reqOpt   `json:"options,omitempty"`
	Multiple    bool       `json:"multiple,omitempty"`
	Min         any        `json:"min,omitempty"` // число; для дат — «YYYY-MM-DD» или «today»
	Max         any        `json:"max,omitempty"`
	MinLen      int        `json:"min_len,omitempty"`
	MaxLen      int        `json:"max_len,omitempty"`
	Pattern     string     `json:"pattern,omitempty"`
	PatternMsg  string     `json:"pattern_msg,omitempty"`
	Unit        string     `json:"unit,omitempty"`
	Accept      string     `json:"accept,omitempty"`
	MaxFiles    int        `json:"max_files,omitempty"`
	VisibleIf   *reqCond   `json:"visible_if,omitempty"`
	RequiredIf  *reqCond   `json:"required_if,omitempty"`
	Columns     []reqField `json:"columns,omitempty"` // для таблицы
	MinRows     int        `json:"min_rows,omitempty"`
	MaxRows     int        `json:"max_rows,omitempty"`
}

type reqSection struct {
	ID        string     `json:"id"`
	Title     string     `json:"title,omitempty"`
	Desc      string     `json:"desc,omitempty"`
	VisibleIf *reqCond   `json:"visible_if,omitempty"`
	Fields    []reqField `json:"fields"`
}

type reqSchema struct {
	Layout   string       `json:"layout,omitempty"` // single | wizard
	Sections []reqSection `json:"sections"`
}

type reqCondItem struct {
	Field string `json:"field"`
	Cmp   string `json:"cmp"`
	Value any    `json:"value,omitempty"`
}

type reqCond struct {
	Op    string        `json:"op,omitempty"` // and | or
	Items []reqCondItem `json:"items"`
}

var (
	reqKeyRe       = regexp.MustCompile(`^[a-z][a-z0-9_]{0,39}$`)
	reqColorRe     = regexp.MustCompile(`^#[0-9a-fA-F]{6}$`)
	reqPhoneRe     = regexp.MustCompile(`^\+?[0-9()\-\s.]{5,25}$`)
	reqFieldTypes  = map[string]bool{"text": true, "textarea": true, "number": true, "money": true, "date": true, "period": true, "time": true, "select": true, "radio": true, "checkboxes": true, "switch": true, "user": true, "department": true, "file": true, "phone": true, "email": true, "heading": true, "divider": true, "note": true, "table": true}
	reqDisplay     = map[string]bool{"heading": true, "divider": true, "note": true}
	reqTableColTyp = map[string]bool{"text": true, "number": true, "money": true, "date": true, "select": true, "switch": true}
	reqCmps        = map[string]bool{"eq": true, "ne": true, "gt": true, "gte": true, "lt": true, "lte": true, "contains": true, "in": true, "empty": true, "notempty": true}
)

func (f *reqField) isDisplay() bool { return reqDisplay[f.Type] }

// fields обходит все поля схемы (без колонок таблиц).
func (sc *reqSchema) fields() []*reqField {
	var out []*reqField
	for i := range sc.Sections {
		for j := range sc.Sections[i].Fields {
			out = append(out, &sc.Sections[i].Fields[j])
		}
	}
	return out
}

func parseSchema(raw []byte) (*reqSchema, error) {
	var sc reqSchema
	if err := json.Unmarshal(raw, &sc); err != nil {
		return nil, fmt.Errorf("схема формы повреждена")
	}
	return &sc, nil
}

// ---------------------------------------------------------------- условия

// reqValKey приводит значение к строке для сравнения: {id,name} → id, bool → true/false, число без хвоста.
func reqValKey(v any) string {
	switch x := v.(type) {
	case nil:
		return ""
	case string:
		return x
	case bool:
		if x {
			return "true"
		}
		return "false"
	case float64:
		return strconv.FormatFloat(x, 'f', -1, 64)
	case int:
		return strconv.Itoa(x)
	case int64:
		return strconv.FormatInt(x, 10)
	case map[string]any:
		if id, ok := x["id"]; ok {
			return reqValKey(id)
		}
		if id, ok := x["value"]; ok {
			return reqValKey(id)
		}
		b, _ := json.Marshal(x)
		return string(b)
	}
	b, _ := json.Marshal(v)
	return string(b)
}

func reqIsEmpty(v any) bool {
	switch x := v.(type) {
	case nil:
		return true
	case string:
		return strings.TrimSpace(x) == ""
	case []any:
		return len(x) == 0
	case map[string]any:
		if _, ok := x["from"]; ok {
			return reqValKey(x["from"]) == "" && reqValKey(x["to"]) == ""
		}
		return len(x) == 0
	}
	return false
}

func reqFloat(v any) (float64, bool) {
	switch x := v.(type) {
	case float64:
		return x, true
	case int:
		return float64(x), true
	case int64:
		return float64(x), true
	case string:
		f, err := strconv.ParseFloat(strings.ReplaceAll(strings.TrimSpace(x), ",", "."), 64)
		return f, err == nil && strings.TrimSpace(x) != ""
	}
	return 0, false
}

// lookup достаёт значение поля; «period.days», «period.workdays», «period.from», «period.to» — части периода.
func reqLookup(data map[string]any, path string) any {
	key, part, _ := strings.Cut(path, ".")
	v := data[key]
	if part == "" {
		return v
	}
	if m, ok := v.(map[string]any); ok {
		return m[part]
	}
	return nil
}

func (c *reqCond) eval(data map[string]any) bool {
	if c == nil || len(c.Items) == 0 {
		return true
	}
	or := c.Op == "or"
	for _, it := range c.Items {
		r := it.eval(data)
		if or && r {
			return true
		}
		if !or && !r {
			return false
		}
	}
	return !or
}

func (it reqCondItem) eval(data map[string]any) bool {
	v := reqLookup(data, it.Field)
	switch it.Cmp {
	case "empty":
		return reqIsEmpty(v)
	case "notempty":
		return !reqIsEmpty(v)
	case "eq", "ne":
		eq := false
		if arr, ok := v.([]any); ok {
			for _, e := range arr {
				if reqValKey(e) == reqValKey(it.Value) {
					eq = true
				}
			}
		} else {
			eq = reqValKey(v) == reqValKey(it.Value)
		}
		return eq == (it.Cmp == "eq")
	case "in":
		var list []string
		switch x := it.Value.(type) {
		case []any:
			for _, e := range x {
				list = append(list, reqValKey(e))
			}
		case string:
			for _, e := range strings.Split(x, ",") {
				list = append(list, strings.TrimSpace(e))
			}
		}
		check := func(s string) bool {
			for _, e := range list {
				if e == s {
					return true
				}
			}
			return false
		}
		if arr, ok := v.([]any); ok {
			for _, e := range arr {
				if check(reqValKey(e)) {
					return true
				}
			}
			return false
		}
		return check(reqValKey(v))
	case "contains":
		if arr, ok := v.([]any); ok {
			for _, e := range arr {
				if reqValKey(e) == reqValKey(it.Value) {
					return true
				}
			}
			return false
		}
		return strings.Contains(strings.ToLower(reqValKey(v)), strings.ToLower(reqValKey(it.Value)))
	case "gt", "gte", "lt", "lte":
		a, ok1 := reqFloat(v)
		b, ok2 := reqFloat(it.Value)
		var cmp int
		switch {
		case ok1 && ok2:
			cmp = 0
			if a < b {
				cmp = -1
			} else if a > b {
				cmp = 1
			}
		case !reqIsEmpty(v) && !ok1 && !ok2: // даты и строки ISO
			cmp = strings.Compare(reqValKey(v), reqValKey(it.Value))
		default:
			return false
		}
		switch it.Cmp {
		case "gt":
			return cmp > 0
		case "gte":
			return cmp >= 0
		case "lt":
			return cmp < 0
		}
		return cmp <= 0
	}
	return false
}

// ---------------------------------------------------------------- рабочие дни и часы

func (s *Server) reqLoc() *time.Location {
	if s.cfg.TZ != "" {
		if l, err := time.LoadLocation(s.cfg.TZ); err == nil {
			return l
		}
	}
	return time.Local
}

func reqIsWorkDay(t time.Time) bool {
	wd := t.Weekday()
	return wd != time.Saturday && wd != time.Sunday
}

// reqCountDays — календарные дни периода (включительно) и рабочие (пн–пт).
func reqCountDays(from, to time.Time) (cal, work int) {
	for d := from; !d.After(to); d = d.AddDate(0, 0, 1) {
		cal++
		if reqIsWorkDay(d) {
			work++
		}
	}
	return
}

const (
	reqWorkStartH = 9
	reqWorkEndH   = 18
)

// reqAddWorkHours прибавляет рабочие часы (пн–пт, 9:00–18:00 по часовому поясу портала).
func reqAddWorkHours(t time.Time, hours float64) time.Time {
	mins := int(math.Round(hours * 60))
	norm := func(t time.Time) time.Time { // ближайший рабочий момент
		for {
			if !reqIsWorkDay(t) {
				t = time.Date(t.Year(), t.Month(), t.Day()+1, reqWorkStartH, 0, 0, 0, t.Location())
				continue
			}
			start := time.Date(t.Year(), t.Month(), t.Day(), reqWorkStartH, 0, 0, 0, t.Location())
			end := time.Date(t.Year(), t.Month(), t.Day(), reqWorkEndH, 0, 0, 0, t.Location())
			if t.Before(start) {
				return start
			}
			if !t.Before(end) {
				t = time.Date(t.Year(), t.Month(), t.Day()+1, reqWorkStartH, 0, 0, 0, t.Location())
				continue
			}
			return t
		}
	}
	t = norm(t)
	for mins > 0 {
		end := time.Date(t.Year(), t.Month(), t.Day(), reqWorkEndH, 0, 0, 0, t.Location())
		left := int(end.Sub(t).Minutes())
		if mins <= left {
			return t.Add(time.Duration(mins) * time.Minute)
		}
		mins -= left
		t = norm(end)
	}
	return t
}

func reqAddWorkDays(t time.Time, n int) time.Time {
	for n > 0 {
		t = t.AddDate(0, 0, 1)
		if reqIsWorkDay(t) {
			n--
		}
	}
	return t
}

// slaDue — срок от момента from. unit: h | wh | d | wd.
func (s *Server) slaDue(from time.Time, value int, unit string) *time.Time {
	if value <= 0 {
		return nil
	}
	from = from.In(s.reqLoc())
	var t time.Time
	switch unit {
	case "h":
		t = from.Add(time.Duration(value) * time.Hour)
	case "wh":
		t = reqAddWorkHours(from, float64(value))
	case "d":
		t = from.AddDate(0, 0, value)
	default:
		t = reqAddWorkDays(from, value)
		if !reqIsWorkDay(from) || from.Hour() < reqWorkStartH || from.Hour() >= reqWorkEndH {
			t = time.Date(t.Year(), t.Month(), t.Day(), reqWorkEndH, 0, 0, 0, t.Location())
		}
	}
	return &t
}

// ---------------------------------------------------------------- проверка схемы при сохранении типа

func (s *Server) checkSchema(sc *reqSchema) error {
	if sc.Layout != "" && sc.Layout != "single" && sc.Layout != "wizard" {
		return badReq("Схема: неизвестный режим отображения")
	}
	if len(sc.Sections) == 0 || len(sc.Sections) > 30 {
		return badReq("Схема: от 1 до 30 секций")
	}
	keys := map[string]bool{}
	secIDs := map[string]bool{}
	total := 0
	for i := range sc.Sections {
		sec := &sc.Sections[i]
		if sec.ID == "" {
			sec.ID = "s" + strconv.Itoa(i+1)
		}
		if secIDs[sec.ID] {
			return badReq("Схема: повторяется идентификатор секции " + sec.ID)
		}
		secIDs[sec.ID] = true
		if sec.Fields == nil {
			sec.Fields = []reqField{}
		}
		for j := range sec.Fields {
			f := &sec.Fields[j]
			total++
			if err := checkField(f, false); err != nil {
				return err
			}
			if !f.isDisplay() || f.Key != "" {
				if f.Key == "" {
					return badReq("Поле «" + f.Label + "»: не задан ключ")
				}
				if keys[f.Key] {
					return badReq("Схема: ключ «" + f.Key + "» повторяется")
				}
				keys[f.Key] = true
			}
		}
	}
	if total > 150 {
		return badReq("Схема: не более 150 полей")
	}
	// условия ссылаются на существующие поля
	check := func(c *reqCond, where string) error {
		if c == nil {
			return nil
		}
		if c.Op != "" && c.Op != "and" && c.Op != "or" {
			return badReq(where + ": неизвестная логика условия")
		}
		for _, it := range c.Items {
			base, _, _ := strings.Cut(it.Field, ".")
			if !keys[base] {
				return badReq(where + ": условие ссылается на неизвестное поле «" + it.Field + "»")
			}
			if !reqCmps[it.Cmp] {
				return badReq(where + ": неизвестная операция сравнения")
			}
		}
		return nil
	}
	for i := range sc.Sections {
		if err := check(sc.Sections[i].VisibleIf, "Секция «"+sc.Sections[i].Title+"»"); err != nil {
			return err
		}
		for _, f := range sc.Sections[i].Fields {
			if err := check(f.VisibleIf, "Поле «"+f.Label+"»"); err != nil {
				return err
			}
			if err := check(f.RequiredIf, "Поле «"+f.Label+"»"); err != nil {
				return err
			}
		}
	}
	return nil
}

func checkField(f *reqField, col bool) error {
	f.Label = strings.TrimSpace(f.Label)
	if !reqFieldTypes[f.Type] {
		return badReq("Поле «" + f.Label + "»: неизвестный тип «" + f.Type + "»")
	}
	if col && !reqTableColTyp[f.Type] {
		return badReq("Колонка таблицы «" + f.Label + "»: тип не поддерживается")
	}
	if f.Key != "" && !reqKeyRe.MatchString(f.Key) {
		return badReq("Ключ поля «" + f.Label + "»: латиница, цифры и _, начинается с буквы, до 40 символов")
	}
	if f.Label == "" && f.Type != "divider" {
		return badReq("У каждого поля должна быть подпись")
	}
	if utf8.RuneCountInString(f.Label) > 300 || utf8.RuneCountInString(f.Hint) > 2000 || utf8.RuneCountInString(f.Placeholder) > 200 {
		return badReq("Поле «" + f.Label + "»: слишком длинная подпись, подсказка или плейсхолдер")
	}
	switch f.Width {
	case "", "1", "1/2", "1/3":
	default:
		return badReq("Поле «" + f.Label + "»: ширина 1, 1/2 или 1/3")
	}
	if f.Pattern != "" {
		if len(f.Pattern) > 300 {
			return badReq("Поле «" + f.Label + "»: слишком длинное регулярное выражение")
		}
		if _, err := regexp.Compile(f.Pattern); err != nil {
			return badReq("Поле «" + f.Label + "»: некорректное регулярное выражение")
		}
	}
	switch f.Type {
	case "select", "radio", "checkboxes":
		if len(f.Options) == 0 || len(f.Options) > 200 {
			return badReq("Поле «" + f.Label + "»: нужно от 1 до 200 вариантов")
		}
		seen := map[string]bool{}
		for i := range f.Options {
			o := &f.Options[i]
			o.Label = strings.TrimSpace(o.Label)
			if o.Value == "" {
				o.Value = o.Label
			}
			if o.Label == "" || seen[o.Value] {
				return badReq("Поле «" + f.Label + "»: варианты не должны быть пустыми или повторяться")
			}
			seen[o.Value] = true
		}
	case "table":
		if col {
			return badReq("Таблица внутри таблицы не поддерживается")
		}
		if len(f.Columns) == 0 || len(f.Columns) > 12 {
			return badReq("Таблица «" + f.Label + "»: от 1 до 12 колонок")
		}
		seen := map[string]bool{}
		for i := range f.Columns {
			c := &f.Columns[i]
			if err := checkField(c, true); err != nil {
				return err
			}
			if c.Key == "" || seen[c.Key] {
				return badReq("Таблица «" + f.Label + "»: у колонок должны быть уникальные ключи")
			}
			seen[c.Key] = true
		}
	}
	return nil
}

// ---------------------------------------------------------------- проверка введённых данных

// reqProfile — данные заявителя для значений «из профиля».
type reqUserRef struct {
	ID   int64  `json:"id"`
	Name string `json:"name"`
}

type reqValidator struct {
	s       *Server
	schema  *reqSchema
	loc     *time.Location
	today   string
	userIDs map[int64]string // кэш найденных людей
	deptIDs map[int64]string
	files   map[int64]reqFileRef
	errs    map[string]string
	fileIDs []int64 // файлы, которые нужно привязать к заявке
}

type reqFileRef struct {
	ID    int64  `json:"id"`
	Name  string `json:"name"`
	Size  int64  `json:"size"`
	Mime  string `json:"mime"`
	Owner int64  `json:"-"`
}

// reqFieldErrors — ошибки проверки по ключам полей (таблицы: «key.3.col»).
type reqFieldErrors map[string]string

func (e reqFieldErrors) Error() string {
	keys := make([]string, 0, len(e))
	for k := range e {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	if len(keys) == 0 {
		return "Проверьте заполнение формы"
	}
	return e[keys[0]]
}

// validateData проверяет данные по снимку схемы и возвращает нормализованные данные (скрытые поля отброшены, значения приведены
// к каноническому виду, периоды пересчитаны, люди/подразделения/файлы дополнены названиями). draft — обязательность не проверяется.
func (s *Server) validateReqData(ctx context.Context, sc *reqSchema, in map[string]any, author int64, existingFiles map[int64]bool, draft bool) (map[string]any, []int64, reqFieldErrors, error) {
	v := &reqValidator{s: s, schema: sc, loc: s.reqLoc(), userIDs: map[int64]string{}, deptIDs: map[int64]string{}, files: map[int64]reqFileRef{}, errs: reqFieldErrors{}}
	v.today = time.Now().In(v.loc).Format("2006-01-02")
	out := map[string]any{}
	// 1) предварительные значения для условий: «сырые» (после нормализации ниже условия считаются по нормализованным)
	// Проходим поля по порядку: условие поля может ссылаться только на уже нормализованные ранее значения; чтобы не зависеть от порядка,
	// сначала нормализуем всё без проверки обязательности, затем вычисляем видимость и проверяем обязательность.
	norm := map[string]any{}
	problems := map[string]string{}
	for _, f := range sc.fields() {
		if f.isDisplay() {
			continue
		}
		raw, present := in[f.Key]
		if !present || reqIsEmpty(raw) {
			continue
		}
		val, msg, err := v.normalize(ctx, f, raw, author, existingFiles, draft)
		if err != nil {
			return nil, nil, nil, err
		}
		if msg != "" {
			problems[f.Key] = msg
			continue
		}
		if val != nil && !reqIsEmpty(val) {
			norm[f.Key] = val
		}
	}
	for _, sec := range sc.Sections {
		secVisible := sec.VisibleIf.eval(norm)
		for _, f := range sec.Fields {
			if f.isDisplay() {
				continue
			}
			vis := secVisible && f.VisibleIf.eval(norm)
			if !vis {
				continue
			}
			if msg, bad := problems[f.Key]; bad {
				v.errs[f.Key] = msg
				continue
			}
			val, has := norm[f.Key]
			if has {
				out[f.Key] = val
				continue
			}
			if !draft && (f.Required || (f.RequiredIf != nil && f.RequiredIf.eval(norm))) {
				v.errs[f.Key] = "Заполните поле «" + f.Label + "»"
			}
		}
	}
	// таблица: минимум строк при обязательности уже проверен выше; нормализатор таблицы вернул строки
	return out, v.fileIDs, v.errs, nil
}

func reqRuneLen(s string) int { return utf8.RuneCountInString(s) }

// normalize приводит значение к каноническому виду. Возвращает (значение, сообщение об ошибке, системная ошибка).
func (v *reqValidator) normalize(ctx context.Context, f *reqField, raw any, author int64, existingFiles map[int64]bool, draft bool) (any, string, error) {
	lbl := "«" + f.Label + "»"
	switch f.Type {
	case "text", "textarea", "phone", "email":
		str, ok := raw.(string)
		if !ok {
			return nil, "Поле " + lbl + ": ожидается текст", nil
		}
		str = strings.TrimSpace(str)
		if str == "" {
			return nil, "", nil
		}
		max := f.MaxLen
		if max <= 0 || max > 20000 {
			max = 500
			if f.Type == "textarea" {
				max = 10000
			}
		}
		if reqRuneLen(str) > max {
			return nil, fmt.Sprintf("Поле %s: не более %d символов", lbl, max), nil
		}
		if f.MinLen > 0 && reqRuneLen(str) < f.MinLen {
			return nil, fmt.Sprintf("Поле %s: не менее %d символов", lbl, f.MinLen), nil
		}
		if f.Type == "email" {
			if a, err := mail.ParseAddress(str); err != nil || a.Address != str || len(str) > 254 {
				return nil, "Поле " + lbl + ": укажите корректный email", nil
			}
		}
		if f.Type == "phone" && !reqPhoneRe.MatchString(str) {
			return nil, "Поле " + lbl + ": укажите корректный телефон", nil
		}
		if f.Pattern != "" {
			if re, err := regexp.Compile(f.Pattern); err == nil && !re.MatchString(str) {
				m := f.PatternMsg
				if m == "" {
					m = "Поле " + lbl + ": значение не соответствует формату"
				}
				return nil, m, nil
			}
		}
		return str, "", nil
	case "number", "money":
		n, ok := reqFloat(raw)
		if !ok || math.IsNaN(n) || math.IsInf(n, 0) || math.Abs(n) > 1e15 {
			return nil, "Поле " + lbl + ": ожидается число", nil
		}
		if f.Type == "money" {
			n = math.Round(n*100) / 100
		}
		if mn, ok := reqFloat(f.Min); ok && n < mn {
			return nil, fmt.Sprintf("Поле %s: не меньше %s", lbl, strconv.FormatFloat(mn, 'f', -1, 64)), nil
		}
		if mx, ok := reqFloat(f.Max); ok && n > mx {
			return nil, fmt.Sprintf("Поле %s: не больше %s", lbl, strconv.FormatFloat(mx, 'f', -1, 64)), nil
		}
		return n, "", nil
	case "date":
		str, ok := raw.(string)
		if !ok {
			return nil, "Поле " + lbl + ": ожидается дата", nil
		}
		d, err := time.Parse("2006-01-02", str)
		if err != nil {
			return nil, "Поле " + lbl + ": укажите корректную дату", nil
		}
		if msg := v.dateBounds(f, lbl, d); msg != "" {
			return nil, msg, nil
		}
		return str, "", nil
	case "time":
		str, ok := raw.(string)
		if !ok {
			return nil, "Поле " + lbl + ": ожидается время", nil
		}
		if _, err := time.Parse("15:04", str); err != nil {
			return nil, "Поле " + lbl + ": укажите время в формате ЧЧ:ММ", nil
		}
		return str, "", nil
	case "period":
		m, ok := raw.(map[string]any)
		if !ok {
			return nil, "Поле " + lbl + ": ожидается период", nil
		}
		fs, ts := reqValKey(m["from"]), reqValKey(m["to"])
		if fs == "" && ts == "" {
			return nil, "", nil
		}
		from, e1 := time.Parse("2006-01-02", fs)
		to, e2 := time.Parse("2006-01-02", ts)
		if e1 != nil || e2 != nil {
			return nil, "Поле " + lbl + ": укажите даты начала и окончания", nil
		}
		if to.Before(from) {
			return nil, "Поле " + lbl + ": окончание раньше начала", nil
		}
		if msg := v.dateBounds(f, lbl, from); msg != "" {
			return nil, msg, nil
		}
		cal, work := reqCountDays(from, to)
		if mx, ok := reqFloat(f.Max); ok && float64(cal) > mx {
			return nil, fmt.Sprintf("Поле %s: период не более %d дн.", lbl, int(mx)), nil
		}
		if cal > 3660 {
			return nil, "Поле " + lbl + ": слишком длинный период", nil
		}
		return map[string]any{"from": fs, "to": ts, "days": float64(cal), "workdays": float64(work)}, "", nil
	case "select", "radio":
		str := reqValKey(raw)
		for _, o := range f.Options {
			if o.Value == str {
				return str, "", nil
			}
		}
		return nil, "Поле " + lbl + ": выберите значение из списка", nil
	case "checkboxes":
		arr, ok := raw.([]any)
		if !ok {
			return nil, "Поле " + lbl + ": ожидается список значений", nil
		}
		set := map[string]bool{}
		for _, o := range f.Options {
			set[o.Value] = true
		}
		out := []any{}
		seen := map[string]bool{}
		for _, e := range arr {
			k := reqValKey(e)
			if !set[k] {
				return nil, "Поле " + lbl + ": недопустимое значение", nil
			}
			if !seen[k] {
				seen[k] = true
				out = append(out, k)
			}
		}
		return out, "", nil
	case "switch":
		b, ok := raw.(bool)
		if !ok {
			return nil, "Поле " + lbl + ": ожидается да/нет", nil
		}
		return b, "", nil
	case "user":
		ids := []int64{}
		switch x := raw.(type) {
		case []any:
			for _, e := range x {
				ids = append(ids, reqRefID(e))
			}
		default:
			ids = append(ids, reqRefID(raw))
		}
		if len(ids) == 0 || (!f.Multiple && len(ids) > 1) || len(ids) > 50 {
			return nil, "Поле " + lbl + ": выберите сотрудника", nil
		}
		out := []any{}
		for _, id := range ids {
			if id <= 0 {
				return nil, "Поле " + lbl + ": выберите сотрудника", nil
			}
			name, ok := v.userIDs[id]
			if !ok {
				err := v.s.db.QueryRow(ctx, `SELECT full_name FROM users WHERE id = $1 AND NOT blocked`, id).Scan(&name)
				if err != nil {
					return nil, "Поле " + lbl + ": сотрудник не найден", nil
				}
				v.userIDs[id] = name
			}
			out = append(out, map[string]any{"id": float64(id), "name": name})
		}
		if !f.Multiple {
			return out[0], "", nil
		}
		return out, "", nil
	case "department":
		id := reqRefID(raw)
		if id <= 0 {
			return nil, "Поле " + lbl + ": выберите подразделение", nil
		}
		name, ok := v.deptIDs[id]
		if !ok {
			if err := v.s.db.QueryRow(ctx, `SELECT name FROM departments WHERE id = $1`, id).Scan(&name); err != nil {
				return nil, "Поле " + lbl + ": подразделение не найдено", nil
			}
			v.deptIDs[id] = name
		}
		return map[string]any{"id": float64(id), "name": name}, "", nil
	case "file":
		arr, ok := raw.([]any)
		if !ok {
			return nil, "Поле " + lbl + ": ожидается список файлов", nil
		}
		mx := f.MaxFiles
		if mx <= 0 || mx > 20 {
			mx = 10
		}
		if !f.Multiple && mx > 1 && f.MaxFiles == 0 {
			mx = 1
		}
		if len(arr) > mx {
			return nil, fmt.Sprintf("Поле %s: не более %d файлов", lbl, mx), nil
		}
		out := []any{}
		for _, e := range arr {
			id := reqRefID(e)
			if id <= 0 {
				return nil, "Поле " + lbl + ": некорректный файл", nil
			}
			ref, err := v.file(ctx, id, author, existingFiles)
			if err != nil {
				return nil, "Поле " + lbl + ": " + err.Error(), nil
			}
			if f.Accept != "" && !reqAcceptOK(f.Accept, ref.Name, ref.Mime) {
				return nil, "Поле " + lbl + ": файл «" + ref.Name + "» недопустимого типа", nil
			}
			out = append(out, map[string]any{"id": float64(ref.ID), "name": ref.Name, "size": float64(ref.Size), "mime": ref.Mime})
			v.fileIDs = append(v.fileIDs, id)
		}
		return out, "", nil
	case "table":
		arr, ok := raw.([]any)
		if !ok {
			return nil, "Поле " + lbl + ": ожидается таблица", nil
		}
		mx := f.MaxRows
		if mx <= 0 || mx > 200 {
			mx = 100
		}
		if len(arr) > mx {
			return nil, fmt.Sprintf("Таблица %s: не более %d строк", lbl, mx), nil
		}
		rows := []any{}
		for ri, rr := range arr {
			rm, ok := rr.(map[string]any)
			if !ok {
				return nil, "Таблица " + lbl + ": некорректная строка", nil
			}
			row := map[string]any{}
			any_ := false
			for ci := range f.Columns {
				c := &f.Columns[ci]
				cv, present := rm[c.Key]
				if !present || reqIsEmpty(cv) {
					if c.Required && !draft {
						v.errs[fmt.Sprintf("%s.%d.%s", f.Key, ri, c.Key)] = fmt.Sprintf("Таблица %s, строка %d: заполните «%s»", lbl, ri+1, c.Label)
					}
					continue
				}
				val, msg, err := v.normalize(ctx, c, cv, author, existingFiles, draft)
				if err != nil {
					return nil, "", err
				}
				if msg != "" {
					v.errs[fmt.Sprintf("%s.%d.%s", f.Key, ri, c.Key)] = fmt.Sprintf("Строка %d: %s", ri+1, msg)
					continue
				}
				if val != nil {
					row[c.Key] = val
					any_ = true
				}
			}
			if any_ || len(row) > 0 {
				rows = append(rows, row)
			}
		}
		if f.MinRows > 0 && len(rows) < f.MinRows && !draft {
			return nil, fmt.Sprintf("Таблица %s: минимум строк — %d", lbl, f.MinRows), nil
		}
		if len(rows) == 0 {
			return nil, "", nil
		}
		return rows, "", nil
	}
	return nil, "", nil
}

func (v *reqValidator) dateBounds(f *reqField, lbl string, d time.Time) string {
	bound := func(b any) (time.Time, bool) {
		s, ok := b.(string)
		if !ok || s == "" {
			return time.Time{}, false
		}
		if s == "today" {
			s = v.today
		}
		t, err := time.Parse("2006-01-02", s)
		return t, err == nil
	}
	if t, ok := bound(f.Min); ok && d.Before(t) {
		return "Поле " + lbl + ": не раньше " + t.Format("02.01.2006")
	}
	if t, ok := bound(f.Max); ok && d.After(t) {
		return "Поле " + lbl + ": не позже " + t.Format("02.01.2006")
	}
	return ""
}

func reqRefID(v any) int64 {
	switch x := v.(type) {
	case float64:
		return int64(x)
	case string:
		n, _ := strconv.ParseInt(x, 10, 64)
		return n
	case map[string]any:
		return reqRefID(x["id"])
	}
	return 0
}

func reqAcceptOK(accept, name, mime string) bool {
	name = strings.ToLower(name)
	for _, a := range strings.Split(strings.ToLower(accept), ",") {
		a = strings.TrimSpace(a)
		switch {
		case a == "":
		case strings.HasPrefix(a, "."):
			if strings.HasSuffix(name, a) {
				return true
			}
		case strings.HasSuffix(a, "/*"):
			if strings.HasPrefix(strings.ToLower(mime), strings.TrimSuffix(a, "*")) {
				return true
			}
		case strings.EqualFold(a, mime):
			return true
		}
	}
	return false
}

// file проверяет, что файл загружен автором (контекст «request») и либо ещё не привязан, либо уже принадлежит этой заявке.
func (v *reqValidator) file(ctx context.Context, id, author int64, existing map[int64]bool) (reqFileRef, error) {
	if r, ok := v.files[id]; ok {
		return r, nil
	}
	var r reqFileRef
	var owner *int64
	var kctx string
	var linked bool
	err := v.s.db.QueryRow(ctx, `SELECT f.id, f.name, f.size, f.mime, f.owner_id, f.context, EXISTS (SELECT 1 FROM req_files rf WHERE rf.file_id = f.id)
		FROM files f WHERE f.id = $1`, id).Scan(&r.ID, &r.Name, &r.Size, &r.Mime, &owner, &kctx, &linked)
	if err != nil || kctx != "request" {
		return r, fmt.Errorf("файл не найден")
	}
	if existing[id] { // уже привязан к этой заявке
		v.files[id] = r
		return r, nil
	}
	if owner == nil || *owner != author || linked {
		return r, fmt.Errorf("файл недоступен")
	}
	v.files[id] = r
	return r, nil
}
