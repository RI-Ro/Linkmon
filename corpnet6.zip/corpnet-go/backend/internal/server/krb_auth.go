package server

import (
	"context"
	"errors"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"corpnet/internal/krb"

	"github.com/go-ldap/ldap/v3"
)

// Kerberos (SPNEGO/Negotiate): бесшовный вход доменных пользователей. Если Kerberos выключен, не настроен, у браузера нет
// билета или сопоставить пользователя не удалось — фронт просто показывает обычную форму пароля (локальный/LDAP).
//
// Схема: GET /api/auth/negotiate
//   нет Authorization: Negotiate …  → 401 + «WWW-Authenticate: Negotiate» (пустое тело): браузер в домене повторит запрос с билетом;
//   Kerberos выключен/не настроен    → 401 без challenge и без тела (X-Auth-Kerberos: off|error), браузер ничего не пробует;
//   токен не прошёл проверку         → 401 JSON {error, code} БЕЗ challenge (иначе браузер зациклится / покажет диалог);
//   пользователь заблокирован/не найден → 403 JSON;  успех → 200 + cookie сессии, как у обычного входа.
// Параметры — переменные KRB5_*, часть можно переопределить в админке (таблица krb_settings).

const krbCacheTTL = 10 * time.Second

// krbCfg — действующая конфигурация (env + переопределения из БД).
type krbCfg struct {
	Enabled    bool
	Keytab     string
	SPN        string
	ConfPath   string
	Realms     []string
	Skew       time.Duration
	UserMap    string
	AutoCreate bool
}

func (c *krbCfg) kc() krb.Config {
	return krb.Config{Keytab: c.Keytab, ServicePrincipal: c.SPN, Realms: c.Realms, ConfPath: c.ConfPath, ClockSkew: c.Skew}
}

func (c *krbCfg) key() string {
	return c.Keytab + "|" + c.SPN + "|" + strings.Join(c.Realms, ",") + "|" + c.Skew.String()
}

// krbOverrides — строка krb_settings.
type krbOverrides struct {
	Enabled     *bool
	UserMap     *string
	AutoCreate  *bool
	SkewSec     *int
	OKCount     int64
	LastOKAt    *time.Time
	LastOKUser  string
	LastOKIP    string
	LastErrorAt *time.Time
	LastError   string
}

// krbRT — состояние процесса (один Server на процесс): кэш настроек и валидатор с keytab.
type krbRT struct {
	mu     sync.Mutex
	cfgAt  time.Time
	cfg    krbCfg
	ov     krbOverrides
	vKey   string
	v      *krb.Validator
	vErr   error
	vErrAt time.Time
}

var krbState krbRT

func krbEnvCfg() krbCfg {
	c := krbCfg{
		Enabled:    envBool("KRB5_ENABLED", false),
		Keytab:     strings.TrimSpace(env("KRB5_KEYTAB", "")),
		SPN:        strings.TrimSpace(env("KRB5_SERVICE_PRINCIPAL", "")),
		ConfPath:   strings.TrimSpace(env("KRB5_CONF", "")),
		Skew:       time.Duration(envInt("KRB5_CLOCK_SKEW_SEC", 300)) * time.Second,
		UserMap:    krb.NormalizeMap(env("KRB5_USER_MAP", krb.MapSAM)),
		AutoCreate: envBool("KRB5_AUTO_CREATE", false),
	}
	for _, r := range strings.Split(env("KRB5_REALM", ""), ",") {
		if r = strings.TrimSpace(r); r != "" {
			c.Realms = append(c.Realms, r)
		}
	}
	if c.Skew < 30*time.Second || c.Skew > time.Hour {
		c.Skew = 5 * time.Minute
	}
	return c
}

func (s *Server) krbLoadOverrides(ctx context.Context) (krbOverrides, error) {
	var o krbOverrides
	err := s.db.QueryRow(ctx, `SELECT enabled, user_map, auto_create, clock_skew_sec, ok_count, last_ok_at, last_ok_user, last_ok_ip,
		last_error_at, last_error FROM krb_settings WHERE id = 1`).Scan(&o.Enabled, &o.UserMap, &o.AutoCreate, &o.SkewSec, &o.OKCount, &o.LastOKAt,
		&o.LastOKUser, &o.LastOKIP, &o.LastErrorAt, &o.LastError)
	return o, err
}

// krbConfig возвращает действующую конфигурацию (кэш на 10 секунд; админка сбрасывает кэш этого экземпляра).
func (s *Server) krbConfig(ctx context.Context) (krbCfg, krbOverrides) {
	st := &krbState
	st.mu.Lock()
	defer st.mu.Unlock()
	if time.Since(st.cfgAt) < krbCacheTTL && !st.cfgAt.IsZero() {
		return st.cfg, st.ov
	}
	cfg := krbEnvCfg()
	ov, err := s.krbLoadOverrides(ctx)
	if err != nil {
		s.log.Warn("kerberos: settings read failed", "err", err)
		ov = krbOverrides{}
	}
	if ov.Enabled != nil {
		cfg.Enabled = *ov.Enabled
	}
	if ov.UserMap != nil {
		cfg.UserMap = krb.NormalizeMap(*ov.UserMap)
	}
	if ov.AutoCreate != nil {
		cfg.AutoCreate = *ov.AutoCreate
	}
	if ov.SkewSec != nil && *ov.SkewSec >= 30 && *ov.SkewSec <= 3600 {
		cfg.Skew = time.Duration(*ov.SkewSec) * time.Second
	}
	st.cfg, st.ov, st.cfgAt = cfg, ov, time.Now()
	return cfg, ov
}

func krbDropCache() {
	krbState.mu.Lock()
	krbState.cfgAt = time.Time{}
	krbState.vKey = ""
	krbState.mu.Unlock()
}

// krbValidator возвращает валидатор для cfg. Ошибка загрузки keytab кэшируется на 15 секунд, чтобы не читать диск на каждый запрос.
func krbValidator(cfg krbCfg) (*krb.Validator, error) {
	st := &krbState
	st.mu.Lock()
	defer st.mu.Unlock()
	k := cfg.key()
	if st.vKey == k {
		if st.v != nil {
			return st.v, nil
		}
		if time.Since(st.vErrAt) < 15*time.Second {
			return nil, st.vErr
		}
	}
	v, err := krb.New(cfg.kc())
	st.vKey, st.v, st.vErr, st.vErrAt = k, v, err, time.Now()
	return v, err
}

// ---------------------------------------------------------------- endpoint

func (s *Server) krbNegotiate(c *Ctx) error {
	w, r := c.W, c.R
	h := w.Header()
	h.Set("Cache-Control", "no-store")
	h.Add("Vary", "Authorization")
	ctx := c.Context()
	cfg, _ := s.krbConfig(ctx)
	if !cfg.Enabled {
		h.Set("X-Auth-Kerberos", "off")
		w.WriteHeader(http.StatusUnauthorized)
		return nil
	}
	v, err := krbValidator(cfg)
	if err != nil {
		h.Set("X-Auth-Kerberos", "error")
		s.krbRecordError(ctx, "конфигурация: "+err.Error())
		w.WriteHeader(http.StatusUnauthorized)
		return nil
	}
	h.Set("X-Auth-Kerberos", "on")
	tok, err := krb.ParseHeader(r.Header.Get("Authorization"))
	if errors.Is(err, krb.ErrNoToken) {
		h.Set("WWW-Authenticate", "Negotiate")
		w.WriteHeader(http.StatusUnauthorized)
		return nil
	}
	if err != nil {
		return s.krbFail(c, 401, "bad_token", "Некорректный токен Kerberos", err.Error())
	}
	if !s.rateOK(ctx, "krb:ip:"+c.IP(), 120, 5*time.Minute) {
		h.Set("Retry-After", "60")
		return s.krbFail(c, 429, "rate", "Слишком много попыток входа. Повторите позже", "rate limit "+c.IP())
	}
	id, err := v.Validate(tok, c.IP())
	if err != nil {
		code := "rejected"
		if errors.Is(err, krb.ErrBadToken) {
			code = "bad_token"
		} else if errors.Is(err, krb.ErrRealm) {
			code = "realm"
		}
		return s.krbFail(c, 401, code, "Kerberos-билет не принят", krbHint(err))
	}
	uid, err := s.krbResolveUser(ctx, cfg, id)
	if err != nil {
		var ae *apiError
		if errors.As(err, &ae) {
			return s.krbFail(c, ae.Code, "user", ae.Msg, id.Principal()+": "+ae.Msg)
		}
		s.log.Error("kerberos: user lookup failed", "principal", id.Principal(), "err", err)
		return s.krbFail(c, 503, "internal", "Сервис временно недоступен", id.Principal()+": "+err.Error())
	}
	tokS, err := s.createSession(ctx, uid, c.IP())
	if err != nil {
		return err
	}
	http.SetCookie(w, &http.Cookie{Name: cookieName, Value: tokS, Path: "/", HttpOnly: true, Secure: s.cfg.CookieSecure,
		SameSite: http.SameSiteLaxMode, MaxAge: int(s.cfg.SessionTTL.Seconds())})
	s.db.Exec(ctx, `UPDATE users SET last_seen = now() WHERE id = $1`, uid)
	if u, err := s.loadUser(ctx, uid); err == nil && u != nil {
		c.U = u
	}
	s.audit(c, "auth.login", "user", uid, map[string]string{"method": "kerberos", "principal": id.Principal()})
	s.db.Exec(ctx, `UPDATE krb_settings SET ok_count = ok_count + 1, last_ok_at = now(), last_ok_user = $1, last_ok_ip = $2 WHERE id = 1`, id.Principal(), c.IP())
	b, err := s.meJSON(ctx, uid)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// krbFail отвечает ошибкой БЕЗ WWW-Authenticate (клиент уже предъявил билет — повторять запрос бессмысленно) и пишет причину
// в krb_settings для админки (не чаще раза в 10 секунд, чтобы поток мусорных токенов не превращался в поток записей в БД).
func (s *Server) krbFail(c *Ctx, status int, code, msg, detail string) error {
	s.krbRecordError(c.Context(), detail)
	s.log.Info("kerberos: вход отклонён", "code", code, "ip", c.IP(), "detail", detail)
	return c.JSON(status, map[string]string{"error": msg, "code": code})
}

func (s *Server) krbRecordError(ctx context.Context, detail string) {
	if len(detail) > 500 {
		detail = detail[:500]
	}
	if ok, err := s.rdb.SetNX(ctx, "krb:errw", 1, 10*time.Second).Result(); err == nil && !ok {
		return
	}
	s.db.Exec(ctx, `UPDATE krb_settings SET last_error_at = now(), last_error = $1 WHERE id = 1`, detail)
}

// krbHint переводит ошибку gokrb5 в понятную администратору подсказку (в журнал и админку, не клиенту).
func krbHint(err error) string {
	m := err.Error()
	l := strings.ToLower(m)
	switch {
	case strings.Contains(l, "replay"):
		return "повтор аутентификатора (KRB_AP_ERR_REPEAT): " + m
	case strings.Contains(l, "matching key not found"), strings.Contains(l, "nokey"):
		return "в keytab нет подходящего ключа — не совпали SPN, kvno или тип шифрования (пересоздайте keytab): " + m
	case strings.Contains(l, "decrypting"), strings.Contains(l, "integrity"), strings.Contains(l, "modified"):
		return "билет не расшифрован ключом из keytab (KRB_AP_ERR_MODIFIED): SPN привязан к другой учётке или ключ устарел: " + m
	case strings.Contains(l, "skew"), strings.Contains(l, "clock"), strings.Contains(l, "not yet valid"), strings.Contains(l, "expired"), strings.Contains(l, "krb_ap_err_tkt"):
		return "расхождение времени или билет просрочен (проверьте NTP): " + m
	case errors.Is(err, krb.ErrRealm):
		return "realm клиента не входит в KRB5_REALM: " + m
	}
	return m
}

// ---------------------------------------------------------------- principal → пользователь портала

func (s *Server) krbResolveUser(ctx context.Context, cfg krbCfg, id *krb.Identity) (int64, error) {
	cands := krb.MapLogin(id.User, id.Realm, cfg.UserMap)
	if len(cands) == 0 {
		return 0, &apiError{403, "Эту учётную запись нельзя использовать для входа"}
	}
	for _, cand := range cands {
		rows, err := s.db.Query(ctx, `SELECT id, blocked FROM users WHERE deleted_at IS NULL
			AND (lower(login) = $1 OR (email <> '' AND lower(email) = $1)) LIMIT 2`, cand)
		if err != nil {
			return 0, err
		}
		type hit struct {
			id      int64
			blocked bool
		}
		var hits []hit
		for rows.Next() {
			var x hit
			if err := rows.Scan(&x.id, &x.blocked); err != nil {
				rows.Close()
				return 0, err
			}
			hits = append(hits, x)
		}
		rows.Close()
		if err := rows.Err(); err != nil {
			return 0, err
		}
		switch len(hits) {
		case 0:
			continue
		case 1:
			if hits[0].blocked {
				return 0, &apiError{403, "Учётная запись заблокирована"}
			}
			return hits[0].id, nil
		default:
			return 0, &apiError{403, "Учётной записи соответствует несколько пользователей. Обратитесь к администратору"}
		}
	}
	if !cfg.AutoCreate {
		return 0, &apiError{403, "Пользователь не найден в портале. Обратитесь к администратору"}
	}
	return s.krbAutoCreate(ctx, cands, id.User)
}

// krbAutoCreate создаёт пользователя при первом входе по данным LDAP (используются настройки сервера: атрибуты, роль по умолчанию).
func (s *Server) krbAutoCreate(ctx context.Context, cands []string, user string) (int64, error) {
	rows, err := s.db.Query(ctx, `SELECT id FROM ldap_servers WHERE enabled AND auto_create ORDER BY sort, id`)
	if err != nil {
		return 0, err
	}
	var ids []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			rows.Close()
			return 0, err
		}
		ids = append(ids, id)
	}
	rows.Close()
	notFound := &apiError{403, "Пользователь не найден в портале. Обратитесь к администратору"}
	if len(ids) == 0 {
		return 0, notFound
	}
	names := append([]string{}, cands...)
	if u := strings.ToLower(user); u != "" && !krbContains(names, u) && !strings.ContainsAny(u, "/\\@") {
		names = append(names, u)
	}
	for _, sid := range ids {
		srv, err := s.loadLDAP(ctx, sid)
		if err != nil {
			continue
		}
		p, err := s.krbLDAPLookup(srv, names)
		if err != nil {
			s.log.Warn("kerberos: ldap lookup failed", "server", srv.Name, "err", err)
			continue
		}
		if p == nil {
			continue
		}
		if p.Disabled {
			return 0, &apiError{403, "Учётная запись отключена в каталоге"}
		}
		uid, blocked, err := s.upsertLDAPUser(ctx, srv, p, true)
		if err != nil {
			return 0, err
		}
		if blocked {
			return 0, &apiError{403, "Учётная запись заблокирована"}
		}
		return uid, nil
	}
	return 0, notFound
}

func krbContains(l []string, v string) bool {
	for _, x := range l {
		if x == v {
			return true
		}
	}
	return false
}

// krbLDAPLookup ищет запись каталога под служебной учёткой: фильтр входа сервера, подставляются кандидаты логина по очереди.
func (s *Server) krbLDAPLookup(srv *ldapSrv, names []string) (*ldapPerson, error) {
	conn, err := srv.connectBound()
	if err != nil {
		return nil, err
	}
	defer conn.Close()
	for _, n := range names {
		filter := strings.ReplaceAll(srv.UserFilter, "%s", ldap.EscapeFilter(n))
		res, err := conn.Search(ldap.NewSearchRequest(srv.BaseDN, ldap.ScopeWholeSubtree, ldap.NeverDerefAliases, 2, 10, false, filter, srv.attrs(), nil))
		if err != nil {
			return nil, err
		}
		if len(res.Entries) != 1 {
			continue
		}
		p := srv.person(res.Entries[0])
		if p.Login == "" {
			p.Login = strings.ToLower(n)
		}
		return p, nil
	}
	return nil, nil
}

// ---------------------------------------------------------------- админка

func (s *Server) registerKerberos(m *http.ServeMux) {
	m.HandleFunc("GET /api/auth/negotiate", s.h("", s.krbNegotiate))
	m.HandleFunc("GET /api/admin/kerberos", s.h("admin", s.adminKrbStatus))
	m.HandleFunc("PUT /api/admin/kerberos", s.h("admin", s.adminKrbSave))
	m.HandleFunc("POST /api/admin/kerberos/check", s.h("admin", s.adminKrbCheck))
}

func (s *Server) krbStatusJSON(ctx context.Context) (map[string]any, krbCfg) {
	krbDropCache()
	cfg, ov := s.krbConfig(ctx)
	env := krbEnvCfg()
	src := func(set bool) string {
		if set {
			return "admin"
		}
		return "env"
	}
	out := map[string]any{
		"enabled": cfg.Enabled, "user_map": cfg.UserMap, "auto_create": cfg.AutoCreate, "clock_skew_sec": int(cfg.Skew.Seconds()),
		"sources": map[string]string{"enabled": src(ov.Enabled != nil), "user_map": src(ov.UserMap != nil), "auto_create": src(ov.AutoCreate != nil),
			"clock_skew_sec": src(ov.SkewSec != nil)},
		"env":    map[string]any{"enabled": env.Enabled, "user_map": env.UserMap, "auto_create": env.AutoCreate, "clock_skew_sec": int(env.Skew.Seconds())},
		"keytab": cfg.Keytab, "principal": cfg.SPN, "realms": krbNZ(cfg.Realms), "conf": cfg.ConfPath,
		"ok_count": ov.OKCount, "last_ok_at": ov.LastOKAt, "last_ok_user": ov.LastOKUser, "last_ok_ip": ov.LastOKIP,
		"last_error_at": ov.LastErrorAt, "last_error": ov.LastError,
	}
	if cfg.Keytab != "" {
		_, err := os.Stat(cfg.Keytab)
		out["keytab_found"] = err == nil
	} else {
		out["keytab_found"] = false
	}
	var n int
	s.db.QueryRow(ctx, `SELECT count(*) FROM ldap_servers WHERE enabled AND auto_create`).Scan(&n)
	out["ldap_autocreate_servers"] = n
	return out, cfg
}

func krbNZ(l []string) []string {
	if l == nil {
		return []string{}
	}
	return l
}

func (s *Server) adminKrbStatus(c *Ctx) error {
	out, _ := s.krbStatusJSON(c.Context())
	return c.JSON(200, out)
}

func (s *Server) adminKrbSave(c *Ctx) error {
	var in struct {
		Enabled      *bool   `json:"enabled"`
		UserMap      *string `json:"user_map"`
		AutoCreate   *bool   `json:"auto_create"`
		ClockSkewSec *int    `json:"clock_skew_sec"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if in.UserMap != nil {
		m := strings.ToLower(strings.TrimSpace(*in.UserMap))
		if m != "sam" && m != "upn" && m != "auto" {
			return badReq("Способ сопоставления: sam, upn или auto")
		}
		in.UserMap = &m
	}
	if in.ClockSkewSec != nil && (*in.ClockSkewSec < 30 || *in.ClockSkewSec > 3600) {
		return badReq("Допустимое смещение часов — от 30 до 3600 секунд")
	}
	// PUT заменяет все переопределения целиком: null = «брать из окружения»
	if _, err := s.db.Exec(c.Context(), `UPDATE krb_settings SET enabled = $1, user_map = $2, auto_create = $3, clock_skew_sec = $4, updated_at = now() WHERE id = 1`,
		in.Enabled, in.UserMap, in.AutoCreate, in.ClockSkewSec); err != nil {
		return err
	}
	krbDropCache()
	s.audit(c, "kerberos.settings", "kerberos", 0, in)
	out, _ := s.krbStatusJSON(c.Context())
	return c.JSON(200, out)
}

type krbCheck struct {
	Name   string `json:"name"`
	Level  string `json:"level"` // ok | warn | fail
	Detail string `json:"detail"`
}

// adminKrbCheck — «Проверить конфигурацию»: keytab, SPN, realm, krb5.conf и соответствие имени сайта SPN. KDC не нужен.
func (s *Server) adminKrbCheck(c *Ctx) error {
	ctx := c.Context()
	krbDropCache()
	cfg, _ := s.krbConfig(ctx)
	rep := krb.Inspect(cfg.kc())
	checks := []krbCheck{}
	add := func(level, name, detail string) { checks = append(checks, krbCheck{name, level, detail}) }

	if cfg.Enabled {
		add("ok", "Kerberos включён", "Эндпоинт /api/auth/negotiate принимает билеты")
	} else {
		add("warn", "Kerberos выключен", "Включите KRB5_ENABLED=true или переключатель ниже — сейчас вход только по паролю")
	}
	for _, p := range rep.Problems {
		add("fail", "Конфигурация", p)
	}
	if rep.KeytabOK {
		add("ok", "Keytab читается", rep.KeytabPath)
	}
	if rep.PrincipalOK {
		add("ok", "Ключ для сервисного принципала найден", rep.Principal)
	}
	for _, w := range rep.Warnings {
		add("warn", "Предупреждение", w)
	}
	if rep.ConfOK != nil && *rep.ConfOK {
		d := "krb5.conf разобран"
		if rep.DefaultRealm != "" {
			d += ", default_realm = " + rep.DefaultRealm
		}
		add("ok", "krb5.conf", d)
	}
	if len(rep.Realms) > 0 {
		add("ok", "Разрешённые realm клиентов", strings.Join(rep.Realms, ", "))
	}
	// имя, по которому администратор открыл портал, должно совпадать с хостом из SPN
	if spn := cfg.SPN; strings.Contains(spn, "/") {
		want := strings.ToLower(strings.TrimPrefix(spn[strings.Index(spn, "/")+1:], ""))
		if i := strings.Index(want, "@"); i >= 0 {
			want = want[:i]
		}
		have := strings.ToLower(c.R.Host)
		if i := strings.LastIndex(have, ":"); i > 0 && !strings.Contains(have[i:], "]") {
			have = have[:i]
		}
		switch {
		case have == "":
		case isIPHost(have):
			add("warn", "Адрес сайта", "Портал открыт по IP-адресу ("+have+"): Kerberos работает только по имени (FQDN), "+want)
		case have != want:
			add("warn", "Адрес сайта", "Вы открыли портал как «"+have+"», а SPN выпущен на «"+want+"». Браузер запрашивает билет на HTTP/<имя в адресной строке> — оно должно совпадать с SPN (либо в AD должны быть зарегистрированы оба SPN)")
		default:
			add("ok", "Адрес сайта", "Имя в адресной строке совпадает с SPN ("+want+")")
		}
	}
	if cfg.AutoCreate {
		var n int
		s.db.QueryRow(ctx, `SELECT count(*) FROM ldap_servers WHERE enabled AND auto_create`).Scan(&n)
		if n == 0 {
			add("warn", "Автосоздание пользователей", "Включено, но нет ни одного включённого LDAP-сервера с «Создавать пользователей при первом входе» — войдут только существующие")
		} else {
			add("ok", "Автосоздание пользователей", "LDAP-серверов для создания: "+strconv.Itoa(n))
		}
	}
	if !s.cfg.CookieSecure {
		add("warn", "Cookie сессии", "COOKIE_SECURE=false: при работе по HTTPS включите true")
	}
	if cfg.Enabled && rep.Ok() {
		if _, err := krbValidator(cfg); err != nil {
			add("fail", "Загрузка keytab приложением", err.Error())
		}
	}
	level := "ok"
	for _, k := range checks {
		if k.Level == "fail" {
			level = "fail"
			break
		}
		if k.Level == "warn" {
			level = "warn"
		}
	}
	s.audit(c, "kerberos.check", "kerberos", 0, map[string]string{"result": level})
	return c.JSON(200, map[string]any{"ok": level != "fail", "level": level, "checks": checks, "report": rep})
}

func isIPHost(h string) bool {
	if strings.HasPrefix(h, "[") || strings.Count(h, ":") > 0 {
		return true
	}
	dots := 0
	for _, r := range h {
		switch {
		case r == '.':
			dots++
		case r < '0' || r > '9':
			return false
		}
	}
	return dots == 3
}
