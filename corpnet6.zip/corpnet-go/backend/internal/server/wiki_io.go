package server

import (
	"archive/zip"
	"bytes"
	"context"
	"fmt"
	"io"
	"net/url"
	"os"
	"path"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

// Экспорт / импорт markdown (zip, только stdlib).
//
// Формат: страница = файл «NN-Название.md» с front matter (title, tags, review_until); у страницы с вложенными
// страницами рядом лежит каталог «NN-Название/» с её детьми. Вложения — в каталоге «_files/», ссылки в тексте
// переписываются на относительные. Импорт понимает тот же формат, а также обычные деревья .md-файлов:
// каталог = страница (текст берётся из «каталог.md» рядом, либо из index.md / README.md внутри; иначе страница пустая).

var badNameRe = regexp.MustCompile(`[\\/:*?"<>|\x00-\x1f]+`)

func fsName(t string) string {
	t = strings.TrimSpace(badNameRe.ReplaceAllString(t, "_"))
	t = strings.Trim(t, ". ")
	if r := []rune(t); len(r) > 80 {
		t = string(r[:80])
	}
	if t == "" {
		t = "page"
	}
	return t
}

func yamlQuote(s string) string { return strconv.Quote(s) }

func (s *Server) wikiExport(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	sp, sj, err := s.wikiSpace(c, id, wvView)
	if err != nil {
		return err
	}
	ctx := c.Context()
	var root *wpage
	if pid := c.QInt64("page"); pid > 0 {
		p, _, err := s.wikiPageAt(c, pid, wvView)
		if err != nil {
			return err
		}
		if p.SpaceID != id {
			return errNotFound
		}
		root = p
	}
	nodes, err := s.wikiBranch(ctx, sj, sp.Level, id, root, true)
	if err != nil {
		return err
	}
	if len(nodes) > 20000 {
		return badReq("Слишком много страниц для одного архива. Экспортируйте ветку")
	}
	ids := make([]int64, len(nodes))
	kids := map[int64][]int{}
	for i, n := range nodes {
		ids[i] = n.ID
		pid := n.PID
		if root != nil && n.ID == root.ID {
			pid = 0
		}
		kids[pid] = append(kids[pid], i)
	}
	// вложения
	type fileRec struct {
		ID            int64
		Name, Storage string
	}
	files := map[int64][]fileRec{}
	rs, err := s.db.Query(ctx, `SELECT wf.page_id, f.id, f.name, f.storage FROM wiki_page_files wf JOIN files f ON f.id = wf.file_id WHERE wf.page_id = ANY($1::bigint[]) ORDER BY wf.sort, f.id`, ids)
	if err != nil {
		return err
	}
	for rs.Next() {
		var pg int64
		var f fileRec
		rs.Scan(&pg, &f.ID, &f.Name, &f.Storage)
		files[pg] = append(files[pg], f)
	}
	rs.Close()

	name := fsName(sp.Title)
	if root != nil {
		name = fsName(root.Title)
	}
	h := c.W.Header()
	h.Set("Content-Type", "application/zip")
	h.Set("Content-Disposition", "attachment; filename*=UTF-8''"+url.PathEscape(name)+".zip")
	zw := zip.NewWriter(c.W)
	defer zw.Close()
	written := map[int64]string{} // file id → путь в архиве
	var walk func(list []int, dir string, depth int) error
	walk = func(list []int, dir string, depth int) error {
		used := map[string]bool{}
		for i, idx := range list {
			n := nodes[idx]
			base := fmt.Sprintf("%02d-%s", i+1, fsName(n.Title))
			for k := 2; used[strings.ToLower(base)]; k++ {
				base = fmt.Sprintf("%02d-%s (%d)", i+1, fsName(n.Title), k)
			}
			used[strings.ToLower(base)] = true
			body := n.Body
			up := strings.Repeat("../", depth)
			for _, f := range files[n.ID] {
				if _, ok := written[f.ID]; !ok {
					p := "_files/" + strconv.FormatInt(f.ID, 10) + "-" + fsName(f.Name)
					written[f.ID] = p
					if err := s.ensureLocal(ctx, false, f.Storage); err == nil {
						if src, err := os.Open(filepath.Join(s.dir(false), path.Base(f.Storage))); err == nil {
							w, werr := zw.Create(p)
							if werr == nil {
								io.Copy(w, src)
							}
							src.Close()
						}
					}
				}
			}
			body = filesRefRe.ReplaceAllStringFunc(body, func(m string) string {
				fid, _ := strconv.ParseInt(m[len("/files/"):], 10, 64)
				if p, ok := written[fid]; ok {
					return up + p
				}
				return m
			})
			var sb strings.Builder
			sb.WriteString("---\ntitle: " + yamlQuote(n.Title) + "\n")
			if len(n.Tags) > 0 {
				sb.WriteString("tags: " + yamlQuote(strings.Join(n.Tags, ", ")) + "\n")
			}
			if n.Review != nil {
				sb.WriteString("review_until: " + n.Review.Format("2006-01-02") + "\n")
			}
			sb.WriteString("---\n\n" + body)
			w, err := zw.Create(dir + base + ".md")
			if err != nil {
				return err
			}
			if _, err := io.WriteString(w, sb.String()); err != nil {
				return err
			}
			if ch := kids[n.ID]; len(ch) > 0 {
				if err := walk(ch, dir+base+"/", depth+1); err != nil {
					return err
				}
			}
		}
		return nil
	}
	return walk(kids[0], "", 0)
}

// ---------------------------------------------------------------- импорт

type inode struct {
	key     string
	title   string
	body    string
	hasBody bool
	srcPath string
	meta    map[string]string
	kids    []*inode
	byKey   map[string]*inode
}

var wikiNumPrefixRe = regexp.MustCompile(`^\d{1,4}\s*[-_.)]\s*`)
var mdLinkRe = regexp.MustCompile(`(!?\[[^\]]*\]\()([^)\s]+)(\))`)

func parseFrontMatter(body string) (map[string]string, string) {
	meta := map[string]string{}
	if !strings.HasPrefix(body, "---\n") {
		return meta, body
	}
	end := strings.Index(body[4:], "\n---")
	if end < 0 {
		return meta, body
	}
	block := body[4 : 4+end]
	rest := strings.TrimLeft(body[4+end+4:], "\n")
	for _, ln := range strings.Split(block, "\n") {
		k, v, ok := strings.Cut(ln, ":")
		if !ok {
			continue
		}
		v = strings.TrimSpace(v)
		if uq, err := strconv.Unquote(v); err == nil {
			v = uq
		}
		meta[strings.ToLower(strings.TrimSpace(k))] = v
	}
	return meta, rest
}

func (n *inode) child(key, title string) *inode {
	if c := n.byKey[key]; c != nil {
		return c
	}
	c := &inode{key: key, title: title, byKey: map[string]*inode{}}
	if n.byKey == nil {
		n.byKey = map[string]*inode{}
	}
	n.byKey[key] = c
	n.kids = append(n.kids, c)
	return c
}

const (
	importMaxZip     = 64 << 20
	importMaxEntries = 5000
	importMaxPages   = 3000
	importMaxUnzip   = 256 << 20
)

func (s *Server) wikiImport(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	var parent *int64
	if pid := c.QInt64("parent"); pid > 0 {
		p, _, err := s.wikiPageAt(c, pid, wvEdit)
		if err != nil {
			return err
		}
		if p.SpaceID != id {
			return errNotFound
		}
		parent = &pid
	} else if _, _, err := s.wikiSpace(c, id, wvEdit); err != nil {
		return err
	}
	var data []byte
	var fname string
	err = s.readParts(c, 1, func(name string, r io.Reader) error {
		fname = name
		b, err := io.ReadAll(io.LimitReader(r, importMaxZip+1))
		if err != nil {
			return err
		}
		if len(b) > importMaxZip {
			return &apiError{413, "Архив больше 64 МБ"}
		}
		data = b
		return nil
	})
	if err != nil {
		return err
	}
	root := &inode{byKey: map[string]*inode{}}
	attach := map[string]*zip.File{}
	if strings.HasSuffix(strings.ToLower(fname), ".md") {
		body := string(data)
		root.child("/"+fname, strings.TrimSuffix(fname, filepath.Ext(fname))).body = body
		root.byKey["/"+fname].hasBody = true
	} else {
		zr, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
		if err != nil {
			return badReq("Не удалось прочитать zip-архив")
		}
		if len(zr.File) > importMaxEntries {
			return badReq("В архиве слишком много файлов")
		}
		var total uint64
		var mds []*zip.File
		for _, f := range zr.File {
			if f.FileInfo().IsDir() {
				continue
			}
			total += f.UncompressedSize64
			if total > importMaxUnzip {
				return badReq("Архив слишком большой после распаковки")
			}
			nm := strings.TrimPrefix(path.Clean("/"+strings.ReplaceAll(f.Name, "\\", "/")), "/")
			if nm == "" || strings.HasPrefix(nm, "__MACOSX/") || strings.HasPrefix(path.Base(nm), ".") {
				continue
			}
			ext := strings.ToLower(path.Ext(nm))
			if ext == ".md" || ext == ".markdown" {
				mds = append(mds, f)
			} else {
				attach[nm] = f
			}
		}
		if len(mds) == 0 {
			return badReq("В архиве нет .md-файлов")
		}
		if len(mds) > importMaxPages {
			return badReq("В архиве слишком много страниц")
		}
		sort.Slice(mds, func(i, j int) bool { return strings.ToLower(mds[i].Name) < strings.ToLower(mds[j].Name) })
		for _, f := range mds {
			if f.UncompressedSize64 > wikiMaxBody {
				continue
			}
			rc, err := f.Open()
			if err != nil {
				continue
			}
			raw, _ := io.ReadAll(io.LimitReader(rc, wikiMaxBody+1))
			rc.Close()
			nm := strings.TrimPrefix(path.Clean("/"+strings.ReplaceAll(f.Name, "\\", "/")), "/")
			parts := strings.Split(nm, "/")
			cur, key := root, ""
			for _, d := range parts[:len(parts)-1] {
				key += "/" + d
				cur = cur.child(key, cleanImportName(d))
			}
			base := strings.TrimSuffix(parts[len(parts)-1], path.Ext(parts[len(parts)-1]))
			low := strings.ToLower(base)
			node := cur
			if cur == root || (low != "index" && low != "readme") {
				key += "/" + base
				node = cur.child(key, cleanImportName(base))
			}
			if node.hasBody {
				node = cur.child(key+"#"+f.Name, cleanImportName(base))
			}
			node.body, node.hasBody, node.srcPath = strings.ReplaceAll(string(raw), "\r\n", "\n"), true, nm
		}
	}
	// заголовки и метаданные
	var prep func(n *inode)
	prep = func(n *inode) {
		if n.hasBody {
			meta, body := parseFrontMatter(n.body)
			n.meta = meta
			if t := cleanTitle(meta["title"]); t != "" {
				n.title = t
			} else if m := regexp.MustCompile(`^#\s+(.+)\n?`).FindStringSubmatch(body); m != nil && len(m[1]) < 200 {
				n.title = cleanTitle(m[1])
				body = strings.TrimLeft(body[len(m[0]):], "\n")
			}
			n.body = body
		}
		n.title = cleanTitle(n.title)
		if n.title == "" {
			n.title = "Без названия"
		}
		for _, k := range n.kids {
			prep(k)
		}
	}
	for _, k := range root.kids {
		prep(k)
	}
	created := 0
	files := 0
	err = s.tx(ctx, func(tx pgx.Tx) error {
		var ins func(n *inode, parent *int64, sortv int) error
		ins = func(n *inode, parent *int64, sortv int) error {
			var tags []string
			if t := n.meta["tags"]; t != "" {
				tags = cleanTags(strings.Split(t, ","))
			} else {
				tags = []string{}
			}
			var review any
			if d, err := time.Parse("2006-01-02", n.meta["review_until"]); err == nil {
				review = d
			}
			var pid int64
			if err := tx.QueryRow(ctx, `INSERT INTO wiki_pages (space_id, parent_id, title, slug, body, sort, owner_id, responsible_id, tags, review_until, created_by, updated_by)
				VALUES ($1, $2, $3, $4, '', $5, $6, $6, $7, $8, $6, $6) RETURNING id`, id, parent, n.title, wikiSlug(n.title), sortv, c.U.ID, tags, review).Scan(&pid); err != nil {
				return err
			}
			body := n.body
			if n.hasBody && n.srcPath != "" {
				dir := path.Dir(n.srcPath)
				var ferr error
				body = mdLinkRe.ReplaceAllStringFunc(body, func(m string) string {
					sm := mdLinkRe.FindStringSubmatch(m)
					ref := sm[2]
					if ferr != nil || strings.Contains(ref, "://") || strings.HasPrefix(ref, "/") || strings.HasPrefix(ref, "#") || strings.HasPrefix(ref, "mailto:") {
						return m
					}
					q := ""
					if i := strings.IndexAny(ref, "?#"); i >= 0 {
						ref, q = ref[:i], ref[i:]
					}
					if u, err := url.PathUnescape(ref); err == nil {
						ref = u
					}
					zf := attach[strings.TrimPrefix(path.Join(dir, ref), "/")]
					if zf == nil {
						return m
					}
					fid, err := s.wikiImportFile(ctx, tx, c.U.ID, pid, zf)
					if err != nil {
						ferr = err
						return m
					}
					files++
					return sm[1] + "/files/" + strconv.FormatInt(fid, 10) + q + sm[3]
				})
				if ferr != nil {
					return ferr
				}
			}
			if n.hasBody {
				if _, err := tx.Exec(ctx, `UPDATE wiki_pages SET body = $2 WHERE id = $1`, pid, body); err != nil {
					return err
				}
			}
			if _, err := tx.Exec(ctx, `INSERT INTO wiki_versions (page_id, version, title, body, author_id, comment) VALUES ($1, 1, $2, $3, $4, 'Импорт из markdown')`, pid, n.title, body, c.U.ID); err != nil {
				return err
			}
			created++
			for i, k := range n.kids {
				if err := ins(k, &pid, (i+1)*1000); err != nil {
					return err
				}
			}
			return nil
		}
		var base int
		if err := tx.QueryRow(ctx, `SELECT coalesce(max(sort), 0) FROM wiki_pages WHERE space_id = $1 AND parent_id IS NOT DISTINCT FROM $2::bigint`, id, parent).Scan(&base); err != nil {
			return err
		}
		for i, k := range root.kids {
			if err := ins(k, parent, base+(i+1)*1000); err != nil {
				return err
			}
		}
		return nil
	})
	if err != nil {
		return err
	}
	s.audit(c, "wiki.import", "wiki_space", id, map[string]any{"pages": created, "files": files})
	return c.JSON(200, map[string]any{"ok": true, "pages": created, "files": files})
}

func cleanImportName(n string) string {
	n = strings.TrimSpace(wikiNumPrefixRe.ReplaceAllString(n, ""))
	if n == "" {
		return "Без названия"
	}
	return n
}

// wikiImportFile сохраняет файл из архива как вложение страницы.
func (s *Server) wikiImportFile(ctx context.Context, tx pgx.Tx, uid, page int64, zf *zip.File) (int64, error) {
	rc, err := zf.Open()
	if err != nil {
		return 0, err
	}
	defer rc.Close()
	st, err := s.storeUpload(rc, path.Base(zf.Name), false)
	if err != nil {
		return 0, err
	}
	fid, err := s.insertFile(ctx, tx, st, nil, uid, "wiki")
	if err != nil {
		s.removeStored(false, st.Storage, st.Thumb, st.View)
		return 0, err
	}
	_, err = tx.Exec(ctx, `INSERT INTO wiki_page_files (page_id, file_id, sort) VALUES ($1, $2, (SELECT coalesce(max(sort), 0) + 1 FROM wiki_page_files WHERE page_id = $1))`, page, fid)
	return fid, err
}
