package server

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"
)

// «Есть идея» — предложения по развитию и оптимизации. Устроено как новость: описание, лайки, комментарии
// (до 5 уровней, с файлами, в реальном времени) без статусов рассмотрения.

const ideaCols = `i.id, i.title, left(i.body, 300) AS summary, i.likes_count, i.comments_count, i.views_count, i.created_at,
	i.author_id, u.full_name AS author, u.avatar AS author_avatar, u.job_title AS author_title`

const ideaFrom = ` FROM ideas i LEFT JOIN users u ON u.id = i.author_id`

func (s *Server) listIdeas(c *Ctx) error {
	ctx := c.Context()
	per := min(max(c.QInt("per", 20), 1), 50)
	w := &whereBuilder{}
	if q := strings.Join(searchTokens(c.Q("q")), " "); q != "" {
		if len([]rune(q)) >= 3 {
			w.add(`(lower(i.title) LIKE ? ESCAPE '\' OR i.search_simple @@ to_tsquery('simple', ?))`, "%"+likeEscape(q)+"%", tsPrefixQuery(q))
		} else {
			w.add(`i.search_simple @@ to_tsquery('simple', ?)`, tsPrefixQuery(q))
		}
	}
	popular := c.Q("sort") == "popular"
	order := "i.id DESC"
	curCol := "i.id::text"
	if popular {
		order = "i.likes_count DESC, i.id DESC"
		curCol = "i.likes_count || '|' || i.id"
	}
	if cur := c.Q("cursor"); cur != "" {
		if popular {
			if p := strings.SplitN(cur, "|", 2); len(p) == 2 {
				l, e1 := strconv.Atoi(p[0])
				id, e2 := strconv.ParseInt(p[1], 10, 64)
				if e1 == nil && e2 == nil {
					w.add("(i.likes_count, i.id) < (?::int, ?::bigint)", l, id)
				}
			}
		} else if id, err := strconv.ParseInt(cur, 10, 64); err == nil {
			w.add("i.id < ?", id)
		}
	}
	items, err := s.ro.Query(ctx, `SELECT row_to_json(t) FROM (SELECT `+ideaCols+`, `+curCol+` AS cur,
		EXISTS (SELECT 1 FROM reactions l WHERE l.entity_type = 'idea' AND l.entity_id = i.id AND l.user_id = $`+strconv.Itoa(w.n()+1)+` AND l.emoji = '👍') AS liked`+ideaFrom+
		` WHERE `+w.String()+` ORDER BY `+order+` LIMIT `+strconv.Itoa(per+1)+`) t`, append(w.args, c.U.ID)...)
	if err != nil {
		return err
	}
	var list []json.RawMessage
	for items.Next() {
		var b []byte
		if err := items.Scan(&b); err != nil {
			items.Close()
			return err
		}
		list = append(list, b)
	}
	items.Close()
	more := len(list) > per
	if more {
		list = list[:per]
	}
	if list == nil {
		list = []json.RawMessage{}
	}
	if c.Q("cursor") == "" {
		s.logSearch(c, "ideas", c.Q("q"), len(list)) // аналитика поиска
	}
	lb, _ := json.Marshal(list)
	withRx, err := s.withSocial(ctx, c.U.ID, "idea", lb, true)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"items": withRx, "has_more": more})
}

func (s *Server) getIdea(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	if s.rdb.SetNX(ctx, fmt.Sprintf("viewed:idea:%d:%d", c.U.ID, id), 1, 30*time.Minute).Val() {
		s.db.Exec(ctx, `UPDATE ideas SET views_count = views_count + 1 WHERE id = $1`, id)
	}
	b, err := s.one(ctx, `SELECT `+ideaCols+`, i.body,
		EXISTS (SELECT 1 FROM reactions l WHERE l.entity_type = 'idea' AND l.entity_id = i.id AND l.user_id = $2 AND l.emoji = '👍') AS liked,
		($3::boolean OR i.author_id = $2) AS can_edit`+ideaFrom+` WHERE i.id = $1`, id, c.U.ID, c.U.CanEdit())
	if err != nil {
		return err
	}
	if b, err = s.withSocialOne(ctx, c.U.ID, "idea", b, true); err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) saveIdea(c *Ctx) error {
	var in struct {
		Title string `json:"title"`
		Body  string `json:"body"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Title, in.Body = strings.TrimSpace(in.Title), strings.TrimSpace(in.Body)
	if in.Title == "" || len([]rune(in.Title)) > 200 {
		return badReq("Опишите идею в заголовке (до 200 символов)")
	}
	if len(in.Body) > 20000 {
		return badReq("Описание слишком длинное")
	}
	ctx := c.Context()
	var id int64
	if c.R.PathValue("id") != "" {
		var err error
		if id, err = c.ID("id"); err != nil {
			return err
		}
		var author *int64
		if err := s.db.QueryRow(ctx, `SELECT author_id FROM ideas WHERE id = $1`, id).Scan(&author); err != nil {
			return err
		}
		if !(c.U.CanEdit() || (author != nil && *author == c.U.ID)) {
			return errForbidden
		}
		if _, err := s.db.Exec(ctx, `UPDATE ideas SET title = $2, body = $3, updated_at = now() WHERE id = $1`, id, in.Title, in.Body); err != nil {
			return err
		}
	} else {
		if !s.rateOK(ctx, fmt.Sprintf("idea:%d", c.U.ID), 5, time.Minute) {
			return &apiError{429, "Слишком часто. Подождите немного"}
		}
		if err := s.db.QueryRow(ctx, `INSERT INTO ideas (title, body, author_id) VALUES ($1, $2, $3) RETURNING id`, in.Title, in.Body, c.U.ID).Scan(&id); err != nil {
			return err
		}
		s.hub.Emit(ctx, "feed", "refresh", map[string]string{"what": "ideas"})
	}
	if strings.Contains(in.Body, "@") || strings.Contains(in.Title, "@") {
		s.syncMentions(ctx, mentionSrc{Type: "idea", ID: id, Actor: c.U, Body: in.Title + "\n" + in.Body, Link: "/ideas/" + strconv.FormatInt(id, 10), Where: "в идее", Title: in.Title, Audience: audienceAll})
	}
	return c.JSON(200, map[string]int64{"id": id})
}

func (s *Server) deleteIdea(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	var author *int64
	if err := s.db.QueryRow(ctx, `SELECT author_id FROM ideas WHERE id = $1`, id).Scan(&author); err != nil {
		return err
	}
	if !(c.U.CanEdit() || (author != nil && *author == c.U.ID)) {
		return errForbidden
	}
	if _, err := s.db.Exec(ctx, `DELETE FROM ideas WHERE id = $1`, id); err != nil {
		return err
	}
	s.db.Exec(ctx, `DELETE FROM comments WHERE entity_type = 'idea' AND entity_id = $1`, id)
	s.audit(c, "idea.delete", "idea", id, nil)
	return c.OK()
}
