package server

import (
	"errors"
	"io"
	"io/fs"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"corpnet/internal/web"
)

// Раздача статики самим приложением (без nginx):
//   GET /media/{name}  — публичные загрузки (аватары, обложки…) из DATA_DIR/pub, с «подтягиванием» с соседнего ЦОДа
//   GET /*             — SPA: встроенный dist (или каталог STATIC_DIR), .gz-версии отдаются предсжатыми, остальное → index.html

type staticFS struct {
	fsys fs.FS
}

func newStatic(dir string) *staticFS {
	if dir != "" {
		return &staticFS{fsys: os.DirFS(dir)}
	}
	return &staticFS{fsys: web.Dist()}
}

func (s *Server) registerStatic(m *http.ServeMux) {
	st := newStatic(s.cfg.StaticDir)
	m.HandleFunc("/media/{name}", s.serveMedia)
	m.HandleFunc("/", st.serve)
}

func (st *staticFS) open(name string) (fs.File, fs.FileInfo, bool) {
	f, err := st.fsys.Open(name)
	if err != nil {
		return nil, nil, false
	}
	fi, err := f.Stat()
	if err != nil || fi.IsDir() {
		f.Close()
		return nil, nil, false
	}
	return f, fi, true
}

var mimeByExt = map[string]string{
	".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
	".html": "text/html; charset=utf-8", ".svg": "image/svg+xml", ".json": "application/json", ".map": "application/json",
	".wasm": "application/wasm", ".ttf": "font/ttf", ".woff2": "font/woff2", ".woff": "font/woff", ".bcmap": "application/octet-stream",
	".pfb": "application/octet-stream", ".icc": "application/octet-stream", ".txt": "text/plain; charset=utf-8", ".png": "image/png", ".ico": "image/x-icon",
}

func (st *staticFS) serve(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet && r.Method != http.MethodHead {
		w.Header().Set("Allow", "GET, HEAD")
		http.Error(w, "method not allowed", 405)
		return
	}
	p := path.Clean("/" + r.URL.Path)
	if strings.HasPrefix(p, "/api/") || p == "/api" {
		w.Header().Set("Content-Type", "application/json; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		w.WriteHeader(404)
		_, _ = io.WriteString(w, `{"error":"not found"}`)
		return
	}
	name := strings.TrimPrefix(p, "/")
	immutable := strings.HasPrefix(name, "assets/")
	ext := strings.ToLower(path.Ext(name))
	if name == "" {
		name = "index.html"
		ext = ".html"
	}
	f, fi, ok := st.open(name)
	if !ok {
		if ext != "" && ext != ".html" { // отсутствующий файл с расширением — честный 404, а не index.html
			http.NotFound(w, r)
			return
		}
		name, ext, immutable = "index.html", ".html", false // клиентский маршрут SPA
		if f, fi, ok = st.open(name); !ok {
			http.Error(w, "frontend не собран: выполните «npm run build» в каталоге frontend и пересоберите backend", 503)
			return
		}
	}
	defer f.Close()
	h := w.Header()
	if ct := mimeByExt[ext]; ct != "" {
		h.Set("Content-Type", ct)
	} else {
		h.Set("Content-Type", "application/octet-stream")
	}
	switch {
	case immutable:
		h.Set("Cache-Control", "public, max-age=31536000, immutable")
	case ext == ".html":
		h.Set("Cache-Control", "no-cache")
	default:
		h.Set("Cache-Control", "public, max-age=604800")
	}
	var rd io.Reader = f
	size := fi.Size()
	h.Add("Vary", "Accept-Encoding")
	if strings.Contains(r.Header.Get("Accept-Encoding"), "gzip") && strings.Contains(".js .css .html .svg .json .txt .map", ext) {
		if gf, gfi, ok := st.open(name + ".gz"); ok {
			defer gf.Close()
			f.Close()
			rd, size = gf, gfi.Size()
			h.Set("Content-Encoding", "gzip")
		}
	}
	if rs, ok := rd.(io.ReadSeeker); ok {
		h.Set("Content-Length", strconv.FormatInt(size, 10))
		http.ServeContent(w, r, "", fi.ModTime(), rs) // Content-Type уже задан; Range/If-Modified-Since работают
		return
	}
	// embed.FS: файл — ReadSeeker, остальные реализации — просто копируем
	h.Set("Content-Length", strconv.FormatInt(size, 10))
	if r.Method != http.MethodHead {
		_, _ = io.Copy(w, rd)
	}
}

// serveMedia отдаёт публичный файл из DATA_DIR/pub; если файла нет (загружен в другом ЦОДе) — подтягивает его у FILE_PEERS.
func (s *Server) serveMedia(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet && r.Method != http.MethodHead {
		http.Error(w, "method not allowed", 405)
		return
	}
	name := path.Base(r.PathValue("name"))
	if name == "." || name == "/" || strings.ContainsAny(name, "/\\") || strings.Contains(name, ".part.") {
		http.NotFound(w, r)
		return
	}
	p := filepath.Join(s.dir(true), name)
	if _, err := os.Stat(p); err != nil {
		if len(s.cfg.FilePeers) > 0 {
			if err := s.ensureLocal(r.Context(), true, name); err != nil {
				s.log.Warn("pull public", "name", name, "err", err)
			}
		}
		if _, err := os.Stat(p); err != nil {
			// нет варианта (.t.jpg/.v.jpg) — отдаём оригинал, а не 404
			orig := strings.TrimSuffix(strings.TrimSuffix(name, ".t.jpg"), ".v.jpg")
			if orig == name || orig == "" {
				http.NotFound(w, r)
				return
			}
			p = filepath.Join(s.dir(true), orig)
			if _, err := os.Stat(p); err != nil && len(s.cfg.FilePeers) > 0 {
				_ = s.ensureLocal(r.Context(), true, orig)
			}
			if _, err := os.Stat(p); err != nil {
				http.NotFound(w, r)
				return
			}
		}
	}
	f, err := os.Open(p)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			http.NotFound(w, r)
		} else {
			http.Error(w, "error", 500)
		}
		return
	}
	defer f.Close()
	st, _ := f.Stat()
	h := w.Header()
	h.Set("Cache-Control", "public, max-age=2592000, immutable")
	h.Set("X-Content-Type-Options", "nosniff")
	h.Set("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; sandbox")
	if st != nil {
		http.ServeContent(w, r, name, st.ModTime(), f)
		return
	}
	http.ServeContent(w, r, name, time.Time{}, f)
}
