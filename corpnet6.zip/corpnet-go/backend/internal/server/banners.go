package server

import (
	"strings"
	"time"
)

// Баннеры над важными новостями: фото, видео, текст и ссылка на важное событие (новость, группа, направление …).

const bannerCols = `id, title, text, image, video_url, link, link_label, sort, active, starts_at, ends_at, created_at`

func (s *Server) listBanners(c *Ctx) error {
	b, err := s.arr2(c.Context(), `SELECT `+bannerCols+` FROM banners WHERE active AND (starts_at IS NULL OR starts_at <= now())
		AND (ends_at IS NULL OR ends_at > now()) ORDER BY sort, id LIMIT 10`)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) adminListBanners(c *Ctx) error {
	b, err := s.arr(c.Context(), `SELECT `+bannerCols+` FROM banners ORDER BY sort, id`)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) saveBanner(c *Ctx) error {
	var in struct {
		Title     string `json:"title"`
		Text      string `json:"text"`
		Image     string `json:"image"`
		VideoURL  string `json:"video_url"`
		Link      string `json:"link"`
		LinkLabel string `json:"link_label"`
		Sort      int    `json:"sort"`
		Active    bool   `json:"active"`
		StartsAt  string `json:"starts_at"`
		EndsAt    string `json:"ends_at"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Title, in.Link, in.VideoURL = strings.TrimSpace(in.Title), strings.TrimSpace(in.Link), strings.TrimSpace(in.VideoURL)
	if in.Title == "" {
		return badReq("Укажите заголовок баннера")
	}
	if in.Link != "" && !strings.HasPrefix(in.Link, "/") && !strings.HasPrefix(in.Link, "https://") && !strings.HasPrefix(in.Link, "http://") {
		return badReq("Ссылка должна быть внутренним путём (/news/5) или адресом http(s)://")
	}
	if strings.HasPrefix(in.Link, "//") {
		return badReq("Некорректная ссылка")
	}
	if strings.HasPrefix(in.Link, "/") && !validAppLink(in.Link) {
		return badReq("Такой страницы нет на портале. Примеры: /news/5, /groups/3, /ideas/2, /calendar?event=7, /documents")
	}
	if in.VideoURL != "" && !strings.HasPrefix(in.VideoURL, "https://") {
		return badReq("Ссылка на видео должна начинаться с https://")
	}
	if strings.TrimSpace(in.LinkLabel) == "" {
		in.LinkLabel = "Подробнее"
	}
	from, err := parseOptTime(in.StartsAt)
	if err != nil {
		return err
	}
	to, err := parseOptTime(in.EndsAt)
	if err != nil {
		return err
	}
	var id int64
	ctx := c.Context()
	if c.R.PathValue("id") != "" {
		if id, err = c.ID("id"); err != nil {
			return err
		}
		if _, err := s.db.Exec(ctx, `UPDATE banners SET title = $2, text = $3, image = $4, video_url = $5, link = $6, link_label = $7,
			sort = $8, active = $9, starts_at = $10, ends_at = $11 WHERE id = $1`,
			id, in.Title, in.Text, in.Image, in.VideoURL, in.Link, in.LinkLabel, in.Sort, in.Active, from, to); err != nil {
			return err
		}
	} else if err := s.db.QueryRow(ctx, `INSERT INTO banners (title, text, image, video_url, link, link_label, sort, active, starts_at, ends_at, created_by)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING id`,
		in.Title, in.Text, in.Image, in.VideoURL, in.Link, in.LinkLabel, in.Sort, in.Active, from, to, c.U.ID).Scan(&id); err != nil {
		return err
	}
	s.audit(c, "banner.save", "banner", id, map[string]string{"title": in.Title})
	return c.JSON(200, map[string]int64{"id": id})
}

func (s *Server) deleteBanner(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, err := s.db.Exec(c.Context(), `DELETE FROM banners WHERE id = $1`, id); err != nil {
		return err
	}
	s.audit(c, "banner.delete", "banner", id, nil)
	return c.OK()
}

var _ = time.Now
