package server

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

// LMS: курсы, прогресс, назначения, напоминания, сертификаты, статистика.
//
// Файлы блока:
//   lms.go          — маршруты, область ответственного за обучение, общие помощники, привязка к прохождению тестов
//   lms_courses.go  — каталог и конструктор курсов
//   lms_progress.go — прохождение курса: шаги, прогресс, завершение, «Моё обучение»
//   lms_assign.go   — назначения, правила автоназначения, действия ответственного
//   lms_jobs.go     — фоновые задачи: автоназначение, переназначение, напоминания, дайджест, окончание срока
//   lms_certs.go    — шаблоны, выдача, проверка и реестр сертификатов
//   lms_stats.go    — статистика и экспорт

// qb — позиционные параметры SQL.
type qb struct{ args []any }

func (b *qb) add(v any) string {
	b.args = append(b.args, v)
	return "$" + strconv.Itoa(len(b.args))
}

func nilIf0(v int64) any {
	if v == 0 {
		return nil
	}
	return v
}

func (s *Server) registerLMS(m *http.ServeMux) {
	const U, E, A = "user", "editor", "admin"
	p := "/api/learning"

	// курсы
	m.HandleFunc("GET "+p+"/courses", s.h(U, s.lmsCatalog))
	m.HandleFunc("POST "+p+"/courses", s.h(U, s.lmsCourseSave))
	m.HandleFunc("GET "+p+"/courses/{id}", s.h(U, s.lmsCourseGet))
	m.HandleFunc("PUT "+p+"/courses/{id}", s.h(U, s.lmsCourseSave))
	m.HandleFunc("DELETE "+p+"/courses/{id}", s.h(U, s.lmsCourseDelete))
	m.HandleFunc("POST "+p+"/courses/{id}/status", s.h(U, s.lmsCourseStatus))
	m.HandleFunc("POST "+p+"/courses/{id}/copy", s.h(U, s.lmsCourseCopy))
	m.HandleFunc("GET "+p+"/courses/pick", s.h(U, s.lmsCoursePick))

	// прохождение
	m.HandleFunc("POST "+p+"/courses/{id}/start", s.h(U, s.lmsStart))
	m.HandleFunc("POST "+p+"/courses/{id}/restart", s.h(U, s.lmsRestart))
	m.HandleFunc("POST "+p+"/courses/{id}/steps/{sid}/open", s.h(U, s.lmsStepOpen))
	m.HandleFunc("POST "+p+"/courses/{id}/steps/{sid}/done", s.h(U, s.lmsStepDone))
	m.HandleFunc("POST "+p+"/courses/{id}/steps/{sid}/beat", s.h(U, s.lmsStepBeat))
	m.HandleFunc("GET "+p+"/my", s.h(U, s.lmsMy))

	// назначения
	m.HandleFunc("GET "+p+"/assignments", s.h(U, s.lmsAssignList))
	m.HandleFunc("POST "+p+"/assignments", s.h(U, s.lmsAssignCreate))
	m.HandleFunc("GET "+p+"/assignments/{id}", s.h(U, s.lmsAssignGet))
	m.HandleFunc("POST "+p+"/assignments/{id}/cancel", s.h(U, s.lmsAssignCancel))
	m.HandleFunc("GET "+p+"/assign/targets", s.h(U, s.lmsAssignTargets))
	m.HandleFunc("POST "+p+"/assignees/remind", s.h(U, s.lmsRemindBulk))
	m.HandleFunc("POST "+p+"/assignees/{id}/remind", s.h(U, s.lmsAssigneeRemind))
	m.HandleFunc("POST "+p+"/assignees/{id}/extend", s.h(U, s.lmsAssigneeExtend))
	m.HandleFunc("POST "+p+"/assignees/{id}/revoke", s.h(U, s.lmsAssigneeRevoke))
	m.HandleFunc("GET "+p+"/assignees/{id}/log", s.h(U, s.lmsAssigneeLog))
	m.HandleFunc("POST "+p+"/jobs/run", s.h(A, s.lmsJobsRun))

	// сертификаты
	m.HandleFunc("GET "+p+"/cert-templates", s.h(U, s.lmsTplList))
	m.HandleFunc("POST "+p+"/cert-templates", s.h(E, s.lmsTplSave))
	m.HandleFunc("PUT "+p+"/cert-templates/{id}", s.h(E, s.lmsTplSave))
	m.HandleFunc("DELETE "+p+"/cert-templates/{id}", s.h(E, s.lmsTplDelete))
	m.HandleFunc("GET "+p+"/certificates", s.h(U, s.lmsCertList))
	m.HandleFunc("GET "+p+"/certificates/export.csv", s.h(U, s.lmsCertExport))
	m.HandleFunc("GET "+p+"/certificates/{id}", s.h(U, s.lmsCertGet))
	m.HandleFunc("POST "+p+"/certificates/{id}/revoke", s.h(U, s.lmsCertRevoke))
	m.HandleFunc("POST "+p+"/certificates/{id}/restore", s.h(U, s.lmsCertRestore))
	m.HandleFunc("GET /api/verify/certificate/{code}", s.h("", s.lmsCertVerify))

	// статистика (ответственный за обучение / администратор)
	m.HandleFunc("GET "+p+"/stats/overview", s.h(U, s.lmsStatsOverview))
	m.HandleFunc("GET "+p+"/stats/departments", s.h(U, s.lmsStatsDepts))
	m.HandleFunc("GET "+p+"/stats/targets", s.h(U, s.lmsStatsTargets))
	m.HandleFunc("GET "+p+"/stats/targets/{type}/{id}", s.h(U, s.lmsStatsTarget))
	m.HandleFunc("GET "+p+"/stats/users", s.h(U, s.lmsStatsUsers))
	m.HandleFunc("GET "+p+"/stats/users/{id}", s.h(U, s.lmsStatsUser))
	m.HandleFunc("GET "+p+"/stats/overdue", s.h(U, s.lmsStatsOverdue))
	m.HandleFunc("GET "+p+"/stats/export/{kind}", s.h(U, s.lmsStatsExport))
	m.HandleFunc("GET "+p+"/stats/me", s.h(U, s.lmsStatsMe))
}

// ---------------------------------------------------------------- роль «ответственный за обучение»

// setLearningManager: флаг и дополнительные подразделения; nil — не менять (LDAP и старые клиенты не затирают).
func setLearningManager(ctx context.Context, tx pgx.Tx, uid int64, flag *bool, depts *[]int64) error {
	if flag != nil {
		if _, err := tx.Exec(ctx, `UPDATE users SET learning_manager = $2 WHERE id = $1`, uid, *flag); err != nil {
			return err
		}
	}
	if depts != nil || (flag != nil && !*flag) {
		if _, err := tx.Exec(ctx, `DELETE FROM learning_manager_departments WHERE user_id = $1`, uid); err != nil {
			return err
		}
	}
	if depts != nil && len(*depts) > 0 && (flag == nil || *flag) {
		if _, err := tx.Exec(ctx, `INSERT INTO learning_manager_departments (user_id, department_id)
			SELECT $1, d.id FROM departments d WHERE d.id = ANY($2::bigint[]) ON CONFLICT DO NOTHING`, uid, *depts); err != nil {
			return err
		}
	}
	return nil
}

// lmsScope — область, в которой пользователь вправе смотреть статистику и управлять назначениями:
// администратор — всё; ответственный — свои подразделения (свое + дополнительные) с дочерними; остальные — nil.
func (s *Server) lmsScope(ctx context.Context, u *User) (*scope, error) {
	if u.IsAdmin() {
		return &scope{All: true, IDs: []int64{}}, nil
	}
	if !u.LM {
		return nil, nil
	}
	sc := &scope{IDs: []int64{}, set: map[int64]bool{}}
	rows, err := s.db.Query(ctx, `WITH RECURSIVE roots AS (
			SELECT department_id AS id FROM users WHERE id = $1 AND department_id IS NOT NULL
			UNION SELECT department_id FROM learning_manager_departments WHERE user_id = $1),
		t AS (SELECT id FROM roots UNION SELECT d.id FROM departments d JOIN t ON d.parent_id = t.id)
		SELECT id FROM t`, u.ID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		sc.IDs = append(sc.IDs, id)
		sc.set[id] = true
	}
	return sc, rows.Err()
}

// lmsManager — область или 403, если пользователь не администратор и не ответственный за обучение.
func (s *Server) lmsManager(c *Ctx) (*scope, error) {
	sc, err := s.lmsScope(c.Context(), c.U)
	if err != nil {
		return nil, err
	}
	if sc == nil {
		return nil, errForbidden
	}
	return sc, nil
}

// cond — условие «пользователь col входит в область» (для администратора — пустое).
func (sc *scope) cond(b *qb, col string) string {
	if sc.All {
		return "true"
	}
	return col + " = ANY(" + b.add(sc.IDs) + "::bigint[])"
}

// lmsUserIn — сотрудник входит в область (по текущему подразделению).
func (s *Server) lmsUserIn(ctx context.Context, sc *scope, uid int64) (bool, error) {
	if sc.All {
		return true, nil
	}
	var d *int64
	if err := s.db.QueryRow(ctx, `SELECT department_id FROM users WHERE id = $1`, uid).Scan(&d); err != nil {
		return false, err
	}
	return sc.HasPtr(d), nil
}

// ---------------------------------------------------------------- шаги курса и привязка тестов

type lstep struct {
	ID          int64   `json:"id"`
	SectionID   *int64  `json:"section_id"`
	Sort        int     `json:"sort"`
	Kind        string  `json:"kind"`
	RefID       *int64  `json:"ref_id"`
	Title       string  `json:"title"`
	Body        string  `json:"body"`
	URL         string  `json:"url"`
	Required    bool    `json:"required"`
	PassPercent *int    `json:"pass_percent"`
	EstMinutes  int     `json:"est_minutes"`
	RefTitle    *string `json:"ref_title"`
	ItemKind    *string `json:"item_kind"`
	Questions   *int    `json:"questions_count"`
	TimeLimit   *int    `json:"time_limit_min"`
	TestStatus  *string `json:"test_status"`
	// вычисляемые для пользователя
	Status    int      `json:"status"`
	Score     *float64 `json:"score"`
	TimeSec   int      `json:"time_sec"`
	Available bool     `json:"available"`
	Locked    string   `json:"locked,omitempty"`
}

func (s *Server) lmsSteps(ctx context.Context, courseID int64) ([]lstep, error) {
	rows, err := s.db.Query(ctx, `SELECT st.id, st.section_id, st.sort, st.kind, st.ref_id, st.title, st.body, st.url, st.required, st.pass_percent, st.est_minutes,
			CASE st.kind WHEN 'item' THEN i.title WHEN 'test' THEN t.title END, i.kind, t.questions_count, t.time_limit_min, t.status
		FROM learn_course_steps st LEFT JOIN learn_items i ON st.kind = 'item' AND i.id = st.ref_id LEFT JOIN learn_tests t ON st.kind = 'test' AND t.id = st.ref_id
		WHERE st.course_id = $1 ORDER BY st.sort, st.id`, courseID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []lstep{}
	for rows.Next() {
		var x lstep
		if err := rows.Scan(&x.ID, &x.SectionID, &x.Sort, &x.Kind, &x.RefID, &x.Title, &x.Body, &x.URL, &x.Required, &x.PassPercent, &x.EstMinutes,
			&x.RefTitle, &x.ItemKind, &x.Questions, &x.TimeLimit, &x.TestStatus); err != nil {
			return nil, err
		}
		out = append(out, x)
	}
	return out, rows.Err()
}

// lmsApplyProgress проставляет статус/доступность шагов пользователя: при строгом порядке шаг доступен,
// когда выполнены все предыдущие обязательные.
func (s *Server) lmsApplyProgress(ctx context.Context, uid int64, co *lcourse, steps []lstep) error {
	rows, err := s.db.Query(ctx, `SELECT step_id, status, score::float8, time_sec FROM learn_step_progress WHERE user_id = $1 AND course_id = $2`, uid, co.ID)
	if err != nil {
		return err
	}
	type pr struct {
		st    int
		score *float64
		t     int
	}
	m := map[int64]pr{}
	for rows.Next() {
		var id int64
		var p pr
		if err := rows.Scan(&id, &p.st, &p.score, &p.t); err != nil {
			rows.Close()
			return err
		}
		m[id] = p
	}
	rows.Close()
	blocked := false
	for i := range steps {
		p := m[steps[i].ID]
		steps[i].Status, steps[i].Score, steps[i].TimeSec = p.st, p.score, p.t
		steps[i].Available = true
		if co.OrderMode == "sequential" && blocked && p.st != 2 {
			steps[i].Available = false
			steps[i].Locked = "Сначала завершите предыдущие шаги"
		}
		if steps[i].Required && p.st != 2 {
			blocked = true
		}
	}
	return nil
}

// lmsPrereqs — предпосылки курса и выполнены ли они пользователем.
func (s *Server) lmsPrereqs(ctx context.Context, uid, cid int64) (list []map[string]any, ok bool, err error) {
	rows, err := s.db.Query(ctx, `SELECT c.id, c.title, coalesce(e.status = 2 AND (e.expires_at IS NULL OR e.expires_at > now()), false)
		FROM learn_course_prereq p JOIN learn_courses c ON c.id = p.req_id LEFT JOIN learn_enrollments e ON e.course_id = c.id AND e.user_id = $1
		WHERE p.course_id = $2 ORDER BY c.title`, uid, cid)
	if err != nil {
		return nil, false, err
	}
	defer rows.Close()
	list, ok = []map[string]any{}, true
	for rows.Next() {
		var id int64
		var title string
		var done bool
		if err := rows.Scan(&id, &title, &done); err != nil {
			return nil, false, err
		}
		list = append(list, map[string]any{"id": id, "title": title, "done": done})
		ok = ok && done
	}
	return list, ok, rows.Err()
}

// lmsStepContext проверяет запуск теста из шага курса: шаг существует, курс доступен, предпосылки и порядок соблюдены.
// Возвращает курс, лимит попыток курса и начало текущего цикла прохождения.
func (s *Server) lmsStepContext(c *Ctx, testID, stepID int64) (course int64, maxAtt *int, from time.Time, err error) {
	ctx := c.Context()
	var st lstep
	var cid int64
	if err = s.db.QueryRow(ctx, `SELECT id, course_id, kind, ref_id FROM learn_course_steps WHERE id = $1`, stepID).Scan(&st.ID, &cid, &st.Kind, &st.RefID); err != nil {
		return
	}
	if st.Kind != "test" || st.RefID == nil || *st.RefID != testID {
		err = badReq("Шаг курса не относится к этому тесту")
		return
	}
	co, _, err := s.lmsCourseAccess(c, cid, lvView)
	if err != nil {
		return
	}
	if err = s.lmsGate(ctx, c.U.ID, co, stepID); err != nil {
		return
	}
	from = time.Unix(0, 0)
	var started *time.Time
	if e := s.db.QueryRow(ctx, `SELECT started_at FROM learn_enrollments WHERE user_id = $1 AND course_id = $2`, c.U.ID, cid).Scan(&started); e == nil && started != nil {
		from = *started
	}
	return cid, co.MaxAttempts, from, nil
}

// lmsGate: можно ли выполнять шаг сейчас (предпосылки курса и строгий порядок).
func (s *Server) lmsGate(ctx context.Context, uid int64, co *lcourse, stepID int64) error {
	_, ok, err := s.lmsPrereqs(ctx, uid, co.ID)
	if err != nil {
		return err
	}
	if !ok {
		return conflict("Сначала пройдите курсы-предпосылки")
	}
	if co.OrderMode != "sequential" {
		return nil
	}
	steps, err := s.lmsSteps(ctx, co.ID)
	if err != nil {
		return err
	}
	if err := s.lmsApplyProgress(ctx, uid, co, steps); err != nil {
		return err
	}
	for _, x := range steps {
		if x.ID == stepID {
			if !x.Available {
				return conflict("Шаг откроется после предыдущих шагов курса")
			}
			return nil
		}
	}
	return errNotFound
}

// lmsOnAttemptStart — начало попытки: отмечаем назначение теста «в процессе» и шаг курса «открыт».
func (s *Server) lmsOnAttemptStart(ctx context.Context, u *User, testID, courseID, stepID int64) {
	if _, err := s.db.Exec(ctx, `UPDATE learn_assignees SET status = 1, started_at = now() WHERE user_id = $1 AND target_type = 'test' AND target_id = $2 AND status = 0`, u.ID, testID); err != nil {
		s.log.Warn("lms attempt start", "err", err)
	}
	if stepID > 0 {
		if co, err := s.lmsLoadCourse(ctx, courseID); err == nil {
			s.lmsTouch(ctx, u.ID, u.Dept, co, stepID)
		}
	}
}

// lmsAfterAttempt вызывается после завершения попытки (один раз): шаг курса, назначение теста, сертификат за тест.
func (s *Server) lmsAfterAttempt(ctx context.Context, a *lattempt, t *ltest) {
	passed := a.Passed != nil && *a.Passed
	pct := 0.0
	if a.Percent != nil {
		pct = *a.Percent
	}
	var dept int64
	s.db.QueryRow(ctx, `SELECT coalesce(department_id, 0) FROM users WHERE id = $1`, a.UserID).Scan(&dept)
	if a.StepID != nil && a.CourseID != nil {
		if co, err := s.lmsLoadCourse(ctx, *a.CourseID); err == nil {
			s.lmsTouch(ctx, a.UserID, dept, co, *a.StepID)
			// результат шага: лучший процент; зачёт — по порогу курса
			if _, err := s.db.Exec(ctx, `INSERT INTO learn_step_progress (user_id, step_id, course_id, status, done_at, score, attempt_id)
				VALUES ($1, $2, $3, CASE WHEN $4::boolean THEN 2 ELSE 1 END, CASE WHEN $4::boolean THEN now() END, $5::numeric, $6)
				ON CONFLICT (user_id, step_id) DO UPDATE SET
					status = CASE WHEN learn_step_progress.status = 2 OR $4::boolean THEN 2 ELSE 1 END,
					done_at = CASE WHEN $4::boolean THEN coalesce(learn_step_progress.done_at, now()) ELSE learn_step_progress.done_at END,
					score = greatest(coalesce(learn_step_progress.score, 0), $5::numeric), attempt_id = $6, last_at = now()`,
				a.UserID, *a.StepID, co.ID, passed, pct, a.ID); err != nil {
				s.log.Warn("lms step result", "err", err)
			}
			if _, err := s.lmsRecalc(ctx, a.UserID, dept, co); err != nil {
				s.log.Warn("lms recalc", "err", err)
			}
		}
	}
	if passed {
		if _, err := s.db.Exec(ctx, `UPDATE learn_assignees SET status = 2, done_at = now(), score = $3::numeric WHERE user_id = $1 AND target_type = 'test' AND target_id = $2 AND status < 2`,
			a.UserID, a.TestID, pct); err != nil {
			s.log.Warn("lms assignee test", "err", err)
		}
		if t != nil && t.CertTemplateID != nil {
			if err := s.lmsIssueForTest(ctx, a, t, dept); err != nil {
				s.log.Warn("lms cert test", "err", err)
			}
		}
	}
}

// jsonOrEmpty — валидный JSON-массив даже для пустого среза.
func jsonOrEmpty(b json.RawMessage) json.RawMessage {
	if len(b) == 0 {
		return json.RawMessage(`[]`)
	}
	return b
}

func errIsNoRows(err error) bool { return errors.Is(err, pgx.ErrNoRows) }

func trimTo(s string, n int) string {
	r := []rune(strings.TrimSpace(s))
	if len(r) > n {
		r = r[:n]
	}
	return string(r)
}
