package server

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/gorilla/websocket"
	"github.com/redis/go-redis/v9"
)

// Hub fans events out to the websocket clients connected to *this* instance.
// Events travel between instances through Redis Pub/Sub: Emit() publishes to
// Redis, every instance that has a local subscriber for the topic receives it
// and writes it to its sockets. No instance needs to know about the others.
type Hub struct {
	s      *Server
	mu     sync.RWMutex
	topics map[string]map[*Client]struct{}
	ps     *redis.PubSub
	conns  atomic.Int64
	up     websocket.Upgrader
}

const chanPrefix = "ws:"

type Client struct {
	hub    *Hub
	conn   *websocket.Conn
	uid    int64
	name   string
	cid    string
	send   chan []byte
	done   chan struct{}
	once   sync.Once
	topics map[string]struct{} // guarded by hub.mu
}

func newHub(s *Server) *Hub {
	h := &Hub{s: s, topics: map[string]map[*Client]struct{}{}}
	h.up = websocket.Upgrader{ReadBufferSize: 1024, WriteBufferSize: 4096, CheckOrigin: s.checkOrigin}
	return h
}

func (s *Server) checkOrigin(r *http.Request) bool {
	o := r.Header.Get("Origin")
	if o == "" {
		return true
	}
	u, err := url.Parse(o)
	if err != nil {
		return false
	}
	if strings.EqualFold(u.Host, r.Host) {
		return true
	}
	for _, a := range s.cfg.AllowedOrigins {
		if a == o {
			return true
		}
	}
	return false
}

func userTopic(id int64) string { return "user:" + strconv.FormatInt(id, 10) }

func (h *Hub) start(ctx context.Context) {
	if h.s.cfg.Realtime == "pg" {
		go h.pollPG(ctx)
		return
	}
	h.ps = h.s.rdb.Subscribe(ctx)
	ch := h.ps.Channel()
	go func() {
		for {
			select {
			case m, ok := <-ch:
				if !ok {
					return
				}
				h.deliver(strings.TrimPrefix(m.Channel, chanPrefix), []byte(m.Payload))
			case <-ctx.Done():
				h.ps.Close()
				return
			}
		}
	}()
}

func (h *Hub) deliver(topic string, payload []byte) {
	if topic == "sys" {
		h.s.handleSys(payload)
		return
	}
	h.mu.RLock()
	defer h.mu.RUnlock()
	for c := range h.topics[topic] {
		select {
		case c.send <- payload:
		case <-c.done:
		default: // slow consumer: drop it, the client will reconnect and resync
			go c.close()
		}
	}
}

func (h *Hub) sub(c *Client, topic string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if _, ok := c.topics[topic]; ok {
		return
	}
	c.topics[topic] = struct{}{}
	set := h.topics[topic]
	if set == nil {
		set = map[*Client]struct{}{}
		h.topics[topic] = set
		if h.ps != nil && h.s.cfg.Realtime != "pg" {
			if err := h.ps.Subscribe(context.Background(), chanPrefix+topic); err != nil {
				h.s.log.Warn("redis subscribe failed", "topic", topic, "err", err)
			}
		}
	}
	set[c] = struct{}{}
}

func (h *Hub) unsub(c *Client, topic string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if _, ok := c.topics[topic]; !ok {
		return
	}
	delete(c.topics, topic)
	set := h.topics[topic]
	delete(set, c)
	if len(set) == 0 {
		delete(h.topics, topic)
		if h.ps != nil && h.s.cfg.Realtime != "pg" {
			h.ps.Unsubscribe(context.Background(), chanPrefix+topic)
		}
	}
}

// Emit publishes an event to every instance subscribed to topic. In "redis" mode it goes through Redis Pub/Sub;
// in "pg" mode (several data centres) it is written to the realtime_events outbox of the primary database and
// every instance reads it from its local replica (see hub_pg.go).
func (h *Hub) Emit(ctx context.Context, topic, typ string, data any) {
	b, err := json.Marshal(map[string]any{"t": typ, "d": data})
	if err != nil {
		return
	}
	if h.s.cfg.Realtime == "pg" {
		if _, err := h.s.db.Exec(ctx, `INSERT INTO realtime_events (topic, payload) VALUES ($1, $2)`, topic, string(b)); err != nil {
			h.s.log.Warn("outbox insert failed", "topic", topic, "err", err)
		}
		return
	}
	if err := h.s.rdb.Publish(ctx, chanPrefix+topic, b).Err(); err != nil {
		h.s.log.Warn("publish failed", "topic", topic, "err", err)
	}
}

func (h *Hub) EmitUsers(ctx context.Context, uids []int64, typ string, data any) {
	for _, id := range uids {
		h.Emit(ctx, userTopic(id), typ, data)
	}
}

// ---------------------------------------------------------------- websocket

func (s *Server) serveWS(c *Ctx) error {
	conn, err := s.hub.up.Upgrade(c.W, c.R, nil)
	if err != nil {
		return nil // Upgrade has already written the HTTP error
	}
	cl := &Client{hub: s.hub, conn: conn, uid: c.U.ID, name: c.U.Name, cid: newToken()[:12],
		send: make(chan []byte, 128), done: make(chan struct{}), topics: map[string]struct{}{}}
	s.hub.conns.Add(1)
	s.hub.sub(cl, userTopic(cl.uid))
	s.hub.sub(cl, "feed")
	s.hub.sub(cl, "presence")
	if s.presenceUp(context.Background(), cl.uid, cl.cid) {
		s.hub.Emit(context.Background(), "presence", "presence", map[string]any{"user_id": cl.uid, "online": true})
	}
	cl.send <- []byte(`{"t":"hello","d":{"instance":` + strconv.Quote(s.cfg.InstanceID) + `}}`)
	go cl.writePump()
	go cl.readPump()
	return nil
}

func (c *Client) close() {
	c.once.Do(func() {
		close(c.done)
		c.conn.Close()
		h := c.hub
		h.mu.Lock()
		topics := make([]string, 0, len(c.topics))
		for t := range c.topics {
			topics = append(topics, t)
		}
		h.mu.Unlock()
		for _, t := range topics {
			h.unsub(c, t)
		}
		h.conns.Add(-1)
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		if h.s.presenceDown(ctx, c.uid, c.cid) {
			h.Emit(ctx, "presence", "presence", map[string]any{"user_id": c.uid, "online": false})
		}
	})
}

func (c *Client) writePump() {
	tick := time.NewTicker(25 * time.Second)
	defer func() { tick.Stop(); c.close() }()
	for {
		select {
		case m := <-c.send:
			c.conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if err := c.conn.WriteMessage(websocket.TextMessage, m); err != nil {
				return
			}
		case <-tick.C:
			c.conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if err := c.conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
			ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			c.hub.s.presenceBeat(ctx, c.uid, c.cid)
			cancel()
		case <-c.done:
			return
		}
	}
}

func (c *Client) readPump() {
	defer c.close()
	c.conn.SetReadLimit(4096)
	c.conn.SetReadDeadline(time.Now().Add(70 * time.Second))
	c.conn.SetPongHandler(func(string) error {
		return c.conn.SetReadDeadline(time.Now().Add(70 * time.Second))
	})
	for {
		_, data, err := c.conn.ReadMessage()
		if err != nil {
			return
		}
		c.conn.SetReadDeadline(time.Now().Add(70 * time.Second))
		var m struct {
			T      string `json:"t"`
			Topic  string `json:"topic"`
			ChatID int64  `json:"chat_id"`
		}
		if json.Unmarshal(data, &m) != nil {
			continue
		}
		switch m.T {
		case "sub":
			if (strings.HasPrefix(m.Topic, "news:") || strings.HasPrefix(m.Topic, "idea:")) && len(m.Topic) < 24 { // live comments on an open article
				c.hub.sub(c, m.Topic)
			} else if strings.HasPrefix(m.Topic, "group:") && len(m.Topic) < 24 {
				go c.subGroup(m.Topic) // реакции в ленте группы: подписка только с правом чтения группы
			}
		case "unsub":
			if strings.HasPrefix(m.Topic, "news:") || strings.HasPrefix(m.Topic, "idea:") || strings.HasPrefix(m.Topic, "group:") {
				c.hub.unsub(c, m.Topic)
			}
		case "typing":
			go c.typing(m.ChatID)
		}
	}
}

func (c *Client) typing(chatID int64) {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	s := c.hub.s
	if chatID <= 0 || !s.rdb.SetNX(ctx, fmt.Sprintf("typ:%d:%d", c.uid, chatID), 1, 2*time.Second).Val() {
		return
	}
	members, err := s.chatMembers(ctx, chatID)
	if err != nil {
		return
	}
	member := false
	for _, id := range members {
		member = member || id == c.uid
	}
	if !member {
		return
	}
	for _, id := range members {
		if id != c.uid {
			s.hub.Emit(ctx, userTopic(id), "typing", map[string]any{"chat_id": chatID, "user_id": c.uid, "name": c.name})
		}
	}
}

// ---------------------------------------------------------------- presence

// Presence is kept in Redis so every instance sees the same picture:
//
//	pc:<uid>  ZSET connId -> expiry   (all live sockets of a user, across instances)
//	online    ZSET uid    -> expiry   (users with at least one live socket)
const presenceTTL = 70

func (s *Server) presenceUp(ctx context.Context, uid int64, cid string) (first bool) {
	key := "pc:" + strconv.FormatInt(uid, 10)
	now := time.Now().Unix()
	s.rdb.ZRemRangeByScore(ctx, key, "-inf", strconv.FormatInt(now, 10))
	n, _ := s.rdb.ZCard(ctx, key).Result()
	s.rdb.ZAdd(ctx, key, redis.Z{Score: float64(now + presenceTTL), Member: cid})
	s.rdb.Expire(ctx, key, 3*presenceTTL*time.Second)
	s.rdb.ZAdd(ctx, "online", redis.Z{Score: float64(now + presenceTTL), Member: uid})
	return n == 0
}

func (s *Server) presenceBeat(ctx context.Context, uid int64, cid string) {
	key := "pc:" + strconv.FormatInt(uid, 10)
	exp := float64(time.Now().Unix() + presenceTTL)
	s.rdb.ZAdd(ctx, key, redis.Z{Score: exp, Member: cid})
	s.rdb.Expire(ctx, key, 3*presenceTTL*time.Second)
	s.rdb.ZAdd(ctx, "online", redis.Z{Score: exp, Member: uid})
}

func (s *Server) presenceDown(ctx context.Context, uid int64, cid string) (last bool) {
	key := "pc:" + strconv.FormatInt(uid, 10)
	s.rdb.ZRem(ctx, key, cid)
	s.rdb.ZRemRangeByScore(ctx, key, "-inf", strconv.FormatInt(time.Now().Unix(), 10))
	n, _ := s.rdb.ZCard(ctx, key).Result()
	if n == 0 {
		s.rdb.ZRem(ctx, "online", uid)
		s.db.Exec(ctx, `UPDATE users SET last_seen = now() WHERE id = $1`, uid)
		return true
	}
	return false
}

func (s *Server) onlineIDs(ctx context.Context) []int64 {
	now := strconv.FormatInt(time.Now().Unix(), 10)
	s.rdb.ZRemRangeByScore(ctx, "online", "-inf", now)
	vals, _ := s.rdb.ZRangeByScore(ctx, "online", &redis.ZRangeBy{Min: "(" + now, Max: "+inf"}).Result()
	ids := make([]int64, 0, len(vals))
	for _, v := range vals {
		if id, err := strconv.ParseInt(v, 10, 64); err == nil {
			ids = append(ids, id)
		}
	}
	return ids
}

func (s *Server) presence(c *Ctx) error {
	return c.JSON(200, map[string]any{"online": s.onlineIDs(c.Context())})
}

// ---------------------------------------------------------------- notifications

// notify stores a notification for every user in uids and pushes it live.
func (s *Server) notify(ctx context.Context, uids []int64, kind, title, body, link string) {
	if len(uids) == 0 {
		return
	}
	if !validAppLink(link) {
		s.log.Warn("notification link is not an SPA route", "kind", kind, "link", link)
	}
	if _, err := s.db.Exec(ctx, `INSERT INTO notifications (user_id, kind, title, body, link)
		SELECT x, $2, $3, $4, $5 FROM unnest($1::bigint[]) AS x`, uids, kind, title, body, link); err != nil {
		s.log.Warn("notify failed", "err", err)
		return
	}
	s.hub.EmitUsers(ctx, uids, "notif", map[string]string{"kind": kind, "title": title, "body": body, "link": link})
}
