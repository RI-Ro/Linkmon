package server

import (
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"
)

// Статистика обучения. Источники — денормализованные таблицы (learn_assignees, learn_enrollments, learn_attempts);
// область (подразделения ответственного) проверяется в каждом запросе условием на users.department_id.

// asgFilter — общие условия по назначениям (алиас a): цель и период назначения.
func asgFilter(c *Ctx, b *qb) []string {
	w := []string{"a.status < 3"}
	if t := c.Q("type"); t == "course" || t == "test" {
		if id := c.QInt64("id"); id > 0 {
			w = append(w, "a.target_type = "+b.add(t)+"::text", "a.target_id = "+b.add(id)+"::bigint")
		} else {
			w = append(w, "a.target_type = "+b.add(t)+"::text")
		}
	}
	if v := c.Q("from"); v != "" {
		if t, err := time.ParseInLocation("2006-01-02", v, msk()); err == nil {
			w = append(w, "a.assigned_at >= "+b.add(t)+"::timestamptz")
		}
	}
	if v := c.Q("to"); v != "" {
		if t, err := time.ParseInLocation("2006-01-02", v, msk()); err == nil {
			w = append(w, "a.assigned_at < "+b.add(t.AddDate(0, 0, 1))+"::timestamptz")
		}
	}
	return w
}

// deptCond — фильтр по подразделению (поддерево) для столбца u.department_id.
func deptCond(c *Ctx, b *qb, col string) string {
	if d := c.QInt64("dept"); d > 0 {
		return col + " IN " + deptSubtree(b.add(d)+"::bigint")
	}
	return "true"
}

func (s *Server) lmsStatsMe(c *Ctx) error {
	sc, err := s.lmsScope(c.Context(), c.U)
	if err != nil {
		return err
	}
	if sc == nil {
		return c.JSON(200, map[string]any{"manager": false})
	}
	roots := json.RawMessage(`[]`)
	if !sc.All {
		roots, err = s.arr(c.Context(), `SELECT d.id, d.name FROM departments d WHERE d.id = ANY($1::bigint[]) AND (d.parent_id IS NULL OR NOT d.parent_id = ANY($1::bigint[])) ORDER BY d.name`, sc.IDs)
		if err != nil {
			return err
		}
	}
	return c.JSON(200, map[string]any{"manager": true, "all": sc.All, "roots": roots})
}

// ---------------------------------------------------------------- обзор

func (s *Server) lmsStatsOverview(c *Ctx) error {
	sc, err := s.lmsManager(c)
	if err != nil {
		return err
	}
	ctx := c.Context()
	b := &qb{}
	w := append(asgFilter(c, b), sc.cond(b, "u.department_id"), "NOT u.blocked", deptCond(c, b, "u.department_id"))
	asg, err := s.one(ctx, `SELECT count(*) AS total, count(*) FILTER (WHERE a.status = 1) AS progress, count(*) FILTER (WHERE a.status = 2) AS done,
			count(*) FILTER (WHERE a.status < 2 AND a.due_at < now()) AS overdue, count(DISTINCT a.user_id) FILTER (WHERE a.status < 2 AND a.due_at < now()) AS overdue_users, count(*) FILTER (WHERE a.status = 1 AND a.due_at < now()) AS progress_overdue,
			coalesce(round(avg(a.score) FILTER (WHERE a.status = 2), 1), 0)::float8 AS avg_score
		FROM learn_assignees a JOIN users u ON u.id = a.user_id WHERE `+strings.Join(w, " AND "), b.args...)
	if err != nil {
		return err
	}
	b2 := &qb{}
	w2 := []string{"NOT u.blocked", sc.cond(b2, "u.department_id"), deptCond(c, b2, "u.department_id")}
	emp, err := s.one(ctx, `SELECT count(*) AS employees FROM users u WHERE `+strings.Join(w2, " AND "), b2.args...)
	if err != nil {
		return err
	}
	b3 := &qb{}
	w3 := []string{sc.cond(b3, "u.department_id"), "NOT u.blocked", deptCond(c, b3, "u.department_id")}
	att, err := s.one(ctx, `SELECT count(*) AS attempts, count(*) FILTER (WHERE a.passed) AS passed FROM learn_attempts a JOIN users u ON u.id = a.user_id
		WHERE a.finished_at > now() - interval '30 days' AND `+strings.Join(w3, " AND "), b3.args...)
	if err != nil {
		return err
	}
	b4 := &qb{}
	w4 := []string{sc.cond(b4, "k.dept_id"), deptCond(c, b4, "k.dept_id")}
	cert, err := s.one(ctx, `SELECT count(*) FILTER (WHERE k.status = 'valid' AND (k.expires_at IS NULL OR k.expires_at >= now())) AS valid,
			count(*) FILTER (WHERE k.status = 'valid' AND k.expires_at >= now() AND k.expires_at < now() + interval '30 days') AS soon FROM learn_certs k WHERE `+strings.Join(w4, " AND "), b4.args...)
	if err != nil {
		return err
	}
	// динамика по неделям (12 недель): назначено / завершено в области (с учётом фильтров цели и подразделения)
	b5 := &qb{}
	w5 := append(asgFilter(c, b5), sc.cond(b5, "u.department_id"), "NOT u.blocked", deptCond(c, b5, "u.department_id"))
	trend, err := s.arr(ctx, `SELECT to_char(w, 'YYYY-MM-DD') AS week,
			(SELECT count(*) FROM learn_assignees a JOIN users u ON u.id = a.user_id WHERE `+strings.Join(w5, " AND ")+` AND a.assigned_at >= w AND a.assigned_at < w + interval '7 days') AS assigned,
			(SELECT count(*) FROM learn_assignees a JOIN users u ON u.id = a.user_id WHERE `+strings.Join(w5, " AND ")+` AND a.status = 2 AND a.done_at >= w AND a.done_at < w + interval '7 days') AS completed
		FROM generate_series(date_trunc('week', now()) - interval '11 weeks', date_trunc('week', now()), interval '7 days') w ORDER BY w`, b5.args...)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]json.RawMessage{"assignments": asg, "employees": emp, "attempts": att, "certs": cert, "trend": trend})
}

// ---------------------------------------------------------------- подразделения

type deptStat struct {
	ID        int64   `json:"id"`
	ParentID  *int64  `json:"parent_id"`
	Name      string  `json:"name"`
	Employees int     `json:"employees"`
	Total     int     `json:"total"`
	Progress  int     `json:"progress"`
	Done      int     `json:"done"`
	Overdue   int     `json:"overdue"`
	ScoreSum  float64 `json:"score_sum"`
	ScoreN    int     `json:"score_n"`
}

func (s *Server) lmsDeptStats(c *Ctx, sc *scope) ([]*deptStat, error) {
	ctx := c.Context()
	b := &qb{}
	rows, err := s.db.Query(ctx, `SELECT d.id, d.parent_id, d.name FROM departments d WHERE `+sc.cond(b, "d.id")+` ORDER BY d.sort, lower(d.name), d.id`, b.args...)
	if err != nil {
		return nil, err
	}
	var list []*deptStat
	byID := map[int64]*deptStat{}
	for rows.Next() {
		d := &deptStat{}
		if err := rows.Scan(&d.ID, &d.ParentID, &d.Name); err != nil {
			rows.Close()
			return nil, err
		}
		list, byID[d.ID] = append(list, d), d
	}
	rows.Close()
	b2 := &qb{}
	rows, err = s.db.Query(ctx, `SELECT u.department_id, count(*) FROM users u WHERE NOT u.blocked AND u.department_id IS NOT NULL AND `+sc.cond(b2, "u.department_id")+` GROUP BY 1`, b2.args...)
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var id int64
		var n int
		rows.Scan(&id, &n)
		if d := byID[id]; d != nil {
			d.Employees = n
		}
	}
	rows.Close()
	b3 := &qb{}
	w := append(asgFilter(c, b3), "NOT u.blocked", sc.cond(b3, "u.department_id"))
	rows, err = s.db.Query(ctx, `SELECT u.department_id, count(*), count(*) FILTER (WHERE a.status = 1), count(*) FILTER (WHERE a.status = 2),
			count(*) FILTER (WHERE a.status < 2 AND a.due_at < now()), coalesce(sum(a.score) FILTER (WHERE a.status = 2), 0)::float8, count(a.score) FILTER (WHERE a.status = 2)
		FROM learn_assignees a JOIN users u ON u.id = a.user_id WHERE `+strings.Join(w, " AND ")+` AND u.department_id IS NOT NULL GROUP BY 1`, b3.args...)
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var id int64
		var t, p, dn, o, sn int
		var ss float64
		rows.Scan(&id, &t, &p, &dn, &o, &ss, &sn)
		if d := byID[id]; d != nil {
			d.Total, d.Progress, d.Done, d.Overdue, d.ScoreSum, d.ScoreN = t, p, dn, o, ss, sn
		}
	}
	rows.Close()
	return list, nil
}

func (s *Server) lmsStatsDepts(c *Ctx) error {
	sc, err := s.lmsManager(c)
	if err != nil {
		return err
	}
	list, err := s.lmsDeptStats(c, sc)
	if err != nil {
		return err
	}
	if list == nil {
		list = []*deptStat{}
	}
	return c.JSON(200, map[string]any{"items": list})
}

// ---------------------------------------------------------------- курсы и тесты

func (s *Server) lmsStatsTargets(c *Ctx) error {
	sc, err := s.lmsManager(c)
	if err != nil {
		return err
	}
	ctx := c.Context()
	b := &qb{}
	scopeW := "NOT u.blocked AND " + sc.cond(b, "u.department_id") + " AND " + deptCond(c, b, "u.department_id")
	q := strings.ToLower(c.Q("q"))
	qw := ""
	if q != "" {
		qw = " AND lower(x.title) LIKE " + b.add("%"+likeEscape(q)+"%") + " ESCAPE '\\'"
	}
	var out []byte
	if c.Q("type") == "test" {
		out, err = s.arr(ctx, `SELECT x.id, x.title, g.attempts, g.users, g.users_passed, g.first_n, g.first_passed, g.avg_percent, g.avg_sec
			FROM (SELECT a.test_id, count(*) AS attempts, count(DISTINCT a.user_id) AS users, count(DISTINCT a.user_id) FILTER (WHERE a.passed) AS users_passed,
					count(*) FILTER (WHERE a.no = 1) AS first_n, count(*) FILTER (WHERE a.no = 1 AND a.passed) AS first_passed,
					round(avg(a.percent), 1)::float8 AS avg_percent, round(avg(a.duration_sec))::int AS avg_sec
				FROM learn_attempts a JOIN users u ON u.id = a.user_id WHERE a.finished_at IS NOT NULL AND `+scopeW+` GROUP BY a.test_id) g
			JOIN learn_tests x ON x.id = g.test_id WHERE true`+qw+` ORDER BY g.attempts DESC, x.id LIMIT 300`, b.args...)
	} else {
		out, err = s.arr(ctx, `SELECT x.id, x.title, g.enrolled, g.progress, g.completed, g.avg_score, g.avg_sec, g.expired
			FROM (SELECT e.course_id, count(*) FILTER (WHERE e.status > 0) AS enrolled, count(*) FILTER (WHERE e.status = 1) AS progress, count(*) FILTER (WHERE e.status = 2) AS completed,
					round(avg(e.score) FILTER (WHERE e.status = 2), 1)::float8 AS avg_score, round(avg(e.time_sec) FILTER (WHERE e.status = 2))::int AS avg_sec,
					count(*) FILTER (WHERE e.status = 2 AND e.expires_at < now()) AS expired
				FROM learn_enrollments e JOIN users u ON u.id = e.user_id WHERE `+scopeW+` GROUP BY e.course_id) g
			JOIN learn_courses x ON x.id = g.course_id WHERE true`+qw+` ORDER BY g.enrolled DESC, x.id LIMIT 300`, b.args...)
	}
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"items": json.RawMessage(out)})
}

type qStat struct {
	ID      int64          `json:"id"`
	Text    string         `json:"text"`
	Type    string         `json:"type"`
	N       int            `json:"n"`
	Correct int            `json:"correct"`
	Skipped int            `json:"skipped"`
	Part    int            `json:"partial"`
	Wrong   []wrongPick    `json:"wrong"`
	picks   map[string]int `json:"-"`
}

type wrongPick struct {
	Text string `json:"text"`
	N    int    `json:"n"`
}

func (s *Server) lmsStatsTarget(c *Ctx) error {
	sc, err := s.lmsManager(c)
	if err != nil {
		return err
	}
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	typ := c.R.PathValue("type")
	b := &qb{}
	scopeW := "NOT u.blocked AND " + sc.cond(b, "u.department_id") + " AND " + deptCond(c, b, "u.department_id")
	tid := b.add(id)
	out := map[string]any{"type": typ}
	switch typ {
	case "course":
		var title string
		if err := s.db.QueryRow(ctx, `SELECT title FROM learn_courses WHERE id = $1`, id).Scan(&title); err != nil {
			return err
		}
		out["title"] = title
		out["summary"], err = s.one(ctx, `SELECT count(*) FILTER (WHERE e.status > 0) AS enrolled, count(*) FILTER (WHERE e.status = 1) AS progress, count(*) FILTER (WHERE e.status = 2) AS completed,
				coalesce(round(avg(e.score) FILTER (WHERE e.status = 2), 1), 0)::float8 AS avg_score, coalesce(round(avg(e.time_sec) FILTER (WHERE e.status = 2)), 0)::int AS avg_sec,
				coalesce(round(avg(e.percent) FILTER (WHERE e.status = 1)), 0)::int AS avg_progress
			FROM learn_enrollments e JOIN users u ON u.id = e.user_id WHERE e.course_id = `+tid+`::bigint AND `+scopeW, b.args...)
		if err != nil {
			return err
		}
		out["histogram"], err = s.arr(ctx, `SELECT least(floor(e.score / 10), 9)::int AS b, count(*) AS n FROM learn_enrollments e JOIN users u ON u.id = e.user_id
			WHERE e.course_id = `+tid+`::bigint AND e.status = 2 AND e.score IS NOT NULL AND `+scopeW+` GROUP BY 1 ORDER BY 1`, b.args...)
		if err != nil {
			return err
		}
		out["weekly"], err = s.arr(ctx, `SELECT to_char(date_trunc('week', ts), 'YYYY-MM-DD') AS week, count(*) FILTER (WHERE k = 's') AS started, count(*) FILTER (WHERE k = 'c') AS completed
			FROM (SELECT e.started_at AS ts, 's' AS k FROM learn_enrollments e JOIN users u ON u.id = e.user_id WHERE e.course_id = `+tid+`::bigint AND e.started_at > now() - interval '26 weeks' AND `+scopeW+`
				UNION ALL SELECT e.completed_at, 'c' FROM learn_enrollments e JOIN users u ON u.id = e.user_id WHERE e.course_id = `+tid+`::bigint AND e.completed_at > now() - interval '26 weeks' AND `+scopeW+`) z
			GROUP BY 1 ORDER BY 1`, b.args...)
		if err != nil {
			return err
		}
		out["steps"], err = s.arr(ctx, `SELECT st.id, st.sort, st.kind, st.title, st.required, count(sp.user_id) FILTER (WHERE sp.status > 0) AS opened, count(sp.user_id) FILTER (WHERE sp.status = 2) AS done,
				coalesce(round(avg(sp.time_sec) FILTER (WHERE sp.status > 0)), 0)::int AS avg_sec, round(avg(sp.score), 1)::float8 AS avg_score
			FROM learn_course_steps st LEFT JOIN learn_step_progress sp ON sp.step_id = st.id AND EXISTS (SELECT 1 FROM users u WHERE u.id = sp.user_id AND `+scopeW+`)
			WHERE st.course_id = `+tid+`::bigint GROUP BY st.id ORDER BY st.sort, st.id`, b.args...)
		if err != nil {
			return err
		}
	case "test":
		var title string
		if err := s.db.QueryRow(ctx, `SELECT title FROM learn_tests WHERE id = $1`, id).Scan(&title); err != nil {
			return err
		}
		out["title"] = title
		base := ` FROM learn_attempts a JOIN users u ON u.id = a.user_id WHERE a.test_id = ` + tid + `::bigint AND a.finished_at IS NOT NULL AND ` + scopeW
		out["summary"], err = s.one(ctx, `SELECT count(*) AS attempts, count(DISTINCT a.user_id) AS users, count(DISTINCT a.user_id) FILTER (WHERE a.passed) AS users_passed,
				count(*) FILTER (WHERE a.no = 1) AS first_n, count(*) FILTER (WHERE a.no = 1 AND a.passed) AS first_passed,
				coalesce(round(avg(a.percent), 1), 0)::float8 AS avg_percent, coalesce(round(avg(a.duration_sec)), 0)::int AS avg_sec`+base, b.args...)
		if err != nil {
			return err
		}
		out["histogram"], err = s.arr(ctx, `SELECT least(floor(a.percent / 10), 9)::int AS b, count(*) AS n`+base+` GROUP BY 1 ORDER BY 1`, b.args...)
		if err != nil {
			return err
		}
		out["weekly"], err = s.arr(ctx, `SELECT to_char(date_trunc('week', a.finished_at), 'YYYY-MM-DD') AS week, count(*) AS attempts, count(*) FILTER (WHERE a.passed) AS passed,
				round(avg(a.percent), 1)::float8 AS avg_percent`+base+` AND a.finished_at > now() - interval '26 weeks' GROUP BY 1 ORDER BY 1`, b.args...)
		if err != nil {
			return err
		}
		qs, err := s.lmsQuestionStats(ctx, id, base, b.args)
		if err != nil {
			return err
		}
		out["questions"] = qs
	default:
		return errNotFound
	}
	return c.JSON(200, out)
}

// lmsQuestionStats — разбор вопросов теста по последним попыткам области: % верных, пропуски, популярные ошибочные варианты.
func (s *Server) lmsQuestionStats(ctx context.Context, test int64, base string, args []any) ([]*qStat, error) {
	qs, err := s.learnLoadQuestions(ctx, test)
	if err != nil {
		return nil, err
	}
	st := map[int64]*qStat{}
	opt := map[int64]map[int]string{}
	correct := map[int64]map[int]bool{}
	var list []*qStat
	for _, q := range qs {
		x := &qStat{ID: q.ID, Text: q.Text, Type: q.Type, picks: map[string]int{}, Wrong: []wrongPick{}}
		st[q.ID], list = x, append(list, x)
		opt[q.ID], correct[q.ID] = map[int]string{}, map[int]bool{}
		for _, o := range q.Options {
			opt[q.ID][o.ID], correct[q.ID][o.ID] = o.Text, o.Correct
		}
	}
	rows, err := s.db.Query(ctx, `SELECT a.answers, a.details`+base+` ORDER BY a.finished_at DESC LIMIT 20000`, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var ans map[string]json.RawMessage
		var det map[string]qres
		var ab, db []byte
		if err := rows.Scan(&ab, &db); err != nil {
			return nil, err
		}
		json.Unmarshal(ab, &ans)
		json.Unmarshal(db, &det)
		for k, r := range det {
			qid, _ := strconv.ParseInt(k, 10, 64)
			x := st[qid]
			if x == nil {
				continue
			}
			x.N++
			switch r.S {
			case 2:
				x.Correct++
			case 1:
				x.Part++
			case -1:
				x.Skipped++
			}
			if r.S == 2 || r.S == -1 {
				continue
			}
			switch x.Type {
			case "single", "multiple":
				ids, _ := ansIDs(ans[k])
				for _, id := range ids {
					if !correct[qid][id] {
						x.picks[opt[qid][id]]++
					}
				}
			case "text":
				var t string
				json.Unmarshal(ans[k], &t)
				if t = normText(t); t != "" {
					x.picks[t]++
				}
			}
		}
	}
	for _, x := range list {
		for t, n := range x.picks {
			x.Wrong = append(x.Wrong, wrongPick{t, n})
		}
		sort.Slice(x.Wrong, func(i, j int) bool {
			return x.Wrong[i].N > x.Wrong[j].N || (x.Wrong[i].N == x.Wrong[j].N && x.Wrong[i].Text < x.Wrong[j].Text)
		})
		if len(x.Wrong) > 4 {
			x.Wrong = x.Wrong[:4]
		}
	}
	return list, rows.Err()
}

// ---------------------------------------------------------------- пользователи

var userSorts = map[string]string{
	"name": "lower(u.last_name), lower(u.first_name), u.id", "dept": "lower(d.name) NULLS LAST, lower(u.last_name), u.id",
	"overdue": "agg.overdue DESC, lower(u.last_name), u.id", "done": "agg.done DESC, lower(u.last_name), u.id", "total": "agg.total DESC, lower(u.last_name), u.id",
	"score": "agg.score DESC NULLS LAST, lower(u.last_name), u.id", "last": "lst.last_at DESC NULLS LAST, lower(u.last_name), u.id",
}

// usersQuery собирает запрос таблицы сотрудников (общий для API и экспорта). Возвращает SQL без LIMIT.
func (s *Server) lmsUsersQuery(c *Ctx, sc *scope, b *qb) (sel, from, where, order string) {
	asg := strings.Join(asgFilter(c, b), " AND ")
	// фильтр по курсу/тесту в таблице сотрудников: цель задаётся параметрами type/id
	sel = `u.id, u.full_name AS name, u.job_title, d.name AS department, u.department_id, coalesce(agg.total, 0) AS total, coalesce(agg.done, 0) AS done,
		coalesce(agg.overdue, 0) AS overdue, coalesce(agg.progress, 0) AS progress, agg.score::float8 AS score, lst.last_at`
	from = ` FROM users u LEFT JOIN departments d ON d.id = u.department_id
		LEFT JOIN LATERAL (SELECT count(*) AS total, count(*) FILTER (WHERE a.status = 2) AS done, count(*) FILTER (WHERE a.status = 1) AS progress,
				count(*) FILTER (WHERE a.status < 2 AND a.due_at < now()) AS overdue, round(avg(a.score) FILTER (WHERE a.status = 2), 1) AS score
			FROM learn_assignees a WHERE a.user_id = u.id AND ` + asg + `) agg ON true
		LEFT JOIN LATERAL (SELECT max(e.last_at) AS last_at FROM learn_enrollments e WHERE e.user_id = u.id) lst ON true`
	w := []string{"NOT u.blocked", sc.cond(b, "u.department_id"), deptCond(c, b, "u.department_id")}
	if q := strings.ToLower(c.Q("q")); q != "" {
		w = append(w, "u.search_text LIKE "+b.add("%"+likeEscape(q)+"%")+" ESCAPE '\\'")
	}
	switch c.Q("status") {
	case "overdue":
		w = append(w, "agg.overdue > 0")
	case "open":
		w = append(w, "agg.total > agg.done")
	case "done":
		w = append(w, "agg.total > 0 AND agg.total = agg.done")
	case "none":
		w = append(w, "coalesce(agg.total, 0) = 0")
	}
	if c.QInt64("id") > 0 && c.Q("type") != "" { // по конкретному курсу/тесту — только назначенные
		w = append(w, "agg.total > 0")
	}
	order = userSorts[c.Q("sort")]
	if order == "" {
		order = userSorts["name"]
	}
	return sel, from, strings.Join(w, " AND "), order
}

func (s *Server) lmsStatsUsers(c *Ctx) error {
	sc, err := s.lmsManager(c)
	if err != nil {
		return err
	}
	ctx := c.Context()
	page, per, off := c.Page(50, 200)
	b := &qb{}
	sel, from, where, order := s.lmsUsersQuery(c, sc, b)
	var total int
	if err := s.db.QueryRow(ctx, `SELECT count(*)`+from+` WHERE `+where, b.args...).Scan(&total); err != nil {
		return err
	}
	lim, offs := b.add(per), b.add(off)
	items, err := s.arr(ctx, `SELECT `+sel+from+` WHERE `+where+` ORDER BY `+order+` LIMIT `+lim+` OFFSET `+offs, b.args...)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"items": json.RawMessage(items), "total": total, "page": page, "per": per})
}

func (s *Server) lmsStatsUser(c *Ctx) error {
	sc, err := s.lmsManager(c)
	if err != nil {
		return err
	}
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	ok, err := s.lmsUserIn(ctx, sc, id)
	if err != nil {
		return err
	}
	if !ok {
		return errForbidden
	}
	user, err := s.one(ctx, `SELECT u.id, u.full_name AS name, u.job_title, d.name AS department, u.department_id FROM users u LEFT JOIN departments d ON d.id = u.department_id WHERE u.id = $1`, id)
	if err != nil {
		return err
	}
	asg, err := s.arr(ctx, `SELECT a.id, a.assignment_id, a.target_type, a.target_id, coalesce(co.title, t.title, 'Удалено') AS title, a.status, a.assigned_at, a.due_at, a.done_at, a.score::float8 AS score,
			a.cycle, (a.status < 2 AND a.due_at < now()) AS overdue, a.manual_remind_at
		FROM learn_assignees a LEFT JOIN learn_courses co ON a.target_type = 'course' AND co.id = a.target_id LEFT JOIN learn_tests t ON a.target_type = 'test' AND t.id = a.target_id
		WHERE a.user_id = $1 ORDER BY a.assigned_at DESC LIMIT 200`, id)
	if err != nil {
		return err
	}
	enr, err := s.arr(ctx, `SELECT c.id, c.title, e.status, e.percent, e.started_at, e.last_at, e.completed_at, e.expires_at, e.time_sec, e.score::float8 AS score, e.cert_id
		FROM learn_enrollments e JOIN learn_courses c ON c.id = e.course_id WHERE e.user_id = $1 AND e.status > 0 ORDER BY e.last_at DESC NULLS LAST LIMIT 200`, id)
	if err != nil {
		return err
	}
	att, err := s.arr(ctx, `SELECT a.id, a.test_id, t.title, a.no, a.started_at, a.finished_at, a.percent::float8 AS percent, a.passed, a.duration_sec, a.course_id
		FROM learn_attempts a JOIN learn_tests t ON t.id = a.test_id WHERE a.user_id = $1 AND a.finished_at IS NOT NULL ORDER BY a.finished_at DESC LIMIT 200`, id)
	if err != nil {
		return err
	}
	certs, err := s.arr(ctx, `SELECT k.id, k.number, k.title, k.issued_at, k.expires_at, `+certState+` AS state FROM learn_certs k WHERE k.user_id = $1 ORDER BY k.issued_at DESC LIMIT 100`, id)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]json.RawMessage{"user": user, "assignments": asg, "enrollments": enr, "attempts": att, "certs": certs})
}

// ---------------------------------------------------------------- просрочки

func (s *Server) lmsOverdueWhere(c *Ctx, sc *scope, b *qb) string {
	w := []string{"a.status < 2", "a.due_at < now()", "NOT u.blocked", sc.cond(b, "u.department_id"), deptCond(c, b, "u.department_id")}
	if t := c.Q("type"); t == "course" || t == "test" {
		w = append(w, "a.target_type = "+b.add(t)+"::text")
		if id := c.QInt64("id"); id > 0 {
			w = append(w, "a.target_id = "+b.add(id)+"::bigint")
		}
	}
	if q := strings.ToLower(c.Q("q")); q != "" {
		w = append(w, "u.search_text LIKE "+b.add("%"+likeEscape(q)+"%")+" ESCAPE '\\'")
	}
	if c.Q("mandatory") != "0" {
		w = append(w, "a.mandatory")
	}
	return strings.Join(w, " AND ")
}

const overdueFrom = ` FROM learn_assignees a JOIN users u ON u.id = a.user_id LEFT JOIN departments d ON d.id = u.department_id
	LEFT JOIN learn_courses co ON a.target_type = 'course' AND co.id = a.target_id LEFT JOIN learn_tests t ON a.target_type = 'test' AND t.id = a.target_id`

func (s *Server) lmsStatsOverdue(c *Ctx) error {
	sc, err := s.lmsManager(c)
	if err != nil {
		return err
	}
	ctx := c.Context()
	page, per, off := c.Page(50, 200)
	b := &qb{}
	where := s.lmsOverdueWhere(c, sc, b)
	var total, users int
	if err := s.db.QueryRow(ctx, `SELECT count(*), count(DISTINCT a.user_id)`+overdueFrom+` WHERE `+where, b.args...).Scan(&total, &users); err != nil {
		return err
	}
	lim, offs := b.add(per), b.add(off)
	items, err := s.arr(ctx, `SELECT a.id, a.user_id, u.full_name AS name, u.job_title, d.name AS department, a.target_type, a.target_id, coalesce(co.title, t.title, 'Удалено') AS title,
			a.due_at, (current_date - (a.due_at AT TIME ZONE 'UTC')::date) AS days, a.high, a.manual_remind_at, a.assigned_at
		`+overdueFrom+` WHERE `+where+` ORDER BY a.due_at, a.id LIMIT `+lim+` OFFSET `+offs, b.args...)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"items": json.RawMessage(items), "total": total, "users": users, "page": page, "per": per})
}

// ---------------------------------------------------------------- экспорт CSV

func (s *Server) lmsStatsExport(c *Ctx) error {
	sc, err := s.lmsManager(c)
	if err != nil {
		return err
	}
	ctx := c.Context()
	kind := c.R.PathValue("kind")
	stamp := time.Now().In(s.loc()).Format("20060102")
	loc := s.loc()
	dtf := func(t *time.Time) string {
		if t == nil {
			return ""
		}
		return t.In(loc).Format("02.01.2006")
	}
	switch kind {
	case "departments":
		list, err := s.lmsDeptStats(c, sc)
		if err != nil {
			return err
		}
		byID := map[int64]*deptStat{}
		kids := map[int64][]*deptStat{}
		var roots []*deptStat
		for _, d := range list {
			byID[d.ID] = d
		}
		for _, d := range list {
			if d.ParentID != nil && byID[*d.ParentID] != nil {
				kids[*d.ParentID] = append(kids[*d.ParentID], d)
			} else {
				roots = append(roots, d)
			}
		}
		w := s.csvStart(c, "learning-departments-"+stamp+".csv")
		w.Write([]string{"Подразделение", "Уровень", "Сотрудников", "Назначено", "В процессе", "Завершено", "Просрочено", "Выполнено, %", "Средний балл"})
		var walk func(d *deptStat, lvl int) deptStat
		walk = func(d *deptStat, lvl int) deptStat {
			t := *d
			rowIdx := -1
			_ = rowIdx
			var sub []deptStat
			for _, k := range kids[d.ID] {
				x := walk(k, lvl+1)
				sub = append(sub, x)
				t.Employees += x.Employees
				t.Total += x.Total
				t.Progress += x.Progress
				t.Done += x.Done
				t.Overdue += x.Overdue
				t.ScoreSum += x.ScoreSum
				t.ScoreN += x.ScoreN
			}
			pct, avg := "", ""
			if t.Total > 0 {
				pct = strings.Replace(strconv.FormatFloat(float64(t.Done)*100/float64(t.Total), 'f', 1, 64), ".", ",", 1)
			}
			if t.ScoreN > 0 {
				avg = strings.Replace(strconv.FormatFloat(t.ScoreSum/float64(t.ScoreN), 'f', 1, 64), ".", ",", 1)
			}
			w.Write([]string{csvCell(strings.Repeat("   ", lvl) + d.Name), strconv.Itoa(lvl + 1), strconv.Itoa(t.Employees), strconv.Itoa(t.Total), strconv.Itoa(t.Progress), strconv.Itoa(t.Done), strconv.Itoa(t.Overdue), pct, avg})
			return t
		}
		for _, r := range roots {
			walk(r, 0)
		}
		w.Flush()
		return nil
	case "users":
		b := &qb{}
		sel, from, where, order := s.lmsUsersQuery(c, sc, b)
		rows, err := s.db.Query(ctx, `SELECT `+sel+from+` WHERE `+where+` ORDER BY `+order, b.args...)
		if err != nil {
			return err
		}
		defer rows.Close()
		w := s.csvStart(c, "learning-users-"+stamp+".csv")
		w.Write([]string{"Сотрудник", "Должность", "Подразделение", "Назначено", "В процессе", "Завершено", "Просрочено", "Средний балл", "Последняя активность"})
		n := 0
		for rows.Next() {
			var id int64
			var name, job string
			var dept *string
			var did *int64
			var total, done, overdue, progress int
			var score *float64
			var last *time.Time
			if err := rows.Scan(&id, &name, &job, &dept, &did, &total, &done, &overdue, &progress, &score, &last); err != nil {
				return err
			}
			dn := ""
			if dept != nil {
				dn = *dept
			}
			w.Write([]string{csvCell(name), csvCell(job), csvCell(dn), strconv.Itoa(total), strconv.Itoa(progress), strconv.Itoa(done), strconv.Itoa(overdue), fnum(score), dtf(last)})
			if n++; n%2000 == 0 {
				w.Flush()
			}
		}
		w.Flush()
		return rows.Err()
	case "overdue":
		b := &qb{}
		where := s.lmsOverdueWhere(c, sc, b)
		rows, err := s.db.Query(ctx, `SELECT u.full_name, u.job_title, coalesce(d.name, ''), a.target_type, coalesce(co.title, t.title, ''), a.assigned_at, a.due_at, a.manual_remind_at`+overdueFrom+` WHERE `+where+` ORDER BY a.due_at, a.id`, b.args...)
		if err != nil {
			return err
		}
		defer rows.Close()
		w := s.csvStart(c, "learning-overdue-"+stamp+".csv")
		w.Write([]string{"Сотрудник", "Должность", "Подразделение", "Тип", "Обучение", "Назначено", "Срок", "Дней просрочки", "Последнее напоминание"})
		for rows.Next() {
			var name, job, dept, typ, title string
			var asg, due time.Time
			var rem *time.Time
			if err := rows.Scan(&name, &job, &dept, &typ, &title, &asg, &due, &rem); err != nil {
				return err
			}
			tn := map[string]string{"course": "Курс", "test": "Тест"}[typ]
			w.Write([]string{csvCell(name), csvCell(job), csvCell(dept), tn, csvCell(title), asg.In(loc).Format("02.01.2006"), due.In(loc).Format("02.01.2006"),
				strconv.Itoa(int(time.Since(due).Hours() / 24)), dtf(rem)})
		}
		w.Flush()
		return rows.Err()
	case "targets":
		b := &qb{}
		scopeW := "NOT u.blocked AND " + sc.cond(b, "u.department_id") + " AND " + deptCond(c, b, "u.department_id")
		w := s.csvStart(c, "learning-"+c.Q("type")+"s-"+stamp+".csv")
		if c.Q("type") == "test" {
			rows, err := s.db.Query(ctx, `SELECT x.title, g.attempts, g.users, g.users_passed, g.first_n, g.first_passed, g.avg_percent, g.avg_sec FROM (
				SELECT a.test_id, count(*) AS attempts, count(DISTINCT a.user_id) AS users, count(DISTINCT a.user_id) FILTER (WHERE a.passed) AS users_passed, count(*) FILTER (WHERE a.no = 1) AS first_n,
					count(*) FILTER (WHERE a.no = 1 AND a.passed) AS first_passed, round(avg(a.percent), 1)::float8 AS avg_percent, round(avg(a.duration_sec))::int AS avg_sec
				FROM learn_attempts a JOIN users u ON u.id = a.user_id WHERE a.finished_at IS NOT NULL AND `+scopeW+` GROUP BY a.test_id) g JOIN learn_tests x ON x.id = g.test_id ORDER BY g.attempts DESC`, b.args...)
			if err != nil {
				return err
			}
			defer rows.Close()
			w.Write([]string{"Тест", "Попыток", "Сотрудников", "Сдали", "Сдали с 1-й попытки, %", "Средний балл, %", "Среднее время, мин"})
			for rows.Next() {
				var title string
				var at, us, up, fn, fp int
				var avg *float64
				var sec *int
				if err := rows.Scan(&title, &at, &us, &up, &fn, &fp, &avg, &sec); err != nil {
					return err
				}
				fr := ""
				if fn > 0 {
					fr = strings.Replace(strconv.FormatFloat(float64(fp)*100/float64(fn), 'f', 1, 64), ".", ",", 1)
				}
				m := ""
				if sec != nil {
					m = strings.Replace(strconv.FormatFloat(float64(*sec)/60, 'f', 1, 64), ".", ",", 1)
				}
				w.Write([]string{csvCell(title), strconv.Itoa(at), strconv.Itoa(us), strconv.Itoa(up), fr, fnum(avg), m})
			}
		} else {
			rows, err := s.db.Query(ctx, `SELECT x.title, g.enrolled, g.progress, g.completed, g.avg_score, g.avg_sec FROM (
				SELECT e.course_id, count(*) FILTER (WHERE e.status > 0) AS enrolled, count(*) FILTER (WHERE e.status = 1) AS progress, count(*) FILTER (WHERE e.status = 2) AS completed,
					round(avg(e.score) FILTER (WHERE e.status = 2), 1)::float8 AS avg_score, round(avg(e.time_sec) FILTER (WHERE e.status = 2))::int AS avg_sec
				FROM learn_enrollments e JOIN users u ON u.id = e.user_id WHERE `+scopeW+` GROUP BY e.course_id) g JOIN learn_courses x ON x.id = g.course_id ORDER BY g.enrolled DESC`, b.args...)
			if err != nil {
				return err
			}
			defer rows.Close()
			w.Write([]string{"Курс", "Приступили", "В процессе", "Завершили", "Средний балл, %", "Среднее время, мин"})
			for rows.Next() {
				var title string
				var en, pr, cm int
				var avg *float64
				var sec *int
				if err := rows.Scan(&title, &en, &pr, &cm, &avg, &sec); err != nil {
					return err
				}
				m := ""
				if sec != nil {
					m = strings.Replace(strconv.FormatFloat(float64(*sec)/60, 'f', 1, 64), ".", ",", 1)
				}
				w.Write([]string{csvCell(title), strconv.Itoa(en), strconv.Itoa(pr), strconv.Itoa(cm), fnum(avg), m})
			}
		}
		w.Flush()
		return nil
	case "matrix":
		return s.lmsExportMatrix(c, sc, stamp)
	}
	return errNotFound
}

// lmsExportMatrix — «люди × курсы»: статус каждого сотрудника области по каждому курсу.
func (s *Server) lmsExportMatrix(c *Ctx, sc *scope, stamp string) error {
	ctx := c.Context()
	loc := s.loc()
	ids := parseIDs(c.Q("courses"))
	b := &qb{}
	scopeW := "NOT u.blocked AND " + sc.cond(b, "u.department_id") + " AND " + deptCond(c, b, "u.department_id")
	type col struct {
		id    int64
		title string
	}
	var cols []col
	var rows interface {
		Next() bool
		Scan(...any) error
		Close()
		Err() error
	}
	var err error
	if len(ids) > 0 {
		rows, err = s.db.Query(ctx, `SELECT id, title FROM learn_courses WHERE id = ANY($1::bigint[]) ORDER BY title LIMIT 60`, ids)
	} else {
		rows, err = s.db.Query(ctx, `SELECT x.id, x.title FROM learn_courses x WHERE x.status = 'published' AND (
			EXISTS (SELECT 1 FROM learn_assignees a JOIN users u ON u.id = a.user_id WHERE a.target_type = 'course' AND a.target_id = x.id AND a.status < 3 AND `+scopeW+`)
			OR EXISTS (SELECT 1 FROM learn_enrollments e JOIN users u ON u.id = e.user_id WHERE e.course_id = x.id AND e.status > 0 AND `+scopeW+`)) ORDER BY x.title LIMIT 60`, b.args...)
	}
	if err != nil {
		return err
	}
	for rows.Next() {
		var x col
		rows.Scan(&x.id, &x.title)
		cols = append(cols, x)
	}
	rows.Close()
	cids := make([]int64, len(cols))
	for i, x := range cols {
		cids[i] = x.id
	}
	type cell struct {
		status    *int
		pct       int
		done, exp *time.Time
		score     *float64
		asg       *int
		due       *time.Time
	}
	cells := map[[2]int64]*cell{}
	get := func(u, cid int64) *cell {
		k := [2]int64{u, cid}
		if cells[k] == nil {
			cells[k] = &cell{}
		}
		return cells[k]
	}
	b2 := &qb{}
	sw2 := "NOT u.blocked AND " + sc.cond(b2, "u.department_id") + " AND " + deptCond(c, b2, "u.department_id")
	cp := b2.add(cids)
	er, err := s.db.Query(ctx, `SELECT e.user_id, e.course_id, e.status, e.percent, e.completed_at, e.expires_at, e.score::float8 FROM learn_enrollments e JOIN users u ON u.id = e.user_id
		WHERE e.course_id = ANY(`+cp+`::bigint[]) AND e.status > 0 AND `+sw2, b2.args...)
	if err != nil {
		return err
	}
	for er.Next() {
		var u, cid int64
		var st, pc int
		var cm, ex *time.Time
		var sco *float64
		er.Scan(&u, &cid, &st, &pc, &cm, &ex, &sco)
		x := get(u, cid)
		x.status, x.pct, x.done, x.exp, x.score = &st, pc, cm, ex, sco
	}
	er.Close()
	b3 := &qb{}
	sw3 := "NOT u.blocked AND " + sc.cond(b3, "u.department_id") + " AND " + deptCond(c, b3, "u.department_id")
	cp3 := b3.add(cids)
	ar, err := s.db.Query(ctx, `SELECT DISTINCT ON (a.user_id, a.target_id) a.user_id, a.target_id, a.status, a.due_at FROM learn_assignees a JOIN users u ON u.id = a.user_id
		WHERE a.target_type = 'course' AND a.target_id = ANY(`+cp3+`::bigint[]) AND a.status < 3 AND `+sw3+` ORDER BY a.user_id, a.target_id, a.cycle DESC`, b3.args...)
	if err != nil {
		return err
	}
	for ar.Next() {
		var u, cid int64
		var st int
		var due *time.Time
		ar.Scan(&u, &cid, &st, &due)
		x := get(u, cid)
		x.asg, x.due = &st, due
	}
	ar.Close()
	b4 := &qb{}
	sw4 := "NOT u.blocked AND " + sc.cond(b4, "u.department_id") + " AND " + deptCond(c, b4, "u.department_id")
	ur, err := s.db.Query(ctx, `SELECT u.id, u.full_name, u.job_title, coalesce(d.name, '') FROM users u LEFT JOIN departments d ON d.id = u.department_id WHERE `+sw4+` ORDER BY lower(u.last_name), lower(u.first_name), u.id`, b4.args...)
	if err != nil {
		return err
	}
	defer ur.Close()
	w := s.csvStart(c, "learning-matrix-"+stamp+".csv")
	head := []string{"Сотрудник", "Должность", "Подразделение"}
	for _, x := range cols {
		head = append(head, csvCell(x.title))
	}
	w.Write(head)
	d := func(t *time.Time) string {
		if t == nil {
			return ""
		}
		return t.In(loc).Format("02.01.2006")
	}
	n := 0
	for ur.Next() {
		var id int64
		var name, job, dept string
		if err := ur.Scan(&id, &name, &job, &dept); err != nil {
			return err
		}
		row := []string{csvCell(name), csvCell(job), csvCell(dept)}
		for _, x := range cols {
			v := ""
			if cl := cells[[2]int64{id, x.id}]; cl != nil {
				switch {
				case cl.status != nil && *cl.status == 2 && cl.exp != nil && cl.exp.Before(time.Now()):
					v = "Истёк срок (" + d(cl.exp) + ")"
				case cl.status != nil && *cl.status == 2:
					v = "Пройден " + d(cl.done)
					if cl.score != nil {
						v += " (" + fnum(cl.score) + "%)"
					}
				case cl.status != nil && *cl.status == 1:
					v = fmt.Sprintf("В процессе %d%%", cl.pct)
				case cl.asg != nil && cl.due != nil && cl.due.Before(time.Now()):
					v = "Просрочено (срок " + d(cl.due) + ")"
				case cl.asg != nil:
					v = "Назначен"
					if cl.due != nil {
						v += " (до " + d(cl.due) + ")"
					}
				}
			}
			row = append(row, v)
		}
		w.Write(row)
		if n++; n%2000 == 0 {
			w.Flush()
		}
	}
	w.Flush()
	return ur.Err()
}
