package server

import (
	"context"
	"crypto/sha1"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"
	"unicode"

	"github.com/jackc/pgx/v5"
)

const newsCols = `n.id, n.title, coalesce(nullif(n.summary, ''), left(n.body, 240)) AS summary, n.cover, n.important, n.pinned, n.status, n.hidden,
	n.published_at, n.visible_until, n.likes_count, n.comments_count, n.views_count, n.category_id, c.name AS category, c.color AS category_color,
	n.author_id, u.full_name AS author, u.avatar AS author_avatar, u.job_title AS author_title,
	n.department_id, d.name AS department, n.direction_id,
	to_char(n.published_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') || '|' || n.id AS cur`

const newsFrom = ` FROM news n LEFT JOIN categories c ON c.id = n.category_id
	LEFT JOIN users u ON u.id = n.author_id LEFT JOIN departments d ON d.id = n.department_id`

// visibleNow — новость показывается читателям: опубликована, не скрыта, наступило время показа и оно не истекло.
const visibleNow = `n.status = 'published' AND NOT n.hidden AND n.published_at <= now() AND (n.visible_until IS NULL OR n.visible_until > now())`

// ---------------------------------------------------------------- search helpers

// searchTokens splits user input into lower-case words (letters and digits only).
func searchTokens(q string) []string {
	words := strings.FieldsFunc(strings.ToLower(q), func(r rune) bool { return !unicode.IsLetter(r) && !unicode.IsDigit(r) })
	if len(words) > 6 {
		words = words[:6]
	}
	return words
}

// tsPrefixQuery — «слово:* & слово:*» для конфигурации 'simple'. Без стемминга: «иии» найдёт только слова,
// начинающиеся на «иии», а не всё, что русский стеммер свёл к тем же основам.
func tsPrefixQuery(q string) string {
	words := searchTokens(q)
	for i, w := range words {
		words[i] = w + ":*"
	}
	return strings.Join(words, " & ")
}

func likeEscape(s string) string {
	return strings.NewReplacer(`\`, `\\`, `%`, `\%`, `_`, `\_`).Replace(s)
}

func withField(obj []byte, key string, val any) []byte {
	v, _ := json.Marshal(val)
	out := make([]byte, 0, len(obj)+len(key)+len(v)+4)
	out = append(out, obj[:len(obj)-1]...)
	out = append(out, ',', '"')
	out = append(out, key...)
	out = append(out, '"', ':')
	out = append(out, v...)
	return append(out, '}')
}

func (s *Server) bumpNews(ctx context.Context) {
	s.rdb.Incr(ctx, "c:news:ver")
	s.sys(ctx, "news", 0)
}

// whereBuilder собирает WHERE с нумерованными параметрами.
type whereBuilder struct {
	where []string
	args  []any
}

func (w *whereBuilder) add(cond string, vals ...any) {
	for _, v := range vals {
		w.args = append(w.args, v)
		cond = strings.Replace(cond, "?", "$"+strconv.Itoa(len(w.args)), 1)
	}
	w.where = append(w.where, cond)
}

func (w *whereBuilder) raw(cond string) { w.where = append(w.where, cond) }

func (w *whereBuilder) String() string {
	if len(w.where) == 0 {
		return "TRUE"
	}
	return strings.Join(w.where, " AND ")
}

func (w *whereBuilder) n() int { return len(w.args) }

func (w *whereBuilder) search(q string) {
	ts := tsPrefixQuery(q)
	if ts == "" {
		return
	}
	// Частые совпадения (> searchCap): намеренно «закрываем» индексы выражением (|| ''), чтобы планировщик, который сильно
	// занижает оценку для префиксных tsquery, не строил гигантский bitmap с сортировкой, а шёл по индексу ленты (дата DESC)
	// и останавливался на первых же найденных строках.
	phrase := strings.Join(searchTokens(q), " ")
	if len([]rune(phrase)) >= 3 {
		w.add(`((lower(n.title) || '') LIKE ? ESCAPE '\' OR (n.search_simple || ''::tsvector) @@ to_tsquery('simple', ?))`, "%"+likeEscape(phrase)+"%", ts)
	} else {
		w.add(`(n.search_simple || ''::tsvector) @@ to_tsquery('simple', ?)`, ts)
	}
}

// searchCap — до скольких совпадений поиск считается «редким».
const searchCap = 5000

// candidates возвращает id строк, подходящих под cond, если их не больше searchCap (иначе ok=false).
// Зачем: при ORDER BY published_at DESC LIMIT N планировщик идёт по индексу ленты и фильтрует — это мгновенно для частых слов,
// но сканирует ВЕСЬ миллион строк для редких/несуществующих («иии»). Редкие совпадения быстро берём из GIN-индекса целиком
// (≤5000 id), частые оставляем индексному обходу по дате (там совпадения встречаются сразу).
func (s *Server) candidates(ctx context.Context, table, cond string, args ...any) ([]int64, bool) {
	rows, err := s.ro.Query(ctx, `SELECT id FROM `+table+` WHERE `+cond+` LIMIT `+strconv.Itoa(searchCap+1), args...)
	if err != nil {
		return nil, false
	}
	defer rows.Close()
	ids := make([]int64, 0, 64)
	for rows.Next() {
		var id int64
		if rows.Scan(&id) != nil {
			return nil, false
		}
		ids = append(ids, id)
	}
	if rows.Err() != nil || len(ids) > searchCap {
		return nil, false
	}
	return ids, true
}

// searchNews добавляет условие поиска по новостям (см. candidates).
// Возвращает true, если совпадений мало и они взяты целиком из индекса (тогда точный подсчёт дешёвый).
func (s *Server) searchNews(ctx context.Context, w *whereBuilder, q string) (rare bool) {
	ts := tsPrefixQuery(q)
	if ts == "" {
		return false
	}
	phrase := strings.Join(searchTokens(q), " ")
	cond, args := `search_simple @@ to_tsquery('simple', $1)`, []any{ts}
	if len([]rune(phrase)) >= 3 {
		cond, args = `(lower(title) LIKE $1 ESCAPE '\' OR search_simple @@ to_tsquery('simple', $2))`, []any{"%" + likeEscape(phrase) + "%", ts}
	}
	if ids, ok := s.candidates(ctx, "news", cond, args...); ok {
		w.add(`n.id = ANY(?::bigint[])`, ids)
		return true
	}
	w.search(q)
	return false
}

// newsTotal — сколько новостей подходит под условия (кэш в Redis на 60 с, ключ включает версию ленты).
// Поиск по частому слову не считаем до конца: total = newsTotalCap и capped = true («5000+»).
func (s *Server) newsTotal(ctx context.Context, ver, cond string, args []any, hasSearch, searchRare bool) (total int, capped bool, err error) {
	h := sha1.Sum([]byte(fmt.Sprint(cond, args)))
	key := "c:newscnt:" + ver + ":" + hex.EncodeToString(h[:8])
	if v, e := s.rdb.Get(ctx, key).Result(); e == nil {
		if p := strings.SplitN(v, "|", 2); len(p) == 2 {
			if n, e := strconv.Atoi(p[0]); e == nil {
				return n, p[1] == "1", nil
			}
		}
	}
	if hasSearch && !searchRare {
		total, capped = newsTotalCap, true
	} else if err = s.ro.QueryRow(ctx, "SELECT count(*) FROM news n WHERE "+cond, args...).Scan(&total); err != nil {
		return 0, false, err
	}
	s.rdb.Set(ctx, key, fmt.Sprintf("%d|%d", total, b2i(capped)), 60*time.Second)
	return total, capped, nil
}

func b2i(b bool) int {
	if b {
		return 1
	}
	return 0
}

// keyset: cursor вида "2026-01-02T03:04:05.123456Z|123"
func (w *whereBuilder) cursor(cur string) {
	if i := strings.LastIndex(cur, "|"); i > 0 {
		if id, err := strconv.ParseInt(cur[i+1:], 10, 64); err == nil {
			w.add(`(n.published_at, n.id) < (?::timestamptz, ?::bigint)`, cur[:i], id)
		}
	}
}

// ---------------------------------------------------------------- feed

// maxNewsOffset — глубже этой позиции постраничный просмотр не поддерживается (используйте поиск и фильтры).
const maxNewsOffset = 100000

// newsTotalCap — потолок для «total» при поиске по частому слову (дальше считать дорого).
const newsTotalCap = searchCap

// listNews — лента новостей. Два режима:
//   - ?page=N&per=M — страницы со ссылками (OFFSET по индексу news_stream); ответ дополнен page, per, total, pages, total_capped;
//   - ?cursor=… — keyset-подгрузка (обратная совместимость).
//
// Закреплённые отдаются отдельным блоком только на 1-й странице; в items их нет.
func (s *Server) listNews(c *Ctx) error {
	ctx := c.Context()
	per := min(max(c.QInt("per", 10), 1), 50)
	cursor := c.Q("cursor")
	pageMode := c.Q("page") != ""
	page, off := 1, 0
	if pageMode {
		page = max(c.QInt("page", 1), 1)
		off = (page - 1) * per
		if off > maxNewsOffset {
			return badReq("Страница слишком далеко от начала ленты. Воспользуйтесь поиском или фильтрами")
		}
		cursor = ""
	}
	w := &whereBuilder{}
	w.raw(visibleNow)
	if v := c.QInt64("category"); v > 0 {
		w.add("n.category_id = ?", v)
	}
	if c.Q("important") == "1" {
		w.raw("n.important")
	}
	if v := c.QInt64("department"); v > 0 {
		w.add("n.department_id IN "+deptSubtree("?"), v)
	}
	if v := c.QInt64("direction"); v > 0 {
		w.add(`n.direction_id IN (WITH RECURSIVE t AS (SELECT id FROM directions WHERE id = ?
			UNION ALL SELECT d.id FROM directions d JOIN t ON d.parent_id = t.id) SELECT id FROM t)`, v)
	}
	q := c.Q("q")
	searchRare := s.searchNews(ctx, w, q)
	// закреплённые показываем отдельным блоком на первой странице обычной ленты
	splitPinned := q == ""
	if splitPinned {
		w.raw("NOT n.pinned")
	}
	pinnedCond := strings.Replace(w.String(), "NOT n.pinned", "n.pinned", 1)
	pinnedArgs := append([]any{}, w.args...)
	countCond, countArgs := w.String(), append([]any{}, w.args...)
	w.cursor(cursor)

	var payload []byte
	cacheable := q == ""
	var key string
	ver, _ := s.rdb.Get(ctx, "c:news:ver").Result()
	if cacheable {
		h := sha1.Sum([]byte(fmt.Sprint(w.String(), w.args, per, "|", off, pageMode)))
		key = "c:news:" + ver + ":" + hex.EncodeToString(h[:8])
		if b, err := s.rdb.Get(ctx, key).Bytes(); err == nil {
			payload = b
		}
	}
	if payload == nil {
		limit := " LIMIT " + strconv.Itoa(per+1)
		if off > 0 {
			limit += " OFFSET " + strconv.Itoa(off)
		}
		items, err := s.ro.Query(ctx, "SELECT row_to_json(t) FROM (SELECT "+newsCols+newsFrom+" WHERE "+w.String()+
			" ORDER BY n.published_at DESC, n.id DESC"+limit+") t", w.args...)
		if err != nil {
			return err
		}
		var list []json.RawMessage
		for items.Next() {
			var b []byte
			if err := items.Scan(&b); err != nil {
				items.Close()
				return err
			}
			list = append(list, b)
		}
		items.Close()
		more := len(list) > per
		if more {
			list = list[:per]
		}
		pinned := json.RawMessage("[]")
		if splitPinned && cursor == "" && page == 1 {
			if pinned, err = s.arr2(ctx, "SELECT "+newsCols+newsFrom+" WHERE "+pinnedCond+" ORDER BY n.published_at DESC, n.id DESC LIMIT 5", pinnedArgs...); err != nil {
				return err
			}
		}
		if q != "" && cursor == "" && off == 0 {
			s.logSearch(c, "news", q, len(list)) // аналитика поиска
		}
		out := map[string]any{"items": list, "has_more": more, "pinned": pinned}
		if list == nil {
			out["items"] = []json.RawMessage{}
		}
		if pageMode {
			total, capped, err := s.newsTotal(ctx, ver, countCond, countArgs, q != "" && len(searchTokens(q)) > 0, searchRare)
			if err != nil {
				return err
			}
			pages := (total + per - 1) / per
			if capped { // точное число неизвестно: страниц не меньше, чем уже видно
				pages = max(pages, page+b2i(more))
			} else {
				more = page < pages
				out["has_more"] = more
			}
			out["page"], out["per"], out["total"], out["pages"], out["total_capped"] = page, per, total, pages, capped
		}
		if payload, err = json.Marshal(out); err != nil {
			return err
		}
		if cacheable {
			s.rdb.Set(ctx, key, payload, 60*time.Second)
		}
	}
	var ids struct {
		Items []struct {
			ID int64 `json:"id"`
		} `json:"items"`
		Pinned []struct {
			ID int64 `json:"id"`
		} `json:"pinned"`
	}
	json.Unmarshal(payload, &ids)
	arr := []int64{}
	for _, it := range ids.Items {
		arr = append(arr, it.ID)
	}
	for _, it := range ids.Pinned {
		arr = append(arr, it.ID)
	}
	// реакции и закладки страницы — одним запросом каждый (index-only по reactions_entity / bookmarks PK); кэш ленты общий, это — на пользователя
	liked := []int64{}
	rx, err := s.reactionsFor(ctx, c.U.ID, "news", arr)
	if err != nil {
		return err
	}
	for id, list := range rx {
		for _, it := range list {
			if it.E == likeEmoji && it.M {
				liked = append(liked, id)
			}
		}
	}
	marks, err := s.bookmarkedSet(ctx, c.U.ID, "news", arr)
	if err != nil {
		return err
	}
	bm := []int64{}
	for id := range marks {
		bm = append(bm, id)
	}
	out := withField(payload, "liked", liked)
	out = withField(out, "reactions", rx)
	return c.Raw(200, withField(out, "bookmarked", bm))
}

// arr2 is arr on the read replica.
func (s *Server) arr2(ctx context.Context, q string, args ...any) (json.RawMessage, error) {
	var b []byte
	err := s.ro.QueryRow(ctx, "SELECT coalesce(json_agg(t), '[]'::json) FROM ("+q+") t", args...).Scan(&b)
	return b, err
}

// ---------------------------------------------------------------- admin list

// adminListNews — список для редактора: админ видит всё, редактор — новости своей области и свои.
func (s *Server) adminListNews(c *Ctx) error {
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	per := min(max(c.QInt("per", 30), 1), 100)
	w := &whereBuilder{}
	if !sc.All {
		w.add("(n.author_id = ? OR n.department_id = ANY(?::bigint[]))", c.U.ID, sc.IDs)
	}
	switch c.Q("state") {
	case "draft":
		w.raw("n.status = 'draft'")
	case "hidden":
		w.raw("n.hidden")
	case "scheduled":
		w.raw("n.status = 'published' AND n.published_at > now()")
	case "expired":
		w.raw("n.visible_until IS NOT NULL AND n.visible_until <= now()")
	case "live":
		w.raw(visibleNow)
	}
	if v := c.QInt64("department"); v > 0 {
		w.add("n.department_id IN "+deptSubtree("?"), v)
	}
	if q := strings.ToLower(c.Q("q")); len([]rune(q)) >= 2 {
		w.add(`lower(n.title) LIKE ? ESCAPE '\'`, "%"+likeEscape(q)+"%")
	}
	if v := c.QInt64("cursor"); v > 0 {
		w.add("n.id < ?", v)
	}
	items, err := s.arr(ctx, `SELECT `+newsCols+`,
		CASE WHEN n.status = 'draft' THEN 'draft' WHEN n.hidden THEN 'hidden' WHEN n.published_at > now() THEN 'scheduled'
			WHEN n.visible_until IS NOT NULL AND n.visible_until <= now() THEN 'expired' ELSE 'live' END AS state`+newsFrom+
		` WHERE `+w.String()+` ORDER BY n.id DESC LIMIT `+strconv.Itoa(per+1), w.args...)
	if err != nil {
		return err
	}
	var list []json.RawMessage
	json.Unmarshal(items, &list)
	more := len(list) > per
	if more {
		list = list[:per]
	}
	if list == nil {
		list = []json.RawMessage{}
	}
	if c.Q("cursor") == "" {
		s.logSearch(c, "admin_news", c.Q("q"), len(list)) // аналитика поиска (управление новостями)
	}
	return c.JSON(200, map[string]any{"items": list, "has_more": more})
}

// ---------------------------------------------------------------- single article

func (s *Server) getNews(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	var dept, author *int64
	var live bool
	if err := s.db.QueryRow(ctx, `SELECT n.department_id, n.author_id, (`+visibleNow+`) FROM news n WHERE n.id = $1`, id).Scan(&dept, &author, &live); err != nil {
		return err
	}
	canEdit := false
	if !live || c.U.CanEdit() {
		sc, err := s.scopeOf(ctx, c.U)
		if err != nil {
			return err
		}
		canEdit = sc.canManageNews(c.U, dept, author)
		if !live && !canEdit {
			return errNotFound
		}
	}
	// Счётчик просмотров: запись буферизуется в Redis (сброс в БД раз в 15 с), а в ответ добавляется ещё не
	// сброшенная часть, чтобы число увеличивалось сразу.
	pending := 0
	if live {
		sid := strconv.FormatInt(id, 10)
		if s.rdb.SetNX(ctx, fmt.Sprintf("viewed:%d:%d", c.U.ID, id), 1, 30*time.Minute).Val() {
			s.rdb.HIncrBy(ctx, "views:"+s.cfg.DCID, sid, 1)
			if author == nil || *author != c.U.ID {
				s.anNewsViewed(ctx, id, c.U.ID) // уникальные читатели для аналитики (автор свою новость не считается)
			}
		}
		for _, k := range []string{"views:" + s.cfg.DCID, "views:" + s.cfg.DCID + ":flush"} {
			if v, err := s.rdb.HGet(ctx, k, sid).Int(); err == nil {
				pending += v
			}
		}
	}
	cols := strings.Replace(newsCols, "n.views_count,", "n.views_count + $4::int AS views_count,", 1)
	b, err := s.one(ctx, `SELECT `+cols+`, n.body,
		EXISTS (SELECT 1 FROM reactions l WHERE l.entity_type = 'news' AND l.entity_id = n.id AND l.user_id = $2 AND l.emoji = '👍') AS liked,
		$3::boolean AS can_edit, (`+visibleNow+`) AS live,
		(SELECT coalesce(json_agg(json_build_object('id', f.id, 'name', f.name, 'mime', f.mime, 'size', f.size) ORDER BY f.id), '[]')
		   FROM news_files nf JOIN files f ON f.id = nf.file_id WHERE nf.news_id = n.id) AS attachments,
		(SELECT coalesce(json_agg(json_build_object('id', g.id, 'folder_id', g.folder_id, 'title', g.title, 'kind', fo.kind, 'folder_name', fo.name,
				'total', (SELECT count(*) FROM files x WHERE x.folder_id = fo.id),
				'items', (SELECT coalesce(json_agg(json_build_object('id', x.id, 'name', x.name, 'mime', x.mime, 'width', x.width, 'height', x.height,
						'external_url', x.external_url) ORDER BY x.id DESC), '[]') FROM (SELECT * FROM files WHERE folder_id = fo.id ORDER BY id DESC LIMIT 8) x)
			) ORDER BY g.sort, g.id), '[]')
		   FROM news_galleries g JOIN folders fo ON fo.id = g.folder_id WHERE g.news_id = n.id) AS galleries,
		(SELECT coalesce(json_agg(json_build_object('folder_id', g.folder_id, 'title', g.title, 'kind', fo.kind, 'folder_name', fo.name) ORDER BY g.sort, g.id), '[]')
		   FROM news_galleries g JOIN folders fo ON fo.id = g.folder_id WHERE g.news_id = n.id AND $3::boolean) AS gallery_refs`+newsFrom+`
		WHERE n.id = $1`, id, c.U.ID, canEdit, pending)
	if err != nil {
		return err
	}
	if b, err = s.withSocialOne(ctx, c.U.ID, "news", b, true); err != nil {
		return err
	}
	return c.Raw(200, b)
}

// ---------------------------------------------------------------- save

type newsIn struct {
	Title        string  `json:"title"`
	Summary      string  `json:"summary"`
	Body         string  `json:"body"`
	CategoryID   *int    `json:"category_id"`
	Cover        string  `json:"cover"`
	Important    bool    `json:"important"`
	Pinned       bool    `json:"pinned"`
	Status       string  `json:"status"`
	Hidden       bool    `json:"hidden"`
	PublishedAt  string  `json:"published_at"`  // с какого момента показывать (пусто = сейчас)
	VisibleUntil string  `json:"visible_until"` // до какого (пусто = бессрочно)
	DepartmentID *int64  `json:"department_id"`
	DirectionID  *int64  `json:"direction_id"`
	Files        []int64 `json:"files"`
	Galleries    []struct {
		FolderID int64  `json:"folder_id"`
		Title    string `json:"title"`
	} `json:"galleries"`
}

func parseOptTime(v string) (*time.Time, error) {
	v = strings.TrimSpace(v)
	if v == "" {
		return nil, nil
	}
	t, err := time.Parse(time.RFC3339, v)
	if err != nil {
		return nil, badReq("Некорректная дата показа")
	}
	return &t, nil
}

func (s *Server) saveNews(c *Ctx) error {
	var in newsIn
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Title = strings.TrimSpace(in.Title)
	if in.Title == "" || len(in.Title) > 300 {
		return badReq("Укажите заголовок (до 300 символов)")
	}
	if in.Status != "draft" {
		in.Status = "published"
	}
	if in.Files == nil {
		in.Files = []int64{}
	}
	from, err := parseOptTime(in.PublishedAt)
	if err != nil {
		return err
	}
	until, err := parseOptTime(in.VisibleUntil)
	if err != nil {
		return err
	}
	if from == nil {
		now := time.Now()
		from = &now
	}
	if until != nil && !until.After(*from) {
		return badReq("Дата окончания показа должна быть позже даты начала")
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	if !sc.canPublishTo(c.U, in.DepartmentID) {
		if in.DepartmentID == nil {
			return &apiError{403, "Новости для всей компании публикуют администраторы и редакторы с таким правом — выберите подразделение"}
		}
		return &apiError{403, "Это подразделение вне вашей области управления"}
	}
	var id int64
	update := c.R.PathValue("id") != ""
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if update {
			var err error
			if id, err = c.ID("id"); err != nil {
				return err
			}
			var dept, author *int64
			if err := tx.QueryRow(ctx, `SELECT department_id, author_id FROM news WHERE id = $1 FOR UPDATE`, id).Scan(&dept, &author); err != nil {
				return err
			}
			if !sc.canManageNews(c.U, dept, author) {
				return errForbidden
			}
			if _, err := tx.Exec(ctx, `UPDATE news SET title = $2, summary = $3, body = $4, category_id = $5, cover = $6, important = $7,
				pinned = $8, status = $9, hidden = $10, published_at = $11, visible_until = $12, department_id = $13, direction_id = $14,
				updated_at = now() WHERE id = $1`,
				id, in.Title, in.Summary, in.Body, in.CategoryID, in.Cover, in.Important, in.Pinned, in.Status, in.Hidden,
				*from, until, in.DepartmentID, in.DirectionID); err != nil {
				return err
			}
		} else if err := tx.QueryRow(ctx, `INSERT INTO news (title, summary, body, category_id, author_id, cover, important, pinned, status, hidden,
				published_at, visible_until, department_id, direction_id, announced)
			VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, false) RETURNING id`,
			in.Title, in.Summary, in.Body, in.CategoryID, c.U.ID, in.Cover, in.Important, in.Pinned, in.Status, in.Hidden,
			*from, until, in.DepartmentID, in.DirectionID).Scan(&id); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `DELETE FROM news_files WHERE news_id = $1 AND NOT (file_id = ANY($2))`, id, in.Files); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `INSERT INTO news_files (news_id, file_id) SELECT $1, f.id FROM files f
			WHERE f.id = ANY($2) AND f.context = 'news' ON CONFLICT DO NOTHING`, id, in.Files); err != nil {
			return err
		}
		// ссылки на фото/видео галереи
		if _, err := tx.Exec(ctx, `DELETE FROM news_galleries WHERE news_id = $1`, id); err != nil {
			return err
		}
		for i, g := range in.Galleries {
			if len(in.Galleries) > 20 {
				return badReq("Слишком много галерей")
			}
			tag, err := tx.Exec(ctx, `INSERT INTO news_galleries (news_id, folder_id, title, sort)
				SELECT $1, fo.id, $3, $4 FROM folders fo WHERE fo.id = $2 AND fo.kind IN ('photos', 'videos')
				AND `+aclVisible("folder", "fo", 5, 6, 7), id, g.FolderID, strings.TrimSpace(g.Title), i, c.U.ID, c.U.Dept, c.U.IsAdmin())
			if err != nil {
				return err
			}
			if tag.RowsAffected() == 0 {
				return badReq("Галерея недоступна или не найдена")
			}
		}
		return nil
	})
	if err != nil {
		return err
	}
	s.bumpNews(ctx)
	s.announceDue(ctx, id)
	act := "news.create"
	if update {
		act = "news.update"
	}
	s.audit(c, act, "news", id, map[string]any{"title": in.Title, "status": in.Status, "hidden": in.Hidden})
	return c.JSON(200, map[string]any{"id": id})
}

// announceDue рассылает уведомления и событие «новая новость» по тем публикациям, которые уже стали видимыми
// (немедленно после сохранения и раз в минуту — для отложенных). UPDATE … RETURNING атомарен: даже при
// нескольких экземплярах и ЦОДах каждая новость объявляется ровно один раз.
func (s *Server) announceDue(ctx context.Context, only int64) {
	rows, err := s.db.Query(ctx, `UPDATE news n SET announced = true WHERE n.id IN (
			SELECT id FROM news WHERE NOT announced AND status = 'published' AND NOT hidden AND published_at <= now()
			AND ($1::bigint = 0 OR id = $1) ORDER BY published_at LIMIT 200 FOR UPDATE SKIP LOCKED)
		RETURNING n.id, n.title, n.important, coalesce(n.author_id, 0)`, only)
	if err != nil {
		s.log.Warn("announce failed", "err", err)
		return
	}
	type item struct {
		id, author int64
		title      string
		important  bool
	}
	var items []item
	for rows.Next() {
		var it item
		if rows.Scan(&it.id, &it.title, &it.important, &it.author) == nil {
			items = append(items, it)
		}
	}
	rows.Close()
	for _, it := range items {
		s.hub.Emit(ctx, "feed", "news.new", map[string]any{"id": it.id, "title": it.title, "important": it.important, "author_id": it.author})
		if it.important {
			link := "/news/" + strconv.FormatInt(it.id, 10)
			if _, err := s.db.Exec(ctx, `INSERT INTO notifications (user_id, kind, title, body, link)
				SELECT id, 'news', 'Важная новость', $2, $3 FROM users WHERE NOT blocked AND id <> $1`, it.author, it.title, link); err == nil {
				s.hub.Emit(ctx, "feed", "refresh", map[string]string{"what": "notifications"})
			}
		}
	}
	if len(items) > 0 {
		s.bumpNews(ctx)
	}
}

func (s *Server) setNewsHidden(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Hidden bool `json:"hidden"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	var dept, author *int64
	if err := s.db.QueryRow(ctx, `SELECT department_id, author_id FROM news WHERE id = $1`, id).Scan(&dept, &author); err != nil {
		return err
	}
	if !sc.canManageNews(c.U, dept, author) {
		return errForbidden
	}
	if _, err := s.db.Exec(ctx, `UPDATE news SET hidden = $2, updated_at = now() WHERE id = $1`, id, in.Hidden); err != nil {
		return err
	}
	s.bumpNews(ctx)
	s.announceDue(ctx, id)
	s.audit(c, "news.hidden", "news", id, map[string]bool{"hidden": in.Hidden})
	return c.OK()
}

func (s *Server) deleteNews(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	var dept, author *int64
	if err := s.db.QueryRow(ctx, `SELECT department_id, author_id FROM news WHERE id = $1`, id).Scan(&dept, &author); err != nil {
		return err
	}
	if !sc.canManageNews(c.U, dept, author) {
		return errForbidden
	}
	if _, err := s.db.Exec(ctx, `DELETE FROM news WHERE id = $1`, id); err != nil {
		return err
	}
	s.db.Exec(ctx, `DELETE FROM comments WHERE entity_type = 'news' AND entity_id = $1`, id)
	s.bumpNews(ctx)
	s.audit(c, "news.delete", "news", id, nil)
	return c.OK()
}

// ---------------------------------------------------------------- comments & likes

// entityAccess checks the user may see the entity and returns its author, a link (without fragment) and a title.
func (s *Server) entityAccess(ctx context.Context, u *User, typ string, id int64) (author int64, link, title string, err error) {
	var a *int64
	switch typ {
	case "news":
		var dept *int64
		var live bool
		err = s.db.QueryRow(ctx, `SELECT n.author_id, n.title, n.department_id, (`+visibleNow+`) FROM news n WHERE n.id = $1`, id).Scan(&a, &title, &dept, &live)
		if err == nil && !live {
			ok := false
			if u.CanEdit() {
				if sc, e := s.scopeOf(ctx, u); e == nil {
					ok = sc.canManageNews(u, dept, a)
				}
			}
			if !ok {
				err = pgx.ErrNoRows
			}
		}
		link = "/news/" + strconv.FormatInt(id, 10)
	case "idea":
		err = s.db.QueryRow(ctx, `SELECT author_id, title FROM ideas WHERE id = $1`, id).Scan(&a, &title)
		link = "/ideas/" + strconv.FormatInt(id, 10)
	case "post":
		var gid int64
		err = s.db.QueryRow(ctx, `SELECT p.user_id, left(p.body, 80), g.id FROM group_posts p JOIN user_groups g ON g.id = p.group_id
			WHERE p.id = $1 AND (g.visibility = 'public' OR $3 OR EXISTS (SELECT 1 FROM group_members m
				WHERE m.group_id = g.id AND m.user_id = $2 AND m.role <> 'pending'))`, id, u.ID, u.IsAdmin()).Scan(&a, &title, &gid)
		link = "/groups/" + strconv.FormatInt(gid, 10) + "?post=" + strconv.FormatInt(id, 10)
	default:
		return 0, "", "", badReq("Неизвестный тип")
	}
	if a != nil {
		author = *a
	}
	return
}

const maxCommentDepth = 5

const commentSelect = `SELECT c.id, c.entity_type, c.entity_id, c.parent_id, c.root_id, c.depth, c.user_id,
	u.full_name AS author, u.avatar AS author_avatar, u.job_title AS author_title,
	CASE WHEN c.deleted_at IS NULL THEN c.body ELSE '' END AS body, c.created_at, c.deleted_at IS NOT NULL AS deleted,
	CASE WHEN c.deleted_at IS NOT NULL THEN '[]'::json ELSE
		(SELECT coalesce(json_agg(json_build_object('id', f.id, 'name', f.name, 'mime', f.mime, 'size', f.size, 'width', f.width, 'height', f.height) ORDER BY f.id), '[]')
		 FROM comment_files cf JOIN files f ON f.id = cf.file_id WHERE cf.comment_id = c.id) END AS files
	FROM comments c LEFT JOIN users u ON u.id = c.user_id`

// listComments отдаёт страницу корневых комментариев вместе со всеми их ответами (до 5 уровней вложенности).
func (s *Server) listComments(c *Ctx) error {
	id := c.QInt64("id")
	typ := c.Q("type")
	if _, _, _, err := s.entityAccess(c.Context(), c.U, typ, id); err != nil {
		return err
	}
	per := min(max(c.QInt("per", 40), 1), 100)
	ctx := c.Context()
	rows, err := s.db.Query(ctx, `SELECT id FROM comments WHERE entity_type = $1 AND entity_id = $2 AND parent_id IS NULL AND id > $3
		ORDER BY id LIMIT $4`, typ, id, c.QInt64("after"), per+1)
	if err != nil {
		return err
	}
	roots := []int64{}
	for rows.Next() {
		var rid int64
		if err := rows.Scan(&rid); err != nil {
			rows.Close()
			return err
		}
		roots = append(roots, rid)
	}
	rows.Close()
	more := len(roots) > per
	if more {
		roots = roots[:per]
	}
	items, err := s.arr(ctx, commentSelect+` WHERE c.root_id = ANY($1) ORDER BY c.id`, roots)
	if err != nil {
		return err
	}
	if items, err = s.withSocial(ctx, c.U.ID, "comment", items, false); err != nil {
		return err
	}
	next := int64(0)
	if len(roots) > 0 {
		next = roots[len(roots)-1]
	}
	return c.JSON(200, map[string]any{"items": items, "has_more": more, "next": next})
}

func (s *Server) addComment(c *Ctx) error {
	var in struct {
		Type     string  `json:"entity_type"`
		ID       int64   `json:"entity_id"`
		ParentID *int64  `json:"parent_id"`
		Body     string  `json:"body"`
		Files    []int64 `json:"files"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Body = strings.TrimSpace(in.Body)
	if (in.Body == "" && len(in.Files) == 0) || len(in.Body) > 4000 {
		return badReq("Комментарий должен содержать от 1 до 4000 символов или вложение")
	}
	if len(in.Files) > 10 {
		return badReq("Не более 10 файлов в комментарии")
	}
	if in.Files == nil {
		in.Files = []int64{}
	}
	ctx := c.Context()
	if !s.rateOK(ctx, fmt.Sprintf("comment:%d", c.U.ID), 30, time.Minute) {
		return &apiError{429, "Слишком часто. Подождите немного"}
	}
	author, link, title, err := s.entityAccess(ctx, c.U, in.Type, in.ID)
	if err != nil {
		return err
	}
	var parentAuthor int64
	depth := 0
	var rootID *int64
	if in.ParentID != nil {
		var pa *int64
		var pd int
		var pr *int64
		var deleted bool
		if err := s.db.QueryRow(ctx, `SELECT user_id, depth, root_id, deleted_at IS NOT NULL FROM comments WHERE id = $1 AND entity_type = $2 AND entity_id = $3`,
			*in.ParentID, in.Type, in.ID).Scan(&pa, &pd, &pr, &deleted); err != nil {
			return badReq("Родительский комментарий не найден")
		}
		if pd+1 > maxCommentDepth {
			return badReq("Достигнута максимальная вложенность ответов (5 уровней)")
		}
		if pa != nil {
			parentAuthor = *pa
		}
		depth, rootID = pd+1, pr
	}
	var cid int64
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if err := tx.QueryRow(ctx, `INSERT INTO comments (entity_type, entity_id, user_id, parent_id, root_id, depth, body)
			VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`, in.Type, in.ID, c.U.ID, in.ParentID, rootID, depth, in.Body).Scan(&cid); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE comments SET root_id = id WHERE id = $1 AND root_id IS NULL`, cid); err != nil {
			return err
		}
		if len(in.Files) > 0 {
			tag, err := tx.Exec(ctx, `INSERT INTO comment_files (comment_id, file_id) SELECT $1, f.id FROM files f
				WHERE f.id = ANY($2) AND f.owner_id = $3 AND f.context = 'comment'
				AND NOT EXISTS (SELECT 1 FROM comment_files x WHERE x.file_id = f.id)`, cid, in.Files, c.U.ID)
			if err != nil {
				return err
			}
			if int(tag.RowsAffected()) != len(in.Files) {
				return badReq("Файл не найден или уже прикреплён")
			}
		}
		return bumpCount(ctx, tx, in.Type, in.ID, "comments_count", 1, nil)
	})
	if err != nil {
		return err
	}
	b, err := s.one(ctx, commentSelect+` WHERE c.id = $1`, cid)
	if err != nil {
		return err
	}
	switch in.Type {
	case "news":
		s.bumpNews(ctx)
		s.hub.Emit(ctx, "news:"+strconv.FormatInt(in.ID, 10), "comment", json.RawMessage(b))
	case "idea":
		s.hub.Emit(ctx, "idea:"+strconv.FormatInt(in.ID, 10), "comment", json.RawMessage(b))
	}
	snippet := in.Body
	if r := []rune(snippet); len(r) > 120 {
		snippet = string(r[:120]) + "…"
	}
	if snippet == "" {
		snippet = "Вложение"
	}
	frag := "#comment-" + strconv.FormatInt(cid, 10)
	if parentAuthor != 0 && parentAuthor != c.U.ID {
		s.notify(ctx, []int64{parentAuthor}, "reply", c.U.Name+" ответил(а) на ваш комментарий", snippet, link+frag)
	}
	if author != 0 && author != c.U.ID && author != parentAuthor {
		s.notify(ctx, []int64{author}, "comment", c.U.Name+" прокомментировал(а): "+title, snippet, link+frag)
	}
	if strings.Contains(in.Body, "@") {
		aud := audienceAll
		if in.Type == "post" {
			var gid int64
			s.db.QueryRow(ctx, `SELECT group_id FROM group_posts WHERE id = $1`, in.ID).Scan(&gid)
			aud = mentionAudience{Group: gid}
		}
		s.syncMentions(ctx, mentionSrc{Type: "comment", ID: cid, Actor: c.U, Body: in.Body, Link: link + frag, Where: "в комментарии", Title: title,
			Audience: aud, Exclude: []int64{parentAuthor, author}})
	}
	return c.Raw(201, b)
}

// bumpCount adjusts a denormalised counter; when out != nil it receives the new value.
func bumpCount(ctx context.Context, tx pgx.Tx, typ string, id int64, col string, delta int, out *int) error {
	table := "news"
	switch typ {
	case "post":
		table = "group_posts"
	case "idea":
		table = "ideas"
	}
	var n int
	err := tx.QueryRow(ctx, fmt.Sprintf(`UPDATE %s SET %s = greatest(%s + $2, 0) WHERE id = $1 RETURNING %s`, table, col, col, col), id, delta).Scan(&n)
	if out != nil {
		*out = n
	}
	return err
}

func (s *Server) deleteComment(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	var typ string
	var eid int64
	var owner *int64
	if err := s.db.QueryRow(ctx, `SELECT entity_type, entity_id, user_id FROM comments WHERE id = $1 AND deleted_at IS NULL`, id).Scan(&typ, &eid, &owner); err != nil {
		return err
	}
	if !c.U.IsAdmin() && (owner == nil || *owner != c.U.ID) {
		return errForbidden
	}
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `UPDATE comments SET deleted_at = now() WHERE id = $1`, id); err != nil {
			return err
		}
		return bumpCount(ctx, tx, typ, eid, "comments_count", -1, nil)
	})
	if err != nil {
		return err
	}
	switch typ {
	case "news":
		s.bumpNews(ctx)
		s.hub.Emit(ctx, "news:"+strconv.FormatInt(eid, 10), "comment.delete", map[string]int64{"id": id})
	case "idea":
		s.hub.Emit(ctx, "idea:"+strconv.FormatInt(eid, 10), "comment.delete", map[string]int64{"id": id})
	}
	s.db.Exec(ctx, `DELETE FROM mentions WHERE entity_type = 'comment' AND entity_id = $1`, id)
	s.audit(c, "comment.delete", "comment", id, nil)
	return c.OK()
}
