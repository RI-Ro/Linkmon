package server

import (
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

// Голосования в групповых чатах (как в Telegram): видно, кто и когда что выбрал; после закрытия выбор менять нельзя.

const pollJSON = `SELECT json_build_object('id', p.id, 'question', p.question, 'multiple', p.multiple,
	'closed', p.closed_at IS NOT NULL, 'closed_at', p.closed_at, 'created_by', p.created_by,
	'voters', (SELECT count(DISTINCT pv.user_id) FROM poll_votes pv WHERE pv.poll_id = p.id),
	'options', (SELECT coalesce(json_agg(json_build_object('id', o.id, 'text', o.text,
		'votes', (SELECT coalesce(json_agg(json_build_object('user_id', v.user_id, 'name', vu.full_name, 'avatar', vu.avatar, 'at', v.voted_at) ORDER BY v.voted_at, v.user_id), '[]')
			FROM poll_votes v JOIN users vu ON vu.id = v.user_id WHERE v.option_id = o.id)) ORDER BY o.sort, o.id), '[]')
		FROM poll_options o WHERE o.poll_id = p.id))
	FROM polls p WHERE p.message_id = m.id`

func (s *Server) createPoll(c *Ctx) error {
	cid, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Question string   `json:"question"`
		Options  []string `json:"options"`
		Multiple bool     `json:"multiple"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Question = strings.TrimSpace(in.Question)
	var opts []string
	for _, o := range in.Options {
		if o = strings.TrimSpace(o); o != "" {
			opts = append(opts, o)
		}
	}
	if in.Question == "" || len(in.Question) > 300 || len(opts) < 2 || len(opts) > 12 {
		return badReq("Укажите вопрос (до 300 символов) и от 2 до 12 вариантов ответа")
	}
	for _, o := range opts {
		if len([]rune(o)) > 200 {
			return badReq("Вариант ответа не должен превышать 200 символов")
		}
	}
	ctx := c.Context()
	if ok, err := s.isMember(ctx, cid, c.U.ID); err != nil {
		return err
	} else if !ok {
		return errForbidden
	}
	var kind string
	if err := s.db.QueryRow(ctx, `SELECT kind FROM chats WHERE id = $1`, cid).Scan(&kind); err != nil {
		return err
	}
	if kind != "group" {
		return badReq("Голосования доступны только в групповых чатах")
	}
	if !s.rateOK(ctx, fmt.Sprintf("poll:%d", c.U.ID), 20, time.Minute) {
		return &apiError{429, "Слишком часто"}
	}
	var mid int64
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if err := tx.QueryRow(ctx, `INSERT INTO messages (chat_id, user_id, body, kind) VALUES ($1, $2, $3, 'poll') RETURNING id`, cid, c.U.ID, in.Question).Scan(&mid); err != nil {
			return err
		}
		var pid int64
		if err := tx.QueryRow(ctx, `INSERT INTO polls (chat_id, message_id, question, multiple, created_by) VALUES ($1, $2, $3, $4, $5) RETURNING id`,
			cid, mid, in.Question, in.Multiple, c.U.ID).Scan(&pid); err != nil {
			return err
		}
		for i, o := range opts {
			if _, err := tx.Exec(ctx, `INSERT INTO poll_options (poll_id, text, sort) VALUES ($1, $2, $3)`, pid, o, i); err != nil {
				return err
			}
		}
		if _, err := tx.Exec(ctx, `UPDATE chats SET last_message_id = $2, last_message_at = now() WHERE id = $1`, cid, mid); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE chat_members SET last_read_id = $3 WHERE chat_id = $1 AND user_id = $2`, cid, c.U.ID, mid); err != nil {
			return err
		}
		_, err := tx.Exec(ctx, `UPDATE chat_members SET hidden = false WHERE chat_id = $1 AND hidden`, cid)
		return err
	})
	if err != nil {
		return err
	}
	msg, err := s.one(ctx, messageSelect+` WHERE m.id = $1`, mid)
	if err != nil {
		return err
	}
	members, err := s.chatMembers(ctx, cid)
	if err != nil {
		return err
	}
	s.hub.EmitUsers(ctx, members, "message", map[string]any{"chat_id": cid, "message": rawJSON(msg)})
	return c.Raw(201, msg)
}

// pollMessage loads the poll with its chat and checks that the caller is a member of the chat.
func (s *Server) pollMessage(c *Ctx, pid int64) (chatID, msgID int64, creator *int64, closed bool, err error) {
	err = s.db.QueryRow(c.Context(), `SELECT p.chat_id, p.message_id, p.created_by, p.closed_at IS NOT NULL FROM polls p
		JOIN chat_members cm ON cm.chat_id = p.chat_id AND cm.user_id = $2 WHERE p.id = $1`, pid, c.U.ID).Scan(&chatID, &msgID, &creator, &closed)
	return
}

func (s *Server) votePoll(c *Ctx) error {
	pid, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		OptionIDs []int64 `json:"option_ids"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	ctx := c.Context()
	chatID, msgID, _, _, err := s.pollMessage(c, pid)
	if err == pgx.ErrNoRows {
		return errForbidden
	}
	if err != nil {
		return err
	}
	if in.OptionIDs == nil {
		in.OptionIDs = []int64{}
	}
	err = s.tx(ctx, func(tx pgx.Tx) error {
		var multiple, closed bool
		if err := tx.QueryRow(ctx, `SELECT multiple, closed_at IS NOT NULL FROM polls WHERE id = $1 FOR UPDATE`, pid).Scan(&multiple, &closed); err != nil {
			return err
		}
		if closed {
			return conflict("Голосование закрыто — выбор изменить нельзя")
		}
		if !multiple && len(in.OptionIDs) > 1 {
			return badReq("В этом голосовании можно выбрать только один вариант")
		}
		if _, err := tx.Exec(ctx, `DELETE FROM poll_votes WHERE poll_id = $1 AND user_id = $2`, pid, c.U.ID); err != nil {
			return err
		}
		if len(in.OptionIDs) == 0 {
			return nil
		}
		tag, err := tx.Exec(ctx, `INSERT INTO poll_votes (poll_id, option_id, user_id) SELECT $1, o.id, $3 FROM poll_options o
			WHERE o.poll_id = $1 AND o.id = ANY($2) ON CONFLICT DO NOTHING`, pid, in.OptionIDs, c.U.ID)
		if err != nil {
			return err
		}
		if int(tag.RowsAffected()) != len(uniq(in.OptionIDs)) {
			return badReq("Неизвестный вариант ответа")
		}
		return nil
	})
	if err != nil {
		return err
	}
	return s.emitPoll(c, chatID, msgID)
}

func uniq(ids []int64) []int64 {
	seen := map[int64]bool{}
	out := make([]int64, 0, len(ids))
	for _, id := range ids {
		if !seen[id] {
			seen[id] = true
			out = append(out, id)
		}
	}
	return out
}

func (s *Server) closePoll(c *Ctx) error {
	pid, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	chatID, msgID, creator, closed, err := s.pollMessage(c, pid)
	if err == pgx.ErrNoRows {
		return errForbidden
	}
	if err != nil {
		return err
	}
	if !(c.U.IsAdmin() || (creator != nil && *creator == c.U.ID)) {
		return &apiError{403, "Закрыть голосование может его автор"}
	}
	if !closed {
		if _, err := s.db.Exec(ctx, `UPDATE polls SET closed_at = now(), closed_by = $2 WHERE id = $1 AND closed_at IS NULL`, pid, c.U.ID); err != nil {
			return err
		}
	}
	return s.emitPoll(c, chatID, msgID)
}

func (s *Server) emitPoll(c *Ctx, chatID, msgID int64) error {
	ctx := c.Context()
	msg, err := s.one(ctx, messageSelect+` WHERE m.id = $1`, msgID)
	if err != nil {
		return err
	}
	members, _ := s.chatMembers(ctx, chatID)
	s.hub.EmitUsers(ctx, members, "message.update", map[string]any{"chat_id": chatID, "message": rawJSON(msg)})
	return c.Raw(200, msg)
}
