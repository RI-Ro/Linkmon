package server

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"

	"github.com/go-ldap/ldap/v3"
	"github.com/jackc/pgx/v5"
)

// LDAP — источник правды о сотрудниках. Серверов может быть несколько; на странице входа пользователь
// выбирает способ входа. Профиль (ФИО, почта, телефоны, должность …) перезаписывается из каталога при
// каждом входе и при синхронизации; поля, для которых в настройках сервера задан атрибут, в портале
// не редактируются.

type ldapSrv struct {
	ID                                                                        int64
	Name, URL, BindDN, BindPassword, BaseDN, UserFilter, SyncFilter           string
	Enabled, StartTLS, SkipVerify, AutoCreate, DeactivateMissing              bool
	AttrLogin, AttrUID, AttrFirst, AttrLast, AttrMiddle, AttrEmail, AttrTitle string
	AttrPhone                                                                 [4]string
	AttrBirthday, AttrDepartment, AttrDisabled, DefaultRole                   string
	SyncMinutes                                                               int
}

const ldapCols = `id, name, enabled, url, start_tls, skip_verify, bind_dn, bind_password, base_dn, user_filter, sync_filter,
	attr_login, attr_uid, attr_first_name, attr_last_name, attr_middle_name, attr_email, attr_title,
	attr_phone1, attr_phone2, attr_phone3, attr_phone4, attr_birthday, attr_department, attr_disabled,
	default_role, auto_create, deactivate_missing, sync_minutes`

type rowScanner interface{ Scan(dest ...any) error }

func (s *Server) scanLDAP(r rowScanner) (*ldapSrv, error) {
	l := &ldapSrv{}
	err := r.Scan(&l.ID, &l.Name, &l.Enabled, &l.URL, &l.StartTLS, &l.SkipVerify, &l.BindDN, &l.BindPassword, &l.BaseDN, &l.UserFilter, &l.SyncFilter,
		&l.AttrLogin, &l.AttrUID, &l.AttrFirst, &l.AttrLast, &l.AttrMiddle, &l.AttrEmail, &l.AttrTitle,
		&l.AttrPhone[0], &l.AttrPhone[1], &l.AttrPhone[2], &l.AttrPhone[3], &l.AttrBirthday, &l.AttrDepartment, &l.AttrDisabled,
		&l.DefaultRole, &l.AutoCreate, &l.DeactivateMissing, &l.SyncMinutes)
	if err != nil {
		return nil, err
	}
	if l.BindPassword != "" {
		if pw, err := s.decrypt(l.BindPassword); err == nil {
			l.BindPassword = pw
		} else {
			l.BindPassword = ""
		}
	}
	return l, nil
}

func (s *Server) loadLDAP(ctx context.Context, id int64) (*ldapSrv, error) {
	return s.scanLDAP(s.db.QueryRow(ctx, `SELECT `+ldapCols+` FROM ldap_servers WHERE id = $1`, id))
}

// ---------------------------------------------------------------- crypto

func (s *Server) gcm() (cipher.AEAD, error) {
	k := sha256.Sum256([]byte(s.cfg.SecretKey))
	b, err := aes.NewCipher(k[:])
	if err != nil {
		return nil, err
	}
	return cipher.NewGCM(b)
}

func (s *Server) encrypt(plain string) (string, error) {
	g, err := s.gcm()
	if err != nil {
		return "", err
	}
	nonce := make([]byte, g.NonceSize())
	if _, err := rand.Read(nonce); err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(g.Seal(nonce, nonce, []byte(plain), nil)), nil
}

func (s *Server) decrypt(enc string) (string, error) {
	raw, err := base64.StdEncoding.DecodeString(enc)
	if err != nil {
		return "", err
	}
	g, err := s.gcm()
	if err != nil {
		return "", err
	}
	if len(raw) < g.NonceSize() {
		return "", errors.New("short ciphertext")
	}
	out, err := g.Open(nil, raw[:g.NonceSize()], raw[g.NonceSize():], nil)
	return string(out), err
}

// ---------------------------------------------------------------- connection

func (l *ldapSrv) dial() (*ldap.Conn, error) {
	tc := &tls.Config{InsecureSkipVerify: l.SkipVerify}
	if u := strings.TrimPrefix(strings.TrimPrefix(l.URL, "ldaps://"), "ldap://"); u != "" {
		host, _, err := net.SplitHostPort(u)
		if err != nil {
			host = u
		}
		tc.ServerName = host
	}
	conn, err := ldap.DialURL(l.URL, ldap.DialWithDialer(&net.Dialer{Timeout: 8 * time.Second}), ldap.DialWithTLSConfig(tc))
	if err != nil {
		return nil, err
	}
	conn.SetTimeout(20 * time.Second)
	if l.StartTLS && strings.HasPrefix(l.URL, "ldap://") {
		if err := conn.StartTLS(tc); err != nil {
			conn.Close()
			return nil, err
		}
	}
	return conn, nil
}

// connectBound returns a connection bound as the service account (or anonymous when no bind DN is set).
func (l *ldapSrv) connectBound() (*ldap.Conn, error) {
	conn, err := l.dial()
	if err != nil {
		return nil, err
	}
	if l.BindDN != "" {
		if err := conn.Bind(l.BindDN, l.BindPassword); err != nil {
			conn.Close()
			return nil, fmt.Errorf("bind: %w", err)
		}
	}
	return conn, nil
}

func (l *ldapSrv) attrs() []string {
	set := map[string]bool{}
	var out []string
	for _, a := range []string{l.AttrLogin, l.AttrUID, l.AttrFirst, l.AttrLast, l.AttrMiddle, l.AttrEmail, l.AttrTitle,
		l.AttrPhone[0], l.AttrPhone[1], l.AttrPhone[2], l.AttrPhone[3], l.AttrBirthday, l.AttrDepartment, l.AttrDisabled} {
		if a != "" && !set[strings.ToLower(a)] {
			set[strings.ToLower(a)] = true
			out = append(out, a)
		}
	}
	return out
}

// attrString reads an attribute; binary values (objectGUID …) are hex-encoded.
func attrString(e *ldap.Entry, name string) string {
	if name == "" {
		return ""
	}
	raw := e.GetRawAttributeValue(name)
	if len(raw) == 0 {
		return ""
	}
	if utf8.Valid(raw) {
		ok := true
		for _, r := range string(raw) {
			if r < 32 {
				ok = false
				break
			}
		}
		if ok {
			return strings.TrimSpace(string(raw))
		}
	}
	return hex.EncodeToString(raw)
}

type ldapPerson struct {
	DN, UID, Login, First, Last, Middle, Email, Title string
	Phone                                             [4]string
	Birthday, Department                              string
	Disabled                                          bool
}

func (l *ldapSrv) person(e *ldap.Entry) *ldapPerson {
	p := &ldapPerson{DN: e.DN}
	p.Login = strings.ToLower(attrString(e, l.AttrLogin))
	p.UID = attrString(e, l.AttrUID)
	if p.UID == "" {
		p.UID = strings.ToLower(e.DN)
	}
	p.First, p.Last, p.Middle = attrString(e, l.AttrFirst), attrString(e, l.AttrLast), attrString(e, l.AttrMiddle)
	p.Email, p.Title = strings.ToLower(attrString(e, l.AttrEmail)), attrString(e, l.AttrTitle)
	for i := range p.Phone {
		p.Phone[i] = attrString(e, l.AttrPhone[i])
	}
	p.Department = attrString(e, l.AttrDepartment)
	if v := attrString(e, l.AttrBirthday); v != "" {
		for _, layout := range []string{"2006-01-02", "20060102", "20060102150405Z", "20060102150405.0Z", "02.01.2006"} {
			if t, err := time.Parse(layout, v); err == nil {
				p.Birthday = t.Format("2006-01-02")
				break
			}
		}
	}
	if v := attrString(e, l.AttrDisabled); v != "" {
		if n, err := strconv.ParseInt(v, 10, 64); err == nil {
			p.Disabled = n&2 != 0 // Active Directory: ACCOUNTDISABLE
		} else {
			p.Disabled = strings.EqualFold(v, "true") || strings.EqualFold(v, "yes")
		}
	}
	// ФИО одной строкой в «sn», если имя не задано отдельно
	if p.First == "" && p.Last != "" {
		parts := strings.Fields(p.Last)
		if len(parts) >= 2 {
			p.Last, p.First = parts[0], parts[1]
			if len(parts) > 2 && p.Middle == "" {
				p.Middle = strings.Join(parts[2:], " ")
			}
		}
	}
	return p
}

// ---------------------------------------------------------------- login

func (s *Server) ldapLogin(ctx context.Context, serverID int64, login, password string) (int64, error) {
	bad := &apiError{401, "Неверный логин или пароль"}
	srv, err := s.loadLDAP(ctx, serverID)
	if err != nil || !srv.Enabled {
		return 0, badReq("Выбранный способ входа недоступен")
	}
	conn, err := srv.connectBound()
	if err != nil {
		s.log.Warn("ldap connect failed", "server", srv.Name, "err", err)
		return 0, &apiError{503, "LDAP-сервер «" + srv.Name + "» недоступен"}
	}
	defer conn.Close()
	filter := strings.ReplaceAll(srv.UserFilter, "%s", ldap.EscapeFilter(login))
	res, err := conn.Search(ldap.NewSearchRequest(srv.BaseDN, ldap.ScopeWholeSubtree, ldap.NeverDerefAliases, 2, 10, false, filter, srv.attrs(), nil))
	if err != nil || len(res.Entries) != 1 {
		if err != nil {
			s.log.Warn("ldap search failed", "server", srv.Name, "err", err)
		}
		return 0, bad
	}
	entry := res.Entries[0]
	if err := conn.Bind(entry.DN, password); err != nil {
		return 0, bad
	}
	p := srv.person(entry)
	if p.Login == "" {
		p.Login = login
	}
	if p.Disabled {
		return 0, &apiError{403, "Учётная запись отключена в каталоге"}
	}
	id, blocked, err := s.upsertLDAPUser(ctx, srv, p, true)
	if err != nil {
		return 0, err
	}
	if blocked {
		return 0, &apiError{403, "Учётная запись заблокирована"}
	}
	return id, nil
}

// upsertLDAPUser creates or updates the portal user for a directory entry.
func (s *Server) upsertLDAPUser(ctx context.Context, srv *ldapSrv, p *ldapPerson, allowCreate bool) (id int64, blocked bool, err error) {
	var deptID *int64
	if p.Department != "" {
		var d int64
		if err := s.db.QueryRow(ctx, `SELECT id FROM departments WHERE lower(name) = lower($1) ORDER BY id LIMIT 1`, p.Department).Scan(&d); err == nil {
			deptID = &d
		}
	}
	if p.Email != "" { // почта уникальна: при конфликте с другим пользователем не записываем её
		var other int64
		if err := s.db.QueryRow(ctx, `SELECT id FROM users WHERE lower(email) = $1 AND NOT (ldap_server_id = $2 AND ldap_uid = $3) LIMIT 1`,
			p.Email, srv.ID, p.UID).Scan(&other); err == nil {
			p.Email = ""
		}
	}
	var existing int64
	err = s.db.QueryRow(ctx, `SELECT id FROM users WHERE ldap_server_id = $1 AND ldap_uid = $2`, srv.ID, p.UID).Scan(&existing)
	if err == pgx.ErrNoRows { // привязка уже заведённой локальной учётки по логину
		err = s.db.QueryRow(ctx, `SELECT id FROM users WHERE ldap_server_id IS NULL AND lower(login) = $1`, p.Login).Scan(&existing)
	}
	if err != nil && err != pgx.ErrNoRows {
		return 0, false, err
	}
	// пустые атрибуты не затирают значения, когда сопоставление не настроено
	keep := func(attr string) bool { return attr == "" }
	if existing != 0 {
		_, err = s.db.Exec(ctx, `UPDATE users SET ldap_server_id = $2, ldap_uid = $3, ldap_dn = $4, login = $5, password_hash = '',
			first_name = CASE WHEN $6 <> '' THEN $6 ELSE first_name END,
			last_name  = CASE WHEN $7 <> '' THEN $7 ELSE last_name END,
			middle_name = CASE WHEN $8 THEN middle_name ELSE $9 END,
			email = CASE WHEN $10 THEN email ELSE $11 END,
			job_title = CASE WHEN $12 THEN job_title ELSE $13 END,
			phone1 = CASE WHEN $14 THEN phone1 ELSE $15 END, phone2 = CASE WHEN $16 THEN phone2 ELSE $17 END,
			phone3 = CASE WHEN $18 THEN phone3 ELSE $19 END, phone4 = CASE WHEN $20 THEN phone4 ELSE $21 END,
			birthday = CASE WHEN $22 THEN birthday ELSE NULLIF($23, '')::date END,
			department_id = coalesce($24::bigint, department_id), updated_at = now()
			WHERE id = $1`,
			existing, srv.ID, p.UID, p.DN, p.Login, p.First, p.Last,
			keep(srv.AttrMiddle), p.Middle, keep(srv.AttrEmail), p.Email, keep(srv.AttrTitle), p.Title,
			keep(srv.AttrPhone[0]), p.Phone[0], keep(srv.AttrPhone[1]), p.Phone[1], keep(srv.AttrPhone[2]), p.Phone[2], keep(srv.AttrPhone[3]), p.Phone[3],
			keep(srv.AttrBirthday), p.Birthday, deptID)
		if err != nil {
			return 0, false, err
		}
		s.dropUserCache(ctx, existing)
		var blk, lb bool
		if err := s.db.QueryRow(ctx, `SELECT blocked, ldap_blocked FROM users WHERE id = $1`, existing).Scan(&blk, &lb); err != nil {
			return 0, false, err
		}
		if blk && lb && !p.Disabled { // каталог снова считает учётку активной
			s.db.Exec(ctx, `UPDATE users SET blocked = false, ldap_blocked = false WHERE id = $1`, existing)
			blk = false
			s.dropUserCache(ctx, existing)
		}
		s.ensurePersonalCalendar(ctx, existing)
		return existing, blk, nil
	}
	if !allowCreate || !srv.AutoCreate {
		return 0, false, &apiError{403, "Пользователь не найден в портале. Обратитесь к администратору"}
	}
	if p.First == "" || p.Last == "" {
		return 0, false, &apiError{422, "В каталоге не заполнены имя и фамилия пользователя"}
	}
	err = s.db.QueryRow(ctx, `INSERT INTO users (login, email, password_hash, first_name, last_name, middle_name, job_title,
			phone1, phone2, phone3, phone4, birthday, department_id, role, ldap_server_id, ldap_dn, ldap_uid)
		VALUES ($1, $2, '', $3, $4, $5, $6, $7, $8, $9, $10, NULLIF($11, '')::date, $12, $13, $14, $15, $16) RETURNING id`,
		p.Login, p.Email, p.First, p.Last, p.Middle, p.Title, p.Phone[0], p.Phone[1], p.Phone[2], p.Phone[3], p.Birthday, deptID,
		srv.DefaultRole, srv.ID, p.DN, p.UID).Scan(&id)
	if err != nil {
		return 0, false, err
	}
	s.ensurePersonalCalendar(ctx, id)
	return id, false, nil
}

func (s *Server) ensurePersonalCalendar(ctx context.Context, uid int64) {
	s.db.Exec(ctx, `INSERT INTO calendars (name, kind, owner_id, visibility, color)
		SELECT 'Мой календарь', 'personal', $1, 'restricted', '#286b9e'
		WHERE NOT EXISTS (SELECT 1 FROM calendars WHERE kind = 'personal' AND owner_id = $1) ON CONFLICT DO NOTHING`, uid)
}

// lockProfile restores the directory-managed fields of an LDAP user so that the portal never edits them.
func (s *Server) lockProfile(ctx context.Context, uid int64, p *profile) error {
	var sid *int64
	if err := s.db.QueryRow(ctx, `SELECT ldap_server_id FROM users WHERE id = $1`, uid).Scan(&sid); err != nil || sid == nil {
		return nil // обычный пользователь (или не найден — ошибку вернёт сам запрос обновления)
	}
	srv, err := s.loadLDAP(ctx, *sid)
	if err != nil {
		return nil
	}
	var cur profile
	if err := s.db.QueryRow(ctx, `SELECT first_name, last_name, middle_name, job_title, email, phone1, phone2, phone3, phone4,
		coalesce(to_char(birthday, 'YYYY-MM-DD'), '') FROM users WHERE id = $1`, uid).
		Scan(&cur.FirstName, &cur.LastName, &cur.MiddleName, &cur.JobTitle, &cur.Email, &cur.Phone1, &cur.Phone2, &cur.Phone3, &cur.Phone4, &cur.Birthday); err != nil {
		return err
	}
	p.FirstName, p.LastName = cur.FirstName, cur.LastName
	if srv.AttrMiddle != "" {
		p.MiddleName = cur.MiddleName
	}
	if srv.AttrEmail != "" {
		p.Email = cur.Email
	}
	if srv.AttrTitle != "" {
		p.JobTitle = cur.JobTitle
	}
	for i, dst := range []*string{&p.Phone1, &p.Phone2, &p.Phone3, &p.Phone4} {
		if srv.AttrPhone[i] != "" {
			*dst = []string{cur.Phone1, cur.Phone2, cur.Phone3, cur.Phone4}[i]
		}
	}
	if srv.AttrBirthday != "" {
		p.Birthday = cur.Birthday
	}
	return nil
}

// ---------------------------------------------------------------- synchronisation

type syncResult struct {
	Seen, Blocked, Errors int
	Message               string
}

func (s *Server) syncLDAP(ctx context.Context, id int64) (*syncResult, error) {
	srv, err := s.loadLDAP(ctx, id)
	if err != nil {
		return nil, err
	}
	res := &syncResult{}
	finish := func(err error) (*syncResult, error) {
		status := fmt.Sprintf("ok: обработано %d, заблокировано %d, ошибок %d", res.Seen, res.Blocked, res.Errors)
		if err != nil {
			status = "ошибка: " + err.Error()
		}
		s.db.Exec(context.Background(), `UPDATE ldap_servers SET last_sync_at = now(), last_sync_status = $2 WHERE id = $1`, id, status)
		res.Message = status
		return res, err
	}
	conn, err := srv.connectBound()
	if err != nil {
		return finish(err)
	}
	defer conn.Close()
	r, err := conn.SearchWithPaging(ldap.NewSearchRequest(srv.BaseDN, ldap.ScopeWholeSubtree, ldap.NeverDerefAliases, 0, 0, false,
		srv.SyncFilter, srv.attrs(), nil), 500)
	if err != nil {
		return finish(err)
	}
	seen := make([]int64, 0, len(r.Entries))
	var disabled []int64
	for _, e := range r.Entries {
		p := srv.person(e)
		if p.Login == "" || p.First == "" || p.Last == "" {
			res.Errors++
			continue
		}
		uid, _, err := s.upsertLDAPUser(ctx, srv, p, true)
		if err != nil {
			s.log.Warn("ldap sync: user failed", "login", p.Login, "err", err)
			res.Errors++
			continue
		}
		res.Seen++
		if p.Disabled {
			disabled = append(disabled, uid)
		} else {
			seen = append(seen, uid)
		}
	}
	if disabled == nil {
		disabled = []int64{}
	}
	if res.Seen == 0 { // защита от ошибочного фильтра: не блокируем всех
		return finish(errors.New("каталог не вернул ни одного пользователя — блокировка пропущена"))
	}
	if srv.DeactivateMissing {
		rows, err := s.db.Query(ctx, `UPDATE users SET blocked = true, ldap_blocked = true WHERE ldap_server_id = $1 AND NOT blocked
			AND (id = ANY($2) OR NOT (id = ANY($3))) RETURNING id`, srv.ID, disabled, seen)
		if err != nil {
			return finish(err)
		}
		var ids []int64
		for rows.Next() {
			var uid int64
			if rows.Scan(&uid) == nil {
				ids = append(ids, uid)
			}
		}
		rows.Close()
		for _, uid := range ids {
			s.killSessions(ctx, uid)
		}
		res.Blocked = len(ids)
	}
	return finish(nil)
}

// ldapSyncJob запускается раз в минуту на каждом экземпляре; атомарный UPDATE гарантирует единственного исполнителя.
func (s *Server) ldapSyncJob(ctx context.Context) {
	rows, err := s.db.Query(ctx, `UPDATE ldap_servers SET last_sync_at = now()
		WHERE enabled AND sync_minutes > 0 AND (last_sync_at IS NULL OR last_sync_at < now() - sync_minutes * interval '1 minute')
		RETURNING id`)
	if err != nil {
		return
	}
	var ids []int64
	for rows.Next() {
		var id int64
		if rows.Scan(&id) == nil {
			ids = append(ids, id)
		}
	}
	rows.Close()
	for _, id := range ids {
		if _, err := s.syncLDAP(ctx, id); err != nil {
			s.log.Warn("ldap sync failed", "server", id, "err", err)
		}
	}
}

// ---------------------------------------------------------------- admin API

const ldapAdminSelect = `SELECT id, name, enabled, url, start_tls, skip_verify, bind_dn, (bind_password <> '') AS password_set, base_dn,
	user_filter, sync_filter, attr_login, attr_uid, attr_first_name, attr_last_name, attr_middle_name, attr_email, attr_title,
	attr_phone1, attr_phone2, attr_phone3, attr_phone4, attr_birthday, attr_department, attr_disabled, default_role, auto_create,
	deactivate_missing, sync_minutes, sort, last_sync_at, last_sync_status,
	(SELECT count(*) FROM users u WHERE u.ldap_server_id = ldap_servers.id) AS users FROM ldap_servers`

func (s *Server) adminListLDAP(c *Ctx) error {
	b, err := s.arr(c.Context(), ldapAdminSelect+` ORDER BY sort, id`)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) adminSaveLDAP(c *Ctx) error {
	var in struct {
		Name              string `json:"name"`
		URL               string `json:"url"`
		BindDN            string `json:"bind_dn"`
		BindPassword      string `json:"bind_password"`
		BaseDN            string `json:"base_dn"`
		UserFilter        string `json:"user_filter"`
		SyncFilter        string `json:"sync_filter"`
		AttrLogin         string `json:"attr_login"`
		AttrUID           string `json:"attr_uid"`
		AttrFirstName     string `json:"attr_first_name"`
		AttrLastName      string `json:"attr_last_name"`
		AttrMiddleName    string `json:"attr_middle_name"`
		AttrEmail         string `json:"attr_email"`
		AttrTitle         string `json:"attr_title"`
		AttrPhone1        string `json:"attr_phone1"`
		AttrPhone2        string `json:"attr_phone2"`
		AttrPhone3        string `json:"attr_phone3"`
		AttrPhone4        string `json:"attr_phone4"`
		AttrBirthday      string `json:"attr_birthday"`
		AttrDepartment    string `json:"attr_department"`
		AttrDisabled      string `json:"attr_disabled"`
		DefaultRole       string `json:"default_role"`
		Enabled           bool   `json:"enabled"`
		StartTLS          bool   `json:"start_tls"`
		SkipVerify        bool   `json:"skip_verify"`
		AutoCreate        bool   `json:"auto_create"`
		DeactivateMissing bool   `json:"deactivate_missing"`
		SyncMinutes       int    `json:"sync_minutes"`
		Sort              int    `json:"sort"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Name, in.URL, in.BaseDN = strings.TrimSpace(in.Name), strings.TrimSpace(in.URL), strings.TrimSpace(in.BaseDN)
	if in.Name == "" || in.BaseDN == "" {
		return badReq("Укажите название и Base DN")
	}
	if !strings.HasPrefix(in.URL, "ldap://") && !strings.HasPrefix(in.URL, "ldaps://") {
		return badReq("Адрес должен начинаться с ldap:// или ldaps://")
	}
	if !strings.Contains(in.UserFilter, "%s") {
		return badReq("Фильтр пользователя должен содержать %s на месте логина")
	}
	if in.DefaultRole != "editor" {
		in.DefaultRole = "user"
	}
	if in.SyncMinutes < 0 {
		in.SyncMinutes = 0
	}
	if in.SyncFilter == "" {
		in.SyncFilter = "(objectClass=person)"
	}
	pw := ""
	if in.BindPassword != "" {
		var err error
		if pw, err = s.encrypt(in.BindPassword); err != nil {
			return err
		}
	}
	ctx := c.Context()
	var id int64
	args := []any{in.Name, in.Enabled, in.URL, in.StartTLS, in.SkipVerify, in.BindDN, pw, in.BaseDN, in.UserFilter, in.SyncFilter,
		in.AttrLogin, in.AttrUID, in.AttrFirstName, in.AttrLastName, in.AttrMiddleName, in.AttrEmail, in.AttrTitle,
		in.AttrPhone1, in.AttrPhone2, in.AttrPhone3, in.AttrPhone4, in.AttrBirthday, in.AttrDepartment, in.AttrDisabled,
		in.DefaultRole, in.AutoCreate, in.DeactivateMissing, in.SyncMinutes, in.Sort}
	if c.R.PathValue("id") != "" {
		var err error
		if id, err = c.ID("id"); err != nil {
			return err
		}
		_, err = s.db.Exec(ctx, `UPDATE ldap_servers SET name = $2, enabled = $3, url = $4, start_tls = $5, skip_verify = $6, bind_dn = $7,
			bind_password = CASE WHEN $8 = '' THEN bind_password ELSE $8 END, base_dn = $9, user_filter = $10, sync_filter = $11,
			attr_login = $12, attr_uid = $13, attr_first_name = $14, attr_last_name = $15, attr_middle_name = $16, attr_email = $17, attr_title = $18,
			attr_phone1 = $19, attr_phone2 = $20, attr_phone3 = $21, attr_phone4 = $22, attr_birthday = $23, attr_department = $24, attr_disabled = $25,
			default_role = $26, auto_create = $27, deactivate_missing = $28, sync_minutes = $29, sort = $30 WHERE id = $1`,
			append([]any{id}, args...)...)
		if err != nil {
			return err
		}
	} else if err := s.db.QueryRow(ctx, `INSERT INTO ldap_servers (name, enabled, url, start_tls, skip_verify, bind_dn, bind_password, base_dn, user_filter, sync_filter,
			attr_login, attr_uid, attr_first_name, attr_last_name, attr_middle_name, attr_email, attr_title,
			attr_phone1, attr_phone2, attr_phone3, attr_phone4, attr_birthday, attr_department, attr_disabled,
			default_role, auto_create, deactivate_missing, sync_minutes, sort)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29) RETURNING id`, args...).Scan(&id); err != nil {
		return err
	}
	s.audit(c, "ldap.save", "ldap", id, map[string]string{"name": in.Name, "url": in.URL})
	b, err := s.one(ctx, ldapAdminSelect+` WHERE id = $1`, id)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) adminDeleteLDAP(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var n int
	s.db.QueryRow(c.Context(), `SELECT count(*) FROM users WHERE ldap_server_id = $1`, id).Scan(&n)
	if n > 0 && c.Q("force") != "1" {
		return conflict(fmt.Sprintf("К этому каталогу привязано пользователей: %d. Они потеряют возможность входа, пока им не задан пароль. Повторите с подтверждением", n))
	}
	if _, err := s.db.Exec(c.Context(), `DELETE FROM ldap_servers WHERE id = $1`, id); err != nil {
		return err
	}
	s.audit(c, "ldap.delete", "ldap", id, nil)
	return c.OK()
}

// adminTestLDAP checks connectivity, the service-account bind and the sync filter without changing any data.
func (s *Server) adminTestLDAP(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	srv, err := s.loadLDAP(c.Context(), id)
	if err != nil {
		return err
	}
	out := map[string]any{"ok": false}
	conn, err := srv.connectBound()
	if err != nil {
		out["error"] = err.Error()
		return c.JSON(200, out)
	}
	defer conn.Close()
	res, err := conn.Search(ldap.NewSearchRequest(srv.BaseDN, ldap.ScopeWholeSubtree, ldap.NeverDerefAliases, 5, 10, false, srv.SyncFilter, srv.attrs(), nil))
	if err != nil && !ldap.IsErrorWithCode(err, ldap.LDAPResultSizeLimitExceeded) {
		out["error"] = err.Error()
		return c.JSON(200, out)
	}
	sample := []map[string]string{}
	if res != nil {
		for _, e := range res.Entries {
			p := srv.person(e)
			sample = append(sample, map[string]string{"login": p.Login, "name": strings.TrimSpace(p.Last + " " + p.First + " " + p.Middle), "email": p.Email})
		}
	}
	out["ok"], out["sample"] = true, sample
	return c.JSON(200, out)
}

func (s *Server) adminSyncLDAP(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	res, err := s.syncLDAP(c.Context(), id)
	if err != nil && res == nil {
		return err
	}
	s.audit(c, "ldap.sync", "ldap", id, res)
	return c.JSON(200, map[string]any{"ok": err == nil, "seen": res.Seen, "blocked": res.Blocked, "errors": res.Errors, "message": res.Message})
}

var _ = json.Marshal
