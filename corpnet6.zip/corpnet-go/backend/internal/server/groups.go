package server

import (
	"context"
	"encoding/json"
	"strconv"
	"strings"

	"github.com/jackc/pgx/v5"
)

// Виды групп:
//   public — открытая: видна всем, вступить может любой;
//   closed — закрытая: видна всем, вступление по заявке (одобряет администратор группы);
//   secret — закрытая и невидимая: нет в списках и поиске, участников добавляет только администратор группы.

const groupSelect = `SELECT g.id, g.name, g.description, g.cover, g.visibility, g.owner_id, g.chat_id, g.created_at,
	(SELECT count(*) FROM group_members m WHERE m.group_id = g.id AND m.role <> 'pending') AS members,
	(SELECT count(*) FROM group_posts p WHERE p.group_id = g.id) AS posts,
	(SELECT m.role FROM group_members m WHERE m.group_id = g.id AND m.user_id = $1) AS my_role
	FROM user_groups g`

// groupVisible — группа видна пользователю $1 (админ портала $2): секретные только участникам.
const groupVisible = `(g.visibility <> 'secret' OR $2::boolean OR EXISTS (SELECT 1 FROM group_members vm WHERE vm.group_id = g.id AND vm.user_id = $1 AND vm.role <> 'pending'))`

func (s *Server) listGroups(c *Ctx) error {
	w := ""
	args := []any{c.U.ID, c.U.IsAdmin()}
	if q := strings.ToLower(c.Q("q")); q != "" {
		w = ` AND lower(g.name) LIKE $3 ESCAPE '\'`
		args = append(args, "%"+likeEscape(q)+"%")
	}
	b, err := s.arr2(c.Context(), groupSelect+` WHERE `+groupVisible+w+` ORDER BY lower(g.name), g.id LIMIT 500`, args...)
	if err != nil {
		return err
	}
	s.logSearch(c, "groups", c.Q("q"), anCount(b)) // аналитика поиска
	return c.Raw(200, b)
}

type groupInfo struct {
	vis   string
	owner int64
	role  string // member role of the caller ("" if none)
	chat  int64
}

func (s *Server) groupInfo(ctx context.Context, gid int64, u *User) (*groupInfo, error) {
	g := &groupInfo{}
	var owner, chat *int64
	var role *string
	err := s.db.QueryRow(ctx, `SELECT g.visibility, g.owner_id, g.chat_id, (SELECT role FROM group_members WHERE group_id = g.id AND user_id = $2)
		FROM user_groups g WHERE g.id = $1`, gid, u.ID).Scan(&g.vis, &owner, &chat, &role)
	if err != nil {
		return nil, err
	}
	if owner != nil {
		g.owner = *owner
	}
	if chat != nil {
		g.chat = *chat
	}
	if role != nil {
		g.role = *role
	}
	// секретной группы для посторонних «не существует»
	if g.vis == "secret" && !u.IsAdmin() && (g.role == "" || g.role == "pending") {
		return nil, pgx.ErrNoRows
	}
	return g, nil
}

func (g *groupInfo) isMember() bool { return g.role != "" && g.role != "pending" }
func (g *groupInfo) canRead(u *User) bool {
	return g.vis == "public" || u.IsAdmin() || g.isMember()
}
func (g *groupInfo) canManage(u *User) bool {
	return u.IsAdmin() || g.owner == u.ID || g.role == "owner" || g.role == "admin"
}

func (s *Server) getGroup(c *Ctx) error {
	gid, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	g, err := s.groupInfo(ctx, gid, c.U)
	if err != nil {
		return err
	}
	grp, err := s.one(ctx, groupSelect+` WHERE g.id = $2`, c.U.ID, gid)
	if err != nil {
		return err
	}
	members := json.RawMessage(`[]`)
	if g.canRead(c.U) || g.canManage(c.U) {
		members, err = s.arr(ctx, `SELECT u.id, u.full_name AS name, u.job_title, u.avatar, u.is_head, m.role
			FROM group_members m JOIN users u ON u.id = m.user_id WHERE m.group_id = $1 AND NOT u.blocked
			ORDER BY (m.role = 'owner') DESC, (m.role = 'admin') DESC, (m.role = 'pending') DESC, `+userOrder+` LIMIT 500`, gid)
		if err != nil {
			return err
		}
	}
	return c.JSON(200, map[string]any{"group": grp, "members": members, "can_read": g.canRead(c.U), "can_manage": g.canManage(c.U),
		"is_owner": g.owner == c.U.ID || c.U.IsAdmin()})
}

func (s *Server) saveGroup(c *Ctx) error {
	var in struct {
		Name        string `json:"name"`
		Description string `json:"description"`
		Cover       string `json:"cover"`
		Visibility  string `json:"visibility"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Name = strings.TrimSpace(in.Name)
	if in.Name == "" {
		return badReq("Укажите название группы")
	}
	if in.Visibility != "closed" && in.Visibility != "secret" {
		in.Visibility = "public"
	}
	ctx := c.Context()
	var id int64
	if c.R.PathValue("id") != "" {
		var err error
		if id, err = c.ID("id"); err != nil {
			return err
		}
		g, err := s.groupInfo(ctx, id, c.U)
		if err != nil {
			return err
		}
		if !g.canManage(c.U) {
			return errForbidden
		}
		err = s.tx(ctx, func(tx pgx.Tx) error {
			if _, err := tx.Exec(ctx, `UPDATE user_groups SET name = $2, description = $3, cover = $4, visibility = $5 WHERE id = $1`,
				id, in.Name, in.Description, in.Cover, in.Visibility); err != nil {
				return err
			}
			if in.Visibility == "public" { // заявки в уже открытой группе теряют смысл
				if _, err := tx.Exec(ctx, `DELETE FROM group_members WHERE group_id = $1 AND role = 'pending'`, id); err != nil {
					return err
				}
			}
			_, err := tx.Exec(ctx, `UPDATE chats SET title = $2 WHERE group_id = $1`, id, in.Name)
			return err
		})
		if err != nil {
			return err
		}
	} else {
		err := s.tx(ctx, func(tx pgx.Tx) error {
			if err := tx.QueryRow(ctx, `INSERT INTO user_groups (name, description, cover, visibility, owner_id) VALUES ($1, $2, $3, $4, $5) RETURNING id`,
				in.Name, in.Description, in.Cover, in.Visibility, c.U.ID).Scan(&id); err != nil {
				return err
			}
			var chat int64
			if err := tx.QueryRow(ctx, `INSERT INTO chats (kind, title, created_by, group_id) VALUES ('group', $1, $2, $3) RETURNING id`, in.Name, c.U.ID, id).Scan(&chat); err != nil {
				return err
			}
			if _, err := tx.Exec(ctx, `UPDATE user_groups SET chat_id = $2 WHERE id = $1`, id, chat); err != nil {
				return err
			}
			if _, err := tx.Exec(ctx, `INSERT INTO group_members (group_id, user_id, role) VALUES ($1, $2, 'owner')`, id, c.U.ID); err != nil {
				return err
			}
			_, err := tx.Exec(ctx, `INSERT INTO chat_members (chat_id, user_id) VALUES ($1, $2)`, chat, c.U.ID)
			return err
		})
		if err != nil {
			return err
		}
	}
	b, err := s.one(ctx, groupSelect+` WHERE g.id = $2`, c.U.ID, id)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) deleteGroup(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	g, err := s.groupInfo(ctx, id, c.U)
	if err != nil {
		return err
	}
	if !(c.U.IsAdmin() || g.owner == c.U.ID) {
		return errForbidden
	}
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `DELETE FROM comments WHERE entity_type = 'post' AND entity_id IN (SELECT id FROM group_posts WHERE group_id = $1)`, id); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `DELETE FROM reactions WHERE entity_type = 'post' AND entity_id IN (SELECT id FROM group_posts WHERE group_id = $1)`, id); err != nil {
			return err
		}
		_, err := tx.Exec(ctx, `DELETE FROM user_groups WHERE id = $1`, id) // cascades members, posts and the group chat
		return err
	})
	if err != nil {
		return err
	}
	s.audit(c, "group.delete", "group", id, nil)
	return c.OK()
}

// groupManagers — владелец и администраторы группы (получатели заявок).
func (s *Server) groupManagers(ctx context.Context, gid int64) []int64 {
	rows, err := s.db.Query(ctx, `SELECT user_id FROM group_members WHERE group_id = $1 AND role IN ('owner', 'admin')`, gid)
	if err != nil {
		return nil
	}
	defer rows.Close()
	var ids []int64
	for rows.Next() {
		var id int64
		if rows.Scan(&id) == nil {
			ids = append(ids, id)
		}
	}
	return ids
}

func (s *Server) joinGroup(c *Ctx) error {
	gid, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	g, err := s.groupInfo(ctx, gid, c.U)
	if err != nil {
		return err
	}
	if g.role != "" {
		return c.JSON(200, map[string]string{"role": g.role})
	}
	if g.vis == "secret" {
		return &apiError{403, "В эту группу добавляет только её администратор"}
	}
	role := "member"
	if g.vis == "closed" {
		role = "pending"
	}
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `INSERT INTO group_members (group_id, user_id, role) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING`, gid, c.U.ID, role); err != nil {
			return err
		}
		if role == "member" && g.chat != 0 {
			_, err := tx.Exec(ctx, `INSERT INTO chat_members (chat_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`, g.chat, c.U.ID)
			return err
		}
		return nil
	})
	if err != nil {
		return err
	}
	if role == "pending" {
		s.notify(ctx, s.groupManagers(ctx, gid), "group", c.U.Name+" хочет вступить в группу", "", "/groups/"+strconv.FormatInt(gid, 10))
	}
	if role == "member" && g.chat != 0 {
		s.hub.Emit(ctx, userTopic(c.U.ID), "chat", map[string]int64{"chat_id": g.chat})
	}
	return c.JSON(200, map[string]string{"role": role})
}

// addGroupMembers — администратор группы добавляет сотрудников напрямую (единственный способ для секретных групп).
func (s *Server) addGroupMembers(c *Ctx) error {
	gid, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		UserIDs []int64 `json:"user_ids"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if len(in.UserIDs) == 0 || len(in.UserIDs) > 500 {
		return badReq("Выберите от 1 до 500 сотрудников")
	}
	ctx := c.Context()
	g, err := s.groupInfo(ctx, gid, c.U)
	if err != nil {
		return err
	}
	if !g.canManage(c.U) {
		return errForbidden
	}
	var added []int64
	err = s.tx(ctx, func(tx pgx.Tx) error {
		rows, err := tx.Query(ctx, `INSERT INTO group_members (group_id, user_id, role) SELECT $1, u.id, 'member' FROM users u
			WHERE u.id = ANY($2) AND NOT u.blocked
			ON CONFLICT (group_id, user_id) DO UPDATE SET role = 'member' WHERE group_members.role = 'pending' RETURNING user_id`, gid, in.UserIDs)
		if err != nil {
			return err
		}
		for rows.Next() {
			var id int64
			if rows.Scan(&id) == nil {
				added = append(added, id)
			}
		}
		rows.Close()
		if g.chat != 0 && len(added) > 0 {
			_, err = tx.Exec(ctx, `INSERT INTO chat_members (chat_id, user_id) SELECT $1, x FROM unnest($2::bigint[]) AS x ON CONFLICT DO NOTHING`, g.chat, added)
		}
		return err
	})
	if err != nil {
		return err
	}
	var name string
	s.db.QueryRow(ctx, `SELECT name FROM user_groups WHERE id = $1`, gid).Scan(&name)
	var others []int64
	for _, id := range added {
		if id != c.U.ID {
			others = append(others, id)
		}
	}
	s.notify(ctx, others, "group", "Вас добавили в группу «"+name+"»", "", "/groups/"+strconv.FormatInt(gid, 10))
	if g.chat != 0 {
		s.hub.EmitUsers(ctx, added, "chat", map[string]int64{"chat_id": g.chat})
	}
	return c.JSON(200, map[string]any{"added": len(added)})
}

func (s *Server) setMemberRole(c *Ctx) error {
	gid, err := c.ID("id")
	if err != nil {
		return err
	}
	uid, err := c.ID("uid")
	if err != nil {
		return err
	}
	var in struct {
		Role string `json:"role"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if in.Role != "admin" && in.Role != "member" {
		return badReq("Роль: admin или member")
	}
	g, err := s.groupInfo(c.Context(), gid, c.U)
	if err != nil {
		return err
	}
	if !(c.U.IsAdmin() || g.owner == c.U.ID) {
		return errForbidden
	}
	tag, err := s.db.Exec(c.Context(), `UPDATE group_members SET role = $3 WHERE group_id = $1 AND user_id = $2 AND role IN ('member', 'admin')`, gid, uid, in.Role)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return errNotFound
	}
	return c.OK()
}

func (s *Server) dropMember(ctx context.Context, tx pgx.Tx, gid, uid, chat int64) error {
	if _, err := tx.Exec(ctx, `DELETE FROM group_members WHERE group_id = $1 AND user_id = $2 AND role <> 'owner'`, gid, uid); err != nil {
		return err
	}
	if chat != 0 {
		_, err := tx.Exec(ctx, `DELETE FROM chat_members WHERE chat_id = $1 AND user_id = $2`, chat, uid)
		return err
	}
	return nil
}

func (s *Server) leaveGroup(c *Ctx) error {
	gid, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	g, err := s.groupInfo(ctx, gid, c.U)
	if err != nil {
		return err
	}
	if g.owner == c.U.ID {
		return badReq("Владелец не может покинуть группу — удалите её или передайте управление")
	}
	if err := s.tx(ctx, func(tx pgx.Tx) error { return s.dropMember(ctx, tx, gid, c.U.ID, g.chat) }); err != nil {
		return err
	}
	return c.OK()
}

func (s *Server) approveMember(c *Ctx) error {
	gid, err := c.ID("id")
	if err != nil {
		return err
	}
	uid, err := c.ID("uid")
	if err != nil {
		return err
	}
	ctx := c.Context()
	g, err := s.groupInfo(ctx, gid, c.U)
	if err != nil {
		return err
	}
	if !g.canManage(c.U) {
		return errForbidden
	}
	err = s.tx(ctx, func(tx pgx.Tx) error {
		tag, err := tx.Exec(ctx, `UPDATE group_members SET role = 'member' WHERE group_id = $1 AND user_id = $2 AND role = 'pending'`, gid, uid)
		if err != nil {
			return err
		}
		if tag.RowsAffected() == 0 {
			return errNotFound
		}
		if g.chat != 0 {
			_, err = tx.Exec(ctx, `INSERT INTO chat_members (chat_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`, g.chat, uid)
		}
		return err
	})
	if err != nil {
		return err
	}
	s.notify(ctx, []int64{uid}, "group", "Ваша заявка в группу одобрена", "", "/groups/"+strconv.FormatInt(gid, 10))
	s.hub.Emit(ctx, userTopic(uid), "chat", map[string]int64{"chat_id": g.chat})
	return c.OK()
}

func (s *Server) removeMember(c *Ctx) error {
	gid, err := c.ID("id")
	if err != nil {
		return err
	}
	uid, err := c.ID("uid")
	if err != nil {
		return err
	}
	ctx := c.Context()
	g, err := s.groupInfo(ctx, gid, c.U)
	if err != nil {
		return err
	}
	if !g.canManage(c.U) && uid != c.U.ID {
		return errForbidden
	}
	if err := s.tx(ctx, func(tx pgx.Tx) error { return s.dropMember(ctx, tx, gid, uid, g.chat) }); err != nil {
		return err
	}
	return c.OK()
}

// ---------------------------------------------------------------- posts

func (s *Server) listPosts(c *Ctx) error {
	gid, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	g, err := s.groupInfo(ctx, gid, c.U)
	if err != nil {
		return err
	}
	if !g.canRead(c.U) {
		return errForbidden
	}
	b, err := s.arr(ctx, `SELECT p.id, p.group_id, p.user_id, u.full_name AS author, u.avatar AS author_avatar,
		u.job_title AS author_title, p.body, p.image, p.likes_count, p.comments_count, p.created_at,
		EXISTS (SELECT 1 FROM reactions l WHERE l.entity_type = 'post' AND l.entity_id = p.id AND l.user_id = $2 AND l.emoji = '👍') AS liked
		FROM group_posts p LEFT JOIN users u ON u.id = p.user_id
		WHERE p.group_id = $1 AND ($3::bigint = 0 OR p.id < $3) ORDER BY p.id DESC LIMIT 20`, gid, c.U.ID, c.QInt64("before"))
	if err != nil {
		return err
	}
	if b, err = s.withSocial(ctx, c.U.ID, "post", b, true); err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) addPost(c *Ctx) error {
	gid, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Body  string `json:"body"`
		Image string `json:"image"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Body = strings.TrimSpace(in.Body)
	if in.Body == "" || len(in.Body) > 5000 {
		return badReq("Текст публикации — от 1 до 5000 символов")
	}
	ctx := c.Context()
	g, err := s.groupInfo(ctx, gid, c.U)
	if err != nil {
		return err
	}
	if !(g.isMember() || c.U.IsAdmin()) {
		return errForbidden
	}
	var id int64
	if err := s.db.QueryRow(ctx, `INSERT INTO group_posts (group_id, user_id, body, image) VALUES ($1, $2, $3, $4) RETURNING id`,
		gid, c.U.ID, in.Body, in.Image).Scan(&id); err != nil {
		return err
	}
	b, err := s.one(ctx, `SELECT p.id, p.group_id, p.user_id, u.full_name AS author, u.avatar AS author_avatar,
		u.job_title AS author_title, p.body, p.image, p.likes_count, p.comments_count, p.created_at, false AS liked
		FROM group_posts p LEFT JOIN users u ON u.id = p.user_id WHERE p.id = $1`, id)
	if err != nil {
		return err
	}
	if strings.Contains(in.Body, "@") {
		var gname string
		s.db.QueryRow(ctx, `SELECT name FROM user_groups WHERE id = $1`, gid).Scan(&gname)
		s.syncMentions(ctx, mentionSrc{Type: "post", ID: id, Actor: c.U, Body: in.Body, Link: "/groups/" + strconv.FormatInt(gid, 10) + "?post=" + strconv.FormatInt(id, 10),
			Where: "в публикации группы", Title: gname, Audience: mentionAudience{Group: gid}})
	}
	return c.Raw(201, b)
}

func (s *Server) deletePost(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	var gid int64
	var author *int64
	if err := s.db.QueryRow(ctx, `SELECT group_id, user_id FROM group_posts WHERE id = $1`, id).Scan(&gid, &author); err != nil {
		return err
	}
	g, err := s.groupInfo(ctx, gid, c.U)
	if err != nil {
		return err
	}
	if !g.canManage(c.U) && (author == nil || *author != c.U.ID) {
		return errForbidden
	}
	err = s.tx(ctx, func(tx pgx.Tx) error {
		tx.Exec(ctx, `DELETE FROM comments WHERE entity_type = 'post' AND entity_id = $1`, id)
		_, err := tx.Exec(ctx, `DELETE FROM group_posts WHERE id = $1`, id)
		return err
	})
	if err != nil {
		return err
	}
	return c.OK()
}
