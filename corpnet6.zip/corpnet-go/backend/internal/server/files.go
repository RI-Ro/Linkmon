package server

import (
	"bufio"
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"image/gif"
	"image/png"
	"io"
	"mime"
	"net/http"
	"net/url"
	"os"
	"path"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

// ---------------------------------------------------------------- storage

type stored struct {
	Storage, Thumb, View, Name, Mime string
	Size                             int64
	W, H                             int
}

var thumbSem = make(chan struct{}, 4) // bound concurrent image decoding

func (s *Server) dir(public bool) string {
	if public {
		return filepath.Join(s.cfg.DataDir, "pub")
	}
	return filepath.Join(s.cfg.DataDir, "prv")
}

func randName(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func cleanName(n string) string {
	n = filepath.Base(strings.ReplaceAll(n, "\\", "/"))
	n = strings.Map(func(r rune) rune {
		if r < 32 || r == 127 || r == '"' {
			return -1
		}
		return r
	}, n)
	if n == "." || n == "/" || n == "" {
		return "file"
	}
	if r := []rune(n); len(r) > 200 {
		n = string(r[:200])
	}
	return n
}

var imageExt = map[string]string{"image/jpeg": ".jpg", "image/png": ".png", "image/gif": ".gif", "image/webp": ".webp"}

func detectMime(sniff []byte, name string) string {
	m := http.DetectContentType(sniff)
	if i := strings.Index(m, ";"); i >= 0 {
		m = m[:i]
	}
	if m == "application/octet-stream" || m == "text/plain" || m == "application/zip" {
		if t := mime.TypeByExtension(strings.ToLower(filepath.Ext(name))); t != "" {
			if i := strings.Index(t, ";"); i >= 0 {
				t = t[:i]
			}
			return t
		}
	}
	return m
}

// storeUpload streams src to disk (never holding the whole file in memory).
func (s *Server) storeUpload(src io.Reader, origName string, public bool) (*stored, error) {
	return s.storeUploadOpt(src, origName, public, s.cfg.MaxUploadMB<<20, false)
}

// storeUploadOpt — storeUpload с собственным лимитом размера и режимом аватара (квадратное превью 160x160, без .v.jpg).
func (s *Server) storeUploadOpt(src io.Reader, origName string, public bool, limit int64, avatar bool) (*stored, error) {
	br := bufio.NewReaderSize(io.LimitReader(src, limit+1), 32<<10)
	sniff, _ := br.Peek(512)
	name := cleanName(origName)
	mt := detectMime(sniff, name)
	ext := ""
	if public {
		if e, ok := imageExt[mt]; ok {
			ext = e
		} else {
			return nil, &apiError{415, "Допустимы только изображения JPG, PNG, GIF и WebP"}
		}
	} else {
		ext = strings.ToLower(filepath.Ext(name))
		if len(ext) > 8 || strings.ContainsAny(ext, "/\\ ") {
			ext = ""
		}
	}
	storage := randName(12) + ext
	dst := filepath.Join(s.dir(public), storage)
	f, err := os.OpenFile(dst, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0o644)
	if err != nil {
		return nil, err
	}
	n, err := io.Copy(f, br)
	if cerr := f.Close(); err == nil {
		err = cerr
	}
	if err != nil || n > limit {
		os.Remove(dst)
		if err == nil {
			err = &apiError{413, fmt.Sprintf("Файл больше %d МБ", limit>>20)}
		}
		return nil, err
	}
	st := &stored{Storage: storage, Name: name, Mime: mt, Size: n}
	if strings.HasPrefix(mt, "image/") && imageExt[mt] != "" {
		v := makeVariants(dst, mt, avatar)
		st.Thumb, st.View, st.W, st.H = v.Thumb, v.View, v.W, v.H
		if avatar && st.Thumb == "" && mt != "image/webp" {
			os.Remove(dst)
			return nil, &apiError{415, "Не удалось прочитать изображение. Загрузите файл JPG, PNG или GIF"}
		}
	}
	return st, nil
}

// removeStored удаляет файлы и их варианты (<имя>.t.jpg, <имя>.v.jpg).
func (s *Server) removeStored(public bool, names ...string) {
	for _, n := range names {
		if n != "" && !strings.ContainsAny(n, "/\\") {
			for _, suf := range []string{"", ".t.jpg", ".v.jpg"} {
				os.Remove(filepath.Join(s.dir(public), n+suf))
			}
		}
	}
}

func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}

var _ = gif.Decode // register GIF decoder
var _ = png.Decode // register PNG decoder

// uploadPublic stores an image under /media/ (avatars, covers, inline images); nginx serves it with long cache.
// ?kind=avatar — оригинал + квадратное превью 160x160 (до 10 МБ). Иначе — оригинал, просмотр (.v.jpg, 1728 px) и превью (.t.jpg, 320 px).
func (s *Server) uploadPublic(c *Ctx) error {
	avatar := c.Q("kind") == "avatar"
	limit := s.cfg.MaxUploadMB << 20
	if avatar {
		limit = min(limit, 10<<20)
	}
	c.R.Body = http.MaxBytesReader(c.W, c.R.Body, limit+1<<20)
	mr, err := c.R.MultipartReader()
	if err != nil {
		return badReq("Ожидается multipart/form-data")
	}
	for {
		part, err := mr.NextPart()
		if err == io.EOF {
			return badReq("Файл не передан")
		}
		if err != nil {
			var mbe *http.MaxBytesError
			if errors.As(err, &mbe) {
				return &apiError{413, "Файл слишком большой"}
			}
			return badReq("Ошибка чтения запроса")
		}
		if part.FileName() == "" {
			continue
		}
		st, err := s.storeUploadOpt(part, part.FileName(), true, limit, avatar)
		if err != nil {
			return err
		}
		return c.JSON(200, map[string]any{"url": "/media/" + st.Storage, "thumb": thumbURL(st), "view": viewURL(st), "width": st.W, "height": st.H})
	}
}

func thumbURL(st *stored) string {
	if st.Thumb != "" {
		return "/media/" + st.Thumb
	}
	return "/media/" + st.Storage
}

func viewURL(st *stored) string {
	if st.View != "" {
		return "/media/" + st.View
	}
	return "/media/" + st.Storage
}

// readParts streams every file part of a multipart request to fn.
func (s *Server) readParts(c *Ctx, maxFiles int, fn func(name string, r io.Reader) error) error {
	c.R.Body = http.MaxBytesReader(c.W, c.R.Body, (s.cfg.MaxUploadMB<<20)*int64(maxFiles)+1<<20)
	mr, err := c.R.MultipartReader()
	if err != nil {
		return badReq("Ожидается multipart/form-data")
	}
	n := 0
	for {
		part, err := mr.NextPart()
		if err == io.EOF {
			break
		}
		if err != nil {
			return badReq("Ошибка чтения запроса")
		}
		if part.FileName() == "" {
			continue
		}
		if n++; n > maxFiles {
			return badReq("Слишком много файлов в одном запросе")
		}
		if err := fn(part.FileName(), part); err != nil {
			return err
		}
	}
	if n == 0 {
		return badReq("Файл не передан")
	}
	return nil
}

const fileJSON = `id, name, mime, size, width, height, external_url, thumb <> '' AS has_thumb, view <> '' AS has_view, created_at, owner_id`

func (s *Server) insertFile(ctx context.Context, q interface {
	QueryRow(context.Context, string, ...any) pgx.Row
}, st *stored, folder *int64, owner int64, kctx string) (int64, error) {
	var id int64
	err := q.QueryRow(ctx, `INSERT INTO files (folder_id, owner_id, name, mime, size, storage, thumb, view, width, height, context)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING id`,
		folder, owner, st.Name, st.Mime, st.Size, st.Storage, st.Thumb, st.View, st.W, st.H, kctx).Scan(&id)
	return id, err
}

func (s *Server) uploadChatFile(c *Ctx) error {
	cid, err := c.ID("id")
	if err != nil {
		return err
	}
	if ok, err := s.isMember(c.Context(), cid, c.U.ID); err != nil {
		return err
	} else if !ok {
		return errForbidden
	}
	var out json.RawMessage
	err = s.readParts(c, 1, func(name string, r io.Reader) error {
		st, err := s.storeUpload(r, name, false)
		if err != nil {
			return err
		}
		id, err := s.insertFile(c.Context(), s.db, st, nil, c.U.ID, "chat")
		if err != nil {
			s.removeStored(false, st.Storage, st.Thumb, st.View)
			return err
		}
		out, err = s.one(c.Context(), `SELECT `+fileJSON+` FROM files WHERE id = $1`, id)
		return err
	})
	if err != nil {
		return err
	}
	return c.Raw(201, out)
}

// uploadCommentFile stores an attachment for a comment (any user; linked when the comment is posted).
func (s *Server) uploadCommentFile(c *Ctx) error {
	if !s.rateOK(c.Context(), fmt.Sprintf("cfile:%d", c.U.ID), 30, time.Minute) {
		return &apiError{429, "Слишком много файлов. Подождите немного"}
	}
	var out json.RawMessage
	err := s.readParts(c, 1, func(name string, r io.Reader) error {
		st, err := s.storeUpload(r, name, false)
		if err != nil {
			return err
		}
		id, err := s.insertFile(c.Context(), s.db, st, nil, c.U.ID, "comment")
		if err != nil {
			s.removeStored(false, st.Storage, st.Thumb, st.View)
			return err
		}
		out, err = s.one(c.Context(), `SELECT `+fileJSON+` FROM files WHERE id = $1`, id)
		return err
	})
	if err != nil {
		return err
	}
	return c.Raw(201, out)
}

// uploadNewsFile stores an attachment for a news article (editors only; linked on save).
func (s *Server) uploadNewsFile(c *Ctx) error {
	var out json.RawMessage
	err := s.readParts(c, 1, func(name string, r io.Reader) error {
		st, err := s.storeUpload(r, name, false)
		if err != nil {
			return err
		}
		id, err := s.insertFile(c.Context(), s.db, st, nil, c.U.ID, "news")
		if err != nil {
			s.removeStored(false, st.Storage, st.Thumb, st.View)
			return err
		}
		out, err = s.one(c.Context(), `SELECT `+fileJSON+` FROM files WHERE id = $1`, id)
		return err
	})
	if err != nil {
		return err
	}
	return c.Raw(201, out)
}

// ---------------------------------------------------------------- folders

const folderCols = `f.id, f.kind, f.parent_id, f.name, f.description, f.visibility, f.owner_id, f.created_at,
	(SELECT count(*) FROM files x WHERE x.folder_id = f.id) AS files_count,
	(SELECT count(*) FROM folders y WHERE y.parent_id = f.id) AS folders_count,
	coalesce(nullif(f.cover, ''), (SELECT CASE WHEN x.external_url <> '' THEN x.external_url ELSE '/files/' || x.id || '?t=1' END
		FROM files x WHERE x.folder_id = f.id AND x.mime LIKE 'image/%' ORDER BY x.id LIMIT 1), '') AS preview`

func (s *Server) listFolders(c *Ctx) error {
	kind := c.Q("kind")
	if kind != "documents" && kind != "photos" && kind != "videos" {
		return badReq("Неизвестный раздел")
	}
	ctx := c.Context()
	parent := c.QInt64("parent_id")
	page, per, off := c.Page(60, 200)
	out := map[string]any{}
	level := 1
	if c.U.CanEdit() {
		level = 2
	}
	if parent > 0 {
		lvl, err := s.level(c, "folder", parent)
		if err != nil {
			return err
		}
		if lvl == 0 {
			return errForbidden
		}
		level = lvl
		cur, err := s.one(ctx, `SELECT `+folderCols+` FROM folders f WHERE f.id = $1 AND f.kind = $2`, parent, kind)
		if err != nil {
			return err
		}
		crumbs, err := s.arr(ctx, `WITH RECURSIVE t AS (SELECT id, parent_id, name, 0 AS depth FROM folders WHERE id = $1
			UNION ALL SELECT f.id, f.parent_id, f.name, t.depth + 1 FROM folders f JOIN t ON f.id = t.parent_id)
			SELECT id, name FROM t ORDER BY depth DESC`, parent)
		if err != nil {
			return err
		}
		var total int
		if err := s.db.QueryRow(ctx, `SELECT count(*) FROM files WHERE folder_id = $1`, parent).Scan(&total); err != nil {
			return err
		}
		files, err := s.arr(ctx, `SELECT `+fileJSON+` FROM files WHERE folder_id = $1 ORDER BY id DESC LIMIT $2 OFFSET $3`, parent, per, off)
		if err != nil {
			return err
		}
		out["folder"], out["breadcrumbs"], out["files"], out["total"], out["page"], out["per"] = cur, crumbs, files, total, page, per
	}
	cond := "f.parent_id IS NULL"
	args := []any{kind, c.U.ID, c.U.Dept, c.U.IsAdmin()}
	if parent > 0 {
		cond = "f.parent_id = $5"
		args = append(args, parent)
	}
	folders, err := s.arr(ctx, `SELECT `+folderCols+` FROM folders f WHERE f.kind = $1 AND `+cond+` AND `+aclVisible("folder", "f", 2, 3, 4)+` ORDER BY f.name`, args...)
	if err != nil {
		return err
	}
	out["folders"], out["level"] = folders, level
	return c.JSON(200, out)
}

func (s *Server) saveFolder(c *Ctx) error {
	var in struct {
		Kind        string `json:"kind"`
		ParentID    *int64 `json:"parent_id"`
		Name        string `json:"name"`
		Description string `json:"description"`
		Cover       string `json:"cover"`
		Visibility  string `json:"visibility"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Name = strings.TrimSpace(in.Name)
	if in.Name == "" || len(in.Name) > 200 {
		return badReq("Укажите название папки")
	}
	ctx := c.Context()
	var id int64
	if c.R.PathValue("id") != "" {
		var err error
		if id, err = c.ID("id"); err != nil {
			return err
		}
		lvl, err := s.level(c, "folder", id)
		if err != nil {
			return err
		}
		if lvl < 3 {
			return errForbidden
		}
		if _, err := s.db.Exec(ctx, `UPDATE folders SET name = $2, description = $3, cover = $4 WHERE id = $1`, id, in.Name, in.Description, in.Cover); err != nil {
			return err
		}
	} else {
		if in.Kind != "documents" && in.Kind != "photos" && in.Kind != "videos" {
			return badReq("Неизвестный раздел")
		}
		vis := "company"
		if in.ParentID != nil {
			lvl, err := s.level(c, "folder", *in.ParentID)
			if err != nil {
				return badReq("Родительская папка не найдена")
			}
			if lvl < 2 {
				return errForbidden
			}
			s.db.QueryRow(ctx, `SELECT visibility FROM folders WHERE id = $1`, *in.ParentID).Scan(&vis)
		} else if !c.U.CanEdit() {
			return errForbidden
		}
		if in.Visibility == "restricted" || in.Visibility == "company" {
			vis = in.Visibility
		}
		err := s.tx(ctx, func(tx pgx.Tx) error {
			if err := tx.QueryRow(ctx, `INSERT INTO folders (kind, parent_id, name, description, cover, visibility, owner_id)
				VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`, in.Kind, in.ParentID, in.Name, in.Description, in.Cover, vis, c.U.ID).Scan(&id); err != nil {
				return err
			}
			if in.ParentID != nil { // inherit the parent's access list
				_, err := tx.Exec(ctx, `INSERT INTO acl (resource_type, resource_id, subject_type, subject_id, level)
					SELECT 'folder', $1, subject_type, subject_id, level FROM acl WHERE resource_type = 'folder' AND resource_id = $2`, id, *in.ParentID)
				return err
			}
			return nil
		})
		if err != nil {
			return err
		}
	}
	b, err := s.one(ctx, `SELECT `+folderCols+` FROM folders f WHERE f.id = $1`, id)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) deleteFolder(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	lvl, err := s.level(c, "folder", id)
	if err != nil {
		return err
	}
	if lvl < 4 {
		return errForbidden
	}
	ctx := c.Context()
	rows, err := s.db.Query(ctx, `WITH RECURSIVE t AS (SELECT id FROM folders WHERE id = $1 UNION ALL SELECT f.id FROM folders f JOIN t ON f.parent_id = t.id)
		SELECT storage, thumb, view FROM files WHERE folder_id IN (SELECT id FROM t) AND storage <> ''`, id)
	if err != nil {
		return err
	}
	var names []string
	for rows.Next() {
		var a, b, v string
		rows.Scan(&a, &b, &v)
		names = append(names, a, b, v)
	}
	rows.Close()
	if _, err := s.db.Exec(ctx, `DELETE FROM folders WHERE id = $1`, id); err != nil {
		return err
	}
	s.db.Exec(ctx, `DELETE FROM acl WHERE resource_type = 'folder' AND resource_id = $1`, id)
	s.removeStored(false, names...)
	s.audit(c, "folder.delete", "folder", id, nil)
	return c.OK()
}

func (s *Server) uploadFolderFiles(c *Ctx) error {
	fid, err := c.ID("id")
	if err != nil {
		return err
	}
	lvl, err := s.level(c, "folder", fid)
	if err != nil {
		return err
	}
	if lvl < 2 {
		return errForbidden
	}
	var kind string
	if err := s.db.QueryRow(c.Context(), `SELECT kind FROM folders WHERE id = $1`, fid).Scan(&kind); err != nil {
		return err
	}
	var ids []int64
	err = s.readParts(c, 50, func(name string, r io.Reader) error {
		st, err := s.storeUpload(r, name, false)
		if err != nil {
			return err
		}
		if (kind == "photos" && !strings.HasPrefix(st.Mime, "image/")) || (kind == "videos" && !strings.HasPrefix(st.Mime, "video/")) {
			s.removeStored(false, st.Storage, st.Thumb, st.View)
			return &apiError{415, "В этот раздел можно загружать только " + map[string]string{"photos": "изображения", "videos": "видео"}[kind]}
		}
		id, err := s.insertFile(c.Context(), s.db, st, &fid, c.U.ID, "folder")
		if err != nil {
			s.removeStored(false, st.Storage, st.Thumb, st.View)
			return err
		}
		ids = append(ids, id)
		return nil
	})
	if err != nil && len(ids) == 0 {
		return err
	}
	b, qerr := s.arr(c.Context(), `SELECT `+fileJSON+` FROM files WHERE id = ANY($1) ORDER BY id DESC`, ids)
	if qerr != nil {
		return qerr
	}
	return c.Raw(201, b)
}

func (s *Server) deleteFile(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	var folder, owner *int64
	var storage, thumb, view string
	if err := s.db.QueryRow(ctx, `SELECT folder_id, owner_id, storage, thumb, view FROM files WHERE id = $1`, id).Scan(&folder, &owner, &storage, &thumb, &view); err != nil {
		return err
	}
	allowed := c.U.IsAdmin() || (owner != nil && *owner == c.U.ID)
	if !allowed && folder != nil {
		lvl, err := s.level(c, "folder", *folder)
		if err != nil {
			return err
		}
		allowed = lvl >= 3
	}
	if !allowed {
		return errForbidden
	}
	if _, err := s.db.Exec(ctx, `DELETE FROM files WHERE id = $1`, id); err != nil {
		return err
	}
	s.rdb.Del(ctx, fmt.Sprintf("fa:%d:%d", id, c.U.ID))
	s.removeStored(false, storage, thumb, view)
	return c.OK()
}

// ---------------------------------------------------------------- serving

type fileMeta struct {
	Storage string `json:"s"`
	Thumb   string `json:"t"`
	View    string `json:"v"`
	Ctx     string `json:"c"`  // контекст файла (folder/chat/news/comment) — для журнала отказов
	Folder  int64  `json:"fo"` // папка (0 — нет)
	ViaNews bool   `json:"vn"` // доступ дан только благодаря новости с галереей на эту папку
	Mime    string `json:"m"`
	Name    string `json:"n"`
	URL     string `json:"u"`
	OK      bool   `json:"ok"`
}

// fileBaseOKSQL — SQL-условие «пользователь вправе открыть файл f» по контексту файла (папка/чат/комментарий/обучение).
// Единственный источник правды: им пользуются и serveFile, и поиск по содержимому файлов (filesearch.go), поэтому
// результаты поиска никогда не шире, чем доступ при скачивании. Параметры: $2 — id пользователя, $3 — его подразделение,
// $4 — признак администратора; f — алиас таблицы files (должна быть в FROM внешнего запроса).
func fileBaseOKSQL(f string) string {
	e := `CASE {f}.context WHEN 'news' THEN true
				WHEN 'learning' THEN learn_file_ok({f}.id, $2, $3, $4)
				WHEN 'request' THEN req_file_ok({f}.id, $2, $3, $4)
				WHEN 'wiki' THEN wiki_file_ok({f}.id, $2, $4)
				WHEN 'comment' THEN ({f}.owner_id = $2 OR EXISTS (SELECT 1 FROM comment_files cf JOIN comments cm ON cm.id = cf.comment_id WHERE cf.file_id = {f}.id
					AND (cm.entity_type IN ('news', 'idea') OR EXISTS (SELECT 1 FROM group_posts gp JOIN user_groups g ON g.id = gp.group_id
						WHERE gp.id = cm.entity_id AND cm.entity_type = 'post' AND (g.visibility = 'public' OR $4 OR EXISTS (
							SELECT 1 FROM group_members m WHERE m.group_id = g.id AND m.user_id = $2 AND m.role <> 'pending'))))))
				WHEN 'chat' THEN ({f}.owner_id = $2 OR EXISTS (SELECT 1 FROM messages m JOIN chat_members cm ON cm.chat_id = m.chat_id AND cm.user_id = $2 WHERE m.file_id = {f}.id))
				ELSE coalesce((SELECT ` + aclVisible("folder", "fo", 2, 3, 4) + ` FROM folders fo WHERE fo.id = {f}.folder_id), false) END`
	return strings.ReplaceAll(e, "{f}", f)
}

// fileViaNewsSQL — фото/видео папки, привязанной галереей к новости, которую пользователь вправе видеть, открываются
// всем читателям новости. Параметры те же ($2, $4).
func fileViaNewsSQL(f string) string {
	return strings.ReplaceAll(`({f}.context = 'folder' AND {f}.folder_id IS NOT NULL AND EXISTS (SELECT 1 FROM news_galleries ng JOIN news n ON n.id = ng.news_id
				WHERE ng.folder_id = {f}.folder_id AND (`+visibleNow+` OR $4 OR n.author_id = $2)))`, "{f}", f)
}

var inlineMime = map[string]bool{
	"image/jpeg": true, "image/png": true, "image/gif": true, "image/webp": true,
	"video/mp4": true, "video/webm": true, "audio/mpeg": true, "audio/ogg": true, "audio/wav": true, "application/pdf": true,
}

// serveFile authorises the download against the file's folder/chat ACL and then
// either hands the actual byte transfer to nginx (X-Accel-Redirect) or serves it.
func (s *Server) serveFile(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	key := fmt.Sprintf("fa:%d:%d", id, c.U.ID)
	var m fileMeta
	if b, err := s.rdb.Get(ctx, key).Bytes(); err == nil && json.Unmarshal(b, &m) == nil {
		// cache hit: no database round trip
	} else {
		var base, viaNews bool
		err := s.db.QueryRow(ctx, `SELECT f.storage, f.thumb, f.view, f.mime, f.name, f.external_url, f.context, coalesce(f.folder_id, 0),
			`+fileBaseOKSQL("f")+` AS base_ok,
			`+fileViaNewsSQL("f")+` AS via_news
			FROM files f WHERE f.id = $1`, id, c.U.ID, c.U.Dept, c.U.IsAdmin()).Scan(&m.Storage, &m.Thumb, &m.View, &m.Mime, &m.Name, &m.URL, &m.Ctx, &m.Folder, &base, &viaNews)
		if err != nil {
			return err
		}
		m.OK, m.ViaNews = base || viaNews, !base && viaNews
		ttl := 60 * time.Second
		if m.Ctx == "folder" && !base { // доступ/отказ зависит от новостей, которые меняются: кэшируем ненадолго
			ttl = 10 * time.Second
		}
		if b, err := json.Marshal(m); err == nil {
			s.rdb.Set(ctx, key, b, ttl)
		}
	}
	if !m.OK {
		s.log.Info("file access denied", "file", id, "user", c.U.ID, "role", c.U.Role, "dept", c.U.Dept, "context", m.Ctx, "folder", m.Folder,
			"reason", denyReason(m.Ctx))
		return errForbidden
	}
	if m.ViaNews {
		s.log.Debug("file access granted via news gallery", "file", id, "user", c.U.ID, "folder", m.Folder)
	}
	if m.URL != "" {
		http.Redirect(c.W, c.R, m.URL, http.StatusFound)
		return nil
	}
	// ?t=1 — превью, ?v=1 — просмотр, иначе оригинал; нет варианта (старые файлы, WebP, маленькие картинки) — отдаём оригинал
	name, mt := m.Storage, m.Mime
	switch {
	case c.Q("t") == "1" && m.Thumb != "":
		name, mt = m.Thumb, "image/jpeg"
	case c.Q("v") == "1" && m.View != "":
		name, mt = m.View, "image/jpeg"
	}
	h := c.W.Header()
	h.Set("Content-Type", mt)
	h.Set("Cache-Control", "private, max-age=86400")
	if mt != "application/pdf" { // sandbox ломает встроенный PDF-просмотрщик браузера (раздел «Обучение»)
		h.Set("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; sandbox")
	}
	if !inlineMime[mt] || c.Q("dl") == "1" {
		h.Set("Content-Disposition", "attachment; filename*=UTF-8''"+url.PathEscape(m.Name))
		if !inlineMime[mt] {
			h.Set("Content-Type", "application/octet-stream")
		}
	} else {
		h.Set("Content-Disposition", "inline; filename*=UTF-8''"+url.PathEscape(m.Name))
	}
	if err := s.ensureLocal(ctx, false, name); err != nil {
		return err
	}
	if name != m.Storage {
		if _, err := os.Stat(filepath.Join(s.dir(false), path.Base(name))); err != nil { // вариант не создан/потерян — оригинал
			name, mt = m.Storage, m.Mime
			h.Set("Content-Type", mt)
			if !inlineMime[mt] {
				h.Set("Content-Type", "application/octet-stream")
			}
			if err := s.ensureLocal(ctx, false, name); err != nil {
				return err
			}
		}
	}
	if s.cfg.FilesAccel {
		h.Set("X-Accel-Redirect", "/_data/"+name)
		c.W.WriteHeader(200)
		return nil
	}
	p := filepath.Join(s.dir(false), path.Base(name))
	f, err := os.Open(p)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return errNotFound
		}
		return err
	}
	defer f.Close()
	st, _ := f.Stat()
	http.ServeContent(c.W, c.R, m.Name, st.ModTime(), f)
	return nil
}

var _ = strconv.Itoa

func denyReason(kctx string) string {
	switch kctx {
	case "folder":
		return "папка недоступна по ACL и нет опубликованной новости с галереей на эту папку"
	case "chat":
		return "не участник чата"
	case "comment":
		return "комментарий с вложением недоступен (группа закрыта?)"
	}
	return "нет доступа"
}

// ---------------------------------------------------------------- несколько ЦОДов: файлы по требованию

// ensureLocal гарантирует, что файл есть на локальном диске этого ЦОДа. Если нет (файл загрузили в другом ЦОДе,
// а rsync ещё не доехал), он подтягивается с одного из FILE_PEERS и кладётся на место (pull-through кэш).
func (s *Server) ensureLocal(ctx context.Context, public bool, name string) error {
	if name == "" || strings.ContainsAny(name, "/\\") || len(s.cfg.FilePeers) == 0 {
		return nil
	}
	dst := filepath.Join(s.dir(public), name)
	if _, err := os.Stat(dst); err == nil {
		return nil
	}
	kind := "prv"
	if public {
		kind = "pub"
	}
	cl := &http.Client{Timeout: 5 * time.Minute}
	for _, peer := range s.cfg.FilePeers {
		req, err := http.NewRequestWithContext(ctx, "GET", peer+"/internal/blob/"+kind+"/"+url.PathEscape(name), nil)
		if err != nil {
			continue
		}
		req.Header.Set("X-Internal-Token", s.cfg.InternalToken)
		resp, err := cl.Do(req)
		if err != nil {
			continue
		}
		if resp.StatusCode != 200 {
			resp.Body.Close()
			continue
		}
		tmp := dst + ".part." + randName(4)
		f, err := os.OpenFile(tmp, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0o644)
		if err != nil {
			resp.Body.Close()
			return err
		}
		_, err = io.Copy(f, resp.Body)
		resp.Body.Close()
		if cerr := f.Close(); err == nil {
			err = cerr
		}
		if err != nil {
			os.Remove(tmp)
			continue
		}
		return os.Rename(tmp, dst)
	}
	return nil // нигде не нашли: дальше обычная 404
}

// internalBlob отдаёт файл соседнему ЦОДу. Защищён общим секретом и не публикуется через HAProxy.
func (s *Server) internalBlob(w http.ResponseWriter, r *http.Request) {
	tok := r.Header.Get("X-Internal-Token")
	if s.cfg.InternalToken == "" || tok != s.cfg.InternalToken {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}
	name := path.Base(r.PathValue("name"))
	if name == "." || name == "/" || strings.ContainsAny(name, "/\\") || strings.Contains(name, ".part.") {
		http.NotFound(w, r)
		return
	}
	f, err := os.Open(filepath.Join(s.dir(r.PathValue("kind") == "pub"), name))
	if err != nil {
		http.NotFound(w, r)
		return
	}
	defer f.Close()
	st, _ := f.Stat()
	w.Header().Set("Content-Type", "application/octet-stream")
	http.ServeContent(w, r, name, st.ModTime(), f)
}

// pullPublic вызывается самим nginx (named location @pull), когда публичного файла /media/<name> нет на диске этого ЦОДа:
// подтягивает его с соседнего ЦОДа (ensureLocal) и просит nginx отдать уже локальную копию.
func (s *Server) pullPublic(w http.ResponseWriter, r *http.Request) {
	name := path.Base(r.PathValue("name"))
	if name == "." || name == "/" || strings.ContainsAny(name, "/\\") || strings.Contains(name, ".part.") {
		http.NotFound(w, r)
		return
	}
	if err := s.ensureLocal(r.Context(), true, name); err != nil {
		s.log.Warn("pull public", "name", name, "err", err)
	}
	if _, err := os.Stat(filepath.Join(s.dir(true), name)); err != nil {
		// нет варианта (.t.jpg/.v.jpg) — отдаём оригинал, а не 404
		orig := strings.TrimSuffix(strings.TrimSuffix(name, ".t.jpg"), ".v.jpg")
		if orig == name || orig == "" {
			http.NotFound(w, r)
			return
		}
		if err := s.ensureLocal(r.Context(), true, orig); err != nil {
			s.log.Warn("pull public", "name", orig, "err", err)
		}
		if _, err := os.Stat(filepath.Join(s.dir(true), orig)); err != nil {
			http.NotFound(w, r)
			return
		}
		name = orig
	}
	w.Header().Set("X-Accel-Redirect", "/_pub/"+url.PathEscape(name))
	w.WriteHeader(http.StatusOK)
}

// listAllFolders — плоский список папок фото/видео для выбора галереи в новости.
func (s *Server) listAllFolders(c *Ctx) error {
	kind := c.Q("kind")
	if kind != "photos" && kind != "videos" {
		return badReq("Укажите kind=photos или kind=videos")
	}
	w := `f.kind = $1 AND ` + aclVisible("folder", "f", 2, 3, 4)
	args := []any{kind, c.U.ID, c.U.Dept, c.U.IsAdmin()}
	if q := strings.ToLower(c.Q("q")); q != "" {
		w += ` AND lower(f.name) LIKE $5 ESCAPE '\'`
		args = append(args, "%"+likeEscape(q)+"%")
	}
	b, err := s.arr2(c.Context(), `SELECT f.id, f.name, f.kind, p.name AS parent_name,
		(SELECT count(*) FROM files x WHERE x.folder_id = f.id) AS files_count
		FROM folders f LEFT JOIN folders p ON p.id = f.parent_id WHERE `+w+` ORDER BY lower(f.name), f.id LIMIT 100`, args...)
	if err != nil {
		return err
	}
	s.logSearch(c, kind, c.Q("q"), anCount(b)) // аналитика поиска (photos | videos)
	return c.Raw(200, b)
}
