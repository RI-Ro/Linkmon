package server

import (
	"context"
	"encoding/json"
	"strconv"
	"time"

	"github.com/redis/go-redis/v9"
)

// Run starts the realtime hub and the periodic jobs. Every job is guarded by a
// Redis lock, so with N instances each job still runs once per period.
func (s *Server) Run(ctx context.Context) {
	s.hub.start(ctx)
	go s.every(ctx, 10*time.Second, monJob("heartbeat", s.heartbeat))
	go s.every(ctx, 15*time.Second, monJob("flush_views", s.flushViews))
	go s.every(ctx, time.Hour, monJob("daily", s.dailyJobs))
	go s.every(ctx, time.Minute, monJob("minute", s.minuteJobs))
	go s.every(ctx, 5*time.Second, s.monRedisProbe) // задержка Redis для /metrics (mon_trace.go)
	s.anRun(ctx)                                    // аналитика: очередь поиска, сброс счётчиков, rollup-задачи
	s.fileIndexLoop(ctx)                            // извлечение текста файлов для поиска (filesearch.go)
}

// minuteJobs — глобальные задачи: каждая безопасна при любом числе экземпляров и ЦОДов
// (атомарный UPDATE … RETURNING или блокировка в основной БД).
func (s *Server) minuteJobs(ctx context.Context) {
	s.announceDue(ctx, 0) // отложенные новости стали видимыми
	s.ldapSyncJob(ctx)
	s.outboxCleanup(ctx)
	s.lmsJobs(ctx)     // LMS: автоназначение, напоминания, сроки действия
	s.requestsJob(ctx) // заявки: напоминания, просрочка, эскалация (requests_jobs.go)
}

func (s *Server) every(ctx context.Context, d time.Duration, fn func(context.Context)) {
	t := time.NewTicker(d)
	defer t.Stop()
	fn(ctx)
	for {
		select {
		case <-t.C:
			fn(ctx)
		case <-ctx.Done():
			return
		}
	}
}

// heartbeat lets the admin dashboard list live app instances.
func (s *Server) heartbeat(ctx context.Context) {
	now := time.Now().Unix()
	info, _ := json.Marshal(map[string]any{"ws": s.hub.conns.Load(), "since": s.up.Unix()})
	s.rdb.HSet(ctx, "insts", s.cfg.InstanceID, string(info))
	s.rdb.ZAdd(ctx, "instances", redis.Z{Score: float64(now), Member: s.cfg.InstanceID})
	s.rdb.ZRemRangeByScore(ctx, "instances", "-inf", strconv.FormatInt(now-30, 10))
}

// flushViews moves buffered view counters of this DC from Redis to Postgres in one UPDATE.
func (s *Server) flushViews(ctx context.Context) {
	key := "views:" + s.cfg.DCID
	if !s.rdb.SetNX(ctx, "lock:"+key, s.cfg.InstanceID, 20*time.Second).Val() {
		return
	}
	defer s.rdb.Del(ctx, "lock:"+key)
	s.rdb.RenameNX(ctx, key, key+":flush") // fails harmlessly if there is nothing to flush
	m, err := s.rdb.HGetAll(ctx, key+":flush").Result()
	if err != nil || len(m) == 0 {
		return
	}
	ids, cnt := make([]int64, 0, len(m)), make([]int32, 0, len(m))
	for k, v := range m {
		id, e1 := strconv.ParseInt(k, 10, 64)
		n, e2 := strconv.ParseInt(v, 10, 32)
		if e1 == nil && e2 == nil {
			ids, cnt = append(ids, id), append(cnt, int32(n))
		}
	}
	if _, err := s.db.Exec(ctx, `UPDATE news n SET views_count = n.views_count + v.c
		FROM unnest($1::bigint[], $2::int[]) AS v(id, c) WHERE n.id = v.id`, ids, cnt); err != nil {
		s.log.Warn("flush views failed", "err", err)
		return
	}
	s.rdb.Del(ctx, key+":flush")
	s.anNewsViews(ctx, ids, cnt) // дневной rollup просмотров для аналитики
	s.bumpNews(ctx)
}

func (s *Server) dailyJobs(ctx context.Context) {
	day := time.Now().Format("2006-01-02")
	if !s.lock(ctx, "daily:"+day, 26*time.Hour) {
		return
	}
	// Дни рождения: поздравляют коллеги из того же подразделения (а не вся компания — иначе при большом штате
	// на каждого именинника пришлось бы создавать десятки тысяч уведомлений).
	tag, err := s.db.Exec(ctx, `INSERT INTO notifications (user_id, kind, title, body, link)
		SELECT r.id, 'birthday', 'Сегодня день рождения: ' || b.full_name, b.job_title, '/people/' || b.id
		FROM users b JOIN users r ON r.department_id = b.department_id
		WHERE b.birthday IS NOT NULL AND NOT b.blocked AND NOT r.blocked AND r.id <> b.id
		  AND extract(month FROM b.birthday) = extract(month FROM now()) AND extract(day FROM b.birthday) = extract(day FROM now())`)
	if err == nil && tag.RowsAffected() > 0 {
		s.hub.Emit(ctx, "feed", "refresh", map[string]string{"what": "notifications"})
	}
	s.db.Exec(ctx, `DELETE FROM notifications WHERE created_at < now() - interval '90 days' AND read_at IS NOT NULL`)
	s.db.Exec(ctx, `DELETE FROM sessions WHERE expires_at < now()`)
	s.log.Info("daily jobs done", "birthdays_notified", tag.RowsAffected())
}
