package server

import (
	"context"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/redis/go-redis/v9"
	"golang.org/x/crypto/bcrypt"
)

const cookieName = "cn_sid"

type User struct {
	ID      int64  `json:"id"`
	Role    string `json:"role"`
	Name    string `json:"name"`
	Dept    int64  `json:"dept"`
	Blocked bool   `json:"blocked"`
	Head    bool   `json:"head"`
	Vac     bool   `json:"vac"`    // может вести график отпусков
	CoNews  bool   `json:"conews"` // редактор может публиковать новости для всей компании
	LM      bool   `json:"lm"`     // ответственный за обучение (LMS)
}

func roleRank(r string) int {
	switch r {
	case "admin":
		return 3
	case "editor":
		return 2
	case "user":
		return 1
	}
	return 0
}

func (u *User) rank() int     { return roleRank(u.Role) }
func (u *User) IsAdmin() bool { return u.Role == "admin" }
func (u *User) CanEdit() bool { return u.rank() >= 2 }

var dummyHash, _ = bcrypt.GenerateFromPassword([]byte("dummy-password"), bcrypt.DefaultCost)

func newToken() string {
	b := make([]byte, 32)
	rand.Read(b)
	return base64.RawURLEncoding.EncodeToString(b)
}

func hashPassword(p string) (string, error) {
	b, err := bcrypt.GenerateFromPassword([]byte(p), bcrypt.DefaultCost)
	return string(b), err
}

// ---------------------------------------------------------------- sessions

// Сессии: Redis — быстрый кэш (общий для всех экземпляров ЦОДа). При SESSION_STORE=pg источником правды
// становится таблица sessions (она реплицируется между ЦОДами), а Redis хранит только короткий кэш.

func (s *Server) sessCacheTTL() time.Duration {
	if s.cfg.SessionStore == "pg" {
		return time.Minute
	}
	return s.cfg.SessionTTL
}

func (s *Server) cacheSession(ctx context.Context, tok string, uid int64) {
	u := strconv.FormatInt(uid, 10)
	s.rdb.Set(ctx, "sess:"+tok, u, s.sessCacheTTL())
	s.rdb.SAdd(ctx, "usess:"+u, tok)
	s.rdb.Expire(ctx, "usess:"+u, s.cfg.SessionTTL)
}

func (s *Server) createSession(ctx context.Context, uid int64, ip string) (string, error) {
	tok := newToken()
	if s.cfg.SessionStore == "pg" {
		if _, err := s.db.Exec(ctx, `INSERT INTO sessions (token, user_id, expires_at, ip) VALUES ($1, $2, $3, $4)`,
			tok, uid, time.Now().Add(s.cfg.SessionTTL), ip); err != nil {
			return "", err
		}
	}
	s.cacheSession(ctx, tok, uid)
	return tok, nil
}

func (s *Server) dropSession(ctx context.Context, tok string) {
	if uid, err := s.rdb.Get(ctx, "sess:"+tok).Result(); err == nil {
		s.rdb.SRem(ctx, "usess:"+uid, tok)
	}
	s.rdb.Del(ctx, "sess:"+tok)
	if s.cfg.SessionStore == "pg" {
		s.db.Exec(ctx, `DELETE FROM sessions WHERE token = $1`, tok)
	}
}

// authenticate resolves the session cookie. It returns (nil, nil) for "not logged in".
func (s *Server) authenticate(r *http.Request) (*User, error) {
	ck, err := r.Cookie(cookieName)
	if err != nil || ck.Value == "" {
		return nil, nil
	}
	ctx := r.Context()
	v, err := s.rdb.Get(ctx, "sess:"+ck.Value).Result()
	var uid int64
	switch {
	case err == nil:
		uid, _ = strconv.ParseInt(v, 10, 64)
	case err == redis.Nil && s.cfg.SessionStore == "pg":
		if err := s.ro.QueryRow(ctx, `SELECT user_id FROM sessions WHERE token = $1 AND expires_at > now()`, ck.Value).Scan(&uid); err != nil {
			if err == pgx.ErrNoRows {
				return nil, nil
			}
			return nil, err
		}
		s.cacheSession(ctx, ck.Value, uid)
	case err == redis.Nil:
		return nil, nil
	default:
		return nil, err
	}
	return s.loadUser(ctx, uid)
}

func (s *Server) loadUser(ctx context.Context, uid int64) (*User, error) {
	key := "u:" + strconv.FormatInt(uid, 10)
	if v, err := s.rdb.Get(ctx, key).Bytes(); err == nil {
		var u User
		if json.Unmarshal(v, &u) == nil {
			if u.Blocked {
				return nil, nil
			}
			return &u, nil
		}
	}
	u := User{ID: uid}
	err := s.ro.QueryRow(ctx, `SELECT role, full_name, coalesce(department_id, 0), blocked, is_head, can_vacations, company_news, learning_manager
		FROM users WHERE id = $1`, uid).Scan(&u.Role, &u.Name, &u.Dept, &u.Blocked, &u.Head, &u.Vac, &u.CoNews, &u.LM)
	if err != nil {
		return nil, nil // deleted user: treat as logged out
	}
	if b, err := json.Marshal(u); err == nil {
		ttl := 5 * time.Minute
		if s.cfg.Realtime == "pg" {
			ttl = time.Minute // другие ЦОДы узнают об изменении через sys-событие, TTL — страховка
		}
		s.rdb.Set(ctx, key, b, ttl)
	}
	if u.Blocked {
		return nil, nil
	}
	return &u, nil
}

// dropUserCache forgets the cached profile of uid in this and (via the realtime channel) in every other DC.
func (s *Server) dropUserCache(ctx context.Context, uid int64) {
	s.rdb.Del(ctx, "u:"+strconv.FormatInt(uid, 10))
	s.sys(ctx, "drop_user", uid)
}

func (s *Server) killSessions(ctx context.Context, uid int64) {
	s.killLocalSessions(ctx, uid)
	if s.cfg.SessionStore == "pg" {
		s.db.Exec(ctx, `DELETE FROM sessions WHERE user_id = $1`, uid)
	}
	s.rdb.Del(ctx, "u:"+strconv.FormatInt(uid, 10))
	s.sys(ctx, "kill_user", uid)
}

func (s *Server) killLocalSessions(ctx context.Context, uid int64) {
	set := "usess:" + strconv.FormatInt(uid, 10)
	toks, _ := s.rdb.SMembers(ctx, set).Result()
	for _, t := range toks {
		s.rdb.Del(ctx, "sess:"+t)
	}
	s.rdb.Del(ctx, set)
}

// rateOK is a fixed-window limiter shared across the instances of one DC.
func (s *Server) rateOK(ctx context.Context, key string, limit int64, window time.Duration) bool {
	n, err := s.rdb.Incr(ctx, "rl:"+key).Result()
	if err != nil {
		return true // fail open
	}
	if n == 1 {
		s.rdb.Expire(ctx, "rl:"+key, window)
	}
	return n <= limit
}

// userCols — публичная карточка сотрудника. name = «Фамилия Имя Отчество».
const userCols = `u.id, u.login, u.first_name, u.last_name, u.middle_name, u.full_name AS name, u.email, u.job_title, u.extra_info,
	u.department_id, d.name AS department, u.role, u.avatar, u.phone1, u.phone2, u.phone3, u.phone4,
	to_char(u.birthday, 'YYYY-MM-DD') AS birthday, CASE WHEN u.birthday IS NULL THEN NULL ELSE date_part('year', age(current_date, u.birthday))::int END AS age,
	u.is_head, u.can_vacations, u.company_news, u.learning_manager, u.blocked, u.ldap_server_id, u.ldap_server_id IS NOT NULL AS ldap`

const userFrom = ` FROM users u LEFT JOIN departments d ON d.id = u.department_id`

// userOrder — «Фамилия, Имя, Отчество» по алфавиту (индекс users_alpha).
const userOrder = `lower(u.last_name), lower(u.first_name), lower(u.middle_name), u.id`

func (s *Server) userJSON(ctx context.Context, id int64) (json.RawMessage, error) {
	return s.one(ctx, `SELECT `+userCols+userFrom+` WHERE u.id = $1`, id)
}

func (s *Server) meJSON(ctx context.Context, id int64) (json.RawMessage, error) {
	return s.one(ctx, `SELECT `+userCols+`, u.settings`+userFrom+` WHERE u.id = $1`, id)
}

// authSources — список способов входа для страницы входа.
func (s *Server) authSources(c *Ctx) error {
	b, err := s.arr(c.Context(), `SELECT 0 AS id, 'Локальная учётная запись' AS name, 0 AS sort
		UNION ALL SELECT id, name, sort + 1 FROM ldap_servers WHERE enabled ORDER BY sort, id`)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) login(c *Ctx) error {
	var in struct {
		Login    string `json:"login"`
		Email    string `json:"email"` // совместимость со старым клиентом
		Password string `json:"password"`
		Source   int64  `json:"source"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	login := strings.ToLower(strings.TrimSpace(in.Login))
	if login == "" {
		login = strings.ToLower(strings.TrimSpace(in.Email))
	}
	ctx := c.Context()
	if login == "" || in.Password == "" {
		return badReq("Введите логин и пароль")
	}
	if !s.rateOK(ctx, "login:ip:"+c.IP(), 40, 15*time.Minute) || !s.rateOK(ctx, "login:em:"+login, 10, 15*time.Minute) {
		return &apiError{429, "Слишком много попыток входа. Повторите позже"}
	}
	var id int64
	if in.Source > 0 {
		var err error
		if id, err = s.ldapLogin(ctx, in.Source, login, in.Password); err != nil {
			return err
		}
	} else {
		var hash string
		var blocked bool
		err := s.db.QueryRow(ctx, `SELECT id, password_hash, blocked FROM users
			WHERE ldap_server_id IS NULL AND (lower(login) = $1 OR (email <> '' AND lower(email) = $1))`, login).Scan(&id, &hash, &blocked)
		if err != nil {
			bcrypt.CompareHashAndPassword(dummyHash, []byte(in.Password)) // equalise timing
			return &apiError{401, "Неверный логин или пароль"}
		}
		if bcrypt.CompareHashAndPassword([]byte(hash), []byte(in.Password)) != nil {
			return &apiError{401, "Неверный логин или пароль"}
		}
		if blocked {
			return &apiError{403, "Учётная запись заблокирована"}
		}
	}
	s.rdb.Del(ctx, "rl:login:em:"+login)
	tok, err := s.createSession(ctx, id, c.IP())
	if err != nil {
		return err
	}
	http.SetCookie(c.W, &http.Cookie{Name: cookieName, Value: tok, Path: "/", HttpOnly: true, Secure: s.cfg.CookieSecure,
		SameSite: http.SameSiteLaxMode, MaxAge: int(s.cfg.SessionTTL.Seconds())})
	s.db.Exec(ctx, `UPDATE users SET last_seen = now() WHERE id = $1`, id)
	b, err := s.meJSON(ctx, id)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) logout(c *Ctx) error {
	if ck, err := c.R.Cookie(cookieName); err == nil {
		s.dropSession(c.Context(), ck.Value)
	}
	http.SetCookie(c.W, &http.Cookie{Name: cookieName, Value: "", Path: "/", HttpOnly: true, MaxAge: -1})
	return c.OK()
}

// bootstrap returns everything the SPA needs on first paint in a single call.
func (s *Server) bootstrap(c *Ctx) error {
	ctx := c.Context()
	if ck, err := c.R.Cookie(cookieName); err == nil { // sliding session
		s.rdb.Expire(ctx, "sess:"+ck.Value, s.sessCacheTTL())
		if s.cfg.SessionStore == "pg" {
			s.db.Exec(ctx, `UPDATE sessions SET expires_at = $2 WHERE token = $1 AND expires_at < $3`,
				ck.Value, time.Now().Add(s.cfg.SessionTTL), time.Now().Add(s.cfg.SessionTTL/2))
		}
	}
	me, err := s.meJSON(ctx, c.U.ID)
	if err != nil {
		return err
	}
	company, err := s.one(ctx, `SELECT * FROM company WHERE id = 1`)
	if err != nil {
		return err
	}
	cats, err := s.arr(ctx, `SELECT id, name, color FROM categories ORDER BY sort, id`)
	if err != nil {
		return err
	}
	notif, chats, err := s.unreadCounts(ctx, c.U.ID)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{
		"me": me, "company": company, "categories": cats,
		"unread":   map[string]int64{"notifications": notif, "chats": chats},
		"instance": s.cfg.InstanceID, "dc": s.cfg.DCID,
	})
}

// unreadCounts: счётчики ограничены 100 — на экране «99+», а запрос остаётся дешёвым при любом числе записей.
func (s *Server) unreadCounts(ctx context.Context, uid int64) (notif, chats int64, err error) {
	err = s.db.QueryRow(ctx, `SELECT
		(SELECT count(*) FROM (SELECT 1 FROM notifications WHERE user_id = $1 AND read_at IS NULL LIMIT 100) q),
		coalesce((SELECT sum(x.n) FROM (
			SELECT (SELECT count(*) FROM (SELECT 1 FROM messages m WHERE m.chat_id = cm.chat_id AND m.id > greatest(cm.last_read_id, cm.cleared_before_id)
				AND m.deleted_at IS NULL AND m.user_id IS DISTINCT FROM $1 LIMIT 99) q) AS n
			FROM chat_members cm WHERE cm.user_id = $1 AND NOT cm.hidden) x), 0)`, uid).Scan(&notif, &chats)
	return
}

// profile — редактируемые поля карточки сотрудника.
type profile struct {
	FirstName  string `json:"first_name"`
	LastName   string `json:"last_name"`
	MiddleName string `json:"middle_name"`
	JobTitle   string `json:"job_title"`
	ExtraInfo  string `json:"extra_info"`
	Email      string `json:"email"`
	Phone1     string `json:"phone1"`
	Phone2     string `json:"phone2"`
	Phone3     string `json:"phone3"`
	Phone4     string `json:"phone4"`
	Birthday   string `json:"birthday"`
	Avatar     string `json:"avatar"`
}

func (p *profile) trim() {
	for _, f := range []*string{&p.FirstName, &p.LastName, &p.MiddleName, &p.JobTitle, &p.ExtraInfo, &p.Email, &p.Phone1, &p.Phone2, &p.Phone3, &p.Phone4, &p.Birthday} {
		*f = strings.TrimSpace(*f)
	}
	p.Email = strings.ToLower(p.Email)
}

func (p *profile) validate() error {
	if p.FirstName == "" || p.LastName == "" {
		return badReq("Укажите фамилию и имя")
	}
	if p.Email != "" && (!strings.Contains(p.Email, "@") || len(p.Email) > 200) {
		return badReq("Некорректный email")
	}
	if len(p.ExtraInfo) > 4000 {
		return badReq("Дополнительная информация слишком длинная")
	}
	for _, ph := range []string{p.Phone1, p.Phone2, p.Phone3, p.Phone4} {
		if len([]rune(ph)) > 64 {
			return badReq("Телефон слишком длинный (до 64 символов)")
		}
	}
	if p.Birthday != "" {
		if _, err := time.Parse("2006-01-02", p.Birthday); err != nil {
			return badReq("Дата рождения должна быть в формате ГГГГ-ММ-ДД")
		}
	}
	return nil
}

func (s *Server) updateMe(c *Ctx) error {
	var in struct {
		profile
		Settings json.RawMessage `json:"settings"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.trim()
	ctx := c.Context()
	if err := s.lockProfile(ctx, c.U.ID, &in.profile); err != nil {
		return err
	}
	if err := in.validate(); err != nil {
		return err
	}
	if len(in.Settings) == 0 {
		in.Settings = json.RawMessage(`{}`)
	}
	_, err := s.db.Exec(ctx, `UPDATE users SET first_name = $2, last_name = $3, middle_name = $4, job_title = $5, extra_info = $6,
		email = $7, phone1 = $8, phone2 = $9, phone3 = $10, phone4 = $11, birthday = NULLIF($12, '')::date, avatar = $13,
		settings = $14::jsonb, updated_at = now() WHERE id = $1`,
		c.U.ID, in.FirstName, in.LastName, in.MiddleName, in.JobTitle, in.ExtraInfo, in.Email, in.Phone1, in.Phone2, in.Phone3, in.Phone4,
		in.Birthday, in.Avatar, string(in.Settings))
	if err != nil {
		return err
	}
	s.dropUserCache(ctx, c.U.ID)
	b, err := s.meJSON(ctx, c.U.ID)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) changePassword(c *Ctx) error {
	var in struct {
		Old string `json:"old"`
		New string `json:"new"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if len(in.New) < 8 {
		return badReq("Пароль должен содержать не менее 8 символов")
	}
	var hash string
	var ldap bool
	if err := s.db.QueryRow(c.Context(), `SELECT password_hash, ldap_server_id IS NOT NULL FROM users WHERE id = $1`, c.U.ID).Scan(&hash, &ldap); err != nil {
		return err
	}
	if ldap {
		return badReq("Пароль этой учётной записи управляется в LDAP-каталоге")
	}
	if bcrypt.CompareHashAndPassword([]byte(hash), []byte(in.Old)) != nil {
		return badReq("Текущий пароль указан неверно")
	}
	nh, err := hashPassword(in.New)
	if err != nil {
		return err
	}
	if _, err := s.db.Exec(c.Context(), `UPDATE users SET password_hash = $2, updated_at = now() WHERE id = $1`, c.U.ID, nh); err != nil {
		return err
	}
	// keep the current session, drop all others
	cur := ""
	if ck, err := c.R.Cookie(cookieName); err == nil {
		cur = ck.Value
	}
	set := "usess:" + strconv.FormatInt(c.U.ID, 10)
	toks, _ := s.rdb.SMembers(c.Context(), set).Result()
	for _, t := range toks {
		if t != cur {
			s.rdb.Del(c.Context(), "sess:"+t)
			s.rdb.SRem(c.Context(), set, t)
		}
	}
	if s.cfg.SessionStore == "pg" {
		s.db.Exec(c.Context(), `DELETE FROM sessions WHERE user_id = $1 AND token <> $2`, c.U.ID, cur)
	}
	return c.OK()
}
