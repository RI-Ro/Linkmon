package server

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

// ---------------------------------------------------------------- модель

type ltest struct {
	ID               int64      `json:"id"`
	FolderID         int64      `json:"folder_id"`
	Title            string     `json:"title"`
	Description      string     `json:"description"`
	Status           string     `json:"status"`
	PassPercent      int        `json:"pass_percent"`
	TimeLimitMin     *int       `json:"time_limit_min"`
	MaxAttempts      *int       `json:"max_attempts"`
	ShuffleQuestions bool       `json:"shuffle_questions"`
	ShuffleAnswers   bool       `json:"shuffle_answers"`
	PartialCredit    bool       `json:"partial_credit"`
	ShowAnswers      string     `json:"show_answers"`
	AvailableFrom    *time.Time `json:"available_from"`
	AvailableTo      *time.Time `json:"available_to"`
	Sort             int        `json:"sort"`
	QuestionsCount   int        `json:"questions_count"`
	MaxScore         float64    `json:"max_score"`
	AttemptsCount    int        `json:"attempts_count"`
	PassedCount      int        `json:"passed_count"`
	AvgPercent       float64    `json:"avg_percent"`
	PoolSize         *int       `json:"pool_size"`
	CertTemplateID   *int64     `json:"cert_template_id"`
	CertValidity     int        `json:"cert_validity_months"`
	AuthorID         *int64     `json:"author_id"`
	CreatedAt        time.Time  `json:"created_at"`
	UpdatedAt        time.Time  `json:"updated_at"`
}

const testCols = `t.id, t.folder_id, t.title, t.description, t.status, t.pass_percent, t.time_limit_min, t.max_attempts, t.shuffle_questions, t.shuffle_answers,
	t.partial_credit, t.show_answers, t.available_from, t.available_to, t.sort, t.questions_count, t.max_score::float8, t.attempts_count, t.passed_count,
	CASE WHEN t.attempts_count > 0 THEN t.sum_percent / t.attempts_count ELSE 0 END, t.pool_size, t.cert_template_id, t.cert_validity_months, t.author_id, t.created_at, t.updated_at`

func (s *Server) learnLoadTest(ctx context.Context, id int64) (*ltest, error) {
	var t ltest
	err := s.db.QueryRow(ctx, `SELECT `+testCols+` FROM learn_tests t WHERE t.id = $1`, id).Scan(&t.ID, &t.FolderID, &t.Title, &t.Description, &t.Status, &t.PassPercent,
		&t.TimeLimitMin, &t.MaxAttempts, &t.ShuffleQuestions, &t.ShuffleAnswers, &t.PartialCredit, &t.ShowAnswers, &t.AvailableFrom, &t.AvailableTo, &t.Sort,
		&t.QuestionsCount, &t.MaxScore, &t.AttemptsCount, &t.PassedCount, &t.AvgPercent, &t.PoolSize, &t.CertTemplateID, &t.CertValidity, &t.AuthorID, &t.CreatedAt, &t.UpdatedAt)
	return &t, err
}

// learnTestAccess загружает тест и проверяет доступ вызывающего: возвращает тест и уровень доступа к его папке.
func (s *Server) learnTestAccess(c *Ctx, id int64, min int) (*ltest, int, error) {
	t, err := s.learnLoadTest(c.Context(), id)
	if err != nil {
		return nil, 0, err
	}
	var lvl int
	if err := s.db.QueryRow(c.Context(), `SELECT learn_level($1, $2, $3, $4)`, t.FolderID, c.U.ID, c.U.Dept, c.U.IsAdmin()).Scan(&lvl); err != nil {
		return nil, 0, err
	}
	if lvl == 0 && min <= lvView && t.Status == "published" { // доступ через курс или назначение
		var ok bool
		if err := s.db.QueryRow(c.Context(), `SELECT lms_ref_ok('test', $1, $2, $3, $4)`, id, c.U.ID, c.U.Dept, c.U.IsAdmin()).Scan(&ok); err != nil {
			return nil, 0, err
		}
		if ok {
			lvl = lvView
		}
	}
	if lvl < lvView || lvl < min || (t.Status != "published" && lvl < lvEdit) {
		return nil, 0, errForbidden
	}
	return t, lvl, nil
}

type qOpt struct {
	ID      int    `json:"id"`
	Text    string `json:"text"`
	Correct bool   `json:"correct"`
}

type qIn struct {
	ID          int64    `json:"id"`
	Type        string   `json:"type"`
	Text        string   `json:"text"`
	FileID      *int64   `json:"file_id"`
	Options     []qOpt   `json:"options"`
	Answers     []string `json:"answers"`
	Pairs       []qPair  `json:"pairs"` // matching
	Items       []qItem  `json:"items"` // ordering: порядок элементов = правильный порядок
	Weight      float64  `json:"weight"`
	Explanation string   `json:"explanation"`
}

type qPair struct {
	ID    int    `json:"id"`
	Left  string `json:"left"`
	Right string `json:"right"`
}

type qItem struct {
	ID   int    `json:"id"`
	Text string `json:"text"`
}

// normalize проверяет вопрос и приводит его к каноническому виду. Возвращает текст ошибки (для отчёта импорта) или "".
func (q *qIn) normalize() string {
	q.Text = strings.TrimSpace(q.Text)
	q.Explanation = strings.TrimSpace(q.Explanation)
	if q.Text == "" {
		return "пустой текст вопроса"
	}
	if len([]rune(q.Text)) > 3000 {
		return "слишком длинный текст вопроса"
	}
	if len([]rune(q.Explanation)) > 3000 {
		return "слишком длинное пояснение"
	}
	if q.Weight == 0 {
		q.Weight = 1
	}
	if q.Weight < 0.01 || q.Weight > 100 {
		return "вес вопроса должен быть от 0,01 до 100"
	}
	switch q.Type {
	case "single", "multiple":
		opts := make([]qOpt, 0, len(q.Options))
		for _, o := range q.Options {
			o.Text = strings.TrimSpace(o.Text)
			if o.Text == "" {
				continue
			}
			if len([]rune(o.Text)) > 1000 {
				return "слишком длинный вариант ответа"
			}
			opts = append(opts, o)
		}
		if len(opts) < 2 {
			return "нужно минимум два варианта ответа"
		}
		if len(opts) > 20 {
			return "не более 20 вариантов ответа"
		}
		used, next, right := map[int]bool{}, 0, 0
		for _, o := range opts {
			if o.ID > next {
				next = o.ID
			}
		}
		next++
		for i := range opts {
			if opts[i].ID <= 0 || used[opts[i].ID] {
				opts[i].ID = next
				next++
			}
			used[opts[i].ID] = true
			if opts[i].Correct {
				right++
			}
		}
		if right == 0 {
			return "не отмечен правильный вариант"
		}
		if q.Type == "single" && right != 1 {
			return "в вопросе с одним ответом должен быть ровно один правильный вариант"
		}
		q.Options, q.Answers = opts, nil
	case "text":
		ans, seen := []string{}, map[string]bool{}
		for _, a := range q.Answers {
			a = strings.TrimSpace(a)
			if a == "" || len([]rune(a)) > 300 {
				continue
			}
			if k := normText(a); !seen[k] {
				seen[k] = true
				ans = append(ans, a)
			}
		}
		if len(ans) == 0 {
			return "не указан правильный ответ"
		}
		if len(ans) > 30 {
			return "слишком много допустимых ответов"
		}
		q.Answers, q.Options = ans, nil
	case "matching":
		pairs, used, next := make([]qPair, 0, len(q.Pairs)), map[int]bool{}, 1
		for _, p := range q.Pairs {
			p.Left, p.Right = strings.TrimSpace(p.Left), strings.TrimSpace(p.Right)
			if p.Left == "" && p.Right == "" {
				continue
			}
			if p.Left == "" || p.Right == "" {
				return "в каждой паре нужны обе части"
			}
			if len([]rune(p.Left)) > 500 || len([]rune(p.Right)) > 500 {
				return "слишком длинный элемент пары"
			}
			if p.ID > next {
				next = p.ID
			}
			pairs = append(pairs, p)
		}
		if len(pairs) < 2 || len(pairs) > 12 {
			return "нужно от 2 до 12 пар"
		}
		next++
		for i := range pairs {
			if pairs[i].ID <= 0 || used[pairs[i].ID] {
				pairs[i].ID = next
				next++
			}
			used[pairs[i].ID] = true
		}
		q.Pairs, q.Options, q.Answers, q.Items = pairs, nil, nil, nil
	case "ordering":
		items, used, next := make([]qItem, 0, len(q.Items)), map[int]bool{}, 1
		for _, it := range q.Items {
			it.Text = strings.TrimSpace(it.Text)
			if it.Text == "" {
				continue
			}
			if len([]rune(it.Text)) > 500 {
				return "слишком длинный элемент"
			}
			if it.ID > next {
				next = it.ID
			}
			items = append(items, it)
		}
		if len(items) < 2 || len(items) > 12 {
			return "нужно от 2 до 12 элементов"
		}
		next++
		for i := range items {
			if items[i].ID <= 0 || used[items[i].ID] {
				items[i].ID = next
				next++
			}
			used[items[i].ID] = true
		}
		q.Items, q.Options, q.Answers, q.Pairs = items, nil, nil, nil
	default:
		return "неизвестный тип вопроса"
	}
	return ""
}

func (q *qIn) data() []byte {
	var m map[string]any
	switch q.Type {
	case "text":
		m = map[string]any{"answers": q.Answers}
	case "matching":
		m = map[string]any{"pairs": q.Pairs}
	case "ordering":
		m = map[string]any{"items": q.Items}
	default:
		m = map[string]any{"options": q.Options}
	}
	b, _ := json.Marshal(m)
	return b
}

type testIn struct {
	FolderID         int64      `json:"folder_id"`
	Title            string     `json:"title"`
	Description      string     `json:"description"`
	Status           string     `json:"status"`
	PassPercent      *int       `json:"pass_percent"`
	TimeLimitMin     *int       `json:"time_limit_min"`
	MaxAttempts      *int       `json:"max_attempts"`
	ShuffleQuestions bool       `json:"shuffle_questions"`
	ShuffleAnswers   bool       `json:"shuffle_answers"`
	PartialCredit    bool       `json:"partial_credit"`
	ShowAnswers      string     `json:"show_answers"`
	AvailableFrom    *time.Time `json:"available_from"`
	AvailableTo      *time.Time `json:"available_to"`
	Sort             int        `json:"sort"`
	PoolSize         *int       `json:"pool_size"`
	CertTemplateID   *int64     `json:"cert_template_id"`
	CertValidity     int        `json:"cert_validity_months"`
	Questions        *[]qIn     `json:"questions"`
}

func (in *testIn) validate() error {
	in.Title = strings.TrimSpace(in.Title)
	if in.Title == "" || len([]rune(in.Title)) > 300 {
		return badReq("Укажите название теста (до 300 символов)")
	}
	if len(in.Description) > 5000 {
		return badReq("Слишком длинное описание")
	}
	if in.Status != "published" {
		in.Status = "draft"
	}
	if in.PassPercent == nil {
		v := 70
		in.PassPercent = &v
	}
	if *in.PassPercent < 0 || *in.PassPercent > 100 {
		return badReq("Проходной балл — от 0 до 100%")
	}
	if in.TimeLimitMin != nil && (*in.TimeLimitMin < 1 || *in.TimeLimitMin > 720) {
		return badReq("Лимит времени — от 1 до 720 минут")
	}
	if in.MaxAttempts != nil && (*in.MaxAttempts < 1 || *in.MaxAttempts > 100) {
		return badReq("Число попыток — от 1 до 100")
	}
	switch in.ShowAnswers {
	case "never", "after_attempt", "after_finish":
	default:
		in.ShowAnswers = "after_attempt"
	}
	if in.PoolSize != nil && (*in.PoolSize < 1 || *in.PoolSize > 500) {
		return badReq("Число вопросов из банка — от 1 до 500")
	}
	if in.CertValidity < 0 || in.CertValidity > 600 {
		return badReq("Срок действия сертификата — от 0 до 600 месяцев")
	}
	if in.AvailableFrom != nil && in.AvailableTo != nil && !in.AvailableTo.After(*in.AvailableFrom) {
		return badReq("Дата окончания доступности должна быть позже даты начала")
	}
	if in.Questions != nil {
		if len(*in.Questions) > 500 {
			return badReq("В тесте не более 500 вопросов")
		}
		for i := range *in.Questions {
			if e := (*in.Questions)[i].normalize(); e != "" {
				return badReq(fmt.Sprintf("Вопрос %d: %s", i+1, e))
			}
		}
	}
	return nil
}

// learnSaveQuestions заменяет набор вопросов теста, сохраняя id существующих (чтобы не терять ответы в попытках).
func (s *Server) learnSaveQuestions(ctx context.Context, tx pgx.Tx, test, uid int64, qs []qIn) (purge []int64, err error) {
	rows, err := tx.Query(ctx, `SELECT id, file_id FROM learn_questions WHERE test_id = $1`, test)
	if err != nil {
		return nil, err
	}
	old := map[int64]*int64{}
	for rows.Next() {
		var id int64
		var f *int64
		rows.Scan(&id, &f)
		old[id] = f
	}
	rows.Close()
	keep := map[int64]bool{}
	fileUse := map[int64]bool{}
	for i := range qs {
		q := &qs[i]
		if q.FileID != nil {
			f := *q.FileID
			if fileUse[f] {
				return nil, badReq("Одна и та же картинка использована в двух вопросах")
			}
			fileUse[f] = true
			var ok bool
			if err := tx.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM files f WHERE f.id = $1 AND f.context = 'learning' AND f.mime LIKE 'image/%'
				AND (f.owner_id = $2 OR EXISTS (SELECT 1 FROM learn_questions x WHERE x.file_id = f.id AND x.test_id = $3))
				AND NOT EXISTS (SELECT 1 FROM learn_questions x WHERE x.file_id = f.id AND x.test_id <> $3))`, f, uid, test).Scan(&ok); err != nil {
				return nil, err
			}
			if !ok {
				return nil, badReq(fmt.Sprintf("Вопрос %d: картинка не найдена", i+1))
			}
		}
		if prev, exists := old[q.ID]; q.ID > 0 && exists {
			keep[q.ID] = true
			if prev != nil && (q.FileID == nil || *q.FileID != *prev) {
				purge = append(purge, *prev)
			}
			if _, err := tx.Exec(ctx, `UPDATE learn_questions SET sort = $2, type = $3, text = $4, file_id = $5, data = $6::jsonb, weight = $7, explanation = $8 WHERE id = $1`,
				q.ID, i, q.Type, q.Text, q.FileID, string(q.data()), q.Weight, q.Explanation); err != nil {
				return nil, err
			}
		} else if err := tx.QueryRow(ctx, `INSERT INTO learn_questions (test_id, sort, type, text, file_id, data, weight, explanation)
			VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7, $8) RETURNING id`, test, i, q.Type, q.Text, q.FileID, string(q.data()), q.Weight, q.Explanation).Scan(&q.ID); err != nil {
			return nil, err
		}
	}
	for id, f := range old {
		if !keep[id] {
			if f != nil {
				purge = append(purge, *f)
			}
			if _, err := tx.Exec(ctx, `DELETE FROM learn_questions WHERE id = $1`, id); err != nil {
				return nil, err
			}
		}
	}
	_, err = tx.Exec(ctx, `UPDATE learn_tests SET questions_count = (SELECT count(*) FROM learn_questions WHERE test_id = $1),
		max_score = coalesce((SELECT sum(weight) FROM learn_questions WHERE test_id = $1), 0) WHERE id = $1`, test)
	return purge, err
}

func (s *Server) learnTestSave(c *Ctx) error {
	var in testIn
	if err := c.Decode(&in); err != nil {
		return err
	}
	if err := in.validate(); err != nil {
		return err
	}
	ctx := c.Context()
	var id int64
	editing := c.R.PathValue("id") != ""
	if editing {
		var err error
		if id, err = c.ID("id"); err != nil {
			return err
		}
		if _, _, err = s.learnTestAccess(c, id, lvEdit); err != nil {
			return err
		}
	} else {
		f, err := s.learnFolder(c, in.FolderID, lvEdit)
		if err != nil {
			return err
		}
		if f.Kind != "tests" {
			return badReq("Тесты добавляются в папки тестов")
		}
	}
	var purge []int64
	err := s.tx(ctx, func(tx pgx.Tx) error {
		if editing {
			if _, err := tx.Exec(ctx, `UPDATE learn_tests SET title = $2, description = $3, status = $4, pass_percent = $5, time_limit_min = $6, max_attempts = $7,
				shuffle_questions = $8, shuffle_answers = $9, partial_credit = $10, show_answers = $11, available_from = $12, available_to = $13, sort = $14,
				pool_size = $15, cert_template_id = $16, cert_validity_months = $17, updated_at = now() WHERE id = $1`, id, in.Title, in.Description, in.Status, *in.PassPercent, in.TimeLimitMin, in.MaxAttempts, in.ShuffleQuestions, in.ShuffleAnswers,
				in.PartialCredit, in.ShowAnswers, in.AvailableFrom, in.AvailableTo, in.Sort, in.PoolSize, in.CertTemplateID, in.CertValidity); err != nil {
				return err
			}
		} else if err := tx.QueryRow(ctx, `INSERT INTO learn_tests (folder_id, title, description, status, pass_percent, time_limit_min, max_attempts, shuffle_questions,
				shuffle_answers, partial_credit, show_answers, available_from, available_to, sort, author_id, pool_size, cert_template_id, cert_validity_months)
			VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18) RETURNING id`, in.FolderID, in.Title, in.Description, in.Status, *in.PassPercent,
			in.TimeLimitMin, in.MaxAttempts, in.ShuffleQuestions, in.ShuffleAnswers, in.PartialCredit, in.ShowAnswers, in.AvailableFrom, in.AvailableTo, in.Sort, c.U.ID,
			in.PoolSize, in.CertTemplateID, in.CertValidity).Scan(&id); err != nil {
			return err
		}
		if in.Questions != nil {
			var err error
			if purge, err = s.learnSaveQuestions(ctx, tx, id, c.U.ID, *in.Questions); err != nil {
				return err
			}
		}
		if in.Status == "published" {
			var n int
			if err := tx.QueryRow(ctx, `SELECT count(*) FROM learn_questions WHERE test_id = $1`, id).Scan(&n); err != nil {
				return err
			}
			if n == 0 {
				return badReq("Нельзя опубликовать тест без вопросов")
			}
		}
		return nil
	})
	if err != nil {
		return err
	}
	s.learnPurgeFiles(ctx, purge)
	s.learnBump(ctx)
	return c.JSON(200, map[string]int64{"id": id})
}

func (s *Server) learnTestStatus(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Status string `json:"status"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	t, _, err := s.learnTestAccess(c, id, lvEdit)
	if err != nil {
		return err
	}
	if in.Status != "published" && in.Status != "draft" {
		return badReq("Некорректный статус")
	}
	if in.Status == "published" && t.QuestionsCount == 0 {
		return badReq("Нельзя опубликовать тест без вопросов")
	}
	if _, err := s.db.Exec(c.Context(), `UPDATE learn_tests SET status = $2, updated_at = now() WHERE id = $1`, id, in.Status); err != nil {
		return err
	}
	s.learnBump(c.Context())
	return c.OK()
}

func (s *Server) learnTestDelete(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, _, err = s.learnTestAccess(c, id, lvEdit); err != nil {
		return err
	}
	ctx := c.Context()
	var fids []int64
	rows, err := s.db.Query(ctx, `SELECT file_id FROM learn_questions WHERE test_id = $1 AND file_id IS NOT NULL`, id)
	if err != nil {
		return err
	}
	for rows.Next() {
		var f int64
		rows.Scan(&f)
		fids = append(fids, f)
	}
	rows.Close()
	if _, err := s.db.Exec(ctx, `DELETE FROM learn_tests WHERE id = $1`, id); err != nil {
		return err
	}
	s.learnPurgeFiles(ctx, fids)
	s.learnBump(ctx)
	s.audit(c, "learning.test.delete", "learn_test", id, nil)
	return c.OK()
}

func (s *Server) learnTestsMove(c *Ctx) error {
	var in struct {
		IDs      []int64 `json:"ids"`
		FolderID int64   `json:"folder_id"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if len(in.IDs) == 0 || len(in.IDs) > 500 {
		return badReq("Выберите тесты")
	}
	dst, err := s.learnFolder(c, in.FolderID, lvEdit)
	if err != nil {
		return err
	}
	if dst.Kind != "tests" {
		return badReq("Тесты можно переносить только в папки тестов")
	}
	if err := s.learnCheckSources(c, "learn_tests", in.IDs); err != nil {
		return err
	}
	if _, err := s.db.Exec(c.Context(), `UPDATE learn_tests SET folder_id = $2, updated_at = now() WHERE id = ANY($1::bigint[])`, in.IDs, in.FolderID); err != nil {
		return err
	}
	s.learnBump(c.Context())
	return c.OK()
}

func (s *Server) learnTestCopy(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, _, err = s.learnTestAccess(c, id, lvEdit); err != nil {
		return err
	}
	ctx := c.Context()
	var nid int64
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if err := tx.QueryRow(ctx, `INSERT INTO learn_tests (folder_id, title, description, status, pass_percent, time_limit_min, max_attempts, shuffle_questions, shuffle_answers,
				partial_credit, show_answers, available_from, available_to, sort, questions_count, max_score, author_id, pool_size, cert_template_id, cert_validity_months)
			SELECT folder_id, left(title, 280) || ' (копия)', description, 'draft', pass_percent, time_limit_min, max_attempts, shuffle_questions, shuffle_answers,
				partial_credit, show_answers, available_from, available_to, sort, questions_count, max_score, $2, pool_size, cert_template_id, cert_validity_months FROM learn_tests WHERE id = $1 RETURNING id`, id, c.U.ID).Scan(&nid); err != nil {
			return err
		}
		rows, err := tx.Query(ctx, `SELECT id, file_id FROM learn_questions WHERE test_id = $1 ORDER BY sort, id`, id)
		if err != nil {
			return err
		}
		type qf struct {
			id   int64
			file *int64
		}
		var qs []qf
		for rows.Next() {
			var x qf
			rows.Scan(&x.id, &x.file)
			qs = append(qs, x)
		}
		rows.Close()
		for _, x := range qs {
			var nf *int64
			if x.file != nil {
				var f int64
				if err := tx.QueryRow(ctx, `INSERT INTO files (owner_id, name, mime, size, storage, thumb, width, height, context)
					SELECT $2, name, mime, size, storage, thumb, width, height, 'learning' FROM files WHERE id = $1 RETURNING id`, *x.file, c.U.ID).Scan(&f); err == nil {
					nf = &f
				}
			}
			if _, err := tx.Exec(ctx, `INSERT INTO learn_questions (test_id, sort, type, text, file_id, data, weight, explanation)
				SELECT $2, sort, type, text, $3, data, weight, explanation FROM learn_questions WHERE id = $1`, x.id, nid, nf); err != nil {
				return err
			}
		}
		return nil
	})
	if err != nil {
		return err
	}
	s.learnBump(ctx)
	return c.JSON(200, map[string]int64{"id": nid})
}

// ---------------------------------------------------------------- список тестов

func (s *Server) learnTests(c *Ctx) error {
	ctx := c.Context()
	q := strings.ToLower(strings.TrimSpace(c.Q("q")))
	folder := c.QInt64("folder")
	page, per, off := c.Page(30, 100)
	args := []any{c.U.ID}
	add := func(v any) string { args = append(args, v); return "$" + itoa(len(args)) }
	where := []string{}
	order := "t.sort, t.id"
	out := map[string]any{"page": page, "per": per}
	if q != "" {
		all, mng, _, err := s.learnTreeIDs(ctx, c.U, "tests")
		if err != nil {
			return err
		}
		if len(all) == 0 {
			return c.JSON(200, map[string]any{"items": []any{}, "has_more": false})
		}
		where = append(where, "t.folder_id = ANY("+add(all)+"::bigint[])", "(t.status = 'published' OR t.folder_id = ANY("+add(mng)+"::bigint[]))")
		if len([]rune(q)) < 3 {
			where = append(where, `lower(t.title) COLLATE "C" LIKE `+add(likeEscape(q)+"%")+` ESCAPE '\'`)
		} else {
			where = append(where, "lower(t.title) LIKE "+add("%"+likeEscape(q)+"%")+" ESCAPE '\\'")
		}
		if len([]rune(q)) < 3 {
			order = `lower(t.title) COLLATE "C", t.id`
		} else {
			order = "(lower(t.title) LIKE " + add(likeEscape(q)+"%") + " ESCAPE '\\') DESC, t.id DESC"
		}
	} else {
		if folder <= 0 {
			return badReq("Не указана папка")
		}
		f, err := s.learnFolder(c, folder, lvView)
		if err != nil {
			return err
		}
		if f.Kind != "tests" {
			return badReq("Это папка материалов")
		}
		where = append(where, "t.folder_id = "+add(folder))
		total := 0
		if f.Level < lvEdit {
			where = append(where, "t.status = 'published'")
			s.db.QueryRow(ctx, `SELECT pub_count FROM learn_folders WHERE id = $1`, folder).Scan(&total)
		} else {
			s.db.QueryRow(ctx, `SELECT items_count FROM learn_folders WHERE id = $1`, folder).Scan(&total)
		}
		switch c.Q("order") {
		case "new":
			order = "t.id DESC"
		case "title":
			order = "lower(t.title), t.id"
		}
		out["total"], out["level"] = total, f.Level
	}
	lim, offs := add(per+1), add(off)
	b, err := s.arr(ctx, `SELECT t.id, t.folder_id, fo.name AS folder_name, t.title, t.description, t.status, t.pass_percent, t.time_limit_min, t.max_attempts, t.available_from, t.available_to,
			t.sort, t.questions_count, t.attempts_count, t.passed_count, CASE WHEN t.attempts_count > 0 THEN round((t.sum_percent / t.attempts_count)::numeric, 1) ELSE 0 END AS avg_percent,
			json_build_object('n', m.n, 'best', m.best, 'passed', m.passed, 'open_id', m.open_id) AS my
		FROM learn_tests t JOIN learn_folders fo ON fo.id = t.folder_id
		LEFT JOIN LATERAL (SELECT count(*) AS n, max(percent) AS best, bool_or(passed) AS passed, max(id) FILTER (WHERE finished_at IS NULL) AS open_id
			FROM learn_attempts WHERE test_id = t.id AND user_id = $1) m ON true
		WHERE `+strings.Join(where, " AND ")+` ORDER BY `+order+` LIMIT `+lim+` OFFSET `+offs, args...)
	if err != nil {
		return err
	}
	var rows []json.RawMessage
	json.Unmarshal(b, &rows)
	more := len(rows) > per
	if more {
		rows = rows[:per]
	}
	if rows == nil {
		rows = []json.RawMessage{}
	}
	out["items"], out["has_more"] = rows, more
	if off == 0 {
		s.logSearch(c, "learning_tests", q, len(rows)) // аналитика поиска
	}
	return c.JSON(200, out)
}

// ---------------------------------------------------------------- карточка теста

func (s *Server) learnQuestionsFull(ctx context.Context, test int64) (json.RawMessage, error) {
	return s.arr(ctx, `SELECT id, type, text, file_id, data->'options' AS options, data->'answers' AS answers, data->'pairs' AS pairs, data->'items' AS items, weight::float8 AS weight, explanation
		FROM learn_questions WHERE test_id = $1 ORDER BY sort, id`, test)
}

// startCheck: можно ли пользователю начать новую попытку.
func (t *ltest) startCheck(lvl, used int, now time.Time) (bool, string) {
	if t.QuestionsCount == 0 {
		return false, "В тесте пока нет вопросов"
	}
	if lvl >= lvEdit {
		return true, ""
	}
	if t.AvailableFrom != nil && now.Before(*t.AvailableFrom) {
		return false, "Тест будет доступен с " + t.AvailableFrom.In(msk()).Format("02.01.2006 15:04")
	}
	if t.AvailableTo != nil && now.After(*t.AvailableTo) {
		return false, "Приём попыток завершён " + t.AvailableTo.In(msk()).Format("02.01.2006 15:04")
	}
	if t.MaxAttempts != nil && used >= *t.MaxAttempts {
		return false, "Использованы все попытки"
	}
	return true, ""
}

func msk() *time.Location {
	if l, err := time.LoadLocation("Europe/Moscow"); err == nil {
		return l
	}
	return time.FixedZone("MSK", 3*3600)
}

func (s *Server) learnTestGet(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	t, lvl, err := s.learnTestAccess(c, id, lvView)
	if err != nil {
		return err
	}
	var used int
	var open *int64
	var best *float64
	var passed *bool
	if err := s.db.QueryRow(ctx, `SELECT count(*), max(id) FILTER (WHERE finished_at IS NULL), max(percent)::float8, bool_or(passed) FROM learn_attempts WHERE test_id = $1 AND user_id = $2`,
		id, c.U.ID).Scan(&used, &open, &best, &passed); err != nil {
		return err
	}
	attempts, err := s.arr(ctx, `SELECT id, no, started_at, finished_at, score, max_score, percent, passed, duration_sec, expired FROM learn_attempts
		WHERE test_id = $1 AND user_id = $2 ORDER BY no DESC LIMIT 100`, id, c.U.ID)
	if err != nil {
		return err
	}
	ok, reason := t.startCheck(lvl, used, time.Now())
	my := map[string]any{"used": used, "open_id": open, "best": best, "passed": passed, "can_start": ok, "reason": reason, "attempts": attempts}
	if t.MaxAttempts != nil {
		my["left"] = max(*t.MaxAttempts-used, 0)
	}
	var folderName string
	s.db.QueryRow(ctx, `SELECT name FROM learn_folders WHERE id = $1`, t.FolderID).Scan(&folderName)
	out := map[string]any{"test": t, "level": lvl, "my": my, "folder_name": folderName}
	if lvl >= lvEdit && c.Q("edit") == "1" {
		if out["questions"], err = s.learnQuestionsFull(ctx, id); err != nil {
			return err
		}
	}
	return c.JSON(200, out)
}

// ---------------------------------------------------------------- статистика

func (s *Server) learnTestStats(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, _, err = s.learnTestAccess(c, id, lvEdit); err != nil {
		return err
	}
	ctx := c.Context()
	sum, err := s.one(ctx, `SELECT count(*) AS attempts, count(DISTINCT user_id) AS users, coalesce(round(avg(percent), 1), 0) AS avg_percent,
			count(*) FILTER (WHERE passed) AS passed, coalesce(round(avg(duration_sec)), 0) AS avg_duration,
			count(DISTINCT user_id) FILTER (WHERE passed) AS users_passed
		FROM learn_attempts WHERE test_id = $1 AND finished_at IS NOT NULL`, id)
	if err != nil {
		return err
	}
	hist, err := s.arr(ctx, `SELECT b, count(*) AS n FROM (SELECT least(floor(percent / 10), 9)::int AS b FROM learn_attempts WHERE test_id = $1 AND finished_at IS NOT NULL) x GROUP BY b ORDER BY b`, id)
	if err != nil {
		return err
	}
	qs, err := s.arr(ctx, `SELECT q.id, q.text, q.type, coalesce(st.n, 0) AS n, coalesce(st.correct, 0) AS correct, coalesce(st.skipped, 0) AS skipped, st.avg_ratio
		FROM learn_questions q LEFT JOIN (
			SELECT k.key::bigint AS qid, count(*) AS n, count(*) FILTER (WHERE (k.value->>'s')::int = 2) AS correct, count(*) FILTER (WHERE (k.value->>'s')::int = -1) AS skipped,
				round(avg((k.value->>'p')::float8 / nullif((k.value->>'m')::float8, 0))::numeric, 3) AS avg_ratio
			FROM learn_attempts a, jsonb_each(a.details) k WHERE a.test_id = $1 AND a.finished_at IS NOT NULL GROUP BY 1) st ON st.qid = q.id
		WHERE q.test_id = $1 ORDER BY q.sort, q.id`, id)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]json.RawMessage{"summary": sum, "histogram": hist, "questions": qs})
}
