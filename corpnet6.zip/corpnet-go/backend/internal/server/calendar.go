package server

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

// levelExpr evaluates the caller's access level (0 none, 1 view, 2 add, 3 edit, 4 owner)
// on resource `alias`. u, d, a are parameter numbers for user id, department id, is-admin.
func levelExpr(rtype, alias string, u, d, a int, base string) string {
	return fmt.Sprintf(`(CASE WHEN $%[4]d OR %[2]s.owner_id = $%[3]d THEN 4 ELSE greatest(coalesce((
		SELECT max(x.level) FROM acl x WHERE x.resource_type = '%[1]s' AND x.resource_id = %[2]s.id AND
			((x.subject_type = 'user' AND x.subject_id = $%[3]d) OR (x.subject_type = 'department' AND x.subject_id = $%[5]d))), 0), %[6]s) END)`,
		rtype, alias, u, a, d, base)
}

// calBase — уровень по умолчанию для общих календарей: просмотр; добавление — если открыто всем или читатель редактор
// (параметр ed — номер параметра «пользователь — редактор»).
func calBase(alias string, ed int) string {
	return fmt.Sprintf(`(CASE WHEN %[1]s.visibility = 'company' THEN (CASE WHEN %[1]s.open_add OR $%[2]d THEN 2 ELSE 1 END) ELSE 0 END)`, alias, ed)
}

// level returns the caller's access level on a folder or calendar.
func (s *Server) level(c *Ctx, rtype string, id int64) (int, error) {
	var lvl int
	var err error
	switch rtype {
	case "folder":
		err = s.db.QueryRow(c.Context(), `SELECT `+levelExpr("folder", "f", 2, 3, 4,
			`(CASE WHEN f.visibility = 'company' THEN (CASE WHEN $5 THEN 2 ELSE 1 END) ELSE 0 END)`)+` FROM folders f WHERE f.id = $1`,
			id, c.U.ID, c.U.Dept, c.U.IsAdmin(), c.U.CanEdit()).Scan(&lvl)
	case "calendar":
		// личный календарь виден и доступен только владельцу — даже администратору
		err = s.db.QueryRow(c.Context(), `SELECT CASE WHEN c.kind = 'personal' AND c.owner_id <> $2 THEN 0 ELSE `+levelExpr("calendar", "c", 2, 3, 4, calBase("c", 5))+
			` END FROM calendars c WHERE c.id = $1`, id, c.U.ID, c.U.Dept, c.U.IsAdmin(), c.U.CanEdit()).Scan(&lvl)
	default:
		return 0, badReq("Неизвестный тип ресурса")
	}
	return lvl, err
}

// ---------------------------------------------------------------- calendars

func (s *Server) listCalendars(c *Ctx) error {
	b, err := s.arr(c.Context(), `SELECT * FROM (SELECT c.id, c.name, c.description, c.kind, c.color, c.owner_id, c.visibility, c.open_add,
		`+levelExpr("calendar", "c", 1, 2, 3, calBase("c", 4))+` AS level FROM calendars c
		WHERE NOT (c.kind = 'personal' AND c.owner_id <> $1)) t WHERE level > 0
		ORDER BY CASE kind WHEN 'personal' THEN 0 WHEN 'birthdays' THEN 1 WHEN 'conference' THEN 2 ELSE 3 END, name`,
		c.U.ID, c.U.Dept, c.U.IsAdmin(), c.U.CanEdit())
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) saveCalendar(c *Ctx) error {
	var in struct {
		Name        string `json:"name"`
		Description string `json:"description"`
		Color       string `json:"color"`
		Visibility  string `json:"visibility"`
		OpenAdd     bool   `json:"open_add"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Name = strings.TrimSpace(in.Name)
	if in.Name == "" {
		return badReq("Укажите название календаря")
	}
	if in.Visibility != "company" {
		in.Visibility = "restricted"
	}
	if in.Color == "" {
		in.Color = "#286b9e"
	}
	ctx := c.Context()
	var id int64
	if c.R.PathValue("id") != "" {
		var err error
		if id, err = c.ID("id"); err != nil {
			return err
		}
		if lvl, err := s.level(c, "calendar", id); err != nil {
			return err
		} else if lvl < 4 {
			return errForbidden
		}
		if _, err := s.db.Exec(ctx, `UPDATE calendars SET name = $2, description = $3, color = $4,
			visibility = CASE WHEN kind = 'personal' THEN 'restricted' ELSE $5 END, open_add = CASE WHEN kind = 'personal' THEN false ELSE $6 END WHERE id = $1`,
			id, in.Name, in.Description, in.Color, in.Visibility, in.OpenAdd); err != nil {
			return err
		}
	} else if err := s.db.QueryRow(ctx, `INSERT INTO calendars (name, description, kind, color, owner_id, visibility, open_add)
		VALUES ($1, $2, 'custom', $3, $4, $5, $6) RETURNING id`, in.Name, in.Description, in.Color, c.U.ID, in.Visibility, in.OpenAdd).Scan(&id); err != nil {
		return err
	}
	return c.JSON(200, map[string]int64{"id": id})
}

func (s *Server) deleteCalendar(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	lvl, err := s.level(c, "calendar", id)
	if err != nil {
		return err
	}
	if lvl < 4 {
		return errForbidden
	}
	tag, err := s.db.Exec(c.Context(), `DELETE FROM calendars WHERE id = $1 AND kind NOT IN ('personal', 'birthdays')`, id)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return badReq("Этот календарь удалить нельзя")
	}
	s.db.Exec(c.Context(), `DELETE FROM acl WHERE resource_type = 'calendar' AND resource_id = $1`, id)
	return c.OK()
}

// ---------------------------------------------------------------- events

func parseIDs(v string) []int64 {
	out := []int64{}
	for _, p := range strings.Split(v, ",") {
		if id, err := strconv.ParseInt(strings.TrimSpace(p), 10, 64); err == nil && id > 0 {
			out = append(out, id)
		}
	}
	return out
}

// eventsSQL возвращает события, видимые пользователю, в интервале [$4, $5):
//
//	$1 пользователь, $2 подразделение, $3 админ, $4/$5 границы, $6 id календарей (пусто = все), $7 часовой пояс, $8 редактор.
//
// Повторяющиеся события разворачиваются в вхождения прямо в SQL (день, неделя, месяц, год с шагом rec_interval и
// необязательной датой окончания), а дни рождения строятся «на лету» из профилей сотрудников: с полной датой
// рождения и исполняющимся возрастом.
var eventsSQL = `WITH base AS (
	SELECT e.*, cal.name AS calendar, cal.color, cal.kind AS calendar_kind, cu.full_name AS creator,
		(SELECT coalesce(json_agg(json_build_object('id', u.id, 'name', u.full_name, 'status', a.status) ORDER BY u.last_name), '[]')
			FROM event_attendees a JOIN users u ON u.id = a.user_id WHERE a.event_id = e.id) AS attendees,
		(e.ends_at - e.starts_at) AS dur,
		(e.starts_at AT TIME ZONE $7::text) AS s_local
	FROM events e JOIN calendars cal ON cal.id = e.calendar_id LEFT JOIN users cu ON cu.id = e.creator_id
	WHERE e.starts_at < $5::timestamptz AND (e.rec_freq <> 'none' OR e.ends_at >= $4::timestamptz)
	AND (e.rec_freq = 'none' OR e.rec_until IS NULL OR e.rec_until >= $4::timestamptz - e.rec_interval * interval '1 day')
	AND (cardinality($6::bigint[]) = 0 OR cal.id = ANY($6))
	AND (EXISTS (SELECT 1 FROM event_attendees a WHERE a.event_id = e.id AND a.user_id = $1)
		OR (NOT (cal.kind = 'personal' AND cal.owner_id <> $1) AND ` + "%LEVEL%" + ` > 0))
), occ AS (
	SELECT b.id, b.calendar_id, b.title, b.description, b.location, b.starts_at AS base_starts_at, b.all_day, b.video_url, b.creator_id,
		b.calendar, b.color, b.calendar_kind, b.creator, b.attendees, b.rec_freq, b.rec_interval, b.rec_until, b.dur, b.s_local, 0::bigint AS k
	FROM base b WHERE b.rec_freq = 'none'
	UNION ALL
	SELECT b.id, b.calendar_id, b.title, b.description, b.location, b.starts_at, b.all_day, b.video_url, b.creator_id,
		b.calendar, b.color, b.calendar_kind, b.creator, b.attendees, b.rec_freq, b.rec_interval, b.rec_until, b.dur, b.s_local, k.k
	FROM base b CROSS JOIN LATERAL (
		SELECT floor(CASE b.rec_freq
			WHEN 'daily'   THEN extract(epoch FROM ($4::timestamptz - b.dur - b.starts_at)) / 86400
			WHEN 'weekly'  THEN extract(epoch FROM ($4::timestamptz - b.dur - b.starts_at)) / 604800
			WHEN 'monthly' THEN (extract(year FROM ($4::timestamptz AT TIME ZONE $7::text)) * 12 + extract(month FROM ($4::timestamptz AT TIME ZONE $7::text)))
				- (extract(year FROM b.s_local) * 12 + extract(month FROM b.s_local))
			ELSE extract(year FROM ($4::timestamptz AT TIME ZONE $7::text)) - extract(year FROM b.s_local) END / b.rec_interval)::bigint AS lo,
		       ceil(CASE b.rec_freq
			WHEN 'daily'   THEN extract(epoch FROM ($5::timestamptz - b.starts_at)) / 86400
			WHEN 'weekly'  THEN extract(epoch FROM ($5::timestamptz - b.starts_at)) / 604800
			WHEN 'monthly' THEN (extract(year FROM ($5::timestamptz AT TIME ZONE $7::text)) * 12 + extract(month FROM ($5::timestamptz AT TIME ZONE $7::text)))
				- (extract(year FROM b.s_local) * 12 + extract(month FROM b.s_local))
			ELSE extract(year FROM ($5::timestamptz AT TIME ZONE $7::text)) - extract(year FROM b.s_local) END / b.rec_interval)::bigint AS hi
	) r CROSS JOIN LATERAL generate_series(greatest(0, r.lo - 1), least(r.hi + 1, greatest(0, r.lo - 1) + 4000)) AS k(k)
	WHERE b.rec_freq <> 'none'
), ev AS (
	SELECT o.id, o.calendar_id, o.title, o.description, o.location, o.all_day, o.video_url, o.creator_id, o.calendar, o.color, o.calendar_kind,
		o.creator, o.attendees, o.rec_freq, o.rec_interval, o.rec_until, o.base_starts_at, o.k,
		CASE WHEN o.rec_freq = 'none' THEN o.base_starts_at ELSE ((o.s_local + CASE o.rec_freq
			WHEN 'daily'   THEN make_interval(days => (o.k * o.rec_interval)::int)
			WHEN 'weekly'  THEN make_interval(days => (7 * o.k * o.rec_interval)::int)
			WHEN 'monthly' THEN make_interval(months => (o.k * o.rec_interval)::int)
			ELSE make_interval(years => (o.k * o.rec_interval)::int) END) AT TIME ZONE $7::text) END AS starts_at,
		o.dur
	FROM occ o
)
SELECT ev.id, ev.calendar_id, ev.title, ev.description, ev.location, ev.starts_at, ev.starts_at + ev.dur AS ends_at, ev.all_day, ev.video_url, ev.creator_id,
	ev.calendar, ev.color, ev.calendar_kind AS kind, ev.creator, ev.attendees, ev.rec_freq, ev.rec_interval, ev.rec_until, ev.base_starts_at,
	NULL::bigint AS user_id, NULL::text AS birthday, NULL::int AS age, NULL::text AS user_avatar
FROM ev WHERE ev.starts_at < $5::timestamptz AND ev.starts_at + ev.dur >= $4::timestamptz AND (ev.rec_freq = 'none' OR ev.rec_until IS NULL OR ev.starts_at <= ev.rec_until)
UNION ALL
SELECT -u.id, bc.id, 'День рождения: ' || u.full_name, u.job_title, '', (g.d::timestamp AT TIME ZONE $7::text),
	((g.d + 1)::timestamp AT TIME ZONE $7::text) - interval '1 second', true, '', NULL::bigint, bc.name, bc.color, 'birthdays', '', '[]'::json,
	'none', 1, NULL::timestamptz, (g.d::timestamp AT TIME ZONE $7::text),
	u.id, to_char(u.birthday, 'YYYY-MM-DD'), (extract(year FROM g.d) - extract(year FROM u.birthday))::int, u.avatar
FROM (SELECT ($4::timestamptz AT TIME ZONE $7::text)::date AS d0, (($5::timestamptz - interval '1 second') AT TIME ZONE $7::text)::date AS d1) rng
CROSS JOIN LATERAL generate_series(0, rng.d1 - rng.d0) AS g0(n)
CROSS JOIN LATERAL (SELECT rng.d0 + g0.n AS d) g
CROSS JOIN (SELECT id, name, color FROM calendars WHERE kind = 'birthdays' ORDER BY id LIMIT 1) bc
JOIN users u ON u.birthday IS NOT NULL AND NOT u.blocked
	AND ((extract(month FROM u.birthday)::int = extract(month FROM g.d)::int AND extract(day FROM u.birthday)::int = extract(day FROM g.d)::int)
	  OR (extract(month FROM u.birthday)::int = 2 AND extract(day FROM u.birthday)::int = 29 AND g.d = make_date(extract(year FROM g.d)::int, 2, 28)
	      AND g.d + 1 = make_date(extract(year FROM g.d)::int, 3, 1)))
WHERE cardinality($6::bigint[]) = 0 OR bc.id = ANY($6)`

func (s *Server) queryEvents(c *Ctx, from, to string, cals []int64, limit int) (json.RawMessage, error) {
	q := strings.ReplaceAll(eventsSQL, "%LEVEL%", levelExpr("calendar", "cal", 1, 2, 3, calBase("cal", 8)))
	q = `SELECT * FROM (` + q + `) x ORDER BY starts_at, id`
	if limit > 0 {
		q += ` LIMIT ` + strconv.Itoa(limit)
	}
	return s.arr(c.Context(), q, c.U.ID, c.U.Dept, c.U.IsAdmin(), from, to, cals, s.cfg.TZ, c.U.CanEdit())
}

func (s *Server) listEvents(c *Ctx) error {
	from, to := c.Q("from"), c.Q("to")
	f, err1 := time.Parse(time.RFC3339, from)
	t, err2 := time.Parse(time.RFC3339, to)
	maxSpan, limit := 100*24*time.Hour, 0
	if c.Q("list") == "1" { // событиями одним списком: период до года и лимит записей
		maxSpan, limit = 400*24*time.Hour, 1000
	}
	if err1 != nil || err2 != nil || t.Sub(f) > maxSpan || t.Before(f) {
		return badReq("Укажите период from/to (RFC3339, не более 100 дней; для списка — до 400)")
	}
	b, err := s.queryEvents(c, from, to, parseIDs(c.Q("calendars")), limit)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// upcomingEvents — события на ближайшие 5 дней (виджет «Предстоящие события»).
func (s *Server) upcomingEvents(c *Ctx) error {
	now := time.Now()
	b, err := s.queryEvents(c, now.Format(time.RFC3339), now.Add(5*24*time.Hour).Format(time.RFC3339), []int64{}, 30)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) saveEvent(c *Ctx) error {
	var in struct {
		CalendarID  int64   `json:"calendar_id"`
		Title       string  `json:"title"`
		Description string  `json:"description"`
		Location    string  `json:"location"`
		StartsAt    string  `json:"starts_at"`
		EndsAt      string  `json:"ends_at"`
		AllDay      bool    `json:"all_day"`
		Video       bool    `json:"video"`
		VideoURL    string  `json:"video_url"`
		Attendees   []int64 `json:"attendee_ids"`
		RecFreq     string  `json:"rec_freq"`
		RecInterval int     `json:"rec_interval"`
		RecUntil    string  `json:"rec_until"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Title = strings.TrimSpace(in.Title)
	st, e1 := time.Parse(time.RFC3339, in.StartsAt)
	en, e2 := time.Parse(time.RFC3339, in.EndsAt)
	if in.Title == "" || e1 != nil || e2 != nil || en.Before(st) {
		return badReq("Укажите название и корректные дату и время начала и окончания")
	}
	switch in.RecFreq {
	case "daily", "weekly", "monthly", "yearly":
	default:
		in.RecFreq = "none"
	}
	if in.RecInterval < 1 || in.RecInterval > 100 {
		in.RecInterval = 1
	}
	var recUntil *time.Time
	if in.RecFreq != "none" && in.RecUntil != "" {
		t, err := time.Parse(time.RFC3339, in.RecUntil)
		if err != nil || t.Before(st) {
			return badReq("Дата окончания повторов должна быть позже начала события")
		}
		recUntil = &t
	}
	if in.Attendees == nil {
		in.Attendees = []int64{}
	}
	ctx := c.Context()
	var id int64
	update := c.R.PathValue("id") != ""
	if update {
		var err error
		if id, err = c.ID("id"); err != nil {
			return err
		}
		var cal int64
		var creator *int64
		if err := s.db.QueryRow(ctx, `SELECT calendar_id, creator_id FROM events WHERE id = $1`, id).Scan(&cal, &creator); err != nil {
			return err
		}
		lvl, err := s.level(c, "calendar", cal)
		if err != nil {
			return err
		}
		if lvl < 3 && !(creator != nil && *creator == c.U.ID && lvl >= 2) {
			return errForbidden
		}
		if cal != in.CalendarID { // moving between calendars needs add access on the target too
			if l2, err := s.level(c, "calendar", in.CalendarID); err != nil || l2 < 2 {
				return errForbidden
			}
		}
	} else if lvl, err := s.level(c, "calendar", in.CalendarID); err != nil {
		return badReq("Календарь не найден")
	} else if lvl < 2 {
		return errForbidden
	}
	var kind string
	if err := s.db.QueryRow(ctx, `SELECT kind FROM calendars WHERE id = $1`, in.CalendarID).Scan(&kind); err != nil {
		return err
	}
	if kind == "birthdays" {
		return badReq("В календарь дней рождения нельзя добавлять события")
	}
	in.Location = strings.TrimSpace(in.Location)
	if in.Video && in.VideoURL == "" {
		b := make([]byte, 6)
		rand.Read(b)
		in.VideoURL = "https://meet.jit.si/CorpNet-" + hex.EncodeToString(b)
	}
	if !in.Video && !strings.HasPrefix(in.VideoURL, "https://") {
		in.VideoURL = ""
	}
	var invited []int64
	err := s.tx(ctx, func(tx pgx.Tx) error {
		if update {
			if _, err := tx.Exec(ctx, `UPDATE events SET calendar_id = $2, title = $3, description = $4, location = $5, starts_at = $6, ends_at = $7,
				all_day = $8, video_url = $9, rec_freq = $10, rec_interval = $11, rec_until = $12 WHERE id = $1`,
				id, in.CalendarID, in.Title, in.Description, in.Location, st, en, in.AllDay, in.VideoURL, in.RecFreq, in.RecInterval, recUntil); err != nil {
				return err
			}
		} else if err := tx.QueryRow(ctx, `INSERT INTO events (calendar_id, title, description, location, starts_at, ends_at, all_day, video_url, creator_id,
				rec_freq, rec_interval, rec_until)
			VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) RETURNING id`,
			in.CalendarID, in.Title, in.Description, in.Location, st, en, in.AllDay, in.VideoURL, c.U.ID, in.RecFreq, in.RecInterval, recUntil).Scan(&id); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `DELETE FROM event_attendees WHERE event_id = $1 AND NOT (user_id = ANY($2))`, id, in.Attendees); err != nil {
			return err
		}
		rows, err := tx.Query(ctx, `INSERT INTO event_attendees (event_id, user_id) SELECT $1, u.id FROM users u WHERE u.id = ANY($2) AND NOT u.blocked
			ON CONFLICT DO NOTHING RETURNING user_id`, id, in.Attendees)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var uid int64
			if err := rows.Scan(&uid); err != nil {
				return err
			}
			if uid != c.U.ID {
				invited = append(invited, uid)
			}
		}
		return rows.Err()
	})
	if err != nil {
		return err
	}
	s.notify(ctx, invited, "event", "Вас пригласили на событие: "+in.Title, st.Format("02.01.2006 15:04"), "/calendar?event="+strconv.FormatInt(id, 10)+"&date="+st.Format("2006-01-02"))
	return c.JSON(200, map[string]int64{"id": id})
}

func (s *Server) deleteEvent(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var cal int64
	var creator *int64
	if err := s.db.QueryRow(c.Context(), `SELECT calendar_id, creator_id FROM events WHERE id = $1`, id).Scan(&cal, &creator); err != nil {
		return err
	}
	lvl, err := s.level(c, "calendar", cal)
	if err != nil {
		return err
	}
	if lvl < 3 && !(creator != nil && *creator == c.U.ID && lvl >= 2) {
		return errForbidden
	}
	if _, err := s.db.Exec(c.Context(), `DELETE FROM events WHERE id = $1`, id); err != nil {
		return err
	}
	return c.OK()
}

// ---------------------------------------------------------------- ACL

func (s *Server) getACL(c *Ctx) error {
	rtype := c.R.PathValue("type")
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	lvl, err := s.level(c, rtype, id)
	if err != nil {
		return err
	}
	if lvl < 4 {
		return errForbidden
	}
	table := "folders"
	if rtype == "calendar" {
		table = "calendars"
	}
	res, err := s.one(c.Context(), `SELECT visibility, owner_id FROM `+table+` WHERE id = $1`, id)
	if err != nil {
		return err
	}
	entries, err := s.arr(c.Context(), `SELECT a.subject_type, a.subject_id, a.level,
		CASE a.subject_type WHEN 'user' THEN (SELECT full_name FROM users WHERE id = a.subject_id)
			ELSE (SELECT name FROM departments WHERE id = a.subject_id) END AS name
		FROM acl a WHERE a.resource_type = $1 AND a.resource_id = $2 ORDER BY a.subject_type DESC, 4`, rtype, id)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]json.RawMessage{"resource": res, "entries": entries})
}

func (s *Server) putACL(c *Ctx) error {
	rtype := c.R.PathValue("type")
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Visibility string `json:"visibility"`
		Entries    []struct {
			SubjectType string `json:"subject_type"`
			SubjectID   int64  `json:"subject_id"`
			Level       int    `json:"level"`
		} `json:"entries"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	lvl, err := s.level(c, rtype, id)
	if err != nil {
		return err
	}
	if lvl < 4 {
		return errForbidden
	}
	if in.Visibility != "company" {
		in.Visibility = "restricted"
	}
	types, ids, lvls := []string{}, []int64{}, []int32{}
	for _, e := range in.Entries {
		if (e.SubjectType == "user" || e.SubjectType == "department") && e.Level >= 1 && e.Level <= 4 {
			types, ids, lvls = append(types, e.SubjectType), append(ids, e.SubjectID), append(lvls, int32(e.Level))
		}
	}
	ctx := c.Context()
	table, label, link := "folders", "папке", "/documents"
	if rtype == "calendar" {
		table, label, link = "calendars", "календарю", "/calendar"
	} else if err := s.db.QueryRow(ctx, `SELECT kind FROM folders WHERE id = $1`, id).Scan(&link); err == nil {
		link = "/" + link + "?folder=" + strconv.FormatInt(id, 10) // /documents, /photos или /videos — по типу папки
	} else {
		link = "/documents"
	}
	var name string
	var before []int64
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if err := tx.QueryRow(ctx, `SELECT name FROM `+table+` WHERE id = $1`, id).Scan(&name); err != nil {
			return err
		}
		rows, err := tx.Query(ctx, `SELECT subject_id FROM acl WHERE resource_type = $1 AND resource_id = $2 AND subject_type = 'user'`, rtype, id)
		if err != nil {
			return err
		}
		for rows.Next() {
			var uid int64
			rows.Scan(&uid)
			before = append(before, uid)
		}
		rows.Close()
		if _, err := tx.Exec(ctx, `UPDATE `+table+` SET visibility = $2 WHERE id = $1`, id, in.Visibility); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `DELETE FROM acl WHERE resource_type = $1 AND resource_id = $2`, rtype, id); err != nil {
			return err
		}
		_, err = tx.Exec(ctx, `INSERT INTO acl (resource_type, resource_id, subject_type, subject_id, level)
			SELECT $1, $2, x.t, x.i, x.l FROM unnest($3::text[], $4::bigint[], $5::int[]) AS x(t, i, l) ON CONFLICT DO NOTHING`, rtype, id, types, ids, lvls)
		return err
	})
	if err != nil {
		return err
	}
	had := map[int64]bool{}
	for _, b := range before {
		had[b] = true
	}
	var added []int64
	for i, t := range types {
		if t == "user" && !had[ids[i]] && ids[i] != c.U.ID {
			added = append(added, ids[i])
		}
	}
	s.notify(ctx, added, "access", "Вам открыт доступ к "+label+" «"+name+"»", "", link)
	s.audit(c, "acl.update", rtype, id, map[string]any{"visibility": in.Visibility, "entries": len(types)})
	return c.OK()
}
