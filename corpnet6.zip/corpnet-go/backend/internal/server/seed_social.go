package server

import "strconv"

// seedSocial — демо-реакции (юникод и анимированные стикеры), закладки и упоминания @. Всё set-based, без N+1.
// Вызывается из seedDemo после остальных блоков; ссылается только на таблицы миграций 001–009.
func (s *Server) seedSocial(d sd, uid []int64) {
	if len(uid) < 4 {
		return
	}
	// реакции на новости: разные эмодзи у разных людей (детерминированно)
	d.exec(`INSERT INTO reactions (entity_type, entity_id, user_id, emoji, created_at)
		SELECT 'news', n.id, u.id, (ARRAY['👍','❤️','🎉',':applause:','👏',':fire:','💡',':rocket:'])[1 + (n.id + u.id) % 8], now() - interval '1 hour' * ((n.id * 7 + u.id) % 48)
		FROM (SELECT id FROM news ORDER BY id DESC LIMIT 12) n JOIN users u ON (u.id * 3 + n.id) % 4 = 0 AND NOT u.blocked
		ON CONFLICT DO NOTHING`)
	d.exec(`UPDATE news n SET likes_count = (SELECT count(*) FROM reactions r WHERE r.entity_type = 'news' AND r.entity_id = n.id AND r.emoji = '👍')
		WHERE n.id IN (SELECT entity_id FROM reactions WHERE entity_type = 'news')`)
	// реакции на комментарии, посты групп и сообщения
	d.exec(`INSERT INTO reactions (entity_type, entity_id, user_id, emoji)
		SELECT 'comment', c.id, u.id, (ARRAY['👍','😂',':heart:','🙏'])[1 + (c.id + u.id) % 4]
		FROM (SELECT id FROM comments WHERE deleted_at IS NULL ORDER BY id LIMIT 20) c JOIN users u ON (u.id + c.id) % 5 = 0 AND NOT u.blocked ON CONFLICT DO NOTHING`)
	d.exec(`INSERT INTO reactions (entity_type, entity_id, user_id, emoji)
		SELECT 'post', p.id, u.id, (ARRAY['👍','🎉',':hooray:'])[1 + (p.id + u.id) % 3]
		FROM (SELECT id FROM group_posts ORDER BY id LIMIT 10) p JOIN users u ON (u.id + p.id) % 4 = 0 AND NOT u.blocked ON CONFLICT DO NOTHING`)
	d.exec(`UPDATE group_posts p SET likes_count = (SELECT count(*) FROM reactions r WHERE r.entity_type = 'post' AND r.entity_id = p.id AND r.emoji = '👍')
		WHERE p.id IN (SELECT entity_id FROM reactions WHERE entity_type = 'post')`)
	d.exec(`INSERT INTO reactions (entity_type, entity_id, user_id, emoji)
		SELECT 'message', m.id, cm.user_id, (ARRAY['👍','✅','😊'])[1 + (m.id + cm.user_id) % 3]
		FROM (SELECT id, chat_id FROM messages WHERE deleted_at IS NULL ORDER BY id LIMIT 15) m JOIN chat_members cm ON cm.chat_id = m.chat_id AND (cm.user_id + m.id) % 2 = 0 ON CONFLICT DO NOTHING`)

	// закладки первого сотрудника и администратора: новости, идеи, публикации
	for _, u := range []int64{uid[0], uid[2]} {
		d.exec(`INSERT INTO bookmarks (user_id, entity_type, entity_id, created_at, note) SELECT $1, 'news', id, now() - interval '1 hour' * id, '' FROM (SELECT id FROM news ORDER BY id DESC LIMIT 4) x ON CONFLICT DO NOTHING`, u)
		d.exec(`INSERT INTO bookmarks (user_id, entity_type, entity_id, note) SELECT $1, 'idea', id, 'Вернуться к обсуждению' FROM (SELECT id FROM ideas ORDER BY id LIMIT 2) x ON CONFLICT DO NOTHING`, u)
		d.exec(`INSERT INTO bookmarks (user_id, entity_type, entity_id) SELECT $1, 'post', p.id FROM group_posts p JOIN user_groups g ON g.id = p.group_id
			WHERE g.visibility = 'public' ORDER BY p.id LIMIT 2 ON CONFLICT DO NOTHING`, u)
	}

	// упоминание: комментарий к новости с @логином администратора и уведомление со ссылкой-якорем
	var nid, cid int64
	var login string
	if d.tx.QueryRow(d.ctx, `SELECT login FROM users WHERE id = $1`, uid[0]).Scan(&login) != nil {
		return
	}
	if d.tx.QueryRow(d.ctx, `SELECT c.entity_id, c.id FROM comments c WHERE c.entity_type = 'news' AND c.deleted_at IS NULL AND c.user_id <> $1 ORDER BY c.id LIMIT 1`, uid[0]).Scan(&nid, &cid) != nil {
		return
	}
	body := "@" + login + ", посмотрите, пожалуйста, этот материал — нужен ваш комментарий."
	d.exec(`UPDATE comments SET body = body || E'\n' || $2::text WHERE id = $1`, cid, body)
	d.exec(`INSERT INTO mentions (entity_type, entity_id, user_id) VALUES ('comment', $1, $2) ON CONFLICT DO NOTHING`, cid, uid[0])
	d.exec(`INSERT INTO notifications (user_id, kind, title, body, link, created_at) VALUES ($1, 'mention', 'Коллега упомянул(а) вас в комментарии', $2, $3, now() - interval '30 minutes')`,
		uid[0], body, "/news/"+strconv.FormatInt(nid, 10)+"#comment-"+strconv.FormatInt(cid, 10))
}
