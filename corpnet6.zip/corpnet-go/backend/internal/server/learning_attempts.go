package server

import (
	"context"
	"crypto/sha1"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"math/rand"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
)

// ---------------------------------------------------------------- вопросы и проверка

type lq struct {
	ID          int64    `json:"id"`
	Type        string   `json:"type"`
	Text        string   `json:"text"`
	FileID      *int64   `json:"file_id,omitempty"`
	Options     []qOpt   `json:"options,omitempty"`
	Answers     []string `json:"answers,omitempty"`
	Pairs       []qPair  `json:"pairs,omitempty"`
	Items       []qItem  `json:"items,omitempty"`
	Weight      float64  `json:"weight"`
	Explanation string   `json:"explanation,omitempty"`
}

type qres struct {
	P float64 `json:"p"` // набрано баллов
	M float64 `json:"m"` // максимум
	S int     `json:"s"` // 2 верно, 1 частично, 0 неверно, -1 нет ответа
}

type lattempt struct {
	ID, TestID, UserID int64
	DeptID             *int64
	No                 int
	Seed               int64
	StartedAt          time.Time
	Deadline           *time.Time
	FinishedAt         *time.Time
	Expired            bool
	Answers            json.RawMessage
	Details            json.RawMessage
	Score, MaxScore    *float64
	Percent            *float64
	Passed             *bool
	Duration           *int
	VersionID          *int64  // снимок вопросов (nil у старых попыток)
	QIDs               []int64 // вопросы попытки в порядке показа
	CourseID, StepID   *int64  // попытка запущена из шага курса
}

const attemptCols = `id, test_id, user_id, dept_id, no, seed, started_at, deadline, finished_at, expired, answers, details, score::float8, max_score::float8, percent::float8, passed, duration_sec,
	version_id, qids, course_id, step_id`

func (s *Server) learnLoadAttempt(ctx context.Context, q interface {
	QueryRow(context.Context, string, ...any) pgx.Row
}, id int64, lock bool) (*lattempt, error) {
	var a lattempt
	sql := `SELECT ` + attemptCols + ` FROM learn_attempts WHERE id = $1`
	if lock {
		sql += ` FOR UPDATE`
	}
	err := q.QueryRow(ctx, sql, id).Scan(&a.ID, &a.TestID, &a.UserID, &a.DeptID, &a.No, &a.Seed, &a.StartedAt, &a.Deadline, &a.FinishedAt, &a.Expired,
		&a.Answers, &a.Details, &a.Score, &a.MaxScore, &a.Percent, &a.Passed, &a.Duration, &a.VersionID, &a.QIDs, &a.CourseID, &a.StepID)
	return &a, err
}

func (s *Server) learnLoadQuestions(ctx context.Context, test int64) ([]lq, error) {
	rows, err := s.db.Query(ctx, `SELECT id, type, text, file_id, data, weight::float8, explanation FROM learn_questions WHERE test_id = $1 ORDER BY sort, id`, test)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []lq
	for rows.Next() {
		var q lq
		var data []byte
		if err := rows.Scan(&q.ID, &q.Type, &q.Text, &q.FileID, &data, &q.Weight, &q.Explanation); err != nil {
			return nil, err
		}
		var d struct {
			Options []qOpt   `json:"options"`
			Answers []string `json:"answers"`
			Pairs   []qPair  `json:"pairs"`
			Items   []qItem  `json:"items"`
		}
		json.Unmarshal(data, &d)
		q.Options, q.Answers, q.Pairs, q.Items = d.Options, d.Answers, d.Pairs, d.Items
		out = append(out, q)
	}
	return out, rows.Err()
}

// normText: регистр, «ё/е» и лишние пробелы не важны.
func normText(s string) string {
	s = strings.ToLower(strings.TrimSpace(s))
	s = strings.ReplaceAll(s, "ё", "е")
	return strings.Join(strings.Fields(s), " ")
}

func parseNum(s string) (float64, bool) {
	s = strings.ReplaceAll(strings.ReplaceAll(strings.TrimSpace(s), " ", ""), ",", ".")
	if s == "" {
		return 0, false
	}
	f, err := strconv.ParseFloat(s, 64)
	return f, err == nil && !math.IsNaN(f) && !math.IsInf(f, 0)
}

func textMatches(given string, accepted []string) bool {
	g := normText(given)
	if g == "" {
		return false
	}
	gn, gok := parseNum(given)
	for _, a := range accepted {
		if normText(a) == g {
			return true
		}
		if an, ok := parseNum(a); ok && gok && math.Abs(an-gn) < 1e-9 {
			return true
		}
	}
	return false
}

func round2(v float64) float64 { return math.Round(v*100) / 100 }

func ansIDs(raw json.RawMessage) (ids []int, ok bool) {
	if len(raw) == 0 {
		return nil, false
	}
	var arr []float64
	if json.Unmarshal(raw, &arr) == nil {
		for _, f := range arr {
			ids = append(ids, int(f))
		}
		return ids, len(ids) > 0
	}
	var one float64
	if json.Unmarshal(raw, &one) == nil {
		return []int{int(one)}, true
	}
	return nil, false
}

func scoreQuestion(t *ltest, q lq, raw json.RawMessage) qres {
	r := qres{M: q.Weight, S: -1}
	switch q.Type {
	case "single", "multiple":
		sel, ok := ansIDs(raw)
		if !ok {
			return r
		}
		cor := map[int]bool{}
		for _, o := range q.Options {
			if o.Correct {
				cor[o.ID] = true
			}
		}
		right, wrong := 0, 0
		seen := map[int]bool{}
		for _, id := range sel {
			if seen[id] {
				continue
			}
			seen[id] = true
			if cor[id] {
				right++
			} else {
				wrong++
			}
		}
		switch {
		case wrong == 0 && right == len(cor):
			r.P, r.S = q.Weight, 2
		case q.Type == "multiple" && t.PartialCredit && right > wrong:
			r.P, r.S = q.Weight*float64(right-wrong)/float64(len(cor)), 1
		default:
			r.S = 0
		}
	case "text":
		var s string
		if json.Unmarshal(raw, &s) != nil || strings.TrimSpace(s) == "" {
			return r
		}
		if textMatches(s, q.Answers) {
			r.P, r.S = q.Weight, 2
		} else {
			r.S = 0
		}
	case "matching":
		var m map[string]float64
		if json.Unmarshal(raw, &m) != nil || len(m) == 0 {
			return r
		}
		right := 0
		for _, p := range q.Pairs {
			if v, ok := m[strconv.Itoa(p.ID)]; ok && int(v) == p.ID {
				right++
			}
		}
		r.P, r.S = partialScore(t, q.Weight, right, len(q.Pairs))
	case "ordering":
		var ids []float64
		if json.Unmarshal(raw, &ids) != nil || len(ids) == 0 {
			return r
		}
		right := 0
		for i, it := range q.Items {
			if i < len(ids) && int(ids[i]) == it.ID {
				right++
			}
		}
		if len(ids) != len(q.Items) {
			right = 0
		}
		r.P, r.S = partialScore(t, q.Weight, right, len(q.Items))
	}
	r.P = round2(r.P)
	return r
}

// partialScore: все верно — полный балл; иначе пропорционально (если включены частичные баллы) или ноль.
func partialScore(t *ltest, w float64, right, total int) (float64, int) {
	switch {
	case total > 0 && right == total:
		return w, 2
	case t.PartialCredit && right > 0:
		return w * float64(right) / float64(total), 1
	}
	return 0, 0
}

// ---------------------------------------------------------------- порядок вопросов

// pickQuestions выбирает вопросы попытки: случайные N из M (пул) в исходном порядке, затем перемешивание, если оно включено.
func pickQuestions(t *ltest, seed int64, qs []lq) []lq {
	out := append([]lq(nil), qs...)
	r := rand.New(rand.NewSource(seed))
	if t.PoolSize != nil && *t.PoolSize < len(out) {
		idx := r.Perm(len(out))[:*t.PoolSize]
		sort.Ints(idx)
		sel := make([]lq, 0, len(idx))
		for _, i := range idx {
			sel = append(sel, out[i])
		}
		out = sel
	}
	if t.ShuffleQuestions {
		r.Shuffle(len(out), func(i, j int) { out[i], out[j] = out[j], out[i] })
	}
	return out
}

// learnVersion сохраняет набор вопросов теста как версию (одинаковое содержимое — одна запись) и возвращает её id.
func (s *Server) learnVersion(ctx context.Context, test int64, qs []lq) (int64, error) {
	b, _ := json.Marshal(qs)
	sum := sha1.Sum(b)
	var id int64
	err := s.db.QueryRow(ctx, `INSERT INTO learn_test_versions (test_id, hash, questions) VALUES ($1, $2, $3::jsonb)
		ON CONFLICT (test_id, hash) DO UPDATE SET hash = EXCLUDED.hash RETURNING id`, test, hex.EncodeToString(sum[:]), string(b)).Scan(&id)
	return id, err
}

// learnAttemptQs — вопросы попытки в порядке показа: из снимка (новые попытки) или из теста (старые).
func (s *Server) learnAttemptQs(ctx context.Context, t *ltest, a *lattempt) ([]lq, error) {
	if a.VersionID == nil {
		qs, err := s.learnLoadQuestions(ctx, a.TestID)
		if err != nil {
			return nil, err
		}
		return orderQuestions(t, a.Seed, qs), nil
	}
	var raw []byte
	if err := s.db.QueryRow(ctx, `SELECT questions FROM learn_test_versions WHERE id = $1`, *a.VersionID).Scan(&raw); err != nil {
		return nil, err
	}
	var all []lq
	if err := json.Unmarshal(raw, &all); err != nil {
		return nil, err
	}
	byID := make(map[int64]lq, len(all))
	for _, q := range all {
		byID[q.ID] = q
	}
	out := make([]lq, 0, len(a.QIDs))
	for _, id := range a.QIDs {
		if q, ok := byID[id]; ok {
			out = append(out, q)
		}
	}
	if t.ShuffleAnswers {
		for i := range out {
			if len(out[i].Options) > 1 {
				o := append([]qOpt(nil), out[i].Options...)
				rand.New(rand.NewSource(a.Seed*31+out[i].ID)).Shuffle(len(o), func(x, y int) { o[x], o[y] = o[y], o[x] })
				out[i].Options = o
			}
		}
	}
	return out, nil
}

// shuffledItems — элементы упорядочивания в случайном (по seed) порядке, не совпадающем с правильным.
func shuffledItems(seed int64, qid int64, items []qItem) []qItem {
	o := append([]qItem(nil), items...)
	rand.New(rand.NewSource(seed*17+qid)).Shuffle(len(o), func(a, b int) { o[a], o[b] = o[b], o[a] })
	same := len(o) > 1
	for i := range o {
		if o[i].ID != items[i].ID {
			same = false
		}
	}
	if same {
		o[0], o[len(o)-1] = o[len(o)-1], o[0]
	}
	return o
}

func shuffledRights(seed int64, qid int64, pairs []qPair) []qPair {
	o := append([]qPair(nil), pairs...)
	rand.New(rand.NewSource(seed*13+qid)).Shuffle(len(o), func(a, b int) { o[a], o[b] = o[b], o[a] })
	return o
}

func orderQuestions(t *ltest, seed int64, qs []lq) []lq {
	out := make([]lq, len(qs))
	copy(out, qs)
	if t.ShuffleQuestions {
		rand.New(rand.NewSource(seed)).Shuffle(len(out), func(i, j int) { out[i], out[j] = out[j], out[i] })
	}
	if t.ShuffleAnswers {
		for i := range out {
			if len(out[i].Options) > 1 {
				o := make([]qOpt, len(out[i].Options))
				copy(o, out[i].Options)
				rand.New(rand.NewSource(seed*31+out[i].ID)).Shuffle(len(o), func(a, b int) { o[a], o[b] = o[b], o[a] })
				out[i].Options = o
			}
		}
	}
	return out
}

// ---------------------------------------------------------------- старт / возобновление

func (s *Server) learnAttemptStart(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	t, lvl, err := s.learnTestAccess(c, id, lvView)
	if err != nil {
		return err
	}
	ctx := c.Context()
	// запуск из шага курса: проверяем доступность шага и берём лимит попыток курса
	var stepID, courseID int64
	var cycleFrom time.Time
	if stepID = c.QInt64("step"); stepID > 0 {
		var maxAtt *int
		if courseID, maxAtt, cycleFrom, err = s.lmsStepContext(c, id, stepID); err != nil {
			return err
		}
		if maxAtt != nil {
			t.MaxAttempts = maxAtt
		}
	}
	s.learnExpireOpen(ctx, id, c.U.ID)
	open := func() (int64, error) {
		var aid int64
		err := s.db.QueryRow(ctx, `SELECT id FROM learn_attempts WHERE test_id = $1 AND user_id = $2 AND finished_at IS NULL`, id, c.U.ID).Scan(&aid)
		return aid, err
	}
	if aid, err := open(); err == nil {
		if stepID > 0 {
			s.db.Exec(ctx, `UPDATE learn_attempts SET course_id = $2, step_id = $3 WHERE id = $1 AND step_id IS NULL`, aid, courseID, stepID)
		}
		return s.learnAttemptRun(c, aid)
	} else if !errors.Is(err, pgx.ErrNoRows) {
		return err
	}
	var no, used int
	if err := s.db.QueryRow(ctx, `SELECT coalesce(max(no), 0) FROM learn_attempts WHERE test_id = $1 AND user_id = $2`, id, c.U.ID).Scan(&no); err != nil {
		return err
	}
	used = no
	if stepID > 0 { // попытки внутри курса считаются отдельно (и в рамках текущего цикла прохождения)
		if err := s.db.QueryRow(ctx, `SELECT count(*) FROM learn_attempts WHERE user_id = $1 AND step_id = $2 AND started_at >= $3`, c.U.ID, stepID, cycleFrom).Scan(&used); err != nil {
			return err
		}
	}
	now := time.Now()
	if ok, reason := t.startCheck(lvl, used, now); !ok {
		return conflict(reason)
	}
	var deadline *time.Time
	if t.TimeLimitMin != nil {
		d := now.Add(time.Duration(*t.TimeLimitMin) * time.Minute)
		deadline = &d
	}
	var dept *int64
	if c.U.Dept > 0 {
		dept = &c.U.Dept
	}
	qs, err := s.learnLoadQuestions(ctx, id)
	if err != nil {
		return err
	}
	seed := rand.Int63()
	sel := pickQuestions(t, seed, qs)
	qids := make([]int64, 0, len(sel))
	for _, q := range sel {
		qids = append(qids, q.ID)
	}
	vid, err := s.learnVersion(ctx, id, qs)
	if err != nil {
		return err
	}
	var cp, sp any
	if stepID > 0 {
		cp, sp = courseID, stepID
	}
	var aid int64
	err = s.db.QueryRow(ctx, `INSERT INTO learn_attempts (test_id, user_id, dept_id, no, seed, started_at, deadline, version_id, qids, course_id, step_id)
		VALUES ($1::bigint, $2::bigint, $3::bigint, $4::int, $5::bigint, $6::timestamptz, $7::timestamptz, $8::bigint, $9::bigint[], $10::bigint, $11::bigint) RETURNING id`,
		id, c.U.ID, dept, no+1, seed, now, deadline, vid, qids, cp, sp).Scan(&aid)
	var pe *pgconn.PgError
	if errors.As(err, &pe) && pe.Code == "23505" { // параллельный старт: берём уже созданную попытку
		if aid, err = open(); err != nil {
			return conflict("Не удалось начать попытку, повторите")
		}
	} else if err != nil {
		return err
	}
	s.lmsOnAttemptStart(ctx, c.U, id, courseID, stepID)
	return s.learnAttemptRun(c, aid)
}

type optOut struct {
	ID   int    `json:"id"`
	Text string `json:"text"`
}

type qOut struct {
	ID      int64    `json:"id"`
	Type    string   `json:"type"`
	Text    string   `json:"text"`
	FileID  *int64   `json:"file_id"`
	Weight  float64  `json:"weight"`
	Options []optOut `json:"options,omitempty"`
	Left    []optOut `json:"left,omitempty"`  // matching: элементы слева
	Right   []optOut `json:"right,omitempty"` // matching: варианты справа (перемешаны)
	Items   []optOut `json:"items,omitempty"` // ordering: элементы (перемешаны)
}

// learnAttemptRun отдаёт клиенту всё для прохождения: вопросы без правильных ответов и сохранённые ответы.
func (s *Server) learnAttemptRun(c *Ctx, aid int64) error {
	ctx := c.Context()
	a, err := s.learnLoadAttempt(ctx, s.db, aid, false)
	if err != nil {
		return err
	}
	t, err := s.learnLoadTest(ctx, a.TestID)
	if err != nil {
		return err
	}
	ord, err := s.learnAttemptQs(ctx, t, a)
	if err != nil {
		return err
	}
	out := make([]qOut, 0, len(ord))
	for _, q := range ord {
		o := qOut{ID: q.ID, Type: q.Type, Text: q.Text, FileID: q.FileID, Weight: q.Weight}
		for _, x := range q.Options {
			o.Options = append(o.Options, optOut{x.ID, x.Text})
		}
		for _, p := range q.Pairs {
			o.Left = append(o.Left, optOut{p.ID, p.Left})
		}
		for _, p := range shuffledRights(a.Seed, q.ID, q.Pairs) {
			o.Right = append(o.Right, optOut{p.ID, p.Right})
		}
		if q.Type == "ordering" {
			for _, it := range shuffledItems(a.Seed, q.ID, q.Items) {
				o.Items = append(o.Items, optOut{it.ID, it.Text})
			}
		}
		out = append(out, o)
	}
	return c.JSON(200, map[string]any{
		"state":     "running",
		"test":      map[string]any{"id": t.ID, "title": t.Title, "description": t.Description, "pass_percent": t.PassPercent, "time_limit_min": t.TimeLimitMin, "folder_id": t.FolderID},
		"attempt":   map[string]any{"id": a.ID, "no": a.No, "started_at": a.StartedAt, "deadline": a.Deadline, "course_id": a.CourseID, "step_id": a.StepID},
		"questions": out, "answers": a.Answers, "server_now": time.Now(),
	})
}

// ---------------------------------------------------------------- автосохранение

func cleanAnswers(in map[string]any) (map[string]any, error) {
	if len(in) > 600 {
		return nil, badReq("Слишком много ответов")
	}
	out := map[string]any{}
	for k, v := range in {
		if id, err := strconv.ParseInt(k, 10, 64); err != nil || id <= 0 {
			continue
		}
		switch x := v.(type) {
		case nil:
			out[k] = nil
		case float64:
			out[k] = int(x)
		case string:
			r := []rune(x)
			if len(r) > 1000 {
				x = string(r[:1000])
			}
			out[k] = x
		case []any:
			ids := []int{}
			for _, e := range x {
				if f, ok := e.(float64); ok && len(ids) < 30 {
					ids = append(ids, int(f))
				}
			}
			out[k] = ids
		case map[string]any: // matching: {"<id пары>": <id выбранного варианта>}
			m := map[string]int{}
			for k2, v2 := range x {
				if f, ok := v2.(float64); ok && len(m) < 30 {
					m[k2] = int(f)
				}
			}
			out[k] = m
		}
	}
	return out, nil
}

func (s *Server) learnAttemptSave(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Answers map[string]any `json:"answers"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	ans, err := cleanAnswers(in.Answers)
	if err != nil {
		return err
	}
	b, _ := json.Marshal(ans)
	tag, err := s.db.Exec(c.Context(), `UPDATE learn_attempts SET answers = jsonb_strip_nulls(answers || $2::jsonb)
		WHERE id = $1 AND user_id = $3 AND finished_at IS NULL AND (deadline IS NULL OR deadline + interval '10 seconds' > now())`, id, string(b), c.U.ID)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		var own bool
		if err := s.db.QueryRow(c.Context(), `SELECT user_id = $2 FROM learn_attempts WHERE id = $1`, id, c.U.ID).Scan(&own); err != nil || !own {
			return errNotFound
		}
		return conflict("Попытка уже завершена или время вышло")
	}
	return c.OK()
}

// ---------------------------------------------------------------- завершение и подсчёт

// learnFinish завершает попытку и считает результат (всегда на сервере). Повторный вызов возвращает уже готовую попытку.
func (s *Server) learnFinish(ctx context.Context, aid int64, merge map[string]any, byTimeout bool) (*lattempt, error) {
	var res *lattempt
	var fresh bool
	var tst *ltest
	err := s.tx(ctx, func(tx pgx.Tx) error {
		a, err := s.learnLoadAttempt(ctx, tx, aid, true)
		if err != nil {
			return err
		}
		if a.FinishedAt != nil {
			res = a
			return nil
		}
		t, err := s.learnLoadTest(ctx, a.TestID)
		if err != nil {
			return err
		}
		qs, err := s.learnAttemptQs(ctx, t, a)
		if err != nil {
			return err
		}
		pass := t.PassPercent
		if a.StepID != nil { // внутри курса порог берётся из шага/курса
			if err := tx.QueryRow(ctx, `SELECT coalesce(st.pass_percent, c.pass_percent) FROM learn_course_steps st JOIN learn_courses c ON c.id = st.course_id WHERE st.id = $1`, *a.StepID).Scan(&pass); err != nil && !errors.Is(err, pgx.ErrNoRows) {
				return err
			}
		}
		now := time.Now()
		fin := now
		expired := byTimeout
		if a.Deadline != nil && now.After(a.Deadline.Add(10*time.Second)) {
			expired = true
		}
		if expired && a.Deadline != nil {
			fin = *a.Deadline
			merge = nil // после дедлайна новые ответы не принимаются
		}
		answers := map[string]json.RawMessage{}
		json.Unmarshal(a.Answers, &answers)
		for k, v := range merge {
			if v == nil {
				delete(answers, k)
				continue
			}
			b, _ := json.Marshal(v)
			answers[k] = b
		}
		details := map[string]qres{}
		var score, max float64
		for _, q := range qs {
			r := scoreQuestion(t, q, answers[strconv.FormatInt(q.ID, 10)])
			details[strconv.FormatInt(q.ID, 10)] = r
			score += r.P
			max += r.M
		}
		score, max = round2(score), round2(max)
		pct := 0.0
		if max > 0 {
			pct = math.Round(score/max*1000) / 10
		}
		passed := max > 0 && pct >= float64(pass)
		dur := int(fin.Sub(a.StartedAt).Seconds())
		if dur < 0 {
			dur = 0
		}
		ab, _ := json.Marshal(answers)
		db, _ := json.Marshal(details)
		if _, err := tx.Exec(ctx, `UPDATE learn_attempts SET finished_at = $2, expired = $3, answers = $4::jsonb, details = $5::jsonb, score = $6, max_score = $7, percent = $8, passed = $9, duration_sec = $10 WHERE id = $1`,
			aid, fin, expired, string(ab), string(db), score, max, pct, passed, dur); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE learn_tests SET attempts_count = attempts_count + 1, passed_count = passed_count + $2, sum_percent = sum_percent + $3 WHERE id = $1`,
			a.TestID, map[bool]int{true: 1, false: 0}[passed], pct); err != nil {
			return err
		}
		a.FinishedAt, a.Expired, a.Score, a.MaxScore, a.Percent, a.Passed, a.Duration = &fin, expired, &score, &max, &pct, &passed, &dur
		a.Answers, a.Details = ab, db
		res, fresh, tst = a, true, t
		return nil
	})
	if err == nil && fresh {
		s.lmsAfterAttempt(ctx, res, tst)
	}
	return res, err
}

func (s *Server) learnAttemptFinish(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Answers map[string]any `json:"answers"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	var owner int64
	if err := s.db.QueryRow(c.Context(), `SELECT user_id FROM learn_attempts WHERE id = $1`, id).Scan(&owner); err != nil {
		return err
	}
	if owner != c.U.ID {
		return errForbidden
	}
	ans, err := cleanAnswers(in.Answers)
	if err != nil {
		return err
	}
	if _, err := s.learnFinish(c.Context(), id, ans, false); err != nil {
		return err
	}
	return s.learnAttemptResult(c, id)
}

// learnExpireOpen завершает по таймеру просроченные попытки пользователя в тесте.
func (s *Server) learnExpireOpen(ctx context.Context, test, user int64) {
	rows, err := s.db.Query(ctx, `SELECT id FROM learn_attempts WHERE test_id = $1 AND user_id = $2 AND finished_at IS NULL AND deadline IS NOT NULL AND deadline < now()`, test, user)
	if err == nil {
		s.learnExpireRows(ctx, rows)
	}
}

func (s *Server) learnExpireRows(ctx context.Context, rows pgx.Rows) {
	var ids []int64
	for rows.Next() {
		var id int64
		rows.Scan(&id)
		ids = append(ids, id)
	}
	rows.Close()
	for _, id := range ids {
		if _, err := s.learnFinish(ctx, id, nil, true); err != nil {
			s.log.Warn("learn expire", "attempt", id, "err", err)
		}
	}
}

// learnSweeper раз в минуту закрывает попытки, у которых вышло время, а пользователь не вернулся.
func (s *Server) learnSweeper() {
	t := time.NewTicker(time.Minute)
	defer t.Stop()
	for range t.C {
		ctx, cancel := context.WithTimeout(context.Background(), 50*time.Second)
		if s.rdb.SetNX(ctx, "lock:learn-sweep", s.cfg.InstanceID, 50*time.Second).Val() {
			rows, err := s.db.Query(ctx, `SELECT id FROM learn_attempts WHERE finished_at IS NULL AND deadline IS NOT NULL AND deadline < now() - interval '15 seconds' ORDER BY deadline LIMIT 200`)
			if err == nil {
				s.learnExpireRows(ctx, rows)
			}
		}
		cancel()
	}
}

// ---------------------------------------------------------------- просмотр попытки / результат

func (s *Server) learnAttemptGet(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	var owner int64
	var finished bool
	var dl *time.Time
	if err := s.db.QueryRow(ctx, `SELECT user_id, finished_at IS NOT NULL, deadline FROM learn_attempts WHERE id = $1`, id).Scan(&owner, &finished, &dl); err != nil {
		return err
	}
	if owner == c.U.ID && !finished {
		if dl != nil && time.Now().After(*dl) {
			if _, err := s.learnFinish(ctx, id, nil, true); err != nil {
				return err
			}
			return s.learnAttemptResult(c, id)
		}
		return s.learnAttemptRun(c, id)
	}
	return s.learnAttemptResult(c, id)
}

func (s *Server) learnAttemptResult(c *Ctx, aid int64) error {
	ctx := c.Context()
	a, err := s.learnLoadAttempt(ctx, s.db, aid, false)
	if err != nil {
		return err
	}
	t, err := s.learnLoadTest(ctx, a.TestID)
	if err != nil {
		return err
	}
	var lvl int
	if err := s.db.QueryRow(ctx, `SELECT learn_level($1, $2, $3, $4)`, t.FolderID, c.U.ID, c.U.Dept, c.U.IsAdmin()).Scan(&lvl); err != nil {
		return err
	}
	mine := a.UserID == c.U.ID
	if !mine && lvl < lvEdit {
		return errForbidden
	}
	var used int
	s.db.QueryRow(ctx, `SELECT coalesce(max(no), 0) FROM learn_attempts WHERE test_id = $1 AND user_id = $2`, a.TestID, a.UserID).Scan(&used)
	now := time.Now()
	exhausted := (t.MaxAttempts != nil && used >= *t.MaxAttempts) || (t.AvailableTo != nil && now.After(*t.AvailableTo))
	show := lvl >= lvEdit || t.ShowAnswers == "after_attempt" || (t.ShowAnswers == "after_finish" && exhausted)
	canRetry, _ := t.startCheck(lvl, used, now)
	if !mine {
		canRetry = false
	}
	out := map[string]any{
		"state": "finished",
		"test":  map[string]any{"id": t.ID, "title": t.Title, "pass_percent": t.PassPercent, "show_answers": t.ShowAnswers, "folder_id": t.FolderID, "time_limit_min": t.TimeLimitMin},
		"attempt": map[string]any{"id": a.ID, "no": a.No, "started_at": a.StartedAt, "finished_at": a.FinishedAt, "expired": a.Expired, "score": a.Score, "max_score": a.MaxScore,
			"percent": a.Percent, "passed": a.Passed, "duration_sec": a.Duration, "user_id": a.UserID, "course_id": a.CourseID, "step_id": a.StepID},
		"can_retry": canRetry, "answers_hidden": !show, "level": lvl,
	}
	if t.MaxAttempts != nil {
		out["attempts_left"] = max(*t.MaxAttempts-used, 0)
	}
	if a.FinishedAt == nil { // чужая незавершённая попытка (вид менеджера)
		out["state"] = "open"
		return c.JSON(200, out)
	}
	if !mine {
		u, err := s.one(ctx, `SELECT u.id, u.full_name AS name, u.login, d.name AS department FROM users u LEFT JOIN departments d ON d.id = u.department_id WHERE u.id = $1`, a.UserID)
		if err == nil {
			out["user"] = u
		}
	}
	if show {
		qs, err := s.learnAttemptQs(ctx, t, a)
		if err != nil {
			return err
		}
		answers := map[string]json.RawMessage{}
		json.Unmarshal(a.Answers, &answers)
		details := map[string]qres{}
		json.Unmarshal(a.Details, &details)
		byID := map[int64]lq{}
		for _, q := range qs {
			byID[q.ID] = q
		}
		review := []map[string]any{}
		for _, q := range qs {
			k := strconv.FormatInt(q.ID, 10)
			r, ok := details[k]
			if !ok {
				r = scoreQuestion(t, q, answers[k])
			}
			item := map[string]any{"id": q.ID, "type": q.Type, "text": q.Text, "file_id": q.FileID, "weight": q.Weight, "explanation": q.Explanation, "points": r.P, "status": r.S}
			switch q.Type {
			case "text":
				var my string
				json.Unmarshal(answers[k], &my)
				item["my"], item["answers"] = my, q.Answers
			case "matching":
				var my map[string]float64
				json.Unmarshal(answers[k], &my)
				text := map[int]string{}
				for _, p := range q.Pairs {
					text[p.ID] = p.Right
				}
				rows := []map[string]any{}
				for _, p := range q.Pairs {
					row := map[string]any{"left": p.Left, "right": p.Right, "my": nil, "ok": false}
					if v, ok := my[strconv.Itoa(p.ID)]; ok {
						row["my"], row["ok"] = text[int(v)], int(v) == p.ID
					}
					rows = append(rows, row)
				}
				item["pairs"] = rows
			case "ordering":
				var my []float64
				json.Unmarshal(answers[k], &my)
				text := map[int]string{}
				for _, it := range q.Items {
					text[it.ID] = it.Text
				}
				mine := []string{}
				for _, id := range my {
					mine = append(mine, text[int(id)])
				}
				right := []string{}
				for _, it := range q.Items {
					right = append(right, it.Text)
				}
				item["my_order"], item["right_order"] = mine, right
			default:
				sel, _ := ansIDs(answers[k])
				set := map[int]bool{}
				for _, x := range sel {
					set[x] = true
				}
				opts := []map[string]any{}
				for _, o := range q.Options {
					opts = append(opts, map[string]any{"id": o.ID, "text": o.Text, "correct": o.Correct, "selected": set[o.ID]})
				}
				item["options"] = opts
			}
			review = append(review, item)
		}
		// вопросы, удалённые из теста после попытки
		for k, r := range details {
			if id, _ := strconv.ParseInt(k, 10, 64); id > 0 {
				if _, ok := byID[id]; !ok {
					review = append(review, map[string]any{"id": id, "deleted": true, "points": r.P, "weight": r.M, "status": r.S, "text": "Вопрос удалён из теста"})
				}
			}
		}
		out["review"] = review
	}
	return c.JSON(200, out)
}

// ---------------------------------------------------------------- моя история

func (s *Server) learnMyAttempts(c *Ctx) error {
	ctx := c.Context()
	page, per, off := c.Page(30, 100)
	s.learnExpireMine(ctx, c.U.ID)
	cond := ""
	switch c.Q("result") {
	case "passed":
		cond = " AND a.passed"
	case "failed":
		cond = " AND a.finished_at IS NOT NULL AND NOT a.passed"
	case "open":
		cond = " AND a.finished_at IS NULL"
	}
	b, err := s.arr(ctx, `SELECT a.id, a.test_id, t.title, t.folder_id, t.pass_percent, a.no, a.started_at, a.finished_at, a.score, a.max_score, a.percent, a.passed, a.duration_sec, a.expired, a.deadline
		FROM learn_attempts a JOIN learn_tests t ON t.id = a.test_id WHERE a.user_id = $1`+cond+` ORDER BY a.started_at DESC LIMIT $2 OFFSET $3`, c.U.ID, per+1, off)
	if err != nil {
		return err
	}
	var rows []json.RawMessage
	json.Unmarshal(b, &rows)
	more := len(rows) > per
	if more {
		rows = rows[:per]
	}
	if rows == nil {
		rows = []json.RawMessage{}
	}
	sum, err := s.one(ctx, `SELECT count(*) AS attempts, count(DISTINCT test_id) AS tests, count(DISTINCT test_id) FILTER (WHERE passed) AS tests_passed,
		coalesce(round(avg(percent), 1), 0) AS avg_percent FROM learn_attempts WHERE user_id = $1 AND finished_at IS NOT NULL`, c.U.ID)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"items": rows, "has_more": more, "page": page, "per": per, "summary": sum})
}

func (s *Server) learnExpireMine(ctx context.Context, user int64) {
	rows, err := s.db.Query(ctx, `SELECT id FROM learn_attempts WHERE user_id = $1 AND finished_at IS NULL AND deadline IS NOT NULL AND deadline < now()`, user)
	if err == nil {
		s.learnExpireRows(ctx, rows)
	}
}

// ---------------------------------------------------------------- результаты теста (редактор)

// learnAttemptConds собирает общие условия фильтра результатов: пользователь, подразделение, период, зачёт.
func learnAttemptConds(c *Ctx, args *[]any) []string {
	add := func(v any) string { *args = append(*args, v); return "$" + itoa(len(*args)) }
	conds := []string{}
	if q := strings.ToLower(c.Q("q")); q != "" {
		conds = append(conds, "u.search_text LIKE "+add("%"+likeEscape(q)+"%")+" ESCAPE '\\'")
	}
	if d := c.QInt64("dept"); d > 0 {
		conds = append(conds, "u.department_id IN "+deptSubtree(add(d)+"::bigint"))
	}
	if v := c.Q("from"); v != "" {
		if t, err := time.ParseInLocation("2006-01-02", v, msk()); err == nil {
			conds = append(conds, "a.finished_at >= "+add(t)+"::timestamptz")
		}
	}
	if v := c.Q("to"); v != "" {
		if t, err := time.ParseInLocation("2006-01-02", v, msk()); err == nil {
			conds = append(conds, "a.finished_at < "+add(t.AddDate(0, 0, 1))+"::timestamptz")
		}
	}
	switch c.Q("passed") {
	case "1":
		conds = append(conds, "a.passed")
	case "0":
		conds = append(conds, "NOT a.passed")
	}
	return conds
}

func (s *Server) learnTestAttempts(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, _, err = s.learnTestAccess(c, id, lvEdit); err != nil {
		return err
	}
	ctx := c.Context()
	rows, err := s.db.Query(ctx, `SELECT id FROM learn_attempts WHERE test_id = $1 AND finished_at IS NULL AND deadline IS NOT NULL AND deadline < now() LIMIT 100`, id)
	if err == nil {
		s.learnExpireRows(ctx, rows)
	}
	page, per, off := c.Page(30, 200)
	args := []any{id}
	conds := append([]string{"a.test_id = $1", "a.finished_at IS NOT NULL"}, learnAttemptConds(c, &args)...)
	from := `FROM learn_attempts a JOIN users u ON u.id = a.user_id LEFT JOIN departments d ON d.id = u.department_id WHERE ` + strings.Join(conds, " AND ")
	sel := `SELECT a.id, a.no, a.user_id, u.full_name AS user_name, u.login, u.department_id, d.name AS department, a.started_at, a.finished_at, a.score, a.max_score, a.percent, a.passed, a.duration_sec, a.expired `
	var q string
	if c.Q("best") == "1" {
		q = `SELECT * FROM (SELECT DISTINCT ON (a.user_id) ` + strings.TrimPrefix(sel, "SELECT ") + from + ` ORDER BY a.user_id, a.percent DESC, a.finished_at DESC) x ORDER BY finished_at DESC`
	} else {
		q = sel + from + ` ORDER BY a.finished_at DESC`
	}
	var total int
	cq := `SELECT count(*) ` + from
	if c.Q("best") == "1" {
		cq = `SELECT count(DISTINCT a.user_id) ` + from
	}
	if err := s.db.QueryRow(ctx, cq, args...).Scan(&total); err != nil {
		return err
	}
	b, err := s.arr(ctx, q+fmt.Sprintf(` LIMIT %d OFFSET %d`, per, off), args...)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"items": json.RawMessage(b), "total": total, "page": page, "per": per})
}

// ---------------------------------------------------------------- экспорт CSV

func (s *Server) loc() *time.Location {
	if s.cfg.TZ != "" {
		if l, err := time.LoadLocation(s.cfg.TZ); err == nil {
			return l
		}
	}
	return msk()
}

func csvCell(v string) string {
	if v != "" && strings.ContainsRune("=+-@\t\r", rune(v[0])) {
		return "'" + v
	}
	return v
}

func fnum(v *float64) string {
	if v == nil {
		return ""
	}
	return strings.Replace(strconv.FormatFloat(*v, 'f', -1, 64), ".", ",", 1)
}

func (s *Server) learnTestPaths(ctx context.Context) (map[int64]string, error) {
	rows, err := s.db.Query(ctx, `SELECT id, parent_id, name FROM learn_folders WHERE kind = 'tests'`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	type fn struct {
		parent *int64
		name   string
	}
	all := map[int64]fn{}
	for rows.Next() {
		var id int64
		var f fn
		rows.Scan(&id, &f.parent, &f.name)
		all[id] = f
	}
	paths := map[int64]string{}
	for id := range all {
		var parts []string
		for cur, n := &id, 0; cur != nil && n < 50; n++ {
			f, ok := all[*cur]
			if !ok {
				break
			}
			parts = append([]string{f.name}, parts...)
			cur = f.parent
		}
		paths[id] = strings.Join(parts, " / ")
	}
	return paths, nil
}

// learnWriteCSV пишет результаты выбранных тестов потоком: UTF-8 с BOM, разделитель «;» (Excel).
func (s *Server) learnWriteCSV(c *Ctx, testIDs []int64, filename string) error {
	ctx := c.Context()
	paths, err := s.learnTestPaths(ctx)
	if err != nil {
		return err
	}
	args := []any{testIDs}
	conds := append([]string{"a.test_id = ANY($1::bigint[])", "a.finished_at IS NOT NULL"}, learnAttemptConds(c, &args)...)
	rows, err := s.db.Query(ctx, `SELECT t.title, t.folder_id, u.full_name, u.login, coalesce(d.name, ''), u.job_title, a.no, a.started_at, a.finished_at, coalesce(a.duration_sec, 0),
			a.score::float8, a.max_score::float8, a.percent::float8, coalesce(a.passed, false), a.expired
		FROM learn_attempts a JOIN learn_tests t ON t.id = a.test_id JOIN users u ON u.id = a.user_id LEFT JOIN departments d ON d.id = u.department_id
		WHERE `+strings.Join(conds, " AND ")+` ORDER BY t.id, a.finished_at`, args...)
	if err != nil {
		return err
	}
	defer rows.Close()
	h := c.W.Header()
	h.Set("Content-Type", "text/csv; charset=utf-8")
	h.Set("Content-Disposition", "attachment; filename*=UTF-8''"+url.PathEscape(filename))
	h.Set("Cache-Control", "no-store")
	c.W.Write([]byte{0xEF, 0xBB, 0xBF})
	w := csv.NewWriter(c.W)
	w.Comma = ';'
	w.Write([]string{"Тест", "Папка", "Сотрудник", "Логин", "Подразделение", "Должность", "Попытка", "Начало", "Окончание", "Длительность, мин", "Баллы", "Максимум", "Процент", "Результат", "По таймеру"})
	loc := s.loc()
	n := 0
	for rows.Next() {
		var title, name, login, dept, job string
		var folder int64
		var no, dur int
		var st, fin time.Time
		var score, mx, pct *float64
		var passed, expired bool
		if err := rows.Scan(&title, &folder, &name, &login, &dept, &job, &no, &st, &fin, &dur, &score, &mx, &pct, &passed, &expired); err != nil {
			return err
		}
		res, tm := "Не сдан", ""
		if passed {
			res = "Сдан"
		}
		if expired {
			tm = "да"
		}
		w.Write([]string{csvCell(title), csvCell(paths[folder]), csvCell(name), csvCell(login), csvCell(dept), csvCell(job), strconv.Itoa(no),
			st.In(loc).Format("02.01.2006 15:04:05"), fin.In(loc).Format("02.01.2006 15:04:05"), fmt.Sprintf("%d:%02d", dur/60, dur%60),
			fnum(score), fnum(mx), fnum(pct), res, tm})
		if n++; n%2000 == 0 {
			w.Flush()
		}
	}
	w.Flush()
	return rows.Err()
}

func (s *Server) learnExportTestCSV(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	t, _, err := s.learnTestAccess(c, id, lvEdit)
	if err != nil {
		return err
	}
	name := "results-" + strconv.FormatInt(id, 10) + "-" + time.Now().In(s.loc()).Format("20060102") + ".csv"
	_ = t
	return s.learnWriteCSV(c, []int64{id}, name)
}

// learnExportFolderCSV: результаты всех тестов папки (с вложенными) или выбранных тестов (?tests=1,2,3); только там, где есть право редактирования.
func (s *Server) learnExportFolderCSV(c *Ctx) error {
	ctx := c.Context()
	_, mng, nodes, err := s.learnTreeIDs(ctx, c.U, "tests")
	if err != nil {
		return err
	}
	canMng := map[int64]bool{}
	for _, id := range mng {
		canMng[id] = true
	}
	var folders []int64
	if f := c.QInt64("folder"); f > 0 {
		kids := map[int64][]int64{}
		for _, n := range nodes {
			if n.Pid != nil {
				kids[*n.Pid] = append(kids[*n.Pid], n.ID)
			}
		}
		var walk func(id int64)
		walk = func(id int64) {
			if canMng[id] {
				folders = append(folders, id)
			}
			for _, k := range kids[id] {
				walk(k)
			}
		}
		walk(f)
	} else {
		folders = mng
	}
	if len(folders) == 0 {
		return errForbidden
	}
	args := []any{folders}
	cond := ""
	if ids := parseIDs(c.Q("tests")); len(ids) > 0 {
		args = append(args, ids)
		cond = " AND id = ANY($2::bigint[])"
	}
	rows, err := s.db.Query(ctx, `SELECT id FROM learn_tests WHERE folder_id = ANY($1::bigint[])`+cond, args...)
	if err != nil {
		return err
	}
	var tests []int64
	for rows.Next() {
		var id int64
		rows.Scan(&id)
		tests = append(tests, id)
	}
	rows.Close()
	if len(tests) == 0 {
		return badReq("Нет тестов для выгрузки")
	}
	return s.learnWriteCSV(c, tests, "results-"+time.Now().In(s.loc()).Format("20060102-1504")+".csv")
}
