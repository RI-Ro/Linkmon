package server

// Аналитика: фоновые пересчёты (rollup). Все задачи идемпотентны: пересчитывают «сегодня» и «вчера» из первичных
// таблиц и записывают АБСОЛЮТНЫЕ значения (dc=''), поэтому повторный или параллельный запуск безопасен. Выполняются
// под job_locks (раз в ~5 минут на весь кластер, независимо от числа экземпляров и ЦОДов).

import (
	"context"
	"strings"
	"sync"
	"time"

	"github.com/jackc/pgx/v5"
)

// ---------------------------------------------------------------- наличие необязательных таблиц

var anTables struct {
	sync.Mutex
	at time.Time
	m  map[string]bool
}

// anHas сообщает, есть ли таблица (to_regclass). Блоки других команд (реакции, закладки, заявки, wiki, LMS) подключаются условно.
func (s *Server) anHas(ctx context.Context, tables ...string) bool {
	anTables.Lock()
	defer anTables.Unlock()
	if anTables.m == nil || time.Since(anTables.at) > time.Minute {
		anTables.m, anTables.at = map[string]bool{}, time.Now()
	}
	for _, t := range tables {
		v, ok := anTables.m[t]
		if !ok {
			var reg *string
			if err := s.ro.QueryRow(ctx, `SELECT to_regclass('public.' || $1)::text`, t).Scan(&reg); err != nil {
				return false
			}
			v = reg != nil
			anTables.m[t] = v
		}
		if !v {
			return false
		}
	}
	return true
}

// anLikeSource — таблица «реакций» на объекты: reactions (после миграции 009), иначе исторический likes.
func (s *Server) anLikeSource(ctx context.Context) string {
	switch {
	case s.anHas(ctx, "reactions"):
		return "reactions"
	case s.anHas(ctx, "likes"):
		return "likes"
	}
	return ""
}

// ---------------------------------------------------------------- расписание

func (s *Server) anRollups(ctx context.Context) {
	if !s.lock(ctx, "an:rollup", 4*time.Minute+30*time.Second) {
		return
	}
	t0 := time.Now()
	now := time.Now().In(s.an.loc)
	days := []string{now.AddDate(0, 0, -1).Format("2006-01-02"), now.Format("2006-01-02")}
	s.anEnsureIndexes(ctx)
	for _, d := range days {
		s.anRollupDay(ctx, d)
	}
	if s.lock(ctx, "an:wm", 29*time.Minute) {
		s.anActiveWindows(ctx, days[1])
	}
	if s.lock(ctx, "an:daily:"+days[1], 26*time.Hour) {
		for i := 1; i <= 7; i++ {
			d := now.AddDate(0, 0, -i).Format("2006-01-02")
			var have bool
			if s.db.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM stats_daily WHERE day = $1::date AND metric = 'mau')`, d).Scan(&have); !have {
				s.anActiveWindows(ctx, d)
			}
		}
		s.anRetention(ctx)
	}
	if d := time.Since(t0); d > 5*time.Second {
		s.log.Info("analytics rollups slow", "ms", d.Milliseconds())
	}
}

var anIndexesOnce sync.Once

// anEnsureIndexes создаёт BRIN-индексы по времени для таблиц, которых могло не быть в момент миграции 012
// (их создают миграции других блоков, применяемые позже). BRIN крошечный и почти не замедляет запись.
func (s *Server) anEnsureIndexes(ctx context.Context) {
	anIndexesOnce.Do(func() {
		for _, x := range [][3]string{
			{"reactions", "created_at", "reactions_created_brin"}, {"bookmarks", "created_at", "bookmarks_created_brin"},
			{"mentions", "created_at", "mentions_created_brin"}, {"req_requests", "submitted_at", "req_requests_submitted_brin"},
			{"req_requests", "closed_at", "req_requests_closed_brin"}, {"learn_attempts", "started_at", "learn_attempts_started_brin"},
			{"learn_attempts", "finished_at", "learn_attempts_finished_brin"}, {"learn_assignees", "assigned_at", "learn_assignees_assigned_brin"},
			{"learn_completions", "completed_at", "learn_completions_completed_brin"}, {"wiki_pages", "created_at", "wiki_pages_created_brin"},
			{"wiki_versions", "created_at", "wiki_versions_created_brin"}, {"wiki_comments", "created_at", "wiki_comments_created_brin"},
			{"learn_progress", "opened_at", "learn_progress_opened_brin"},
		} {
			if s.anHas(ctx, x[0]) {
				if _, err := s.db.Exec(ctx, `CREATE INDEX IF NOT EXISTS `+x[2]+` ON `+x[0]+` USING brin (`+x[1]+`)`); err != nil {
					s.log.Warn("analytics: index failed", "index", x[2], "err", err)
				}
			}
		}
	})
}

const (
	anLo = `(($1::date)::timestamp AT TIME ZONE $2)`
	anHi = `((($1::date) + 1)::timestamp AT TIME ZONE $2)`
)

// anPut выполняет подзапрос, возвращающий (metric, dim, value), и записывает результат как абсолютные значения дня.
// В подзапросе доступны $1 (день), $2 (часовой пояс) и макросы {lo}/{hi} — границы дня как timestamptz.
func (s *Server) anPut(ctx context.Context, day, sub string) {
	sub = strings.NewReplacer("{lo}", anLo, "{hi}", anHi).Replace(sub)
	if _, err := s.db.Exec(ctx, `INSERT INTO stats_daily (day, metric, dim, dc, value)
		SELECT $1::date, metric, dim, '', value FROM (`+sub+`) q(metric, dim, value) WHERE value IS NOT NULL AND $2::text IS NOT NULL
		ON CONFLICT (day, metric, dim, dc) DO UPDATE SET value = EXCLUDED.value`, day, s.cfg.TZ); err != nil {
		s.log.Warn("analytics: rollup failed", "day", day, "err", err, "sql", clip(strings.Join(strings.Fields(sub), " "), 90))
	}
}

func (s *Server) anRollupDay(ctx context.Context, day string) {
	// поиск: полные счётчики дня и повторяющиеся/нулевые запросы
	s.anPut(ctx, day, `SELECT m, scope, v FROM (
			SELECT 'search_total' m, scope, count(*) v FROM search_log WHERE created_at >= {lo} AND created_at < {hi} GROUP BY scope
			UNION ALL SELECT 'search_zero', scope, count(*) FROM search_log WHERE created_at >= {lo} AND created_at < {hi} AND results_count = 0 GROUP BY scope
			UNION ALL SELECT 'search_clicked', scope, count(*) FROM search_log WHERE created_at >= {lo} AND created_at < {hi} AND clicked GROUP BY scope
			UNION ALL SELECT 'search_ms', scope, sum(took_ms) FROM search_log WHERE created_at >= {lo} AND created_at < {hi} GROUP BY scope
			UNION ALL SELECT 'search_users', '', count(DISTINCT user_id) FROM search_log WHERE created_at >= {lo} AND created_at < {hi} AND scope <> 'admin_news') t`)
	if _, err := s.db.Exec(ctx, `INSERT INTO search_daily (day, scope, normalized, searches, zero, noclick, clicks, users, took_ms, sample)
		SELECT $1::date, scope, normalized, count(*), count(*) FILTER (WHERE results_count = 0), count(*) FILTER (WHERE results_count > 0 AND NOT clicked),
			count(*) FILTER (WHERE clicked), count(DISTINCT user_id), sum(took_ms), mode() WITHIN GROUP (ORDER BY query)
		FROM search_log WHERE created_at >= `+anLo+` AND created_at < `+anHi+`
		GROUP BY scope, normalized HAVING count(*) >= 2 OR count(*) FILTER (WHERE results_count = 0) > 0
		ON CONFLICT (day, scope, normalized) DO UPDATE SET searches = EXCLUDED.searches, zero = EXCLUDED.zero, noclick = EXCLUDED.noclick,
			clicks = EXCLUDED.clicks, users = EXCLUDED.users, took_ms = EXCLUDED.took_ms, sample = EXCLUDED.sample`, day, s.cfg.TZ); err != nil {
		s.log.Warn("analytics: search rollup failed", "err", err)
	}

	// активность и пользователи
	s.anPut(ctx, day, `SELECT 'dau', '', count(*) FROM user_daily_activity WHERE day = $1::date`)
	s.anPut(ctx, day, `SELECT 'users_total', '', count(*) FROM users WHERE NOT blocked`)
	s.anPut(ctx, day, `SELECT 'users_new', '', count(*) FROM users WHERE created_at >= {lo} AND created_at < {hi}`)

	// новости: реакции и комментарии по каждой новости за день (обнуляем и пересчитываем: снятая реакция должна уменьшить счётчик)
	likes := s.anLikeSource(ctx)
	err := s.tx(ctx, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `UPDATE news_stats_daily SET likes = 0, comments = 0 WHERE day = $1::date AND (likes <> 0 OR comments <> 0)`, day); err != nil {
			return err
		}
		if likes != "" {
			if _, err := tx.Exec(ctx, `INSERT INTO news_stats_daily (news_id, day, likes)
				SELECT l.entity_id, $1::date, count(*)::int FROM `+likes+` l JOIN news n ON n.id = l.entity_id
				WHERE l.entity_type = 'news' AND l.created_at >= `+anLo+` AND l.created_at < `+anHi+` GROUP BY l.entity_id
				ON CONFLICT (news_id, day) DO UPDATE SET likes = EXCLUDED.likes`, day, s.cfg.TZ); err != nil {
				return err
			}
		}
		_, err := tx.Exec(ctx, `INSERT INTO news_stats_daily (news_id, day, comments)
			SELECT c.entity_id, $1::date, count(*)::int FROM comments c JOIN news n ON n.id = c.entity_id
			WHERE c.entity_type = 'news' AND c.deleted_at IS NULL AND c.created_at >= `+anLo+` AND c.created_at < `+anHi+` GROUP BY c.entity_id
			ON CONFLICT (news_id, day) DO UPDATE SET comments = EXCLUDED.comments`, day, s.cfg.TZ)
		return err
	})
	if err != nil {
		s.log.Warn("analytics: news engagement rollup failed", "err", err)
	}
	s.anPut(ctx, day, `SELECT m, '', coalesce(sum(v), 0) FROM (SELECT 'likes_news' m, likes v FROM news_stats_daily WHERE day = $1::date
		UNION ALL SELECT 'comments_news', comments FROM news_stats_daily WHERE day = $1::date) t GROUP BY m`)
	s.anPut(ctx, day, `SELECT 'news_published', '', count(*) FROM news WHERE status = 'published' AND NOT hidden AND published_at >= {lo} AND published_at < {hi}`)

	// комментарии вне новостей, ответы, личные/групповые сообщения (только счётчики, текст не читается)
	s.anPut(ctx, day, `SELECT 'comments_' || entity_type, '', count(*) FROM comments WHERE deleted_at IS NULL AND created_at >= {lo} AND created_at < {hi} GROUP BY entity_type
		UNION ALL SELECT 'replies', '', count(*) FROM comments WHERE deleted_at IS NULL AND parent_id IS NOT NULL AND created_at >= {lo} AND created_at < {hi}`)
	s.anPut(ctx, day, `SELECT 'msg_' || c.kind, '', count(*) FROM messages m JOIN chats c ON c.id = m.chat_id
			WHERE m.deleted_at IS NULL AND m.created_at >= {lo} AND m.created_at < {hi} GROUP BY c.kind
		UNION ALL SELECT 'msg_senders', '', count(DISTINCT user_id) FROM messages WHERE deleted_at IS NULL AND created_at >= {lo} AND created_at < {hi}
		UNION ALL SELECT 'chats_active', '', count(DISTINCT chat_id) FROM messages WHERE deleted_at IS NULL AND created_at >= {lo} AND created_at < {hi}`)
	s.anPut(ctx, day, `SELECT 'group_posts', '', count(*) FROM group_posts WHERE created_at >= {lo} AND created_at < {hi}
		UNION ALL SELECT 'groups_active', '', count(DISTINCT group_id) FROM group_posts WHERE created_at >= {lo} AND created_at < {hi}
		UNION ALL SELECT 'poll_votes', '', count(*) FROM poll_votes WHERE voted_at >= {lo} AND voted_at < {hi}
		UNION ALL SELECT 'poll_voters', '', count(DISTINCT user_id) FROM poll_votes WHERE voted_at >= {lo} AND voted_at < {hi}
		UNION ALL SELECT 'ideas_new', '', count(*) FROM ideas WHERE created_at >= {lo} AND created_at < {hi}`)

	// реакции, закладки, упоминания (блок «social», может отсутствовать)
	if s.anHas(ctx, "reactions") {
		s.anPut(ctx, day, `SELECT 'reactions_' || entity_type, '', count(*) FROM reactions WHERE created_at >= {lo} AND created_at < {hi} GROUP BY entity_type
			UNION ALL SELECT 'reaction_emoji', emoji, n FROM (SELECT emoji, count(*) n FROM reactions WHERE entity_type = 'news' AND created_at >= {lo} AND created_at < {hi}
				GROUP BY emoji ORDER BY n DESC LIMIT 30) e`)
	}
	if s.anHas(ctx, "bookmarks") {
		s.anPut(ctx, day, `SELECT 'bookmarks', entity_type, count(*) FROM bookmarks WHERE created_at >= {lo} AND created_at < {hi} GROUP BY entity_type`)
	}
	if s.anHas(ctx, "mentions") {
		s.anPut(ctx, day, `SELECT 'mentions', entity_type, count(*) FROM mentions WHERE created_at >= {lo} AND created_at < {hi} GROUP BY entity_type`)
	}
	// обучение
	if s.anHas(ctx, "learn_attempts") {
		s.anPut(ctx, day, `SELECT 'learn_att_started', '', count(*) FROM learn_attempts WHERE started_at >= {lo} AND started_at < {hi}
			UNION ALL SELECT 'learn_att_finished', '', count(*) FROM learn_attempts WHERE finished_at >= {lo} AND finished_at < {hi}
			UNION ALL SELECT 'learn_att_passed', '', count(*) FROM learn_attempts WHERE finished_at >= {lo} AND finished_at < {hi} AND passed`)
	}
	if s.anHas(ctx, "learn_progress") {
		s.anPut(ctx, day, `SELECT 'learn_opened', '', count(*) FROM learn_progress WHERE opened_at >= {lo} AND opened_at < {hi}
			UNION ALL SELECT 'learn_item_done', '', count(*) FROM learn_progress WHERE done_at >= {lo} AND done_at < {hi}`)
	}
	if s.anHas(ctx, "learn_assignees") {
		s.anPut(ctx, day, `SELECT 'learn_assigned', '', count(*) FROM learn_assignees WHERE assigned_at >= {lo} AND assigned_at < {hi}
			UNION ALL SELECT 'learn_done', '', count(*) FROM learn_assignees WHERE status = 2 AND done_at >= {lo} AND done_at < {hi}`)
	}
	if s.anHas(ctx, "learn_completions") {
		s.anPut(ctx, day, `SELECT 'learn_completions', '', count(*) FROM learn_completions WHERE completed_at >= {lo} AND completed_at < {hi}`)
	}
	// заявки
	if s.anHas(ctx, "req_requests") {
		s.anPut(ctx, day, `SELECT 'req_submitted', '', count(*) FROM req_requests WHERE submitted_at >= {lo} AND submitted_at < {hi}
			UNION ALL SELECT 'req_closed', status, count(*) FROM req_requests WHERE closed_at >= {lo} AND closed_at < {hi} GROUP BY status`)
	}
	// wiki
	if s.anHas(ctx, "wiki_pages") {
		s.anPut(ctx, day, `SELECT 'wiki_created', '', count(*) FROM wiki_pages WHERE created_at >= {lo} AND created_at < {hi}`)
	}
	if s.anHas(ctx, "wiki_versions") {
		s.anPut(ctx, day, `SELECT 'wiki_edits', '', count(*) FROM wiki_versions WHERE created_at >= {lo} AND created_at < {hi}`)
	}
	if s.anHas(ctx, "wiki_comments") {
		s.anPut(ctx, day, `SELECT 'wiki_comments', '', count(*) FROM wiki_comments WHERE created_at >= {lo} AND created_at < {hi}`)
	}
}

// anActiveWindows считает WAU и MAU на конец дня (скользящие 7 и 30 дней) по user_daily_activity.
func (s *Server) anActiveWindows(ctx context.Context, day string) {
	s.anPut(ctx, day, `SELECT 'wau', '', count(DISTINCT user_id) FROM user_daily_activity WHERE day > $1::date - 7 AND day <= $1::date
		UNION ALL SELECT 'mau', '', count(DISTINCT user_id) FROM user_daily_activity WHERE day > $1::date - 30 AND day <= $1::date
		UNION ALL SELECT 'dau', '', count(*) FROM user_daily_activity WHERE day = $1::date`)
}

// anRetentionDays — срок хранения сырых данных (настройка ANALYTICS_RETENTION_DAYS, по умолчанию 400 дней).
func anRetentionDays() int { return max(envInt("ANALYTICS_RETENTION_DAYS", 400), 30) }

// anRetention удаляет устаревшие сырые данные пачками (чтобы не держать долгих блокировок и не раздувать WAL).
func (s *Server) anRetention(ctx context.Context) {
	days := anRetentionDays()
	cut := time.Now().AddDate(0, 0, -days).Format("2006-01-02")
	var total int64
	for i := 0; i < 200; i++ { // до 200 × 20 000 строк за запуск
		tag, err := s.db.Exec(ctx, `DELETE FROM search_log WHERE id IN (SELECT id FROM search_log WHERE created_at < $1::date ORDER BY created_at LIMIT 20000)`, cut)
		if err != nil {
			s.log.Warn("analytics: retention failed", "err", err)
			break
		}
		total += tag.RowsAffected()
		if tag.RowsAffected() < 20000 {
			break
		}
	}
	for _, q := range []string{
		`DELETE FROM search_daily WHERE day < $1::date`,
		`DELETE FROM user_daily_activity WHERE day < $1::date`,
		`DELETE FROM stats_daily WHERE day < $1::date`,
		`DELETE FROM news_stats_daily WHERE day < $1::date`,
	} {
		if tag, err := s.db.Exec(ctx, q, cut); err == nil {
			total += tag.RowsAffected()
		}
	}
	s.log.Info("analytics retention", "days", days, "deleted", total)
}
