package server

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"
	"unicode"

	"github.com/jackc/pgx/v5"
)

// Базы знаний (Wiki) в разделе «Обучение → Материалы».
//
// Файлы блока:
//   wiki.go        — маршруты, субъекты и уровни доступа, базы знаний, права (ACL), полка в папке материалов
//   wiki_pages.go  — дерево, страницы, версии, перенос/копирование, вложения, комментарии, «требуют обновления»
//   wiki_search.go — полнотекстовый поиск (tsvector 'simple') с проверкой прав в SQL до сниппетов
//   wiki_io.go     — экспорт / импорт markdown (zip)
//   seed_wiki.go   — демо-база «Корпоративный справочник»
//
// Права: см. комментарий к wiki_level в migrate/sql/014_wiki.sql. Скрытые страницы не попадают ни в дерево,
// ни в поиск, ни в хлебные крошки, ни в соседние/дочерние страницы; обращение к ним по id даёт 404.

const (
	wvView = 1
	wvEdit = 3
	wvOwn  = 4
)

// registerWiki регистрирует маршруты баз знаний.
func (s *Server) registerWiki(m *http.ServeMux) {
	const U = "user"
	p := "/api/wiki"

	m.HandleFunc("GET "+p+"/shelf", s.h(U, s.wikiShelf))
	m.HandleFunc("GET "+p+"/spaces", s.h(U, s.wikiSpacesList))
	m.HandleFunc("GET "+p+"/search", s.h(U, s.wikiSearch))
	m.HandleFunc("GET "+p+"/review", s.h(U, s.wikiReviewMine))

	m.HandleFunc("POST "+p+"/spaces", s.h(U, s.wikiSpaceSave))
	m.HandleFunc("GET "+p+"/spaces/{id}", s.h(U, s.wikiSpaceGet))
	m.HandleFunc("PUT "+p+"/spaces/{id}", s.h(U, s.wikiSpaceSave))
	m.HandleFunc("DELETE "+p+"/spaces/{id}", s.h(U, s.wikiSpaceDelete))
	m.HandleFunc("POST "+p+"/spaces/{id}/move", s.h(U, s.wikiSpaceMove))
	m.HandleFunc("GET "+p+"/spaces/{id}/acl", s.h(U, s.wikiSpaceACLGet))
	m.HandleFunc("PUT "+p+"/spaces/{id}/acl", s.h(U, s.wikiSpaceACLPut))
	m.HandleFunc("GET "+p+"/spaces/{id}/tree", s.h(U, s.wikiTree))
	m.HandleFunc("GET "+p+"/spaces/{id}/recent", s.h(U, s.wikiRecent))
	m.HandleFunc("GET "+p+"/spaces/{id}/review", s.h(U, s.wikiReviewSpace))
	m.HandleFunc("GET "+p+"/spaces/{id}/export.zip", s.h(U, s.wikiExport))
	m.HandleFunc("POST "+p+"/spaces/{id}/import", s.h(U, s.wikiImport))

	m.HandleFunc("POST "+p+"/pages", s.h(U, s.wikiPageCreate))
	m.HandleFunc("GET "+p+"/pages/{id}", s.h(U, s.wikiPageGet))
	m.HandleFunc("PUT "+p+"/pages/{id}", s.h(U, s.wikiPageSave))
	m.HandleFunc("DELETE "+p+"/pages/{id}", s.h(U, s.wikiPageDelete))
	m.HandleFunc("POST "+p+"/pages/{id}/move", s.h(U, s.wikiPageMove))
	m.HandleFunc("POST "+p+"/pages/{id}/copy", s.h(U, s.wikiPageCopy))
	m.HandleFunc("GET "+p+"/pages/{id}/acl", s.h(U, s.wikiPageACLGet))
	m.HandleFunc("PUT "+p+"/pages/{id}/acl", s.h(U, s.wikiPageACLPut))
	m.HandleFunc("GET "+p+"/pages/{id}/versions", s.h(U, s.wikiVersions))
	m.HandleFunc("GET "+p+"/pages/{id}/versions/{v}", s.h(U, s.wikiVersionGet))
	m.HandleFunc("POST "+p+"/pages/{id}/restore", s.h(U, s.wikiRestore))
	m.HandleFunc("POST "+p+"/pages/{id}/files", s.h(U, s.wikiFileUpload))
	m.HandleFunc("DELETE "+p+"/pages/{id}/files/{fid}", s.h(U, s.wikiFileDelete))
	m.HandleFunc("GET "+p+"/pages/{id}/comments", s.h(U, s.wikiComments))
	m.HandleFunc("POST "+p+"/pages/{id}/comments", s.h(U, s.wikiCommentAdd))
	m.HandleFunc("DELETE "+p+"/comments/{id}", s.h(U, s.wikiCommentDelete))
	m.HandleFunc("POST "+p+"/pages/{id}/reviewed", s.h(U, s.wikiMarkReviewed))

	s.registerWikiBookmarks()
	go s.wikiSweeper()
}

// registerWikiBookmarks — TODO: регистрация типа закладки wiki_page в реестре закладок (registerBookmarkResolver),
// когда блок «закладки» появится в коде. Сейчас реестра нет, поэтому метод пуст.
func (s *Server) registerWikiBookmarks() {}

// ---------------------------------------------------------------- субъекты и уровни

type wsubj struct {
	UID    int64    `json:"uid"`
	Dept   int64    `json:"dept"`
	Depts  []int64  `json:"depts"` // своё подразделение и вышестоящие
	Groups []int64  `json:"groups"`
	Roles  []string `json:"roles"`
	Adm    bool     `json:"adm"`
}

func (sj *wsubj) args() []any {
	return []any{sj.UID, sj.Dept, sj.Depts, sj.Groups, sj.Roles, sj.Adm}
}

// wA — первые шесть параметров любого запроса, использующего функции wiki_level / wiki_space_level.
const wA = "$1::bigint, $2::bigint, $3::bigint[], $4::bigint[], $5::text[], $6::boolean"

func (s *Server) wikiSubj(ctx context.Context, u *User) (*wsubj, error) {
	key := fmt.Sprintf("wk:sj:%d:%d", u.ID, u.Dept)
	var sj wsubj
	if b, err := s.rdb.Get(ctx, key).Bytes(); err == nil && json.Unmarshal(b, &sj) == nil && sj.UID == u.ID {
		sj.Adm = u.IsAdmin()
		return &sj, nil
	}
	sj = wsubj{UID: u.ID, Dept: u.Dept, Adm: u.IsAdmin(), Depts: []int64{}, Groups: []int64{}, Roles: []string{"user"}}
	if u.CanEdit() {
		sj.Roles = append(sj.Roles, "editor")
	}
	if u.IsAdmin() {
		sj.Roles = append(sj.Roles, "admin")
	}
	if u.Head {
		sj.Roles = append(sj.Roles, "head")
	}
	err := s.db.QueryRow(ctx, `SELECT
		coalesce((WITH RECURSIVE dc AS (SELECT id, parent_id FROM departments WHERE id = $1::bigint
			UNION ALL SELECT x.id, x.parent_id FROM departments x JOIN dc ON x.id = dc.parent_id) SELECT array_agg(id) FROM dc), '{}'::bigint[]),
		coalesce((SELECT array_agg(group_id) FROM group_members WHERE user_id = $2::bigint AND role <> 'pending'), '{}'::bigint[])`,
		u.Dept, u.ID).Scan(&sj.Depts, &sj.Groups)
	if err != nil {
		return nil, err
	}
	if b, err := json.Marshal(sj); err == nil {
		s.rdb.Set(ctx, key, b, 30*time.Second)
	}
	return &sj, nil
}

type wspace struct {
	ID          int64
	FolderID    *int64
	Title, Slug string
	Description string
	Icon, Cover string
	Visibility  string
	OwnerID     *int64
	Level       int
}

// wikiSpace читает базу знаний с эффективным уровнем доступа; нет доступа — 404 (существование не раскрываем).
func (s *Server) wikiSpace(c *Ctx, id int64, min int) (*wspace, *wsubj, error) {
	sj, err := s.wikiSubj(c.Context(), c.U)
	if err != nil {
		return nil, nil, err
	}
	var sp wspace
	err = s.db.QueryRow(c.Context(), `SELECT id, folder_id, title, slug, description, icon, cover, visibility, owner_id, wiki_space_level(id, `+wA+`)
		FROM wiki_spaces WHERE id = $7::bigint`, append(sj.args(), id)...).
		Scan(&sp.ID, &sp.FolderID, &sp.Title, &sp.Slug, &sp.Description, &sp.Icon, &sp.Cover, &sp.Visibility, &sp.OwnerID, &sp.Level)
	if err != nil {
		return nil, nil, err
	}
	if sp.Level == 0 {
		return nil, nil, errNotFound
	}
	if sp.Level < min {
		return nil, nil, errForbidden
	}
	return &sp, sj, nil
}

type wpage struct {
	ID, SpaceID int64
	ParentID    *int64
	Title       string
	OwnerID     *int64
	Visibility  string
	Version     int
	Level       int
}

func (s *Server) wikiPageAt(c *Ctx, id int64, min int) (*wpage, *wsubj, error) {
	sj, err := s.wikiSubj(c.Context(), c.U)
	if err != nil {
		return nil, nil, err
	}
	var p wpage
	err = s.db.QueryRow(c.Context(), `SELECT p.id, p.space_id, p.parent_id, p.title, p.owner_id, p.visibility, p.version, wiki_level(p.id, `+wA+`)
		FROM wiki_pages p WHERE p.id = $7::bigint`, append(sj.args(), id)...).
		Scan(&p.ID, &p.SpaceID, &p.ParentID, &p.Title, &p.OwnerID, &p.Visibility, &p.Version, &p.Level)
	if err != nil {
		return nil, nil, err
	}
	if p.Level == 0 {
		return nil, nil, errNotFound
	}
	if p.Level < min {
		return nil, nil, errForbidden
	}
	return &p, sj, nil
}

// ---------------------------------------------------------------- slug

var translit = map[rune]string{'а': "a", 'б': "b", 'в': "v", 'г': "g", 'д': "d", 'е': "e", 'ё': "e", 'ж': "zh", 'з': "z", 'и': "i", 'й': "y", 'к': "k",
	'л': "l", 'м': "m", 'н': "n", 'о': "o", 'п': "p", 'р': "r", 'с': "s", 'т': "t", 'у': "u", 'ф': "f", 'х': "h", 'ц': "c", 'ч': "ch", 'ш': "sh",
	'щ': "sch", 'ъ': "", 'ы': "y", 'ь': "", 'э': "e", 'ю': "yu", 'я': "ya"}

// wikiSlug — латинский slug для красивых ссылок. Идентификатором служит число перед ним, slug необязателен.
func wikiSlug(title string) string {
	var b strings.Builder
	dash := true
	for _, r := range strings.ToLower(title) {
		switch {
		case r < 128 && (unicode.IsLetter(r) || unicode.IsDigit(r)):
			b.WriteRune(r)
			dash = false
		case translit[r] != "":
			b.WriteString(translit[r])
			dash = false
		case !dash:
			b.WriteByte('-')
			dash = true
		}
		if b.Len() >= 60 {
			break
		}
	}
	return strings.Trim(b.String(), "-")
}

func cleanTitle(t string) string {
	t = strings.Join(strings.Fields(t), " ")
	if r := []rune(t); len(r) > 200 {
		t = string(r[:200])
	}
	return t
}

func okCover(c string) bool {
	if c == "" {
		return true
	}
	if len(c) == 2 && c[0] == 'c' && c[1] >= '1' && c[1] <= '8' {
		return true
	}
	return len(c) < 500 && (strings.HasPrefix(c, "/media/") || urlOK(c))
}

// ---------------------------------------------------------------- полка в папке материалов

func (s *Server) wikiShelf(c *Ctx) error {
	sj, err := s.wikiSubj(c.Context(), c.U)
	if err != nil {
		return err
	}
	b, err := s.arr(c.Context(), `SELECT * FROM (
		SELECT s.id, s.folder_id, s.title, s.slug, s.description, s.icon, s.cover, s.visibility, s.updated_at, wiki_space_level(s.id, `+wA+`) AS level, s.sort
		FROM wiki_spaces s WHERE CASE WHEN $7::bigint = 0 THEN s.folder_id IS NULL ELSE s.folder_id = $7::bigint END) x
		WHERE level > 0 ORDER BY sort, lower(title), id`, append(sj.args(), c.QInt64("folder"))...)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// wikiSpacesList — все доступные базы знаний (для выбора места копирования, быстрого перехода).
func (s *Server) wikiSpacesList(c *Ctx) error {
	sj, err := s.wikiSubj(c.Context(), c.U)
	if err != nil {
		return err
	}
	b, err := s.arr(c.Context(), `SELECT * FROM (
		SELECT s.id, s.folder_id, s.title, s.slug, s.icon, s.cover, s.description, s.visibility, wiki_space_level(s.id, `+wA+`) AS level, s.sort
		FROM wiki_spaces s) x WHERE level > 0 ORDER BY sort, lower(title), id`, sj.args()...)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) wikiSpaceJSON(c *Ctx, sp *wspace) map[string]any {
	return map[string]any{"id": sp.ID, "folder_id": sp.FolderID, "title": sp.Title, "slug": sp.Slug, "description": sp.Description,
		"icon": sp.Icon, "cover": sp.Cover, "visibility": sp.Visibility, "owner_id": sp.OwnerID, "level": sp.Level}
}

func (s *Server) wikiSpaceGet(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	sp, _, err := s.wikiSpace(c, id, wvView)
	if err != nil {
		return err
	}
	out := s.wikiSpaceJSON(c, sp)
	if sp.FolderID != nil {
		var name string
		s.db.QueryRow(c.Context(), `SELECT name FROM learn_folders WHERE id = $1`, *sp.FolderID).Scan(&name)
		out["folder_name"] = name
	}
	return c.JSON(200, out)
}

func (s *Server) wikiSpaceSave(c *Ctx) error {
	var in struct {
		FolderID    *int64 `json:"folder_id"`
		Title       string `json:"title"`
		Description string `json:"description"`
		Icon        string `json:"icon"`
		Cover       string `json:"cover"`
		Visibility  string `json:"visibility"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Title = cleanTitle(in.Title)
	if in.Title == "" {
		return badReq("Укажите название базы знаний")
	}
	if len(in.Description) > 2000 || len([]rune(in.Icon)) > 8 || !okCover(in.Cover) {
		return badReq("Некорректные данные")
	}
	ctx := c.Context()
	var id int64
	if c.R.PathValue("id") != "" {
		var err error
		if id, err = c.ID("id"); err != nil {
			return err
		}
		if _, _, err = s.wikiSpace(c, id, wvOwn); err != nil {
			return err
		}
		if _, err = s.db.Exec(ctx, `UPDATE wiki_spaces SET title = $2, slug = $3, description = $4, icon = $5, cover = $6, updated_at = now() WHERE id = $1`,
			id, in.Title, wikiSlug(in.Title), in.Description, in.Icon, in.Cover); err != nil {
			return err
		}
	} else {
		if in.FolderID != nil {
			f, err := s.learnFolder(c, *in.FolderID, lvEdit)
			if err != nil {
				return err
			}
			if f.Kind != "materials" {
				return badReq("База знаний создаётся только в папке материалов")
			}
		} else if !s.canCreateRoot(c) {
			return errForbidden
		}
		vis := "company"
		if in.Visibility == "restricted" {
			vis = "restricted"
		}
		if err := s.db.QueryRow(ctx, `INSERT INTO wiki_spaces (folder_id, title, slug, description, icon, cover, visibility, owner_id)
			VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id`, in.FolderID, in.Title, wikiSlug(in.Title), in.Description, in.Icon, in.Cover, vis, c.U.ID).Scan(&id); err != nil {
			return err
		}
		s.audit(c, "wiki.space.create", "wiki_space", id, map[string]any{"title": in.Title})
	}
	sp, _, err := s.wikiSpace(c, id, wvView)
	if err != nil {
		return err
	}
	return c.JSON(200, s.wikiSpaceJSON(c, sp))
}

func (s *Server) wikiSpaceMove(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		FolderID *int64 `json:"folder_id"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if _, _, err = s.wikiSpace(c, id, wvOwn); err != nil {
		return err
	}
	if in.FolderID != nil {
		f, err := s.learnFolder(c, *in.FolderID, lvEdit)
		if err != nil {
			return err
		}
		if f.Kind != "materials" {
			return badReq("Папка относится к другому разделу")
		}
	} else if !s.canCreateRoot(c) {
		return errForbidden
	}
	if _, err := s.db.Exec(c.Context(), `UPDATE wiki_spaces SET folder_id = $2, updated_at = now() WHERE id = $1`, id, in.FolderID); err != nil {
		return err
	}
	return c.OK()
}

func (s *Server) wikiSpaceDelete(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, _, err = s.wikiSpace(c, id, wvOwn); err != nil {
		return err
	}
	ctx := c.Context()
	fids, err := s.wikiFileIDs(ctx, `SELECT wf.file_id FROM wiki_page_files wf JOIN wiki_pages p ON p.id = wf.page_id WHERE p.space_id = $1`, id)
	if err != nil {
		return err
	}
	if _, err := s.db.Exec(ctx, `DELETE FROM wiki_spaces WHERE id = $1`, id); err != nil {
		return err
	}
	s.wikiPurgeFiles(ctx, fids)
	s.audit(c, "wiki.space.delete", "wiki_space", id, nil)
	return c.OK()
}

// ---------------------------------------------------------------- права (ACL)

type wentry struct {
	SubjectType string `json:"subject_type"`
	SubjectID   int64  `json:"subject_id"`
	SubjectKey  string `json:"subject_key"`
	Level       int    `json:"level"`
	Name        string `json:"name,omitempty"`
}

var wikiRoleKeys = map[string]bool{"user": true, "editor": true, "head": true, "admin": true}

func (s *Server) wikiACLEntries(ctx context.Context, space int64, page *int64) (json.RawMessage, error) {
	return s.arr(ctx, `SELECT a.subject_type, a.subject_id, a.subject_key, a.level,
		CASE a.subject_type WHEN 'user' THEN (SELECT full_name FROM users WHERE id = a.subject_id)
			WHEN 'department' THEN (SELECT name FROM departments WHERE id = a.subject_id)
			WHEN 'group' THEN (SELECT name FROM user_groups WHERE id = a.subject_id) ELSE '' END AS name
		FROM wiki_acl a WHERE a.space_id = $1 AND a.page_id IS NOT DISTINCT FROM $2::bigint ORDER BY a.subject_type, 5, a.id`, space, page)
}

func (s *Server) wikiACLParse(in []wentry) (types []string, ids []int64, keys []string, lvls []int32) {
	types, ids, keys, lvls = []string{}, []int64{}, []string{}, []int32{}
	seen := map[string]bool{}
	for _, e := range in {
		if len(types) >= 200 {
			break
		}
		lv := int32(e.Level)
		if lv == 2 {
			lv = 1
		}
		if lv != 1 && lv != 3 && lv != 4 {
			continue
		}
		switch e.SubjectType {
		case "all":
			e.SubjectID, e.SubjectKey = 0, ""
		case "role":
			if !wikiRoleKeys[e.SubjectKey] {
				continue
			}
			e.SubjectID = 0
		case "user", "department", "group":
			if e.SubjectID <= 0 {
				continue
			}
			e.SubjectKey = ""
		default:
			continue
		}
		k := fmt.Sprint(e.SubjectType, "|", e.SubjectID, "|", e.SubjectKey)
		if seen[k] {
			continue
		}
		seen[k] = true
		types, ids, keys, lvls = append(types, e.SubjectType), append(ids, e.SubjectID), append(keys, e.SubjectKey), append(lvls, lv)
	}
	return
}

func (s *Server) wikiSpaceACLGet(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	sp, _, err := s.wikiSpace(c, id, wvOwn)
	if err != nil {
		return err
	}
	entries, err := s.wikiACLEntries(c.Context(), id, nil)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"resource": map[string]any{"visibility": sp.Visibility, "owner_id": sp.OwnerID}, "entries": entries})
}

func (s *Server) wikiSpaceACLPut(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Visibility string   `json:"visibility"`
		Entries    []wentry `json:"entries"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if _, _, err = s.wikiSpace(c, id, wvOwn); err != nil {
		return err
	}
	if in.Visibility != "company" {
		in.Visibility = "restricted"
	}
	types, ids, keys, lvls := s.wikiACLParse(in.Entries)
	ctx := c.Context()
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `UPDATE wiki_spaces SET visibility = $2, updated_at = now() WHERE id = $1`, id, in.Visibility); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `DELETE FROM wiki_acl WHERE space_id = $1 AND page_id IS NULL`, id); err != nil {
			return err
		}
		_, err := tx.Exec(ctx, `INSERT INTO wiki_acl (space_id, page_id, subject_type, subject_id, subject_key, level)
			SELECT $1, NULL, t, i, k, l FROM unnest($2::text[], $3::bigint[], $4::text[], $5::smallint[]) AS x(t, i, k, l)`, id, types, ids, keys, lvls)
		return err
	})
	if err != nil {
		return err
	}
	s.audit(c, "wiki.space.acl", "wiki_space", id, map[string]any{"visibility": in.Visibility, "entries": len(types)})
	return c.OK()
}

// canManagePage — управлять правами страницы: управляющий (уровень 4) либо её владелец.
func canManagePage(p *wpage, uid int64) bool {
	return p.Level >= wvOwn || (p.OwnerID != nil && *p.OwnerID == uid && p.Level >= wvEdit)
}

func (s *Server) wikiPageACLGet(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	p, _, err := s.wikiPageAt(c, id, wvEdit)
	if err != nil {
		return err
	}
	if !canManagePage(p, c.U.ID) {
		return errForbidden
	}
	entries, err := s.wikiACLEntries(c.Context(), p.SpaceID, &p.ID)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"resource": map[string]any{"restricted": p.Visibility == "restricted", "owner_id": p.OwnerID}, "entries": entries})
}

func (s *Server) wikiPageACLPut(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Restricted bool     `json:"restricted"`
		Entries    []wentry `json:"entries"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	p, _, err := s.wikiPageAt(c, id, wvEdit)
	if err != nil {
		return err
	}
	if !canManagePage(p, c.U.ID) {
		return errForbidden
	}
	types, ids, keys, lvls := s.wikiACLParse(in.Entries)
	if !in.Restricted { // обычная страница: имеют смысл только дополнительные редакторы ветки
		t2, i2, k2, l2 := []string{}, []int64{}, []string{}, []int32{}
		for i := range types {
			if lvls[i] >= 3 {
				t2, i2, k2, l2 = append(t2, types[i]), append(i2, ids[i]), append(k2, keys[i]), append(l2, lvls[i])
			}
		}
		types, ids, keys, lvls = t2, i2, k2, l2
	}
	vis := "inherit"
	if in.Restricted {
		vis = "restricted"
	}
	ctx := c.Context()
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `UPDATE wiki_pages SET visibility = $2 WHERE id = $1`, id, vis); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `DELETE FROM wiki_acl WHERE page_id = $1`, id); err != nil {
			return err
		}
		_, err := tx.Exec(ctx, `INSERT INTO wiki_acl (space_id, page_id, subject_type, subject_id, subject_key, level)
			SELECT $1, $2, t, i, k, l FROM unnest($3::text[], $4::bigint[], $5::text[], $6::smallint[]) AS x(t, i, k, l)`, p.SpaceID, id, types, ids, keys, lvls)
		return err
	})
	if err != nil {
		return err
	}
	s.audit(c, "wiki.page.acl", "wiki_page", id, map[string]any{"restricted": in.Restricted, "entries": len(types)})
	return c.OK()
}
