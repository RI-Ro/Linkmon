package server

import (
	"os"
	"strconv"
	"strings"
	"time"
)

type Config struct {
	Addr           string
	DatabaseURL    string
	RedisURL       string
	DataDir        string
	PGPoolMax      int
	MaxUploadMB    int64
	FilesAccel     bool   // X-Accel-Redirect для внешнего nginx (по умолчанию выключено: файлы отдаёт само приложение)
	StaticDir      string // STATIC_DIR: каталог собранного фронтенда вместо встроенного (удобно при разработке)
	CookieSecure   bool
	SessionTTL     time.Duration
	AllowedOrigins []string
	SeedDemo       bool
	AdminEmail     string
	AdminPassword  string
	InstanceID     string

	// --- несколько ЦОДов ---
	DCID          string   // имя ЦОДа (main, dc2 …): префикс локальных ключей Redis, владелец локальных очередей
	ReplicaURL    string   // DATABASE_REPLICA_URL: локальная read-реплика (читающие запросы), пусто = читаем с основной
	Realtime      string   // redis | pg: чем доставлять события между экземплярами (pg — между ЦОДами)
	SessionStore  string   // redis | pg: где хранить сессии (pg — общие для ЦОДов)
	SecretKey     string   // ключ шифрования паролей LDAP-подключений
	FilePeers     []string // базовые URL других ЦОДов для подтягивания файлов «по требованию»
	InternalToken string   // общий секрет для /internal/blob между ЦОДами
	TZ            string   // часовой пояс для повторяющихся событий

	// --- мониторинг (mon_*.go)
	SlowRequestMS int // порог «медленного» HTTP-запроса (флаг slow в access-логе), SLOW_REQUEST_MS
	SlowSQLMS     int // порог лога медленного SQL, SLOW_SQL_MS
}

func env(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

func envInt(k string, def int) int {
	if v, err := strconv.Atoi(os.Getenv(k)); err == nil {
		return v
	}
	return def
}

func envBool(k string, def bool) bool {
	switch strings.ToLower(os.Getenv(k)) {
	case "1", "true", "yes", "on":
		return true
	case "0", "false", "no", "off":
		return false
	}
	return def
}

func LoadConfig() Config {
	host, _ := os.Hostname()
	c := Config{
		Addr:          env("HTTP_ADDR", ":8080"),
		DatabaseURL:   env("DATABASE_URL", "postgres://corpnet:corpnet@localhost:5432/corpnet?sslmode=disable"),
		RedisURL:      env("REDIS_URL", "redis://localhost:6379/0"),
		DataDir:       env("DATA_DIR", "./data"),
		PGPoolMax:     envInt("PG_POOL_MAX", 12),
		MaxUploadMB:   int64(envInt("MAX_UPLOAD_MB", 200)),
		FilesAccel:    envBool("FILES_ACCEL", false),
		StaticDir:     env("STATIC_DIR", ""),
		CookieSecure:  envBool("COOKIE_SECURE", false),
		SessionTTL:    time.Duration(envInt("SESSION_TTL_HOURS", 24*14)) * time.Hour,
		SeedDemo:      envBool("SEED_DEMO", true),
		AdminEmail:    env("ADMIN_EMAIL", "admin@corpnet.local"),
		AdminPassword: env("ADMIN_PASSWORD", "admin12345"),
		InstanceID:    env("INSTANCE_ID", host),
		DCID:          env("DC_ID", "main"),
		ReplicaURL:    env("DATABASE_REPLICA_URL", ""),
		Realtime:      strings.ToLower(env("REALTIME_MODE", "redis")),
		SessionStore:  strings.ToLower(env("SESSION_STORE", "redis")),
		SecretKey:     env("SECRET_KEY", "change-me-corpnet-secret"),
		InternalToken: env("INTERNAL_TOKEN", ""),
		TZ:            env("TZ", "Europe/Moscow"),
		SlowRequestMS: envInt("SLOW_REQUEST_MS", 1000),
		SlowSQLMS:     envInt("SLOW_SQL_MS", 200),
	}
	if p := os.Getenv("FILE_PEERS"); p != "" {
		for _, x := range strings.Split(p, ",") {
			if x = strings.TrimRight(strings.TrimSpace(x), "/"); x != "" {
				c.FilePeers = append(c.FilePeers, x)
			}
		}
	}
	if o := os.Getenv("ALLOWED_ORIGINS"); o != "" {
		c.AllowedOrigins = strings.Split(o, ",")
	}
	return c
}
