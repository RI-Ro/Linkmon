package server

import (
	"context"
	"crypto/rand"
	"encoding/json"
	"fmt"
	"math/big"
	"net/http"
	"reflect"
	"sort"

	"github.com/jackc/pgx/v5"
)

// Управление пользователями (админка → «Пользователи»).
//
//   - admin  — все пользователи, любые роли.
//   - editor — пользователи своей области (подразделение редактора + дочерние + editor_departments): создание, правка, блокировка,
//     мягкое удаление, сброс пароля. Роль не выше «редактор»; администраторов и пользователей вне области трогать нельзя;
//     себя через этот раздел менять нельзя; переносить пользователя можно только внутри своей области;
//     привилегии «публикация на всю компанию», «график отпусков» и «ответственный за обучение» выдаёт только администратор.
//
// Каждое изменение пишется в audit_log в той же транзакции (кто, кого, diff до/после без паролей, IP, request id).

func (s *Server) registerUserMgmt(m *http.ServeMux) {
	const E, A = "editor", "admin"
	m.HandleFunc("GET /api/manage/users", s.h(E, s.mgmtListUsers))
	m.HandleFunc("POST /api/users", s.h(E, s.createUser))
	m.HandleFunc("PUT /api/users/{id}", s.h(E, s.updateUser))
	m.HandleFunc("DELETE /api/users/{id}", s.h(E, s.deleteUser))
	m.HandleFunc("POST /api/users/{id}/password", s.h(E, s.resetUserPassword))
	m.HandleFunc("GET /api/admin/audit/export", s.h(A, s.adminAuditExport))
}

// ---------------------------------------------------------------- target & snapshots

type mgTarget struct {
	ID       int64
	Role     string
	Dept     *int64
	Ldap     bool
	Deleted  bool
	CanVac   bool
	CoNews   bool
	EdDepts  []int64
	Login    string
	FullName string
}

type pgQuerier interface {
	QueryRow(ctx context.Context, sql string, args ...any) pgx.Row
}

// lockTarget читает пользователя с блокировкой строки (проверка прав и изменение — в одной транзакции).
func lockTarget(ctx context.Context, tx pgx.Tx, id int64) (*mgTarget, error) {
	t := &mgTarget{ID: id}
	err := tx.QueryRow(ctx, `SELECT role, department_id, ldap_server_id IS NOT NULL, deleted_at IS NOT NULL, can_vacations, company_news, login, full_name,
		coalesce((SELECT array_agg(department_id) FROM editor_departments e WHERE e.user_id = u.id), '{}'::bigint[])
		FROM users u WHERE id = $1 FOR UPDATE`, id).Scan(&t.Role, &t.Dept, &t.Ldap, &t.Deleted, &t.CanVac, &t.CoNews, &t.Login, &t.FullName, &t.EdDepts)
	if err != nil {
		return nil, err
	}
	return t, nil
}

// check — вправе ли исполнитель управлять этим пользователем. Несуществующий/удалённый → 404, чужой → 403.
func (t *mgTarget) check(c *Ctx, sc *scope) error {
	if t.Deleted {
		return errNotFound
	}
	if c.U.IsAdmin() {
		return nil
	}
	if t.ID == c.U.ID {
		return &apiError{403, "Свою учётную запись редактируйте в профиле"}
	}
	if t.Role == "admin" || t.Dept == nil || !sc.Has(*t.Dept) {
		return errForbidden
	}
	for _, d := range t.EdDepts { // редактор с правами за пределами вашей области вам не подчинён
		if !sc.Has(d) {
			return errForbidden
		}
	}
	return nil
}

// restrict — ограничения на входные данные для редактора (администратору всё можно).
func (in *userIn) restrict(c *Ctx, sc *scope, t *mgTarget) error {
	if c.U.IsAdmin() {
		return nil
	}
	if in.Role != "user" && in.Role != "editor" {
		return &apiError{403, "Редактор может назначать только роли «Сотрудник» и «Редактор»"}
	}
	if in.DepartmentID == nil {
		return badReq("Укажите подразделение")
	}
	if !sc.Has(*in.DepartmentID) {
		return &apiError{403, "Подразделение вне вашей области управления"}
	}
	for _, d := range in.EditorDepartments {
		if !sc.Has(d) {
			return &apiError{403, "Подразделение редактирования вне вашей области управления"}
		}
	}
	// привилегии, расширяющие права за пределы области, выдаёт только администратор: значения остаются прежними
	in.LearningManager, in.LearningDepts = nil, nil
	if t == nil {
		in.CanVacations, in.CompanyNews = false, false
	} else {
		in.CanVacations, in.CompanyNews = t.CanVac, t.CoNews
	}
	return nil
}

const snapSQL = `SELECT to_jsonb(x) FROM (SELECT u.login, u.email, u.first_name, u.last_name, u.middle_name, u.job_title, u.extra_info, u.department_id,
		u.role, u.phone1, u.phone2, u.phone3, u.phone4, coalesce(to_char(u.birthday, 'YYYY-MM-DD'), '') AS birthday, u.avatar, u.is_head,
		u.can_vacations, u.company_news, u.learning_manager, u.blocked, u.deleted_at IS NOT NULL AS deleted,
		coalesce((SELECT array_agg(e.department_id ORDER BY e.department_id) FROM editor_departments e WHERE e.user_id = u.id), '{}'::bigint[]) AS editor_departments,
		coalesce((SELECT array_agg(e.department_id ORDER BY e.department_id) FROM learning_manager_departments e WHERE e.user_id = u.id), '{}'::bigint[]) AS learning_departments
	FROM users u WHERE u.id = $1) x`

// userSnap — состояние пользователя для журнала (без пароля и служебных хэшей).
func userSnap(ctx context.Context, q pgQuerier, id int64) (map[string]any, error) {
	var raw []byte
	if err := q.QueryRow(ctx, snapSQL, id).Scan(&raw); err != nil {
		return nil, err
	}
	m := map[string]any{}
	return m, json.Unmarshal(raw, &m)
}

// snapDiff — {поле: {from, to}} для изменившихся полей.
func snapDiff(before, after map[string]any) map[string]map[string]any {
	out := map[string]map[string]any{}
	for k, v := range after {
		if !reflect.DeepEqual(before[k], v) {
			out[k] = map[string]any{"from": before[k], "to": v}
		}
	}
	return out
}

func diffKeys(d map[string]map[string]any) []string {
	ks := make([]string, 0, len(d))
	for k := range d {
		ks = append(ks, k)
	}
	sort.Strings(ks)
	return ks
}

func (t *mgTarget) label() string { return fmt.Sprintf("%s (%s)", t.FullName, t.Login) }

// ---------------------------------------------------------------- list

func (s *Server) mgmtListUsers(c *Ctx) error {
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	page, per, off := c.Page(20, 100)
	w := &whereBuilder{}
	w.raw("u.deleted_at IS NULL")
	if !sc.All {
		w.add("u.department_id = ANY(?::bigint[])", sc.IDs)
		w.raw("u.role <> 'admin'")
	}
	s.userSearch(ctx, w, c.Q("q"))
	if v := c.QInt64("department"); v > 0 {
		if !sc.Has(v) {
			return &apiError{403, "Подразделение вне вашей области управления"}
		}
		w.add("u.department_id IN "+deptSubtree("?"), v)
	}
	if c.Q("heads") == "1" {
		w.raw("u.is_head")
	}
	if r := c.Q("role"); roleRank(r) > 0 {
		w.add("u.role = ?", r)
	}
	switch c.Q("state") {
	case "blocked":
		w.raw("u.blocked")
	case "active":
		w.raw("NOT u.blocked")
	}
	var total int
	if err := s.ro.QueryRow(ctx, "SELECT count(*) FROM users u WHERE "+w.String(), w.args...).Scan(&total); err != nil {
		return err
	}
	n := w.n()
	args := append(w.args, per, off, sc.All, sc.IDs, c.U.ID)
	items, err := s.arr2(ctx, `SELECT `+userCols+`,
		(SELECT coalesce(json_agg(e.department_id), '[]') FROM editor_departments e WHERE e.user_id = u.id) AS editor_departments,
		(SELECT coalesce(json_agg(e.department_id), '[]') FROM learning_manager_departments e WHERE e.user_id = u.id) AS learning_departments,
		(u.id <> $`+fmt.Sprint(n+5)+`::bigint AND ($`+fmt.Sprint(n+3)+`::boolean OR (u.role <> 'admin' AND NOT EXISTS (
			SELECT 1 FROM editor_departments e WHERE e.user_id = u.id AND NOT (e.department_id = ANY($`+fmt.Sprint(n+4)+`::bigint[])))))) AS manageable`+
		userFrom+` WHERE `+w.String()+
		fmt.Sprintf(` ORDER BY `+userOrder+` LIMIT $%d OFFSET $%d`, n+1, n+2), args...)
	if err != nil {
		return err
	}
	return c.Raw(200, []byte(fmt.Sprintf(`{"items":%s,"total":%d,"page":%d,"per":%d}`, items, total, page, per)))
}

// ---------------------------------------------------------------- create / update / delete

func (s *Server) createUser(c *Ctx) error {
	var in userIn
	if err := c.Decode(&in); err != nil {
		return err
	}
	if err := in.validate(true); err != nil {
		return err
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	if err := in.restrict(c, sc, nil); err != nil {
		return err
	}
	hash, err := hashPassword(in.Password)
	if err != nil {
		return err
	}
	var id int64
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if err := tx.QueryRow(ctx, `INSERT INTO users (login, email, password_hash, first_name, last_name, middle_name, job_title, extra_info, department_id, role,
				phone1, phone2, phone3, phone4, birthday, avatar, is_head, can_vacations, company_news)
			VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, NULLIF($15, '')::date, $16, $17, $18, $19) RETURNING id`,
			in.Login, in.Email, hash, in.FirstName, in.LastName, in.MiddleName, in.JobTitle, in.ExtraInfo, in.DepartmentID, in.Role,
			in.Phone1, in.Phone2, in.Phone3, in.Phone4, in.Birthday, in.Avatar, in.IsHead, in.CanVacations, in.CompanyNews).Scan(&id); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `INSERT INTO calendars (name, kind, owner_id, visibility, color) VALUES ('Мой календарь', 'personal', $1, 'restricted', '#286b9e')`, id); err != nil {
			return err
		}
		if err := setEditorDepts(ctx, tx, id, in.Role, in.EditorDepartments); err != nil {
			return err
		}
		if err := setLearningManager(ctx, tx, id, in.LearningManager, in.LearningDepts); err != nil {
			return err
		}
		after, err := userSnap(ctx, tx, id)
		if err != nil {
			return err
		}
		return s.auditTx(ctx, tx, c, "user.create", "user", id, map[string]any{
			"target": in.LastName + " " + in.FirstName + " (" + in.Login + ")", "after": after})
	})
	if err != nil {
		return err
	}
	b, err := s.userJSON(ctx, id)
	if err != nil {
		return err
	}
	return c.Raw(201, b)
}

func (s *Server) updateUser(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in userIn
	if err := c.Decode(&in); err != nil {
		return err
	}
	if err := in.validate(false); err != nil {
		return err
	}
	blocked := in.Blocked != nil && *in.Blocked
	if id == c.U.ID && !c.U.IsAdmin() {
		return &apiError{403, "Свою учётную запись редактируйте в профиле"}
	}
	if id == c.U.ID && (blocked || in.Role != "admin") {
		return badReq("Нельзя заблокировать себя или снять с себя права администратора")
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	var hash string
	if in.Password != "" {
		if hash, err = hashPassword(in.Password); err != nil {
			return err
		}
	}
	var pwSet, kill bool
	err = s.tx(ctx, func(tx pgx.Tx) error {
		t, err := lockTarget(ctx, tx, id)
		if err != nil {
			return err
		}
		if err := t.check(c, sc); err != nil {
			return err
		}
		if err := in.restrict(c, sc, t); err != nil {
			return err
		}
		before, err := userSnap(ctx, tx, id)
		if err != nil {
			return err
		}
		if err := s.lockProfile(ctx, id, &in.profile); err != nil { // поля, управляемые LDAP, не меняются
			return err
		}
		if err := in.profile.validate(); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE users SET login = CASE WHEN $2 THEN login ELSE $3 END, email = $4, first_name = $5, last_name = $6, middle_name = $7,
			job_title = $8, extra_info = $9, department_id = $10, role = $11, phone1 = $12, phone2 = $13, phone3 = $14, phone4 = $15,
			birthday = NULLIF($16, '')::date, avatar = $17, is_head = $18, can_vacations = $19, company_news = $20,
			blocked = $21, ldap_blocked = CASE WHEN $21 THEN ldap_blocked ELSE false END, updated_at = now() WHERE id = $1`,
			id, t.Ldap, in.Login, in.Email, in.FirstName, in.LastName, in.MiddleName, in.JobTitle, in.ExtraInfo, in.DepartmentID, in.Role,
			in.Phone1, in.Phone2, in.Phone3, in.Phone4, in.Birthday, in.Avatar, in.IsHead, in.CanVacations, in.CompanyNews, blocked); err != nil {
			return err
		}
		if in.EditorDepartments != nil || in.Role != "editor" {
			if err := setEditorDepts(ctx, tx, id, in.Role, in.EditorDepartments); err != nil {
				return err
			}
		}
		if err := setLearningManager(ctx, tx, id, in.LearningManager, in.LearningDepts); err != nil {
			return err
		}
		if hash != "" && !t.Ldap {
			if _, err := tx.Exec(ctx, `UPDATE users SET password_hash = $2 WHERE id = $1`, id, hash); err != nil {
				return err
			}
			pwSet = true
		}
		after, err := userSnap(ctx, tx, id)
		if err != nil {
			return err
		}
		diff := snapDiff(before, after)
		keys := diffKeys(diff)
		if pwSet {
			keys = append(keys, "password")
		}
		action := "user.update"
		if len(keys) == 1 {
			switch keys[0] {
			case "blocked":
				action = "user.unblock"
				if blocked {
					action = "user.block"
				}
			case "password":
				action = "user.password_reset"
			case "role":
				action = "user.role_change"
			}
		}
		kill = pwSet || blocked
		return s.auditTx(ctx, tx, c, action, "user", id, map[string]any{"target": t.label(), "changes": diff, "password_reset": pwSet})
	})
	if err != nil {
		return err
	}
	if kill {
		s.killSessions(ctx, id)
	}
	s.dropUserCache(ctx, id)
	b, err := s.userJSON(ctx, id)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// deleteUser — мягкое удаление: строка остаётся (авторство новостей, комментариев, файлов сохраняется), вход закрыт,
// из всех списков скрыта; логин и почта (у локальных учёток) освобождаются.
func (s *Server) deleteUser(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if id == c.U.ID {
		return badReq("Нельзя удалить самого себя")
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	err = s.tx(ctx, func(tx pgx.Tx) error {
		t, err := lockTarget(ctx, tx, id)
		if err != nil {
			return err
		}
		if err := t.check(c, sc); err != nil {
			return err
		}
		before, err := userSnap(ctx, tx, id)
		if err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE users SET deleted_at = now(), blocked = true, ldap_blocked = false, updated_at = now(),
			login = CASE WHEN ldap_server_id IS NULL THEN login || '~del' || id::text ELSE login END,
			email = CASE WHEN ldap_server_id IS NULL THEN '' ELSE email END WHERE id = $1`, id); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE departments SET head_id = NULL WHERE head_id = $1`, id); err != nil {
			return err
		}
		return s.auditTx(ctx, tx, c, "user.delete", "user", id, map[string]any{"target": t.label(), "before": before, "soft": true})
	})
	if err != nil {
		return err
	}
	s.killSessions(ctx, id)
	s.dropUserCache(ctx, id)
	s.bumpNews(ctx)
	return c.OK()
}

// resetUserPassword — сброс пароля: свой пароль (поле password) или сгенерированный (возвращается один раз).
func (s *Server) resetUserPassword(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Password string `json:"password"`
	}
	if c.R.ContentLength != 0 {
		if err := c.Decode(&in); err != nil {
			return err
		}
	}
	gen := in.Password == ""
	if gen {
		in.Password = randPassword(12)
	} else if len(in.Password) < 8 {
		return badReq("Пароль должен содержать не менее 8 символов")
	}
	hash, err := hashPassword(in.Password)
	if err != nil {
		return err
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	err = s.tx(ctx, func(tx pgx.Tx) error {
		t, err := lockTarget(ctx, tx, id)
		if err != nil {
			return err
		}
		if err := t.check(c, sc); err != nil {
			return err
		}
		if t.Ldap {
			return badReq("Пароль пользователя из LDAP задаётся в каталоге")
		}
		if _, err := tx.Exec(ctx, `UPDATE users SET password_hash = $2, updated_at = now() WHERE id = $1`, id, hash); err != nil {
			return err
		}
		return s.auditTx(ctx, tx, c, "user.password_reset", "user", id, map[string]any{"target": t.label(), "generated": gen})
	})
	if err != nil {
		return err
	}
	s.killSessions(ctx, id)
	s.dropUserCache(ctx, id)
	if gen {
		return c.JSON(200, map[string]any{"ok": true, "password": in.Password})
	}
	return c.OK()
}

func randPassword(n int) string {
	const alpha = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
	out := make([]byte, n)
	for i := range out {
		x, _ := rand.Int(rand.Reader, big.NewInt(int64(len(alpha))))
		out[i] = alpha[x.Int64()]
	}
	return string(out)
}
