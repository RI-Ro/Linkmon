package server

import (
	"context"
	"errors"
	"log/slog"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

// ---------------------------------------------------------------- pgx

type pgTrace struct {
	pool   string
	slowMS int
	log    *slog.Logger
}

type pgTraceKey struct{}
type pgTraceVal struct {
	t   time.Time
	sql string
}

// NewPGTracer возвращает pgx.QueryTracer: время и число SQL на запрос (в monReq), гистограмма и лог медленных SQL.
// Подключается в cmd/server: pcfg.ConnConfig.Tracer = server.NewPGTracer("primary", cfg, log).
func NewPGTracer(pool string, cfg Config, log *slog.Logger) pgx.QueryTracer {
	return &pgTrace{pool: pool, slowMS: cfg.SlowSQLMS, log: log}
}

func (t *pgTrace) TraceQueryStart(ctx context.Context, _ *pgx.Conn, d pgx.TraceQueryStartData) context.Context {
	return context.WithValue(ctx, pgTraceKey{}, pgTraceVal{t: time.Now(), sql: d.SQL})
}

func (t *pgTrace) TraceQueryEnd(ctx context.Context, _ *pgx.Conn, d pgx.TraceQueryEndData) {
	v, ok := ctx.Value(pgTraceKey{}).(pgTraceVal)
	if !ok {
		return
	}
	dur := time.Since(v.t)
	monObs(&mon.dbDur, t.pool, dur)
	if m := monFrom(ctx); m != nil {
		m.dbN.Add(1)
		m.dbNs.Add(int64(dur))
	}
	if d.Err != nil && !errors.Is(d.Err, pgx.ErrNoRows) && !errors.Is(d.Err, context.Canceled) {
		monCnt(&mon.dbErrs, t.pool, 1)
	}
	if dur.Milliseconds() >= int64(t.slowMS) {
		monCnt(&mon.dbSlow, t.pool, 1)
		// текст SQL без аргументов (в них могут быть персональные данные)
		q := strings.Join(strings.Fields(v.sql), " ")
		attrs := []slog.Attr{slog.String("pool", t.pool), slog.Float64("duration_ms", float64(dur.Microseconds())/1000), slog.String("sql", trunc(q, 300))}
		if id := RequestID(ctx); id != "" {
			attrs = append(attrs, slog.String("request_id", id))
		}
		t.log.LogAttrs(ctx, slog.LevelWarn, "slow sql", attrs...)
	}
}

// ---------------------------------------------------------------- redis

// monRedisProbe измеряет задержку Redis (PING) раз в несколько секунд: corpnet_redis_ping_seconds.
// Хук go-redis на каждую команду не используется: сборка проекта должна работать без правок go-redis.
func (s *Server) monRedisProbe(ctx context.Context) {
	c, cancel := context.WithTimeout(ctx, 2*time.Second)
	defer cancel()
	t := time.Now()
	err := s.rdb.Ping(c).Err()
	monObs(&mon.redisDur, "ping", time.Since(t))
	if err != nil && ctx.Err() == nil {
		monCnt(&mon.redisErrs, "ping", 1)
	}
}
