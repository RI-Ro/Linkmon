package server

import (
	"bytes"
	"context"
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"path"
	"path/filepath"
	"regexp"
	"strconv"
	"time"
)

// Серверный предпросмотр PDF (фолбэк, когда браузер не может открыть файл через pdf.js): страницы рендерит pdftoppm в JPEG,
// результат кэшируется на диске (DATA_DIR/pvc, ключ — имя файла в хранилище + страница + ширина), поэтому повторные
// запросы не запускают процесс. Права — те же, что у скачивания (fileBaseOKSQL / fileViaNewsSQL).
//
//	GET /api/files/{id}/pdf/info          → {"pages":N}
//	GET /api/files/{id}/pdf/page/{n}?w=900 → image/jpeg

var (
	pvSem    = make(chan struct{}, 2) // не более двух одновременных рендеров на экземпляр
	pvPagesR = regexp.MustCompile(`(?m)^Pages:\s+(\d+)`)
)

const pvTimeout = 30 * time.Second

func (s *Server) registerFilePreview(m *http.ServeMux) {
	m.HandleFunc("GET /api/files/{id}/pdf/info", s.h("user", s.pdfInfoAPI))
	m.HandleFunc("GET /api/files/{id}/pdf/page/{n}", s.h("user", s.pdfPageAPI))
}

// pdfSource проверяет доступ и возвращает имя файла в хранилище (только PDF).
func (s *Server) pdfSource(c *Ctx) (id int64, storage string, err error) {
	if id, err = c.ID("id"); err != nil {
		return
	}
	var base, viaNews bool
	var mime, name string
	err = s.db.QueryRow(c.Context(), `SELECT f.storage, f.mime, f.name, `+fileBaseOKSQL("f")+`, `+fileViaNewsSQL("f")+`
		FROM files f WHERE f.id = $1 AND f.external_url = ''`, id, c.U.ID, c.U.Dept, c.U.IsAdmin()).Scan(&storage, &mime, &name, &base, &viaNews)
	if err != nil {
		return 0, "", errNotFound
	}
	if !base && !viaNews {
		return 0, "", errForbidden
	}
	if fileKind(name, mime) != "pdf" || storage == "" || filepath.Base(storage) != storage {
		return 0, "", badReq("Это не PDF")
	}
	if err = s.ensureLocal(c.Context(), false, storage); err != nil {
		return
	}
	return
}

func (s *Server) pdfInfoAPI(c *Ctx) error {
	_, storage, err := s.pdfSource(c)
	if err != nil {
		return err
	}
	bin, err := exec.LookPath("pdfinfo")
	if err != nil {
		return &apiError{503, "Серверный просмотр недоступен (нет poppler-utils)"}
	}
	ctx, cancel := context.WithTimeout(c.Context(), pvTimeout)
	defer cancel()
	out, err := exec.CommandContext(ctx, bin, filepath.Join(s.dir(false), path.Base(storage))).Output()
	if err != nil {
		return &apiError{422, "Не удалось прочитать PDF"}
	}
	n := 0
	if m := pvPagesR.FindSubmatch(out); m != nil {
		n, _ = strconv.Atoi(string(m[1]))
	}
	c.W.Header().Set("Cache-Control", "private, max-age=3600")
	return c.JSON(200, map[string]any{"pages": n})
}

func (s *Server) pdfPageAPI(c *Ctx) error {
	_, storage, err := s.pdfSource(c)
	if err != nil {
		return err
	}
	n, _ := strconv.Atoi(c.R.PathValue("n"))
	if n < 1 || n > 5000 {
		return badReq("Неверный номер страницы")
	}
	w := min(max(c.QInt("w", 900), 200), 2000)
	w = (w + 99) / 100 * 100 // округление до 100 px: меньше вариантов в кэше
	bin, err := exec.LookPath("pdftoppm")
	if err != nil {
		return &apiError{503, "Серверный просмотр недоступен (нет poppler-utils)"}
	}
	cdir := filepath.Join(s.cfg.DataDir, "pvc")
	if err := os.MkdirAll(cdir, 0o755); err != nil {
		return err
	}
	cached := filepath.Join(cdir, fmt.Sprintf("%s.%d.%d.jpg", storage, n, w))
	if _, err := os.Stat(cached); err != nil {
		select {
		case pvSem <- struct{}{}:
			defer func() { <-pvSem }()
		case <-c.Context().Done():
			return c.Context().Err()
		}
		ctx, cancel := context.WithTimeout(c.Context(), pvTimeout)
		defer cancel()
		tmp := cached + "." + randName(4)
		var stderr bytes.Buffer
		cmd := exec.CommandContext(ctx, bin, "-jpeg", "-jpegopt", "quality=82", "-f", strconv.Itoa(n), "-l", strconv.Itoa(n),
			"-scale-to-x", strconv.Itoa(w), "-scale-to-y", "-1", "-singlefile", filepath.Join(s.dir(false), path.Base(storage)), tmp)
		cmd.Stderr = &limitedWriter{w: &stderr, n: 512}
		if err := cmd.Run(); err != nil {
			os.Remove(tmp + ".jpg")
			return &apiError{422, "Не удалось отрисовать страницу"}
		}
		if err := os.Rename(tmp+".jpg", cached); err != nil {
			return err
		}
	}
	f, err := os.Open(cached)
	if err != nil {
		return err
	}
	defer f.Close()
	st, _ := f.Stat()
	h := c.W.Header()
	h.Set("Content-Type", "image/jpeg")
	h.Set("Cache-Control", "private, max-age=86400")
	h.Set("Content-Security-Policy", "default-src 'none'; sandbox")
	http.ServeContent(c.W, c.R, "", st.ModTime(), f)
	return nil
}
