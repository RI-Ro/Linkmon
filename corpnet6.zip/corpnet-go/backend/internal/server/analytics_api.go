package server

// Аналитика: ОТЧЁТЫ. Все запросы идут по rollup-таблицам (stats_daily, news_stats_daily, search_daily) и индексам,
// читают с реплики (s.ro) и кэшируются в Redis на 2–5 минут с ключом по параметрам. Доступ:
//   - admin — все отчёты;
//   - editor — только /content (охват и вовлечение новостей его области из scope.go), остальное 403;
//   - user — 403 на всё, кроме сбора (pv, search-click).

import (
	"context"
	"crypto/sha1"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"
)

func (s *Server) registerAnalytics(m *http.ServeMux) {
	const U, E, A = "user", "editor", "admin"
	m.HandleFunc("POST /api/analytics/pv", s.h(U, s.anPageview))
	m.HandleFunc("POST /api/analytics/search-click", s.h(U, s.anSearchClick))
	m.HandleFunc("GET /api/analytics/overview", s.h(A, s.anOverview))
	m.HandleFunc("GET /api/analytics/audience", s.h(A, s.anAudience))
	m.HandleFunc("GET /api/analytics/content", s.h(E, s.anContent))
	m.HandleFunc("GET /api/analytics/engagement", s.h(A, s.anEngagement))
	m.HandleFunc("GET /api/analytics/search", s.h(A, s.anSearch))
	m.HandleFunc("POST /api/analytics/search/resolve", s.h(A, s.anSearchResolve))
	m.HandleFunc("GET /api/analytics/search/users", s.h(A, s.anSearchWho))
	m.HandleFunc("GET /api/analytics/search/export", s.h(A, s.anSearchExport))
	m.HandleFunc("GET /api/analytics/sections", s.h(A, s.anSections2))
	m.HandleFunc("GET /api/analytics/editors", s.h(A, s.anEditors))
	m.HandleFunc("GET /api/analytics/modules", s.h(A, s.anModules))
	m.HandleFunc("GET /api/analytics/meta", s.h(E, s.anMeta))
}

// ---------------------------------------------------------------- период, кэш, вспомогательное

type anRange struct {
	From, To, PFrom, PTo string
	Days                 int
	Compare              bool
}

func (r *anRange) key() string { return r.From + "_" + r.To + "_" + strconv.FormatBool(r.Compare) }

func (s *Server) anRange(c *Ctx) (*anRange, error) {
	loc := s.an.loc
	to := time.Now().In(loc)
	to = time.Date(to.Year(), to.Month(), to.Day(), 0, 0, 0, 0, loc)
	if v := c.Q("to"); v != "" {
		t, err := time.ParseInLocation("2006-01-02", v, loc)
		if err != nil {
			return nil, badReq("Некорректная дата окончания периода")
		}
		to = t
	}
	from := to.AddDate(0, 0, -29)
	if v := c.Q("from"); v != "" {
		t, err := time.ParseInLocation("2006-01-02", v, loc)
		if err != nil {
			return nil, badReq("Некорректная дата начала периода")
		}
		from = t
	} else if d := c.QInt("days", 0); d > 0 {
		from = to.AddDate(0, 0, -(d - 1))
	}
	if from.After(to) {
		return nil, badReq("Начало периода позже окончания")
	}
	days := int(to.Sub(from).Hours()/24+0.5) + 1
	if days > 800 {
		return nil, badReq("Период не может быть длиннее 800 дней")
	}
	r := &anRange{From: from.Format("2006-01-02"), To: to.Format("2006-01-02"), Days: days, Compare: c.Q("compare") != "0"}
	pto := from.AddDate(0, 0, -1)
	r.PTo, r.PFrom = pto.Format("2006-01-02"), pto.AddDate(0, 0, -(days-1)).Format("2006-01-02")
	return r, nil
}

func anDays(from, to string) []string {
	a, _ := time.Parse("2006-01-02", from)
	b, _ := time.Parse("2006-01-02", to)
	var out []string
	for d := a; !d.After(b); d = d.AddDate(0, 0, 1) {
		out = append(out, d.Format("2006-01-02"))
	}
	return out
}

// anCache отдаёт отчёт из Redis или строит его и кладёт в кэш. refresh=1 пропускает чтение кэша.
func (s *Server) anCache(c *Ctx, name string, ttl time.Duration, parts []string, build func(ctx context.Context) (any, error)) error {
	ctx := c.Context()
	scope := "A"
	if !c.U.IsAdmin() {
		scope = "E" + strconv.FormatInt(c.U.ID, 10)
	}
	h := sha1.Sum([]byte(strings.Join(parts, "|")))
	key := "an:c:" + name + ":" + scope + ":" + hex.EncodeToString(h[:8])
	if c.Q("refresh") != "1" {
		if b, err := s.rdb.Get(ctx, key).Bytes(); err == nil {
			c.W.Header().Set("X-Cache", "hit")
			return c.Raw(200, b)
		}
	}
	v, err := build(ctx)
	if err != nil {
		return err
	}
	b, err := json.Marshal(v)
	if err != nil {
		return err
	}
	s.rdb.Set(ctx, key, b, ttl)
	c.W.Header().Set("X-Cache", "miss")
	return c.Raw(200, b)
}

func pctDelta(cur, prev float64) *float64 {
	if prev == 0 || math.IsNaN(prev) || math.IsInf(prev, 0) {
		return nil
	}
	v := math.Round((cur-prev)/prev*1000) / 10
	return &v
}

func ratio(a, b float64) float64 {
	if b == 0 {
		return 0
	}
	return a / b
}

// ---------------------------------------------------------------- метрики из stats_daily

type anMetricSet struct {
	Days []string             `json:"days"`
	M    map[string][]float64 `json:"m"`
	Sum  map[string]float64   `json:"sum"`
}

// anMetrics возвращает дневные ряды метрик (значения всех dim и всех ЦОДов суммируются; запросы управления новостями не учитываются).
func (s *Server) anMetrics(ctx context.Context, from, to string, names ...string) (*anMetricSet, error) {
	days := anDays(from, to)
	idx := make(map[string]int, len(days))
	for i, d := range days {
		idx[d] = i
	}
	out := &anMetricSet{Days: days, M: map[string][]float64{}, Sum: map[string]float64{}}
	for _, n := range names {
		out.M[n] = make([]float64, len(days))
	}
	rows, err := s.ro.Query(ctx, `SELECT to_char(day, 'YYYY-MM-DD'), metric, sum(value)::float8 FROM stats_daily
		WHERE metric = ANY($1::text[]) AND day BETWEEN $2::text::date AND $3::text::date AND dim <> 'admin_news' GROUP BY day, metric`, names, from, to)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var d, m string
		var v float64
		if err := rows.Scan(&d, &m, &v); err != nil {
			return nil, err
		}
		if i, ok := idx[d]; ok {
			out.M[m][i] = v
			out.Sum[m] += v
		}
	}
	return out, rows.Err()
}

func (ms *anMetricSet) avg(name string) float64 { return ratio(ms.Sum[name], float64(len(ms.Days))) }

// last — последнее ненулевое значение ряда (для WAU/MAU «на конец периода»).
func (ms *anMetricSet) last(name string) float64 {
	v := ms.M[name]
	for i := len(v) - 1; i >= 0; i-- {
		if v[i] > 0 {
			return v[i]
		}
	}
	return 0
}

// ---------------------------------------------------------------- численность подразделений

type anHC struct {
	Total  int              `json:"total"`
	Sub    map[int64]int    `json:"sub"`    // с вложенными подразделениями
	Direct map[int64]int    `json:"direct"` // только прямые сотрудники
	Names  map[int64]string `json:"names"`
}

func (s *Server) anHeadcount(ctx context.Context) (*anHC, error) {
	if b, err := s.rdb.Get(ctx, "an:hc").Bytes(); err == nil {
		var h anHC
		if json.Unmarshal(b, &h) == nil {
			return &h, nil
		}
	}
	h := &anHC{Sub: map[int64]int{}, Direct: map[int64]int{}, Names: map[int64]string{}}
	if err := s.ro.QueryRow(ctx, `SELECT count(*) FROM users WHERE NOT blocked`).Scan(&h.Total); err != nil {
		return nil, err
	}
	rows, err := s.ro.Query(ctx, `SELECT department_id, count(*) FROM users WHERE NOT blocked AND department_id IS NOT NULL GROUP BY 1`)
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var id int64
		var n int
		if err := rows.Scan(&id, &n); err != nil {
			rows.Close()
			return nil, err
		}
		h.Direct[id] = n
	}
	rows.Close()
	kids := map[int64][]int64{}
	rows, err = s.ro.Query(ctx, `SELECT id, name, coalesce(parent_id, 0) FROM departments`)
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var id, p int64
		var name string
		if err := rows.Scan(&id, &name, &p); err != nil {
			rows.Close()
			return nil, err
		}
		h.Names[id] = name
		kids[p] = append(kids[p], id)
	}
	rows.Close()
	var walk func(id int64, depth int) int
	walk = func(id int64, depth int) int {
		n := h.Direct[id]
		if depth < 64 {
			for _, k := range kids[id] {
				n += walk(k, depth+1)
			}
		}
		h.Sub[id] = n
		return n
	}
	for id := range h.Names {
		if _, done := h.Sub[id]; !done {
			walk(id, 0)
		}
	}
	if b, err := json.Marshal(h); err == nil {
		s.rdb.Set(ctx, "an:hc", b, 5*time.Minute)
	}
	return h, nil
}

// arrays — численность аудитории подразделений для unnest($a::bigint[], $b::int[]).
func (h *anHC) arrays() ([]int64, []int32) {
	ids, ns := make([]int64, 0, len(h.Sub)), make([]int32, 0, len(h.Sub))
	for id, n := range h.Sub {
		ids, ns = append(ids, id), append(ns, int32(n))
	}
	return ids, ns
}

// ---------------------------------------------------------------- фильтр новостей по области

type anNF struct {
	admin  bool
	uid    int64
	ids    []int64
	dept   int64
	author int64
	cat    int64
}

func (f *anNF) scoped() bool { return !f.admin || f.dept > 0 || f.author > 0 || f.cat > 0 }

func (f *anNF) key() string {
	return fmt.Sprint(f.admin, f.uid, f.dept, f.author, f.cat)
}

// sql возвращает условие над алиасом n и его аргументы; плейсхолдеры нумеруются с base.
func (f *anNF) sql(base int) (string, []any) {
	conds, args := []string{"TRUE"}, []any{}
	add := func(v any) string { args = append(args, v); return "$" + strconv.Itoa(base+len(args)-1) }
	if !f.admin {
		conds = append(conds, fmt.Sprintf("(n.author_id = %s OR n.department_id = ANY(%s::bigint[]))", add(f.uid), add(f.ids)))
	}
	if f.dept > 0 {
		conds = append(conds, "n.department_id IN "+deptSubtree(add(f.dept)+"::bigint"))
	}
	if f.author > 0 && f.admin {
		conds = append(conds, "n.author_id = "+add(f.author)+"::bigint")
	}
	if f.cat > 0 {
		conds = append(conds, "n.category_id = "+add(int(f.cat))+"::int")
	}
	return strings.Join(conds, " AND "), args
}

func (s *Server) anFilter(c *Ctx) (*anNF, error) {
	f := &anNF{admin: c.U.IsAdmin(), uid: c.U.ID, dept: c.QInt64("dept"), author: c.QInt64("author"), cat: c.QInt64("category"), ids: []int64{}}
	if !f.admin {
		sc, err := s.scopeOf(c.Context(), c.U)
		if err != nil {
			return nil, err
		}
		f.ids = sc.IDs
		if f.dept > 0 && !sc.Has(f.dept) {
			return nil, errForbidden
		}
		f.author = 0
	}
	return f, nil
}

// cohort — условие «новость опубликована в периоде»; параметры $1 (с), $2 (по), $3 (часовой пояс).
const anCohort = `n.status = 'published' AND NOT n.hidden AND n.published_at <= now()
	AND n.published_at >= (($1::text)::date)::timestamp AT TIME ZONE $3::text AND n.published_at < ((($2::text)::date) + 1)::timestamp AT TIME ZONE $3::text`

// ---------------------------------------------------------------- содержание: охват и вовлечение

type anContentKPI struct {
	Published    int     `json:"published"`
	Reach        float64 `json:"reach"` // средний охват новостей, опубликованных в периоде (0..1)
	Views        float64 `json:"views"`
	Uniq         float64 `json:"uniq"`
	Reactions    float64 `json:"reactions"`
	Comments     float64 `json:"comments"`
	ER           float64 `json:"er"` // (реакции + комментарии) / просмотры
	ViewsPerNews float64 `json:"views_per_news"`
}

func (s *Server) anContentKPI(ctx context.Context, f *anNF, hc *anHC, from, to string) (*anContentKPI, error) {
	k := &anContentKPI{}
	ids, ns := hc.arrays()
	cond, fa := f.sql(7)
	args := append([]any{from, to, s.cfg.TZ, ids, ns, hc.Total}, fa...)
	if err := s.ro.QueryRow(ctx, `SELECT count(*), coalesce(avg(least(1.0, n.uniq_views::float8 / greatest(coalesce(h.cnt, $6::int), 1))), 0)::float8
		FROM news n LEFT JOIN unnest($4::bigint[], $5::int[]) AS h(dept_id, cnt) ON h.dept_id = n.department_id
		WHERE `+anCohort+` AND `+cond, args...).Scan(&k.Published, &k.Reach); err != nil {
		return nil, err
	}
	if f.scoped() {
		cond, fa := f.sql(3)
		if err := s.ro.QueryRow(ctx, `SELECT coalesce(sum(s.views), 0)::float8, coalesce(sum(s.uniq_views), 0)::float8, coalesce(sum(s.likes), 0)::float8, coalesce(sum(s.comments), 0)::float8
			FROM news_stats_daily s JOIN news n ON n.id = s.news_id WHERE s.day BETWEEN $1::text::date AND $2::text::date AND `+cond, append([]any{from, to}, fa...)...).
			Scan(&k.Views, &k.Uniq, &k.Reactions, &k.Comments); err != nil {
			return nil, err
		}
	} else {
		ms, err := s.anMetrics(ctx, from, to, "news_views", "news_uniq", "likes_news", "comments_news")
		if err != nil {
			return nil, err
		}
		k.Views, k.Uniq, k.Reactions, k.Comments = ms.Sum["news_views"], ms.Sum["news_uniq"], ms.Sum["likes_news"], ms.Sum["comments_news"]
	}
	k.ER = ratio(k.Reactions+k.Comments, k.Views)
	k.ViewsPerNews = ratio(k.Views, float64(k.Published))
	return k, nil
}

func (s *Server) anContent(c *Ctx) error {
	r, err := s.anRange(c)
	if err != nil {
		return err
	}
	f, err := s.anFilter(c)
	if err != nil {
		return err
	}
	return s.anCache(c, "content", 120*time.Second, []string{r.key(), f.key(), c.Q("limit")}, func(ctx context.Context) (any, error) {
		hc, err := s.anHeadcount(ctx)
		if err != nil {
			return nil, err
		}
		cur, err := s.anContentKPI(ctx, f, hc, r.From, r.To)
		if err != nil {
			return nil, err
		}
		out := map[string]any{"range": r, "kpi": cur, "scoped": f.scoped(), "headcount": hc.Total}
		if r.Compare {
			if out["prev"], err = s.anContentKPI(ctx, f, hc, r.PFrom, r.PTo); err != nil {
				return nil, err
			}
		}
		ids, ns := hc.arrays()
		// ряд по дням: просмотры, уникальные, реакции, комментарии, публикации
		days := anDays(r.From, r.To)
		idx := map[string]int{}
		series := make([]map[string]any, len(days))
		for i, d := range days {
			idx[d] = i
			series[i] = map[string]any{"day": d, "views": 0, "uniq": 0, "reactions": 0, "comments": 0, "published": 0}
		}
		cond, fa := f.sql(3)
		rows, err := s.ro.Query(ctx, `SELECT to_char(s.day, 'YYYY-MM-DD'), sum(s.views)::int, sum(s.uniq_views)::int, sum(s.likes)::int, sum(s.comments)::int
			FROM news_stats_daily s JOIN news n ON n.id = s.news_id WHERE s.day BETWEEN $1::text::date AND $2::text::date AND `+cond+` GROUP BY s.day`, append([]any{r.From, r.To}, fa...)...)
		if err != nil {
			return nil, err
		}
		for rows.Next() {
			var d string
			var v, u, l, cm int
			if err := rows.Scan(&d, &v, &u, &l, &cm); err != nil {
				rows.Close()
				return nil, err
			}
			if i, ok := idx[d]; ok {
				series[i]["views"], series[i]["uniq"], series[i]["reactions"], series[i]["comments"] = v, u, l, cm
			}
		}
		rows.Close()
		cond, fa = f.sql(4)
		rows, err = s.ro.Query(ctx, `SELECT to_char((n.published_at AT TIME ZONE $3::text)::date, 'YYYY-MM-DD'), count(*)::int FROM news n WHERE `+anCohort+` AND `+cond+` GROUP BY 1`,
			append([]any{r.From, r.To, s.cfg.TZ}, fa...)...)
		if err != nil {
			return nil, err
		}
		for rows.Next() {
			var d string
			var n int
			if err := rows.Scan(&d, &n); err != nil {
				rows.Close()
				return nil, err
			}
			if i, ok := idx[d]; ok {
				series[i]["published"] = n
			}
		}
		rows.Close()
		out["series"] = series

		// ТОП новостей периода по просмотрам
		condT, faT := f.sql(6)
		args := append([]any{r.From, r.To, ids, ns, hc.Total}, faT...)
		if out["top"], err = s.arr2(ctx, `WITH top AS (
				SELECT s.news_id, sum(s.views)::int AS views, sum(s.uniq_views)::int AS uniq, sum(s.likes)::int AS reactions, sum(s.comments)::int AS comments
				FROM news_stats_daily s JOIN news n ON n.id = s.news_id
				WHERE s.day BETWEEN $1::text::date AND $2::text::date AND `+condT+` GROUP BY s.news_id ORDER BY 2 DESC, 1 DESC LIMIT 20)
			SELECT n.id, n.title, n.published_at, n.department_id, coalesce(d.name, 'Вся компания') AS dept, u.full_name AS author,
				t.views, t.uniq, t.reactions, t.comments, n.views_count AS total_views, n.uniq_views AS total_uniq,
				round(100.0 * least(1.0, n.uniq_views::float8 / greatest(coalesce(h.cnt, $5::int), 1)))::int AS reach,
				round(100.0 * (t.reactions + t.comments) / greatest(t.views, 1), 1)::float8 AS er
			FROM top t JOIN news n ON n.id = t.news_id LEFT JOIN departments d ON d.id = n.department_id LEFT JOIN users u ON u.id = n.author_id
				LEFT JOIN unnest($3::bigint[], $4::int[]) AS h(dept_id, cnt) ON h.dept_id = n.department_id
			ORDER BY t.views DESC, n.id DESC`, args...); err != nil {
			return nil, err
		}

		// низкий охват: опубликованы в периоде не менее 2 суток назад
		condL, faL := f.sql(7)
		largs := append([]any{r.From, r.To, s.cfg.TZ, ids, ns, hc.Total}, faL...)
		if out["low_reach"], err = s.arr2(ctx, `SELECT n.id, n.title, n.published_at, coalesce(d.name, 'Вся компания') AS dept, u.full_name AS author, n.views_count, n.uniq_views,
				coalesce(h.cnt, $6::int) AS audience,
				round(100.0 * least(1.0, n.uniq_views::float8 / greatest(coalesce(h.cnt, $6::int), 1)))::int AS reach
			FROM news n LEFT JOIN departments d ON d.id = n.department_id LEFT JOIN users u ON u.id = n.author_id
				LEFT JOIN unnest($4::bigint[], $5::int[]) AS h(dept_id, cnt) ON h.dept_id = n.department_id
			WHERE `+anCohort+` AND n.published_at < now() - interval '2 days' AND `+condL+`
			ORDER BY least(1.0, n.uniq_views::float8 / greatest(coalesce(h.cnt, $6::int), 1)), n.published_at DESC LIMIT 20`, largs...); err != nil {
			return nil, err
		}

		// по подразделениям-авторам и по категориям (когорта новостей периода)
		for _, g := range []struct{ key, sel, join, grp string }{
			{"by_dept", `n.department_id AS id, coalesce(d.name, 'Вся компания') AS name`, `LEFT JOIN departments d ON d.id = n.department_id`, `n.department_id, d.name`},
			{"by_category", `n.category_id AS id, coalesce(ct.name, 'Без категории') AS name`, `LEFT JOIN categories ct ON ct.id = n.category_id`, `n.category_id, ct.name`},
		} {
			if g.key == "by_dept" && !f.admin {
				out[g.key] = []any{} // охват по подразделениям — только администратору
				continue
			}
			cond, fa := f.sql(7)
			if out[g.key], err = s.arr2(ctx, `SELECT `+g.sel+`, count(*)::int AS published, sum(n.views_count)::bigint AS views, sum(n.uniq_views)::bigint AS uniq,
					avg(least(1.0, n.uniq_views::float8 / greatest(coalesce(h.cnt, $6::int), 1)))::float8 AS reach,
					sum(n.likes_count + n.comments_count)::bigint AS engagement
				FROM news n `+g.join+` LEFT JOIN unnest($4::bigint[], $5::int[]) AS h(dept_id, cnt) ON h.dept_id = n.department_id
				WHERE `+anCohort+` AND `+cond+` GROUP BY `+g.grp+` ORDER BY count(*) DESC, 2 LIMIT 30`,
				append([]any{r.From, r.To, s.cfg.TZ, ids, ns, hc.Total}, fa...)...); err != nil {
				return nil, err
			}
		}

		// воронка когорты: аудитория -> прочитали -> отреагировали/прокомментировали (суммы по новостям периода)
		{
			cond, fa := f.sql(7)
			var aud, uniq, likes, cm float64
			if err := s.ro.QueryRow(ctx, `SELECT coalesce(sum(coalesce(h.cnt, $6::int)), 0)::float8, coalesce(sum(least(n.uniq_views, coalesce(h.cnt, $6::int))), 0)::float8,
					coalesce(sum(n.likes_count), 0)::float8, coalesce(sum(n.comments_count), 0)::float8
				FROM news n LEFT JOIN unnest($4::bigint[], $5::int[]) AS h(dept_id, cnt) ON h.dept_id = n.department_id
				WHERE `+anCohort+` AND `+cond, append([]any{r.From, r.To, s.cfg.TZ, ids, ns, hc.Total}, fa...)...).Scan(&aud, &uniq, &likes, &cm); err != nil {
				return nil, err
			}
			out["funnel"] = []map[string]any{{"label": "Аудитория новостей", "value": aud}, {"label": "Прочитали", "value": uniq},
				{"label": "Оставили реакцию", "value": math.Min(likes, uniq)}, {"label": "Прокомментировали", "value": math.Min(cm, uniq)}}
		}

		// читатели по подразделениям (по последним ≤ 20 000 новостям когорты)
		cond, fa = f.sql(4)
		type vd struct {
			ID      int64   `json:"id"`
			Name    string  `json:"name"`
			Viewers int64   `json:"viewers"`
			Staff   int     `json:"staff"`
			Share   float64 `json:"share"` // средняя доля сотрудников подразделения, прочитавших новость
		}
		var viewers []vd
		var newsN int
		if f.admin { // охват по подразделениям редактору не показывается
			rows, err = s.ro.Query(ctx, `WITH c AS (SELECT n.id FROM news n WHERE `+anCohort+` AND `+cond+` ORDER BY n.published_at DESC LIMIT 20000)
				SELECT v.dept_id, sum(v.viewers)::bigint, (SELECT count(*) FROM c)::int FROM news_dept_views v JOIN c ON c.id = v.news_id GROUP BY v.dept_id ORDER BY 2 DESC LIMIT 40`,
				append([]any{r.From, r.To, s.cfg.TZ}, fa...)...)
			if err != nil {
				return nil, err
			}
			for rows.Next() {
				var d vd
				if err := rows.Scan(&d.ID, &d.Viewers, &newsN); err != nil {
					rows.Close()
					return nil, err
				}
				d.Name = hc.Names[d.ID]
				if d.ID == 0 {
					d.Name = "Без подразделения"
				}
				d.Staff = hc.Direct[d.ID]
				d.Share = ratio(float64(d.Viewers), float64(d.Staff)*float64(newsN))
				viewers = append(viewers, d)
			}
			rows.Close()
		}
		if viewers == nil {
			viewers = []vd{}
		}
		out["viewer_depts"], out["viewer_news"] = viewers, newsN
		return out, nil
	})
}

// anMeta — справочник для фильтров: подразделения области, категории (для редактора — только его область).
func (s *Server) anMeta(c *Ctx) error {
	ctx := c.Context()
	f, err := s.anFilter(c)
	if err != nil {
		return err
	}
	var depts json.RawMessage
	if f.admin {
		depts, err = s.arr2(ctx, `SELECT id, name, coalesce(parent_id, 0) AS parent_id FROM departments ORDER BY sort, name`)
	} else {
		depts, err = s.arr2(ctx, `SELECT id, name, coalesce(parent_id, 0) AS parent_id FROM departments WHERE id = ANY($1::bigint[]) ORDER BY sort, name`, f.ids)
	}
	if err != nil {
		return err
	}
	cats, err := s.arr2(ctx, `SELECT id, name FROM categories ORDER BY sort, name`)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"departments": depts, "categories": cats, "admin": f.admin, "retention_days": anRetentionDays(),
		"dropped_searches": s.an.dropped.Load(), "tz": s.cfg.TZ})
}

// ---------------------------------------------------------------- обзор

type anTile struct {
	ID     string    `json:"id"`
	Value  float64   `json:"value"`
	Prev   *float64  `json:"prev,omitempty"`
	Delta  *float64  `json:"delta,omitempty"`    // % изменения
	DeltaP *float64  `json:"delta_pp,omitempty"` // для долей: изменение в процентных пунктах
	Unit   string    `json:"unit"`               // n | pct | ms
	Spark  []float64 `json:"spark"`
}

func (s *Server) anOverview(c *Ctx) error {
	r, err := s.anRange(c)
	if err != nil {
		return err
	}
	return s.anCache(c, "overview", 120*time.Second, []string{r.key()}, func(ctx context.Context) (any, error) {
		names := []string{"dau", "wau", "mau", "visits", "news_views", "news_uniq", "likes_news", "comments_news", "msg_direct", "msg_group",
			"search_total", "search_zero", "search_clicked", "search_ms", "pv", "users_total", "poll_votes", "group_posts", "ideas_new",
			"learn_done", "req_submitted"}
		cur, err := s.anMetrics(ctx, r.From, r.To, names...)
		if err != nil {
			return nil, err
		}
		var prev *anMetricSet
		if r.Compare {
			if prev, err = s.anMetrics(ctx, r.PFrom, r.PTo, names...); err != nil {
				return nil, err
			}
		}
		// pv — сумма по всем разделам
		for _, ms := range []*anMetricSet{cur, prev} {
			if ms == nil {
				continue
			}
			pv, err := s.anPV(ctx, ms.Days[0], ms.Days[len(ms.Days)-1])
			if err != nil {
				return nil, err
			}
			ms.M["pv"] = pv
			for _, v := range pv {
				ms.Sum["pv"] += v
			}
		}
		hc, err := s.anHeadcount(ctx)
		if err != nil {
			return nil, err
		}
		all := &anNF{admin: true}
		kc, err := s.anContentKPI(ctx, all, hc, r.From, r.To)
		if err != nil {
			return nil, err
		}
		var kp *anContentKPI
		if r.Compare {
			if kp, err = s.anContentKPI(ctx, all, hc, r.PFrom, r.PTo); err != nil {
				return nil, err
			}
		}
		tiles := []anTile{}
		// sum — сумма за период, avg — среднее за день, last — значение на конец периода
		add := func(id, unit, mode, metric string, f func(*anMetricSet) float64) {
			t := anTile{ID: id, Unit: unit}
			val := func(ms *anMetricSet) float64 {
				if f != nil {
					return f(ms)
				}
				switch mode {
				case "avg":
					return ms.avg(metric)
				case "last":
					return ms.last(metric)
				}
				return ms.Sum[metric]
			}
			t.Value = val(cur)
			if metric != "" {
				t.Spark = cur.M[metric]
			}
			if prev != nil {
				pv := val(prev)
				t.Prev = &pv
				if unit == "pct" {
					d := math.Round((t.Value-pv)*1000) / 10
					t.DeltaP = &d
				} else {
					t.Delta = pctDelta(t.Value, pv)
				}
			}
			tiles = append(tiles, t)
		}
		sparkOf := func(ms *anMetricSet, f func(i int) float64) []float64 {
			o := make([]float64, len(ms.Days))
			for i := range o {
				o[i] = f(i)
			}
			return o
		}
		add("dau", "n", "avg", "dau", nil)
		add("mau", "n", "last", "mau", nil)
		add("visits", "n", "sum", "visits", nil)
		add("pv", "n", "sum", "pv", nil)
		add("news_views", "n", "sum", "news_views", nil)
		// охват и вовлечённость новостей — по когорте периода
		tiles = append(tiles, anTile{ID: "reach", Unit: "pct", Value: kc.Reach})
		tiles = append(tiles, anTile{ID: "er", Unit: "pct", Value: kc.ER})
		for i := range tiles {
			if tiles[i].ID == "reach" || tiles[i].ID == "er" {
				if kp != nil {
					p := kp.Reach
					if tiles[i].ID == "er" {
						p = kp.ER
					}
					tiles[i].Prev = &p
					d := math.Round((tiles[i].Value-p)*1000) / 10
					tiles[i].DeltaP = &d
				}
			}
		}
		tiles[len(tiles)-1].Spark = sparkOf(cur, func(i int) float64 {
			return ratio(cur.M["likes_news"][i]+cur.M["comments_news"][i], cur.M["news_views"][i])
		})
		tiles[len(tiles)-2].Spark = sparkOf(cur, func(i int) float64 { return ratio(cur.M["news_uniq"][i], cur.M["news_views"][i]) })
		add("msgs", "n", "sum", "", func(ms *anMetricSet) float64 { return ms.Sum["msg_direct"] + ms.Sum["msg_group"] })
		tiles[len(tiles)-1].Spark = sparkOf(cur, func(i int) float64 { return cur.M["msg_direct"][i] + cur.M["msg_group"][i] })
		add("searches", "n", "sum", "search_total", nil)
		add("zero_rate", "pct", "", "", func(ms *anMetricSet) float64 { return ratio(ms.Sum["search_zero"], ms.Sum["search_total"]) })
		tiles[len(tiles)-1].Spark = sparkOf(cur, func(i int) float64 { return ratio(cur.M["search_zero"][i], cur.M["search_total"][i]) })
		add("reactions", "n", "sum", "", func(ms *anMetricSet) float64 { return ms.Sum["likes_news"] + ms.Sum["comments_news"] })
		tiles[len(tiles)-1].Spark = sparkOf(cur, func(i int) float64 { return cur.M["likes_news"][i] + cur.M["comments_news"][i] })

		out := map[string]any{"range": r, "tiles": tiles, "days": cur.Days, "published": kc.Published, "users_total": hc.Total,
			"online": len(s.onlineIDs(ctx)), "server_time": time.Now().Format(time.RFC3339)}
		// «дошло ли до сбора»: отсутствие данных ≠ ноль
		var anyData bool
		s.ro.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM stats_daily WHERE day >= $1::text::date LIMIT 1)`, r.From).Scan(&anyData)
		out["has_data"] = anyData
		return out, nil
	})
}

// anPV — число просмотров страниц по дням (сумма по разделам).
func (s *Server) anPV(ctx context.Context, from, to string) ([]float64, error) {
	ms, err := s.anMetrics(ctx, from, to, "pv")
	if err != nil {
		return nil, err
	}
	return ms.M["pv"], nil
}

// ---------------------------------------------------------------- аудитория

func (s *Server) anAudience(c *Ctx) error {
	r, err := s.anRange(c)
	if err != nil {
		return err
	}
	return s.anCache(c, "audience", 120*time.Second, []string{r.key()}, func(ctx context.Context) (any, error) {
		names := []string{"dau", "wau", "mau", "visits", "users_new", "users_total"}
		cur, err := s.anMetrics(ctx, r.From, r.To, names...)
		if err != nil {
			return nil, err
		}
		stick := make([]float64, len(cur.Days))
		var peak float64
		for i := range stick {
			stick[i] = ratio(cur.M["dau"][i], cur.M["mau"][i])
			peak = math.Max(peak, cur.M["dau"][i])
		}
		hc, err := s.anHeadcount(ctx)
		if err != nil {
			return nil, err
		}
		kp := map[string]float64{"dau_avg": cur.avg("dau"), "dau_peak": peak, "wau": cur.last("wau"), "mau": cur.last("mau"),
			"visits": cur.Sum["visits"], "new_users": cur.Sum["users_new"], "users_total": float64(hc.Total)}
		kp["stickiness"] = ratio(kp["dau_avg"], kp["mau"])
		kp["active_share"] = ratio(kp["mau"], kp["users_total"])
		out := map[string]any{"range": r, "days": cur.Days, "dau": cur.M["dau"], "wau": cur.M["wau"], "mau": cur.M["mau"], "stickiness": stick,
			"visits": cur.M["visits"], "new_users": cur.M["users_new"], "kpi": kp, "online": len(s.onlineIDs(ctx))}
		if r.Compare {
			p, err := s.anMetrics(ctx, r.PFrom, r.PTo, "dau", "mau", "wau", "visits")
			if err != nil {
				return nil, err
			}
			out["prev"] = map[string]float64{"dau_avg": p.avg("dau"), "mau": p.last("mau"), "wau": p.last("wau"), "visits": p.Sum["visits"]}
		}
		// тепловая карта: день недели (пн=0) × час визитов
		heat := make([][]float64, 7)
		for i := range heat {
			heat[i] = make([]float64, 24)
		}
		rows, err := s.ro.Query(ctx, `SELECT extract(isodow FROM day)::int - 1, dim::int, sum(value)::float8 FROM stats_daily
			WHERE metric = 'visit_hour' AND day BETWEEN $1::text::date AND $2::text::date AND dim ~ '^[0-9]{1,2}$' GROUP BY 1, 2`, r.From, r.To)
		if err != nil {
			return nil, err
		}
		for rows.Next() {
			var d, h int
			var v float64
			if err := rows.Scan(&d, &h, &v); err != nil {
				rows.Close()
				return nil, err
			}
			if d >= 0 && d < 7 && h >= 0 && h < 24 {
				heat[d][h] = v
			}
		}
		rows.Close()
		out["heatmap"] = heat
		for _, m := range []string{"device", "browser"} {
			list := []map[string]any{}
			rows, err := s.ro.Query(ctx, `SELECT dim, sum(value)::float8 FROM stats_daily WHERE metric = $1 AND day BETWEEN $2::text::date AND $3::text::date GROUP BY dim ORDER BY 2 DESC`, m, r.From, r.To)
			if err != nil {
				return nil, err
			}
			for rows.Next() {
				var d string
				var v float64
				if err := rows.Scan(&d, &v); err != nil {
					rows.Close()
					return nil, err
				}
				list = append(list, map[string]any{"id": d, "value": v})
			}
			rows.Close()
			out[m+"s"] = list
		}
		return out, nil
	})
}

// ---------------------------------------------------------------- разделы

func (s *Server) anSections2(c *Ctx) error {
	r, err := s.anRange(c)
	if err != nil {
		return err
	}
	return s.anCache(c, "sections", 120*time.Second, []string{r.key()}, func(ctx context.Context) (any, error) {
		type sec struct {
			ID    string   `json:"id"`
			PV    float64  `json:"pv"`
			Prev  float64  `json:"prev"`
			Users float64  `json:"users_avg"` // среднее число уникальных посетителей раздела в день
			Delta *float64 `json:"delta,omitempty"`
		}
		days := anDays(r.From, r.To)
		idx := map[string]int{}
		for i, d := range days {
			idx[d] = i
		}
		series := map[string][]float64{}
		secs := map[string]*sec{}
		get := func(id string) *sec {
			if secs[id] == nil {
				secs[id] = &sec{ID: id}
			}
			return secs[id]
		}
		load := func(from, to string, fn func(day, dim, metric string, v float64)) error {
			rows, err := s.ro.Query(ctx, `SELECT to_char(day, 'YYYY-MM-DD'), dim, metric, sum(value)::float8 FROM stats_daily
				WHERE metric IN ('pv', 'pv_users') AND day BETWEEN $1::text::date AND $2::text::date GROUP BY day, dim, metric`, from, to)
			if err != nil {
				return err
			}
			defer rows.Close()
			for rows.Next() {
				var d, dim, m string
				var v float64
				if err := rows.Scan(&d, &dim, &m, &v); err != nil {
					return err
				}
				fn(d, dim, m, v)
			}
			return rows.Err()
		}
		if err := load(r.From, r.To, func(d, dim, m string, v float64) {
			if m == "pv" {
				get(dim).PV += v
				if series[dim] == nil {
					series[dim] = make([]float64, len(days))
				}
				if i, ok := idx[d]; ok {
					series[dim][i] += v
				}
			} else {
				get(dim).Users += v / float64(len(days))
			}
		}); err != nil {
			return nil, err
		}
		if r.Compare {
			if err := load(r.PFrom, r.PTo, func(d, dim, m string, v float64) {
				if m == "pv" {
					get(dim).Prev += v
				}
			}); err != nil {
				return nil, err
			}
		}
		list := make([]*sec, 0, len(secs))
		for _, v := range secs {
			v.Delta = pctDelta(v.PV, v.Prev)
			list = append(list, v)
		}
		sort.Slice(list, func(i, j int) bool { return list[i].PV > list[j].PV })
		return map[string]any{"range": r, "days": days, "sections": list, "series": series}, nil
	})
}

// ---------------------------------------------------------------- вовлечённость вне новостей (чаты, группы, идеи, опросы…)

func (s *Server) anEngagement(c *Ctx) error {
	r, err := s.anRange(c)
	if err != nil {
		return err
	}
	return s.anCache(c, "engagement", 120*time.Second, []string{r.key()}, func(ctx context.Context) (any, error) {
		names := []string{"msg_direct", "msg_group", "msg_senders", "chats_active", "group_posts", "groups_active", "poll_votes", "poll_voters",
			"ideas_new", "comments_news", "comments_post", "comments_idea", "replies", "likes_news", "reactions_idea", "reactions_post", "reactions_comment", "reactions_message",
			"bookmarks", "mentions"}
		cur, err := s.anMetrics(ctx, r.From, r.To, names...)
		if err != nil {
			return nil, err
		}
		out := map[string]any{"range": r, "days": cur.Days, "m": cur.M, "sum": cur.Sum}
		if r.Compare {
			p, err := s.anMetrics(ctx, r.PFrom, r.PTo, names...)
			if err != nil {
				return nil, err
			}
			out["prev"] = p.Sum
		}
		// топ реакций (смайлы) — если блок реакций присутствует
		if s.anHas(ctx, "reactions") {
			emo := []map[string]any{}
			rows, err := s.ro.Query(ctx, `SELECT dim, sum(value)::float8 FROM stats_daily WHERE metric = 'reaction_emoji' AND day BETWEEN $1::text::date AND $2::text::date
				GROUP BY dim ORDER BY 2 DESC LIMIT 12`, r.From, r.To)
			if err != nil {
				return nil, err
			}
			for rows.Next() {
				var e string
				var v float64
				if err := rows.Scan(&e, &v); err != nil {
					rows.Close()
					return nil, err
				}
				emo = append(emo, map[string]any{"id": e, "value": v})
			}
			rows.Close()
			out["emoji"] = emo
		}
		out["has_reactions"], out["has_bookmarks"], out["has_mentions"] = s.anHas(ctx, "reactions"), s.anHas(ctx, "bookmarks"), s.anHas(ctx, "mentions")
		return out, nil
	})
}

// ---------------------------------------------------------------- редакторы

func (s *Server) anEditors(c *Ctx) error {
	r, err := s.anRange(c)
	if err != nil {
		return err
	}
	return s.anCache(c, "editors", 180*time.Second, []string{r.key()}, func(ctx context.Context) (any, error) {
		hc, err := s.anHeadcount(ctx)
		if err != nil {
			return nil, err
		}
		ids, ns := hc.arrays()
		list, err := s.arr2(ctx, `SELECT n.author_id AS id, u.full_name AS name, coalesce(d.name, '') AS dept, count(*)::int AS published,
				sum(n.views_count)::bigint AS views, sum(n.uniq_views)::bigint AS uniq,
				avg(least(1.0, n.uniq_views::float8 / greatest(coalesce(h.cnt, $6::int), 1)))::float8 AS reach,
				sum(n.likes_count + n.comments_count)::bigint AS engagement, max(n.published_at) AS last_at
			FROM news n JOIN users u ON u.id = n.author_id LEFT JOIN departments d ON d.id = u.department_id
				LEFT JOIN unnest($4::bigint[], $5::int[]) AS h(dept_id, cnt) ON h.dept_id = n.department_id
			WHERE `+anCohort+` GROUP BY n.author_id, u.full_name, d.name ORDER BY count(*) DESC, 2 LIMIT 100`, r.From, r.To, s.cfg.TZ, ids, ns, hc.Total)
		if err != nil {
			return nil, err
		}
		return map[string]any{"range": r, "items": list}, nil
	})
}

// ---------------------------------------------------------------- поиск

// Разделы, из которых фронт отправляет клик по результату: только по ним считаются CTR и «без клика».
var anClickScopes = []string{"global"}

func anClickable(scope string) bool {
	for _, s := range anClickScopes {
		if s == scope {
			return true
		}
	}
	return false
}

func (s *Server) anSearchScopeFilter(c *Ctx) (string, []any) {
	if sc := c.Q("scope"); sc != "" && sc != "all" {
		return "scope = $1::text", []any{sc}
	}
	return "scope <> $1::text", []any{"admin_news"}
}

func (s *Server) anSearch(c *Ctx) error {
	r, err := s.anRange(c)
	if err != nil {
		return err
	}
	scopeCond, scopeArgs := s.anSearchScopeFilter(c)
	return s.anCache(c, "search", 120*time.Second, []string{r.key(), c.Q("scope"), c.Q("resolved")}, func(ctx context.Context) (any, error) {
		// ряды по дням (полные счётчики)
		days := anDays(r.From, r.To)
		idx := map[string]int{}
		for i, d := range days {
			idx[d] = i
		}
		type agg struct{ total, zero, clicked, ms, clickable, clickZero float64 }
		load := func(from, to string) (map[string]*agg, map[string]*agg, error) {
			byDay, byScope := map[string]*agg{}, map[string]*agg{}
			rows, err := s.ro.Query(ctx, `SELECT to_char(day, 'YYYY-MM-DD'), dim, metric, value::float8 FROM stats_daily
				WHERE metric IN ('search_total', 'search_zero', 'search_clicked', 'search_ms') AND `+strings.Replace(scopeCond, "scope", "dim", 1)+`
				AND day BETWEEN $2::text::date AND $3::text::date`, append(scopeArgs, from, to)...)
			if err != nil {
				return nil, nil, err
			}
			defer rows.Close()
			for rows.Next() {
				var d, dim, m string
				var v float64
				if err := rows.Scan(&d, &dim, &m, &v); err != nil {
					return nil, nil, err
				}
				for _, p := range []struct {
					mp  map[string]*agg
					key string
				}{{byDay, d}, {byScope, dim}} {
					a := p.mp[p.key]
					if a == nil {
						a = &agg{}
						p.mp[p.key] = a
					}
					switch m {
					case "search_total":
						a.total += v
						if anClickable(dim) { // «кликабельные» поиски — из разделов, где фронт шлёт клики
							a.clickable += v
						}
					case "search_zero":
						a.zero += v
						if anClickable(dim) {
							a.clickZero += v
						}
					case "search_clicked":
						a.clicked += v
					case "search_ms":
						a.ms += v
					}
				}
			}
			return byDay, byScope, rows.Err()
		}
		byDay, byScope, err := load(r.From, r.To)
		if err != nil {
			return nil, err
		}
		series := make([]map[string]any, len(days))
		var tot agg
		for i, d := range days {
			a := byDay[d]
			if a == nil {
				a = &agg{}
			}
			series[i] = map[string]any{"day": d, "total": a.total, "zero": a.zero, "clicked": a.clicked, "zero_rate": ratio(a.zero, a.total)}
			tot.total += a.total
			tot.zero += a.zero
			tot.clicked += a.clicked
			tot.ms += a.ms
			tot.clickable += a.clickable
			tot.clickZero += a.clickZero
		}
		kpi := func(a agg) map[string]float64 {
			return map[string]float64{"total": a.total, "zero": a.zero, "zero_rate": ratio(a.zero, a.total), "clicked": a.clicked,
				"ctr": ratio(a.clicked, a.clickable-a.clickZero), "avg_ms": ratio(a.ms, a.total)}
		}
		out := map[string]any{"range": r, "series": series, "kpi": kpi(tot), "click_scopes": anClickScopes}
		if r.Compare {
			pd, _, err := load(r.PFrom, r.PTo)
			if err != nil {
				return nil, err
			}
			var pt agg
			for _, a := range pd {
				pt.total += a.total
				pt.zero += a.zero
				pt.clicked += a.clicked
				pt.ms += a.ms
				pt.clickable += a.clickable
				pt.clickZero += a.clickZero
			}
			out["prev"] = kpi(pt)
		}
		scopes := []map[string]any{}
		for k, a := range byScope {
			scopes = append(scopes, map[string]any{"scope": k, "total": a.total, "zero": a.zero, "zero_rate": ratio(a.zero, a.total), "clicked": a.clicked})
		}
		sort.Slice(scopes, func(i, j int) bool { return scopes[i]["total"].(float64) > scopes[j]["total"].(float64) })
		out["by_scope"] = scopes

		// списки запросов из дневного rollup
		base := `SELECT normalized AS q, max(sample) AS sample, sum(searches)::int AS searches, sum(zero)::int AS zero, sum(noclick)::int AS noclick, sum(clicks)::int AS clicks,
				sum(users)::int AS users FROM search_daily WHERE day BETWEEN $2::text::date AND $3::text::date AND ` + scopeCond
		args := append(append([]any{}, scopeArgs...), r.From, r.To)
		q := func(having, order string, extra ...any) (json.RawMessage, error) {
			return s.arr2(ctx, base+` GROUP BY normalized HAVING `+having+` ORDER BY `+order+` LIMIT 50`, append(args, extra...)...)
		}
		if out["top"], err = q("sum(searches) > 0", "sum(searches) DESC, 1"); err != nil {
			return nil, err
		}
		// «обработано» — отметка администратора, что для запроса добавлен контент/синоним; фильтр resolved=open|done|all
		resCond := "NOT EXISTS (SELECT 1 FROM search_resolved x WHERE x.normalized = search_daily.normalized)"
		switch c.Q("resolved") {
		case "done":
			resCond = strings.Replace(resCond, "NOT EXISTS", "EXISTS", 1)
		case "all":
			resCond = "TRUE"
		}
		if out["zero_queries"], err = s.arr2(ctx, `SELECT normalized AS q, max(sample) AS sample, sum(searches)::int AS searches, sum(zero)::int AS zero, sum(users)::int AS users,
				(SELECT r.resolved_at FROM search_resolved r WHERE r.normalized = search_daily.normalized) AS resolved_at,
				(SELECT r.note FROM search_resolved r WHERE r.normalized = search_daily.normalized) AS note
			FROM search_daily WHERE day BETWEEN $2::text::date AND $3::text::date AND `+scopeCond+` AND `+resCond+`
			GROUP BY normalized HAVING sum(zero) > 0 ORDER BY sum(zero) DESC, 1 LIMIT 50`, args...); err != nil {
			return nil, err
		}
		// «с результатами, но без клика»: только разделы с отслеживанием кликов
		nb2 := `SELECT normalized AS q, max(sample) AS sample, sum(searches)::int AS searches, sum(noclick)::int AS noclick, sum(clicks)::int AS clicks, sum(users)::int AS users
			FROM search_daily WHERE day BETWEEN $1::text::date AND $2::text::date AND scope = ANY($3::text[]) GROUP BY normalized
			HAVING sum(noclick) >= 2 AND sum(clicks) * 5 <= sum(noclick) ORDER BY sum(noclick) DESC, 1 LIMIT 50`
		if out["noclick_queries"], err = s.arr2(ctx, nb2, r.From, r.To, anClickScopes); err != nil {
			return nil, err
		}
		return out, nil
	})
}

// anSearchWho — кто искал запрос (только админ; действие пишется в журнал аудита).
func (s *Server) anSearchWho(c *Ctx) error {
	r, err := s.anRange(c)
	if err != nil {
		return err
	}
	q := normQuery(c.Q("q"))
	if q == "" {
		return badReq("Не указан запрос")
	}
	s.audit(c, "analytics.search_users", "search", 0, map[string]any{"q": q, "from": r.From, "to": r.To})
	b, err := s.arr2(c.Context(), `SELECT l.user_id AS id, coalesce(u.full_name, 'Удалённый пользователь') AS name, coalesce(d.name, '') AS dept, count(*)::int AS searches,
			count(*) FILTER (WHERE l.results_count = 0)::int AS zero, count(*) FILTER (WHERE l.clicked)::int AS clicks, max(l.created_at) AS last_at
		FROM search_log l LEFT JOIN users u ON u.id = l.user_id LEFT JOIN departments d ON d.id = u.department_id
		WHERE l.normalized = $1 AND l.created_at >= (($2::text)::date)::timestamp AT TIME ZONE $4::text AND l.created_at < ((($3::text)::date) + 1)::timestamp AT TIME ZONE $4::text
		GROUP BY l.user_id, u.full_name, d.name ORDER BY searches DESC, 1 LIMIT 100`, q, r.From, r.To, s.cfg.TZ)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"q": q, "items": b, "private": true})
}

// anSearchExport — CSV (UTF-8 с BOM, для Excel): kind = top | zero | noclick. Без данных о пользователях.
func (s *Server) anSearchExport(c *Ctx) error {
	r, err := s.anRange(c)
	if err != nil {
		return err
	}
	scopeCond, scopeArgs := s.anSearchScopeFilter(c)
	kind := c.Q("kind")
	var sqlq string
	args := []any{}
	switch kind {
	case "zero":
		sqlq = `SELECT normalized, max(sample), sum(searches), sum(zero), sum(clicks), sum(users) FROM search_daily WHERE day BETWEEN $2::text::date AND $3::text::date AND ` + scopeCond +
			` GROUP BY normalized HAVING sum(zero) > 0 ORDER BY sum(zero) DESC, 1 LIMIT 5000`
		args = append(scopeArgs, r.From, r.To)
	case "noclick":
		sqlq = `SELECT normalized, max(sample), sum(searches), sum(zero), sum(clicks), sum(users) FROM search_daily WHERE day BETWEEN $1::text::date AND $2::text::date AND scope = ANY($3::text[])
			GROUP BY normalized HAVING sum(noclick) >= 2 AND sum(clicks) * 5 <= sum(noclick) ORDER BY sum(noclick) DESC, 1 LIMIT 5000`
		args = []any{r.From, r.To, anClickScopes}
	default:
		kind = "top"
		sqlq = `SELECT normalized, max(sample), sum(searches), sum(zero), sum(clicks), sum(users) FROM search_daily WHERE day BETWEEN $2::text::date AND $3::text::date AND ` + scopeCond +
			` GROUP BY normalized ORDER BY sum(searches) DESC, 1 LIMIT 5000`
		args = append(scopeArgs, r.From, r.To)
	}
	rows, err := s.ro.Query(c.Context(), sqlq, args...)
	if err != nil {
		return err
	}
	defer rows.Close()
	c.W.Header().Set("Content-Type", "text/csv; charset=utf-8")
	c.W.Header().Set("Content-Disposition", fmt.Sprintf(`attachment; filename="search-%s-%s_%s.csv"`, kind, r.From, r.To))
	c.W.Write([]byte("\xEF\xBB\xBF"))
	w := csv.NewWriter(c.W)
	w.Comma = ';'
	w.Write([]string{"Запрос", "Как вводили", "Поисков", "Без результатов", "Переходов", "Пользователей (сумма по дням)"})
	for rows.Next() {
		var n, sample string
		var a, b2, cl, u int64
		if err := rows.Scan(&n, &sample, &a, &b2, &cl, &u); err != nil {
			break
		}
		w.Write([]string{csvSafe(n), csvSafe(sample), strconv.FormatInt(a, 10), strconv.FormatInt(b2, 10), strconv.FormatInt(cl, 10), strconv.FormatInt(u, 10)})
	}
	w.Flush()
	return nil
}

// ---------------------------------------------------------------- обучение, заявки, wiki (условно)

func (s *Server) anModules(c *Ctx) error {
	r, err := s.anRange(c)
	if err != nil {
		return err
	}
	return s.anCache(c, "modules", 180*time.Second, []string{r.key()}, func(ctx context.Context) (any, error) {
		out := map[string]any{"range": r}
		sumOf := func(names ...string) (*anMetricSet, *anMetricSet, error) {
			cur, err := s.anMetrics(ctx, r.From, r.To, names...)
			if err != nil {
				return nil, nil, err
			}
			var prev *anMetricSet
			if r.Compare {
				if prev, err = s.anMetrics(ctx, r.PFrom, r.PTo, names...); err != nil {
					return nil, nil, err
				}
			}
			return cur, prev, nil
		}
		pack := func(cur, prev *anMetricSet) map[string]any {
			m := map[string]any{"days": cur.Days, "m": cur.M, "sum": cur.Sum}
			if prev != nil {
				m["prev"] = prev.Sum
			}
			return m
		}
		// ---- обучение
		if s.anHas(ctx, "learn_attempts") || s.anHas(ctx, "learn_assignees") || s.anHas(ctx, "learn_progress") {
			cur, prev, err := sumOf("learn_att_started", "learn_att_finished", "learn_att_passed", "learn_opened", "learn_item_done", "learn_assigned", "learn_done", "learn_completions")
			if err != nil {
				return nil, err
			}
			l := pack(cur, prev)
			if s.anHas(ctx, "learn_assignees") {
				var open, overdue int64
				if err := s.ro.QueryRow(ctx, `SELECT count(*), count(*) FILTER (WHERE due_at < now()) FROM learn_assignees WHERE status < 2 AND due_at IS NOT NULL`).Scan(&open, &overdue); err != nil {
					s.log.Warn("analytics: learning snapshot failed", "err", err)
				} else {
					l["open"], l["overdue"] = open, overdue
				}
				if l["overdue_by_dept"], err = s.arr2(ctx, `SELECT coalesce(d.name, 'Без подразделения') AS name, count(*)::int AS overdue
					FROM learn_assignees a LEFT JOIN departments d ON d.id = a.dept_id WHERE a.status < 2 AND a.due_at < now() GROUP BY d.name ORDER BY 2 DESC, 1 LIMIT 12`); err != nil {
					s.log.Warn("analytics: learning overdue failed", "err", err)
					l["overdue_by_dept"] = []any{}
				}
			}
			if s.anHas(ctx, "learn_completions", "learn_courses") {
				if l["top_courses"], err = s.arr2(ctx, `SELECT co.title, count(*)::int AS completed FROM learn_completions lc JOIN learn_courses co ON co.id = lc.course_id
					WHERE lc.completed_at >= (($1::text)::date)::timestamp AT TIME ZONE $3::text AND lc.completed_at < ((($2::text)::date) + 1)::timestamp AT TIME ZONE $3::text
					GROUP BY co.id, co.title ORDER BY 2 DESC, 1 LIMIT 10`, r.From, r.To, s.cfg.TZ); err != nil {
					s.log.Warn("analytics: top courses failed", "err", err)
					l["top_courses"] = []any{}
				}
			}
			out["learning"] = l
		}
		// ---- заявки
		if s.anHas(ctx, "req_requests") {
			cur, prev, err := sumOf("req_submitted", "req_closed")
			if err != nil {
				return nil, err
			}
			q := pack(cur, prev)
			var open, overdue int64
			if err := s.ro.QueryRow(ctx, `SELECT count(*), count(*) FILTER (WHERE due_at < now()) FROM req_requests WHERE status IN ('pending', 'in_progress', 'rework') AND submitted_at > now() - interval '400 days'`).Scan(&open, &overdue); err == nil {
				q["open"], q["overdue"] = open, overdue
			}
			var avgH, medH *float64
			if err := s.ro.QueryRow(ctx, `SELECT avg(extract(epoch FROM closed_at - submitted_at)) / 3600, percentile_cont(0.5) WITHIN GROUP (ORDER BY extract(epoch FROM closed_at - submitted_at)) / 3600
				FROM req_requests WHERE status IN ('approved', 'in_progress', 'done') AND closed_at >= (($1::text)::date)::timestamp AT TIME ZONE $3::text
				AND closed_at < ((($2::text)::date) + 1)::timestamp AT TIME ZONE $3::text AND submitted_at IS NOT NULL`, r.From, r.To, s.cfg.TZ).Scan(&avgH, &medH); err == nil {
				q["avg_hours"], q["median_hours"] = avgH, medH
			}
			if q["by_status"], err = s.arr2(ctx, `SELECT status, count(*)::int AS n FROM req_requests WHERE submitted_at >= (($1::text)::date)::timestamp AT TIME ZONE $3::text
				AND submitted_at < ((($2::text)::date) + 1)::timestamp AT TIME ZONE $3::text GROUP BY status ORDER BY 2 DESC`, r.From, r.To, s.cfg.TZ); err != nil {
				q["by_status"] = []any{}
			}
			if s.anHas(ctx, "req_types") {
				if q["by_type"], err = s.arr2(ctx, `SELECT t.name, count(*)::int AS n, count(*) FILTER (WHERE r.status IN ('approved', 'done'))::int AS ok
					FROM req_requests r JOIN req_types t ON t.id = r.type_id WHERE r.submitted_at >= (($1::text)::date)::timestamp AT TIME ZONE $3::text
					AND r.submitted_at < ((($2::text)::date) + 1)::timestamp AT TIME ZONE $3::text GROUP BY t.id, t.name ORDER BY 2 DESC, 1 LIMIT 10`, r.From, r.To, s.cfg.TZ); err != nil {
					q["by_type"] = []any{}
				}
			}
			out["requests"] = q
		}
		// ---- wiki
		if s.anHas(ctx, "wiki_pages") {
			cur, prev, err := sumOf("wiki_created", "wiki_edits", "wiki_comments")
			if err != nil {
				return nil, err
			}
			w := pack(cur, prev)
			var pages, stale int64
			if err := s.ro.QueryRow(ctx, `SELECT count(*), count(*) FILTER (WHERE review_until < current_date) FROM wiki_pages`).Scan(&pages, &stale); err == nil {
				w["pages"], w["stale"] = pages, stale
			}
			if w["top_pages"], err = s.arr2(ctx, `SELECT p.id, p.title, p.views_count FROM wiki_pages p ORDER BY p.views_count DESC, p.id DESC LIMIT 10`); err != nil {
				w["top_pages"] = []any{}
			}
			out["wiki"] = w
		}
		return out, nil
	})
}

// anSearchResolve помечает нулевой запрос «обработанным» (или снимает отметку). Только администратор.
func (s *Server) anSearchResolve(c *Ctx) error {
	var in struct {
		Q        string `json:"q"`
		Resolved bool   `json:"resolved"`
		Note     string `json:"note"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	norm := normQuery(in.Q)
	if norm == "" {
		return badReq("Пустой запрос")
	}
	var err error
	if in.Resolved {
		_, err = s.db.Exec(c.Context(), `INSERT INTO search_resolved (normalized, resolved_by, note) VALUES ($1::text, $2::bigint, $3::text)
			ON CONFLICT (normalized) DO UPDATE SET resolved_by = EXCLUDED.resolved_by, resolved_at = now(), note = EXCLUDED.note`, norm, c.U.ID, clip(strings.TrimSpace(in.Note), 300))
	} else {
		_, err = s.db.Exec(c.Context(), `DELETE FROM search_resolved WHERE normalized = $1::text`, norm)
	}
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"ok": true})
}
