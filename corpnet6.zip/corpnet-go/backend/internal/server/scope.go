package server

import (
	"context"
	"strings"
)

// Области управления.
//
//   - admin  — видит и правит всё.
//   - editor — управляет своим подразделением и всеми дочерними (вложенность любой глубины), а также теми
//     подразделениями (с их поддеревьями), которые администратор добавил ему в editor_departments.
//
// Новости, подразделения и направления в админке фильтруются по этой области.

type scope struct {
	All bool
	IDs []int64 // всегда не nil
	set map[int64]bool
}

func (sc *scope) Has(id int64) bool { return sc.All || sc.set[id] }

func (sc *scope) HasPtr(id *int64) bool { return id != nil && sc.Has(*id) }

func (s *Server) scopeOf(ctx context.Context, u *User) (*scope, error) {
	if u.IsAdmin() {
		return &scope{All: true, IDs: []int64{}}, nil
	}
	sc := &scope{IDs: []int64{}, set: map[int64]bool{}}
	if !u.CanEdit() {
		return sc, nil
	}
	rows, err := s.db.Query(ctx, `WITH RECURSIVE roots AS (
			SELECT department_id AS id FROM users WHERE id = $1 AND department_id IS NOT NULL
			UNION SELECT department_id FROM editor_departments WHERE user_id = $1),
		t AS (SELECT id FROM roots UNION SELECT d.id FROM departments d JOIN t ON d.parent_id = t.id)
		SELECT id FROM t`, u.ID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		sc.IDs = append(sc.IDs, id)
		sc.set[id] = true
	}
	return sc, rows.Err()
}

// canManageNews: админ; редактор — свои новости и новости подразделений своей области.
func (sc *scope) canManageNews(u *User, dept, author *int64) bool {
	if u.IsAdmin() {
		return true
	}
	if author != nil && *author == u.ID {
		return true
	}
	return sc.HasPtr(dept)
}

// canPublishTo: куда редактор вправе публиковать (подразделение из области; «вся компания» — по флагу).
func (sc *scope) canPublishTo(u *User, dept *int64) bool {
	if u.IsAdmin() {
		return true
	}
	if dept == nil {
		return u.CanEdit() && u.CoNews
	}
	return u.CanEdit() && sc.Has(*dept)
}

// dirTreeSQL — «можно ли управлять направлением»: права наследуются вниз по дереву направлений.
// $1 = id подразделений области (bigint[]), $2 = админ. Возвращает (id, ok) для всех направлений.
const dirTreeSQL = `WITH RECURSIVE m(id, ok) AS (
		SELECT id, $2::boolean OR coalesce(department_id = ANY($1::bigint[]), false) FROM directions WHERE parent_id IS NULL
		UNION ALL
		SELECT d.id, m.ok OR $2::boolean OR coalesce(d.department_id = ANY($1::bigint[]), false) FROM directions d JOIN m ON d.parent_id = m.id)`

func (s *Server) canManageDirection(ctx context.Context, u *User, sc *scope, id int64) (bool, error) {
	if u.IsAdmin() {
		return true, nil
	}
	var ok bool
	err := s.db.QueryRow(ctx, dirTreeSQL+` SELECT coalesce((SELECT ok FROM m WHERE id = $3), false)`, sc.IDs, false, id).Scan(&ok)
	return ok, err
}

// deptSubtree — условие «подразделение в поддереве $n» для SQL (включая само подразделение).
func deptSubtree(param string) string {
	return `(WITH RECURSIVE t AS (SELECT id FROM departments WHERE id = ` + param + `
		UNION ALL SELECT d.id FROM departments d JOIN t ON d.parent_id = t.id) SELECT id FROM t)`
}

var _ = strings.TrimSpace
