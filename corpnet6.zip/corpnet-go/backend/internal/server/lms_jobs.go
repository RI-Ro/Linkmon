package server

import (
	"context"
	"strconv"
	"time"

	"github.com/jackc/pgx/v5"
)

// Фоновые задачи LMS. Работают в нескольких экземплярах и ЦОДах без дублей:
//   • запуск ограничивается блокировкой в job_locks (не чаще раза за период на весь кластер);
//   • каждая задача идемпотентна сама по себе: уникальные ключи (назначения, цикл), ключи напоминаний (learn_reminders), дайджест (learn_digests).

func (s *Server) lmsJobs(ctx context.Context) { s.lmsRunAll(ctx, false) }

func (s *Server) lmsRunAll(ctx context.Context, force bool) map[string]any {
	res := map[string]any{}
	gate := func(name string, every time.Duration) bool {
		return force || s.lock(ctx, "lms:"+name, every)
	}
	if gate("follow", 4*time.Minute) {
		res["follow"] = s.lmsJobFollow(ctx)
	}
	if gate("expire", 25*time.Minute) {
		res["expire"] = s.lmsJobExpire(ctx)
	}
	if gate("recur", 25*time.Minute) {
		res["recur"] = s.lmsJobRecur(ctx)
	}
	if gate("remind", 29*time.Minute) {
		res["remind"] = s.lmsJobRemind(ctx)
	}
	if gate("certsoon", 5*time.Hour) {
		res["cert_soon"] = s.lmsJobCertSoon(ctx)
	}
	if gate("digest", 55*time.Minute) {
		res["digest"] = s.lmsJobDigest(ctx)
	}
	return res
}

func (s *Server) lmsJobsRun(c *Ctx) error {
	return c.JSON(200, s.lmsRunAll(c.Context(), true))
}

// lmsJobFollow — правила автоназначения: новые сотрудники подразделения и переведённые получают назначения.
func (s *Server) lmsJobFollow(ctx context.Context) int {
	rows, err := s.db.Query(ctx, `SELECT id FROM learn_assignments WHERE status = 'active' AND follow ORDER BY id`)
	if err != nil {
		s.log.Warn("lms follow", "err", err)
		return 0
	}
	var ids []int64
	for rows.Next() {
		var id int64
		rows.Scan(&id)
		ids = append(ids, id)
	}
	rows.Close()
	total := 0
	for _, id := range ids {
		n, err := s.lmsMaterialize(ctx, id, "", "")
		if err != nil {
			s.log.Warn("lms follow assignment", "id", id, "err", err)
			continue
		}
		total += n
	}
	return total
}

// lmsCycleRows запускает новый цикл прохождения: для курсов сбрасывает завершённое прохождение (история остаётся).
func (s *Server) lmsStartCycle(ctx context.Context, users, courses []int64) error {
	if len(users) == 0 {
		return nil
	}
	return s.tx(ctx, func(q pgx.Tx) error {
		if _, err := q.Exec(ctx, `DELETE FROM learn_step_progress sp USING unnest($1::bigint[], $2::bigint[]) x(u, c)
			WHERE sp.user_id = x.u AND sp.course_id = x.c AND EXISTS (SELECT 1 FROM learn_enrollments e WHERE e.user_id = sp.user_id AND e.course_id = sp.course_id AND e.status = 2)`, users, courses); err != nil {
			return err
		}
		_, err := q.Exec(ctx, `UPDATE learn_enrollments e SET status = 0, cycle = e.cycle + 1, started_at = NULL, last_at = NULL, completed_at = NULL, expires_at = NULL, steps_done = 0, percent = 0,
				time_sec = 0, score = NULL, cert_id = NULL, soon_notified = false
			FROM unnest($1::bigint[], $2::bigint[]) x(u, c) WHERE e.user_id = x.u AND e.course_id = x.c AND e.status = 2`, users, courses)
		return err
	})
}

// lmsJobRecur — периодическое переназначение (раз в N месяцев): выполненное назначение порождает новый цикл.
func (s *Server) lmsJobRecur(ctx context.Context) int {
	rows, err := s.db.Query(ctx, `INSERT INTO learn_assignees (assignment_id, user_id, dept_id, target_type, target_id, cycle, assigned_at, due_at, status, high, mandatory)
		SELECT a.assignment_id, a.user_id, u.department_id, a.target_type, a.target_id, a.cycle + 1, now(),
			CASE g.due_mode WHEN 'days' THEN now() + make_interval(days => g.due_days) WHEN 'date' THEN now() + (g.due_date - g.created_at) END, 0, g.priority = 'high', g.mandatory
		FROM learn_assignees a JOIN learn_assignments g ON g.id = a.assignment_id AND g.status = 'active' AND g.recur_months > 0
			JOIN users u ON u.id = a.user_id AND NOT u.blocked
		WHERE a.status = 2 AND a.done_at + make_interval(months => g.recur_months) <= now()
			AND NOT EXISTS (SELECT 1 FROM learn_assignees n WHERE n.assignment_id = a.assignment_id AND n.user_id = a.user_id AND n.cycle = a.cycle + 1)
		ORDER BY a.id LIMIT 20000
		ON CONFLICT (assignment_id, user_id, cycle) DO NOTHING RETURNING user_id, target_type, target_id`)
	if err != nil {
		s.log.Warn("lms recur", "err", err)
		return 0
	}
	n := s.lmsAfterCycle(ctx, rows, "Требуется повторное обучение")
	return n
}

type cycleRow struct {
	user int64
	typ  string
	id   int64
}

// lmsAfterCycle: сброс прохождения курсов и уведомление о повторном обучении (rows: user_id, target_type, target_id).
func (s *Server) lmsAfterCycle(ctx context.Context, rows interface {
	Next() bool
	Scan(...any) error
	Close()
}, title string) int {
	var list []cycleRow
	for rows.Next() {
		var r cycleRow
		rows.Scan(&r.user, &r.typ, &r.id)
		list = append(list, r)
	}
	rows.Close()
	var cu, cc []int64
	for _, r := range list {
		if r.typ == "course" {
			cu, cc = append(cu, r.user), append(cc, r.id)
		}
	}
	if err := s.lmsStartCycle(ctx, cu, cc); err != nil {
		s.log.Warn("lms start cycle", "err", err)
	}
	for _, r := range list {
		link := "/learning/courses/" + strconv.FormatInt(r.id, 10)
		name := ""
		if r.typ == "test" {
			link = "/learning/tests/" + strconv.FormatInt(r.id, 10)
			s.db.QueryRow(ctx, `SELECT title FROM learn_tests WHERE id = $1`, r.id).Scan(&name)
		} else {
			s.db.QueryRow(ctx, `SELECT title FROM learn_courses WHERE id = $1`, r.id).Scan(&name)
		}
		s.notify(ctx, []int64{r.user}, "learning", title+": "+name, "", link)
	}
	return len(list)
}

// lmsJobExpire — истёк срок действия результата курса: прохождение сбрасывается, активные назначения получают новый цикл.
func (s *Server) lmsJobExpire(ctx context.Context) int {
	rows, err := s.db.Query(ctx, `SELECT user_id, course_id FROM learn_enrollments WHERE status = 2 AND expires_at IS NOT NULL AND expires_at <= now() ORDER BY expires_at LIMIT 5000`)
	if err != nil {
		s.log.Warn("lms expire", "err", err)
		return 0
	}
	var us, cs []int64
	for rows.Next() {
		var u, c int64
		rows.Scan(&u, &c)
		us, cs = append(us, u), append(cs, c)
	}
	rows.Close()
	if len(us) == 0 {
		return 0
	}
	// новый цикл по действующим назначениям (идемпотентно по уникальному ключу)
	r2, err := s.db.Query(ctx, `INSERT INTO learn_assignees (assignment_id, user_id, dept_id, target_type, target_id, cycle, assigned_at, due_at, status, high, mandatory)
		SELECT a.assignment_id, a.user_id, u.department_id, a.target_type, a.target_id, a.cycle + 1, now(),
			CASE g.due_mode WHEN 'days' THEN now() + make_interval(days => g.due_days) WHEN 'date' THEN now() + (g.due_date - g.created_at) END, 0, g.priority = 'high', g.mandatory
		FROM unnest($1::bigint[], $2::bigint[]) x(uid, cid) JOIN learn_assignees a ON a.user_id = x.uid AND a.target_type = 'course' AND a.target_id = x.cid AND a.status = 2
			JOIN learn_assignments g ON g.id = a.assignment_id AND g.status = 'active' JOIN users u ON u.id = a.user_id AND NOT u.blocked
		WHERE NOT EXISTS (SELECT 1 FROM learn_assignees n WHERE n.assignment_id = a.assignment_id AND n.user_id = a.user_id AND n.cycle > a.cycle)
		ON CONFLICT (assignment_id, user_id, cycle) DO NOTHING RETURNING user_id, target_type, target_id`, us, cs)
	if err != nil {
		s.log.Warn("lms expire assignees", "err", err)
		return 0
	}
	// сначала сбрасываем все истёкшие прохождения, затем уведомляем (дубль сброса безопасен: статус уже не 2)
	var cyc []cycleRow
	for r2.Next() {
		var r cycleRow
		r2.Scan(&r.user, &r.typ, &r.id)
		cyc = append(cyc, r)
	}
	r2.Close()
	if err := s.lmsStartCycle(ctx, us, cs); err != nil {
		s.log.Warn("lms expire reset", "err", err)
		return 0
	}
	for i := range us {
		name := ""
		s.db.QueryRow(ctx, `SELECT title FROM learn_courses WHERE id = $1`, cs[i]).Scan(&name)
		s.notify(ctx, []int64{us[i]}, "learning", "Истёк срок действия результата: "+name, "Пройдите курс заново", "/learning/courses/"+strconv.FormatInt(cs[i], 10))
	}
	return len(us)
}

// lmsJobRemind — напоминания по срокам назначений. Ключ b<N> — за N дней до срока (b0 — в день срока), o<N> — N-й день просрочки.
// Ключи фиксируются в learn_reminders, повторный запуск (и другой экземпляр) не создаёт дублей.
func (s *Server) lmsJobRemind(ctx context.Context) int {
	var n int
	var uids []int64
	err := s.db.QueryRow(ctx, `WITH cand AS (
			SELECT a.id, a.user_id, a.target_type, a.target_id, a.due_at, g.remind_days, g.remind_overdue_days,
				(a.due_at AT TIME ZONE $1::text)::date - (now() AT TIME ZONE $1::text)::date AS d
			FROM learn_assignees a JOIN learn_assignments g ON g.id = a.assignment_id AND g.status = 'active'
			WHERE a.status < 2 AND a.due_at IS NOT NULL AND a.due_at < now() + interval '400 days' AND a.due_at > now() - interval '2 years'),
		k AS (
			SELECT cand.*, CASE WHEN d >= 0 AND d = ANY(remind_days) THEN 'b' || d
				WHEN d < 0 AND remind_overdue_days > 0 AND (d = -1 OR (-d) % remind_overdue_days = 0) THEN 'o' || (-d) END AS key FROM cand),
		ins AS (INSERT INTO learn_reminders (assignee_id, key) SELECT id, key FROM k WHERE key IS NOT NULL ON CONFLICT DO NOTHING RETURNING assignee_id, key),
		nt AS (
			INSERT INTO notifications (user_id, kind, title, body, link)
			SELECT k.user_id, 'learning',
				CASE WHEN ins.key = 'b0' THEN 'Сегодня последний день для обучения: '
					WHEN left(ins.key, 1) = 'b' THEN 'Срок обучения истекает через ' || substr(ins.key, 2) || ' дн.: '
					ELSE 'Просрочено обучение: ' END || coalesce(co.title, t.title, ''),
				CASE WHEN left(ins.key, 1) = 'b' THEN 'Срок: ' ELSE 'Срок был: ' END || to_char(k.due_at AT TIME ZONE $1::text, 'DD.MM.YYYY'),
				CASE k.target_type WHEN 'course' THEN '/learning/courses/' ELSE '/learning/tests/' END || k.target_id
			FROM ins JOIN k ON k.id = ins.assignee_id LEFT JOIN learn_courses co ON k.target_type = 'course' AND co.id = k.target_id
				LEFT JOIN learn_tests t ON k.target_type = 'test' AND t.id = k.target_id
			WHERE co.id IS NOT NULL OR t.id IS NOT NULL RETURNING user_id)
		SELECT (SELECT count(*) FROM nt), coalesce((SELECT array_agg(user_id) FROM (SELECT user_id FROM nt LIMIT 2001) x), '{}')`, s.loc().String()).Scan(&n, &uids)
	if err != nil {
		s.log.Warn("lms remind", "err", err)
		return 0
	}
	s.lmsEmit(ctx, n, uids, "Напоминание об обучении")
	return n
}

// lmsEmit — живое уведомление: адресно при небольшом числе получателей, иначе общий сигнал обновления.
func (s *Server) lmsEmit(ctx context.Context, n int, uids []int64, title string) {
	if n == 0 {
		return
	}
	if len(uids) <= 2000 {
		s.hub.EmitUsers(ctx, uids, "notif", map[string]string{"kind": "learning", "title": title, "body": "", "link": "/learning/my"})
	} else {
		s.hub.Emit(ctx, "feed", "refresh", map[string]string{"what": "notifications"})
	}
}

// lmsJobCertSoon — «скоро истекает» срок действия сертификата (за expire_remind_days шаблона, по умолчанию 30).
func (s *Server) lmsJobCertSoon(ctx context.Context) int {
	var n int
	var uids []int64
	err := s.db.QueryRow(ctx, `WITH c AS (
			SELECT k.id FROM learn_certs k LEFT JOIN learn_cert_templates t ON t.id = k.template_id
			WHERE k.status = 'valid' AND k.expires_at IS NOT NULL AND NOT k.soon_notified AND k.expires_at > now()
				AND k.expires_at <= now() + make_interval(days => coalesce(t.expire_remind_days, 30)) AND coalesce(t.expire_remind_days, 30) > 0 LIMIT 20000),
		u AS (UPDATE learn_certs k SET soon_notified = true FROM c WHERE k.id = c.id AND k.user_id IS NOT NULL RETURNING k.id, k.user_id, k.title, k.expires_at),
		nt AS (INSERT INTO notifications (user_id, kind, title, body, link)
			SELECT user_id, 'learning', 'Срок действия сертификата истекает: ' || title, 'Действителен до ' || to_char(expires_at AT TIME ZONE $1::text, 'DD.MM.YYYY'), '/learning/certificates/' || id FROM u RETURNING user_id)
		SELECT (SELECT count(*) FROM nt), coalesce((SELECT array_agg(user_id) FROM (SELECT user_id FROM nt LIMIT 2001) x), '{}')`, s.loc().String()).Scan(&n, &uids)
	if err != nil {
		s.log.Warn("lms cert soon", "err", err)
		return 0
	}
	s.lmsEmit(ctx, n, uids, "Срок действия сертификата истекает")
	return n
}

// lmsJobDigest — раз в сутки (после 8:00) руководителям подразделений и ответственным за обучение: сколько сотрудников
// их области просрочили обязательное обучение.
func (s *Server) lmsJobDigest(ctx context.Context) int {
	now := time.Now().In(s.loc())
	if now.Hour() < 8 {
		return 0
	}
	day := now.Format("2006-01-02")
	own := map[int64]int{}
	rows, err := s.db.Query(ctx, `SELECT a.dept_id, count(DISTINCT a.user_id) FROM learn_assignees a JOIN users u ON u.id = a.user_id AND NOT u.blocked
		WHERE a.status < 2 AND a.mandatory AND a.due_at < now() AND a.dept_id IS NOT NULL GROUP BY a.dept_id`)
	if err != nil {
		s.log.Warn("lms digest", "err", err)
		return 0
	}
	for rows.Next() {
		var d int64
		var c int
		rows.Scan(&d, &c)
		own[d] = c
	}
	rows.Close()
	if len(own) == 0 {
		return 0
	}
	parent := map[int64]*int64{}
	kids := map[int64][]int64{}
	rows, err = s.db.Query(ctx, `SELECT id, parent_id FROM departments`)
	if err != nil {
		return 0
	}
	for rows.Next() {
		var id int64
		var p *int64
		rows.Scan(&id, &p)
		parent[id] = p
		if p != nil {
			kids[*p] = append(kids[*p], id)
		}
	}
	rows.Close()
	total := map[int64]int{}
	var sum func(id int64, depth int) int
	sum = func(id int64, depth int) int {
		if v, ok := total[id]; ok {
			return v
		}
		n := own[id]
		if depth < 64 {
			for _, k := range kids[id] {
				n += sum(k, depth+1)
			}
		}
		total[id] = n
		return n
	}
	roots := map[int64]map[int64]bool{} // получатель → корневые подразделения
	add := func(u, d int64) {
		if roots[u] == nil {
			roots[u] = map[int64]bool{}
		}
		roots[u][d] = true
	}
	rows, err = s.db.Query(ctx, `SELECT id, department_id FROM users WHERE NOT blocked AND department_id IS NOT NULL AND (learning_manager OR is_head)
		UNION SELECT user_id, department_id FROM learning_manager_departments m JOIN users u ON u.id = m.user_id AND NOT u.blocked AND u.learning_manager`)
	if err != nil {
		return 0
	}
	for rows.Next() {
		var u, d int64
		rows.Scan(&u, &d)
		add(u, d)
	}
	rows.Close()
	var recips []int64
	counts := map[int64]int{}
	for u, rs := range roots {
		n := 0
		for r := range rs {
			dup := false // корень внутри другого корня того же получателя не считаем дважды
			for p := parent[r]; p != nil && !dup; p = parent[*p] {
				dup = rs[*p]
			}
			if !dup {
				n += sum(r, 0)
			}
		}
		if n > 0 {
			recips, counts[u] = append(recips, u), n
		}
	}
	if len(recips) == 0 {
		return 0
	}
	rows, err = s.db.Query(ctx, `INSERT INTO learn_digests (user_id, day) SELECT x, $2::date FROM unnest($1::bigint[]) x ON CONFLICT DO NOTHING RETURNING user_id`, recips, day)
	if err != nil {
		s.log.Warn("lms digest insert", "err", err)
		return 0
	}
	var fresh []int64
	for rows.Next() {
		var u int64
		rows.Scan(&u)
		fresh = append(fresh, u)
	}
	rows.Close()
	for _, u := range fresh {
		s.notify(ctx, []int64{u}, "learning", "Просрочено обучение: "+plural(counts[u], "сотрудник", "сотрудника", "сотрудников"), "Список просрочек и кнопка «Напомнить» — в статистике обучения", "/learning/stats?tab=overdue")
	}
	return len(fresh)
}

func plural(n int, one, few, many string) string {
	m10, m100 := n%10, n%100
	w := many
	switch {
	case m10 == 1 && m100 != 11:
		w = one
	case m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20):
		w = few
	}
	return strconv.Itoa(n) + " " + w
}
