package server

import (
	"context"
	"encoding/json"
	"strconv"
	"strings"
	"time"
)

// Realtime между ЦОДами без Redis.
//
// Redis Pub/Sub не реплицируется между площадками, а растянутый Redis Cluster через WAN ненадёжен. Поэтому в режиме
// REALTIME_MODE=pg события пишутся в таблицу realtime_events основной БД (outbox) и приезжают в каждый ЦОД вместе с
// обычной потоковой репликацией PostgreSQL. Каждый экземпляр раз в ~300 мс читает новые строки со своей реплики.
//
// Порядок и полнота. Значения bigserial выдаются не в порядке фиксации транзакций, поэтому читать «id > last»
// нельзя: можно пропустить событие, зафиксированное позже, но с меньшим id. Вместо этого строка помечается номером
// транзакции (xid), а читатель берёт только строки с xid < xmin текущего снимка — то есть все транзакции с меньшими
// номерами уже завершены и видны. Позиция читателя — пара (xid, id), она движется строго вперёд.

const pollInterval = 300 * time.Millisecond

func (h *Hub) topicList() []string {
	h.mu.RLock()
	defer h.mu.RUnlock()
	out := make([]string, 0, len(h.topics)+1)
	for t := range h.topics {
		out = append(out, t)
	}
	return append(out, "sys")
}

const pgBound = `SELECT xid, id FROM realtime_events WHERE xid < pg_snapshot_xmin(pg_current_snapshot())::text::bigint
	ORDER BY xid DESC, id DESC LIMIT 1`

func (h *Hub) pollPG(ctx context.Context) {
	s := h.s
	var lx, li int64
	for { // стартуем с «сейчас»: историю не воспроизводим
		err := s.ro.QueryRow(ctx, `SELECT coalesce(max(xid), 0), coalesce(max(id), 0) FROM (`+pgBound+`) b`).Scan(&lx, &li)
		if err == nil {
			break
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(time.Second):
		}
	}
	t := time.NewTicker(pollInterval)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		var bx, bi int64
		err := s.ro.QueryRow(ctx, `SELECT xid, id FROM (`+pgBound+`) b`).Scan(&bx, &bi)
		if err != nil {
			continue // нет новых строк (или реплика недоступна): повторим на следующем тике
		}
		if bx < lx || (bx == lx && bi <= li) {
			continue
		}
		rows, err := s.ro.Query(ctx, `SELECT topic, payload FROM realtime_events
			WHERE (xid, id) > ($1::bigint, $2::bigint) AND (xid, id) <= ($3::bigint, $4::bigint) AND topic = ANY($5)
			ORDER BY xid, id`, lx, li, bx, bi, h.topicList())
		if err != nil {
			s.log.Warn("outbox poll failed", "err", err)
			continue
		}
		type ev struct{ topic, payload string }
		var evs []ev
		for rows.Next() {
			var e ev
			if rows.Scan(&e.topic, &e.payload) == nil {
				evs = append(evs, e)
			}
		}
		rows.Close()
		lx, li = bx, bi
		for _, e := range evs {
			h.deliver(e.topic, []byte(e.payload))
		}
	}
}

// outboxCleanup removes delivered events (every instance has long since read them).
func (s *Server) outboxCleanup(ctx context.Context) {
	if s.cfg.Realtime != "pg" || !s.lock(ctx, "outbox-cleanup", 50*time.Second) {
		return
	}
	s.db.Exec(ctx, `DELETE FROM realtime_events WHERE created_at < now() - interval '15 minutes'`)
}

// ---------------------------------------------------------------- sys events (cache invalidation across DCs)

// sys разносит сброс кэшей по ЦОДам (в одном ЦОДе вызывающий уже сделал это сам).
func (s *Server) sys(ctx context.Context, kind string, v any) {
	if s.cfg.Realtime != "pg" {
		return
	}
	s.hub.Emit(ctx, "sys", kind, v)
}

func (s *Server) handleSys(payload []byte) {
	var m struct {
		T string  `json:"t"`
		D float64 `json:"d"`
	}
	if err := json.Unmarshal(payload, &m); err != nil {
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	switch m.T {
	case "drop_user":
		s.rdb.Del(ctx, "u:"+strconv.FormatInt(int64(m.D), 10))
	case "kill_user":
		s.killLocalSessions(ctx, int64(m.D))
		s.rdb.Del(ctx, "u:"+strconv.FormatInt(int64(m.D), 10))
	case "news":
		s.rdb.Incr(ctx, "c:news:ver")
	}
}

// lock — глобальная блокировка фоновой задачи: строка в основной БД, поэтому работает между ЦОДами.
func (s *Server) lock(ctx context.Context, name string, ttl time.Duration) bool {
	var got string
	err := s.db.QueryRow(ctx, `INSERT INTO job_locks (name, holder, locked_until) VALUES ($1, $2, now() + $3::interval)
		ON CONFLICT (name) DO UPDATE SET holder = EXCLUDED.holder, locked_until = EXCLUDED.locked_until WHERE job_locks.locked_until < now()
		RETURNING holder`, name, s.cfg.InstanceID, strconv.Itoa(int(ttl.Seconds()))+" seconds").Scan(&got)
	return err == nil && got == s.cfg.InstanceID
}

func (s *Server) unlock(ctx context.Context, name string) {
	s.db.Exec(ctx, `UPDATE job_locks SET locked_until = now() WHERE name = $1 AND holder = $2`, name, s.cfg.InstanceID)
}

var _ = strings.TrimSpace
