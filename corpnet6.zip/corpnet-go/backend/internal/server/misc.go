package server

import (
	"encoding/json"
	"strings"
)

// ---------------------------------------------------------------- resources

func (s *Server) listResources(c *Ctx) error {
	b, err := s.arr(c.Context(), `SELECT id, name, description, url, icon, sort FROM resources ORDER BY sort, id`)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) saveResource(c *Ctx) error {
	var in struct {
		Name, Description, URL, Icon string
		Sort                         int
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Name, in.URL = strings.TrimSpace(in.Name), strings.TrimSpace(in.URL)
	if in.Name == "" || !(strings.HasPrefix(in.URL, "http://") || strings.HasPrefix(in.URL, "https://")) {
		return badReq("Укажите название и ссылку, начинающуюся с http:// или https://")
	}
	if in.Icon == "" {
		in.Icon = "link"
	}
	var id int64
	if c.R.PathValue("id") != "" {
		var err error
		if id, err = c.ID("id"); err != nil {
			return err
		}
		if _, err := s.db.Exec(c.Context(), `UPDATE resources SET name = $2, description = $3, url = $4, icon = $5, sort = $6 WHERE id = $1`,
			id, in.Name, in.Description, in.URL, in.Icon, in.Sort); err != nil {
			return err
		}
	} else if err := s.db.QueryRow(c.Context(), `INSERT INTO resources (name, description, url, icon, sort) VALUES ($1, $2, $3, $4, $5) RETURNING id`,
		in.Name, in.Description, in.URL, in.Icon, in.Sort).Scan(&id); err != nil {
		return err
	}
	s.audit(c, "resource.save", "resource", id, map[string]string{"name": in.Name})
	return c.JSON(200, map[string]int64{"id": id})
}

func (s *Server) deleteResource(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, err := s.db.Exec(c.Context(), `DELETE FROM resources WHERE id = $1`, id); err != nil {
		return err
	}
	s.audit(c, "resource.delete", "resource", id, nil)
	return c.OK()
}

// ---------------------------------------------------------------- company

func (s *Server) getCompany(c *Ctx) error {
	b, err := s.one(c.Context(), `SELECT * FROM company WHERE id = 1`)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) putCompany(c *Ctx) error {
	var in struct {
		Name, Tagline, About, Address, Phone, Email, Logo string
		Founded                                           int
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if strings.TrimSpace(in.Name) == "" {
		return badReq("Укажите название компании")
	}
	if _, err := s.db.Exec(c.Context(), `UPDATE company SET name = $1, tagline = $2, about = $3, address = $4, phone = $5, email = $6, logo = $7, founded = $8 WHERE id = 1`,
		in.Name, in.Tagline, in.About, in.Address, in.Phone, in.Email, in.Logo, in.Founded); err != nil {
		return err
	}
	s.audit(c, "company.update", "company", 1, nil)
	return s.getCompany(c)
}

// ---------------------------------------------------------------- categories

func (s *Server) listCategories(c *Ctx) error {
	b, err := s.arr(c.Context(), `SELECT id, name, color, sort,
		(SELECT count(*) FROM news n WHERE n.category_id = categories.id) AS news_count FROM categories ORDER BY sort, id`)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) saveCategory(c *Ctx) error {
	var in struct {
		Name, Color string
		Sort        int
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Name = strings.TrimSpace(in.Name)
	if in.Name == "" {
		return badReq("Укажите название")
	}
	if in.Color == "" {
		in.Color = "#286b9e"
	}
	var id int64
	if c.R.PathValue("id") != "" {
		var err error
		if id, err = c.ID("id"); err != nil {
			return err
		}
		if _, err := s.db.Exec(c.Context(), `UPDATE categories SET name = $2, color = $3, sort = $4 WHERE id = $1`, id, in.Name, in.Color, in.Sort); err != nil {
			return err
		}
	} else if err := s.db.QueryRow(c.Context(), `INSERT INTO categories (name, color, sort) VALUES ($1, $2, $3) RETURNING id`, in.Name, in.Color, in.Sort).Scan(&id); err != nil {
		return err
	}
	s.bumpNews(c.Context())
	s.audit(c, "category.save", "category", id, map[string]string{"name": in.Name})
	return c.JSON(200, map[string]int64{"id": id})
}

func (s *Server) deleteCategory(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, err := s.db.Exec(c.Context(), `DELETE FROM categories WHERE id = $1`, id); err != nil {
		return err
	}
	s.bumpNews(c.Context())
	s.audit(c, "category.delete", "category", id, nil)
	return c.OK()
}

// ---------------------------------------------------------------- notifications

// listNotifications — постраничный (keyset по id) список. По умолчанию только непрочитанные; filter=read — прочитанные.
func (s *Server) listNotifications(c *Ctx) error {
	ctx := c.Context()
	per := min(max(c.QInt("per", 20), 1), 50)
	cond := "read_at IS NULL"
	if c.Q("filter") == "read" {
		cond = "read_at IS NOT NULL"
	}
	rows, err := s.db.Query(ctx, `SELECT row_to_json(t) FROM (SELECT id, kind, title, body, link, created_at, read_at IS NOT NULL AS read
		FROM notifications WHERE user_id = $1 AND `+cond+` AND ($2::bigint = 0 OR id < $2) ORDER BY id DESC LIMIT $3) t`,
		c.U.ID, c.QInt64("cursor"), per+1)
	if err != nil {
		return err
	}
	var list []json.RawMessage
	var lastID int64
	for rows.Next() {
		var b []byte
		if err := rows.Scan(&b); err != nil {
			rows.Close()
			return err
		}
		list = append(list, b)
	}
	rows.Close()
	more := len(list) > per
	if more {
		list = list[:per]
	}
	if list == nil {
		list = []json.RawMessage{}
	} else {
		var last struct {
			ID int64 `json:"id"`
		}
		json.Unmarshal(list[len(list)-1], &last)
		lastID = last.ID
	}
	unread, _, err := s.unreadCounts(ctx, c.U.ID)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"items": list, "has_more": more, "next": lastID, "unread": unread})
}

func (s *Server) readNotifications(c *Ctx) error {
	var in struct {
		IDs []int64 `json:"ids"`
		All bool    `json:"all"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if in.IDs == nil {
		in.IDs = []int64{}
	}
	if _, err := s.db.Exec(c.Context(), `UPDATE notifications SET read_at = now() WHERE user_id = $1 AND read_at IS NULL AND ($2 OR id = ANY($3))`,
		c.U.ID, in.All, in.IDs); err != nil {
		return err
	}
	s.hub.Emit(c.Context(), userTopic(c.U.ID), "refresh", map[string]string{"what": "notifications"}) // sync other devices
	unread, _, err := s.unreadCounts(c.Context(), c.U.ID)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"ok": true, "unread": unread})
}

// ---------------------------------------------------------------- search

// search — глобальный поиск. Без стемминга: совпадение по подстроке заголовка/имени (триграммные индексы)
// и по префиксам слов (tsvector 'simple'); поэтому «иии» находит только то, что реально содержит «иии».
// Работает на реплике; каждая выборка ограничена несколькими строками и идёт по индексу.
func (s *Server) search(c *Ctx) error {
	q := c.Q("q")
	if len([]rune(q)) < 2 || len(searchTokens(q)) == 0 {
		return c.Raw(200, []byte(`{"news":[],"users":[],"departments":[],"files":[],"groups":[],"ideas":[],"file_content":[],"wiki":[]}`))
	}
	ctx := c.Context()
	like := "%" + likeEscape(strings.Join(searchTokens(q), " ")) + "%"

	nw := &whereBuilder{}
	nw.raw(visibleNow)
	s.searchNews(ctx, nw, q)
	news, err := s.arr2(ctx, `SELECT n.id, n.title, n.cover, n.published_at, c.name AS category FROM news n LEFT JOIN categories c ON c.id = n.category_id
		WHERE `+nw.String()+` ORDER BY n.published_at DESC, n.id DESC LIMIT 6`, nw.args...)
	if err != nil {
		return err
	}
	uw := &whereBuilder{}
	uw.raw("NOT u.blocked")
	s.userSearch(ctx, uw, q)
	users, err := s.arr2(ctx, `SELECT u.id, u.full_name AS name, u.job_title, u.avatar, u.is_head, d.name AS department`+userFrom+
		` WHERE `+uw.String()+` ORDER BY `+userOrder+` LIMIT 6`, uw.args...)
	if err != nil {
		return err
	}
	deps, err := s.arr2(ctx, `SELECT id, name FROM departments WHERE lower(name) LIKE $1 ESCAPE '\' ORDER BY sort, lower(name) LIMIT 5`, like)
	if err != nil {
		return err
	}
	files, err := s.arr2(ctx, `SELECT f.id, f.name, f.mime, f.size, fo.id AS folder_id, fo.kind, fo.name AS folder
		FROM files f JOIN folders fo ON fo.id = f.folder_id
		WHERE f.context = 'folder' AND lower(f.name) LIKE $1 ESCAPE '\' AND `+aclVisible("folder", "fo", 2, 3, 4)+` ORDER BY f.id DESC LIMIT 6`,
		like, c.U.ID, c.U.Dept, c.U.IsAdmin())
	if err != nil {
		return err
	}
	groups, err := s.arr2(ctx, `SELECT g.id, g.name, g.visibility FROM user_groups g
		WHERE lower(g.name) LIKE $3 ESCAPE '\' AND `+groupVisible+` ORDER BY lower(g.name) LIMIT 5`, c.U.ID, c.U.IsAdmin(), like)
	if err != nil {
		return err
	}
	ideas, err := s.arr2(ctx, `SELECT id, title FROM ideas WHERE lower(title) LIKE $1 ESCAPE '\' OR search_simple @@ to_tsquery('simple', $2)
		ORDER BY id DESC LIMIT 4`, like, tsPrefixQuery(q))
	if err != nil {
		return err
	}
	fileContent, err := s.searchFileContent(ctx, c.U, q, 6) // по содержимому файлов, с учётом прав (filesearch.go)
	if err != nil {
		return err
	}
	fc, _ := json.Marshal(fileContent)
	s.logSearch(c, "global", q, anCount(news, users, deps, files, groups, ideas, fc)) // аналитика поиска
	return c.JSON(200, map[string]json.RawMessage{"file_content": fc, "news": news, "users": users, "departments": deps, "files": files, "groups": groups, "ideas": ideas, "wiki": s.wikiSearchBrief(c, q, 6)})
}
