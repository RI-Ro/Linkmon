package server

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
)

// Фоновые задачи раздела «Заявки»: напоминания о сроке, просрочка и эскалация, замещение «на лету» (отпуск начался уже после
// назначения), уборка неиспользованных вложений. Запускаются из minuteJobs каждого экземпляра, но:
//   1) под блокировкой job_locks — обычно работает один экземпляр на минуту;
//   2) каждая строка «забирается» атомарным UPDATE … RETURNING (FOR UPDATE SKIP LOCKED), поэтому даже при двух одновременно
//      работающих экземплярах (в том числе в разных ЦОДах) напоминание/эскалация по одной позиции уходит ровно один раз.

func (s *Server) requestsJob(ctx context.Context) {
	if !s.lock(ctx, "requests:tick", 45*time.Second) {
		return
	}
	s.reqVacationSwap(ctx)
	s.reqReminders(ctx)
	s.reqOverdue(ctx)
	day := time.Now().Format("2006-01-02")
	if s.lock(ctx, "requests:gc:"+day, 26*time.Hour) {
		s.reqGC(ctx)
	}
}

func (s *Server) reqReminders(ctx context.Context) {
	rows, err := s.db.Query(ctx, `WITH c AS (
			UPDATE req_assignees a SET remind_sent_at = now()
			WHERE a.id IN (SELECT id FROM req_assignees WHERE state = 'pending' AND remind_sent_at IS NULL AND remind_at IS NOT NULL AND remind_at <= now()
				ORDER BY remind_at LIMIT 500 FOR UPDATE SKIP LOCKED)
			RETURNING a.request_id, a.step_id, a.user_id, a.due_at)
		SELECT c.request_id, c.step_id, c.user_id, c.due_at, coalesce(r.number, ''), r.title FROM c JOIN req_requests r ON r.id = c.request_id`)
	if err != nil {
		s.log.Warn("requests reminders failed", "err", err)
		return
	}
	defer rows.Close()
	loc := s.reqLoc()
	type item struct {
		rid, step, uid int64
		due            *time.Time
		num, title     string
	}
	var items []item
	for rows.Next() {
		var it item
		if rows.Scan(&it.rid, &it.step, &it.uid, &it.due, &it.num, &it.title) == nil {
			items = append(items, it)
		}
	}
	rows.Close()
	for _, it := range items {
		due := ""
		if it.due != nil {
			due = " до " + it.due.In(loc).Format("02.01 15:04")
		}
		s.notify(ctx, []int64{it.uid}, "request", "Заявка "+it.num+": срок решения истекает"+due, it.title, reqLink(it.rid, it.step))
		s.hub.EmitUsers(ctx, []int64{it.uid}, "req", map[string]any{"id": it.rid})
	}
}

func (s *Server) reqOverdue(ctx context.Context) {
	rows, err := s.db.Query(ctx, `WITH c AS (
			UPDATE req_assignees a SET overdue_sent_at = now()
			WHERE a.id IN (SELECT id FROM req_assignees WHERE state = 'pending' AND overdue_sent_at IS NULL AND due_at IS NOT NULL AND due_at <= now()
				ORDER BY due_at LIMIT 500 FOR UPDATE SKIP LOCKED)
			RETURNING a.id, a.request_id, a.step_id, a.user_id, a.esc_to IS NOT NULL AS esc)
		SELECT c.id, c.request_id, c.step_id, c.user_id, c.esc, coalesce(r.number, ''), r.title, coalesce(r.author_id, 0) FROM c JOIN req_requests r ON r.id = c.request_id`)
	if err != nil {
		s.log.Warn("requests overdue failed", "err", err)
		return
	}
	type item struct {
		id, rid, step, uid, author int64
		esc                        bool
		num, title                 string
	}
	var items []item
	for rows.Next() {
		var it item
		if rows.Scan(&it.id, &it.rid, &it.step, &it.uid, &it.esc, &it.num, &it.title, &it.author) == nil {
			items = append(items, it)
		}
	}
	rows.Close()
	for _, it := range items {
		s.notify(ctx, []int64{it.uid}, "request", "Заявка "+it.num+": срок решения истёк", it.title, reqLink(it.rid, it.step))
		if _, err := s.db.Exec(ctx, `INSERT INTO req_events (request_id, step_id, actor_id, kind, text, data) VALUES ($1, $2, NULL, 'overdue', $3, $4::jsonb)`,
			it.rid, it.step, "Срок решения истёк: "+s.userName2(ctx, it.uid), fmt.Sprintf(`{"user":%d}`, it.uid)); err != nil {
			s.log.Warn("requests overdue event failed", "err", err)
		}
		touch := []int64{it.uid}
		if it.author > 0 {
			s.notify(ctx, []int64{it.author}, "request", "Заявка "+it.num+": просрочено решение", it.title, reqLink(it.rid, it.step))
			touch = append(touch, it.author)
		}
		if it.esc {
			if err := s.reqEscalate(ctx, it.rid, it.id); err != nil {
				s.log.Warn("requests escalation failed", "request", it.rid, "err", err)
			}
		}
		s.hub.EmitUsers(ctx, touch, "req", map[string]any{"id": it.rid})
	}
}

func (s *Server) userName2(ctx context.Context, id int64) string {
	var n string
	_ = s.db.QueryRow(ctx, `SELECT full_name FROM users WHERE id = $1`, id).Scan(&n)
	return n
}

// reqEscalate добавляет вышестоящего (или резервного) исполнителя к просроченной позиции. Исходный исполнитель остаётся,
// решение любого из двоих закрывает позицию (см. reqEvalStep: запасные исполнители не увеличивают число требуемых решений).
func (s *Server) reqEscalate(ctx context.Context, rid, asgID int64) error {
	var out *reqOut
	err := s.tx(ctx, func(tx pgx.Tx) error {
		r, err := s.reqLoad(ctx, tx, rid, true)
		if err != nil {
			return err
		}
		if r.Status != "pending" && r.Status != "in_progress" {
			return nil
		}
		var user, step int64
		var branch int
		var esc *string
		var kind string
		err = tx.QueryRow(ctx, `SELECT a.user_id, a.step_id, a.branch, a.esc_to::text, s.kind FROM req_assignees a JOIN req_steps s ON s.id = a.step_id
			WHERE a.id = $1 AND a.state = 'pending' AND a.escalated_at IS NULL AND s.state = 'active'`, asgID).Scan(&user, &step, &branch, &esc, &kind)
		if err == pgx.ErrNoRows || esc == nil {
			return nil
		}
		if err != nil {
			return err
		}
		var rule reqEsc
		if json.Unmarshal([]byte(*esc), &rule) != nil {
			return nil
		}
		var target int64
		switch rule.To {
		case "user":
			target = rule.UserID
		case "manager", "manager_up":
			var dept *int64
			_ = tx.QueryRow(ctx, `SELECT department_id FROM users WHERE id = $1`, user).Scan(&dept)
			heads, err := s.reqHeads(ctx, tx, dept, user)
			if err != nil {
				return err
			}
			n := 0
			if rule.To == "manager_up" {
				n = max(rule.N, 1)
			}
			if len(heads) > n {
				target = heads[n]
			}
		}
		if _, err := tx.Exec(ctx, `UPDATE req_assignees SET escalated_at = now() WHERE id = $1`, asgID); err != nil {
			return err
		}
		out = newReqOut(rid)
		if target == 0 || target == user || target == r.AuthorID {
			_, err := s.reqEvent(ctx, tx, rid, step, 0, "escalation_failed", "Эскалация не выполнена: не найден вышестоящий руководитель", nil)
			return err
		}
		picks, _, err := s.reqSubstitute(ctx, tx, []int64{target}, r.AuthorID)
		if err != nil {
			return err
		}
		if len(picks) > 0 {
			target = picks[0].User
		}
		tag, err := tx.Exec(ctx, `INSERT INTO req_assignees (request_id, step_id, branch, mode, user_id, via, orig_user_id)
			SELECT a.request_id, a.step_id, a.branch, a.mode, $2, 'escalation', a.user_id FROM req_assignees a WHERE a.id = $1
			ON CONFLICT (step_id, user_id) DO NOTHING`, asgID, target)
		if err != nil {
			return err
		}
		if tag.RowsAffected() == 0 {
			return nil
		}
		if _, err := s.reqEvent(ctx, tx, rid, step, 0, "escalated", "Эскалация: "+s.userName(ctx, tx, target)+" (вместо "+s.userName(ctx, tx, user)+")", map[string]any{"user": target, "orig": user}); err != nil {
			return err
		}
		out.note([]int64{target}, "Заявка "+r.label()+": эскалация — "+reqKindVerb(kind), r.TypeName+" — "+r.AuthorName+". Просрочено: "+s.userName(ctx, tx, user), reqLink(rid, step))
		return nil
	})
	if err != nil {
		return err
	}
	if out != nil {
		s.reqFlush(ctx, out)
	}
	return nil
}

// reqVacationSwap: пока заявка ждёт решения, согласующий ушёл в отпуск (запись в графике появилась позже) — позиция
// переадресуется заместителю из графика.
func (s *Server) reqVacationSwap(ctx context.Context) {
	today := time.Now().In(s.reqLoc()).Format("2006-01-02")
	rows, err := s.db.Query(ctx, `WITH v AS (
			SELECT DISTINCT ON (vv.user_id) vv.user_id, vv.deputy_id FROM vacations vv JOIN users du ON du.id = vv.deputy_id AND NOT du.blocked
			WHERE $1::date BETWEEN vv.starts_on AND vv.ends_on ORDER BY vv.user_id, vv.id DESC),
		c AS (
			UPDATE req_assignees a SET user_id = v.deputy_id, orig_user_id = a.user_id, via = 'deputy'
			FROM v, req_requests r
			WHERE a.user_id = v.user_id AND a.state = 'pending' AND a.via = 'direct' AND r.id = a.request_id AND r.author_id IS DISTINCT FROM v.deputy_id
				AND NOT EXISTS (SELECT 1 FROM vacations w WHERE w.user_id = v.deputy_id AND $1::date BETWEEN w.starts_on AND w.ends_on)
				AND NOT EXISTS (SELECT 1 FROM req_assignees x WHERE x.step_id = a.step_id AND x.user_id = v.deputy_id)
			RETURNING a.request_id, a.step_id, a.user_id, a.orig_user_id)
		SELECT c.request_id, c.step_id, c.user_id, c.orig_user_id, coalesce(r.number, ''), r.title FROM c JOIN req_requests r ON r.id = c.request_id`, today)
	if err != nil {
		s.log.Warn("requests vacation swap failed", "err", err)
		return
	}
	type item struct {
		rid, step, uid, orig int64
		num, title           string
	}
	var items []item
	for rows.Next() {
		var it item
		if rows.Scan(&it.rid, &it.step, &it.uid, &it.orig, &it.num, &it.title) == nil {
			items = append(items, it)
		}
	}
	rows.Close()
	for _, it := range items {
		who, orig := s.userName2(ctx, it.uid), s.userName2(ctx, it.orig)
		s.db.Exec(ctx, `INSERT INTO req_events (request_id, step_id, kind, text, data) VALUES ($1, $2, 'substituted', $3, $4::jsonb)`,
			it.rid, it.step, orig+" в отпуске — шаг передан заместителю: "+who, fmt.Sprintf(`{"user":%d,"orig":%d,"via":"deputy"}`, it.uid, it.orig))
		s.notify(ctx, []int64{it.uid}, "request", "Заявка "+it.num+": вы замещаете "+orig, it.title, reqLink(it.rid, it.step))
		s.hub.EmitUsers(ctx, []int64{it.uid, it.orig}, "req", map[string]any{"id": it.rid})
	}
}

// reqGC удаляет загруженные, но так и не привязанные к заявке файлы (старше 3 суток).
func (s *Server) reqGC(ctx context.Context) {
	rows, err := s.db.Query(ctx, `DELETE FROM files f WHERE f.id IN (
			SELECT id FROM files x WHERE x.context = 'request' AND x.created_at < now() - interval '3 days'
				AND NOT EXISTS (SELECT 1 FROM req_files rf WHERE rf.file_id = x.id) LIMIT 1000)
		RETURNING f.storage, f.thumb, f.view`)
	if err != nil {
		s.log.Warn("requests gc failed", "err", err)
		return
	}
	defer rows.Close()
	n := 0
	for rows.Next() {
		var a, b, c string
		if rows.Scan(&a, &b, &c) == nil {
			s.removeStored(false, a, b, c)
			n++
		}
	}
	if n > 0 {
		s.log.Info("requests: removed unattached files", "n", n)
	}
}
