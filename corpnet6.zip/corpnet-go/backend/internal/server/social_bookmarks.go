package server

import (
	"context"
	"strings"
	"time"
	"unicode"
)

// Закладки: bookmarks (user_id, entity_type, entity_id, created_at, note) + реестр резолверов типов.
//
// Другие блоки регистрируют свой тип в init():
//
//	registerBookmarkResolver("wiki_page", func(ctx context.Context, s *Server, u *User, ids []int64) (map[int64]BookmarkInfo, error) {...}, BookmarkMeta{"Wiki", "wiki"})
//
// Резолвер получает пачку id и ОБЯЗАН вернуть только те, что пользователь вправе видеть (недоступные в закладках скрываются,
// а добавить закладку на недоступное нельзя). Один запрос на тип. Повторная регистрация того же типа заменяет резолвер.

type BookmarkInfo struct {
	Title    string    `json:"title"`
	Subtitle string    `json:"subtitle"`
	Link     string    `json:"link"` // абсолютный путь SPA (validAppLink)
	At       time.Time `json:"at"`
}

type bookmarkFn func(ctx context.Context, s *Server, u *User, ids []int64) (map[int64]BookmarkInfo, error)

type bookmarkResolver struct {
	Label string // «Новости» — заголовок группы в списке
	Icon  string // подсказка клиенту (news, idea, file, post, event, message, learn, wiki …)
	Fn    bookmarkFn
}

var (
	bookmarkResolvers = map[string]*bookmarkResolver{}
	bookmarkOrder     []string
)

// BookmarkMeta — подпись группы и значок типа в странице «Закладки» (необязательно: по умолчанию подпись = имя типа).
type BookmarkMeta struct{ Label, Icon string }

func registerBookmarkResolver(typ string, fn bookmarkFn, meta ...BookmarkMeta) {
	r := &bookmarkResolver{Label: typ, Icon: "bookmark", Fn: fn}
	if len(meta) > 0 {
		if meta[0].Label != "" {
			r.Label = meta[0].Label
		}
		if meta[0].Icon != "" {
			r.Icon = meta[0].Icon
		}
	}
	if _, ok := bookmarkResolvers[typ]; !ok {
		bookmarkOrder = append(bookmarkOrder, typ)
	}
	bookmarkResolvers[typ] = r
}

// bmQuery выполняет SELECT id, title, subtitle, link, at; параметры: $1 ids, $2 пользователь, $3 подразделение, $4 админ, $5 редактор.
func (s *Server) bmQuery(ctx context.Context, u *User, q string, ids []int64) (map[int64]BookmarkInfo, error) {
	// обёртка ссылается на все пять параметров (Postgres не принимает неиспользованные $N)
	rows, err := s.db.Query(ctx, `SELECT * FROM (`+q+`) t WHERE $1::bigint[] IS NOT NULL AND $2::bigint IS NOT NULL AND $3::bigint IS NOT NULL
		AND $4::boolean IS NOT NULL AND $5::boolean IS NOT NULL`, ids, u.ID, u.Dept, u.IsAdmin(), u.CanEdit())
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := map[int64]BookmarkInfo{}
	for rows.Next() {
		var id int64
		var b BookmarkInfo
		if err := rows.Scan(&id, &b.Title, &b.Subtitle, &b.Link, &b.At); err != nil {
			return nil, err
		}
		out[id] = b
	}
	return out, rows.Err()
}

func sqlResolver(q string) bookmarkFn {
	return func(ctx context.Context, s *Server, u *User, ids []int64) (map[int64]BookmarkInfo, error) {
		return s.bmQuery(ctx, u, q, ids)
	}
}

func init() {
	regBM("news", "Новости", "news", sqlResolver(`SELECT n.id, n.title, coalesce(u.full_name, ''), '/news/' || n.id, n.published_at
		FROM news n LEFT JOIN users u ON u.id = n.author_id
		WHERE n.id = ANY($1) AND (`+visibleNow+` OR $4 OR n.author_id = $2)`))
	regBM("idea", "Идеи", "idea", sqlResolver(`SELECT i.id, i.title, coalesce(u.full_name, ''), '/ideas/' || i.id, i.created_at
		FROM ideas i LEFT JOIN users u ON u.id = i.author_id WHERE i.id = ANY($1)`))
	regBM("file", "Документы и файлы", "file", sqlResolver(`SELECT f.id, f.name, fo.name, '/' || fo.kind || '?folder=' || fo.id, f.created_at
		FROM files f JOIN folders fo ON fo.id = f.folder_id
		WHERE f.id = ANY($1) AND f.context = 'folder' AND `+aclVisible("folder", "fo", 2, 3, 4)))
	regBM("post", "Публикации групп", "post", sqlResolver(`SELECT p.id, left(p.body, 120), g.name, '/groups/' || g.id || '?post=' || p.id, p.created_at
		FROM group_posts p JOIN user_groups g ON g.id = p.group_id
		WHERE p.id = ANY($1) AND (g.visibility = 'public' OR $4 OR EXISTS (SELECT 1 FROM group_members m
			WHERE m.group_id = g.id AND m.user_id = $2 AND m.role <> 'pending'))`))
	regBM("event", "События календаря", "event", sqlResolver(`SELECT e.id, e.title, c.name,
			'/calendar?event=' || e.id || '&date=' || to_char(e.starts_at AT TIME ZONE 'UTC', 'YYYY-MM-DD'), e.starts_at
		FROM events e JOIN calendars c ON c.id = e.calendar_id
		WHERE e.id = ANY($1) AND (CASE WHEN c.kind = 'personal' AND c.owner_id <> $2 THEN 0 ELSE `+levelExpr("calendar", "c", 2, 3, 4, calBase("c", 5))+` END) >= 1`))
	regBM("message", "Сообщения чатов", "message", sqlResolver(`SELECT m.id, CASE WHEN m.body = '' THEN 'Вложение' ELSE left(m.body, 160) END,
			coalesce(u.full_name, ''), '/messages?chat=' || m.chat_id || '&msg=' || m.id, m.created_at
		FROM messages m JOIN chat_members cm ON cm.chat_id = m.chat_id AND cm.user_id = $2
		LEFT JOIN users u ON u.id = m.user_id WHERE m.id = ANY($1) AND m.deleted_at IS NULL`))
	regBM("learn_item", "Материалы обучения", "learn", sqlResolver(`SELECT i.id, i.title, f.name, '/learning/materials/item/' || i.id, i.created_at
		FROM learn_items i JOIN learn_folders f ON f.id = i.folder_id
		WHERE i.id = ANY($1) AND learn_level(i.folder_id, $2, $3, $4) > 0`))
	// Wiki-страницы появятся в другом блоке: пока таблицы нет — заглушка (тип пропускается). Блок wiki может заменить резолвер.
	regBM("wiki_page", "Wiki", "wiki", func(ctx context.Context, s *Server, u *User, ids []int64) (map[int64]BookmarkInfo, error) {
		var reg *string
		if err := s.db.QueryRow(ctx, `SELECT to_regclass('public.wiki_pages')::text`).Scan(&reg); err != nil || reg == nil {
			return map[int64]BookmarkInfo{}, nil
		}
		return s.bmQuery(ctx, u, `SELECT p.id, p.title, '', '/wiki/' || p.id, now() FROM wiki_pages p WHERE p.id = ANY($1)`, ids)
	})
}

// bookmarkAllowed — тип зарегистрирован и объект виден пользователю.
func (s *Server) bookmarkAllowed(ctx context.Context, u *User, typ string, id int64) (bool, error) {
	r, ok := bookmarkResolvers[typ]
	if !ok || id <= 0 {
		return false, nil
	}
	m, err := r.Fn(ctx, s, u, []int64{id})
	if err != nil {
		return false, err
	}
	_, ok = m[id]
	return ok, nil
}

// POST /api/bookmarks {entity_type, entity_id, note?, on?} — переключить закладку.
func (s *Server) bookmarkToggle(c *Ctx) error {
	var in struct {
		Type string `json:"entity_type"`
		ID   int64  `json:"entity_id"`
		Note string `json:"note"`
		On   *bool  `json:"on"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	ctx := c.Context()
	if _, ok := bookmarkResolvers[in.Type]; !ok {
		return badReq("Неизвестный тип объекта")
	}
	in.Note = strings.TrimSpace(in.Note)
	if len([]rune(in.Note)) > 500 {
		return badReq("Заметка — не более 500 символов")
	}
	var had bool
	if err := s.db.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM bookmarks WHERE user_id = $1 AND entity_type = $2 AND entity_id = $3)`, c.U.ID, in.Type, in.ID).Scan(&had); err != nil {
		return err
	}
	on := !had
	if in.On != nil {
		on = *in.On
	}
	if on && !had {
		if ok, err := s.bookmarkAllowed(ctx, c.U, in.Type, in.ID); err != nil {
			return err
		} else if !ok {
			return errNotFound
		}
		var n int
		if err := s.db.QueryRow(ctx, `SELECT count(*) FROM bookmarks WHERE user_id = $1`, c.U.ID).Scan(&n); err != nil {
			return err
		}
		if n >= 2000 {
			return badReq("Слишком много закладок (не более 2000)")
		}
		if _, err := s.db.Exec(ctx, `INSERT INTO bookmarks (user_id, entity_type, entity_id, note) VALUES ($1, $2, $3, $4) ON CONFLICT DO NOTHING`, c.U.ID, in.Type, in.ID, in.Note); err != nil {
			return err
		}
	} else if !on && had {
		if _, err := s.db.Exec(ctx, `DELETE FROM bookmarks WHERE user_id = $1 AND entity_type = $2 AND entity_id = $3`, c.U.ID, in.Type, in.ID); err != nil {
			return err
		}
	}
	return c.JSON(200, map[string]any{"bookmarked": on})
}

// PUT /api/bookmarks {entity_type, entity_id, note} — заметка к существующей закладке.
func (s *Server) bookmarkNote(c *Ctx) error {
	var in struct {
		Type string `json:"entity_type"`
		ID   int64  `json:"entity_id"`
		Note string `json:"note"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Note = strings.TrimSpace(in.Note)
	if len([]rune(in.Note)) > 500 {
		return badReq("Заметка — не более 500 символов")
	}
	tag, err := s.db.Exec(c.Context(), `UPDATE bookmarks SET note = $4 WHERE user_id = $1 AND entity_type = $2 AND entity_id = $3`, c.U.ID, in.Type, in.ID, in.Note)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return errNotFound
	}
	return c.OK()
}

// GET /api/bookmarks/state?type=news&ids=1,2,3 — какие из объектов в закладках (для страниц, где состояние не пришло вместе со списком).
func (s *Server) bookmarkState(c *Ctx) error {
	ids := parseIDs(c.Q("ids"))
	if len(ids) > 200 {
		ids = ids[:200]
	}
	set, err := s.bookmarkedSet(c.Context(), c.U.ID, c.Q("type"), ids)
	if err != nil {
		return err
	}
	out := []int64{}
	for id := range set {
		out = append(out, id)
	}
	return c.JSON(200, map[string]any{"ids": out})
}

type bmItem struct {
	Type      string    `json:"entity_type"`
	ID        int64     `json:"entity_id"`
	Title     string    `json:"title"`
	Subtitle  string    `json:"subtitle"`
	Link      string    `json:"link"`
	At        time.Time `json:"at"`
	CreatedAt time.Time `json:"created_at"`
	Note      string    `json:"note"`
	Label     string    `json:"label"`
	Icon      string    `json:"icon"`
}

// GET /api/bookmarks?type=&q=&page=&per= — список пользователя: заголовки и ссылки даёт резолвер типа, недоступное скрыто.
func (s *Server) bookmarkList(c *Ctx) error {
	ctx := c.Context()
	rows, err := s.db.Query(ctx, `SELECT entity_type, entity_id, created_at, note FROM bookmarks WHERE user_id = $1 ORDER BY created_at DESC, entity_id DESC LIMIT 2000`, c.U.ID)
	if err != nil {
		return err
	}
	type raw struct {
		typ  string
		id   int64
		at   time.Time
		note string
	}
	var all []raw
	byType := map[string][]int64{}
	for rows.Next() {
		var r raw
		if err := rows.Scan(&r.typ, &r.id, &r.at, &r.note); err != nil {
			rows.Close()
			return err
		}
		all = append(all, r)
		byType[r.typ] = append(byType[r.typ], r.id)
	}
	rows.Close()
	if err := rows.Err(); err != nil {
		return err
	}
	info := map[string]map[int64]BookmarkInfo{}
	for typ, ids := range byType {
		r, ok := bookmarkResolvers[typ]
		if !ok {
			continue
		}
		m, err := r.Fn(ctx, s, c.U, ids)
		if err != nil {
			s.log.Warn("bookmark resolver failed", "type", typ, "err", err)
			continue
		}
		info[typ] = m
	}
	q := strings.ToLower(c.Q("q"))
	want := c.Q("type")
	counts := map[string]int{}
	var items []bmItem
	for _, r := range all {
		b, ok := info[r.typ][r.id]
		if !ok {
			continue
		}
		if q != "" && !strings.Contains(strings.ToLower(b.Title), q) && !strings.Contains(strings.ToLower(r.note), q) && !strings.Contains(strings.ToLower(b.Subtitle), q) {
			continue
		}
		counts[r.typ]++
		if want != "" && want != r.typ {
			continue
		}
		res := bookmarkResolvers[r.typ]
		items = append(items, bmItem{Type: r.typ, ID: r.id, Title: socialOneLine(b.Title), Subtitle: b.Subtitle, Link: b.Link, At: b.At, CreatedAt: r.at, Note: r.note, Label: res.Label, Icon: res.Icon})
	}
	types := []map[string]any{}
	for _, t := range bookmarkOrder {
		if counts[t] > 0 {
			types = append(types, map[string]any{"type": t, "label": bookmarkResolvers[t].Label, "icon": bookmarkResolvers[t].Icon, "count": counts[t]})
		}
	}
	page, per, off := c.Page(30, 100)
	total := len(items)
	if off > total {
		off = total
	}
	end := min(off+per, total)
	out := items[off:end]
	if out == nil {
		out = []bmItem{}
	}
	return c.JSON(200, map[string]any{"items": out, "total": total, "page": page, "per": per, "pages": (total + per - 1) / per, "types": types})
}

// socialOneLine сжимает пробелы/переводы строк в заголовке из текста сообщения или поста.
func socialOneLine(s string) string {
	return strings.TrimSpace(strings.Map(func(r rune) rune {
		if unicode.IsSpace(r) {
			return ' '
		}
		return r
	}, s))
}

func regBM(typ, label, icon string, fn bookmarkFn) {
	registerBookmarkResolver(typ, fn, BookmarkMeta{Label: label, Icon: icon})
}
