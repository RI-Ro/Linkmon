package server

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestMonitorPanicAndRequestID(t *testing.T) {
	var buf bytes.Buffer
	cfg := Config{InstanceID: "t1", DCID: "main", SlowRequestMS: 1000}
	s := &Server{cfg: cfg, log: NewLogger(&buf, cfg)}
	mux := http.NewServeMux()
	mux.HandleFunc("GET /boom/{id}", func(w http.ResponseWriter, r *http.Request) { panic("kaboom") })
	h := s.monitor(mux)

	req := httptest.NewRequest("GET", "/boom/42?secret=1", nil)
	req.Header.Set("X-Request-ID", "req-12345678")
	req.Header.Set("X-Forwarded-For", "10.0.0.7, 10.0.0.1")
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)

	if rec.Code != 500 || rec.Header().Get("X-Request-ID") != "req-12345678" {
		t.Fatalf("code=%d rid=%q", rec.Code, rec.Header().Get("X-Request-ID"))
	}
	var l map[string]any
	if err := json.Unmarshal(buf.Bytes(), &l); err != nil {
		t.Fatalf("log is not JSON: %v: %s", err, buf.String())
	}
	if l["route"] != "/boom/{id}" || l["path"] != "/boom/42" || l["ip"] != "10.0.0.7" || l["level"] != "error" || l["panic"] != "kaboom" || l["stack"] == "" || l["ts"] == nil {
		t.Fatalf("unexpected log: %v", l)
	}
}

func TestMonWriterKeepsInterfaces(t *testing.T) {
	var w http.ResponseWriter = &monWriter{ResponseWriter: httptest.NewRecorder()}
	if _, ok := w.(http.Flusher); !ok {
		t.Fatal("no Flusher")
	}
	if _, ok := w.(http.Hijacker); !ok {
		t.Fatal("no Hijacker")
	}
}

func TestValidRequestID(t *testing.T) {
	for id, want := range map[string]bool{"abcdef0123456789": true, "short": false, "bad id with spaces": false, "ok-id_1.2:3": true, "a\nb-injection-xx": false} {
		if validRequestID(id) != want {
			t.Errorf("%q", id)
		}
	}
}
