package server

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

func (s *Server) chatMembers(ctx context.Context, chatID int64) ([]int64, error) {
	rows, err := s.db.Query(ctx, `SELECT user_id FROM chat_members WHERE chat_id = $1`, chatID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var ids []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		ids = append(ids, id)
	}
	return ids, rows.Err()
}

func (s *Server) isMember(ctx context.Context, chatID, uid int64) (bool, error) {
	var ok bool
	err := s.db.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM chat_members WHERE chat_id = $1 AND user_id = $2)`, chatID, uid).Scan(&ok)
	return ok, err
}

const chatSelect = `SELECT c.id, c.kind, c.group_id,
	CASE WHEN c.kind = 'direct' THEN ou.full_name ELSE c.title END AS title,
	CASE WHEN c.kind = 'direct' THEN ou.avatar ELSE c.avatar END AS avatar,
	ou.id AS peer_id, ou.job_title AS peer_title, cm.hidden,
	(SELECT count(*) FROM chat_members x WHERE x.chat_id = c.id) AS members,
	c.last_message_at, lm.body AS last_body, lm.user_id AS last_user_id, lm.kind AS last_kind,
	(lm.file_id IS NOT NULL) AS last_has_file, coalesce(lm.deleted_at IS NOT NULL, false) AS last_deleted,
	(SELECT count(*) FROM (SELECT 1 FROM messages m WHERE m.chat_id = c.id AND m.id > greatest(cm.last_read_id, cm.cleared_before_id)
		AND m.deleted_at IS NULL AND m.user_id IS DISTINCT FROM $1 LIMIT 99) q) AS unread
	FROM chat_members cm JOIN chats c ON c.id = cm.chat_id
	LEFT JOIN messages lm ON lm.id = c.last_message_id AND lm.id > cm.cleared_before_id
	LEFT JOIN LATERAL (SELECT u.id, u.full_name, u.avatar, u.job_title FROM chat_members o JOIN users u ON u.id = o.user_id
		WHERE c.kind = 'direct' AND o.chat_id = c.id AND o.user_id <> $1 LIMIT 1) ou ON true
	WHERE cm.user_id = $1 AND (($2::bigint = 0 AND NOT cm.hidden) OR c.id = $2)`

func (s *Server) listChats(c *Ctx) error {
	b, err := s.arr(c.Context(), chatSelect+` ORDER BY c.last_message_at DESC LIMIT 300`, c.U.ID, int64(0))
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) getChat(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	chat, err := s.one(ctx, chatSelect, c.U.ID, id)
	if err != nil {
		return err
	}
	members, err := s.arr(ctx, `SELECT u.id, u.full_name AS name, u.job_title, u.avatar, cm.last_read_id
		FROM chat_members cm JOIN users u ON u.id = cm.user_id WHERE cm.chat_id = $1 ORDER BY `+userOrder, id)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]json.RawMessage{"chat": chat, "members": members})
}

func (s *Server) createChat(c *Ctx) error {
	var in struct {
		UserID  int64   `json:"user_id"`
		UserIDs []int64 `json:"user_ids"`
		Title   string  `json:"title"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	ctx := c.Context()
	var chatID int64
	var members []int64
	if in.UserID != 0 { // direct chat: get-or-create
		if in.UserID == c.U.ID {
			return badReq("Нельзя создать чат с самим собой")
		}
		var ok bool
		if err := s.db.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM users WHERE id = $1 AND NOT blocked)`, in.UserID).Scan(&ok); err != nil || !ok {
			return badReq("Сотрудник не найден")
		}
		lo, hi := c.U.ID, in.UserID
		if lo > hi {
			lo, hi = hi, lo
		}
		key := fmt.Sprintf("%d:%d", lo, hi)
		err := s.tx(ctx, func(tx pgx.Tx) error {
			err := tx.QueryRow(ctx, `INSERT INTO chats (kind, direct_key, created_by) VALUES ('direct', $1, $2)
				ON CONFLICT (direct_key) DO NOTHING RETURNING id`, key, c.U.ID).Scan(&chatID)
			if err == pgx.ErrNoRows {
				return tx.QueryRow(ctx, `SELECT id FROM chats WHERE direct_key = $1`, key).Scan(&chatID)
			}
			if err != nil {
				return err
			}
			_, err = tx.Exec(ctx, `INSERT INTO chat_members (chat_id, user_id) VALUES ($1, $2), ($1, $3)`, chatID, c.U.ID, in.UserID)
			return err
		})
		if err != nil {
			return err
		}
		s.db.Exec(ctx, `UPDATE chat_members SET hidden = false WHERE chat_id = $1 AND user_id = $2 AND hidden`, chatID, c.U.ID)
		members = []int64{in.UserID}
	} else { // group chat
		in.Title = strings.TrimSpace(in.Title)
		if in.Title == "" || len(in.UserIDs) == 0 {
			return badReq("Укажите название и участников")
		}
		if len(in.UserIDs) > 200 {
			return badReq("Слишком много участников")
		}
		err := s.tx(ctx, func(tx pgx.Tx) error {
			if err := tx.QueryRow(ctx, `INSERT INTO chats (kind, title, created_by) VALUES ('group', $1, $2) RETURNING id`, in.Title, c.U.ID).Scan(&chatID); err != nil {
				return err
			}
			_, err := tx.Exec(ctx, `INSERT INTO chat_members (chat_id, user_id)
				SELECT $1, u.id FROM users u WHERE (u.id = ANY($2) OR u.id = $3) AND NOT u.blocked ON CONFLICT DO NOTHING`, chatID, in.UserIDs, c.U.ID)
			return err
		})
		if err != nil {
			return err
		}
		members = in.UserIDs
	}
	s.hub.EmitUsers(ctx, members, "chat", map[string]int64{"chat_id": chatID})
	b, err := s.one(ctx, chatSelect, c.U.ID, chatID)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) addChatMembers(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		UserIDs []int64 `json:"user_ids"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	ctx := c.Context()
	var kind string
	var gid *int64
	if err := s.db.QueryRow(ctx, `SELECT kind, group_id FROM chats WHERE id = $1`, id).Scan(&kind, &gid); err != nil {
		return err
	}
	if ok, _ := s.isMember(ctx, id, c.U.ID); !ok {
		return errForbidden
	}
	if kind != "group" || gid != nil {
		return badReq("Участников можно добавлять только в обычные групповые чаты")
	}
	if _, err := s.db.Exec(ctx, `INSERT INTO chat_members (chat_id, user_id) SELECT $1, u.id FROM users u WHERE u.id = ANY($2) AND NOT u.blocked ON CONFLICT DO NOTHING`, id, in.UserIDs); err != nil {
		return err
	}
	all, _ := s.chatMembers(ctx, id)
	s.hub.EmitUsers(ctx, all, "chat", map[string]int64{"chat_id": id})
	return c.OK()
}

func (s *Server) leaveChat(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var kind string
	var gid *int64
	if err := s.db.QueryRow(c.Context(), `SELECT kind, group_id FROM chats WHERE id = $1`, id).Scan(&kind, &gid); err != nil {
		return err
	}
	if kind != "group" || gid != nil {
		return badReq("Из этого чата выйти нельзя")
	}
	if _, err := s.db.Exec(c.Context(), `DELETE FROM chat_members WHERE chat_id = $1 AND user_id = $2`, id, c.U.ID); err != nil {
		return err
	}
	return c.OK()
}

const messageSelect = `SELECT m.id, m.chat_id, m.user_id, u.full_name AS author, u.avatar AS author_avatar, m.kind,
	CASE WHEN m.deleted_at IS NULL THEN m.body ELSE '' END AS body, m.reply_to, left(rm.body, 120) AS reply_body,
	ru.first_name AS reply_author, m.client_id, m.created_at, m.edited_at, m.deleted_at IS NOT NULL AS deleted,
	CASE WHEN f.id IS NULL OR m.deleted_at IS NOT NULL THEN NULL ELSE json_build_object('id', f.id, 'name', f.name, 'mime', f.mime,
		'size', f.size, 'width', f.width, 'height', f.height) END AS file,
	CASE WHEN m.kind = 'poll' AND m.deleted_at IS NULL THEN (` + pollJSON + `) END AS poll
	FROM messages m LEFT JOIN users u ON u.id = m.user_id LEFT JOIN files f ON f.id = m.file_id
	LEFT JOIN messages rm ON rm.id = m.reply_to LEFT JOIN users ru ON ru.id = rm.user_id`

func (s *Server) listMessages(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	if ok, err := s.isMember(ctx, id, c.U.ID); err != nil {
		return err
	} else if !ok {
		return errForbidden
	}
	limit := min(max(c.QInt("limit", 40), 1), 100)
	clr := func(n string) string { // скрытое «очисткой истории» не показываем
		return `m.id > (SELECT cleared_before_id FROM chat_members WHERE chat_id = $1 AND user_id = $` + n + `)`
	}
	var items json.RawMessage
	hasMore, hasNewer := false, false
	switch {
	case c.QInt64("around") > 0: // переход к сообщению (закладка, упоминание): окно вокруг него
		around := c.QInt64("around")
		items, err = s.arr(ctx, `SELECT * FROM (`+messageSelect+` WHERE m.chat_id = $1 AND `+clr("3")+`
			AND m.id >= coalesce((SELECT min(id) FROM (SELECT id FROM messages WHERE chat_id = $1 AND id <= $2 ORDER BY id DESC LIMIT 25) x), 0)
			AND m.id <= coalesce((SELECT max(id) FROM (SELECT id FROM messages WHERE chat_id = $1 AND id >= $2 ORDER BY id LIMIT 25) y), $2)
			ORDER BY m.id) t ORDER BY id`, id, around, c.U.ID)
		if err == nil {
			err = s.db.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM messages m WHERE m.chat_id = $1 AND `+clr("3")+` AND m.id < (SELECT min((x->>'id')::bigint) FROM json_array_elements($2::json) x)),
				EXISTS (SELECT 1 FROM messages m WHERE m.chat_id = $1 AND m.id > (SELECT max((x->>'id')::bigint) FROM json_array_elements($2::json) x))`,
				id, string(items), c.U.ID).Scan(&hasMore, &hasNewer)
		}
	case c.QInt64("after") > 0: // дочитать вперёд после перехода к старому сообщению
		items, err = s.arr(ctx, `SELECT * FROM (`+messageSelect+` WHERE m.chat_id = $1 AND m.id > $2 AND `+clr("4")+` ORDER BY m.id LIMIT $3) t ORDER BY id`,
			id, c.QInt64("after"), limit+1, c.U.ID)
		if err == nil {
			var list []json.RawMessage
			json.Unmarshal(items, &list)
			if hasNewer = len(list) > limit; hasNewer {
				list = list[:limit]
				items, _ = json.Marshal(list)
			}
		}
	default:
		items, err = s.arr(ctx, `SELECT * FROM (`+messageSelect+` WHERE m.chat_id = $1 AND ($2::bigint = 0 OR m.id < $2) AND `+clr("4")+` ORDER BY m.id DESC LIMIT $3) t ORDER BY id`,
			id, c.QInt64("before"), limit, c.U.ID)
		hasMore = countJSON(items) >= limit
	}
	if err != nil {
		return err
	}
	if items, err = s.withSocial(ctx, c.U.ID, "message", items, true); err != nil {
		return err
	}
	reads, err := s.arr(ctx, `SELECT user_id, last_read_id FROM chat_members WHERE chat_id = $1`, id)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"items": items, "reads": reads, "has_more": hasMore, "has_newer": hasNewer})
}

func countJSON(b json.RawMessage) int {
	var a []json.RawMessage
	json.Unmarshal(b, &a)
	return len(a)
}

func (s *Server) sendMessage(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Body     string `json:"body"`
		FileID   *int64 `json:"file_id"`
		ReplyTo  *int64 `json:"reply_to"`
		ClientID string `json:"client_id"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Body = strings.TrimSpace(in.Body)
	if (in.Body == "" && in.FileID == nil) || len(in.Body) > 5000 {
		return badReq("Сообщение должно содержать от 1 до 5000 символов")
	}
	ctx := c.Context()
	if !s.rateOK(ctx, fmt.Sprintf("msg:%d", c.U.ID), 120, time.Minute) {
		return &apiError{429, "Слишком много сообщений. Подождите немного"}
	}
	if ok, err := s.isMember(ctx, id, c.U.ID); err != nil {
		return err
	} else if !ok {
		return errForbidden
	}
	var cid any
	if in.ClientID != "" && len(in.ClientID) <= 64 {
		cid = in.ClientID
	}
	var mid int64
	created := true
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if in.FileID != nil {
			var ok bool
			if err := tx.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM files WHERE id = $1 AND owner_id = $2 AND context = 'chat')`, *in.FileID, c.U.ID).Scan(&ok); err != nil {
				return err
			}
			if !ok {
				return badReq("Файл не найден")
			}
		}
		err := tx.QueryRow(ctx, `INSERT INTO messages (chat_id, user_id, body, file_id, reply_to, client_id)
			VALUES ($1, $2, $3, $4, $5, $6) ON CONFLICT DO NOTHING RETURNING id`, id, c.U.ID, in.Body, in.FileID, in.ReplyTo, cid).Scan(&mid)
		if err == pgx.ErrNoRows { // retry of an already stored message (idempotency by client_id)
			created = false
			return tx.QueryRow(ctx, `SELECT id FROM messages WHERE chat_id = $1 AND user_id = $2 AND client_id = $3`, id, c.U.ID, cid).Scan(&mid)
		}
		if err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE chats SET last_message_id = $2, last_message_at = now() WHERE id = $1`, id, mid); err != nil {
			return err
		}
		if _, err = tx.Exec(ctx, `UPDATE chat_members SET last_read_id = $3 WHERE chat_id = $1 AND user_id = $2`, id, c.U.ID, mid); err != nil {
			return err
		}
		_, err = tx.Exec(ctx, `UPDATE chat_members SET hidden = false WHERE chat_id = $1 AND hidden`, id) // «удалённый у меня» чат возвращается с новым сообщением
		return err
	})
	if err != nil {
		return err
	}
	msg, err := s.one(ctx, messageSelect+` WHERE m.id = $1`, mid)
	if err != nil {
		return err
	}
	if created {
		members, err := s.chatMembers(ctx, id)
		if err != nil {
			return err
		}
		s.hub.EmitUsers(ctx, members, "message", map[string]any{"chat_id": id, "message": rawJSON(msg)})
		s.messageMentions(ctx, c.U, mid, id, in.Body)
	}
	return c.Raw(201, msg)
}

func (s *Server) markRead(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		MessageID int64 `json:"message_id"`
	}
	c.Decode(&in)
	ctx := c.Context()
	var last int64
	err = s.db.QueryRow(ctx, `UPDATE chat_members cm SET last_read_id = greatest(cm.last_read_id, CASE WHEN $3 > 0 THEN $3 ELSE coalesce(
			(SELECT last_message_id FROM chats WHERE id = cm.chat_id), 0) END)
		WHERE cm.chat_id = $1 AND cm.user_id = $2 RETURNING cm.last_read_id`, id, c.U.ID, in.MessageID).Scan(&last)
	if err == pgx.ErrNoRows {
		return errForbidden
	}
	if err != nil {
		return err
	}
	members, _ := s.chatMembers(ctx, id)
	s.hub.EmitUsers(ctx, members, "read", map[string]int64{"chat_id": id, "user_id": c.U.ID, "last_read_id": last})
	return c.OK()
}

func (s *Server) editMessage(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Body string `json:"body"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Body = strings.TrimSpace(in.Body)
	if in.Body == "" || len(in.Body) > 5000 {
		return badReq("Сообщение должно содержать от 1 до 5000 символов")
	}
	return s.mutateMessage(c, id, `UPDATE messages SET body = $2, edited_at = now() WHERE id = $1 AND user_id = $3 AND deleted_at IS NULL AND kind = 'text' RETURNING chat_id`, in.Body)
}

func (s *Server) deleteMessage(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	return s.mutateMessage(c, id, `UPDATE messages SET deleted_at = now(), body = $2 WHERE id = $1 AND (user_id = $3 OR $4) AND deleted_at IS NULL RETURNING chat_id`, "", c.U.IsAdmin())
}

func (s *Server) mutateMessage(c *Ctx, id int64, q string, body string, extra ...any) error {
	ctx := c.Context()
	var chatID int64
	if err := s.db.QueryRow(ctx, q, append([]any{id, body, c.U.ID}, extra...)...).Scan(&chatID); err != nil {
		if err == pgx.ErrNoRows {
			return errForbidden
		}
		return err
	}
	msg, err := s.one(ctx, messageSelect+` WHERE m.id = $1`, id)
	if err != nil {
		return err
	}
	members, _ := s.chatMembers(ctx, chatID)
	s.hub.EmitUsers(ctx, members, "message.update", map[string]any{"chat_id": chatID, "message": rawJSON(msg)})
	s.messageMentions(ctx, c.U, id, chatID, body) // правка: уведомляем только новых; удаление (body = "") снимает упоминания
	return c.Raw(200, msg)
}

// clearChat — «очистить у меня»: старые сообщения скрываются только для этого пользователя.
func (s *Server) clearChat(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	tag, err := s.db.Exec(ctx, `UPDATE chat_members cm SET cleared_before_id = coalesce((SELECT max(id) FROM messages WHERE chat_id = cm.chat_id), 0),
		last_read_id = greatest(cm.last_read_id, coalesce((SELECT max(id) FROM messages WHERE chat_id = cm.chat_id), 0))
		WHERE cm.chat_id = $1 AND cm.user_id = $2`, id, c.U.ID)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return errForbidden
	}
	s.hub.Emit(ctx, userTopic(c.U.ID), "chat.clear", map[string]int64{"chat_id": id})
	return c.OK()
}

// hideChat — «удалить у меня»: чат пропадает из списка (и очищается) только у этого пользователя и
// возвращается, когда в нём появится новое сообщение.
func (s *Server) hideChat(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	tag, err := s.db.Exec(ctx, `UPDATE chat_members cm SET hidden = true,
		cleared_before_id = coalesce((SELECT max(id) FROM messages WHERE chat_id = cm.chat_id), 0),
		last_read_id = greatest(cm.last_read_id, coalesce((SELECT max(id) FROM messages WHERE chat_id = cm.chat_id), 0))
		WHERE cm.chat_id = $1 AND cm.user_id = $2`, id, c.U.ID)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return errForbidden
	}
	s.hub.Emit(ctx, userTopic(c.U.ID), "chat.hide", map[string]int64{"chat_id": id})
	return c.OK()
}

func rawJSON(b []byte) json.RawMessage { return json.RawMessage(b) }
