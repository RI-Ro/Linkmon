package server

import (
	"context"
	"encoding/json"
	"fmt"
	"slices"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

// Назначения: курс или тест — пользователям, подразделениям (с дочерними), группам, ролям, «всем».
// Назначение материализуется в learn_assignees (по строке на сотрудника и цикл); правила (follow) подхватывают новых сотрудников джобом.

type assignIn struct {
	TargetType string `json:"target_type"`
	TargetID   int64  `json:"target_id"`
	Targets    []struct {
		Type string `json:"type"`
		ID   int64  `json:"id"`
		Key  string `json:"key"`
	} `json:"targets"`
	DueMode           string     `json:"due_mode"`
	DueDate           *time.Time `json:"due_date"`
	DueDays           *int       `json:"due_days"`
	Priority          string     `json:"priority"`
	Mandatory         *bool      `json:"mandatory"`
	RemindDays        []int      `json:"remind_days"`
	RemindOverdueDays *int       `json:"remind_overdue_days"`
	RecurMonths       int        `json:"recur_months"`
	Follow            bool       `json:"follow"`
	NewWithinDays     *int       `json:"new_within_days"`
	Note              string     `json:"note"`
}

var assignRoles = []string{"user", "editor", "admin", "head", "learning_manager"}

func (s *Server) lmsAssignCreate(c *Ctx) error {
	sc, err := s.lmsManager(c)
	if err != nil {
		return err
	}
	var in assignIn
	if err := c.Decode(&in); err != nil {
		return err
	}
	ctx := c.Context()
	// цель
	var title, link string
	switch in.TargetType {
	case "course":
		co, _, err := s.lmsCourseAccess(c, in.TargetID, lvView)
		if err != nil {
			return err
		}
		if co.Status != "published" {
			return badReq("Назначать можно только опубликованный курс")
		}
		title, link = co.Title, "/learning/courses/"+strconv.FormatInt(co.ID, 10)
	case "test":
		t, _, err := s.learnTestAccess(c, in.TargetID, lvView)
		if err != nil {
			return err
		}
		title, link = t.Title, "/learning/tests/"+strconv.FormatInt(t.ID, 10)
	default:
		return badReq("Выберите курс или тест")
	}
	if len(in.Targets) == 0 || len(in.Targets) > 100 {
		return badReq("Выберите, кому назначить")
	}
	var userIDs, deptIDs []int64
	for i, t := range in.Targets {
		switch t.Type {
		case "user":
			userIDs = append(userIDs, t.ID)
		case "department":
			deptIDs = append(deptIDs, t.ID)
		case "group":
			if t.ID <= 0 {
				return badReq("Группа не выбрана")
			}
		case "role":
			if !slices.Contains(assignRoles, t.Key) {
				return badReq("Неизвестная роль")
			}
			in.Targets[i].ID = 0
		case "all":
			in.Targets[i].ID = 0
		default:
			return badReq("Неизвестный тип получателя")
		}
	}
	if !sc.All {
		for _, d := range deptIDs {
			if !sc.Has(d) {
				return &apiError{403, "Подразделение вне вашей области"}
			}
		}
		if len(userIDs) > 0 {
			var n int
			if err := s.db.QueryRow(ctx, `SELECT count(DISTINCT id) FROM users WHERE id = ANY($1::bigint[]) AND department_id = ANY($2::bigint[])`, userIDs, sc.IDs).Scan(&n); err != nil {
				return err
			}
			if n != len(slices.Compact(slices.Sorted(slices.Values(userIDs)))) {
				return &apiError{403, "Сотрудник вне вашей области"}
			}
		}
	}
	switch in.DueMode {
	case "date":
		if in.DueDate == nil || !in.DueDate.After(time.Now()) {
			return badReq("Срок должен быть в будущем")
		}
		in.DueDays = nil
	case "days":
		if in.DueDays == nil || *in.DueDays < 1 || *in.DueDays > 3650 {
			return badReq("Срок — от 1 до 3650 дней")
		}
		in.DueDate = nil
	default:
		in.DueMode, in.DueDate, in.DueDays = "none", nil, nil
	}
	if in.Priority != "high" {
		in.Priority = "normal"
	}
	mandatory := in.Mandatory == nil || *in.Mandatory
	if in.RemindDays == nil {
		in.RemindDays = []int{7, 3, 1, 0}
	}
	rd := []int{}
	for _, d := range in.RemindDays {
		if d < 0 || d > 365 {
			return badReq("Напоминание — за 0–365 дней до срока")
		}
		if !slices.Contains(rd, d) && len(rd) < 10 {
			rd = append(rd, d)
		}
	}
	overdue := 3
	if in.RemindOverdueDays != nil {
		overdue = *in.RemindOverdueDays
	}
	if overdue < 0 || overdue > 90 || in.RecurMonths < 0 || in.RecurMonths > 120 {
		return badReq("Некорректные параметры напоминаний или переназначения")
	}
	if in.NewWithinDays != nil && (!in.Follow || *in.NewWithinDays < 1 || *in.NewWithinDays > 3650) {
		in.NewWithinDays = nil
	}
	in.Note = trimTo(in.Note, 1000)
	var limit any
	if !sc.All {
		limit = sc.IDs
	}
	var id int64
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if err := tx.QueryRow(ctx, `INSERT INTO learn_assignments (target_type, target_id, created_by, priority, mandatory, due_mode, due_date, due_days, remind_days, remind_overdue_days,
				recur_months, follow, new_within_days, limit_depts, note)
			VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9::int[], $10, $11, $12, $13, $14::bigint[], $15) RETURNING id`,
			in.TargetType, in.TargetID, c.U.ID, in.Priority, mandatory, in.DueMode, in.DueDate, in.DueDays, rd, overdue, in.RecurMonths, in.Follow, in.NewWithinDays, limit, in.Note).Scan(&id); err != nil {
			return err
		}
		for _, t := range in.Targets {
			if _, err := tx.Exec(ctx, `INSERT INTO learn_assign_targets (assignment_id, subject_type, subject_id, subject_key) VALUES ($1, $2, $3, $4) ON CONFLICT DO NOTHING`, id, t.Type, t.ID, t.Key); err != nil {
				return err
			}
		}
		_, err := tx.Exec(ctx, `INSERT INTO learn_assign_log (assignment_id, actor_id, action, data) VALUES ($1, $2, 'create', $3::jsonb)`, id, c.U.ID, fmt.Sprintf(`{"target":%q}`, title))
		return err
	})
	if err != nil {
		return err
	}
	n, err := s.lmsMaterialize(ctx, id, title, link)
	if err != nil {
		return err
	}
	s.audit(c, "learning.assign", "learn_assignment", id, map[string]any{"target": in.TargetType, "target_id": in.TargetID, "assigned": n})
	return c.JSON(200, map[string]any{"id": id, "assigned": n})
}

// lmsMaterialize создаёт строки назначений для всех подходящих сотрудников (идемпотентно: повтор ничего не дублирует)
// и уведомляет новых. Возвращает число созданных строк.
func (s *Server) lmsMaterialize(ctx context.Context, id int64, title, link string) (int, error) {
	n, uids, title, link, err := s.lmsMaterializeQ(ctx, s.db, id, title, link)
	if err != nil {
		return 0, err
	}
	if n > 0 {
		if len(uids) <= 2000 {
			s.hub.EmitUsers(ctx, uids, "notif", map[string]string{"kind": "learning", "title": "Вам назначено обучение: " + title, "body": "", "link": link})
		} else {
			s.hub.Emit(ctx, "feed", "refresh", map[string]string{"what": "notifications"})
		}
	}
	return n, nil
}

type rowQuerier interface {
	Query(ctx context.Context, sql string, args ...any) (pgx.Rows, error)
	QueryRow(ctx context.Context, sql string, args ...any) pgx.Row
}

// lmsMaterializeQ — то же в произвольном соединении/транзакции (используется и сидом); без живых уведомлений.
func (s *Server) lmsMaterializeQ(ctx context.Context, q rowQuerier, id int64, title, link string) (int, []int64, string, string, error) {
	if title == "" {
		q.QueryRow(ctx, `SELECT coalesce(co.title, t.title, '') FROM learn_assignments g LEFT JOIN learn_courses co ON g.target_type = 'course' AND co.id = g.target_id
			LEFT JOIN learn_tests t ON g.target_type = 'test' AND t.id = g.target_id WHERE g.id = $1`, id).Scan(&title)
		var tt string
		var tid int64
		q.QueryRow(ctx, `SELECT target_type, target_id FROM learn_assignments WHERE id = $1`, id).Scan(&tt, &tid)
		if tt == "test" {
			link = "/learning/tests/" + strconv.FormatInt(tid, 10)
		} else {
			link = "/learning/courses/" + strconv.FormatInt(tid, 10)
		}
	}
	rows, err := q.Query(ctx, `WITH RECURSIVE ds AS (
			SELECT t.subject_id AS id FROM learn_assign_targets t WHERE t.assignment_id = $1 AND t.subject_type = 'department'
			UNION SELECT d.id FROM departments d JOIN ds ON d.parent_id = ds.id),
		a AS (SELECT * FROM learn_assignments WHERE id = $1 AND status = 'active'),
		ins AS (
			INSERT INTO learn_assignees (assignment_id, user_id, dept_id, target_type, target_id, cycle, assigned_at, due_at, status, done_at, score, high, mandatory)
			SELECT a.id, u.id, u.department_id, a.target_type, a.target_id, 1, now(),
				CASE a.due_mode WHEN 'date' THEN a.due_date WHEN 'days' THEN now() + make_interval(days => a.due_days) END,
				CASE WHEN dn.done_at IS NOT NULL THEN 2 ELSE 0 END, dn.done_at, dn.score, a.priority = 'high', a.mandatory
			FROM a JOIN users u ON NOT u.blocked
			LEFT JOIN LATERAL (
				SELECT done_at, score FROM (
					SELECT e.completed_at AS done_at, e.score FROM learn_enrollments e
						WHERE a.target_type = 'course' AND e.user_id = u.id AND e.course_id = a.target_id AND e.status = 2 AND (e.expires_at IS NULL OR e.expires_at > now())
					UNION ALL
					SELECT max(t.finished_at), max(t.percent) FROM learn_attempts t
						WHERE a.target_type = 'test' AND t.test_id = a.target_id AND t.user_id = u.id AND t.passed AND (a.recur_months = 0 OR t.finished_at > now() - make_interval(months => a.recur_months))
						HAVING max(t.finished_at) IS NOT NULL) z LIMIT 1) dn ON true
			WHERE (a.limit_depts IS NULL OR u.department_id = ANY(a.limit_depts))
			  AND (NOT a.follow OR a.new_within_days IS NULL OR u.department_since > now() - make_interval(days => a.new_within_days))
			  AND EXISTS (SELECT 1 FROM learn_assign_targets t WHERE t.assignment_id = a.id AND (
					t.subject_type = 'all'
					OR (t.subject_type = 'user' AND t.subject_id = u.id)
					OR (t.subject_type = 'department' AND u.department_id IN (SELECT id FROM ds))
					OR (t.subject_type = 'group' AND EXISTS (SELECT 1 FROM group_members g WHERE g.group_id = t.subject_id AND g.user_id = u.id AND g.role <> 'pending'))
					OR (t.subject_type = 'role' AND ((t.subject_key IN ('user', 'editor', 'admin') AND u.role = t.subject_key)
						OR (t.subject_key = 'head' AND u.is_head) OR (t.subject_key = 'learning_manager' AND u.learning_manager)))))
			ON CONFLICT (assignment_id, user_id, cycle) DO NOTHING
			RETURNING user_id, due_at, status),
		nt AS (
			INSERT INTO notifications (user_id, kind, title, body, link)
			SELECT user_id, 'learning', 'Вам назначено обучение: ' || $2::text,
				CASE WHEN due_at IS NULL THEN 'Без срока' ELSE 'Срок: ' || to_char(due_at AT TIME ZONE $4::text, 'DD.MM.YYYY') END, $3::text
			FROM ins WHERE status = 0 RETURNING user_id)
		SELECT (SELECT count(*) FROM ins), coalesce((SELECT array_agg(user_id) FROM (SELECT user_id FROM nt LIMIT 2001) x), '{}')`, id, title, link, s.loc().String())
	if err != nil {
		return 0, nil, title, link, err
	}
	var n int
	var uids []int64
	for rows.Next() {
		if err := rows.Scan(&n, &uids); err != nil {
			rows.Close()
			return 0, nil, title, link, err
		}
	}
	rows.Close()
	return n, uids, title, link, rows.Err()
}

// ---------------------------------------------------------------- список и карточка

func (s *Server) lmsAssignList(c *Ctx) error {
	sc, err := s.lmsManager(c)
	if err != nil {
		return err
	}
	ctx := c.Context()
	page, per, off := c.Page(30, 100)
	b := &qb{}
	scopeCond := sc.cond(b, "a.dept_id")
	w := []string{"true"}
	if !sc.All {
		w = []string{"(agg.total > 0 OR g.created_by = " + b.add(c.U.ID) + "::bigint)"}
	}
	switch c.Q("status") {
	case "active", "cancelled":
		w = append(w, "g.status = "+b.add(c.Q("status")))
	}
	if t := c.Q("type"); t == "course" || t == "test" {
		w = append(w, "g.target_type = "+b.add(t))
	}
	if v := c.QInt64("target"); v > 0 {
		w = append(w, "g.target_id = "+b.add(v)+"::bigint")
	}
	from := ` FROM learn_assignments g
		LEFT JOIN learn_courses co ON g.target_type = 'course' AND co.id = g.target_id LEFT JOIN learn_tests t ON g.target_type = 'test' AND t.id = g.target_id
		LEFT JOIN LATERAL (SELECT count(*) AS total, count(*) FILTER (WHERE a.status = 2) AS done, count(*) FILTER (WHERE a.status = 1) AS progress,
				count(*) FILTER (WHERE a.status < 2 AND a.due_at < now()) AS overdue
			FROM learn_assignees a WHERE a.assignment_id = g.id AND a.status < 3 AND ` + scopeCond + `) agg ON true`
	where := strings.Join(w, " AND ")
	var total int
	if err := s.db.QueryRow(ctx, `SELECT count(*)`+from+` WHERE `+where, b.args...).Scan(&total); err != nil {
		return err
	}
	lim, offs := b.add(per), b.add(off)
	items, err := s.arr(ctx, `SELECT g.id, g.target_type, g.target_id, coalesce(co.title, t.title, 'Удалено') AS title, g.created_at, g.priority, g.mandatory, g.due_mode, g.due_date, g.due_days,
			g.remind_days, g.remind_overdue_days, g.recur_months, g.follow, g.new_within_days, g.status, g.note, (SELECT full_name FROM users WHERE id = g.created_by) AS author,
			agg.total, agg.done, agg.progress, agg.overdue, `+targetsJSON+` AS targets`+from+` WHERE `+where+` ORDER BY g.id DESC LIMIT `+lim+` OFFSET `+offs, b.args...)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"items": json.RawMessage(items), "total": total, "page": page, "per": per})
}

const targetsJSON = `(SELECT coalesce(json_agg(json_build_object('type', x.subject_type, 'id', x.subject_id, 'key', x.subject_key, 'name',
		CASE x.subject_type WHEN 'user' THEN (SELECT full_name FROM users WHERE id = x.subject_id) WHEN 'department' THEN (SELECT name FROM departments WHERE id = x.subject_id)
			WHEN 'group' THEN (SELECT name FROM user_groups WHERE id = x.subject_id) END) ORDER BY x.id), '[]') FROM learn_assign_targets x WHERE x.assignment_id = g.id)`

func (s *Server) lmsAssignGet(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	sc, err := s.lmsManager(c)
	if err != nil {
		return err
	}
	ctx := c.Context()
	b := &qb{}
	head, err := s.one(ctx, `SELECT g.id, g.target_type, g.target_id, coalesce(co.title, t.title, 'Удалено') AS title, g.created_at, g.priority, g.mandatory, g.due_mode, g.due_date, g.due_days,
			g.remind_days, g.remind_overdue_days, g.recur_months, g.follow, g.new_within_days, g.status, g.note, g.created_by, (SELECT full_name FROM users WHERE id = g.created_by) AS author,
			`+targetsJSON+` AS targets FROM learn_assignments g
		LEFT JOIN learn_courses co ON g.target_type = 'course' AND co.id = g.target_id LEFT JOIN learn_tests t ON g.target_type = 'test' AND t.id = g.target_id WHERE g.id = $1`, id)
	if err != nil {
		return err
	}
	var h struct {
		CreatedBy *int64 `json:"created_by"`
	}
	json.Unmarshal(head, &h)
	page, per, off := c.Page(50, 200)
	b.add(id)
	w := []string{"a.assignment_id = $1", sc.cond(b, "a.dept_id")}
	if q := strings.ToLower(c.Q("q")); q != "" {
		w = append(w, "u.search_text LIKE "+b.add("%"+likeEscape(q)+"%")+" ESCAPE '\\'")
	}
	switch c.Q("filter") {
	case "overdue":
		w = append(w, "a.status < 2 AND a.due_at < now()")
	case "done":
		w = append(w, "a.status = 2")
	case "open":
		w = append(w, "a.status < 2")
	case "revoked":
		w = append(w, "a.status = 3")
	}
	where := strings.Join(w, " AND ")
	var total int
	if err := s.db.QueryRow(ctx, `SELECT count(*) FROM learn_assignees a JOIN users u ON u.id = a.user_id WHERE `+where, b.args...).Scan(&total); err != nil {
		return err
	}
	if total == 0 && !sc.All && (h.CreatedBy == nil || *h.CreatedBy != c.U.ID) {
		ab := &qb{}
		ab.add(id)
		var any bool
		s.db.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM learn_assignees a WHERE a.assignment_id = $1 AND `+sc.cond(ab, "a.dept_id")+`)`, ab.args...).Scan(&any)
		if !any {
			return errForbidden
		}
	}
	lim, offs := b.add(per), b.add(off)
	items, err := s.arr(ctx, `SELECT a.id, a.user_id, u.full_name AS name, u.job_title, d.name AS department, a.status, a.assigned_at, a.due_at, a.done_at, a.score::float8 AS score, a.cycle,
			(a.status < 2 AND a.due_at < now()) AS overdue, a.manual_remind_at
		FROM learn_assignees a JOIN users u ON u.id = a.user_id LEFT JOIN departments d ON d.id = u.department_id WHERE `+where+`
		ORDER BY (a.status < 2 AND a.due_at < now()) DESC, a.due_at NULLS LAST, u.full_name LIMIT `+lim+` OFFSET `+offs, b.args...)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"assignment": json.RawMessage(head), "items": json.RawMessage(items), "total": total, "page": page, "per": per})
}

func (s *Server) lmsAssignCancel(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, err := s.lmsManager(c); err != nil {
		return err
	}
	ctx := c.Context()
	var by *int64
	if err := s.db.QueryRow(ctx, `SELECT created_by FROM learn_assignments WHERE id = $1`, id).Scan(&by); err != nil {
		return err
	}
	if !c.U.IsAdmin() && (by == nil || *by != c.U.ID) {
		return &apiError{403, "Отменить назначение может его автор или администратор"}
	}
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `UPDATE learn_assignments SET status = 'cancelled' WHERE id = $1`, id); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE learn_assignees SET status = 3 WHERE assignment_id = $1 AND status < 2`, id); err != nil {
			return err
		}
		_, err := tx.Exec(ctx, `INSERT INTO learn_assign_log (assignment_id, actor_id, action) VALUES ($1, $2, 'cancel')`, id, c.U.ID)
		return err
	})
	if err != nil {
		return err
	}
	return c.OK()
}

// lmsAssignTargets — поиск групп для выбора получателей.
func (s *Server) lmsAssignTargets(c *Ctx) error {
	if _, err := s.lmsManager(c); err != nil {
		return err
	}
	q := strings.ToLower(c.Q("q"))
	b, err := s.arr(c.Context(), `SELECT g.id, g.name, (SELECT count(*) FROM group_members m WHERE m.group_id = g.id AND m.role <> 'pending') AS members FROM user_groups g
		WHERE lower(g.name) LIKE $1 ESCAPE '\' ORDER BY lower(g.name) LIMIT 30`, "%"+likeEscape(q)+"%")
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// ---------------------------------------------------------------- действия над назначением сотрудника

type assigneeRow struct {
	ID, UserID, AssignmentID int64
	Status                   int
	DueAt                    *time.Time
	Title                    string
	Link                     string
}

// lmsAssigneeAccess: строка назначения и проверка, что сотрудник входит в область ответственного.
func (s *Server) lmsAssigneeAccess(c *Ctx, id int64) (*assigneeRow, error) {
	sc, err := s.lmsManager(c)
	if err != nil {
		return nil, err
	}
	var r assigneeRow
	var tt string
	var tid int64
	var dept *int64
	if err := ctxQuery(s, c, `SELECT a.id, a.user_id, a.assignment_id, a.status, a.due_at, a.target_type, a.target_id, u.department_id, coalesce(co.title, t.title, '')
		FROM learn_assignees a JOIN users u ON u.id = a.user_id LEFT JOIN learn_courses co ON a.target_type = 'course' AND co.id = a.target_id
		LEFT JOIN learn_tests t ON a.target_type = 'test' AND t.id = a.target_id WHERE a.id = $1`, id).Scan(&r.ID, &r.UserID, &r.AssignmentID, &r.Status, &r.DueAt, &tt, &tid, &dept, &r.Title); err != nil {
		return nil, err
	}
	if !sc.All && !sc.HasPtr(dept) {
		return nil, errForbidden
	}
	if tt == "test" {
		r.Link = "/learning/tests/" + strconv.FormatInt(tid, 10)
	} else {
		r.Link = "/learning/courses/" + strconv.FormatInt(tid, 10)
	}
	return &r, nil
}

func ctxQuery(s *Server, c *Ctx, q string, args ...any) pgx.Row {
	return s.db.QueryRow(c.Context(), q, args...)
}

func (s *Server) lmsLog(ctx context.Context, assignee, assignment, actor int64, action string, data any) {
	b, _ := json.Marshal(data)
	if _, err := s.db.Exec(ctx, `INSERT INTO learn_assign_log (assignee_id, assignment_id, actor_id, action, data) VALUES ($1, $2, $3, $4, $5::jsonb)`, nilIf0(assignee), nilIf0(assignment), actor, action, string(b)); err != nil {
		s.log.Warn("assign log", "err", err)
	}
}

const remindCooldown = 12 * time.Hour

// lmsRemindOne отправляет ручное напоминание (не чаще раза в 12 часов на сотрудника и назначение).
func (s *Server) lmsRemindOne(ctx context.Context, actor *User, r *assigneeRow) (bool, error) {
	if r.Status >= 2 {
		return false, conflict("Обучение уже выполнено или отозвано")
	}
	tag, err := s.db.Exec(ctx, `UPDATE learn_assignees SET manual_remind_at = now() WHERE id = $1 AND status < 2 AND (manual_remind_at IS NULL OR manual_remind_at < now() - $2::interval)`,
		r.ID, strconv.Itoa(int(remindCooldown.Seconds()))+" seconds")
	if err != nil {
		return false, err
	}
	if tag.RowsAffected() == 0 {
		return false, nil
	}
	body := "Напоминает: " + actor.Name
	if r.DueAt != nil {
		body += ". Срок: " + r.DueAt.In(s.loc()).Format("02.01.2006")
	}
	s.notify(ctx, []int64{r.UserID}, "learning", "Напоминание: пройдите обучение «"+r.Title+"»", body, r.Link)
	s.lmsLog(ctx, r.ID, r.AssignmentID, actor.ID, "remind", nil)
	return true, nil
}

func (s *Server) lmsAssigneeRemind(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	r, err := s.lmsAssigneeAccess(c, id)
	if err != nil {
		return err
	}
	ok, err := s.lmsRemindOne(c.Context(), c.U, r)
	if err != nil {
		return err
	}
	if !ok {
		return conflict("Напоминание уже отправлялось недавно — повторить можно через 12 часов")
	}
	return c.OK()
}

// lmsRemindBulk — «напомнить» нескольким сотрудникам (список просрочек): каждый проверяется по области отдельно.
func (s *Server) lmsRemindBulk(c *Ctx) error {
	var in struct {
		IDs []int64 `json:"ids"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if len(in.IDs) == 0 || len(in.IDs) > 500 {
		return badReq("Выберите сотрудников (до 500)")
	}
	sent, skipped := 0, 0
	for _, id := range in.IDs {
		r, err := s.lmsAssigneeAccess(c, id)
		if err != nil {
			if ae, ok := err.(*apiError); ok && ae.Code == 403 {
				return err
			}
			skipped++
			continue
		}
		ok, err := s.lmsRemindOne(c.Context(), c.U, r)
		if err != nil || !ok {
			skipped++
			continue
		}
		sent++
	}
	return c.JSON(200, map[string]int{"sent": sent, "skipped": skipped})
}

func (s *Server) lmsAssigneeExtend(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		DueAt  time.Time `json:"due_at"`
		Reason string    `json:"reason"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	r, err := s.lmsAssigneeAccess(c, id)
	if err != nil {
		return err
	}
	if in.DueAt.IsZero() || !in.DueAt.After(time.Now()) {
		return badReq("Новый срок должен быть в будущем")
	}
	if r.Status >= 2 {
		return conflict("Обучение уже выполнено или отозвано")
	}
	ctx := c.Context()
	in.Reason = trimTo(in.Reason, 500)
	if _, err := s.db.Exec(ctx, `UPDATE learn_assignees SET due_at = $2 WHERE id = $1`, id, in.DueAt); err != nil {
		return err
	}
	s.db.Exec(ctx, `DELETE FROM learn_reminders WHERE assignee_id = $1`, id) // напоминания по новому сроку отправятся заново
	s.lmsLog(ctx, id, r.AssignmentID, c.U.ID, "extend", map[string]any{"from": r.DueAt, "to": in.DueAt, "reason": in.Reason})
	s.notify(ctx, []int64{r.UserID}, "learning", "Срок обучения изменён: "+r.Title, "Новый срок: "+in.DueAt.In(s.loc()).Format("02.01.2006"), r.Link)
	return c.OK()
}

func (s *Server) lmsAssigneeRevoke(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Reason  string `json:"reason"`
		Restore bool   `json:"restore"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	r, err := s.lmsAssigneeAccess(c, id)
	if err != nil {
		return err
	}
	ctx := c.Context()
	in.Reason = trimTo(in.Reason, 500)
	if in.Restore {
		if r.Status != 3 {
			return conflict("Назначение не отозвано")
		}
		if _, err := s.db.Exec(ctx, `UPDATE learn_assignees SET status = CASE WHEN started_at IS NULL THEN 0 ELSE 1 END WHERE id = $1`, id); err != nil {
			return err
		}
		s.lmsLog(ctx, id, r.AssignmentID, c.U.ID, "restore", map[string]any{"reason": in.Reason})
		return c.OK()
	}
	if r.Status >= 2 {
		return conflict("Обучение уже выполнено или отозвано")
	}
	if _, err := s.db.Exec(ctx, `UPDATE learn_assignees SET status = 3 WHERE id = $1`, id); err != nil {
		return err
	}
	s.lmsLog(ctx, id, r.AssignmentID, c.U.ID, "revoke", map[string]any{"reason": in.Reason})
	return c.OK()
}

func (s *Server) lmsAssigneeLog(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, err := s.lmsAssigneeAccess(c, id); err != nil {
		return err
	}
	b, err := s.arr(c.Context(), `SELECT l.id, l.action, l.data, l.at, u.full_name AS actor FROM learn_assign_log l LEFT JOIN users u ON u.id = l.actor_id
		WHERE l.assignee_id = $1 OR (l.assignee_id IS NULL AND l.assignment_id = (SELECT assignment_id FROM learn_assignees WHERE id = $1)) ORDER BY l.at DESC LIMIT 100`, id)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}
