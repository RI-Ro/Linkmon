package server

import (
	"bytes"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"
	"unicode"

	"github.com/jackc/pgx/v5"
)

// Импорт и экспорт заданий. Форматы:
//   JSON — массив вопросов или объект {"title", ..., "questions": [...]}; см. learnTemplateJSON
//   CSV  — разделитель ; , или табуляция; колонки: вопрос; тип; правильные; вес; пояснение; вариант1..N
//   Текст — блоки через пустую строку: первая строка — вопрос, далее варианты, правильные начинаются с «*»

type importErr struct {
	Line  int    `json:"line,omitempty"`  // номер строки (CSV/текст)
	Index int    `json:"index,omitempty"` // номер вопроса (JSON)
	Msg   string `json:"message"`
}

type importResult struct {
	Format    string      `json:"format"`
	Questions []qIn       `json:"questions"`
	Errors    []importErr `json:"errors"`
	Test      *testMeta   `json:"test,omitempty"`
	Total     int         `json:"total"` // сколько заданий найдено в файле (включая ошибочные)
}

type testMeta struct {
	Title            string `json:"title,omitempty"`
	Description      string `json:"description,omitempty"`
	PassPercent      *int   `json:"pass_percent,omitempty"`
	TimeLimitMin     *int   `json:"time_limit_min,omitempty"`
	MaxAttempts      *int   `json:"max_attempts,omitempty"`
	ShuffleQuestions bool   `json:"shuffle_questions,omitempty"`
	ShuffleAnswers   bool   `json:"shuffle_answers,omitempty"`
	PartialCredit    bool   `json:"partial_credit,omitempty"`
	ShowAnswers      string `json:"show_answers,omitempty"`
}

func typeToken(s string) string {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "single", "one", "radio", "один", "одиночный", "один ответ", "одиночный выбор", "1":
		return "single"
	case "multiple", "multi", "checkbox", "несколько", "множественный", "несколько ответов", "множественный выбор":
		return "multiple"
	case "text", "number", "numeric", "текст", "число", "открытый", "текст/число", "ввод":
		return "text"
	}
	return ""
}

func parseNumList(s string, n int) ([]int, string) {
	var out []int
	for _, p := range strings.FieldsFunc(s, func(r rune) bool { return r == '|' || r == ',' || r == ';' || r == ' ' || r == '+' }) {
		v, err := strconv.Atoi(p)
		if err != nil {
			return nil, "неверный номер правильного варианта: «" + p + "»"
		}
		if v < 1 || v > n {
			return nil, fmt.Sprintf("номер правильного варианта %d вне диапазона 1–%d", v, n)
		}
		out = append(out, v)
	}
	return out, ""
}

// finish приводит разобранное задание к виду qIn: выводит тип и валидирует.
func finishQ(q *qIn, correct []int) string {
	if q.Type == "" {
		switch {
		case len(q.Options) == 0:
			q.Type = "text"
		case len(correct) > 1:
			q.Type = "multiple"
		default:
			q.Type = "single"
		}
	}
	if q.Type != "text" {
		for _, c := range correct {
			if c >= 1 && c <= len(q.Options) {
				q.Options[c-1].Correct = true
			}
		}
	}
	return q.normalize()
}

// ---------------------------------------------------------------- JSON

type jq struct {
	Type        string            `json:"type"`
	Text        string            `json:"text"`
	Question    string            `json:"question"`
	Options     []json.RawMessage `json:"options"`
	Correct     json.RawMessage   `json:"correct"`
	Answers     []string          `json:"answers"`
	Weight      float64           `json:"weight"`
	Explanation string            `json:"explanation"`
}

func parseJSONQuestion(j jq) (qIn, string) {
	q := qIn{Type: typeToken(j.Type), Text: j.Text, Weight: j.Weight, Explanation: j.Explanation, Answers: j.Answers}
	if q.Text == "" {
		q.Text = j.Question
	}
	if j.Type != "" && q.Type == "" {
		return q, "неизвестный тип «" + j.Type + "»"
	}
	for _, r := range j.Options {
		var s string
		if json.Unmarshal(r, &s) == nil {
			q.Options = append(q.Options, qOpt{Text: s})
			continue
		}
		var o struct {
			Text    string `json:"text"`
			Correct bool   `json:"correct"`
		}
		if json.Unmarshal(r, &o) != nil {
			return q, "некорректный вариант ответа"
		}
		q.Options = append(q.Options, qOpt{Text: o.Text, Correct: o.Correct})
	}
	var correct []int
	if len(j.Correct) > 0 && string(j.Correct) != "null" {
		var nums []int
		var one int
		var strs []string
		var str string
		switch {
		case json.Unmarshal(j.Correct, &nums) == nil:
			correct = nums
		case json.Unmarshal(j.Correct, &one) == nil:
			correct = []int{one}
		case json.Unmarshal(j.Correct, &strs) == nil:
			q.Answers = append(q.Answers, strs...)
		case json.Unmarshal(j.Correct, &str) == nil:
			q.Answers = append(q.Answers, str)
		default:
			return q, "некорректное поле correct"
		}
		for _, c := range correct {
			if c < 1 || c > len(q.Options) {
				return q, fmt.Sprintf("номер правильного варианта %d вне диапазона 1–%d", c, len(q.Options))
			}
		}
	}
	// флаги correct в объектах вариантов уже учтены; номера из correct добавляются сверху
	return q, finishQ(&q, correct)
}

func parseJSONImport(content string) importResult {
	res := importResult{Format: "json", Questions: []qIn{}, Errors: []importErr{}}
	var list []jq
	trim := strings.TrimSpace(content)
	if strings.HasPrefix(trim, "[") {
		if err := json.Unmarshal([]byte(trim), &list); err != nil {
			res.Errors = append(res.Errors, importErr{Msg: "Некорректный JSON: " + err.Error()})
			return res
		}
	} else {
		var obj struct {
			testMeta
			Questions []jq `json:"questions"`
		}
		if err := json.Unmarshal([]byte(trim), &obj); err != nil {
			res.Errors = append(res.Errors, importErr{Msg: "Некорректный JSON: " + err.Error()})
			return res
		}
		list = obj.Questions
		if obj.Title != "" || obj.PassPercent != nil || obj.TimeLimitMin != nil || obj.MaxAttempts != nil {
			m := obj.testMeta
			res.Test = &m
		}
	}
	res.Total = len(list)
	for i, j := range list {
		q, e := parseJSONQuestion(j)
		if e != "" {
			res.Errors = append(res.Errors, importErr{Index: i + 1, Msg: e})
			continue
		}
		res.Questions = append(res.Questions, q)
	}
	return res
}

// ---------------------------------------------------------------- CSV

var optColRe = regexp.MustCompile(`^(вариант|ответ|option|answer)\s*(\d+)$`)

func parseCSVImport(content string) importResult {
	res := importResult{Format: "csv", Questions: []qIn{}, Errors: []importErr{}}
	content = strings.TrimPrefix(content, "\uFEFF")
	first := content
	if i := strings.IndexByte(content, '\n'); i >= 0 {
		first = content[:i]
	}
	delim := ';'
	if strings.Count(first, "\t") > strings.Count(first, ";") {
		delim = '\t'
	} else if strings.Count(first, ",") > strings.Count(first, ";") {
		delim = ','
	}
	r := csv.NewReader(strings.NewReader(content))
	r.Comma = delim
	r.FieldsPerRecord = -1
	r.LazyQuotes = true
	r.TrimLeadingSpace = true
	// порядок колонок по умолчанию
	col := map[string]int{"q": 0, "type": 1, "correct": 2, "weight": 3, "expl": 4}
	var optCols []int
	hasHeader := false
	line := 0
	for {
		rec, err := r.Read()
		if err == io.EOF {
			break
		}
		line, _ = r.FieldPos(0)
		if err != nil {
			res.Total++
			res.Errors = append(res.Errors, importErr{Line: line, Msg: "ошибка разбора строки: " + err.Error()})
			continue
		}
		blank := true
		for _, f := range rec {
			if strings.TrimSpace(f) != "" {
				blank = false
			}
		}
		if blank {
			continue
		}
		if line == 1 || (!hasHeader && res.Total == 0 && len(optCols) == 0) {
			lower := make([]string, len(rec))
			isHeader := false
			for i, f := range rec {
				lower[i] = strings.ToLower(strings.TrimSpace(f))
				if lower[i] == "вопрос" || lower[i] == "question" {
					isHeader = true
				}
			}
			if isHeader {
				hasHeader = true
				col = map[string]int{}
				for i, h := range lower {
					switch {
					case h == "вопрос" || h == "question":
						col["q"] = i
					case h == "тип" || h == "type":
						col["type"] = i
					case h == "правильные" || h == "правильный" || h == "правильные ответы" || h == "correct" || h == "answers":
						col["correct"] = i
					case h == "вес" || h == "weight":
						col["weight"] = i
					case h == "пояснение" || h == "explanation":
						col["expl"] = i
					case optColRe.MatchString(h):
						optCols = append(optCols, i)
					}
				}
				continue
			}
		}
		if len(optCols) == 0 && !hasHeader {
			for i := 5; i < len(rec); i++ {
				optCols = append(optCols, i)
			}
		}
		res.Total++
		get := func(k string) string {
			if i, ok := col[k]; ok && i < len(rec) {
				return strings.TrimSpace(rec[i])
			}
			return ""
		}
		q := qIn{Text: get("q"), Explanation: get("expl")}
		if t := get("type"); t != "" {
			if q.Type = typeToken(t); q.Type == "" {
				res.Errors = append(res.Errors, importErr{Line: line, Msg: "неизвестный тип «" + t + "»"})
				continue
			}
		}
		if w := get("weight"); w != "" {
			v, err := strconv.ParseFloat(strings.Replace(w, ",", ".", 1), 64)
			if err != nil {
				res.Errors = append(res.Errors, importErr{Line: line, Msg: "вес должен быть числом"})
				continue
			}
			q.Weight = v
		}
		for _, i := range optCols {
			if i < len(rec) && strings.TrimSpace(rec[i]) != "" {
				q.Options = append(q.Options, qOpt{Text: strings.TrimSpace(rec[i])})
			}
		}
		corr := get("correct")
		var correct []int
		if q.Type == "text" || (q.Type == "" && len(q.Options) == 0) {
			q.Type = "text"
			for _, a := range strings.Split(corr, "|") {
				q.Answers = append(q.Answers, a)
			}
			if corr == "" {
				for _, o := range q.Options {
					q.Answers = append(q.Answers, o.Text)
				}
			}
		} else {
			var e string
			if correct, e = parseNumList(corr, len(q.Options)); e != "" {
				res.Errors = append(res.Errors, importErr{Line: line, Msg: e})
				continue
			}
		}
		if e := finishQ(&q, correct); e != "" {
			res.Errors = append(res.Errors, importErr{Line: line, Msg: e})
			continue
		}
		res.Questions = append(res.Questions, q)
	}
	return res
}

// ---------------------------------------------------------------- текст

var (
	numPrefixRe = regexp.MustCompile(`^\s*\d{1,3}[.)]\s+`)
	labelRe     = regexp.MustCompile(`^[A-Za-zА-Яа-я0-9][.)]\s+`)
)

func parseTextImport(content string) importResult {
	res := importResult{Format: "text", Questions: []qIn{}, Errors: []importErr{}}
	content = strings.TrimPrefix(strings.ReplaceAll(content, "\r\n", "\n"), "\uFEFF")
	lines := strings.Split(content, "\n")
	type block struct {
		start int
		lines []string
	}
	var blocks []block
	var cur *block
	for i, l := range lines {
		if strings.TrimSpace(l) == "" {
			cur = nil
			continue
		}
		if cur == nil {
			blocks = append(blocks, block{start: i + 1})
			cur = &blocks[len(blocks)-1]
		}
		cur.lines = append(cur.lines, l)
	}
	for _, b := range blocks {
		res.Total++
		q := qIn{Text: numPrefixRe.ReplaceAllString(strings.TrimSpace(b.lines[0]), "")}
		var correct []int
		bad := ""
		for _, raw := range b.lines[1:] {
			l := strings.TrimSpace(raw)
			switch {
			case strings.HasPrefix(l, "#"):
				k, v, _ := strings.Cut(strings.TrimSpace(strings.TrimLeft(l, "#")), ":")
				v = strings.TrimSpace(v)
				switch strings.ToLower(strings.TrimSpace(k)) {
				case "вес", "weight":
					w, err := strconv.ParseFloat(strings.Replace(v, ",", ".", 1), 64)
					if err != nil {
						bad = "вес должен быть числом"
					}
					q.Weight = w
				case "пояснение", "explanation":
					q.Explanation = v
				case "тип", "type":
					if q.Type = typeToken(v); q.Type == "" {
						bad = "неизвестный тип «" + v + "»"
					}
				}
			case strings.HasPrefix(l, "="):
				q.Answers = append(q.Answers, strings.TrimSpace(strings.TrimPrefix(l, "=")))
			default:
				l = strings.TrimSpace(strings.TrimPrefix(l, "-"))
				ok := false
				if strings.HasPrefix(l, "*") || strings.HasPrefix(l, "+") {
					ok = true
					l = strings.TrimSpace(l[1:])
				}
				l = labelRe.ReplaceAllString(l, "")
				q.Options = append(q.Options, qOpt{Text: l})
				if ok {
					correct = append(correct, len(q.Options))
				}
			}
		}
		if bad != "" {
			res.Errors = append(res.Errors, importErr{Line: b.start, Msg: bad})
			continue
		}
		if len(q.Answers) > 0 && q.Type == "" {
			q.Type = "text"
		}
		if e := finishQ(&q, correct); e != "" {
			res.Errors = append(res.Errors, importErr{Line: b.start, Msg: e})
			continue
		}
		res.Questions = append(res.Questions, q)
	}
	return res
}

func detectFormat(content, filename string) string {
	t := strings.TrimSpace(strings.TrimPrefix(content, "\uFEFF"))
	fn := strings.ToLower(filename)
	switch {
	case strings.HasPrefix(t, "{") || strings.HasPrefix(t, "["):
		return "json"
	case strings.HasSuffix(fn, ".csv"), strings.HasSuffix(fn, ".tsv"):
		return "csv"
	case strings.HasSuffix(fn, ".txt"):
		return "text"
	}
	first := t
	if i := strings.IndexByte(t, '\n'); i >= 0 {
		first = t[:i]
	}
	l := strings.ToLower(first)
	if (strings.Contains(l, "вопрос;") || strings.Contains(l, "question;") || strings.Contains(l, "вопрос\t") || strings.Contains(l, "вопрос,")) && strings.ContainsAny(l, ";\t,") {
		return "csv"
	}
	return "text"
}

func (s *Server) learnImportParse(c *Ctx) error {
	var in struct {
		Format   string `json:"format"`
		Content  string `json:"content"`
		Filename string `json:"filename"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if strings.TrimSpace(in.Content) == "" {
		return badReq("Файл пуст")
	}
	f := in.Format
	if f != "json" && f != "csv" && f != "text" {
		f = detectFormat(in.Content, in.Filename)
	}
	var res importResult
	switch f {
	case "json":
		res = parseJSONImport(in.Content)
	case "csv":
		res = parseCSVImport(in.Content)
	default:
		res = parseTextImport(in.Content)
	}
	if len(res.Questions) > 500 {
		res.Questions = res.Questions[:500]
		res.Errors = append(res.Errors, importErr{Msg: "Принято только первые 500 заданий"})
	}
	return c.JSON(200, res)
}

// learnQuestionsImport добавляет (или заменяет) вопросы существующего теста.
func (s *Server) learnQuestionsImport(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Questions []qIn `json:"questions"`
		Replace   bool  `json:"replace"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	t, _, err := s.learnTestAccess(c, id, lvEdit)
	if err != nil {
		return err
	}
	if len(in.Questions) == 0 {
		return badReq("Нет заданий для импорта")
	}
	for i := range in.Questions {
		in.Questions[i].ID, in.Questions[i].FileID = 0, nil
		if e := in.Questions[i].normalize(); e != "" {
			return badReq(fmt.Sprintf("Задание %d: %s", i+1, e))
		}
	}
	ctx := c.Context()
	all := []qIn{}
	if !in.Replace {
		old, err := s.learnLoadQuestions(ctx, id)
		if err != nil {
			return err
		}
		for _, q := range old {
			all = append(all, qIn{ID: q.ID, Type: q.Type, Text: q.Text, FileID: q.FileID, Options: q.Options, Answers: q.Answers, Weight: q.Weight, Explanation: q.Explanation})
		}
	}
	all = append(all, in.Questions...)
	if len(all) > 500 {
		return badReq("В тесте не более 500 вопросов")
	}
	var purge []int64
	err = s.tx(ctx, func(tx pgx.Tx) error {
		var err error
		purge, err = s.learnSaveQuestions(ctx, tx, id, c.U.ID, all)
		return err
	})
	if err != nil {
		return err
	}
	s.learnPurgeFiles(ctx, purge)
	s.learnBump(ctx)
	_ = t
	return c.JSON(200, map[string]int{"added": len(in.Questions), "total": len(all)})
}

// ---------------------------------------------------------------- экспорт теста / шаблоны

func (s *Server) learnExportTestJSON(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	t, _, err := s.learnTestAccess(c, id, lvEdit)
	if err != nil {
		return err
	}
	qs, err := s.learnLoadQuestions(c.Context(), id)
	if err != nil {
		return err
	}
	type optOut struct {
		Text    string `json:"text"`
		Correct bool   `json:"correct,omitempty"`
	}
	type qOut struct {
		Type        string   `json:"type"`
		Text        string   `json:"text"`
		Options     []optOut `json:"options,omitempty"`
		Answers     []string `json:"answers,omitempty"`
		Weight      float64  `json:"weight"`
		Explanation string   `json:"explanation,omitempty"`
	}
	out := struct {
		Version int `json:"version"`
		testMeta
		Questions []qOut `json:"questions"`
	}{Version: 1, testMeta: testMeta{Title: t.Title, Description: t.Description, PassPercent: &t.PassPercent, TimeLimitMin: t.TimeLimitMin, MaxAttempts: t.MaxAttempts,
		ShuffleQuestions: t.ShuffleQuestions, ShuffleAnswers: t.ShuffleAnswers, PartialCredit: t.PartialCredit, ShowAnswers: t.ShowAnswers}, Questions: []qOut{}}
	for _, q := range qs {
		o := qOut{Type: q.Type, Text: q.Text, Answers: q.Answers, Weight: q.Weight, Explanation: q.Explanation}
		for _, x := range q.Options {
			o.Options = append(o.Options, optOut{x.Text, x.Correct})
		}
		out.Questions = append(out.Questions, o)
	}
	b, _ := json.MarshalIndent(out, "", "  ")
	h := c.W.Header()
	h.Set("Content-Type", "application/json; charset=utf-8")
	h.Set("Content-Disposition", "attachment; filename*=UTF-8''"+url.PathEscape(fmt.Sprintf("test-%d-%s.json", id, time.Now().Format("20060102"))))
	_, err = c.W.Write(b)
	return err
}

const learnTemplateJSON = `{
  "version": 1,
  "title": "Пример теста",
  "description": "Описание теста (необязательно)",
  "pass_percent": 70,
  "time_limit_min": 20,
  "max_attempts": 3,
  "shuffle_questions": true,
  "shuffle_answers": true,
  "show_answers": "after_attempt",
  "questions": [
    {
      "type": "single",
      "text": "Столица России?",
      "options": [{"text": "Санкт-Петербург"}, {"text": "Москва", "correct": true}, {"text": "Казань"}],
      "weight": 1,
      "explanation": "Москва — столица с 1918 года."
    },
    {
      "type": "multiple",
      "text": "Какие из перечисленных — простые числа?",
      "options": ["2", "4", "7", "9"],
      "correct": [1, 3],
      "weight": 2
    },
    {
      "type": "text",
      "text": "Сколько будет 2 + 2?",
      "answers": ["4", "четыре"]
    }
  ]
}
`

const learnTemplateCSV = "вопрос;тип;правильные;вес;пояснение;вариант1;вариант2;вариант3;вариант4\n" +
	"Столица России?;single;2;1;Москва — столица с 1918 года.;Санкт-Петербург;Москва;Казань;\n" +
	"Простые числа?;multiple;1,3;2;;2;4;7;9\n" +
	"Сколько будет 2 + 2?;text;4|четыре;1;;;;;\n"

const learnTemplateText = `Столица России?
Санкт-Петербург
*Москва
Казань
# вес: 1
# пояснение: Москва — столица с 1918 года.

Какие из перечисленных — простые числа?
*2
4
*7
9

Сколько будет 2 + 2?
= 4
= четыре
`

func (s *Server) learnImportTemplate(c *Ctx) error {
	h := c.W.Header()
	switch c.R.PathValue("ext") {
	case "json":
		h.Set("Content-Type", "application/json; charset=utf-8")
		h.Set("Content-Disposition", "attachment; filename*=UTF-8''test-template.json")
		_, err := c.W.Write([]byte(learnTemplateJSON))
		return err
	case "csv":
		h.Set("Content-Type", "text/csv; charset=utf-8")
		h.Set("Content-Disposition", "attachment; filename*=UTF-8''test-template.csv")
		_, err := c.W.Write(append([]byte{0xEF, 0xBB, 0xBF}, learnTemplateCSV...))
		return err
	case "txt":
		h.Set("Content-Type", "text/plain; charset=utf-8")
		h.Set("Content-Disposition", "attachment; filename*=UTF-8''test-template.txt")
		_, err := c.W.Write([]byte(learnTemplateText))
		return err
	}
	return errNotFound
}

var _ = bytes.NewReader
var _ = unicode.IsSpace
