package server

import (
	"context"
	"encoding/json"
	"errors"
	"strconv"
	"time"

	"github.com/jackc/pgx/v5"
)

// ---------------------------------------------------------------- старт и открытие шага

// lmsTouch отмечает активность: строка прохождения курса (upsert), шаг «в процессе», назначение «в процессе».
// Все записи — по первичному ключу пользователя, без блокировок чужих строк.
func (s *Server) lmsTouch(ctx context.Context, uid, dept int64, co *lcourse, stepID int64) {
	if _, err := s.db.Exec(ctx, `INSERT INTO learn_enrollments (user_id, course_id, dept_id, status, started_at, last_at, started_version, steps_total)
		VALUES ($1::bigint, $2::bigint, NULLIF($3::bigint, 0), 1, now(), now(), $4::int, $5::int)
		ON CONFLICT (user_id, course_id) DO UPDATE SET
			status = CASE WHEN learn_enrollments.status = 0 THEN 1 ELSE learn_enrollments.status END,
			started_version = CASE WHEN learn_enrollments.started_at IS NULL THEN EXCLUDED.started_version ELSE learn_enrollments.started_version END,
			started_at = coalesce(learn_enrollments.started_at, now()), last_at = now()`, uid, co.ID, dept, co.Version, co.RequiredCount); err != nil {
		s.log.Warn("lms touch enrollment", "err", err)
		return
	}
	if stepID > 0 {
		if _, err := s.db.Exec(ctx, `INSERT INTO learn_step_progress (user_id, step_id, course_id, status) VALUES ($1::bigint, $2::bigint, $3::bigint, 1)
			ON CONFLICT (user_id, step_id) DO UPDATE SET last_at = now()`, uid, stepID, co.ID); err != nil {
			s.log.Warn("lms touch step", "err", err)
		}
	}
	s.db.Exec(ctx, `UPDATE learn_assignees SET status = 1, started_at = now() WHERE user_id = $1 AND target_type = 'course' AND target_id = $2 AND status = 0`, uid, co.ID)
}

// lmsStepOf — шаг курса (проверка принадлежности курсу).
func (s *Server) lmsStepOf(ctx context.Context, cid, sid int64) (*lstep, error) {
	var x lstep
	err := s.db.QueryRow(ctx, `SELECT id, kind, ref_id, required FROM learn_course_steps WHERE id = $1 AND course_id = $2`, sid, cid).Scan(&x.ID, &x.Kind, &x.RefID, &x.Required)
	return &x, err
}

func (s *Server) lmsStart(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	co, _, err := s.lmsCourseAccess(c, id, lvView)
	if err != nil {
		return err
	}
	if _, ok, err := s.lmsPrereqs(c.Context(), c.U.ID, id); err != nil {
		return err
	} else if !ok {
		return conflict("Сначала пройдите курсы-предпосылки")
	}
	s.lmsTouch(c.Context(), c.U.ID, c.U.Dept, co, 0)
	return c.OK()
}

func (s *Server) lmsStepOpen(c *Ctx) error {
	cid, err := c.ID("id")
	if err != nil {
		return err
	}
	sid, err := c.ID("sid")
	if err != nil {
		return err
	}
	co, _, err := s.lmsCourseAccess(c, cid, lvView)
	if err != nil {
		return err
	}
	if _, err := s.lmsStepOf(c.Context(), cid, sid); err != nil {
		return err
	}
	if err := s.lmsGate(c.Context(), c.U.ID, co, sid); err != nil {
		return err
	}
	s.lmsTouch(c.Context(), c.U.ID, c.U.Dept, co, sid)
	return c.OK()
}

// lmsStepDone — отметка шага выполненным (материал просмотрен, ссылка открыта, «ознакомлен»). Тесты засчитываются только по попытке.
func (s *Server) lmsStepDone(c *Ctx) error {
	cid, err := c.ID("id")
	if err != nil {
		return err
	}
	sid, err := c.ID("sid")
	if err != nil {
		return err
	}
	ctx := c.Context()
	co, _, err := s.lmsCourseAccess(c, cid, lvView)
	if err != nil {
		return err
	}
	st, err := s.lmsStepOf(ctx, cid, sid)
	if err != nil {
		return err
	}
	if st.Kind == "test" {
		return badReq("Тест засчитывается автоматически по результату попытки")
	}
	if err := s.lmsGate(ctx, c.U.ID, co, sid); err != nil {
		return err
	}
	s.lmsTouch(ctx, c.U.ID, c.U.Dept, co, sid)
	if _, err := s.db.Exec(ctx, `UPDATE learn_step_progress SET status = 2, done_at = coalesce(done_at, now()), last_at = now() WHERE user_id = $1 AND step_id = $2`, c.U.ID, sid); err != nil {
		return err
	}
	if st.Kind == "item" && st.RefID != nil { // заодно отмечаем материал изученным в разделе «Материалы»
		s.db.Exec(ctx, `INSERT INTO learn_progress (user_id, item_id, folder_id, done_at) SELECT $1, i.id, i.folder_id, now() FROM learn_items i WHERE i.id = $2
			ON CONFLICT (user_id, item_id) DO UPDATE SET done_at = coalesce(learn_progress.done_at, now())`, c.U.ID, *st.RefID)
	}
	done, err := s.lmsRecalc(ctx, c.U.ID, c.U.Dept, co)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"ok": true, "completed": done})
}

// lmsStepBeat — сигнал активности с клиента (не чаще раза в ~30 с на шаг): накопительное время шага и курса.
func (s *Server) lmsStepBeat(c *Ctx) error {
	cid, err := c.ID("id")
	if err != nil {
		return err
	}
	sid, err := c.ID("sid")
	if err != nil {
		return err
	}
	_, err = s.db.Exec(c.Context(), `WITH u AS (
			UPDATE learn_step_progress sp SET time_sec = sp.time_sec + 30, beat_at = now(), last_at = now()
			WHERE sp.user_id = $1 AND sp.step_id = $2 AND sp.course_id = $3 AND (sp.beat_at IS NULL OR sp.beat_at < now() - interval '25 seconds') RETURNING sp.course_id)
		UPDATE learn_enrollments e SET time_sec = e.time_sec + 30, last_at = now() FROM u WHERE e.user_id = $1 AND e.course_id = u.course_id`, c.U.ID, sid, cid)
	if err != nil {
		return err
	}
	return c.OK()
}

// ---------------------------------------------------------------- пересчёт и завершение

// lmsRecalc пересчитывает прогресс курса пользователя и завершает курс, когда выполнены все обязательные шаги.
func (s *Server) lmsRecalc(ctx context.Context, uid, dept int64, co *lcourse) (bool, error) {
	var done int
	if err := s.db.QueryRow(ctx, `SELECT count(*) FROM learn_step_progress sp JOIN learn_course_steps st ON st.id = sp.step_id
		WHERE sp.user_id = $1 AND sp.course_id = $2 AND sp.status = 2 AND st.required`, uid, co.ID).Scan(&done); err != nil {
		return false, err
	}
	pct := 0
	if co.RequiredCount > 0 {
		pct = min(100, done*100/co.RequiredCount)
	}
	var status int
	err := s.db.QueryRow(ctx, `UPDATE learn_enrollments SET steps_done = $3, steps_total = $4, percent = CASE WHEN status = 2 THEN percent ELSE $5::smallint END, last_at = now()
		WHERE user_id = $1 AND course_id = $2 RETURNING status`, uid, co.ID, done, co.RequiredCount, pct).Scan(&status)
	if errors.Is(err, pgx.ErrNoRows) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	if status < 2 && co.RequiredCount > 0 && done >= co.RequiredCount {
		return s.lmsComplete(ctx, uid, dept, co)
	}
	return false, nil
}

// lmsRecalcCourse — после изменения структуры курса: пересчёт незавершивших (завершившие не сбрасываются).
func (s *Server) lmsRecalcCourse(ctx context.Context, cid int64) {
	co, err := s.lmsLoadCourse(ctx, cid)
	if err != nil {
		return
	}
	if _, err := s.db.Exec(ctx, `UPDATE learn_enrollments e SET steps_total = $2,
			steps_done = x.n, percent = CASE WHEN $2 = 0 THEN 0 ELSE least(100, x.n * 100 / $2) END
		FROM (SELECT e2.user_id, (SELECT count(*) FROM learn_step_progress sp JOIN learn_course_steps st ON st.id = sp.step_id
				WHERE sp.user_id = e2.user_id AND sp.course_id = e2.course_id AND sp.status = 2 AND st.required) AS n
			FROM learn_enrollments e2 WHERE e2.course_id = $1 AND e2.status < 2) x
		WHERE e.course_id = $1 AND e.user_id = x.user_id AND e.status < 2`, cid, co.RequiredCount); err != nil {
		s.log.Warn("lms recalc course", "err", err)
		return
	}
	if co.RequiredCount == 0 || co.Status != "published" {
		return
	}
	rows, err := s.db.Query(ctx, `SELECT user_id, coalesce(dept_id, 0) FROM learn_enrollments WHERE course_id = $1 AND status < 2 AND steps_done >= steps_total AND steps_total > 0 LIMIT 2000`, cid)
	if err != nil {
		return
	}
	type ud struct{ u, d int64 }
	var list []ud
	for rows.Next() {
		var x ud
		rows.Scan(&x.u, &x.d)
		list = append(list, x)
	}
	rows.Close()
	for _, x := range list {
		s.lmsComplete(ctx, x.u, x.d, co)
	}
}

// lmsComplete завершает курс: фиксирует результат, срок действия, выдаёт сертификат, закрывает назначения, уведомляет. Идемпотентно.
func (s *Server) lmsComplete(ctx context.Context, uid, dept int64, co *lcourse) (bool, error) {
	var certID *int64
	var exp *time.Time
	finished := false
	err := s.tx(ctx, func(tx pgx.Tx) error {
		var cycle, tsec int
		var score *float64
		err := tx.QueryRow(ctx, `UPDATE learn_enrollments SET status = 2, completed_at = now(), completed_version = $3, percent = 100, steps_done = greatest(steps_done, steps_total),
				expires_at = CASE WHEN $4::int > 0 THEN now() + make_interval(months => $4::int) END, soon_notified = false,
				score = (SELECT round(avg(score), 1) FROM learn_step_progress WHERE user_id = $1 AND course_id = $2 AND score IS NOT NULL)
			WHERE user_id = $1 AND course_id = $2 AND status < 2 RETURNING cycle, expires_at, score::float8, time_sec`, uid, co.ID, co.Version, co.ValidityMonths).Scan(&cycle, &exp, &score, &tsec)
		if errors.Is(err, pgx.ErrNoRows) {
			return nil // уже завершён
		}
		if err != nil {
			return err
		}
		finished = true
		var cid *int64
		if co.CertTemplateID != nil {
			id, err := s.lmsIssueCert(ctx, tx, certParams{UserID: uid, CourseID: &co.ID, TemplateID: *co.CertTemplateID, Title: co.Title, Score: score, Expires: exp})
			if err != nil {
				return err
			}
			cid = &id
			certID = cid
			if _, err := tx.Exec(ctx, `UPDATE learn_enrollments SET cert_id = $3 WHERE user_id = $1 AND course_id = $2`, uid, co.ID, id); err != nil {
				return err
			}
		}
		if _, err := tx.Exec(ctx, `INSERT INTO learn_completions (user_id, course_id, cycle, version, expires_at, score, time_sec, cert_id) VALUES ($1, $2, $3, $4, $5, $6::numeric, $7, $8)`,
			uid, co.ID, cycle, co.Version, exp, score, tsec, cid); err != nil {
			return err
		}
		_, err = tx.Exec(ctx, `UPDATE learn_assignees SET status = 2, done_at = now(), score = $3::numeric WHERE user_id = $1 AND target_type = 'course' AND target_id = $2 AND status < 2`, uid, co.ID, score)
		return err
	})
	if err != nil || !finished {
		return false, err
	}
	body := ""
	link := "/learning/courses/" + strconv.FormatInt(co.ID, 10)
	if certID != nil {
		body = "Сертификат выдан и доступен в разделе «Сертификаты»"
		link = "/learning/certificates/" + strconv.FormatInt(*certID, 10)
	}
	s.notify(ctx, []int64{uid}, "learning", "Курс пройден: "+co.Title, body, link)
	return true, nil
}

// lmsReset начинает новый цикл прохождения курса (истёк срок действия или переназначение): шаги сбрасываются, история остаётся.
func (s *Server) lmsReset(ctx context.Context, tx pgx.Tx, uid, cid int64) error {
	if _, err := tx.Exec(ctx, `DELETE FROM learn_step_progress WHERE user_id = $1 AND course_id = $2`, uid, cid); err != nil {
		return err
	}
	_, err := tx.Exec(ctx, `UPDATE learn_enrollments SET status = 0, cycle = cycle + 1, started_at = NULL, last_at = NULL, completed_at = NULL, expires_at = NULL, steps_done = 0, percent = 0,
		time_sec = 0, score = NULL, cert_id = NULL, soon_notified = false WHERE user_id = $1 AND course_id = $2`, uid, cid)
	return err
}

// ---------------------------------------------------------------- «Моё обучение»

func (s *Server) lmsMy(c *Ctx) error {
	ctx := c.Context()
	uid := c.U.ID
	assigned, err := s.arr(ctx, `SELECT a.id AS assignee_id, a.assignment_id, a.target_type, a.target_id, coalesce(co.title, t.title, 'Удалено') AS title, co.cover, co.est_minutes, a.due_at, a.status, a.high, a.mandatory,
			(a.due_at < now()) AS overdue, a.assigned_at, coalesce(e.percent, 0) AS percent, e.status AS e_status,
			CASE WHEN a.target_type = 'test' THEN (SELECT max(percent)::float8 FROM learn_attempts WHERE test_id = a.target_id AND user_id = a.user_id AND finished_at IS NOT NULL) END AS best
		FROM learn_assignees a LEFT JOIN learn_courses co ON a.target_type = 'course' AND co.id = a.target_id LEFT JOIN learn_tests t ON a.target_type = 'test' AND t.id = a.target_id
		LEFT JOIN learn_enrollments e ON a.target_type = 'course' AND e.course_id = a.target_id AND e.user_id = a.user_id
		WHERE a.user_id = $1 AND a.status < 2 AND (co.id IS NOT NULL OR t.id IS NOT NULL) ORDER BY (a.due_at < now()) DESC NULLS LAST, a.due_at NULLS LAST, a.id LIMIT 100`, uid)
	if err != nil {
		return err
	}
	progress, err := s.arr(ctx, `SELECT c.id, c.title, c.cover, c.est_minutes, e.percent, e.last_at, e.steps_done, e.steps_total
		FROM learn_enrollments e JOIN learn_courses c ON c.id = e.course_id WHERE e.user_id = $1 AND e.status = 1 AND c.status = 'published' ORDER BY e.last_at DESC NULLS LAST LIMIT 30`, uid)
	if err != nil {
		return err
	}
	completed, err := s.arr(ctx, `SELECT c.id, c.title, c.cover, e.completed_at, e.expires_at, e.score::float8 AS score, e.cert_id, (e.expires_at IS NOT NULL AND e.expires_at < now()) AS expired
		FROM learn_enrollments e JOIN learn_courses c ON c.id = e.course_id WHERE e.user_id = $1 AND e.status = 2 ORDER BY e.completed_at DESC LIMIT 50`, uid)
	if err != nil {
		return err
	}
	certs, err := s.arr(ctx, `SELECT id, number, title, issued_at, expires_at, status, (status = 'valid' AND expires_at IS NOT NULL AND expires_at < now()) AS expired,
			(status = 'valid' AND expires_at IS NOT NULL AND expires_at >= now() AND expires_at < now() + interval '30 days') AS soon
		FROM learn_certs WHERE user_id = $1 ORDER BY issued_at DESC LIMIT 50`, uid)
	if err != nil {
		return err
	}
	b := &qb{}
	vis, _, err := s.lmsVisible(c, b)
	if err != nil {
		return err
	}
	me := b.add(uid)
	recs, err := s.arr(ctx, `SELECT c.id, c.title, c.cover, c.est_minutes, c.tags, c.description FROM learn_courses c
		WHERE `+vis+` AND c.status = 'published' AND NOT EXISTS (SELECT 1 FROM learn_enrollments e WHERE e.user_id = `+me+`::bigint AND e.course_id = c.id AND e.status > 0)
			AND NOT EXISTS (SELECT 1 FROM learn_assignees a WHERE a.user_id = `+me+`::bigint AND a.target_type = 'course' AND a.target_id = c.id AND a.status < 2)
			AND NOT EXISTS (SELECT 1 FROM learn_course_prereq p WHERE p.course_id = c.id AND NOT EXISTS (SELECT 1 FROM learn_enrollments e WHERE e.user_id = `+me+`::bigint AND e.course_id = p.req_id AND e.status = 2))
		ORDER BY (SELECT count(*) FROM learn_enrollments e JOIN learn_courses d ON d.id = e.course_id WHERE e.user_id = `+me+`::bigint AND e.status = 2 AND d.tags && c.tags) DESC,
			c.steps_count DESC, c.id LIMIT 6`, b.args...)
	if err != nil {
		return err
	}
	sum, err := s.one(ctx, `SELECT count(*) FILTER (WHERE status < 2) AS open, count(*) FILTER (WHERE status < 2 AND due_at < now()) AS overdue,
			count(*) FILTER (WHERE status < 2 AND due_at >= now() AND due_at < now() + interval '7 days') AS soon, count(*) FILTER (WHERE status = 2) AS done
		FROM learn_assignees WHERE user_id = $1 AND status < 3`, uid)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]json.RawMessage{"assigned": assigned, "progress": progress, "completed": completed, "certs": certs, "recommended": recs, "summary": sum})
}

// lmsRestart — пересдача: пользователь начинает курс заново, когда срок действия результата истёк или заканчивается (≤ 30 дней).
// История прохождений и сертификаты сохраняются.
func (s *Server) lmsRestart(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	if _, _, err := s.lmsCourseAccess(c, id, lvView); err != nil {
		return err
	}
	var st int
	var exp *time.Time
	if err := s.db.QueryRow(ctx, `SELECT status, expires_at FROM learn_enrollments WHERE user_id = $1 AND course_id = $2`, c.U.ID, id).Scan(&st, &exp); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return conflict("Курс ещё не пройден")
		}
		return err
	}
	if st != 2 || exp == nil || exp.After(time.Now().AddDate(0, 0, 30)) {
		return conflict("Пройти курс заново можно, когда срок действия результата истёк или скоро истечёт")
	}
	if err := s.lmsStartCycle(ctx, []int64{c.U.ID}, []int64{id}); err != nil {
		return err
	}
	return c.OK()
}
