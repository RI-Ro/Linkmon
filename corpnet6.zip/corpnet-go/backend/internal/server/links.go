package server

import (
	"regexp"
	"strings"
)

// Внутренние ссылки (уведомления, баннеры) — абсолютные пути SPA, которые есть в frontend/src/main.tsx (ROUTES).
// Параметры, которые понимает фронтенд: /groups/:id?post=ID#comment-ID, /messages?chat=ID, /calendar?event=ID&date=YYYY-MM-DD,
// /documents|photos|videos?folder=ID, /search?q=, /news/:id#comment-ID, /ideas/:id#comment-ID.
var appRouteRe = regexp.MustCompile(`^/(?:` + strings.Join([]string{
	``, // главная
	`news/new`, `news/\d+`, `news/\d+/edit`,
	`people`, `people/\d+`, `departments`, `departments/\d+`, `directions`,
	`groups`, `groups/\d+`, `messages`, `calendar`, `documents`, `photos`, `videos`,
	`company`, `resources`, `search`, `settings`, `ideas`, `ideas/\d+`, `vacations`, `notifications`,
	`learning(?:/[A-Za-z0-9._~/-]*)?`, `requests(?:/[A-Za-z0-9._~/-]*)?`, `admin`, `admin/[a-z-]+`,
}, "|") + `)/?$`)

// validAppLink — путь существует в SPA (query и #hash не проверяются). Пустая ссылка допустима.
func validAppLink(link string) bool {
	if link == "" {
		return true
	}
	if !strings.HasPrefix(link, "/") || strings.HasPrefix(link, "//") {
		return false
	}
	p := link
	if i := strings.IndexAny(p, "?#"); i >= 0 {
		p = p[:i]
	}
	return appRouteRe.MatchString(p)
}
