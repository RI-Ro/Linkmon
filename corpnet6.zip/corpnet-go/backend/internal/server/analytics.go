package server

// Аналитика: СБОР данных. Отчёты — в analytics_api.go, фоновые пересчёты — в analytics_jobs.go.
//
// Правила для горячих путей:
//   - поиск: logSearch кладёт запись в буферизованный канал процесса (select/default: при переполнении запись
//     отбрасывается, запрос не блокируется); писатель раз в секунду вставляет накопленное одним INSERT … unnest;
//   - просмотр новости: одно SADD в Redis в момент, когда и так делается SETNX дедупликации просмотра;
//   - переходы по страницам: POST /api/analytics/pv (sendBeacon из роутера) — пара команд Redis одним pipeline;
//   - в PostgreSQL всё попадает пачками из фоновых задач.
//
// Несколько ЦОДов: счётчики лежат в Redis своего ЦОДа (ключи с dc), сбрасываются «прибавлением» в строки
// stats_daily с колонкой dc этого ЦОДа; отчёты суммируют по dc. Два ЦОДа не пишут в одну строку, поэтому конфликтов
// и потерянных обновлений нет. Абсолютные величины (dau, лайки…) пересчитываются из PG под job_locks и пишутся с dc=''.

import (
	"context"
	"encoding/json"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/redis/go-redis/v9"
)

type searchRec struct {
	id    int64
	uid   int64
	scope string
	q     string
	norm  string
	n, ms int
	at    time.Time
}

type searchClick struct {
	uid         int64
	norm, scope string
	entity      string
	id          int64
}

// analytics — состояние процесса (всё остальное хранится в Redis/PG).
type analytics struct {
	search  chan searchRec
	clicks  chan searchClick
	dropped atomic.Int64 // записей поиска отброшено из-за переполнения очереди
	written atomic.Int64

	mu     sync.Mutex
	lastMs int64
	seq    int64
	inst   int64

	loc *time.Location
}

const anQueue = 8192

func newAnalytics(instance, tz string) *analytics {
	a := &analytics{search: make(chan searchRec, anQueue), clicks: make(chan searchClick, 1024)}
	h := int64(0)
	for _, c := range instance {
		h = (h*31 + int64(c)) & 0x3ff
	}
	a.inst = h
	a.loc = time.UTC
	if l, err := time.LoadLocation(tz); err == nil {
		a.loc = l
	}
	return a
}

// nextID — монотонный идентификатор: миллисекунды | экземпляр (10 бит) | счётчик (12 бит). Не требует обращения к БД.
func (a *analytics) nextID() int64 {
	a.mu.Lock()
	defer a.mu.Unlock()
	ms := time.Now().UnixMilli() - 1704067200000 // 2024-01-01
	if ms <= a.lastMs {
		ms = a.lastMs
		a.seq++
		if a.seq >= 4096 {
			a.seq, ms = 0, ms+1
		}
	} else {
		a.seq = 0
	}
	a.lastMs = ms
	return ms<<22 | a.inst<<12 | a.seq
}

func (s *Server) anToday() string { return time.Now().In(s.an.loc).Format("2006-01-02") }

// normQuery приводит запрос к виду для группировки: нижний регистр, ё→е, одиночные пробелы, не длиннее 200 символов.
func normQuery(q string) string {
	q = strings.ToLower(strings.ReplaceAll(strings.ReplaceAll(q, "ё", "е"), "Ё", "е"))
	q = strings.Join(strings.Fields(q), " ")
	if r := []rune(q); len(r) > 200 {
		q = string(r[:200])
	}
	return q
}

func clip(q string, n int) string {
	if r := []rune(q); len(r) > n {
		return string(r[:n])
	}
	return q
}

// logSearch записывает поисковый запрос пользователя (асинхронно, без блокировок).
//
//	scope — раздел: global | news | people | groups | ideas | photos | videos | vacations | learning | …
//	count — число найденных результатов; took (необязательно) — время ответа, иначе считается от начала запроса.
//
// Вызывать одной строкой в хендлере после получения результатов:   s.logSearch(c, "news", q, len(list))
// Запросы короче двух символов, пустые и от неавторизованных не пишутся. Заголовок X-Search-Id содержит id записи.
func (s *Server) logSearch(c *Ctx, scope, q string, count int, took ...time.Duration) {
	if c == nil || c.U == nil || s.an == nil {
		return
	}
	norm := normQuery(q)
	if len([]rune(norm)) < 2 {
		return
	}
	d := time.Since(c.T0)
	if len(took) > 0 {
		d = took[0]
	}
	id := s.an.nextID()
	rec := searchRec{id: id, uid: c.U.ID, scope: clip(scope, 32), q: clip(strings.TrimSpace(q), 200), norm: norm, n: count, ms: int(d.Milliseconds()), at: time.Now()}
	select {
	case s.an.search <- rec:
		c.W.Header().Set("X-Search-Id", strconv.FormatInt(id, 10))
	default:
		s.an.dropped.Add(1)
	}
}

// anRun запускает писатель очереди поиска и фоновые задачи аналитики (вызывается из Run).
func (s *Server) anRun(ctx context.Context) {
	go s.anSearchWriter(ctx)
	go s.every(ctx, 20*time.Second, s.anFlush)
	go s.every(ctx, time.Minute, s.anRollups)
}

func (s *Server) anSearchWriter(ctx context.Context) {
	t := time.NewTicker(time.Second)
	defer t.Stop()
	for {
		select {
		case <-t.C:
			s.anWriteSearch(ctx)
		case <-ctx.Done():
			s.anWriteSearch(context.Background())
			return
		}
	}
}

// anWriteSearch вставляет накопленные запросы одним оператором. Набор подряд вводимых «и» → «ив» → «иван» одним
// пользователем в одном разделе за несколько секунд схлопывается в последний запрос (поиск с автодополнением
// иначе забил бы статистику префиксами).
func (s *Server) anWriteSearch(ctx context.Context) {
	var recs []searchRec
	for len(recs) < 5000 {
		select {
		case r := <-s.an.search:
			recs = append(recs, r)
			continue
		default:
		}
		break
	}
	var clicks []searchClick
	for len(clicks) < 1000 {
		select {
		case k := <-s.an.clicks:
			clicks = append(clicks, k)
			continue
		default:
		}
		break
	}
	if len(recs) == 0 && len(clicks) == 0 {
		return
	}
	cctx, cancel := context.WithTimeout(ctx, 15*time.Second)
	defer cancel()
	if len(recs) > 0 {
		out := make([]searchRec, 0, len(recs))
		last := map[string]int{}
		for _, r := range recs {
			k := strconv.FormatInt(r.uid, 10) + "|" + r.scope
			if i, ok := last[k]; ok && r.at.Sub(out[i].at) < 8*time.Second && strings.HasPrefix(r.norm, out[i].norm) {
				out[i] = r
				continue
			}
			last[k] = len(out)
			out = append(out, r)
		}
		n := len(out)
		ids, uids, scopes, qs, norms, cnt, ms, at := make([]int64, n), make([]int64, n), make([]string, n), make([]string, n), make([]string, n), make([]int32, n), make([]int32, n), make([]time.Time, n)
		for i, r := range out {
			ids[i], uids[i], scopes[i], qs[i], norms[i], cnt[i], ms[i], at[i] = r.id, r.uid, r.scope, r.q, r.norm, int32(r.n), int32(r.ms), r.at
		}
		if _, err := s.db.Exec(cctx, `INSERT INTO search_log (id, user_id, scope, query, normalized, results_count, took_ms, created_at)
			SELECT * FROM unnest($1::bigint[], $2::bigint[], $3::text[], $4::text[], $5::text[], $6::int[], $7::int[], $8::timestamptz[])
			ON CONFLICT (id) DO NOTHING`, ids, uids, scopes, qs, norms, cnt, ms, at); err != nil {
			s.log.Warn("search log insert failed", "err", err, "n", n)
		} else {
			s.an.written.Add(int64(n))
		}
	}
	for _, k := range clicks {
		var err error
		if k.id > 0 {
			_, err = s.db.Exec(cctx, `UPDATE search_log SET clicked = true, click_entity = $3 WHERE id = $1 AND user_id = $2 AND NOT clicked`, k.id, k.uid, k.entity)
		} else {
			_, err = s.db.Exec(cctx, `UPDATE search_log SET clicked = true, click_entity = $4 WHERE id = (
				SELECT id FROM search_log WHERE user_id = $1 AND NOT clicked AND normalized = $2 AND ($3 = '' OR scope = $3)
				  AND created_at > now() - interval '30 minutes' ORDER BY created_at DESC LIMIT 1)`, k.uid, k.norm, k.scope, k.entity)
		}
		if err != nil {
			s.log.Warn("search click failed", "err", err)
		}
	}
}

// ---------------------------------------------------------------- эндпоинты сбора

// anSearchClick: POST /api/analytics/search-click {query_id?, q, scope, entity}. Фронт шлёт через navigator.sendBeacon
// при открытии результата. Привязка — по query_id (заголовок X-Search-Id) либо по паре «пользователь + запрос».
func (s *Server) anSearchClick(c *Ctx) error {
	var in struct {
		QueryID json.Number `json:"query_id"`
		Q       string      `json:"q"`
		Scope   string      `json:"scope"`
		Entity  string      `json:"entity"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	k := searchClick{uid: c.U.ID, norm: normQuery(in.Q), scope: clip(in.Scope, 32), entity: clip(in.Entity, 80)}
	if id, err := in.QueryID.Int64(); err == nil && id > 0 {
		k.id = id
	} else if len([]rune(k.norm)) < 2 {
		c.W.WriteHeader(http.StatusNoContent)
		return nil
	}
	select {
	case s.an.clicks <- k:
	default:
	}
	c.W.WriteHeader(http.StatusNoContent)
	return nil
}

// Разделы портала для статистики посещений: по префиксу маршрута фронта. Сырые пути (с id) не сохраняются.
var anSections = []struct{ prefix, id string }{
	{"/messages", "chat"}, {"/groups", "groups"}, {"/learning", "learning"}, {"/documents", "documents"}, {"/photos", "photos"},
	{"/videos", "videos"}, {"/calendar", "calendar"}, {"/people", "people"}, {"/departments", "departments"}, {"/directions", "directions"},
	{"/ideas", "ideas"}, {"/requests", "requests"}, {"/wiki", "wiki"}, {"/vacations", "vacations"}, {"/search", "search"},
	{"/notifications", "notifications"}, {"/admin", "admin"}, {"/settings", "settings"}, {"/company", "company"}, {"/resources", "company"},
	{"/news", "news"},
}

func anSection(p string) string {
	if i := strings.IndexAny(p, "?#"); i >= 0 {
		p = p[:i]
	}
	if p == "/" || p == "" {
		return "news"
	}
	for _, s := range anSections {
		if p == s.prefix || strings.HasPrefix(p, s.prefix+"/") {
			return s.id
		}
	}
	return "other"
}

// anSectionIDs — все идентификаторы разделов (для HLL «уникальных посетителей раздела»).
func anSectionIDs() []string {
	seen := map[string]bool{"other": true}
	ids := []string{"other"}
	for _, s := range anSections {
		if !seen[s.id] {
			seen[s.id] = true
			ids = append(ids, s.id)
		}
	}
	return ids
}

func uaClass(ua string) (device, browser string) {
	l := strings.ToLower(ua)
	switch {
	case strings.Contains(l, "ipad") || strings.Contains(l, "tablet"):
		device = "tablet"
	case strings.Contains(l, "mobi") || strings.Contains(l, "android") || strings.Contains(l, "iphone"):
		device = "mobile"
	default:
		device = "desktop"
	}
	switch {
	case strings.Contains(l, "yabrowser"):
		browser = "yandex"
	case strings.Contains(l, "edg/") || strings.Contains(l, "edga/") || strings.Contains(l, "edgios/"):
		browser = "edge"
	case strings.Contains(l, "opr/") || strings.Contains(l, "opera"):
		browser = "opera"
	case strings.Contains(l, "firefox") || strings.Contains(l, "fxios"):
		browser = "firefox"
	case strings.Contains(l, "chrome") || strings.Contains(l, "crios"):
		browser = "chrome"
	case strings.Contains(l, "safari"):
		browser = "safari"
	default:
		browser = "other"
	}
	return
}

func (s *Server) anKey(kind string) string { return "an:" + kind + ":" + s.cfg.DCID }

// anPageview: POST /api/analytics/pv {p: "/news/12"}. Фронт шлёт при смене маршрута (один раз на страницу).
// Redis: счётчик раздела за день, HLL посетителей раздела; не чаще раза в 5 минут — «пользователь активен сегодня»,
// не чаще раза в 30 минут — «визит» (час суток, устройство, браузер).
func (s *Server) anPageview(c *Ctx) error {
	var in struct {
		P string `json:"p"`
	}
	_ = c.Decode(&in) // ошибка разбора не важна: просто считаем как «другое»
	ctx := c.Context()
	day := s.anToday()
	sec := anSection(in.P)
	uid := strconv.FormatInt(c.U.ID, 10)
	pipe := s.rdb.Pipeline()
	pipe.HIncrBy(ctx, s.anKey("sd"), day+"|pv|"+sec, 1)
	hll := s.anKey("hll") + ":" + day + ":" + sec
	pipe.PFAdd(ctx, hll, uid)
	pipe.Expire(ctx, hll, 72*time.Hour)
	active := pipe.SetNX(ctx, "an:ua:"+uid, 1, 5*time.Minute)
	visit := pipe.SetNX(ctx, "an:vs:"+uid, 1, 30*time.Minute)
	if _, err := pipe.Exec(ctx); err != nil {
		c.W.WriteHeader(http.StatusNoContent) // аналитика не должна ломать страницу
		return nil
	}
	if active.Val() || visit.Val() {
		p2 := s.rdb.Pipeline()
		if active.Val() {
			p2.HIncrBy(ctx, s.anKey("uda"), day+"|"+uid, 1)
		}
		if visit.Val() {
			dev, br := uaClass(c.R.UserAgent())
			sd := s.anKey("sd")
			p2.HIncrBy(ctx, sd, day+"|visits|", 1)
			p2.HIncrBy(ctx, sd, day+"|visit_hour|"+time.Now().In(s.an.loc).Format("15"), 1)
			p2.HIncrBy(ctx, sd, day+"|device|"+dev, 1)
			p2.HIncrBy(ctx, sd, day+"|browser|"+br, 1)
		}
		p2.Exec(ctx)
	}
	c.W.WriteHeader(http.StatusNoContent)
	return nil
}

// anNewsViewed отмечает первый за 30 минут просмотр новости пользователем (вызывается из getNews рядом со счётчиком просмотров).
func (s *Server) anNewsViewed(ctx context.Context, newsID, uid int64) {
	s.rdb.SAdd(ctx, s.anKey("nv"), strconv.FormatInt(newsID, 10)+":"+strconv.FormatInt(uid, 10))
}

// anNewsViews добавляет сброшенные из Redis просмотры новостей в дневной rollup (вызывается из flushViews).
func (s *Server) anNewsViews(ctx context.Context, ids []int64, cnt []int32) {
	day := s.anToday()
	var total int64
	for _, n := range cnt {
		total += int64(n)
	}
	if _, err := s.db.Exec(ctx, `INSERT INTO news_stats_daily (news_id, day, views)
		SELECT v.id, $3::date, v.c FROM unnest($1::bigint[], $2::int[]) AS v(id, c) JOIN news n ON n.id = v.id
		ON CONFLICT (news_id, day) DO UPDATE SET views = news_stats_daily.views + EXCLUDED.views`, ids, cnt, day); err != nil {
		s.log.Warn("analytics: news views rollup failed", "err", err)
		return
	}
	s.rdb.HIncrBy(ctx, s.anKey("sd"), day+"|news_views|", total)
}

// ---------------------------------------------------------------- сброс Redis → PG

type sdRow struct {
	day, metric, dim string
	v                int64
}

// anTake переименовывает ключ в «…:flush» (если предыдущий сброс не завершился — берёт его) и возвращает имя для чтения.
func (s *Server) anTake(ctx context.Context, key string) string {
	s.rdb.RenameNX(ctx, key, key+":flush")
	return key + ":flush"
}

// anFlush сбрасывает накопленное этим ЦОДом: счётчики разделов/посещений, активность пользователей, уникальных читателей новостей.
func (s *Server) anFlush(ctx context.Context) {
	lk := "lock:an:flush:" + s.cfg.DCID
	if !s.rdb.SetNX(ctx, lk, s.cfg.InstanceID, 30*time.Second).Val() {
		return
	}
	defer s.rdb.Del(ctx, lk)
	s.anFlushCounters(ctx)
	s.anFlushActivity(ctx)
	s.anFlushNewsViewers(ctx)
	s.anFlushHLL(ctx)
}

func (s *Server) anFlushCounters(ctx context.Context) {
	key := s.anTake(ctx, s.anKey("sd"))
	m, err := s.rdb.HGetAll(ctx, key).Result()
	if err != nil || len(m) == 0 {
		return
	}
	days, metrics, dims, vals := []string{}, []string{}, []string{}, []int64{}
	for f, v := range m {
		p := strings.SplitN(f, "|", 3)
		n, e := strconv.ParseInt(v, 10, 64)
		if len(p) != 3 || e != nil {
			continue
		}
		days, metrics, dims, vals = append(days, p[0]), append(metrics, p[1]), append(dims, p[2]), append(vals, n)
	}
	if len(days) > 0 {
		if _, err := s.db.Exec(ctx, `INSERT INTO stats_daily (day, metric, dim, dc, value)
			SELECT d::date, m, x, $5, v FROM unnest($1::text[], $2::text[], $3::text[], $4::bigint[]) AS t(d, m, x, v)
			ON CONFLICT (day, metric, dim, dc) DO UPDATE SET value = stats_daily.value + EXCLUDED.value`, days, metrics, dims, vals, s.cfg.DCID); err != nil {
			s.log.Warn("analytics: counters flush failed", "err", err)
			return
		}
	}
	s.rdb.Del(ctx, key)
}

func (s *Server) anFlushActivity(ctx context.Context) {
	key := s.anTake(ctx, s.anKey("uda"))
	m, err := s.rdb.HGetAll(ctx, key).Result()
	if err != nil || len(m) == 0 {
		return
	}
	days, uids, hits := []string{}, []int64{}, []int32{}
	for f, v := range m {
		p := strings.SplitN(f, "|", 2)
		if len(p) != 2 {
			continue
		}
		u, e1 := strconv.ParseInt(p[1], 10, 64)
		n, e2 := strconv.ParseInt(v, 10, 32)
		if e1 == nil && e2 == nil {
			days, uids, hits = append(days, p[0]), append(uids, u), append(hits, int32(n))
		}
	}
	if len(days) > 0 {
		if _, err := s.db.Exec(ctx, `INSERT INTO user_daily_activity (day, user_id, hits)
			SELECT d::date, u, h FROM unnest($1::text[], $2::bigint[], $3::int[]) AS t(d, u, h)
			ON CONFLICT (day, user_id) DO UPDATE SET hits = user_daily_activity.hits + EXCLUDED.hits`, days, uids, hits); err != nil {
			s.log.Warn("analytics: activity flush failed", "err", err)
			return
		}
	}
	s.rdb.Del(ctx, key)
}

// anFlushNewsViewers фиксирует новых уникальных читателей: вставка в news_views идемпотентна (ON CONFLICT DO NOTHING),
// а счётчики прибавляются только по реально вставленным строкам — повторный сброс не удвоит охват.
func (s *Server) anFlushNewsViewers(ctx context.Context) {
	key := s.anTake(ctx, s.anKey("nv"))
	members, err := s.rdb.SMembers(ctx, key).Result()
	if err != nil || len(members) == 0 {
		return
	}
	nids, uids := make([]int64, 0, len(members)), make([]int64, 0, len(members))
	for _, mm := range members {
		a, b, ok := strings.Cut(mm, ":")
		n, e1 := strconv.ParseInt(a, 10, 64)
		u, e2 := strconv.ParseInt(b, 10, 64)
		if ok && e1 == nil && e2 == nil {
			nids, uids = append(nids, n), append(uids, u)
		}
	}
	day := s.anToday()
	err = s.tx(ctx, func(tx pgx.Tx) error {
		var total int64
		err := tx.QueryRow(ctx, `WITH inp AS (
				SELECT DISTINCT i.nid, i.uid FROM unnest($1::bigint[], $2::bigint[]) AS i(nid, uid) JOIN news n ON n.id = i.nid),
			ins AS (INSERT INTO news_views (news_id, user_id) SELECT nid, uid FROM inp ON CONFLICT DO NOTHING RETURNING news_id, user_id),
			per AS (SELECT news_id, count(*)::int AS c FROM ins GROUP BY news_id),
			d1 AS (UPDATE news n SET uniq_views = n.uniq_views + per.c FROM per WHERE n.id = per.news_id RETURNING 1),
			d2 AS (INSERT INTO news_stats_daily (news_id, day, uniq_views) SELECT news_id, $3::date, c FROM per
				ON CONFLICT (news_id, day) DO UPDATE SET uniq_views = news_stats_daily.uniq_views + EXCLUDED.uniq_views RETURNING 1),
			d3 AS (INSERT INTO news_dept_views (news_id, dept_id, viewers)
				SELECT i.news_id, coalesce(u.department_id, 0), count(*)::int FROM ins i LEFT JOIN users u ON u.id = i.user_id GROUP BY 1, 2
				ON CONFLICT (news_id, dept_id) DO UPDATE SET viewers = news_dept_views.viewers + EXCLUDED.viewers RETURNING 1)
			SELECT coalesce((SELECT sum(c) FROM per), 0)::bigint`, nids, uids, day).Scan(&total)
		if err != nil {
			return err
		}
		if total > 0 {
			_, err = tx.Exec(ctx, `INSERT INTO stats_daily (day, metric, dim, dc, value) VALUES ($1::date, 'news_uniq', '', $2, $3)
				ON CONFLICT (day, metric, dim, dc) DO UPDATE SET value = stats_daily.value + EXCLUDED.value`, day, s.cfg.DCID, total)
		}
		return err
	})
	if err != nil {
		s.log.Warn("analytics: news viewers flush failed", "err", err)
		return
	}
	s.rdb.Del(ctx, key)
}

// anFlushHLL записывает число уникальных посетителей разделов за сегодня/вчера (абсолютное значение для (день, ЦОД)).
func (s *Server) anFlushHLL(ctx context.Context) {
	now := time.Now().In(s.an.loc)
	days := []string{now.Format("2006-01-02"), now.AddDate(0, 0, -1).Format("2006-01-02")}
	secs := anSectionIDs()
	type item struct {
		day, sec string
		c        *redis.IntCmd
	}
	pipe := s.rdb.Pipeline()
	var items []item
	for _, d := range days {
		for _, sec := range secs {
			items = append(items, item{d, sec, pipe.PFCount(ctx, s.anKey("hll")+":"+d+":"+sec)})
		}
	}
	if _, err := pipe.Exec(ctx); err != nil {
		return
	}
	ds, dims, vals := []string{}, []string{}, []int64{}
	for _, it := range items {
		if v := it.c.Val(); v > 0 {
			ds, dims, vals = append(ds, it.day), append(dims, it.sec), append(vals, v)
		}
	}
	if len(ds) == 0 {
		return
	}
	if _, err := s.db.Exec(ctx, `INSERT INTO stats_daily (day, metric, dim, dc, value)
		SELECT d::date, 'pv_users', x, $4, v FROM unnest($1::text[], $2::text[], $3::bigint[]) AS t(d, x, v)
		ON CONFLICT (day, metric, dim, dc) DO UPDATE SET value = EXCLUDED.value`, ds, dims, vals, s.cfg.DCID); err != nil {
		s.log.Warn("analytics: hll flush failed", "err", err)
	}
}

// anCount — общее число элементов в нескольких JSON-массивах (для подсчёта результатов поиска).
func anCount(arrs ...json.RawMessage) int {
	n := 0
	for _, a := range arrs {
		if len(a) <= 2 {
			continue // "[]"
		}
		var x []json.RawMessage
		if json.Unmarshal(a, &x) == nil {
			n += len(x)
		}
	}
	return n
}
