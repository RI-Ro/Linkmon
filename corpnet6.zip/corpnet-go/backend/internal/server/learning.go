package server

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

// Раздел «Обучение»: материалы (папки, права, файлы, прогресс) и тесты (вопросы, попытки, результаты).
//
// Файлы раздела:
//   learning.go          — маршруты, права, дерево папок, ACL папок
//   learning_items.go    — материалы и загрузка файлов
//   learning_tests.go    — тесты и вопросы (редактирование, список, статистика)
//   learning_attempts.go — прохождение, проверка, история, результаты, экспорт CSV
//   learning_import.go   — импорт/экспорт заданий (JSON, CSV, текст)

const (
	lvView = 1 // просмотр
	lvEdit = 3 // редактирование: материалы, тесты, результаты
	lvOwn  = 4 // управление: права, удаление папки
)

// registerLearning регистрирует маршруты раздела «Обучение» (материалы и тесты).
func (s *Server) registerLearning(m *http.ServeMux) {
	const U, E = "user", "editor"
	_ = E
	p := "/api/learning"

	// папки (материалы и тесты) и права
	m.HandleFunc("GET "+p+"/tree", s.h(U, s.learnTreeH))
	m.HandleFunc("POST "+p+"/folders", s.h(U, s.learnFolderSave))
	m.HandleFunc("PUT "+p+"/folders/{id}", s.h(U, s.learnFolderSave))
	m.HandleFunc("DELETE "+p+"/folders/{id}", s.h(U, s.learnFolderDelete))
	m.HandleFunc("POST "+p+"/folders/{id}/move", s.h(U, s.learnFolderMove))
	m.HandleFunc("GET "+p+"/folders/{id}/acl", s.h(U, s.learnACLGet))
	m.HandleFunc("PUT "+p+"/folders/{id}/acl", s.h(U, s.learnACLPut))
	m.HandleFunc("POST "+p+"/folders/{id}/bulk", s.h(U, s.learnBulkUpload))
	m.HandleFunc("POST "+p+"/files", s.h(U, s.learnUpload))

	// материалы
	m.HandleFunc("GET "+p+"/materials", s.h(U, s.learnMaterials))
	m.HandleFunc("GET "+p+"/materials/recent", s.h(U, s.learnRecent))
	m.HandleFunc("POST "+p+"/items", s.h(U, s.learnItemSave))
	m.HandleFunc("POST "+p+"/items/move", s.h(U, s.learnItemsMove))
	m.HandleFunc("GET "+p+"/items/{id}", s.h(U, s.learnItemGet))
	m.HandleFunc("PUT "+p+"/items/{id}", s.h(U, s.learnItemSave))
	m.HandleFunc("DELETE "+p+"/items/{id}", s.h(U, s.learnItemDelete))
	m.HandleFunc("POST "+p+"/items/{id}/done", s.h(U, s.learnItemDone))

	// тесты
	m.HandleFunc("GET "+p+"/tests", s.h(U, s.learnTests))
	m.HandleFunc("POST "+p+"/tests", s.h(U, s.learnTestSave))
	m.HandleFunc("POST "+p+"/tests/move", s.h(U, s.learnTestsMove))
	m.HandleFunc("GET "+p+"/tests/{id}", s.h(U, s.learnTestGet))
	m.HandleFunc("PUT "+p+"/tests/{id}", s.h(U, s.learnTestSave))
	m.HandleFunc("DELETE "+p+"/tests/{id}", s.h(U, s.learnTestDelete))
	m.HandleFunc("POST "+p+"/tests/{id}/copy", s.h(U, s.learnTestCopy))
	m.HandleFunc("POST "+p+"/tests/{id}/status", s.h(U, s.learnTestStatus))
	m.HandleFunc("POST "+p+"/tests/{id}/questions/import", s.h(U, s.learnQuestionsImport))
	m.HandleFunc("GET "+p+"/tests/{id}/attempts", s.h(U, s.learnTestAttempts))
	m.HandleFunc("GET "+p+"/tests/{id}/stats", s.h(U, s.learnTestStats))
	m.HandleFunc("GET "+p+"/tests/{id}/export.csv", s.h(U, s.learnExportTestCSV))
	m.HandleFunc("GET "+p+"/tests/{id}/export.json", s.h(U, s.learnExportTestJSON))
	m.HandleFunc("GET "+p+"/results/export.csv", s.h(U, s.learnExportFolderCSV))
	m.HandleFunc("POST "+p+"/import/parse", s.h(U, s.learnImportParse))
	m.HandleFunc("GET "+p+"/import/template/{ext}", s.h(U, s.learnImportTemplate))

	// прохождение и результаты
	m.HandleFunc("POST "+p+"/tests/{id}/start", s.h(U, s.learnAttemptStart))
	m.HandleFunc("GET "+p+"/attempts/{id}", s.h(U, s.learnAttemptGet))
	m.HandleFunc("PUT "+p+"/attempts/{id}/answers", s.h(U, s.learnAttemptSave))
	m.HandleFunc("POST "+p+"/attempts/{id}/finish", s.h(U, s.learnAttemptFinish))
	m.HandleFunc("GET "+p+"/my/attempts", s.h(U, s.learnMyAttempts))

	go s.learnSweeper()
}

// ---------------------------------------------------------------- права

type lfolder struct {
	ID          int64
	Kind        string
	ParentID    *int64
	Name        string
	Description string
	Visibility  string
	OwnerID     *int64
	Level       int
}

// learnFolder читает папку вместе с эффективным уровнем доступа вызывающего (learn_level) и проверяет минимум.
func (s *Server) learnFolder(c *Ctx, id int64, min int) (*lfolder, error) {
	var f lfolder
	err := s.db.QueryRow(c.Context(), `SELECT f.id, f.kind, f.parent_id, f.name, f.description, f.visibility, f.owner_id,
		learn_level(f.id, $2, $3, $4) FROM learn_folders f WHERE f.id = $1`, id, c.U.ID, c.U.Dept, c.U.IsAdmin()).
		Scan(&f.ID, &f.Kind, &f.ParentID, &f.Name, &f.Description, &f.Visibility, &f.OwnerID, &f.Level)
	if err != nil {
		return nil, err
	}
	if f.Level < min || f.Level == 0 {
		return nil, errForbidden
	}
	return &f, nil
}

// learnFolderOf — то же по id объекта (материала/теста) через его папку.
func (s *Server) learnLevelOf(c *Ctx, table string, id int64) (folder int64, lvl int, err error) {
	if table != "learn_items" && table != "learn_tests" {
		return 0, 0, errNotFound
	}
	err = s.db.QueryRow(c.Context(), `SELECT t.folder_id, learn_level(t.folder_id, $2, $3, $4) FROM `+table+` t WHERE t.id = $1`,
		id, c.U.ID, c.U.Dept, c.U.IsAdmin()).Scan(&folder, &lvl)
	if err == nil && lvl == 0 { // материал/тест доступен как шаг доступного курса или по назначению
		kind := "item"
		if table == "learn_tests" {
			kind = "test"
		}
		var ok bool
		if e := s.db.QueryRow(c.Context(), `SELECT lms_ref_ok($1, $2, $3, $4, $5)`, kind, id, c.U.ID, c.U.Dept, c.U.IsAdmin()).Scan(&ok); e == nil && ok {
			lvl = lvView
		}
	}
	return
}

func (s *Server) canCreateRoot(c *Ctx) bool { return c.U.CanEdit() }

// ---------------------------------------------------------------- дерево папок (кэш на пользователя в Redis)

type treeNode struct {
	ID    int64  `json:"id"`
	Level int    `json:"level"`
	Pid   *int64 `json:"parent_id"`
}

const treeSQL = `WITH RECURSIVE dc AS (
		SELECT id, parent_id FROM departments WHERE id = $3::bigint
		UNION ALL SELECT x.id, x.parent_id FROM departments x JOIN dc ON x.id = dc.parent_id),
	g AS (SELECT folder_id, max(level) AS lvl FROM learn_acl
		WHERE (subject_type = 'user' AND subject_id = $2::bigint) OR (subject_type = 'department' AND subject_id IN (SELECT id FROM dc)) GROUP BY 1),
	t AS (
		SELECT f.id, CASE WHEN f.visibility = 'restricted' THEN o.own ELSE 1 END AS vl, CASE WHEN o.own >= 3 THEN o.own ELSE 0 END AS mng
		FROM learn_folders f LEFT JOIN g ON g.folder_id = f.id
		JOIN LATERAL (SELECT greatest(coalesce(g.lvl, 0), CASE WHEN f.owner_id = $2::bigint THEN 4 ELSE 0 END) AS own) o ON true
		WHERE f.kind = $1::text AND f.parent_id IS NULL
		UNION ALL
		SELECT f.id, CASE WHEN f.visibility = 'restricted' THEN o.own ELSE t.vl END, greatest(t.mng, CASE WHEN o.own >= 3 THEN o.own ELSE 0 END)
		FROM t JOIN learn_folders f ON f.parent_id = t.id LEFT JOIN g ON g.folder_id = f.id
		JOIN LATERAL (SELECT greatest(coalesce(g.lvl, 0), CASE WHEN f.owner_id = $2::bigint THEN 4 ELSE 0 END) AS own) o ON true)
	SELECT f.id, f.parent_id, f.name, f.description, f.visibility, f.sort, f.owner_id, f.created_at, f.items_count,
		CASE WHEN l.lvl >= 3 THEN f.items_count ELSE f.pub_count END AS count, l.lvl AS level
	FROM t JOIN learn_folders f ON f.id = t.id
	CROSS JOIN LATERAL (SELECT CASE WHEN $4::boolean THEN 4 ELSE greatest(t.vl, t.mng) END AS lvl) l
	WHERE l.lvl > 0 ORDER BY f.sort, lower(f.name), f.id`

func (s *Server) learnVer(ctx context.Context) string {
	v, err := s.rdb.Get(ctx, "lt:ver").Result()
	if err != nil {
		return "0"
	}
	return v
}

// learnBump сбрасывает кэши деревьев всех пользователей (папки/права/счётчики изменились).
func (s *Server) learnBump(ctx context.Context) { s.rdb.Incr(ctx, "lt:ver") }

func (s *Server) learnTreeRaw(ctx context.Context, u *User, kind string) (json.RawMessage, error) {
	key := fmt.Sprintf("lt:%s:%s:%d", s.learnVer(ctx), kind, u.ID)
	if b, err := s.rdb.Get(ctx, key).Bytes(); err == nil {
		return b, nil
	}
	b, err := s.arr(ctx, treeSQL, kind, u.ID, u.Dept, u.IsAdmin())
	if err != nil {
		return nil, err
	}
	s.rdb.Set(ctx, key, []byte(b), 2*time.Minute)
	return b, nil
}

// learnTreeIDs возвращает id доступных папок (level>=1) и управляемых (level>=3). all==nil означает «все» (администратор).
func (s *Server) learnTreeIDs(ctx context.Context, u *User, kind string) (all, mng []int64, nodes []treeNode, err error) {
	b, err := s.learnTreeRaw(ctx, u, kind)
	if err != nil {
		return nil, nil, nil, err
	}
	if err = json.Unmarshal(b, &nodes); err != nil {
		return
	}
	all, mng = []int64{}, []int64{}
	for _, n := range nodes {
		all = append(all, n.ID)
		if n.Level >= lvEdit {
			mng = append(mng, n.ID)
		}
	}
	return
}

func (s *Server) learnTreeH(c *Ctx) error {
	kind := c.Q("kind")
	if kind != "materials" && kind != "tests" && kind != "courses" {
		return badReq("Неизвестный раздел")
	}
	ctx := c.Context()
	b, err := s.learnTreeRaw(ctx, c.U, kind)
	if err != nil {
		return err
	}
	out := map[string]any{"folders": json.RawMessage(b)}
	if kind == "materials" {
		rows, err := s.db.Query(ctx, `SELECT folder_id, count(*) FROM learn_progress WHERE user_id = $1 AND done_at IS NOT NULL GROUP BY 1`, c.U.ID)
		if err != nil {
			return err
		}
		done := map[int64]int{}
		for rows.Next() {
			var f int64
			var n int
			if err := rows.Scan(&f, &n); err != nil {
				return err
			}
			done[f] = n
		}
		rows.Close()
		out["done"] = done
	}
	return c.JSON(200, out)
}

// ---------------------------------------------------------------- папки

func (s *Server) learnFolderJSON(c *Ctx, id int64) (json.RawMessage, error) {
	return s.one(c.Context(), `SELECT f.id, f.kind, f.parent_id, f.name, f.description, f.visibility, f.sort, f.owner_id, f.items_count, f.pub_count,
		learn_level(f.id, $2, $3, $4) AS level FROM learn_folders f WHERE f.id = $1`, id, c.U.ID, c.U.Dept, c.U.IsAdmin())
}

func (s *Server) learnFolderSave(c *Ctx) error {
	var in struct {
		Kind        string `json:"kind"`
		ParentID    *int64 `json:"parent_id"`
		Name        string `json:"name"`
		Description string `json:"description"`
		Visibility  string `json:"visibility"`
		Sort        int    `json:"sort"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Name = strings.TrimSpace(in.Name)
	if in.Name == "" || len([]rune(in.Name)) > 200 {
		return badReq("Укажите название папки (до 200 символов)")
	}
	if len(in.Description) > 2000 {
		return badReq("Слишком длинное описание")
	}
	ctx := c.Context()
	var id int64
	if c.R.PathValue("id") != "" {
		var err error
		if id, err = c.ID("id"); err != nil {
			return err
		}
		if _, err = s.learnFolder(c, id, lvEdit); err != nil {
			return err
		}
		if _, err = s.db.Exec(ctx, `UPDATE learn_folders SET name = $2, description = $3, sort = $4, updated_at = now() WHERE id = $1`,
			id, in.Name, in.Description, in.Sort); err != nil {
			return err
		}
	} else {
		if in.Kind != "materials" && in.Kind != "tests" && in.Kind != "courses" {
			return badReq("Неизвестный раздел")
		}
		if in.ParentID != nil {
			p, err := s.learnFolder(c, *in.ParentID, lvEdit)
			if err != nil {
				return err
			}
			if p.Kind != in.Kind {
				return badReq("Папка относится к другому разделу")
			}
		} else if !s.canCreateRoot(c) {
			return errForbidden
		}
		vis := "company"
		if in.Visibility == "restricted" {
			vis = "restricted"
		}
		if err := s.db.QueryRow(ctx, `INSERT INTO learn_folders (kind, parent_id, name, description, visibility, owner_id, sort)
			VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`, in.Kind, in.ParentID, in.Name, in.Description, vis, c.U.ID, in.Sort).Scan(&id); err != nil {
			return err
		}
	}
	s.learnBump(ctx)
	b, err := s.learnFolderJSON(c, id)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// learnPurgeFiles удаляет файлы (записи и байты) вложений и картинок вопросов, найденные до удаления владельца.
func (s *Server) learnPurgeFiles(ctx context.Context, ids []int64) {
	if len(ids) == 0 {
		return
	}
	// копии тестов делят байты картинок: файл на диске удаляется, только когда на него больше нет записей
	rows, err := s.db.Query(ctx, `DELETE FROM files d WHERE d.id = ANY($1::bigint[]) AND d.context = 'learning'
		RETURNING d.storage, d.thumb, EXISTS (SELECT 1 FROM files o WHERE o.storage = d.storage AND o.id <> d.id)`, ids)
	if err != nil {
		s.log.Warn("learn purge files", "err", err)
		return
	}
	var names []string
	for rows.Next() {
		var a, b string
		var shared bool
		rows.Scan(&a, &b, &shared)
		if !shared {
			names = append(names, a, b)
		}
	}
	rows.Close()
	s.removeStored(false, names...)
}

func (s *Server) learnFolderDelete(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, err = s.learnFolder(c, id, lvOwn); err != nil {
		return err
	}
	ctx := c.Context()
	var fids []int64
	rows, err := s.db.Query(ctx, `WITH RECURSIVE t AS (SELECT id FROM learn_folders WHERE id = $1 UNION ALL SELECT f.id FROM learn_folders f JOIN t ON f.parent_id = t.id)
		SELECT lf.file_id FROM learn_item_files lf JOIN learn_items i ON i.id = lf.item_id WHERE i.folder_id IN (SELECT id FROM t)
		UNION SELECT q.file_id FROM learn_questions q JOIN learn_tests x ON x.id = q.test_id WHERE x.folder_id IN (SELECT id FROM t) AND q.file_id IS NOT NULL`, id)
	if err != nil {
		return err
	}
	for rows.Next() {
		var f int64
		rows.Scan(&f)
		fids = append(fids, f)
	}
	rows.Close()
	if _, err := s.db.Exec(ctx, `DELETE FROM learn_folders WHERE id = $1`, id); err != nil {
		return err
	}
	s.learnPurgeFiles(ctx, fids)
	s.learnBump(ctx)
	s.audit(c, "learning.folder.delete", "learn_folder", id, nil)
	return c.OK()
}

func (s *Server) learnFolderMove(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		ParentID *int64 `json:"parent_id"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	f, err := s.learnFolder(c, id, lvEdit)
	if err != nil {
		return err
	}
	ctx := c.Context()
	if in.ParentID == nil {
		if !s.canCreateRoot(c) {
			return errForbidden
		}
	} else {
		p, err := s.learnFolder(c, *in.ParentID, lvEdit)
		if err != nil {
			return err
		}
		if p.Kind != f.Kind {
			return badReq("Папка относится к другому разделу")
		}
		var cyc bool
		if err := s.db.QueryRow(ctx, `WITH RECURSIVE t AS (SELECT id FROM learn_folders WHERE id = $1 UNION ALL SELECT x.id FROM learn_folders x JOIN t ON x.parent_id = t.id)
			SELECT EXISTS (SELECT 1 FROM t WHERE id = $2)`, id, *in.ParentID).Scan(&cyc); err != nil {
			return err
		}
		if cyc {
			return badReq("Нельзя переместить папку внутрь самой себя")
		}
	}
	if _, err := s.db.Exec(ctx, `UPDATE learn_folders SET parent_id = $2, updated_at = now() WHERE id = $1`, id, in.ParentID); err != nil {
		return err
	}
	s.learnBump(ctx)
	return c.OK()
}

// ---------------------------------------------------------------- права на папку

func (s *Server) learnACLGet(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	f, err := s.learnFolder(c, id, lvOwn)
	if err != nil {
		return err
	}
	entries, err := s.arr(c.Context(), `SELECT a.subject_type, a.subject_id, a.level,
		CASE a.subject_type WHEN 'user' THEN (SELECT full_name FROM users WHERE id = a.subject_id)
			ELSE (SELECT name FROM departments WHERE id = a.subject_id) END AS name
		FROM learn_acl a WHERE a.folder_id = $1 ORDER BY a.subject_type DESC, 4`, id)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"resource": map[string]any{"visibility": f.Visibility, "owner_id": f.OwnerID, "kind": f.Kind}, "entries": entries})
}

func (s *Server) learnACLPut(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Visibility string `json:"visibility"`
		Entries    []struct {
			SubjectType string `json:"subject_type"`
			SubjectID   int64  `json:"subject_id"`
			Level       int    `json:"level"`
		} `json:"entries"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if _, err = s.learnFolder(c, id, lvOwn); err != nil {
		return err
	}
	if in.Visibility != "company" {
		in.Visibility = "restricted"
	}
	types, ids, lvls := []string{}, []int64{}, []int32{}
	seen := map[string]bool{}
	for _, e := range in.Entries {
		k := fmt.Sprint(e.SubjectType, e.SubjectID)
		if (e.SubjectType != "user" && e.SubjectType != "department") || e.SubjectID <= 0 || e.Level < 1 || e.Level > 4 || seen[k] {
			continue
		}
		seen[k] = true
		lv := int32(e.Level)
		if lv == 2 {
			lv = 1
		}
		types, ids, lvls = append(types, e.SubjectType), append(ids, e.SubjectID), append(lvls, lv)
	}
	ctx := c.Context()
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `UPDATE learn_folders SET visibility = $2, updated_at = now() WHERE id = $1`, id, in.Visibility); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `DELETE FROM learn_acl WHERE folder_id = $1`, id); err != nil {
			return err
		}
		_, err := tx.Exec(ctx, `INSERT INTO learn_acl (folder_id, subject_type, subject_id, level)
			SELECT $1, t, i, l FROM unnest($2::text[], $3::bigint[], $4::smallint[]) AS x(t, i, l)`, id, types, ids, lvls)
		return err
	})
	if err != nil {
		return err
	}
	s.learnBump(ctx)
	s.audit(c, "learning.acl", "learn_folder", id, map[string]any{"visibility": in.Visibility, "entries": len(types)})
	return c.OK()
}
