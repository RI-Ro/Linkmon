package server

import (
	"archive/zip"
	"bufio"
	"bytes"
	"context"
	"encoding/xml"
	"errors"
	"fmt"
	"html"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode"
	"unicode/utf16"
	"unicode/utf8"
)

// Извлечение текста из файлов для поиска по содержимому. Только stdlib (+ pdftotext из poppler-utils через os/exec).
// Все пределы жёсткие: размер исходного файла, число байт после распаковки (zip-bomb), длина текста, время и вывод pdftotext.

const (
	idxMaxFile      = 50 << 20  // файлы больше не индексируем (unsupported)
	idxMaxText      = 1 << 20   // сколько текста храним на файл
	idxZipBudget    = 128 << 20 // всего байт, которые разрешено распаковать из одного архива
	idxZipEntryMax  = 64 << 20  // и из одной записи архива
	idxZipMaxEntry  = 20000     // записей в архиве
	idxPdfTimeout   = 90 * time.Second
	idxPdfMaxPages  = "3000"
	idxTextReadSize = 8 << 20 // сколько байт простого текста читаем (до перекодировки/очистки)
)

var (
	errUnsupported = errors.New("тип файла не поддерживается")
	errPdfMissing  = errors.New("pdftotext не установлен (poppler-utils)")
	errFull        = errors.New("full") // служебная: текста уже достаточно, разбор можно прекращать
)

// pdfSem — не более одного процесса pdftotext на экземпляр приложения.
var pdfSem = make(chan struct{}, 1)

// textBuf собирает текст со сжатием пробелов и ограничением длины.
type textBuf struct {
	b     bytes.Buffer
	max   int
	space bool
}

func newTextBuf(max int) *textBuf { return &textBuf{max: max, space: true} }

// WriteString добавляет s; возвращает true, когда лимит достигнут.
func (t *textBuf) WriteString(s string) bool {
	for _, r := range s {
		if t.b.Len() >= t.max {
			return true
		}
		if r == 0 || r == utf8.RuneError || unicode.IsSpace(r) || unicode.IsControl(r) {
			if !t.space {
				t.b.WriteByte(' ')
				t.space = true
			}
			continue
		}
		t.b.WriteRune(r)
		t.space = false
	}
	return t.b.Len() >= t.max
}

func (t *textBuf) Space() {
	if !t.space && t.b.Len() < t.max {
		t.b.WriteByte(' ')
		t.space = true
	}
}

func (t *textBuf) String() string {
	s := strings.TrimSpace(t.b.String())
	if len(s) > t.max { // обрезаем по границе руны
		s = s[:t.max]
		for !utf8.ValidString(s) && len(s) > 0 {
			s = s[:len(s)-1]
		}
	}
	return s
}

// fileKind определяет способ извлечения по расширению и MIME-типу.
func fileKind(name, mime string) string {
	ext := strings.ToLower(filepath.Ext(name))
	switch ext {
	case ".txt", ".md", ".markdown", ".csv", ".tsv", ".json", ".log", ".yml", ".yaml", ".ini", ".conf", ".cfg", ".sql", ".tex", ".srt", ".vtt":
		return "text"
	case ".html", ".htm", ".xhtml":
		return "html"
	case ".xml", ".svg", ".fb2":
		return "xml"
	case ".rtf":
		return "rtf"
	case ".docx", ".dotx", ".docm":
		return "docx"
	case ".xlsx", ".xlsm", ".xltx":
		return "xlsx"
	case ".pptx", ".ppsx", ".potx", ".pptm":
		return "pptx"
	case ".odt", ".ods", ".odp", ".ott", ".ots", ".otp":
		return "odf"
	case ".pdf":
		return "pdf"
	}
	switch {
	case mime == "application/pdf":
		return "pdf"
	case mime == "text/html":
		return "html"
	case mime == "text/xml" || mime == "application/xml":
		return "xml"
	case mime == "text/rtf" || mime == "application/rtf":
		return "rtf"
	case mime == "application/json" || strings.HasPrefix(mime, "text/"):
		return "text"
	}
	return ""
}

// extractText возвращает очищенный текст файла (≤ idxMaxText). errUnsupported / errPdfMissing — это статус unsupported, а не сбой.
func extractText(ctx context.Context, path, name, mime string, size int64) (string, error) {
	kind := fileKind(name, mime)
	if kind == "" {
		return "", errUnsupported
	}
	if size > idxMaxFile {
		return "", fmt.Errorf("%w: файл больше %d МБ", errUnsupported, idxMaxFile>>20)
	}
	var out string
	var err error
	switch kind {
	case "pdf":
		out, err = extractPDF(ctx, path)
	case "docx", "xlsx", "pptx", "odf":
		out, err = extractZipDoc(path, kind)
	default:
		var f *os.File
		if f, err = os.Open(path); err != nil {
			return "", err
		}
		defer f.Close()
		raw, rerr := io.ReadAll(io.LimitReader(f, idxTextReadSize))
		if rerr != nil {
			return "", rerr
		}
		raw = decodeText(raw)
		switch kind {
		case "text":
			t := newTextBuf(idxMaxText)
			t.WriteString(string(raw))
			out = t.String()
		case "html":
			out = htmlToText(string(raw))
		case "xml":
			out, err = xmlToText(bytes.NewReader(raw), nil)
		case "rtf":
			out = rtfToText(raw)
		}
	}
	if err != nil {
		return "", err
	}
	return strings.ToValidUTF8(strings.ReplaceAll(out, "\x00", " "), " "), nil
}

// ---------------------------------------------------------------- кодировки

// decodeText приводит простой текст к UTF-8: BOM UTF-16/UTF-8, иначе валидный UTF-8 как есть, иначе windows-1251.
func decodeText(b []byte) []byte {
	if len(b) >= 2 && ((b[0] == 0xFF && b[1] == 0xFE) || (b[0] == 0xFE && b[1] == 0xFF)) {
		le := b[0] == 0xFF
		u := make([]uint16, 0, len(b)/2)
		for i := 2; i+1 < len(b); i += 2 {
			if le {
				u = append(u, uint16(b[i])|uint16(b[i+1])<<8)
			} else {
				u = append(u, uint16(b[i+1])|uint16(b[i])<<8)
			}
		}
		return []byte(string(utf16.Decode(u)))
	}
	b = bytes.TrimPrefix(b, []byte{0xEF, 0xBB, 0xBF})
	// файл, обрезанный лимитом чтения посреди многобайтового символа, всё равно считается UTF-8
	for k := 0; k < 4 && k <= len(b); k++ {
		if utf8.Valid(b[:len(b)-k]) {
			return b
		}
	}
	return []byte(cp1251(b))
}

func cp1251(b []byte) string {
	var sb strings.Builder
	sb.Grow(len(b) * 2)
	for _, c := range b {
		switch {
		case c < 0x80:
			sb.WriteByte(c)
		case c >= 0xC0:
			sb.WriteRune(rune(c) - 0xC0 + 0x0410)
		case c == 0xA8:
			sb.WriteRune('Ё')
		case c == 0xB8:
			sb.WriteRune('ё')
		case c == 0x96 || c == 0x97:
			sb.WriteRune('–')
		default:
			sb.WriteByte(' ')
		}
	}
	return sb.String()
}

// ---------------------------------------------------------------- html / xml / rtf

var (
	reScript = regexp.MustCompile(`(?is)<(script|style|head)\b.*?</(script|style|head)\s*>`)
	reComm   = regexp.MustCompile(`(?s)<!--.*?-->`)
	reTag    = regexp.MustCompile(`(?s)<[^>]*>`)
)

func htmlToText(s string) string {
	s = reComm.ReplaceAllString(s, " ")
	s = reScript.ReplaceAllString(s, " ")
	s = reTag.ReplaceAllString(s, " ")
	t := newTextBuf(idxMaxText)
	t.WriteString(html.UnescapeString(s))
	return t.String()
}

// xmlToText потоково собирает текстовые узлы. breaks — имена элементов, после которых ставится пробел (абзацы);
// only — если задан, берутся только узлы внутри этих элементов.
func xmlToText(r io.Reader, only map[string]bool) (string, error) {
	d := xml.NewDecoder(r)
	d.Strict = false
	d.Entity = xml.HTMLEntity
	d.CharsetReader = func(_ string, in io.Reader) (io.Reader, error) { return in, nil }
	t := newTextBuf(idxMaxText)
	depth := 0 // глубина внутри элементов из only
	for {
		tok, err := d.Token()
		if err == io.EOF {
			break
		}
		if err != nil {
			if errors.Is(err, errZipLimit) {
				return "", err
			}
			if t.b.Len() > 0 { // битый хвост документа — берём то, что успели
				break
			}
			return "", err
		}
		switch v := tok.(type) {
		case xml.StartElement:
			if only != nil && only[v.Name.Local] {
				depth++
			}
			switch v.Name.Local {
			case "tab", "br", "line-break", "tab-stop":
				t.Space()
			}
		case xml.EndElement:
			if only != nil && only[v.Name.Local] {
				depth--
			}
			switch v.Name.Local {
			case "p", "h", "tr", "row", "si", "is", "c", "tc", "title", "para", "br":
				t.Space()
			}
		case xml.CharData:
			if only == nil || depth > 0 {
				if t.WriteString(string(v)) {
					return t.String(), nil
				}
			}
		}
	}
	return t.String(), nil
}

var rtfSkip = map[string]bool{"fonttbl": true, "colortbl": true, "stylesheet": true, "info": true, "pict": true, "object": true, "header": true,
	"footer": true, "themedata": true, "colorschememapping": true, "datastore": true, "latentstyles": true, "listtable": true,
	"listoverridetable": true, "rsidtbl": true, "generator": true, "fldinst": true, "xmlnstbl": true, "wgrffmtfilter": true}

// rtfToText — упрощённый разбор RTF: управляющие слова, \'hh (windows-1251), \uN, пропуск служебных групп.
func rtfToText(b []byte) string {
	t := newTextBuf(idxMaxText)
	type st struct{ skip bool }
	stack := []st{{}}
	skip := func() bool { return stack[len(stack)-1].skip }
	var runes []rune
	flush := func() {
		if len(runes) > 0 {
			t.WriteString(string(runes))
			runes = runes[:0]
		}
	}
	uc := 1
	for i := 0; i < len(b) && t.b.Len() < t.max; i++ {
		c := b[i]
		switch c {
		case '{':
			stack = append(stack, stack[len(stack)-1])
		case '}':
			if len(stack) > 1 {
				stack = stack[:len(stack)-1]
			}
		case '\\':
			i++
			if i >= len(b) {
				break
			}
			c = b[i]
			switch {
			case c == '\'' && i+2 < len(b):
				if v, err := strconv.ParseUint(string(b[i+1:i+3]), 16, 8); err == nil && !skip() {
					runes = append(runes, []rune(cp1251([]byte{byte(v)}))...)
				}
				i += 2
			case c == '*':
				stack[len(stack)-1].skip = true
			case c == '\\' || c == '{' || c == '}':
				if !skip() {
					runes = append(runes, rune(c))
				}
			case c == '~':
				runes = append(runes, ' ')
			case (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'):
				j := i
				for j < len(b) && ((b[j] >= 'a' && b[j] <= 'z') || (b[j] >= 'A' && b[j] <= 'Z')) {
					j++
				}
				word := string(b[i:j])
				k := j
				if k < len(b) && (b[k] == '-' || (b[k] >= '0' && b[k] <= '9')) {
					k++
					for k < len(b) && b[k] >= '0' && b[k] <= '9' {
						k++
					}
				}
				num := string(b[j:k])
				if k < len(b) && b[k] == ' ' {
					k++
				}
				i = k - 1
				switch {
				case rtfSkip[word]:
					stack[len(stack)-1].skip = true
				case word == "par" || word == "line" || word == "tab" || word == "cell" || word == "row" || word == "sect" || word == "page":
					if !skip() {
						flush()
						t.Space()
					}
				case word == "uc":
					if n, err := strconv.Atoi(num); err == nil {
						uc = n
					}
				case word == "u":
					if n, err := strconv.Atoi(num); err == nil && !skip() {
						if n < 0 {
							n += 65536
						}
						runes = append(runes, rune(n))
						for s := 0; s < uc && i+1 < len(b); s++ { // пропускаем ASCII-замену
							if b[i+1] == '\\' && i+4 < len(b) && b[i+2] == '\'' {
								i += 4
							} else if b[i+1] != '\\' && b[i+1] != '{' && b[i+1] != '}' {
								i++
							}
						}
					}
				}
			}
		case '\r', '\n':
		default:
			if !skip() {
				runes = append(runes, rune(c))
				if c >= 0x80 { // сырые 8-битные символы внутри RTF — кодовая страница документа (чаще 1251)
					runes[len(runes)-1] = []rune(cp1251([]byte{c}))[0]
				}
			}
		}
		if len(runes) > 512 {
			flush()
		}
	}
	flush()
	return t.String()
}

// ---------------------------------------------------------------- zip-контейнеры (OOXML, ODF)

var errZipLimit = errors.New("архив слишком велик после распаковки (возможна zip-бомба)")

// budgetReader не отдаёт больше max байт суммарно (общий бюджет на все записи архива).
type budgetReader struct {
	r      io.Reader
	budget *int64
	max    int64
	n      int64
}

func (b *budgetReader) Read(p []byte) (int, error) {
	if b.n >= b.max || *b.budget <= 0 {
		return 0, errZipLimit
	}
	if lim := b.max - b.n; int64(len(p)) > lim {
		p = p[:lim]
	}
	if int64(len(p)) > *b.budget {
		p = p[:*b.budget]
	}
	n, err := b.r.Read(p)
	b.n += int64(n)
	*b.budget -= int64(n)
	return n, err
}

var reNum = regexp.MustCompile(`(\d+)\.xml$`)

func extractZipDoc(path, kind string) (string, error) {
	zr, err := zip.OpenReader(path)
	if err != nil {
		return "", fmt.Errorf("не удалось открыть как zip: %w", err)
	}
	defer zr.Close()
	if len(zr.File) > idxZipMaxEntry {
		return "", fmt.Errorf("слишком много записей в архиве (%d)", len(zr.File))
	}
	byName := map[string]*zip.File{}
	for _, f := range zr.File {
		byName[f.Name] = f
	}
	budget := int64(idxZipBudget)
	open := func(f *zip.File) (io.Reader, io.Closer, error) {
		rc, err := f.Open()
		if err != nil {
			return nil, nil, err
		}
		return &budgetReader{r: rc, budget: &budget, max: idxZipEntryMax}, rc, nil
	}
	var names []string
	var only map[string]bool
	pick := func(re *regexp.Regexp) {
		for n := range byName {
			if re.MatchString(n) {
				names = append(names, n)
			}
		}
		sort.Slice(names, func(i, j int) bool {
			return numKey(names[i]) < numKey(names[j]) || (numKey(names[i]) == numKey(names[j]) && names[i] < names[j])
		})
	}
	switch kind {
	case "docx":
		only = map[string]bool{"t": true}
		pick(regexp.MustCompile(`^word/(document|footnotes|endnotes|header\d*|footer\d*|comments)\.xml$`))
		// document.xml должен идти первым
		sort.SliceStable(names, func(i, j int) bool { return names[i] == "word/document.xml" && names[j] != "word/document.xml" })
	case "xlsx":
		only = map[string]bool{"t": true}
		pick(regexp.MustCompile(`^xl/(sharedStrings\.xml|worksheets/sheet\d+\.xml)$`))
		sort.SliceStable(names, func(i, j int) bool { return names[i] == "xl/sharedStrings.xml" && names[j] != "xl/sharedStrings.xml" })
	case "pptx":
		only = map[string]bool{"t": true}
		pick(regexp.MustCompile(`^ppt/(slides/slide\d+|notesSlides/notesSlide\d+)\.xml$`))
	case "odf":
		pick(regexp.MustCompile(`^content\.xml$`))
		only = nil
	}
	if len(names) == 0 {
		return "", errors.New("в документе не найдено текстовых частей")
	}
	total := newTextBuf(idxMaxText)
	for _, n := range names {
		r, cl, err := open(byName[n])
		if err != nil {
			return "", err
		}
		var txt string
		if kind == "odf" && n == "content.xml" {
			txt, err = odfText(r)
		} else if kind == "odf" {
			txt, err = xmlToText(r, nil)
		} else {
			txt, err = xmlToText(r, only)
		}
		cl.Close()
		if err != nil {
			return "", err
		}
		if total.WriteString(txt) {
			break
		}
		total.Space()
	}
	return total.String(), nil
}

// odfText — content.xml: текст внутри text:p / text:h / text:span и пр., без office:automatic-styles и office:scripts.
func odfText(r io.Reader) (string, error) {
	d := xml.NewDecoder(r)
	d.Strict = false
	t := newTextBuf(idxMaxText)
	skip := 0
	for {
		tok, err := d.Token()
		if err == io.EOF {
			break
		}
		if err != nil {
			if errors.Is(err, errZipLimit) {
				return "", err
			}
			if t.b.Len() > 0 {
				break
			}
			return "", err
		}
		switch v := tok.(type) {
		case xml.StartElement:
			switch v.Name.Local {
			case "automatic-styles", "scripts", "font-face-decls", "styles":
				skip++
			case "tab", "line-break", "s":
				t.Space()
			}
		case xml.EndElement:
			switch v.Name.Local {
			case "automatic-styles", "scripts", "font-face-decls", "styles":
				skip--
			case "p", "h", "table-cell", "list-item":
				t.Space()
			}
		case xml.CharData:
			if skip == 0 && t.WriteString(string(v)) {
				return t.String(), nil
			}
		}
	}
	return t.String(), nil
}

func numKey(n string) int {
	if m := reNum.FindStringSubmatch(n); m != nil {
		v, _ := strconv.Atoi(m[1])
		return v
	}
	return 0
}

// ---------------------------------------------------------------- pdf

func pdfAvailable() bool {
	_, err := exec.LookPath("pdftotext")
	return err == nil
}

// extractPDF запускает pdftotext с таймаутом; вывод читается не более idxMaxText*2 байт, затем процесс прерывается.
func extractPDF(ctx context.Context, path string) (string, error) {
	bin, err := exec.LookPath("pdftotext")
	if err != nil {
		return "", errPdfMissing
	}
	select {
	case pdfSem <- struct{}{}:
		defer func() { <-pdfSem }()
	case <-ctx.Done():
		return "", ctx.Err()
	}
	cctx, cancel := context.WithTimeout(ctx, idxPdfTimeout)
	defer cancel()
	cmd := exec.CommandContext(cctx, bin, "-q", "-enc", "UTF-8", "-nopgbrk", "-l", idxPdfMaxPages, path, "-")
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return "", err
	}
	var stderr bytes.Buffer
	cmd.Stderr = &limitedWriter{w: &stderr, n: 2048}
	if err := cmd.Start(); err != nil {
		return "", err
	}
	t := newTextBuf(idxMaxText)
	br := bufio.NewReaderSize(stdout, 64<<10)
	full := false
	for !full {
		r, _, rerr := br.ReadRune()
		if rerr != nil {
			break
		}
		full = t.WriteString(string(r))
	}
	if full {
		cancel() // текста достаточно: остальное не нужно
	} else {
		io.Copy(io.Discard, stdout)
	}
	werr := cmd.Wait()
	if full {
		return t.String(), nil
	}
	if werr != nil {
		if errors.Is(cctx.Err(), context.DeadlineExceeded) {
			return "", fmt.Errorf("pdftotext: превышено время %s", idxPdfTimeout)
		}
		msg := strings.TrimSpace(stderr.String())
		if msg == "" {
			msg = werr.Error()
		}
		return "", fmt.Errorf("pdftotext: %s", msg)
	}
	return t.String(), nil
}

type limitedWriter struct {
	w *bytes.Buffer
	n int
}

func (l *limitedWriter) Write(p []byte) (int, error) {
	if room := l.n - l.w.Len(); room > 0 {
		if len(p) > room {
			l.w.Write(p[:room])
		} else {
			l.w.Write(p)
		}
	}
	return len(p), nil
}
