package server

// seedAnalytics — демо-данные аналитики за последние 30 дней: просмотры и читатели новостей, активность пользователей,
// визиты, поисковые запросы (с нулевой выдачей) и дневные агрегаты. Вызывается из seed.go после остальных демо-данных.
func (s *Server) seedAnalytics(d sd) {
	// читатели новостей: у каждой опубликованной новости 20–80% сотрудников
	d.exec(`INSERT INTO news_views (news_id, user_id, viewed_at)
		SELECT n.id, u.id, greatest(n.published_at, now() - interval '30 days') + random() * (now() - greatest(n.published_at, now() - interval '30 days'))
		FROM news n CROSS JOIN users u WHERE n.status = 'published' AND NOT u.blocked AND u.id <> n.author_id
			AND random() + u.id * 0 < 0.2 + 0.6 * ((n.id * 7919) % 100) / 100.0 ON CONFLICT DO NOTHING`)
	d.exec(`UPDATE news n SET uniq_views = c.c, views_count = greatest(n.views_count, (c.c * 6)::int)
		FROM (SELECT news_id, count(*)::int c FROM news_views GROUP BY news_id) c WHERE c.news_id = n.id`)
	d.exec(`INSERT INTO news_dept_views (news_id, dept_id, viewers)
		SELECT v.news_id, coalesce(u.department_id, 0), count(*) FROM news_views v JOIN users u ON u.id = v.user_id GROUP BY 1, 2`)
	d.exec(`INSERT INTO news_stats_daily (news_id, day, views, uniq_views)
		SELECT news_id, viewed_at::date, (count(*) * 6)::int, count(*)::int FROM news_views GROUP BY 1, 2
		ON CONFLICT (news_id, day) DO UPDATE SET views = EXCLUDED.views, uniq_views = EXCLUDED.uniq_views`)

	// активность пользователей по дням (в будни выше)
	d.exec(`INSERT INTO user_daily_activity (day, user_id, hits)
		SELECT g::date, u.id, 1 + (random() * 25)::int FROM generate_series(current_date - 29, current_date - 1, interval '1 day') g, users u
		WHERE NOT u.blocked AND random() < CASE WHEN extract(isodow FROM g) >= 6 THEN 0.15 ELSE 0.75 END`)
	d.exec(`INSERT INTO stats_daily (day, metric, dim, dc, value)
		SELECT day, 'dau', '', '', count(*) FROM user_daily_activity GROUP BY day
		UNION ALL SELECT g::date, 'wau', '', '', (SELECT count(DISTINCT user_id) FROM user_daily_activity a WHERE a.day > g::date - 7 AND a.day <= g::date)
			FROM generate_series(current_date - 29, current_date - 1, interval '1 day') g
		UNION ALL SELECT g::date, 'mau', '', '', (SELECT count(DISTINCT user_id) FROM user_daily_activity a WHERE a.day > g::date - 30 AND a.day <= g::date)
			FROM generate_series(current_date - 29, current_date - 1, interval '1 day') g
		UNION ALL SELECT day, 'visits', '', '', (count(*) * 1.3)::bigint FROM user_daily_activity GROUP BY day
		UNION ALL SELECT day, 'news_views', '', '', sum(views) FROM news_stats_daily GROUP BY day
		UNION ALL SELECT day, 'news_uniq', '', '', sum(uniq_views) FROM news_stats_daily GROUP BY day
		ON CONFLICT DO NOTHING`)
	d.exec(`INSERT INTO stats_daily (day, metric, dim, dc, value)
		SELECT a.day, 'visit_hour', t.h::text, '', (count(*) * t.w / 10.0)::bigint
		FROM user_daily_activity a, unnest(ARRAY[8,9,10,11,12,13,14,15,16,17,18], ARRAY[6,16,20,14,8,10,12,12,10,6,3]) AS t(h, w)
		GROUP BY a.day, t.h, t.w ON CONFLICT DO NOTHING`)
	d.exec(`INSERT INTO stats_daily (day, metric, dim, dc, value)
		SELECT a.day, 'pv', sec, '', (count(*) * w)::bigint FROM user_daily_activity a,
			unnest(ARRAY['news','chat','groups','calendar','people','documents','ideas'], ARRAY[6,4,2,1,2,1,1]) AS t(sec, w) GROUP BY a.day, sec, w ON CONFLICT DO NOTHING`)
	d.exec(`INSERT INTO stats_daily (day, metric, dim, dc, value)
		SELECT a.day, 'device', t.dv, '', (count(*) * t.w / 10.0)::bigint FROM user_daily_activity a,
			unnest(ARRAY['desktop','mobile','tablet'], ARRAY[7,2.6,0.4]) AS t(dv, w) GROUP BY a.day, t.dv, t.w ON CONFLICT DO NOTHING`)

	// поисковые запросы: часть — без результатов
	d.exec(`INSERT INTO search_log (id, user_id, scope, query, normalized, results_count, took_ms, clicked, created_at)
		SELECT 900000000000 + g, u.id, 'global', q.t, q.t, q.n, 5 + (g % 40), q.n > 0 AND g % 3 = 0, now() - random() * 29 * interval '1 day'
		FROM generate_series(1, 400) g
		JOIN LATERAL (SELECT id FROM users ORDER BY id OFFSET (g % 30) LIMIT 1) u ON true
		JOIN (VALUES (1,'отпуск',12),(2,'график отпусков',5),(3,'справка 2-ндфл',0),(4,'впн',0),(5,'пропуск',7),(6,'дмс',0),
			(7,'расписание автобусов',0),(8,'корпоратив',9),(9,'оформить командировку',3),(10,'парковка',0)) q(k, t, n) ON q.k = 1 + (g * 7) % 10`)
	d.exec(`INSERT INTO stats_daily (day, metric, dim, dc, value)
		SELECT created_at::date, 'search_total', scope, '', count(*) FROM search_log GROUP BY 1, 3
		UNION ALL SELECT created_at::date, 'search_zero', scope, '', count(*) FROM search_log WHERE results_count = 0 GROUP BY 1, 3
		UNION ALL SELECT created_at::date, 'search_clicked', scope, '', count(*) FROM search_log WHERE clicked GROUP BY 1, 3
		UNION ALL SELECT created_at::date, 'search_ms', scope, '', sum(took_ms) FROM search_log GROUP BY 1, 3
		ON CONFLICT DO NOTHING`)
	d.exec(`INSERT INTO search_daily (day, scope, normalized, searches, zero, noclick, clicks, users, took_ms, sample)
		SELECT created_at::date, scope, normalized, count(*), count(*) FILTER (WHERE results_count = 0), count(*) FILTER (WHERE results_count > 0 AND NOT clicked),
			count(*) FILTER (WHERE clicked), count(DISTINCT user_id), sum(took_ms), min(query)
		FROM search_log GROUP BY 1, 2, 3 ON CONFLICT DO NOTHING`)
}
