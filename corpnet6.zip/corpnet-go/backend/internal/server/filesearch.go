package server

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

// Поиск по содержимому файлов (миграция 010_file_search.sql).
//
//	загрузка файла ──(триггер files_enqueue_text)──► file_texts(pending)
//	воркеры (любое число экземпляров/ЦОДов) ──FOR UPDATE SKIP LOCKED──► extractText ──► file_texts(done, text, tsv)
//	GET /api/search → searchFileContent: кандидаты из GIN (≤N) → фильтр прав (тот же SQL, что у serveFile) → сниппеты ts_headline
//
// Права проверяются ДО генерации сниппетов, поэтому текст недоступного файла наружу не попадает.

const (
	fidxMaxAttempts = 4
	fidxLease       = 10 * time.Minute // аренда задачи: если экземпляр упал, через это время задачу заберёт другой
	fidxRareCap     = 2000             // до скольких совпадений слово считается «редким» (все кандидаты берутся из GIN целиком)
	fidxRound       = 200              // размер пачки кандидатов для частых слов (обход от новых файлов к старым)
	fidxMaxRounds   = 12
	// маркеры подсветки в сниппете (символы Private Use): клиент разбирает их сам и рисует <mark>, HTML не приходит
	hlStart, hlStop = "\xee\x80\x80", "\xee\x80\x81" // U+E000, U+E001
)

func (s *Server) registerFileSearch(m *http.ServeMux) {
	const U, A = "user", "admin"
	m.HandleFunc("GET /api/search/files", s.h(U, s.searchFilesAPI))
	m.HandleFunc("GET /api/admin/file-index", s.h(A, s.adminFileIndex))
	m.HandleFunc("POST /api/admin/file-index/reindex", s.h(A, s.adminFileReindex))
}

// ---------------------------------------------------------------- фоновый индексатор

// fileIndexLoop запускает воркеры извлечения текста. FILE_INDEX=off — отключить на этом экземпляре,
// FILE_INDEX_WORKERS — число параллельных воркеров (по умолчанию 2; pdftotext при этом всё равно не более одного процесса).
func (s *Server) fileIndexLoop(ctx context.Context) {
	if v := strings.ToLower(os.Getenv("FILE_INDEX")); v == "off" || v == "false" || v == "0" {
		return
	}
	n := min(max(envInt("FILE_INDEX_WORKERS", 2), 1), 4)
	for i := 0; i < n; i++ {
		go s.fileIndexWorker(ctx, i)
	}
	go s.every(ctx, 10*time.Minute, s.fileIndexBackfill)
}

type idxJob struct {
	ID       int64
	Attempts int
	Storage  string
	Name     string
	Mime     string
	Size     int64
}

func (s *Server) fileIndexWorker(ctx context.Context, n int) {
	idle := 3 * time.Second
	select { // небольшой разнос по времени после старта, чтобы не мешать прогреву
	case <-time.After(time.Duration(5+n*2) * time.Second):
	case <-ctx.Done():
		return
	}
	for ctx.Err() == nil {
		jobs, err := s.claimIndexJobs(ctx, 4)
		if err != nil || len(jobs) == 0 {
			if err != nil {
				s.log.Warn("file index claim", "err", err)
			}
			select {
			case <-time.After(idle):
			case <-ctx.Done():
				return
			}
			if idle < 30*time.Second {
				idle += idle / 2
			}
			continue
		}
		idle = 3 * time.Second
		for _, j := range jobs {
			s.processIndexJob(ctx, j)
			select { // не занимаем диск/БД подряд: пользовательские запросы важнее
			case <-time.After(30 * time.Millisecond):
			case <-ctx.Done():
				return
			}
		}
	}
}

// claimIndexJobs атомарно берёт пачку задач (SKIP LOCKED) и ставит на них аренду; повторно задачу не получит никто, пока аренда не истечёт.
func (s *Server) claimIndexJobs(ctx context.Context, limit int) ([]idxJob, error) {
	rows, err := s.db.Query(ctx, `WITH c AS (
			SELECT file_id FROM file_texts WHERE status = 'pending' AND next_try_at <= now() AND (locked_until IS NULL OR locked_until < now())
			ORDER BY next_try_at, file_id LIMIT $1 FOR UPDATE SKIP LOCKED)
		UPDATE file_texts t SET locked_until = now() + $2::bigint * interval '1 second', attempts = t.attempts + 1
		FROM c JOIN files f ON f.id = c.file_id WHERE t.file_id = c.file_id
		RETURNING t.file_id, t.attempts, f.storage, f.name, f.mime, f.size`, limit, int64(fidxLease/time.Second))
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []idxJob
	for rows.Next() {
		var j idxJob
		if err := rows.Scan(&j.ID, &j.Attempts, &j.Storage, &j.Name, &j.Mime, &j.Size); err != nil {
			return nil, err
		}
		out = append(out, j)
	}
	return out, rows.Err()
}

func (s *Server) processIndexJob(ctx context.Context, j idxJob) {
	jctx, cancel := context.WithTimeout(ctx, 4*time.Minute)
	defer cancel()
	text, err := s.extractFile(jctx, j)
	switch {
	case err == nil:
		s.finishIndexJob(ctx, j, text)
	case errors.Is(err, errUnsupported) || errors.Is(err, errPdfMissing):
		msg := err.Error()
		if errors.Is(err, errPdfMissing) {
			msg = errPdfMissing.Error()
		}
		s.db.Exec(ctx, `UPDATE file_texts SET status = 'unsupported', text = '', tsv = NULL, size = 0, error = $2, locked_until = NULL, extracted_at = now() WHERE file_id = $1`, j.ID, cut(msg, 300))
	case ctx.Err() != nil:
		// остановка сервера: аренда истечёт сама
	default:
		s.failIndexJob(ctx, j, err)
	}
}

func cut(s string, n int) string {
	if r := []rune(s); len(r) > n {
		return string(r[:n])
	}
	return s
}

func (s *Server) extractFile(ctx context.Context, j idxJob) (string, error) {
	if fileKind(j.Name, j.Mime) == "" {
		return "", errUnsupported
	}
	if j.Storage == "" || strings.ContainsAny(j.Storage, "/\\") {
		return "", errUnsupported
	}
	if fileKind(j.Name, j.Mime) == "pdf" && !pdfAvailable() {
		return "", errPdfMissing
	}
	if err := s.ensureLocal(ctx, false, j.Storage); err != nil { // файл мог быть загружен в другом ЦОДе
		return "", err
	}
	p := filepath.Join(s.dir(false), path.Base(j.Storage))
	st, err := os.Stat(p)
	if err != nil {
		return "", fmt.Errorf("файл не найден на диске: %w", err)
	}
	return extractText(ctx, p, j.Name, j.Mime, st.Size())
}

func (s *Server) finishIndexJob(ctx context.Context, j idxJob, text string) {
	if text == "" {
		s.db.Exec(ctx, `UPDATE file_texts SET status = 'done', text = '', tsv = NULL, size = 0, error = '', locked_until = NULL, extracted_at = now() WHERE file_id = $1`, j.ID)
		return
	}
	var err error
	for try := 0; try < 4; try++ {
		_, err = s.db.Exec(ctx, `UPDATE file_texts SET status = 'done', text = $2, tsv = to_tsvector('simple', $2), size = octet_length($2), error = '',
			locked_until = NULL, extracted_at = now() WHERE file_id = $1`, j.ID, text)
		if err == nil || !strings.Contains(err.Error(), "too long") { // tsvector ≤ 1 МБ: при переполнении сокращаем текст
			break
		}
		text = cut(text, len([]rune(text))/2)
	}
	if err != nil {
		s.failIndexJob(ctx, j, err)
	}
}

// failIndexJob — ретрай с растущей паузой (2, 8, 18 мин …), после fidxMaxAttempts попыток статус failed.
func (s *Server) failIndexJob(ctx context.Context, j idxJob, cause error) {
	msg := cut(cause.Error(), 500)
	if j.Attempts >= fidxMaxAttempts {
		s.db.Exec(ctx, `UPDATE file_texts SET status = 'failed', error = $2, locked_until = NULL WHERE file_id = $1`, j.ID, msg)
		s.log.Warn("file index failed", "file", j.ID, "name", j.Name, "err", msg)
		return
	}
	delay := int64(j.Attempts*j.Attempts) * 120
	s.db.Exec(ctx, `UPDATE file_texts SET error = $2, locked_until = NULL, next_try_at = now() + $3::bigint * interval '1 second' WHERE file_id = $1`, j.ID, msg, delay)
}

// fileIndexBackfill — файлы, которых ещё нет в file_texts (загружены до миграции или в обход триггера): ставит в очередь пачками.
func (s *Server) fileIndexBackfill(ctx context.Context) {
	if !s.lock(ctx, "fileindex:backfill", 9*time.Minute) {
		return
	}
	defer s.unlock(ctx, "fileindex:backfill")
	for i := 0; i < 40 && ctx.Err() == nil; i++ {
		n, err := s.enqueueMissingFiles(ctx, 5000)
		if err != nil {
			s.log.Warn("file index backfill", "err", err)
			return
		}
		if n < 5000 {
			return
		}
	}
}

func (s *Server) enqueueMissingFiles(ctx context.Context, limit int) (int64, error) {
	tag, err := s.db.Exec(ctx, `INSERT INTO file_texts (file_id, status)
		SELECT f.id, CASE WHEN f.mime LIKE 'image/%' OR f.mime LIKE 'video/%' OR f.mime LIKE 'audio/%' THEN 'unsupported' ELSE 'pending' END
		FROM files f WHERE f.storage <> '' AND f.external_url = '' AND NOT EXISTS (SELECT 1 FROM file_texts t WHERE t.file_id = f.id)
		ORDER BY f.id LIMIT $1 ON CONFLICT (file_id) DO NOTHING`, limit)
	return tag.RowsAffected(), err
}

// ---------------------------------------------------------------- поиск

// fileSearchExtraSQL — дополнительные ограничения ТОЛЬКО для поиска (строже, чем скачивание по прямой ссылке):
// вложения новостей — только видимых пользователю новостей; комментариев — только неудалённых; чатов — только пока
// сообщение с файлом не удалено и пользователь участник чата. Параметры $2 (пользователь), $4 (админ).
func fileSearchExtraSQL(f string) string {
	return strings.ReplaceAll(`(CASE {f}.context
		WHEN 'news' THEN ({f}.owner_id = $2 OR $4 OR EXISTS (SELECT 1 FROM news_files nf JOIN news n ON n.id = nf.news_id WHERE nf.file_id = {f}.id AND `+visibleNow+`))
		WHEN 'comment' THEN EXISTS (SELECT 1 FROM comment_files cf JOIN comments cx ON cx.id = cf.comment_id WHERE cf.file_id = {f}.id AND cx.deleted_at IS NULL)
		WHEN 'chat' THEN EXISTS (SELECT 1 FROM messages mx JOIN chat_members cmx ON cmx.chat_id = mx.chat_id AND cmx.user_id = $2 WHERE mx.file_id = {f}.id AND mx.deleted_at IS NULL)
		ELSE true END)`, "{f}", f)
}

// visibleFileIDs оставляет из кандидатов те, что пользователь вправе видеть (новые — первыми), не более limit.
func (s *Server) visibleFileIDs(ctx context.Context, u *User, ids []int64, limit int) ([]int64, error) {
	if len(ids) == 0 {
		return nil, nil
	}
	rows, err := s.ro.Query(ctx, `SELECT f.id FROM files f WHERE f.id = ANY($1::bigint[]) AND f.external_url = ''
		AND (`+fileBaseOKSQL("f")+` OR `+fileViaNewsSQL("f")+`) AND `+fileSearchExtraSQL("f")+` ORDER BY f.id DESC LIMIT $5::int`,
		ids, u.ID, u.Dept, u.IsAdmin(), limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		out = append(out, id)
	}
	return out, rows.Err()
}

// fileHit — результат поиска по содержимому.
type fileHit struct {
	ID        int64     `json:"id"`
	Name      string    `json:"name"`
	Mime      string    `json:"mime"`
	Size      int64     `json:"size"`
	CreatedAt time.Time `json:"created_at"`
	Source    string    `json:"source"`  // documents / news / comment / chat / learning
	Origin    string    `json:"origin"`  // человекочитаемое «откуда»: папка, заголовок новости …
	Link      string    `json:"link"`    // страница-источник
	Snippet   string    `json:"snippet"` // фрагмент с маркерами подсветки hlStart/hlStop
}

// searchFileContent ищет по содержимому файлов, доступных пользователю. Не более limit результатов.
//
//  1. Редкое слово (≤ fidxRareCap совпадений в GIN): все кандидаты берутся одним запросом к индексу.
//  2. Частое слово: обход от новых файлов к старым пачками по fidxRound (индекс GIN намеренно не используется:
//     `tsv || ”` — совпадений много, выгоднее идти по первичному ключу и остановиться, набрав limit видимых).
//  3. В обоих случаях сначала фильтр прав по пачке кандидатов, и только потом метаданные и ts_headline — для ≤ limit файлов.
func (s *Server) searchFileContent(ctx context.Context, u *User, q string, limit int) ([]fileHit, error) {
	ts := tsPrefixQuery(q)
	if ts == "" || limit <= 0 {
		return []fileHit{}, nil
	}
	var cand []int64
	rows, err := s.ro.Query(ctx, `SELECT file_id FROM file_texts WHERE tsv @@ to_tsquery('simple', $1) LIMIT $2::int`, ts, fidxRareCap+1)
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			rows.Close()
			return nil, err
		}
		cand = append(cand, id)
	}
	rows.Close()
	if err := rows.Err(); err != nil {
		return nil, err
	}
	var ids []int64
	if len(cand) <= fidxRareCap {
		if ids, err = s.visibleFileIDs(ctx, u, cand, limit); err != nil {
			return nil, err
		}
	} else {
		cursor := int64(1) << 62
		for round := 0; round < fidxMaxRounds && len(ids) < limit; round++ {
			batch := make([]int64, 0, fidxRound)
			br, err := s.ro.Query(ctx, `SELECT file_id FROM file_texts WHERE (tsv || ''::tsvector) @@ to_tsquery('simple', $1) AND file_id < $2
				ORDER BY file_id DESC LIMIT $3::int`, ts, cursor, fidxRound)
			if err != nil {
				return nil, err
			}
			for br.Next() {
				var id int64
				if err := br.Scan(&id); err != nil {
					br.Close()
					return nil, err
				}
				batch = append(batch, id)
			}
			br.Close()
			if err := br.Err(); err != nil {
				return nil, err
			}
			if len(batch) == 0 {
				break
			}
			vis, err := s.visibleFileIDs(ctx, u, batch, limit-len(ids))
			if err != nil {
				return nil, err
			}
			ids = append(ids, vis...)
			if len(batch) < fidxRound {
				break
			}
			cursor = batch[len(batch)-1]
		}
	}
	if len(ids) == 0 {
		return []fileHit{}, nil
	}
	return s.fileHits(ctx, ids, ts, searchTokens(q))
}

// fileHits — метаданные, источник и сниппеты для уже отфильтрованных по правам файлов.
func (s *Server) fileHits(ctx context.Context, ids []int64, ts string, toks []string) ([]fileHit, error) {
	rows, err := s.ro.Query(ctx, `SELECT f.id, f.name, f.mime, f.size, f.created_at, f.context,
			coalesce(o.label, ''), coalesce(o.link, '')
		FROM files f LEFT JOIN LATERAL (
			SELECT CASE f.context
				WHEN 'folder' THEN (SELECT fo.name || ' (' || CASE fo.kind WHEN 'documents' THEN 'Документы' WHEN 'photos' THEN 'Фотогалерея' ELSE 'Видео' END || ')' FROM folders fo WHERE fo.id = f.folder_id)
				WHEN 'news' THEN (SELECT 'Новость: ' || n.title FROM news_files nf JOIN news n ON n.id = nf.news_id WHERE nf.file_id = f.id ORDER BY n.id DESC LIMIT 1)
				WHEN 'comment' THEN (SELECT CASE cm.entity_type
						WHEN 'news' THEN 'Комментарий к новости: ' || coalesce((SELECT title FROM news WHERE id = cm.entity_id), '')
						WHEN 'idea' THEN 'Комментарий к идее: ' || coalesce((SELECT title FROM ideas WHERE id = cm.entity_id), '')
						ELSE 'Комментарий в группе: ' || coalesce((SELECT g.name FROM group_posts gp JOIN user_groups g ON g.id = gp.group_id WHERE gp.id = cm.entity_id), '') END
					FROM comment_files cf JOIN comments cm ON cm.id = cf.comment_id WHERE cf.file_id = f.id AND cm.deleted_at IS NULL LIMIT 1)
				WHEN 'chat' THEN (SELECT 'Чат: ' || CASE WHEN c.kind = 'direct' THEN 'личная переписка' ELSE coalesce(nullif(c.title, ''), 'группа') END
					FROM messages m JOIN chats c ON c.id = m.chat_id WHERE m.file_id = f.id AND m.deleted_at IS NULL LIMIT 1)
				WHEN 'learning' THEN (SELECT 'Обучение: ' || i.title FROM learn_item_files lf JOIN learn_items i ON i.id = lf.item_id WHERE lf.file_id = f.id LIMIT 1)
			END AS label,
			CASE f.context
				WHEN 'folder' THEN (SELECT '/' || fo.kind || '?folder=' || fo.id FROM folders fo WHERE fo.id = f.folder_id)
				WHEN 'news' THEN (SELECT '/news/' || n.id FROM news_files nf JOIN news n ON n.id = nf.news_id WHERE nf.file_id = f.id ORDER BY n.id DESC LIMIT 1)
				WHEN 'comment' THEN (SELECT CASE cm.entity_type WHEN 'news' THEN '/news/' || cm.entity_id WHEN 'idea' THEN '/ideas/' || cm.entity_id
						ELSE '/groups/' || coalesce((SELECT gp.group_id FROM group_posts gp WHERE gp.id = cm.entity_id), 0) END
					FROM comment_files cf JOIN comments cm ON cm.id = cf.comment_id WHERE cf.file_id = f.id AND cm.deleted_at IS NULL LIMIT 1)
				WHEN 'chat' THEN (SELECT '/messages?chat=' || m.chat_id FROM messages m WHERE m.file_id = f.id AND m.deleted_at IS NULL LIMIT 1)
				WHEN 'learning' THEN (SELECT '/learning/materials/item/' || lf.item_id FROM learn_item_files lf WHERE lf.file_id = f.id LIMIT 1)
			END AS link
		) o ON true
		WHERE f.id = ANY($1::bigint[]) ORDER BY f.id DESC`, ids)
	if err != nil {
		return nil, err
	}
	hits := make([]fileHit, 0, len(ids))
	byID := map[int64]int{}
	for rows.Next() {
		var h fileHit
		if err := rows.Scan(&h.ID, &h.Name, &h.Mime, &h.Size, &h.CreatedAt, &h.Source, &h.Origin, &h.Link); err != nil {
			rows.Close()
			return nil, err
		}
		if h.Source == "folder" {
			h.Source = "documents"
		}
		byID[h.ID] = len(hits)
		hits = append(hits, h)
	}
	rows.Close()
	if err := rows.Err(); err != nil {
		return nil, err
	}
	// сниппеты: сначала по началу текста (до 60 КБ), для тех, у кого совпадение дальше, — окно вокруг первого вхождения слова
	opts := "StartSel=" + hlStart + ", StopSel=" + hlStop + ", MaxWords=30, MinWords=12, ShortWord=1, MaxFragments=2, FragmentDelimiter=\" … \""
	var missing []int64
	hr, err := s.ro.Query(ctx, `SELECT file_id, ts_headline('simple', translate(left(text, 60000), E'\uE000\uE001', ''), to_tsquery('simple', $2), $3) FROM file_texts WHERE file_id = ANY($1::bigint[])`, ids, ts, opts)
	if err != nil {
		return nil, err
	}
	for hr.Next() {
		var id int64
		var sn string
		if err := hr.Scan(&id, &sn); err != nil {
			hr.Close()
			return nil, err
		}
		if strings.Contains(sn, hlStart) {
			hits[byID[id]].Snippet = sn
		} else {
			missing = append(missing, id)
		}
	}
	hr.Close()
	if len(missing) > 0 && len(toks) > 0 {
		wr, err := s.ro.Query(ctx, `SELECT file_id, ts_headline('simple', translate(substr(text, greatest(strpos(lower(text), $3) - 1500, 1), 6000), E'\uE000\uE001', ''), to_tsquery('simple', $2), $4), left(text, 200)
			FROM file_texts WHERE file_id = ANY($1::bigint[])`, missing, ts, toks[0], opts)
		if err != nil {
			return nil, err
		}
		for wr.Next() {
			var id int64
			var sn, head string
			if err := wr.Scan(&id, &sn, &head); err != nil {
				wr.Close()
				return nil, err
			}
			if !strings.Contains(sn, hlStart) {
				sn = head
			}
			hits[byID[id]].Snippet = sn
		}
		wr.Close()
	}
	return hits, nil
}

// searchFilesAPI — GET /api/search/files?q=…&limit=30: полный список совпадений по содержимому для страницы «Все результаты».
func (s *Server) searchFilesAPI(c *Ctx) error {
	q := c.Q("q")
	if len([]rune(q)) < 2 || len(searchTokens(q)) == 0 {
		return c.Raw(200, []byte(`[]`))
	}
	hits, err := s.searchFileContent(c.Context(), c.U, q, min(max(c.QInt("limit", 30), 1), 50))
	if err != nil {
		return err
	}
	return c.JSON(200, hits)
}

// ---------------------------------------------------------------- админка: «Индекс файлов»

func (s *Server) adminFileIndex(c *Ctx) error {
	ctx := c.Context()
	counts := map[string]int64{"pending": 0, "done": 0, "failed": 0, "unsupported": 0}
	rows, err := s.db.Query(ctx, `SELECT status, count(*) FROM file_texts GROUP BY status`)
	if err != nil {
		return err
	}
	for rows.Next() {
		var st string
		var n int64
		if err := rows.Scan(&st, &n); err != nil {
			rows.Close()
			return err
		}
		counts[st] = n
	}
	rows.Close()
	var missing, doneHour int64
	var lastAt *time.Time
	var textBytes int64
	if err := s.db.QueryRow(ctx, `SELECT
			(SELECT count(*) FROM files f WHERE f.storage <> '' AND f.external_url = '' AND NOT EXISTS (SELECT 1 FROM file_texts t WHERE t.file_id = f.id)),
			(SELECT count(*) FROM file_texts WHERE status = 'done' AND extracted_at > now() - interval '1 hour'),
			(SELECT max(extracted_at) FROM file_texts),
			(SELECT coalesce(sum(size), 0) FROM file_texts WHERE status = 'done')`).Scan(&missing, &doneHour, &lastAt, &textBytes); err != nil {
		return err
	}
	fails, err := s.arr(ctx, `SELECT t.file_id AS id, f.name, f.mime, f.size AS file_size, t.error, t.attempts, t.extracted_at, f.context
		FROM file_texts t JOIN files f ON f.id = t.file_id WHERE t.status = 'failed' ORDER BY t.file_id DESC LIMIT 100`)
	if err != nil {
		return err
	}
	unsup, err := s.arr(ctx, `SELECT t.error AS reason, count(*) AS n FROM file_texts t WHERE t.status = 'unsupported' AND t.error <> '' GROUP BY t.error ORDER BY n DESC LIMIT 10`)
	if err != nil {
		return err
	}
	prog, _ := s.rdb.HGetAll(ctx, "fidx:reindex").Result()
	return c.JSON(200, map[string]any{
		"counts": counts, "not_queued": missing, "done_last_hour": doneHour, "last_extracted_at": lastAt, "text_bytes": textBytes,
		"pdftotext": pdfAvailable(), "failures": json.RawMessage(fails), "unsupported_reasons": json.RawMessage(unsup),
		"reindex": prog,
	})
}

// adminFileReindex — POST {"scope":"all"|"failed"|"unsupported"}: возвращает файлы в очередь пачками в фоне; прогресс — в GET /api/admin/file-index.
// Старый текст остаётся доступным для поиска, пока файл не будет обработан заново.
func (s *Server) adminFileReindex(c *Ctx) error {
	var in struct {
		Scope string `json:"scope"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	var cond string
	switch in.Scope {
	case "", "all":
		in.Scope = "all"
		cond = `t.status <> 'pending' AND f.mime NOT LIKE 'image/%' AND f.mime NOT LIKE 'video/%' AND f.mime NOT LIKE 'audio/%'`
	case "failed":
		cond = `t.status = 'failed'`
	case "unsupported":
		cond = `t.status = 'unsupported' AND f.mime NOT LIKE 'image/%' AND f.mime NOT LIKE 'video/%' AND f.mime NOT LIKE 'audio/%'`
	default:
		return badReq("Неизвестная область переиндексации")
	}
	if !s.lock(c.Context(), "fileindex:reindex", 30*time.Minute) {
		return &apiError{409, "Переиндексация уже выполняется"}
	}
	rk := "fidx:reindex"
	s.rdb.Del(c.Context(), rk)
	s.rdb.HSet(c.Context(), rk, "state", "running", "scope", in.Scope, "queued", 0, "started", time.Now().Unix())
	s.rdb.Expire(c.Context(), rk, 24*time.Hour)
	s.audit(c, "fileindex.reindex", "file_index", 0, map[string]string{"scope": in.Scope})
	go func() { // не привязано к запросу: идёт, пока не обработает все пачки
		ctx := context.Background()
		defer s.unlock(ctx, "fileindex:reindex")
		var queued int64
		st := "done"
		if _, err := s.enqueueMissingFiles(ctx, 1<<30); err != nil { // новые файлы, не попавшие в очередь
			s.log.Warn("reindex: enqueue missing", "err", err)
		}
		cursor := int64(0)
		for {
			var n, last int64
			err := s.db.QueryRow(ctx, `WITH b AS (SELECT t.file_id FROM file_texts t JOIN files f ON f.id = t.file_id WHERE t.file_id > $1 AND `+cond+`
					ORDER BY t.file_id LIMIT 2000),
				u AS (UPDATE file_texts t SET status = 'pending', attempts = 0, next_try_at = now(), locked_until = NULL, error = '' FROM b WHERE t.file_id = b.file_id RETURNING t.file_id)
				SELECT count(*), coalesce(max(file_id), 0) FROM u`, cursor).Scan(&n, &last)
			if err != nil {
				s.log.Warn("reindex batch", "err", err)
				st = "error"
				break
			}
			if n == 0 {
				break
			}
			cursor = last
			queued += n
			s.rdb.HSet(ctx, rk, "queued", queued)
			time.Sleep(20 * time.Millisecond)
		}
		s.rdb.HSet(ctx, rk, "state", st, "queued", queued, "finished", time.Now().Unix())
	}()
	return c.JSON(202, map[string]any{"ok": true, "scope": in.Scope})
}

var _ = strconv.Itoa
