package server

import (
	"encoding/csv"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/redis/go-redis/v9"
)

func (s *Server) adminStats(c *Ctx) error {
	ctx := c.Context()
	totals, err := s.one(ctx, `SELECT
		(SELECT count(*) FROM users WHERE deleted_at IS NULL) AS users,
		(SELECT count(*) FROM users WHERE NOT blocked) AS active_users,
		(SELECT count(*) FROM news WHERE status = 'published') AS news,
		(SELECT count(*) FROM news WHERE status = 'draft') AS drafts,
		(SELECT count(*) FROM comments WHERE deleted_at IS NULL) AS comments,
		(SELECT count(*) FROM messages WHERE created_at > now() - interval '24 hours') AS messages_24h,
		(SELECT count(*) FROM messages) AS messages,
		(SELECT count(*) FROM chats) AS chats,
		(SELECT count(*) FROM files) AS files,
		(SELECT coalesce(sum(size), 0) FROM files) AS files_size,
		(SELECT count(*) FROM user_groups) AS groups,
		(SELECT count(*) FROM departments) AS departments,
		(SELECT coalesce(sum(views_count), 0) FROM news) AS views`)
	if err != nil {
		return err
	}
	series, err := s.arr(ctx, `SELECT to_char(g.d, 'YYYY-MM-DD') AS day,
		(SELECT count(*) FROM news WHERE published_at::date = g.d AND status = 'published') AS news,
		(SELECT count(*) FROM comments WHERE created_at::date = g.d) AS comments,
		(SELECT count(*) FROM messages WHERE created_at::date = g.d) AS messages
		FROM (SELECT d::date AS d FROM generate_series(current_date - 13, current_date, interval '1 day') d) g ORDER BY g.d`)
	if err != nil {
		return err
	}
	top, err := s.arr(ctx, `SELECT id, title, views_count, likes_count, comments_count FROM news WHERE status = 'published'
		ORDER BY views_count DESC, id DESC LIMIT 5`)
	if err != nil {
		return err
	}
	byDept, err := s.arr(ctx, `SELECT d.name, count(u.id) AS employees FROM departments d LEFT JOIN users u ON u.department_id = d.id AND NOT u.blocked
		WHERE d.parent_id IS NULL GROUP BY d.id ORDER BY d.sort, d.name`)
	if err != nil {
		return err
	}

	now := time.Now().Unix()
	ids, _ := s.rdb.ZRangeByScore(ctx, "instances", &redis.ZRangeBy{Min: strconv.FormatInt(now-30, 10), Max: "+inf"}).Result()
	info, _ := s.rdb.HGetAll(ctx, "insts").Result()
	insts := make([]map[string]any, 0, len(ids))
	for _, id := range ids {
		m := map[string]any{"id": id, "self": id == s.cfg.InstanceID}
		var v struct {
			WS    int64 `json:"ws"`
			Since int64 `json:"since"`
		}
		if json.Unmarshal([]byte(info[id]), &v) == nil {
			m["ws"], m["since"] = v.WS, v.Since
		}
		insts = append(insts, m)
	}
	return c.JSON(200, map[string]any{
		"totals": totals, "series": series, "top_news": top, "by_department": byDept,
		"online": len(s.onlineIDs(ctx)), "instances": insts, "served_by": s.cfg.InstanceID,
	})
}

// auditFilter собирает условия журнала: user (исполнитель), action (точное или префикс «user.»), entity, entity_id, target (id пользователя-цели),
// ip, request_id, q (подстрока в JSON данных), from/to (даты YYYY-MM-DD, включительно).
func auditFilter(c *Ctx) *whereBuilder {
	w := &whereBuilder{}
	if v := c.QInt64("user"); v > 0 {
		w.add("a.user_id = ?", v)
	}
	if v := c.Q("action"); v != "" {
		if strings.HasSuffix(v, ".") || strings.HasSuffix(v, "*") {
			w.add("a.action LIKE ? ESCAPE '\\'", likeEscape(strings.TrimRight(v, ".*"))+".%")
		} else {
			w.add("a.action = ?", v)
		}
	}
	if v := c.Q("entity"); v != "" {
		w.add("a.entity = ?", v)
	}
	if v := c.QInt64("entity_id"); v > 0 {
		w.add("a.entity_id = ?", v)
	}
	if v := c.QInt64("target"); v > 0 {
		w.add("a.entity = 'user' AND a.entity_id = ?", v)
	}
	if v := c.Q("ip"); v != "" {
		w.add("a.ip = ?", v)
	}
	if v := c.Q("request_id"); v != "" {
		w.add("a.request_id = ?", v)
	}
	if v := c.Q("role"); roleRank(v) > 0 {
		w.add("a.actor_role = ?", v)
	}
	if v := c.Q("from"); len(v) == 10 {
		w.add("a.created_at >= ?::date", v)
	}
	if v := c.Q("to"); len(v) == 10 {
		w.add("a.created_at < ?::date + 1", v)
	}
	if v := c.Q("q"); v != "" {
		w.add("a.data::text ILIKE ? ESCAPE '\\'", "%"+likeEscape(v)+"%")
	}
	return w
}

const auditSelect = `SELECT a.id, a.user_id, a.action, a.entity, a.entity_id, a.data, a.ip, a.request_id, a.actor_role, a.created_at,
	u.full_name AS user_name, u.login AS user_login, tu.full_name AS target_name
	FROM audit_log a LEFT JOIN users u ON u.id = a.user_id LEFT JOIN users tu ON a.entity = 'user' AND tu.id = a.entity_id`

func (s *Server) adminAudit(c *Ctx) error {
	_, per, off := c.Page(50, 200)
	w := auditFilter(c)
	n := w.n()
	b, err := s.arr(c.Context(), auditSelect+` WHERE `+w.String()+fmt.Sprintf(` ORDER BY a.id DESC LIMIT $%d OFFSET $%d`, n+1, n+2),
		append(w.args, per, off)...)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// adminAuditExport — выгрузка журнала в CSV (те же фильтры), потоково по keyset-страницам, не более 100 000 строк.
func (s *Server) adminAuditExport(c *Ctx) error {
	w := auditFilter(c)
	n := w.n()
	h := c.W.Header()
	h.Set("Content-Type", "text/csv; charset=utf-8")
	h.Set("Content-Disposition", `attachment; filename="audit-`+time.Now().Format("2006-01-02")+`.csv"`)
	c.W.WriteHeader(200)
	c.W.Write([]byte("\xef\xbb\xbf"))
	cw := csv.NewWriter(c.W)
	cw.Write([]string{"id", "время", "исполнитель", "логин", "роль", "действие", "объект", "id объекта", "цель", "IP", "request id", "данные"})
	last := int64(1) << 62
	for sent := 0; sent < 100000; {
		rows, err := s.db.Query(c.Context(), `SELECT a.id, a.created_at, coalesce(u.full_name, ''), coalesce(u.login, ''), a.actor_role, a.action, a.entity,
			coalesce(a.entity_id, 0), coalesce(tu.full_name, ''), a.ip, a.request_id, a.data::text
			FROM audit_log a LEFT JOIN users u ON u.id = a.user_id LEFT JOIN users tu ON a.entity = 'user' AND tu.id = a.entity_id
			WHERE `+w.String()+fmt.Sprintf(` AND a.id < $%d ORDER BY a.id DESC LIMIT 2000`, n+1), append(append([]any{}, w.args...), last)...)
		if err != nil {
			s.log.Warn("audit export", "err", err)
			break
		}
		cnt := 0
		for rows.Next() {
			var id, eid int64
			var at time.Time
			var un, ul, role, act, ent, tn, ip, rid, data string
			if err := rows.Scan(&id, &at, &un, &ul, &role, &act, &ent, &eid, &tn, &ip, &rid, &data); err != nil {
				break
			}
			last = id
			cnt++
			cw.Write([]string{strconv.FormatInt(id, 10), at.Format("2006-01-02 15:04:05"), csvSafe(un), ul, role, act, ent, strconv.FormatInt(eid, 10), csvSafe(tn), ip, rid, csvSafe(data)})
		}
		rows.Close()
		sent += cnt
		if cnt < 2000 {
			break
		}
	}
	cw.Flush()
	return nil
}

// csvSafe защищает от CSV-инъекции формул при открытии в Excel.
func csvSafe(v string) string {
	if v != "" && strings.ContainsRune("=+-@\t\r", rune(v[0])) {
		return "'" + v
	}
	return v
}

func (s *Server) adminComments(c *Ctx) error {
	_, per, off := c.Page(50, 200)
	b, err := s.arr(c.Context(), `SELECT c.id, c.entity_type, c.entity_id, c.body, c.created_at, c.deleted_at IS NOT NULL AS deleted,
		u.full_name AS author, n.title AS news_title
		FROM comments c LEFT JOIN users u ON u.id = c.user_id LEFT JOIN news n ON c.entity_type = 'news' AND n.id = c.entity_id
		ORDER BY c.id DESC LIMIT $1 OFFSET $2`, per, off)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}
