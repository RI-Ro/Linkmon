package server

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

// Конструктор типов заявок: метаданные, версии схемы/маршрута, доступ, импорт/экспорт.
// Правила редактирования типа: админ — все; редактор — типы, которые создал, и типы подразделений своей области (scope.go);
// владельцы типа (req_acl kind=owner) — свои типы; создание новых типов — редакторы и админ.

func (s *Server) registerRequestsManage(m *http.ServeMux) {
	const U, E = "user", "editor"
	p := "/api/requests"
	m.HandleFunc("GET "+p+"/categories", s.h(U, s.reqCategories))
	m.HandleFunc("POST "+p+"/manage/categories", s.h(E, s.reqCategorySave))
	m.HandleFunc("PUT "+p+"/manage/categories/{id}", s.h(E, s.reqCategorySave))
	m.HandleFunc("DELETE "+p+"/manage/categories/{id}", s.h("admin", s.reqCategoryDelete))
	m.HandleFunc("GET "+p+"/manage/types", s.h(U, s.reqManageList))
	m.HandleFunc("POST "+p+"/manage/types", s.h(E, s.reqTypeSave))
	m.HandleFunc("GET "+p+"/manage/types/{id}", s.h(U, s.reqTypeGet))
	m.HandleFunc("PUT "+p+"/manage/types/{id}", s.h(U, s.reqTypeSave))
	m.HandleFunc("DELETE "+p+"/manage/types/{id}", s.h(U, s.reqTypeDelete))
	m.HandleFunc("POST "+p+"/manage/types/{id}/duplicate", s.h(U, s.reqTypeDuplicate))
	m.HandleFunc("GET "+p+"/manage/types/{id}/export", s.h(U, s.reqTypeExport))
	m.HandleFunc("GET "+p+"/manage/types/{id}/versions/{ver}", s.h(U, s.reqVersionGet))
	m.HandleFunc("POST "+p+"/manage/import", s.h(E, s.reqTypeImport))
	m.HandleFunc("GET "+p+"/manage/groups", s.h(U, s.reqManageGroups))
}

// canManageType — права на редактирование типа (см. комментарий выше).
func (s *Server) canManageType(ctx context.Context, u *User, sc *scope, typeID int64) (bool, error) {
	if u.IsAdmin() {
		var ok bool
		err := s.db.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM req_types WHERE id = $1)`, typeID).Scan(&ok)
		return ok, err
	}
	var ok bool
	scopeIDs := []int64{}
	if sc != nil {
		scopeIDs = sc.IDs
	}
	err := s.db.QueryRow(ctx, `SELECT coalesce(t.created_by = $1 OR req_in_acl(t.id, 'owner', $1) OR ($2 AND t.department_id = ANY($3::bigint[])), false)
		FROM req_types t WHERE t.id = $4`, u.ID, u.CanEdit(), scopeIDs, typeID).Scan(&ok)
	if err == pgx.ErrNoRows {
		return false, nil
	}
	return ok, err
}

// ---------------------------------------------------------------- категории

func (s *Server) reqCategories(c *Ctx) error {
	b, err := s.arr(c.Context(), `SELECT id, name, icon, color, sort FROM req_categories ORDER BY sort, lower(name), id`)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) reqCategorySave(c *Ctx) error {
	var in struct {
		Name  string `json:"name"`
		Icon  string `json:"icon"`
		Color string `json:"color"`
		Sort  int    `json:"sort"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Name = strings.TrimSpace(in.Name)
	if in.Name == "" || reqRuneLen(in.Name) > 80 {
		return badReq("Название категории: от 1 до 80 символов")
	}
	if in.Icon == "" || len(in.Icon) > 30 {
		in.Icon = "file"
	}
	if !reqColorRe.MatchString(in.Color) {
		in.Color = "#286b9e"
	}
	var id int64
	var err error
	if c.R.PathValue("id") != "" {
		if id, err = c.ID("id"); err != nil {
			return err
		}
		tag, e := s.db.Exec(c.Context(), `UPDATE req_categories SET name = $2, icon = $3, color = $4, sort = $5 WHERE id = $1`, id, in.Name, in.Icon, in.Color, in.Sort)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return errNotFound
		}
	} else {
		err = s.db.QueryRow(c.Context(), `INSERT INTO req_categories (name, icon, color, sort, created_by)
			VALUES ($1, $2, $3, coalesce(nullif($4, 0), (SELECT coalesce(max(sort), 0) + 10 FROM req_categories)), $5) RETURNING id`, in.Name, in.Icon, in.Color, in.Sort, c.U.ID).Scan(&id)
		if err != nil {
			return err
		}
	}
	s.audit(c, "requests.category.save", "req_category", id, map[string]string{"name": in.Name})
	return c.JSON(200, map[string]int64{"id": id})
}

func (s *Server) reqCategoryDelete(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, err := s.db.Exec(c.Context(), `DELETE FROM req_categories WHERE id = $1`, id); err != nil {
		return err
	}
	s.audit(c, "requests.category.delete", "req_category", id, nil)
	return c.OK()
}

// ---------------------------------------------------------------- список и карточка типа

func (s *Server) reqManageList(c *Ctx) error {
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	b, err := s.arr(ctx, `SELECT t.id, t.name, t.icon, t.color, t.category_id, t.active, t.archived, t.department_id, d.name AS department, t.created_by, cu.full_name AS creator,
			v.version, t.updated_at, t.number_mask,
			(SELECT count(*) FROM req_requests r WHERE r.type_id = t.id AND r.status <> 'draft') AS requests,
			(SELECT count(*) FROM req_requests r WHERE r.type_id = t.id AND r.status IN ('pending', 'in_progress', 'rework')) AS open_requests
		FROM req_types t LEFT JOIN req_type_versions v ON v.id = t.cur_version LEFT JOIN departments d ON d.id = t.department_id LEFT JOIN users cu ON cu.id = t.created_by
		WHERE $1 OR t.created_by = $2 OR req_in_acl(t.id, 'owner', $2) OR ($3 AND t.department_id = ANY($4::bigint[]))
		ORDER BY t.archived, lower(t.name), t.id`, reqIsAdmin(c.U), c.U.ID, c.U.CanEdit(), sc.IDs)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func reqIsAdmin(u *User) bool { return u.IsAdmin() }

type reqSubj struct {
	Type string `json:"type"` // all | user | department | group | role
	ID   int64  `json:"id,omitempty"`
	Key  string `json:"key,omitempty"`
	Name string `json:"name,omitempty"`
}

type reqACLIn struct {
	Submit      []reqSubj `json:"submit"`
	Owner       []reqSubj `json:"owner"`
	Responsible []reqSubj `json:"responsible"`
	Watcher     []reqSubj `json:"watcher"`
}

func (s *Server) reqLoadACL(ctx context.Context, typeID int64) (map[string][]reqSubj, error) {
	rows, err := s.db.Query(ctx, `SELECT a.kind, a.subject_type, a.subject_id, a.subject_key,
			coalesce(u.full_name, d.name, g.name, '') FROM req_acl a
		LEFT JOIN users u ON a.subject_type = 'user' AND u.id = a.subject_id
		LEFT JOIN departments d ON a.subject_type = 'department' AND d.id = a.subject_id
		LEFT JOIN user_groups g ON a.subject_type = 'group' AND g.id = a.subject_id
		WHERE a.type_id = $1 ORDER BY a.kind, a.subject_type, a.subject_id, a.subject_key`, typeID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := map[string][]reqSubj{"submit": {}, "owner": {}, "responsible": {}, "watcher": {}}
	for rows.Next() {
		var kind string
		var sj reqSubj
		if err := rows.Scan(&kind, &sj.Type, &sj.ID, &sj.Key, &sj.Name); err != nil {
			return nil, err
		}
		if sj.Type == "role" {
			sj.Name = reqRoleLabel(sj.Key)
		}
		out[kind] = append(out[kind], sj)
	}
	return out, rows.Err()
}

func reqRoleLabel(k string) string {
	switch k {
	case "admin":
		return "Администраторы"
	case "editor":
		return "Редакторы"
	case "user":
		return "Все сотрудники (роль)"
	case "head":
		return "Руководители подразделений"
	}
	return k
}

func (s *Server) reqTypeGet(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	if ok, err := s.canManageType(ctx, c.U, sc, id); err != nil {
		return err
	} else if !ok {
		return errForbidden
	}
	head, err := s.one(ctx, `SELECT t.id, t.category_id, t.code, t.name, t.description, t.icon, t.color, t.number_mask, t.sla_value, t.sla_unit, t.remind_before_h,
			t.active, t.archived, t.department_id, d.name AS department, t.created_by, cu.full_name AS creator, t.created_at, t.updated_at, v.version, v.id AS version_id,
			v.schema, v.workflow, (SELECT count(*) FROM req_requests r WHERE r.type_id = t.id AND r.status <> 'draft') AS requests
		FROM req_types t JOIN req_type_versions v ON v.id = t.cur_version LEFT JOIN departments d ON d.id = t.department_id LEFT JOIN users cu ON cu.id = t.created_by WHERE t.id = $1`, id)
	if err != nil {
		return err
	}
	acl, err := s.reqLoadACL(ctx, id)
	if err != nil {
		return err
	}
	vers, err := s.arr(ctx, `SELECT v.version, v.note, v.created_at, u.full_name AS author, (SELECT count(*) FROM req_requests r WHERE r.version_id = v.id) AS requests
		FROM req_type_versions v LEFT JOIN users u ON u.id = v.created_by WHERE v.type_id = $1 ORDER BY v.version DESC`, id)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"type": json.RawMessage(head), "acl": acl, "versions": json.RawMessage(vers)})
}

func (s *Server) reqVersionGet(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ver, _ := strconv.Atoi(c.R.PathValue("ver"))
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	if ok, err := s.canManageType(ctx, c.U, sc, id); err != nil {
		return err
	} else if !ok {
		return errForbidden
	}
	b, err := s.one(ctx, `SELECT version, schema, workflow, note, created_at FROM req_type_versions WHERE type_id = $1 AND version = $2`, id, ver)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) reqManageGroups(c *Ctx) error {
	if !c.U.CanEdit() {
		var owner bool
		_ = s.db.QueryRow(c.Context(), `SELECT EXISTS (SELECT 1 FROM req_types WHERE NOT archived AND (created_by = $1 OR req_in_acl(id, 'owner', $1)))`, c.U.ID).Scan(&owner)
		if !owner {
			return errForbidden
		}
	}
	q := "%" + likeEscape(strings.ToLower(c.Q("q"))) + "%"
	b, err := s.arr(c.Context(), `SELECT id, name FROM user_groups WHERE lower(name) LIKE $1 ESCAPE '\' ORDER BY lower(name) LIMIT 30`, q)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// ---------------------------------------------------------------- сохранение типа

type reqTypeIn struct {
	Name         string          `json:"name"`
	Description  string          `json:"description"`
	Icon         string          `json:"icon"`
	Color        string          `json:"color"`
	Code         string          `json:"code"`
	NumberMask   string          `json:"number_mask"`
	CategoryID   *int64          `json:"category_id"`
	SLAValue     int             `json:"sla_value"`
	SLAUnit      string          `json:"sla_unit"`
	RemindBefore int             `json:"remind_before_h"`
	Active       bool            `json:"active"`
	Archived     bool            `json:"archived"`
	DepartmentID *int64          `json:"department_id"`
	Schema       json.RawMessage `json:"schema"`
	Workflow     json.RawMessage `json:"workflow"`
	ACL          reqACLIn        `json:"acl"`
	Note         string          `json:"note"`
}

var reqMaskLitRe = func() func(string) bool {
	return func(m string) bool {
		rest := reqMaskTokRe.ReplaceAllString(m, "")
		for _, r := range rest {
			if !(r == ' ' || r == '-' || r == '_' || r == '.' || r == '/' || r == '№' || r == '#' || (r >= '0' && r <= '9') || (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= 'а' && r <= 'я') || (r >= 'А' && r <= 'Я') || r == 'ё' || r == 'Ё') {
				return false
			}
		}
		return !strings.ContainsAny(rest, "{}")
	}
}()

func (in *reqTypeIn) validateMeta() error {
	in.Name = strings.TrimSpace(in.Name)
	in.Code = strings.TrimSpace(in.Code)
	in.NumberMask = strings.TrimSpace(in.NumberMask)
	if in.Name == "" || reqRuneLen(in.Name) > 120 {
		return badReq("Название типа заявки: от 1 до 120 символов")
	}
	if reqRuneLen(in.Description) > 20000 {
		return badReq("Описание слишком длинное")
	}
	if in.Icon == "" || len(in.Icon) > 30 {
		in.Icon = "file"
	}
	if !reqColorRe.MatchString(in.Color) {
		in.Color = "#286b9e"
	}
	if reqRuneLen(in.Code) > 12 || !reqMaskLitRe(in.Code) {
		return badReq("Код типа: до 12 символов (буквы, цифры, - _ . / №)")
	}
	if in.NumberMask != "" {
		if reqRuneLen(in.NumberMask) > 60 || !reqMaskLitRe(in.NumberMask) {
			return badReq("Маска нумерации: до 60 символов, допустимы {YYYY} {YY} {MM} {DD} {CODE} и {NNNNNN}")
		}
		cnt := 0
		for _, m := range reqMaskTokRe.FindAllString(in.NumberMask, -1) {
			if strings.HasPrefix(m, "{N") {
				cnt++
			}
		}
		if cnt != 1 {
			return badReq("В маске нумерации должен быть ровно один счётчик вида {NNNNNN}")
		}
	}
	switch in.SLAUnit {
	case "h", "wh", "d", "wd":
	case "":
		in.SLAUnit = "wd"
	default:
		return badReq("Единица срока: h, wh, d или wd")
	}
	if in.SLAValue < 0 || in.SLAValue > 100000 || in.RemindBefore < 0 || in.RemindBefore > 10000 {
		return badReq("Некорректный срок или время напоминания")
	}
	return nil
}

// checkWorkflow проверяет маршрут относительно схемы формы и дополняет подписи (имена пользователей, групп, подразделений).
// drop=true (импорт) — ссылки на несуществующие сущности отбрасываются, а не вызывают ошибку.
func (s *Server) checkWorkflow(ctx context.Context, wf *reqWF, sc *reqSchema, drop bool) ([]string, error) {
	var warns []string
	if len(wf.Steps) > 30 {
		return nil, badReq("Маршрут: не более 30 шагов")
	}
	keys := map[string]*reqField{}
	for _, f := range sc.fields() {
		if !f.isDisplay() {
			keys[f.Key] = f
		}
	}
	seenStep := map[string]bool{}
	nameOf := func(q string, id int64) (string, bool) {
		var n string
		if err := s.db.QueryRow(ctx, q, id).Scan(&n); err != nil {
			return "", false
		}
		return n, true
	}
	checkAsg := func(list []reqAssignee, where string) ([]reqAssignee, error) {
		out := make([]reqAssignee, 0, len(list))
		for _, a := range list {
			switch a.T {
			case "manager", "responsible":
			case "manager_up":
				if a.N < 1 || a.N > 10 {
					return nil, badReq(where + ": уровень «руководитель выше» от 1 до 10")
				}
			case "user":
				n, ok := nameOf(`SELECT full_name FROM users WHERE id = $1 AND NOT blocked`, a.ID)
				if !ok {
					if drop {
						warns = append(warns, where+": сотрудник не найден — исполнитель пропущен")
						continue
					}
					return nil, badReq(where + ": сотрудник не найден")
				}
				a.Name = n
			case "dept", "dept_head":
				n, ok := nameOf(`SELECT name FROM departments WHERE id = $1`, a.ID)
				if !ok {
					if drop {
						warns = append(warns, where+": подразделение не найдено — исполнитель пропущен")
						continue
					}
					return nil, badReq(where + ": подразделение не найдено")
				}
				a.Name = n
			case "group":
				n, ok := nameOf(`SELECT name FROM user_groups WHERE id = $1`, a.ID)
				if !ok {
					if drop {
						warns = append(warns, where+": группа не найдена — исполнитель пропущен")
						continue
					}
					return nil, badReq(where + ": группа не найдена")
				}
				a.Name = n
			case "field":
				f := keys[a.Key]
				if f == nil || f.Type != "user" {
					return nil, badReq(where + ": исполнитель «из поля» должен ссылаться на поле типа «Сотрудник»")
				}
				a.Name = f.Label
			default:
				return nil, badReq(where + ": неизвестный тип исполнителя")
			}
			out = append(out, a)
		}
		return out, nil
	}
	for i := range wf.Steps {
		st := &wf.Steps[i]
		st.Name = strings.TrimSpace(st.Name)
		where := "Шаг " + strconv.Itoa(i+1)
		if st.ID == "" {
			st.ID = "st" + strconv.Itoa(i+1)
		}
		if seenStep[st.ID] {
			st.ID = "st" + strconv.Itoa(i+1) + "_" + strconv.Itoa(len(seenStep))
		}
		seenStep[st.ID] = true
		if st.Name == "" || reqRuneLen(st.Name) > 120 {
			return nil, badReq(where + ": название шага от 1 до 120 символов")
		}
		where = "Шаг «" + st.Name + "»"
		switch st.Kind {
		case "approve", "execute", "inform":
		default:
			return nil, badReq(where + ": тип шага — согласование, исполнение или ознакомление")
		}
		if len(st.Branches) == 0 || len(st.Branches) > 6 {
			return nil, badReq(where + ": от 1 до 6 веток исполнителей")
		}
		for bi := range st.Branches {
			b := &st.Branches[bi]
			switch b.Mode {
			case "any", "all", "majority":
			case "":
				b.Mode = "any"
			default:
				return nil, badReq(where + ": неизвестный режим ветки")
			}
			var err error
			if b.Assignees, err = checkAsg(b.Assignees, where); err != nil {
				return nil, err
			}
			if len(b.Assignees) == 0 || len(b.Assignees) > 30 {
				if drop {
					warns = append(warns, where+": в ветке не осталось исполнителей")
					continue
				}
				return nil, badReq(where + ": в каждой ветке нужен хотя бы один исполнитель (до 30)")
			}
		}
		var err error
		if st.Fallback, err = checkAsg(st.Fallback, where+" (резерв)"); err != nil {
			return nil, err
		}
		if st.SLA != nil {
			switch st.SLA.Unit {
			case "h", "wh", "d", "wd":
			default:
				return nil, badReq(where + ": единица срока h, wh, d или wd")
			}
			if st.SLA.Value < 0 || st.SLA.Value > 100000 {
				return nil, badReq(where + ": некорректный срок")
			}
			if st.SLA.Value == 0 {
				st.SLA = nil
			}
		}
		if st.RemindH != nil && (*st.RemindH < 0 || *st.RemindH > 10000) {
			return nil, badReq(where + ": некорректное время напоминания")
		}
		if st.Escalate != nil {
			switch st.Escalate.To {
			case "":
				st.Escalate = nil
			case "manager":
			case "manager_up":
				if st.Escalate.N < 1 || st.Escalate.N > 10 {
					st.Escalate.N = 1
				}
			case "user":
				if _, ok := nameOf(`SELECT full_name FROM users WHERE id = $1 AND NOT blocked`, st.Escalate.UserID); !ok {
					if drop {
						st.Escalate = nil
						break
					}
					return nil, badReq(where + ": пользователь для эскалации не найден")
				}
			default:
				return nil, badReq(where + ": неизвестная эскалация")
			}
		}
		if st.Cond != nil {
			if len(st.Cond.Items) == 0 {
				st.Cond = nil
			} else {
				for _, it := range st.Cond.Items {
					base, _, _ := strings.Cut(it.Field, ".")
					if keys[base] == nil || !reqCmps[it.Cmp] {
						return nil, badReq(where + ": условие ссылается на неизвестное поле или операцию")
					}
				}
			}
		}
	}
	for _, h := range wf.Hooks {
		if h.Action != "vacation" {
			return nil, badReq("Неизвестное действие по завершению")
		}
		if f := keys[h.Period]; f == nil || f.Type != "period" {
			return nil, badReq("Действие «добавить в график отпусков»: укажите поле типа «Период дат»")
		}
		if h.Deputy != "" && (keys[h.Deputy] == nil || keys[h.Deputy].Type != "user") {
			return nil, badReq("Действие «добавить в график отпусков»: заместитель — поле типа «Сотрудник»")
		}
		if h.Flag != "" && (keys[h.Flag] == nil || keys[h.Flag].Type != "switch") {
			return nil, badReq("Действие «добавить в график отпусков»: флаг — поле типа «Переключатель»")
		}
	}
	return warns, nil
}

// checkACL проверяет и нормализует список доступа типа.
func (s *Server) checkACL(ctx context.Context, in *reqACLIn, drop bool) error {
	for kind, list := range map[string]*[]reqSubj{"submit": &in.Submit, "owner": &in.Owner, "responsible": &in.Responsible, "watcher": &in.Watcher} {
		out := make([]reqSubj, 0, len(*list))
		seen := map[string]bool{}
		for _, sj := range *list {
			var ok bool
			switch sj.Type {
			case "all":
				if kind == "owner" || kind == "responsible" {
					return badReq("«Все сотрудники» нельзя назначить владельцем или ответственным")
				}
				sj.ID, sj.Key, ok = 0, "", true
			case "user":
				ok = s.exists(ctx, `SELECT EXISTS (SELECT 1 FROM users WHERE id = $1 AND NOT blocked)`, sj.ID)
				sj.Key = ""
			case "department":
				ok = s.exists(ctx, `SELECT EXISTS (SELECT 1 FROM departments WHERE id = $1)`, sj.ID)
				sj.Key = ""
			case "group":
				ok = s.exists(ctx, `SELECT EXISTS (SELECT 1 FROM user_groups WHERE id = $1)`, sj.ID)
				sj.Key = ""
			case "role":
				ok = sj.Key == "admin" || sj.Key == "editor" || sj.Key == "user" || sj.Key == "head"
				sj.ID = 0
				if ok && (kind == "owner" || kind == "responsible") && sj.Key == "user" {
					return badReq("Роль «все пользователи» нельзя назначить владельцем или ответственным")
				}
			}
			if !ok {
				if drop {
					continue
				}
				return badReq("Доступ: участник «" + sj.Name + "» не найден")
			}
			k := fmt.Sprintf("%s/%d/%s", sj.Type, sj.ID, sj.Key)
			if !seen[k] {
				seen[k] = true
				out = append(out, sj)
			}
		}
		if len(out) > 200 {
			return badReq("Доступ: слишком много участников")
		}
		*list = out
	}
	return nil
}

func (s *Server) exists(ctx context.Context, q string, args ...any) bool {
	var ok bool
	_ = s.db.QueryRow(ctx, q, args...).Scan(&ok)
	return ok
}

func (s *Server) writeACL(ctx context.Context, tx pgx.Tx, typeID int64, a *reqACLIn) error {
	if _, err := tx.Exec(ctx, `DELETE FROM req_acl WHERE type_id = $1`, typeID); err != nil {
		return err
	}
	for kind, list := range map[string][]reqSubj{"submit": a.Submit, "owner": a.Owner, "responsible": a.Responsible, "watcher": a.Watcher} {
		for _, sj := range list {
			if _, err := tx.Exec(ctx, `INSERT INTO req_acl (type_id, kind, subject_type, subject_id, subject_key) VALUES ($1, $2, $3, $4, $5) ON CONFLICT DO NOTHING`,
				typeID, kind, sj.Type, sj.ID, sj.Key); err != nil {
				return err
			}
		}
	}
	return nil
}

func reqCanon(v any) string { b, _ := json.Marshal(v); return string(b) }

// reqMaskSig — как выглядит первый номер по маске: два типа не должны выдавать одинаковые номера.
func reqMaskSig(mask, code string) string {
	return reqRenderMask(mask, code, time.Date(2000, 1, 1, 0, 0, 0, 0, time.UTC), 1)
}

func (s *Server) reqTypeSave(c *Ctx) error {
	var in reqTypeIn
	if err := c.Decode(&in); err != nil {
		return err
	}
	ctx := c.Context()
	u := c.U
	if err := in.validateMeta(); err != nil {
		return err
	}
	sc, err := s.scopeOf(ctx, u)
	if err != nil {
		return err
	}
	var id int64
	editing := c.R.PathValue("id") != ""
	if editing {
		if id, err = c.ID("id"); err != nil {
			return err
		}
		if ok, err := s.canManageType(ctx, u, sc, id); err != nil {
			return err
		} else if !ok {
			return errForbidden
		}
	}
	// область: подразделение типа
	if in.DepartmentID != nil && !u.IsAdmin() && !sc.Has(*in.DepartmentID) {
		var cur *int64
		if editing {
			_ = s.db.QueryRow(ctx, `SELECT department_id FROM req_types WHERE id = $1`, id).Scan(&cur)
		}
		if cur == nil || *cur != *in.DepartmentID { // оставить прежнее значение можно, назначить недоступное — нельзя
			return &apiError{403, "Подразделение типа должно входить в вашу область управления"}
		}
	}
	if in.DepartmentID != nil && !s.exists(ctx, `SELECT EXISTS (SELECT 1 FROM departments WHERE id = $1)`, *in.DepartmentID) {
		return badReq("Подразделение не найдено")
	}
	if in.CategoryID != nil && !s.exists(ctx, `SELECT EXISTS (SELECT 1 FROM req_categories WHERE id = $1)`, *in.CategoryID) {
		return badReq("Категория не найдена")
	}
	schema, err := parseSchema(in.Schema)
	if err != nil {
		return badReq("Схема формы не передана или повреждена")
	}
	if err := s.checkSchema(schema); err != nil {
		return err
	}
	wf := &reqWF{}
	if len(in.Workflow) == 0 {
		in.Workflow = []byte(`{"steps":[]}`)
	}
	if err := json.Unmarshal(in.Workflow, wf); err != nil {
		return badReq("Маршрут повреждён")
	}
	if wf.Steps == nil {
		wf.Steps = []reqStep{}
	}
	if _, err := s.checkWorkflow(ctx, wf, schema, false); err != nil {
		return err
	}
	if err := s.checkACL(ctx, &in.ACL, false); err != nil {
		return err
	}
	if !editing && len(in.ACL.Submit) == 0 {
		in.ACL.Submit = []reqSubj{{Type: "all"}}
	}
	// маска нумерации и уникальность номеров
	mask, code := in.NumberMask, in.Code
	autoMask := mask == ""
	if autoMask {
		mask = "{CODE}-{YYYY}-{NNNNNN}"
		if code == "" {
			code = "ЗАЯ"
		}
	}
	if strings.Contains(mask, "{CODE}") && code == "" {
		return badReq("В маске есть {CODE}, но код типа не задан")
	}
	clash := func(mask, code string) string {
		rows, err := s.db.Query(ctx, `SELECT name, number_mask, code FROM req_types WHERE id <> $1 AND NOT archived`, id)
		if err != nil {
			return ""
		}
		defer rows.Close()
		sig := reqMaskSig(mask, code)
		for rows.Next() {
			var n, m, cd string
			if rows.Scan(&n, &m, &cd) == nil && reqMaskSig(m, cd) == sig {
				return n
			}
		}
		return ""
	}
	if other := clash(mask, code); other != "" {
		if !autoMask {
			return badReq("Такая маска нумерации уже используется типом «" + other + "». Добавьте {CODE} и задайте код типа")
		}
		base := code
		for i := 2; i < 200 && clash(mask, code) != ""; i++ { // подбираем свободный код
			code = base + strconv.Itoa(i)
		}
	}
	var verChanged bool
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if !editing {
			var dept any
			if in.DepartmentID != nil {
				dept = *in.DepartmentID
			} else if u.Dept > 0 {
				dept = u.Dept
			}
			if err := tx.QueryRow(ctx, `INSERT INTO req_types (category_id, code, name, description, icon, color, number_mask, sla_value, sla_unit, remind_before_h, active, archived, department_id, created_by, sort)
				VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, false, $12, $13, coalesce((SELECT max(sort) + 10 FROM req_types), 10)) RETURNING id`,
				in.CategoryID, code, in.Name, in.Description, in.Icon, in.Color, mask, in.SLAValue, in.SLAUnit, in.RemindBefore, in.Active, dept, u.ID).Scan(&id); err != nil {
				return err
			}
		} else {
			// смену подразделения может делать тот, у кого оно в области (проверено выше); владелец без прав редактора не меняет область
			dept := in.DepartmentID
			if !u.IsAdmin() && !u.CanEdit() {
				_ = tx.QueryRow(ctx, `SELECT department_id FROM req_types WHERE id = $1`, id).Scan(&dept)
			}
			if _, err := tx.Exec(ctx, `UPDATE req_types SET category_id = $2, code = $3, name = $4, description = $5, icon = $6, color = $7, number_mask = $8, sla_value = $9, sla_unit = $10,
				remind_before_h = $11, active = $12, archived = $13, department_id = $14, updated_at = now() WHERE id = $1`,
				id, in.CategoryID, code, in.Name, in.Description, in.Icon, in.Color, mask, in.SLAValue, in.SLAUnit, in.RemindBefore, in.Active && !in.Archived, in.Archived, dept); err != nil {
				return err
			}
		}
		sj, wj := reqCanon(schema), reqCanon(wf)
		var same bool
		if editing {
			err := tx.QueryRow(ctx, `SELECT v.schema = $2::jsonb AND v.workflow = $3::jsonb FROM req_types t JOIN req_type_versions v ON v.id = t.cur_version WHERE t.id = $1`, id, sj, wj).Scan(&same)
			if err != nil && err != pgx.ErrNoRows {
				return err
			}
		}
		if !same {
			verChanged = true
			var vid int64
			if err := tx.QueryRow(ctx, `INSERT INTO req_type_versions (type_id, version, schema, workflow, note, created_by)
				VALUES ($1, coalesce((SELECT max(version) FROM req_type_versions WHERE type_id = $1), 0) + 1, $2::jsonb, $3::jsonb, $4, $5) RETURNING id`,
				id, sj, wj, reqClip(strings.TrimSpace(in.Note), 300), u.ID).Scan(&vid); err != nil {
				return err
			}
			if _, err := tx.Exec(ctx, `UPDATE req_types SET cur_version = $2, updated_at = now() WHERE id = $1`, id, vid); err != nil {
				return err
			}
		}
		return s.writeACL(ctx, tx, id, &in.ACL)
	})
	if err != nil {
		return err
	}
	s.audit(c, "requests.type.save", "req_type", id, map[string]any{"name": in.Name, "new_version": verChanged, "created": !editing})
	return c.JSON(200, map[string]any{"id": id, "new_version": verChanged})
}

func (s *Server) reqTypeDelete(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	if ok, err := s.canManageType(ctx, c.U, sc, id); err != nil {
		return err
	} else if !ok {
		return errForbidden
	}
	var n int
	if err := s.db.QueryRow(ctx, `SELECT count(*) FROM req_requests WHERE type_id = $1`, id).Scan(&n); err != nil {
		return err
	}
	if n > 0 { // заявки есть — тип архивируется (заявки и история остаются)
		if _, err := s.db.Exec(ctx, `UPDATE req_types SET archived = true, active = false, updated_at = now() WHERE id = $1`, id); err != nil {
			return err
		}
		s.audit(c, "requests.type.archive", "req_type", id, nil)
		return c.JSON(200, map[string]bool{"archived": true})
	}
	if _, err := s.db.Exec(ctx, `UPDATE req_types SET cur_version = NULL WHERE id = $1`, id); err != nil {
		return err
	}
	if _, err := s.db.Exec(ctx, `DELETE FROM req_types WHERE id = $1`, id); err != nil {
		return err
	}
	s.audit(c, "requests.type.delete", "req_type", id, nil)
	return c.JSON(200, map[string]bool{"archived": false})
}

func (s *Server) reqTypeDuplicate(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	if !c.U.CanEdit() {
		return errForbidden // создавать новые типы могут редакторы и администраторы
	}
	if ok, err := s.canManageType(ctx, c.U, sc, id); err != nil {
		return err
	} else if !ok {
		return errForbidden
	}
	var nid int64
	err = s.tx(ctx, func(tx pgx.Tx) error {
		var dept any
		if c.U.Dept > 0 {
			dept = c.U.Dept
		}
		if err := tx.QueryRow(ctx, `INSERT INTO req_types (category_id, code, name, description, icon, color, number_mask, sla_value, sla_unit, remind_before_h, active, department_id, created_by, sort)
			SELECT category_id, 'КОП', name || ' (копия)', description, icon, color, '{CODE}-{YYYY}-{NNNNNN}', sla_value, sla_unit, remind_before_h, false,
				CASE WHEN $2::bigint IS NOT NULL THEN $2 ELSE department_id END, $3, (SELECT max(sort) + 10 FROM req_types) FROM req_types WHERE id = $1 RETURNING id`, id, dept, c.U.ID).Scan(&nid); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE req_types SET code = 'КОП' || id::text WHERE id = $1`, nid); err != nil {
			return err
		}
		var vid int64
		if err := tx.QueryRow(ctx, `INSERT INTO req_type_versions (type_id, version, schema, workflow, note, created_by)
			SELECT $2, 1, v.schema, v.workflow, 'Копия типа #' || $1::text, $3 FROM req_types t JOIN req_type_versions v ON v.id = t.cur_version WHERE t.id = $1 RETURNING id`, id, nid, c.U.ID).Scan(&vid); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE req_types SET cur_version = $2 WHERE id = $1`, nid, vid); err != nil {
			return err
		}
		_, err := tx.Exec(ctx, `INSERT INTO req_acl (type_id, kind, subject_type, subject_id, subject_key)
			SELECT $2, kind, subject_type, subject_id, subject_key FROM req_acl WHERE type_id = $1`, id, nid)
		return err
	})
	if err != nil {
		return err
	}
	s.audit(c, "requests.type.duplicate", "req_type", nid, map[string]int64{"from": id})
	return c.JSON(200, map[string]int64{"id": nid})
}

// ---------------------------------------------------------------- импорт / экспорт

const reqExportFormat = "corpnet.request-type"

func (s *Server) reqTypeExport(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	if ok, err := s.canManageType(ctx, c.U, sc, id); err != nil {
		return err
	} else if !ok {
		return errForbidden
	}
	b, err := s.one(ctx, `SELECT 'corpnet.request-type' AS format, 1 AS v, t.name, t.description, t.icon, t.color, t.code, t.number_mask, t.sla_value, t.sla_unit, t.remind_before_h,
			v.schema, v.workflow FROM req_types t JOIN req_type_versions v ON v.id = t.cur_version WHERE t.id = $1`, id)
	if err != nil {
		return err
	}
	h := c.W.Header()
	h.Set("Content-Type", "application/json; charset=utf-8")
	h.Set("Content-Disposition", "attachment; filename*=UTF-8''"+reqURLEsc("request-type-"+strconv.FormatInt(id, 10)+".json"))
	_, err = c.W.Write(b)
	return err
}

func (s *Server) reqTypeImport(c *Ctx) error {
	var in struct {
		Format       string          `json:"format"`
		Name         string          `json:"name"`
		Description  string          `json:"description"`
		Icon         string          `json:"icon"`
		Color        string          `json:"color"`
		Code         string          `json:"code"`
		NumberMask   string          `json:"number_mask"`
		SLAValue     int             `json:"sla_value"`
		SLAUnit      string          `json:"sla_unit"`
		RemindBefore int             `json:"remind_before_h"`
		Schema       json.RawMessage `json:"schema"`
		Workflow     json.RawMessage `json:"workflow"`
		CategoryID   *int64          `json:"category_id"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if in.Format != reqExportFormat {
		return badReq("Это не файл схемы типа заявки (ожидается формат " + reqExportFormat + ")")
	}
	ctx := c.Context()
	schema, err := parseSchema(in.Schema)
	if err != nil {
		return badReq("Схема в файле повреждена")
	}
	if err := s.checkSchema(schema); err != nil {
		return err
	}
	wf := &reqWF{}
	if len(in.Workflow) > 0 {
		if err := json.Unmarshal(in.Workflow, wf); err != nil {
			return badReq("Маршрут в файле повреждён")
		}
	}
	if wf.Steps == nil {
		wf.Steps = []reqStep{}
	}
	warns, err := s.checkWorkflow(ctx, wf, schema, true)
	if err != nil {
		return err
	}
	meta := reqTypeIn{Name: in.Name, Description: in.Description, Icon: in.Icon, Color: in.Color, SLAValue: in.SLAValue, SLAUnit: in.SLAUnit, RemindBefore: in.RemindBefore}
	meta.Name += " (импорт)"
	if err := meta.validateMeta(); err != nil {
		return err
	}
	var id int64
	err = s.tx(ctx, func(tx pgx.Tx) error {
		var dept any
		if c.U.Dept > 0 {
			dept = c.U.Dept
		}
		if err := tx.QueryRow(ctx, `INSERT INTO req_types (category_id, code, name, description, icon, color, number_mask, sla_value, sla_unit, remind_before_h, active, department_id, created_by, sort)
			VALUES ($1, 'ИМП', $2, $3, $4, $5, '{CODE}-{YYYY}-{NNNNNN}', $6, $7, $8, false, $9, $10, (SELECT coalesce(max(sort), 0) + 10 FROM req_types)) RETURNING id`,
			nil, meta.Name, meta.Description, meta.Icon, meta.Color, meta.SLAValue, meta.SLAUnit, meta.RemindBefore, dept, c.U.ID).Scan(&id); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE req_types SET code = 'ИМП' || id::text WHERE id = $1`, id); err != nil {
			return err
		}
		var vid int64
		if err := tx.QueryRow(ctx, `INSERT INTO req_type_versions (type_id, version, schema, workflow, note, created_by) VALUES ($1, 1, $2::jsonb, $3::jsonb, 'Импорт из файла', $4) RETURNING id`,
			id, reqCanon(schema), reqCanon(wf), c.U.ID).Scan(&vid); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE req_types SET cur_version = $2 WHERE id = $1`, id, vid); err != nil {
			return err
		}
		_, err := tx.Exec(ctx, `INSERT INTO req_acl (type_id, kind, subject_type) VALUES ($1, 'submit', 'all')`, id)
		return err
	})
	if err != nil {
		return err
	}
	s.audit(c, "requests.type.import", "req_type", id, map[string]string{"name": meta.Name})
	return c.JSON(201, map[string]any{"id": id, "warnings": warns})
}
