package server

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"regexp"
	"strconv"
	"time"
	"unicode"

	"github.com/jackc/pgx/v5"
)

// Универсальные реакции: таблица reactions (entity_type, entity_id, user_id, emoji). Эмодзи — юникод либо шорткод
// анимированного стикера «:имя:». Лайк = реакция 👍; у новостей/идей/постов групп число 👍 дополнительно лежит в
// денормализованной колонке likes_count (сортировка «популярных идей», карточки кэшированной ленты).
//
// Как подключить реакции новому типу объектов (другому блоку): registerReactionTarget("wiki", func(...)) в init(),
// а в списке объектов вызвать s.withSocial(ctx, uid, "wiki", items, false) — поле reactions появится у каждого элемента.

const likeEmoji = "👍"

const (
	maxReactionsPerUser   = 12 // разных реакций одного пользователя на один объект
	maxReactionKindsTotal = 40 // разных эмодзи на одном объекте
)

type rxItem struct {
	E string `json:"e"`
	N int    `json:"n"`
	M bool   `json:"m,omitempty"`
}

// reactionTarget — куда слать событие «реакции изменились» (все экземпляры/ЦОДы через hub.Emit).
type reactionTarget struct {
	Topic string  // тема WebSocket (news:1, idea:2, group:3)
	Users []int64 // либо адресаты событий (участники чата)
	News  bool    // 👍 на новости: сбросить кэш ленты
}

type reactionResolver func(ctx context.Context, s *Server, u *User, id int64) (*reactionTarget, error)

var reactionTargets = map[string]reactionResolver{}

// registerReactionTarget регистрирует тип объекта для реакций. Резолвер обязан проверить, что пользователь видит объект.
func registerReactionTarget(typ string, fn reactionResolver) { reactionTargets[typ] = fn }

func groupTopic(gid int64) string { return "group:" + strconv.FormatInt(gid, 10) }

func init() {
	registerReactionTarget("news", func(ctx context.Context, s *Server, u *User, id int64) (*reactionTarget, error) {
		if _, _, _, err := s.entityAccess(ctx, u, "news", id); err != nil {
			return nil, err
		}
		return &reactionTarget{Topic: "news:" + strconv.FormatInt(id, 10), News: true}, nil
	})
	registerReactionTarget("idea", func(ctx context.Context, s *Server, u *User, id int64) (*reactionTarget, error) {
		if _, _, _, err := s.entityAccess(ctx, u, "idea", id); err != nil {
			return nil, err
		}
		return &reactionTarget{Topic: "idea:" + strconv.FormatInt(id, 10)}, nil
	})
	registerReactionTarget("post", func(ctx context.Context, s *Server, u *User, id int64) (*reactionTarget, error) {
		if _, _, _, err := s.entityAccess(ctx, u, "post", id); err != nil {
			return nil, err
		}
		var gid int64
		if err := s.db.QueryRow(ctx, `SELECT group_id FROM group_posts WHERE id = $1`, id).Scan(&gid); err != nil {
			return nil, err
		}
		return &reactionTarget{Topic: groupTopic(gid)}, nil
	})
	registerReactionTarget("comment", func(ctx context.Context, s *Server, u *User, id int64) (*reactionTarget, error) {
		var et string
		var eid int64
		if err := s.db.QueryRow(ctx, `SELECT entity_type, entity_id FROM comments WHERE id = $1 AND deleted_at IS NULL`, id).Scan(&et, &eid); err != nil {
			return nil, err
		}
		if _, _, _, err := s.entityAccess(ctx, u, et, eid); err != nil {
			return nil, err
		}
		if et == "post" {
			var gid int64
			if err := s.db.QueryRow(ctx, `SELECT group_id FROM group_posts WHERE id = $1`, eid).Scan(&gid); err != nil {
				return nil, err
			}
			return &reactionTarget{Topic: groupTopic(gid)}, nil
		}
		return &reactionTarget{Topic: et + ":" + strconv.FormatInt(eid, 10)}, nil
	})
	registerReactionTarget("message", func(ctx context.Context, s *Server, u *User, id int64) (*reactionTarget, error) {
		var chat int64
		if err := s.db.QueryRow(ctx, `SELECT chat_id FROM messages WHERE id = $1 AND deleted_at IS NULL`, id).Scan(&chat); err != nil {
			return nil, err
		}
		if ok, err := s.isMember(ctx, chat, u.ID); err != nil {
			return nil, err
		} else if !ok {
			return nil, errNotFound // личный чат/чужая группа: объекта «не существует»
		}
		members, err := s.chatMembers(ctx, chat)
		if err != nil {
			return nil, err
		}
		return &reactionTarget{Users: members}, nil
	})
}

var stickerCodeRe = regexp.MustCompile(`^:[a-z0-9_]{1,40}:$`)

// validReaction — шорткод стикера либо короткая последовательность символов эмодзи (буквы, цифры и пробелы не допускаются).
func validReaction(e string) bool {
	if stickerCodeRe.MatchString(e) {
		return true
	}
	rs := []rune(e)
	if len(rs) == 0 || len(rs) > 16 {
		return false
	}
	sym := false
	for _, r := range rs {
		switch {
		case unicode.In(r, unicode.So, unicode.Sk, unicode.Sm):
			sym = true
		case unicode.In(r, unicode.Cf, unicode.Mn, unicode.Me), r >= 0x2000 && unicode.Is(unicode.Po, r): // ‼ ⁉ ZWJ, селекторы вариантов
		default:
			return false
		}
	}
	return sym
}

// reactionsFor — агрегаты реакций для набора объектов одним запросом (index-only по reactions_entity).
func (s *Server) reactionsFor(ctx context.Context, uid int64, typ string, ids []int64) (map[int64][]rxItem, error) {
	out := make(map[int64][]rxItem, len(ids))
	if len(ids) == 0 {
		return out, nil
	}
	rows, err := s.db.Query(ctx, `SELECT entity_id, emoji, count(*)::int, bool_or(user_id = $3) FROM reactions
		WHERE entity_type = $1 AND entity_id = ANY($2) GROUP BY entity_id, emoji ORDER BY entity_id, count(*) DESC, emoji`, typ, ids, uid)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var id int64
		var it rxItem
		if err := rows.Scan(&id, &it.E, &it.N, &it.M); err != nil {
			return nil, err
		}
		out[id] = append(out[id], it)
	}
	return out, rows.Err()
}

// bookmarkedSet — какие из объектов в закладках у пользователя (одним запросом на страницу).
func (s *Server) bookmarkedSet(ctx context.Context, uid int64, typ string, ids []int64) (map[int64]bool, error) {
	out := map[int64]bool{}
	if len(ids) == 0 {
		return out, nil
	}
	rows, err := s.db.Query(ctx, `SELECT entity_id FROM bookmarks WHERE user_id = $1 AND entity_type = $2 AND entity_id = ANY($3)`, uid, typ, ids)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		out[id] = true
	}
	return out, rows.Err()
}

// withSocial добавляет каждому объекту JSON-массива items поля reactions (и bookmarked, если bm) — по одному запросу на страницу.
func (s *Server) withSocial(ctx context.Context, uid int64, typ string, items json.RawMessage, bm bool) (json.RawMessage, error) {
	var list []map[string]json.RawMessage
	if err := json.Unmarshal(items, &list); err != nil || len(list) == 0 {
		return items, nil
	}
	ids := make([]int64, 0, len(list))
	for _, o := range list {
		var id int64
		if json.Unmarshal(o["id"], &id) == nil {
			ids = append(ids, id)
		}
	}
	rx, err := s.reactionsFor(ctx, uid, typ, ids)
	if err != nil {
		return nil, err
	}
	var marks map[int64]bool
	if bm {
		if marks, err = s.bookmarkedSet(ctx, uid, typ, ids); err != nil {
			return nil, err
		}
	}
	for _, o := range list {
		var id int64
		if json.Unmarshal(o["id"], &id) != nil {
			continue
		}
		r := rx[id]
		if r == nil {
			r = []rxItem{}
		}
		o["reactions"], _ = json.Marshal(r)
		if bm {
			o["bookmarked"], _ = json.Marshal(marks[id])
		}
	}
	return json.Marshal(list)
}

// withSocialOne — то же для одного объекта-JSON.
func (s *Server) withSocialOne(ctx context.Context, uid int64, typ string, obj json.RawMessage, bm bool) (json.RawMessage, error) {
	b, err := s.withSocial(ctx, uid, typ, json.RawMessage("["+string(obj)+"]"), bm)
	if err != nil {
		return nil, err
	}
	return b[1 : len(b)-1], nil
}

type rxResult struct {
	On    bool
	Items []rxItem
	Likes int
}

// setReaction ставит/снимает реакцию. want == nil — переключить, иначе привести к заданному состоянию.
func (s *Server) setReaction(ctx context.Context, u *User, typ string, id int64, emoji string, want *bool) (*rxResult, error) {
	res, ok := reactionTargets[typ]
	if !ok || id <= 0 {
		return nil, badReq("Неизвестный тип объекта")
	}
	if !validReaction(emoji) {
		return nil, badReq("Недопустимая реакция")
	}
	if !s.rateOK(ctx, fmt.Sprintf("react:%d", u.ID), 90, time.Minute) {
		return nil, &apiError{429, "Слишком часто. Подождите немного"}
	}
	tg, err := res(ctx, s, u, id)
	if err != nil {
		return nil, err
	}
	out := &rxResult{}
	counted := emoji == likeEmoji && (typ == "news" || typ == "idea" || typ == "post")
	err = s.tx(ctx, func(tx pgx.Tx) error {
		var had bool
		if err := tx.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM reactions WHERE entity_type = $1 AND entity_id = $2 AND user_id = $3 AND emoji = $4)`,
			typ, id, u.ID, emoji).Scan(&had); err != nil {
			return err
		}
		on := !had
		if want != nil {
			on = *want
		}
		out.On = on
		if on == had {
			return nil
		}
		delta := 1
		if on {
			var mine, kinds int
			if err := tx.QueryRow(ctx, `SELECT count(*) FILTER (WHERE user_id = $3), count(DISTINCT emoji) FROM reactions WHERE entity_type = $1 AND entity_id = $2`,
				typ, id, u.ID).Scan(&mine, &kinds); err != nil {
				return err
			}
			if mine >= maxReactionsPerUser {
				return badReq(fmt.Sprintf("Можно поставить не более %d разных реакций", maxReactionsPerUser))
			}
			var exists bool
			if err := tx.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM reactions WHERE entity_type = $1 AND entity_id = $2 AND emoji = $3)`, typ, id, emoji).Scan(&exists); err != nil {
				return err
			}
			if !exists && kinds >= maxReactionKindsTotal {
				return badReq("На этом объекте уже слишком много разных реакций")
			}
			if _, err := tx.Exec(ctx, `INSERT INTO reactions (entity_type, entity_id, user_id, emoji) VALUES ($1, $2, $3, $4) ON CONFLICT DO NOTHING`, typ, id, u.ID, emoji); err != nil {
				return err
			}
		} else {
			delta = -1
			if _, err := tx.Exec(ctx, `DELETE FROM reactions WHERE entity_type = $1 AND entity_id = $2 AND user_id = $3 AND emoji = $4`, typ, id, u.ID, emoji); err != nil {
				return err
			}
		}
		if counted {
			return bumpCount(ctx, tx, typ, id, "likes_count", delta, &out.Likes)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	m, err := s.reactionsFor(ctx, u.ID, typ, []int64{id})
	if err != nil {
		return nil, err
	}
	out.Items = m[id]
	if out.Items == nil {
		out.Items = []rxItem{}
	}
	if emoji == likeEmoji && typ == "news" {
		s.bumpNews(ctx)
	}
	// событие без «моя»: у каждого получателя «моя» своя; автор события помечен actor
	pub := make([]rxItem, len(out.Items))
	for i, it := range out.Items {
		pub[i] = rxItem{E: it.E, N: it.N}
	}
	ev := map[string]any{"entity_type": typ, "entity_id": id, "reactions": pub, "actor": u.ID, "emoji": emoji, "on": out.On}
	if tg.Users != nil {
		s.hub.EmitUsers(ctx, tg.Users, "reaction", ev)
	} else if tg.Topic != "" {
		s.hub.Emit(ctx, tg.Topic, "reaction", ev)
	}
	return out, nil
}

// POST /api/reactions {entity_type, entity_id, emoji, on?} — поставить/снять (без on — переключить).
func (s *Server) reactionSet(c *Ctx) error {
	var in struct {
		Type  string `json:"entity_type"`
		ID    int64  `json:"entity_id"`
		Emoji string `json:"emoji"`
		On    *bool  `json:"on"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	r, err := s.setReaction(c.Context(), c.U, in.Type, in.ID, in.Emoji, in.On)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"on": r.On, "reactions": r.Items})
}

// GET /api/reactions?entity_type=&entity_id= — агрегаты объекта.
func (s *Server) reactionGet(c *Ctx) error {
	typ, id := c.Q("entity_type"), c.QInt64("entity_id")
	ctx := c.Context()
	res, ok := reactionTargets[typ]
	if !ok {
		return badReq("Неизвестный тип объекта")
	}
	if _, err := res(ctx, s, c.U, id); err != nil {
		return err
	}
	m, err := s.reactionsFor(ctx, c.U.ID, typ, []int64{id})
	if err != nil {
		return err
	}
	r := m[id]
	if r == nil {
		r = []rxItem{}
	}
	return c.JSON(200, map[string]any{"reactions": r})
}

// GET /api/reactions/users?entity_type=&entity_id=&emoji=&page=&per= — «кто поставил».
func (s *Server) reactionUsers(c *Ctx) error {
	typ, id, emoji := c.Q("entity_type"), c.QInt64("entity_id"), c.Q("emoji")
	ctx := c.Context()
	res, ok := reactionTargets[typ]
	if !ok {
		return badReq("Неизвестный тип объекта")
	}
	if _, err := res(ctx, s, c.U, id); err != nil {
		return err
	}
	_, per, off := c.Page(30, 100)
	rows, err := s.db.Query(ctx, `SELECT r.user_id, u.full_name, u.avatar, r.emoji, r.created_at
		FROM reactions r JOIN users u ON u.id = r.user_id
		WHERE r.entity_type = $1 AND r.entity_id = $2 AND ($3 = '' OR r.emoji = $3)
		ORDER BY r.created_at DESC, r.user_id, r.emoji LIMIT $4 OFFSET $5`, typ, id, emoji, per+1, off)
	if err != nil {
		return err
	}
	defer rows.Close()
	type row struct {
		UserID int64     `json:"user_id"`
		Name   string    `json:"name"`
		Avatar string    `json:"avatar"`
		Emoji  string    `json:"emoji"`
		At     time.Time `json:"at"`
	}
	items := []row{}
	for rows.Next() {
		var r row
		if err := rows.Scan(&r.UserID, &r.Name, &r.Avatar, &r.Emoji, &r.At); err != nil {
			return err
		}
		items = append(items, r)
	}
	if err := rows.Err(); err != nil {
		return err
	}
	more := len(items) > per
	if more {
		items = items[:per]
	}
	m, err := s.reactionsFor(ctx, c.U.ID, typ, []int64{id})
	if err != nil {
		return err
	}
	tot := m[id]
	if tot == nil {
		tot = []rxItem{}
	}
	return c.JSON(200, map[string]any{"items": items, "has_more": more, "reactions": tot})
}

// toggleLike — совместимость со старым POST /api/likes: лайк = реакция 👍.
func (s *Server) toggleLike(c *Ctx) error {
	var in struct {
		Type string `json:"entity_type"`
		ID   int64  `json:"entity_id"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if in.Type != "news" && in.Type != "idea" && in.Type != "post" {
		return badReq("Неизвестный тип")
	}
	r, err := s.setReaction(c.Context(), c.U, in.Type, in.ID, likeEmoji, nil)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"liked": r.On, "count": r.Likes, "reactions": r.Items})
}

// registerSocial — реакции, закладки, упоминания (social_*.go).
func (s *Server) registerSocial(m *http.ServeMux) {
	const U = "user"
	m.HandleFunc("POST /api/reactions", s.h(U, s.reactionSet))
	m.HandleFunc("GET /api/reactions", s.h(U, s.reactionGet))
	m.HandleFunc("GET /api/reactions/users", s.h(U, s.reactionUsers))
	m.HandleFunc("POST /api/bookmarks", s.h(U, s.bookmarkToggle))
	m.HandleFunc("PUT /api/bookmarks", s.h(U, s.bookmarkNote))
	m.HandleFunc("GET /api/bookmarks", s.h(U, s.bookmarkList))
	m.HandleFunc("GET /api/bookmarks/state", s.h(U, s.bookmarkState))
	m.HandleFunc("GET /api/mentions/suggest", s.h(U, s.mentionSuggest))
	m.HandleFunc("GET /api/mentions/resolve", s.h(U, s.mentionResolve))
}

// subGroup подписывает сокет на события группы (реакции), если пользователь вправе читать её ленту.
func (c *Client) subGroup(topic string) {
	gid, err := strconv.ParseInt(topic[len("group:"):], 10, 64)
	if err != nil || gid <= 0 {
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	s := c.hub.s
	u, err := s.loadUser(ctx, c.uid)
	if err != nil || u == nil {
		return
	}
	g, err := s.groupInfo(ctx, gid, u)
	if err != nil || !g.canRead(u) {
		return
	}
	c.hub.sub(c, topic)
}
