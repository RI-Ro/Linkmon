package server

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

type sd struct {
	ctx context.Context
	tx  pgx.Tx
}

func (d sd) exec(q string, a ...any) {
	if _, err := d.tx.Exec(d.ctx, q, a...); err != nil {
		panic(fmt.Errorf("%w\nSQL: %s", err, q))
	}
}

func (d sd) id(q string, a ...any) int64 {
	var id int64
	if err := d.tx.QueryRow(d.ctx, q, a...).Scan(&id); err != nil {
		panic(fmt.Errorf("%w\nSQL: %s", err, q))
	}
	return id
}

var seedImgs = []string{
	"https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=1200&q=80",
	"https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1200&q=80",
	"https://images.unsplash.com/photo-1518609878373-06d740f60d8b?auto=format&fit=crop&w=1200&q=80",
	"https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=1200&q=80",
	"https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=1200&q=80",
}

// Seed fills an empty database. It is serialised with an advisory lock, so when
// several instances start together exactly one of them does the work.
func (s *Server) Seed(ctx context.Context) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("%v", r)
		}
	}()
	adminHash, err := hashPassword(s.cfg.AdminPassword)
	if err != nil {
		return err
	}
	demoHash, err := hashPassword("corpnet123")
	if err != nil {
		return err
	}
	return s.tx(ctx, func(tx pgx.Tx) error {
		d := sd{ctx, tx}
		d.exec(`SELECT pg_advisory_xact_lock(7243902)`)
		var n int
		if err := tx.QueryRow(ctx, `SELECT count(*) FROM users`).Scan(&n); err != nil {
			return err
		}
		if n > 0 {
			return nil
		}
		s.log.Info("seeding database", "demo", s.cfg.SeedDemo)
		s.seedBase(d, adminHash)
		if s.cfg.SeedDemo {
			s.seedDemo(d, adminHash, demoHash)
		}
		return nil
	})
}

var seedCats = [][2]string{{"Компания", "#286b9e"}, {"IT", "#7c5cff"}, {"Мероприятия", "#e8590c"}, {"Проекты", "#2f9e44"}, {"HR", "#d6336c"}}

func (s *Server) seedBase(d sd, adminHash string) {
	d.exec(`UPDATE company SET about = $1, address = $2, phone = $3, email = $4, founded = 2014 WHERE id = 1`,
		"Единое пространство для внутренних новостей, коммуникаций, документов, календарей и медиаматериалов компании.",
		"Москва, Пресненская наб., 12 · Главный офис", "+7 495 000-00-00", "info@corpnet.local")
	for i, c := range seedCats {
		d.exec(`INSERT INTO categories (name, color, sort) VALUES ($1, $2, $3)`, c[0], c[1], i)
	}
	d.exec(`INSERT INTO calendars (name, description, kind, color, visibility, open_add) VALUES
		('Дни рождения', 'Дни рождения сотрудников', 'birthdays', '#d6336c', 'company', false),
		('Видеоконференции', 'Запланированные видеоконференции', 'conference', '#7c5cff', 'company', true),
		('Мероприятия', 'Праздники, турниры и события компании (редакторы могут добавлять)', 'custom', '#e8590c', 'company', false)`)
	d.exec(`INSERT INTO folders (kind, name, description, visibility) VALUES ('documents', 'Общие', 'Общие документы компании', 'company')`)
	if !s.cfg.SeedDemo {
		id := d.id(`INSERT INTO users (login, email, password_hash, first_name, last_name, job_title, role) VALUES ('admin', $1, $2, 'Администратор', 'Системы', 'Администратор портала', 'admin') RETURNING id`,
			s.cfg.AdminEmail, adminHash)
		d.exec(`INSERT INTO calendars (name, kind, owner_id, visibility) VALUES ('Мой календарь', 'personal', $1, 'restricted')`, id)
	}
}

type seedUser struct {
	first, last, slug, title, dept, role, bday string
}

var seedUsers = []seedUser{
	{"Алексей", "Морозов", "alexey.morozov", "Руководитель проектов", "it", "admin", "03-14"},
	{"Елена", "Соколова", "elena.sokolova", "HR Business Partner", "hr", "editor", "10-03"},
	{"Илья", "Кузнецов", "ilya.kuznetsov", "Backend Developer", "dev", "user", "07-21"},
	{"Ольга", "Васильева", "olga.vasilieva", "Финансовый директор", "fin", "user", "11-02"},
	{"Дмитрий", "Фёдоров", "dmitry.fedorov", "Руководитель отдела продаж", "sales", "user", "05-30"},
	{"Мария", "Орлова", "maria.orlova", "Менеджер по корпоративным коммуникациям", "comm", "editor", "10-01"},
	{"Сергей", "Волков", "sergey.volkov", "Product Manager", "it", "editor", "01-17"},
	{"Наталья", "Белова", "natalia.belova", "Финансовый аналитик", "fp", "user", "09-09"},
	{"Андрей", "Новиков", "andrey.novikov", "Генеральный директор", "gen", "user", "04-04"},
	{"Татьяна", "Лебедева", "tatiana.lebedeva", "Директор по персоналу", "hr", "user", "12-12"},
	{"Павел", "Козлов", "pavel.kozlov", "Frontend Developer", "dev", "user", "10-05"},
	{"Екатерина", "Морозова", "ekaterina.morozova", "QA Engineer", "dev", "user", "02-27"},
	{"Владимир", "Попов", "vladimir.popov", "DevOps Engineer", "infra", "user", "06-15"},
	{"Анастасия", "Смирнова", "anastasia.smirnova", "Data Analyst", "analytics", "user", "08-08"},
	{"Юлия", "Кузьмина", "yulia.kuzmina", "Главный бухгалтер", "acc", "user", "03-03"},
	{"Александр", "Соловьёв", "alexander.solovyov", "Бухгалтер", "acc", "user", "10-20"},
	{"Ирина", "Григорьева", "irina.grigorieva", "Менеджер по работе с ключевыми клиентами", "kam", "user", "11-23"},
	{"Максим", "Зайцев", "maxim.zaitsev", "Региональный менеджер", "reg", "user", "09-30"},
	{"Анна", "Петрова", "anna.petrova", "Специалист по подбору персонала", "hrs", "user", "10-12"},
	{"Роман", "Борисов", "roman.borisov", "Системный администратор", "infra", "user", "05-05"},
	{"Виктория", "Крылова", "victoria.krylova", "Корпоративный юрист", "adm", "user", "07-07"},
	{"Николай", "Орлов", "nikolay.orlov", "Руководитель направления стратегии", "strat", "user", "12-30"},
	{"Светлана", "Медведева", "svetlana.medvedeva", "Офис-менеджер", "adm", "user", "01-29"},
	{"Артём", "Жуков", "artem.zhukov", "Менеджер по продажам", "kam", "user", "10-27"},
	{"Дарья", "Комарова", "daria.komarova", "Дизайнер интерфейсов", "it", "user", "04-18"},
	{"Кирилл", "Щербаков", "kirill.shcherbakov", "Системный аналитик", "analytics", "user", "06-02"},
	{"Полина", "Егорова", "polina.egorova", "SMM-менеджер", "comm", "user", "08-21"},
	{"Григорий", "Тихонов", "grigory.tikhonov", "Менеджер по продажам", "reg", "user", "02-14"},
	{"Алина", "Фролова", "alina.frolova", "Специалист по обучению", "hrs", "user", "11-11"},
	{"Егор", "Антонов", "egor.antonov", "Руководитель отдела разработки", "dev", "user", "09-19"},
	{"Лариса", "Дмитриева", "larisa.dmitrieva", "Экономист", "fp", "user", "03-25"},
	{"Борис", "Королёв", "boris.korolev", "Специалист по информационной безопасности", "infra", "user", "12-05"},
	{"Валерия", "Киселёва", "valeria.kiseleva", "Бизнес-аналитик", "analytics", "user", "07-30"},
	{"Фёдор", "Макаров", "fedor.makarov", "Менеджер по закупкам", "adm", "user", "05-18"},
	{"Оксана", "Богданова", "oksana.bogdanova", "Руководитель проектов", "it", "user", "10-08"},
}

type seedNews struct {
	title, summary, body string
	cat, author, cover   int
	important, pinned    bool
	dir                  string
}

var seedNewsList = []seedNews{
	{"Компания запускает новую программу развития сотрудников",
		"Бесплатное обучение, менторство и внутренние карьерные треки для всех подразделений стартуют с октября.",
		"С 1 октября в компании стартует программа развития сотрудников. Она объединяет профессиональное обучение, наставничество и карьерные треки внутри подразделений.\n\n## Что входит в программу\n\n- Бюджет на внешнее обучение: до 60 000 ₽ на сотрудника в год\n- Внутренние курсы и мастер-классы от коллег-экспертов\n- Индивидуальный план развития, согласованный с руководителем\n- Доступ к библиотеке онлайн-курсов\n\nЗаявки принимаются через HR Business Partner вашего подразделения. Подробности и шаблон плана развития — в разделе «Документы».",
		4, 1, 0, true, true, "hr"},
	{"Обновление корпоративного портала",
		"Новый интерфейс, быстрый поиск, мессенджер и календарь — всё в одном месте.",
		"Мы обновили корпоративный портал: он стал заметно быстрее, а поиск теперь работает по новостям, сотрудникам, подразделениям и документам одновременно.\n\n## Что нового\n\n- Мессенджер с личными и групповыми чатами\n- Календари с повторяющимися событиями и списком\n- Комментарии и реакции под новостями\n- Уведомления в реальном времени\n\nЕсли вы заметили ошибку или хотите предложить улучшение — напишите в группу **IT Community**.",
		1, 6, 3, true, false, "it"},
	{"Осенний корпоративный турнир",
		"Футбол, настольный теннис и киберспорт: регистрируйте команды до 10 октября.",
		"Приглашаем всех сотрудников принять участие в осеннем корпоративном турнире. Соревнования пройдут в субботу на спортивной площадке рядом с офисом.\n\nДисциплины: мини-футбол, настольный теннис, дартс и киберспортивный турнир. Для болельщиков будет организована зона отдыха с горячими напитками.\n\nРегистрация команд — в группе «Спорт и активный отдых».",
		2, 5, 2, false, false, ""},
	{"Новый проект: автоматизация внутренних заявок",
		"Единая система заявок заменит почту и таблицы: пилот запускаем в ноябре.",
		"Команда цифровой трансформации начинает проект по автоматизации внутренних заявок: на IT-поддержку, закупки, доступы и командировки.\n\nЦель — сократить среднее время обработки заявки с трёх рабочих дней до одного. Пилот пройдёт в подразделениях IT и HR, затем решение будет масштабировано на всю компанию.\n\nУчастники проектной группы будут объявлены на этой неделе.",
		3, 6, 3, false, false, "it"},
	{"Изменение графика работы офиса",
		"С 15 октября офис открывается в 8:00 и закрывается в 20:00.",
		"По результатам опроса сотрудников мы расширяем часы работы офиса: с 15 октября он будет открыт с 8:00 до 20:00 в будние дни.\n\nГибкое начало рабочего дня остаётся доступным по согласованию с руководителем. Расписание встреч в календаре тоже учитывает новые часы.",
		0, 22, 4, false, false, ""},
	{"Итоги квартала и планы подразделений",
		"Выручка выросла на 18%, три ключевых проекта завершены в срок.",
		"Подведены итоги третьего квартала. Выручка компании выросла на 18% по сравнению с аналогичным периодом прошлого года, операционная маржа — на 2,4 п.п.\n\n## Ключевые достижения\n\n- Запущено два новых продукта\n- Завершена миграция инфраструктуры\n- Реализована программа адаптации новых сотрудников\n\nПланы подразделений на четвёртый квартал обсудим на видеоконференции — приглашение уже в вашем календаре.",
		0, 8, 1, true, false, "fin"},
	{"График отпусков руководителей теперь на портале",
		"Даты отпусков, заместители и город пребывания — в новом разделе «Отпуска».",
		"В разделе «Отпуска» опубликован график отпусков руководящего состава: даты, замещающий сотрудник и город, в котором находится руководитель.\n\nГрафик ведёт HR-директор. Если вы замещаете руководителя, получите уведомление.",
		0, 23, 4, false, false, ""},
	{"Обновлены материалы базы знаний",
		"Актуализированы регламенты по информационной безопасности и работе с клиентами.",
		"Мы обновили материалы базы знаний: актуализированы регламенты по информационной безопасности, работе с персональными данными и обслуживанию ключевых клиентов.\n\nПросим всех сотрудников ознакомиться с обновлёнными документами до конца месяца. Ознакомление отмечается в профиле.",
		1, 32, 0, false, false, "it"},
	{"Корпоративный день открытых дверей",
		"Приглашаем сотрудников с семьями познакомиться с офисом и командами.",
		"В субботу, 17 октября, в главном офисе пройдёт день открытых дверей. Для детей подготовлена творческая программа, для взрослых — экскурсии по подразделениям и встреча с руководством.\n\nПожалуйста, зарегистрируйтесь заранее в разделе «Календарь», чтобы мы могли подготовить пропуска.",
		2, 5, 4, false, false, ""},
	{"Новая программа наставничества",
		"Опытные сотрудники помогут новичкам быстрее вникнуть в процессы и культуру.",
		"Стартует программа наставничества: каждому новому сотруднику будет назначен наставник из смежного подразделения. Он поможет разобраться в процессах, познакомит с коллегами и ответит на вопросы первых месяцев.\n\nСтать наставником можно, отправив заявку в HR. Для наставников предусмотрены корпоративные бонусы и бесплатное обучение коучингу.",
		4, 18, 0, false, false, "hr"},
	{"Итоги внутреннего опроса",
		"87% сотрудников довольны условиями работы. Главная точка роста — внутренние коммуникации.",
		"Завершился ежегодный опрос вовлечённости. В нём приняли участие 94% сотрудников. Уровень удовлетворённости условиями работы составил 87%.\n\n## Что просили улучшить\n\n- Прозрачность принятия решений\n- Скорость обмена информацией между подразделениями\n- Возможности карьерного роста\n\nПодробный отчёт и план действий опубликованы в разделе «Документы».",
		4, 1, 1, false, false, "hr"},
	{"График праздничных мероприятий",
		"Новогодний корпоратив, детский утренник и благотворительная ярмарка — даты уже известны.",
		"Мы подготовили график праздничных мероприятий на конец года. Новогодний корпоратив состоится 19 декабря, детский утренник — 21 декабря, а благотворительная ярмарка — 24 декабря.\n\nСледите за обновлениями в календаре «Мероприятия» и группе «Корпоративные коммуникации».",
		2, 26, 2, false, false, ""},
}

func (s *Server) seedDemo(d sd, adminHash, demoHash string) {
	now := time.Now()
	at := func(day, h, m int) time.Time {
		t := now.AddDate(0, 0, day)
		return time.Date(t.Year(), t.Month(), t.Day(), h, m, 0, 0, t.Location())
	}

	// ---- departments
	dep := map[string]int64{}
	type dd struct {
		key, name, parent string
		img               int
	}
	for i, x := range []dd{
		{"gen", "Генеральная дирекция", "", 4}, {"it", "IT и цифровая трансформация", "", 3}, {"hr", "HR и корпоративные коммуникации", "", 0},
		{"fin", "Финансы", "", 1}, {"sales", "Продажи", "", 2},
		{"strat", "Стратегия", "gen", 4}, {"adm", "Администрация", "gen", 4},
		{"dev", "Разработка", "it", 3}, {"infra", "Инфраструктура", "it", 3}, {"analytics", "Аналитика", "it", 3},
		{"hrs", "HR", "hr", 0}, {"comm", "Корпоративные коммуникации", "hr", 0},
		{"acc", "Бухгалтерия", "fin", 1}, {"fp", "Финансовое планирование", "fin", 1},
		{"kam", "Ключевые клиенты", "sales", 2}, {"reg", "Региональные продажи", "sales", 2},
	} {
		var parent any
		if x.parent != "" {
			parent = dep[x.parent]
		}
		dep[x.key] = d.id(`INSERT INTO departments (name, parent_id, image, sort) VALUES ($1, $2, $3, $4) RETURNING id`, x.name, parent, seedImgs[x.img], (i+1)*10)
	}
	for k, txt := range map[string]string{
		"it":  "## Чем занимается подразделение\n\nМы отвечаем за **цифровые продукты**, инфраструктуру и информационную безопасность компании.\n\n- Разработка и поддержка внутренних систем\n- *Эксплуатация* серверов, сетей и рабочих мест\n- Аналитика данных и отчётность\n\n### Контакты\n\nСлужба поддержки: **support@corpnet.local**",
		"hr":  "## HR и корпоративные коммуникации\n\nПодбор и развитие персонала, адаптация, **внутренние коммуникации** и корпоративные мероприятия.\n\n1. Подбор и онбординг\n2. Обучение и развитие\n3. Корпоративная культура",
		"fin": "## Финансы\n\nБюджетирование, бухгалтерский и управленческий учёт, **финансовое планирование** и отчётность.",
	} {
		d.exec(`UPDATE departments SET description = $2 WHERE id = $1`, dep[k], txt)
	}

	// ---- users (+ personal calendars)
	uid := make([]int64, len(seedUsers))
	female := map[string]bool{"Елена": true, "Ольга": true, "Мария": true, "Наталья": true, "Татьяна": true, "Екатерина": true, "Анастасия": true, "Юлия": true,
		"Ирина": true, "Анна": true, "Виктория": true, "Светлана": true, "Дарья": true, "Полина": true, "Алина": true, "Лариса": true, "Валерия": true, "Оксана": true}
	patr := []string{"Александрович", "Сергеевич", "Иванович", "Петрович", "Андреевич", "Викторович", "Николаевич", "Дмитриевич", "Павлович", "Михайлович"}
	heads := map[int]bool{0: true, 3: true, 4: true, 8: true, 9: true, 22: true, 29: true}
	for i, u := range seedUsers {
		email, h, login := u.slug+"@corpnet.local", demoHash, u.slug
		if i == 0 {
			email, h, login = s.cfg.AdminEmail, adminHash, "admin"
		}
		mid := patr[(i*3)%len(patr)]
		if female[u.first] {
			mid = strings.TrimSuffix(mid, "ич") + "на"
		}
		year := 1980 + (i*7)%20
		uid[i] = d.id(`INSERT INTO users (login, email, password_hash, first_name, last_name, middle_name, job_title, extra_info, department_id, role,
				phone1, phone2, phone3, birthday, is_head, can_vacations, company_news)
			VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14::date, $15, $16, $17) RETURNING id`,
			login, email, h, u.first, u.last, mid, u.title, "Работаю в компании с удовольствием. Пишите — всегда рад помочь.", dep[u.dept], u.role,
			fmt.Sprintf("+7 495 000-%02d-%02d", 10+i, 20+i), fmt.Sprintf("+7 916 %03d-%02d-%02d", 100+i, 10+i, 30+i), "",
			fmt.Sprintf("%d-%s", year, u.bday), heads[i], i == 9, i == 5)
		d.exec(`INSERT INTO calendars (name, kind, owner_id, visibility, color) VALUES ('Мой календарь', 'personal', $1, 'restricted', '#286b9e')`, uid[i])
	}
	for k, who := range map[string]int{"gen": 8, "it": 0, "hr": 9, "fin": 3, "sales": 4, "dev": 29, "comm": 5} {
		d.exec(`UPDATE departments SET head_id = $2 WHERE id = $1`, dep[k], uid[who])
	}

	// ---- directions
	dir := map[string]int64{}
	for i, x := range []struct {
		key, name string
		subs      []string
		img       int
	}{
		{"hr", "HR", []string{"Приём на работу", "Адаптация и воспитание", "Тесты", "Корпоративная культура"}, 0},
		{"it", "IT", []string{"Разработка", "Инфраструктура", "Информационная безопасность"}, 3},
		{"sales", "Продажи", []string{"Продукты", "Работа с клиентами", "Обучение продажам"}, 2},
		{"fin", "Финансы", []string{"Бюджетирование", "Отчётность", "Финансовое планирование"}, 1},
	} {
		dir[x.key] = d.id(`INSERT INTO directions (name, description, cover, sort, department_id) VALUES ($1, 'Направление деятельности с подразделами, новостями и материалами', $2, $3, $4) RETURNING id`,
			x.name, seedImgs[x.img], (i+1)*10, dep[x.key])
		for j, sub := range x.subs {
			d.exec(`INSERT INTO directions (parent_id, name, description, sort) VALUES ($1, $2, 'Новости, документы, фото и видео раздела', $3)`, dir[x.key], sub, (j+1)*10)
		}
	}

	// ---- news
	catID := map[int]int64{}
	rows, err := d.tx.Query(d.ctx, `SELECT id FROM categories ORDER BY sort`)
	if err != nil {
		panic(err)
	}
	for i := 0; rows.Next(); i++ {
		var id int64
		rows.Scan(&id)
		catID[i] = id
	}
	rows.Close()
	for i, n := range seedNewsList {
		var directionID any
		if n.dir != "" {
			directionID = dir[n.dir]
		}
		d.exec(`INSERT INTO news (title, summary, body, category_id, author_id, cover, important, pinned, direction_id, department_id, published_at)
			VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
			n.title, n.summary, n.body, catID[n.cat], uid[n.author], seedImgs[n.cover], n.important, n.pinned, directionID,
			dep[seedUsers[n.author].dept], now.Add(-time.Duration(i*19+2)*time.Hour))
	}
	d.exec(`INSERT INTO reactions (entity_type, entity_id, user_id, emoji) SELECT 'news', n.id, u.id, '👍' FROM news n JOIN users u ON (n.id * 7 + u.id) % 3 = 0`)
	d.exec(`UPDATE news n SET likes_count = (SELECT count(*) FROM reactions l WHERE l.entity_type = 'news' AND l.entity_id = n.id AND l.emoji = '👍'),
		views_count = 40 + (n.id * 37) % 260`)
	cm := func(nid int, who int, body string, parent any) int64 {
		return d.id(`INSERT INTO comments (entity_type, entity_id, user_id, parent_id, body, created_at)
			VALUES ('news', (SELECT id FROM news ORDER BY id LIMIT 1 OFFSET $1), $2, $3, $4, now() - interval '3 hours' * $5::int) RETURNING id`,
			nid, uid[who], parent, body, nid+1)
	}
	c1 := cm(0, 2, "Отличная инициатива! Подскажите, можно ли использовать бюджет на оплату зарубежных конференций?", nil)
	cm(0, 1, "Да, конференции входят в программу. Заявку согласуйте с руководителем и направьте мне.", c1)
	cm(0, 10, "Супер, давно ждали такого формата.", nil)
	c2 := cm(1, 12, "Поиск стал реально быстрее, спасибо команде!", nil)
	cm(1, 6, "Рады, что понравилось. Идеи по улучшению пишите в IT Community.", c2)
	cm(2, 23, "Записываем сборную отдела продаж!", nil)
	d.exec(`UPDATE news n SET comments_count = (SELECT count(*) FROM comments c WHERE c.entity_type = 'news' AND c.entity_id = n.id AND c.deleted_at IS NULL)`)

	// ---- groups
	type gg struct {
		name, desc, vis string
		cover, owner    int
		members         []int
		posts           []string
	}
	for _, g := range []gg{
		{"IT Community", "Обсуждение технологий, архитектуры и разработки", "public", 1, 0, []int{2, 6, 10, 11, 12, 24, 29, 31}, []string{
			"Коллеги, делимся полезными ссылками и докладами с последних конференций. Что смотрели интересного?",
			"В пятницу в 16:00 — внутренний митап по Go и PostgreSQL. Приходите, будет практика!"}},
		{"Корпоративные коммуникации", "Новости компании и внутренние мероприятия", "public", 0, 5, []int{1, 8, 9, 18, 26, 28, 22}, []string{
			"Готовим материалы к осеннему дню открытых дверей. Нужны фотографии с прошлых мероприятий!"}},
		{"Руководители проектов", "Рабочая группа руководителей проектов", "closed", 3, 0, []int{6, 34, 4}, []string{
			"Напоминаю: статусные отчёты по проектам нужно загрузить до четверга."}},
		{"Спорт и активный отдых", "Турниры, забеги и совместные активности", "public", 2, 4, []int{2, 11, 12, 17, 23, 27, 33}, []string{
			"Собираем команду на осенний корпоративный турнир! Пишите в комментариях, кто в деле.",
			"Утренние пробежки по вторникам и четвергам в парке рядом с офисом. Присоединяйтесь!"}},
	} {
		gid := d.id(`INSERT INTO user_groups (name, description, cover, visibility, owner_id) VALUES ($1, $2, $3, $4, $5) RETURNING id`, g.name, g.desc, seedImgs[g.cover], g.vis, uid[g.owner])
		chat := d.id(`INSERT INTO chats (kind, title, created_by, group_id) VALUES ('group', $1, $2, $3) RETURNING id`, g.name, uid[g.owner], gid)
		d.exec(`UPDATE user_groups SET chat_id = $2 WHERE id = $1`, gid, chat)
		d.exec(`INSERT INTO group_members (group_id, user_id, role) VALUES ($1, $2, 'owner')`, gid, uid[g.owner])
		d.exec(`INSERT INTO chat_members (chat_id, user_id) VALUES ($1, $2)`, chat, uid[g.owner])
		for _, m := range g.members {
			d.exec(`INSERT INTO group_members (group_id, user_id) VALUES ($1, $2)`, gid, uid[m])
			d.exec(`INSERT INTO chat_members (chat_id, user_id) VALUES ($1, $2)`, chat, uid[m])
		}
		if g.vis == "closed" { // a pending join request to demonstrate approval
			d.exec(`INSERT INTO group_members (group_id, user_id, role) VALUES ($1, $2, 'pending')`, gid, uid[13])
		}
		for i, p := range g.posts {
			author := g.owner
			if i > 0 && len(g.members) > 0 {
				author = g.members[i%len(g.members)]
			}
			d.exec(`INSERT INTO group_posts (group_id, user_id, body, created_at) VALUES ($1, $2, $3, now() - interval '5 hours' * $4::int)`, gid, uid[author], p, i+1)
		}
	}
	d.exec(`INSERT INTO comments (entity_type, entity_id, user_id, body) SELECT 'post', id, $1, 'Отличная идея, поддерживаю!' FROM group_posts WHERE group_id = (SELECT id FROM user_groups ORDER BY id LIMIT 1) LIMIT 1`, uid[2])
	d.exec(`UPDATE group_posts p SET comments_count = (SELECT count(*) FROM comments c WHERE c.entity_type = 'post' AND c.entity_id = p.id)`)

	// ---- calendars & events
	var adminCal, confCal int64
	adminCal = d.id(`SELECT id FROM calendars WHERE kind = 'personal' AND owner_id = $1`, uid[0])
	confCal = d.id(`SELECT id FROM calendars WHERE kind = 'conference'`)
	corpCal := d.id(`SELECT id FROM calendars WHERE name = 'Мероприятия'`)
	ev := func(cal int64, title, loc string, st, en time.Time, allDay bool, video string, creator int, att ...int) {
		id := d.id(`INSERT INTO events (calendar_id, title, location, starts_at, ends_at, all_day, video_url, creator_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id`,
			cal, title, loc, st, en, allDay, video, uid[creator])
		for _, a := range att {
			d.exec(`INSERT INTO event_attendees (event_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`, id, uid[a])
		}
	}
	ev(adminCal, "Планёрка команды", "", at(0, 10, 0), at(0, 10, 30), false, "", 0)
	ev(adminCal, "Ревью архитектуры портала", "", at(1, 14, 0), at(1, 15, 0), false, "", 0, 2, 6, 10)
	ev(adminCal, "Синхронизация с HR", "", at(3, 12, 0), at(3, 12, 45), false, "", 0, 1)
	ev(confCal, "Видеоконференция: итоги квартала", "Онлайн", at(2, 15, 0), at(2, 16, 30), false, "https://meet.jit.si/CorpNet-quarter-results", 8, 0, 1, 3, 4, 5, 6)
	ev(confCal, "Онбординг новых сотрудников", "Онлайн", at(5, 11, 0), at(5, 12, 0), false, "https://meet.jit.si/CorpNet-onboarding", 1, 0, 18, 28)
	ev(corpCal, "Осенний корпоративный турнир", "Спортивная площадка", at(9, 11, 0), at(9, 16, 0), false, "", 5)
	ev(corpCal, "День открытых дверей", "Главный офис", at(14, 0, 0), at(14, 23, 59), true, "", 5)
	// ежегодные события с повтором
	yearly := func(title string, month time.Month, day int) {
		st := time.Date(now.Year(), month, day, 0, 0, 0, 0, now.Location())
		d.exec(`INSERT INTO events (calendar_id, title, starts_at, ends_at, all_day, creator_id, rec_freq, rec_interval)
			VALUES ($1, $2, $3, $4, true, $5, 'yearly', 1)`, corpCal, title, st, st.Add(24*time.Hour-time.Second), uid[5])
	}
	yearly("Новый год", time.January, 1)
	yearly("День защитника Отечества", time.February, 23)
	yearly("Международный женский день", time.March, 8)
	yearly("День Победы", time.May, 9)
	yearly("День города", time.September, 7)
	d.exec(`INSERT INTO events (calendar_id, title, location, starts_at, ends_at, creator_id, rec_freq, rec_interval)
		VALUES ($1, 'Еженедельная планёрка', 'Онлайн', $2, $3, $4, 'weekly', 1)`, confCal, at(0, 9, 30), at(0, 10, 0), uid[0])
	d.exec(`INSERT INTO events (calendar_id, title, starts_at, ends_at, all_day, creator_id, rec_freq, rec_interval)
		VALUES ($1, 'Закрытие отчётного месяца', $2, $3, true, $4, 'monthly', 1)`, corpCal, at(3, 0, 0), at(3, 23, 59), uid[3])

	// ---- documents / media
	docsRoot := d.id(`SELECT id FROM folders WHERE kind = 'documents' AND name = 'Общие'`)
	reg := d.id(`INSERT INTO folders (kind, parent_id, name, description, owner_id) VALUES ('documents', $1, 'Регламенты', 'Внутренние регламенты и положения', $2) RETURNING id`, docsRoot, uid[0])
	pres := d.id(`INSERT INTO folders (kind, parent_id, name, description, owner_id) VALUES ('documents', $1, 'Презентации', 'Презентации компании', $2) RETURNING id`, docsRoot, uid[0])
	hrOnly := d.id(`INSERT INTO folders (kind, parent_id, name, description, visibility, owner_id) VALUES ('documents', $1, 'HR: личные дела', 'Доступ только HR и руководству', 'restricted', $2) RETURNING id`, docsRoot, uid[9])
	d.exec(`INSERT INTO acl (resource_type, resource_id, subject_type, subject_id, level) VALUES ('folder', $1, 'department', $2, 3), ('folder', $1, 'user', $3, 1)`, hrOnly, dep["hr"], uid[8])
	mk := func(folder int64, name, mime string, content []byte, owner int) {
		stg := randName(12) + strings.ToLower(filepath.Ext(name))
		if err := os.WriteFile(filepath.Join(s.dir(false), stg), content, 0o644); err != nil {
			panic(err)
		}
		d.exec(`INSERT INTO files (folder_id, owner_id, name, mime, size, storage) VALUES ($1, $2, $3, $4, $5, $6)`, folder, uid[owner], name, mime, len(content), stg)
	}
	for _, f := range []struct {
		folder int64
		name   string
	}{{reg, "Регламент внутреннего документооборота.pdf"}, {reg, "Положение о корпоративной культуре.pdf"}, {reg, "План развития IT 2026–2027.pdf"}, {pres, "Презентация компании 2026.pdf"}} {
		mk(f.folder, f.name, "application/pdf", demoPDF(strings.TrimSuffix(f.name, ".pdf")), 0)
	}
	mk(docsRoot, "Шаблон служебной записки.txt", "text/plain", []byte("СЛУЖЕБНАЯ ЗАПИСКА\n\nКому: ____\nОт: ____\nТема: ____\n\nТекст записки.\n"), 1)
	mk(docsRoot, "Контакты подразделений.csv", "text/csv", []byte("Подразделение;Телефон\nIT;+7 495 000-00-01\nHR;+7 495 000-00-02\nФинансы;+7 495 000-00-03\n"), 3)
	mk(hrOnly, "Образец личной карточки.txt", "text/plain", []byte("Образец личной карточки сотрудника (демо)\n"), 9)

	photoFolders := []struct {
		name, desc string
		img        int
		extra      []int
	}{
		{"HR и корпоративные коммуникации / Новости", "Материалы новостей подразделения", 0, []int{1, 4, 2}},
		{"HR и корпоративные коммуникации / Дни рождения", "Фотографии поздравлений", 1, []int{0, 3}},
		{"IT и цифровая трансформация / Новости", "Фото мероприятий IT", 3, []int{2, 1, 0, 4}},
		{"IT и цифровая трансформация / Мероприятия", "Архив материалов событий", 2, []int{3, 4, 1}},
	}
	for _, pf := range photoFolders {
		fid := d.id(`INSERT INTO folders (kind, name, description, cover, owner_id) VALUES ('photos', $1, $2, $3, $4) RETURNING id`, pf.name, pf.desc, seedImgs[pf.img], uid[5])
		for i, im := range append([]int{pf.img}, pf.extra...) {
			d.exec(`INSERT INTO files (folder_id, owner_id, name, mime, size, external_url, width, height) VALUES ($1, $2, $3, 'image/jpeg', 250000, $4, 1200, 800)`,
				fid, uid[5], fmt.Sprintf("photo-%02d.jpg", i+1), seedImgs[im])
		}
	}
	vid := d.id(`INSERT INTO folders (kind, name, description, owner_id) VALUES ('videos', 'Корпоративные мероприятия / Видео', 'Видеоматериалы событий компании', $1) RETURNING id`, uid[5])
	_ = vid

	// ---- resources
	for i, r := range [][4]string{
		{"Корпоративная Wiki", "База знаний и документация", "https://wiki.example.com", "book"},
		{"Service Desk", "Заявки в службу поддержки", "https://support.example.com", "briefcase"},
		{"CRM", "Работа с клиентами", "https://crm.example.com", "building"},
		{"Электронный документооборот", "Согласование и подписание документов", "https://edo.example.com", "file"},
	} {
		d.exec(`INSERT INTO resources (name, description, url, icon, sort) VALUES ($1, $2, $3, $4, $5)`, r[0], r[1], r[2], r[3], i)
	}

	// ---- chats
	msg := func(chat int64, from int, mins int, body string) {
		d.exec(`INSERT INTO messages (chat_id, user_id, body, created_at) VALUES ($1, $2, $3, now() - make_interval(mins => $4::int))`, chat, uid[from], body, mins)
	}
	direct := func(peer int, lines [][3]interface{}) int64 {
		lo, hi := uid[0], uid[peer]
		if lo > hi {
			lo, hi = hi, lo
		}
		c := d.id(`INSERT INTO chats (kind, direct_key, created_by) VALUES ('direct', $1, $2) RETURNING id`, fmt.Sprintf("%d:%d", lo, hi), uid[0])
		d.exec(`INSERT INTO chat_members (chat_id, user_id) VALUES ($1, $2), ($1, $3)`, c, uid[0], uid[peer])
		for _, l := range lines {
			who := 0
			if l[0].(bool) {
				who = peer
			}
			msg(c, who, l[1].(int), l[2].(string))
		}
		return c
	}
	direct(2, [][3]interface{}{{true, 240, "Привет! Отправил обновлённые материалы по API."}, {false, 235, "Отлично, посмотрю сегодня."}, {true, 12, "Если будут вопросы по схеме БД — пиши, объясню."}})
	direct(1, [][3]interface{}{{true, 600, "Алексей, добрый день! Нужно согласовать график адаптации новичков."}, {false, 580, "Добрый! Давайте в четверг после планёрки."}, {true, 30, "Договорились 👍"}})
	direct(6, [][3]interface{}{{true, 90, "Сергей: подготовил roadmap портала на следующий квартал."}, {true, 88, "Посмотришь до конца недели?"}})
	direct(5, [][3]interface{}{{false, 300, "Мария, нужны фото с последнего мероприятия для новости."}, {true, 290, "Конечно, загружу в медиаархив сегодня."}})
	gc := d.id(`INSERT INTO chats (kind, title, created_by) VALUES ('group', 'Проект: новый портал', $1) RETURNING id`, uid[0])
	for _, m := range []int{0, 2, 6, 10, 24} {
		d.exec(`INSERT INTO chat_members (chat_id, user_id) VALUES ($1, $2)`, gc, uid[m])
	}
	msg(gc, 0, 1500, "Коллеги, стартуем новый этап по порталу. Цели — скорость и удобство.")
	msg(gc, 24, 1400, "Подготовила обновлённые макеты, загрузила в медиаархив.")
	msg(gc, 10, 1380, "Посмотрел, по фронтенду вопросов нет — беру в работу.")
	msg(gc, 2, 120, "Бэкенд готов к нагрузочному тестированию, масштабируем до трёх инстансов.")
	d.exec(`UPDATE chats c SET last_message_id = m.id, last_message_at = m.created_at
		FROM (SELECT DISTINCT ON (chat_id) id, chat_id, created_at FROM messages ORDER BY chat_id, id DESC) m WHERE m.chat_id = c.id`)
	// mark everything read for everyone except a few unread messages for the admin
	d.exec(`UPDATE chat_members cm SET last_read_id = coalesce((SELECT last_message_id FROM chats WHERE id = cm.chat_id), 0)`)
	d.exec(`UPDATE chat_members cm SET last_read_id = (SELECT min(id) - 1 FROM messages m WHERE m.chat_id = cm.chat_id AND m.user_id <> cm.user_id
		AND m.created_at > now() - interval '15 minutes') WHERE cm.user_id = $1 AND EXISTS (SELECT 1 FROM messages m WHERE m.chat_id = cm.chat_id
		AND m.user_id <> cm.user_id AND m.created_at > now() - interval '15 minutes')`, uid[0])

	// ---- notifications for the admin (ссылки ведут на реальные страницы SPA — см. links.go)
	var mariaID, evID, hrFolder int64
	var hrKind string
	d.tx.QueryRow(d.ctx, `SELECT id FROM users WHERE login = 'maria.orlova'`).Scan(&mariaID)
	d.tx.QueryRow(d.ctx, `SELECT id FROM events WHERE title LIKE 'Видеоконференция%' ORDER BY id LIMIT 1`).Scan(&evID)
	d.tx.QueryRow(d.ctx, `SELECT id, kind FROM folders WHERE name = 'HR: личные дела' ORDER BY id LIMIT 1`).Scan(&hrFolder, &hrKind)
	evLink, accLink := "/calendar", "/documents"
	if evID != 0 {
		evLink = fmt.Sprintf("/calendar?event=%d", evID)
	}
	if hrFolder != 0 {
		accLink = fmt.Sprintf("/%s?folder=%d", hrKind, hrFolder)
	}
	for _, n := range [][4]string{
		{"comment", "Илья Кузнецов прокомментировал(а): Обновление корпоративного портала", "Поиск стал реально быстрее, спасибо команде!", "/news/2"},
		{"event", "Вас пригласили на событие: Видеоконференция: итоги квартала", "", evLink},
		{"access", "Вам открыт доступ к папке «HR: личные дела»", "", accLink},
		{"birthday", "Сегодня день рождения: Мария Орлова", "Менеджер по корпоративным коммуникациям", fmt.Sprintf("/people/%d", mariaID)},
	} {
		d.exec(`INSERT INTO notifications (user_id, kind, title, body, link, created_at) VALUES ($1, $2, $3, $4, $5, now() - interval '40 minutes' * (random() * 5 + 1))`, uid[0], n[0], n[1], n[2], n[3])
	}

	// ---- вложенные комментарии (до 5 уровней): нормализуем root_id/depth
	cmt := func(nid int, who int, body string, parent int64) int64 {
		var pd int
		root := int64(0)
		if parent != 0 {
			d.tx.QueryRow(d.ctx, `SELECT depth, root_id FROM comments WHERE id = $1`, parent).Scan(&pd, &root)
			pd++
		}
		id := d.id(`INSERT INTO comments (entity_type, entity_id, user_id, parent_id, root_id, depth, body, created_at)
			VALUES ('news', (SELECT id FROM news ORDER BY id LIMIT 1 OFFSET $1), $2, NULLIF($3::bigint, 0), NULLIF($4::bigint, 0), $5, $6, now() - interval '20 minutes') RETURNING id`,
			nid, uid[who], parent, root, pd, body)
		d.exec(`UPDATE comments SET root_id = id WHERE id = $1 AND root_id IS NULL`, id)
		return id
	}
	d.exec(`UPDATE comments SET root_id = id WHERE parent_id IS NULL AND root_id IS NULL`)
	d.exec(`UPDATE comments c SET root_id = p.root_id, depth = p.depth + 1 FROM comments p WHERE c.parent_id = p.id AND c.root_id IS NULL`)
	d.exec(`UPDATE comments c SET root_id = p.id, depth = 1 FROM comments p WHERE c.parent_id = p.id AND p.parent_id IS NULL AND c.depth = 0`)
	t0 := cmt(1, 3, "А как поиск ведёт себя на больших объёмах? У нас тысячи документов.", 0)
	t1 := cmt(1, 6, "Индексы построены по префиксам слов и триграммам — поиск остаётся быстрым и на миллионе записей.", t0)
	t2 := cmt(1, 3, "Отлично, проверим на реальных данных.", t1)
	t3 := cmt(1, 12, "Присоединяюсь к вопросу — расскажете подробнее на митапе?", t2)
	t4 := cmt(1, 6, "Конечно, в пятницу в 16:00.", t3)
	cmt(1, 3, "Спасибо! Буду.", t4)
	d.exec(`UPDATE news n SET comments_count = (SELECT count(*) FROM comments c WHERE c.entity_type = 'news' AND c.entity_id = n.id AND c.deleted_at IS NULL)`)

	// ---- новости: окно показа, скрытая, истёкшая; картинки внутри текста и галереи
	d.exec(`INSERT INTO news (title, summary, body, category_id, author_id, cover, status, department_id, published_at, announced)
		VALUES ('Анонс: открытие нового офиса (запланировано)', 'Эта новость появится автоматически завтра в 09:00.',
		'Подготовленная заранее новость: она **не видна читателям** до наступления времени показа и появится сама.', $1, $2, $3, 'published', $4, $5, false)`,
		catID[0], uid[5], seedImgs[4], dep["comm"], at(1, 9, 0))
	d.exec(`INSERT INTO news (title, summary, body, category_id, author_id, cover, status, hidden, department_id, published_at)
		VALUES ('Черновик объявления (скрыто с публикации)', 'Скрыта редактором — видна только в админке.', 'Текст пока не готов к публикации.', $1, $2, $3, 'published', true, $4, now() - interval '2 days')`,
		catID[0], uid[5], seedImgs[2], dep["comm"])
	d.exec(`INSERT INTO news (title, summary, body, category_id, author_id, cover, status, department_id, published_at, visible_until)
		VALUES ('Акция «Неделя здоровья» завершилась', 'Показ новости закончился вчера, в ленте её уже нет.', 'Спасибо всем участникам!', $1, $2, $3, 'published', $4, now() - interval '9 days', now() - interval '1 day')`,
		catID[2], uid[1], seedImgs[1], dep["hr"])
	d.exec(`UPDATE news SET body = body || $1 WHERE title = 'Обновление корпоративного портала'`,
		"\n\n## Как это выглядит\n\n![Новый интерфейс портала]("+seedImgs[0]+"){w=60%}\n\nФотографии можно вставлять в текст в любом количестве и задавать им размер — например, **половину ширины**:\n\n![Команда за работой]("+seedImgs[2]+"){w=50%}\n\nА это узкая картинка фиксированной ширины 320 px: ![Офис]("+seedImgs[4]+"){w=320}")
	var vidFolder int64
	d.tx.QueryRow(d.ctx, `SELECT id FROM folders WHERE kind = 'videos' LIMIT 1`).Scan(&vidFolder)
	d.exec(`INSERT INTO files (folder_id, owner_id, name, mime, size, external_url) VALUES ($1, $2, 'Обзор нового портала.mp4', 'video/mp4', 1000000,
		'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4')`, vidFolder, uid[5])
	d.exec(`INSERT INTO news_galleries (news_id, folder_id, title, sort)
		SELECT n.id, f.id, 'Фотоотчёт: ' || f.name, 0 FROM news n, folders f WHERE n.title = 'Обновление корпоративного портала' AND f.kind = 'photos' ORDER BY f.id LIMIT 1`)
	d.exec(`INSERT INTO news_galleries (news_id, folder_id, title, sort)
		SELECT n.id, $1, 'Видео: знакомство с порталом', 1 FROM news n WHERE n.title = 'Обновление корпоративного портала'`, vidFolder)

	// ---- группы: скрытая и администратор группы
	secret := d.id(`INSERT INTO user_groups (name, description, cover, visibility, owner_id) VALUES ('Совет директоров', 'Скрытая группа: нет в списках, участников добавляет только администратор группы', $1, 'secret', $2) RETURNING id`, seedImgs[3], uid[8])
	schat := d.id(`INSERT INTO chats (kind, title, created_by, group_id) VALUES ('group', 'Совет директоров', $1, $2) RETURNING id`, uid[8], secret)
	d.exec(`UPDATE user_groups SET chat_id = $2 WHERE id = $1`, secret, schat)
	d.exec(`INSERT INTO group_members (group_id, user_id, role) VALUES ($1, $2, 'owner'), ($1, $3, 'admin'), ($1, $4, 'member'), ($1, $5, 'member')`, secret, uid[8], uid[0], uid[3], uid[9])
	d.exec(`INSERT INTO chat_members (chat_id, user_id) VALUES ($1, $2), ($1, $3), ($1, $4), ($1, $5)`, schat, uid[8], uid[0], uid[3], uid[9])
	d.exec(`INSERT INTO group_posts (group_id, user_id, body) VALUES ($1, $2, 'Повестка ближайшего совета: бюджет следующего года и стратегия развития.')`, secret, uid[8])
	d.exec(`UPDATE group_members SET role = 'admin' WHERE role = 'member' AND user_id = $1 AND group_id = (SELECT id FROM user_groups WHERE name = 'IT Community')`, uid[6])

	// ---- голосование в групповом чате
	var itChat int64
	d.tx.QueryRow(d.ctx, `SELECT chat_id FROM user_groups WHERE name = 'IT Community'`).Scan(&itChat)
	pm := d.id(`INSERT INTO messages (chat_id, user_id, body, kind) VALUES ($1, $2, 'Когда проводим внутренний митап?', 'poll') RETURNING id`, itChat, uid[0])
	pid := d.id(`INSERT INTO polls (chat_id, message_id, question, multiple, created_by) VALUES ($1, $2, 'Когда проводим внутренний митап?', false, $3) RETURNING id`, itChat, pm, uid[0])
	var opts []int64
	for i, t := range []string{"В пятницу в 16:00", "В четверг в 12:00", "Через неделю"} {
		opts = append(opts, d.id(`INSERT INTO poll_options (poll_id, text, sort) VALUES ($1, $2, $3) RETURNING id`, pid, t, i))
	}
	for i, who := range []int{2, 6, 10, 11} {
		d.exec(`INSERT INTO poll_votes (poll_id, option_id, user_id, voted_at) VALUES ($1, $2, $3, now() - interval '7 minutes' * $4::int)`, pid, opts[i%2], uid[who], i+1)
	}
	d.exec(`UPDATE chats SET last_message_id = $2, last_message_at = now() WHERE id = $1`, itChat, pm)

	// ---- баннеры
	var impNews, grpID int64
	d.tx.QueryRow(d.ctx, `SELECT id FROM news WHERE title LIKE 'Компания запускает%'`).Scan(&impNews)
	d.tx.QueryRow(d.ctx, `SELECT id FROM user_groups WHERE name = 'Спорт и активный отдых'`).Scan(&grpID)
	d.exec(`INSERT INTO banners (title, text, image, link, link_label, sort, created_by) VALUES
		('Программа развития сотрудников', 'Бесплатное обучение, менторство и карьерные треки — старт с октября.', $1, '/news/' || $3::bigint::text, 'Читать новость', 10, $5),
		('Осенний корпоративный турнир', 'Футбол, настольный теннис и киберспорт. Регистрация команд до 10 октября.', $2, '/groups/' || $4::bigint::text, 'Записать команду', 20, $5)`,
		seedImgs[1], seedImgs[2], impNews, grpID, uid[0])

	// ---- график отпусков (только для руководящего состава)
	for i, v := range [][5]interface{}{
		{8, -2, 12, 0, "Сочи"}, {3, 6, 20, 9, "Москва"}, {4, 15, 29, 22, "Казань"}, {9, 30, 44, 1, "Санкт-Петербург"}, {29, 3, 16, 6, "Новосибирск"},
	} {
		d.exec(`INSERT INTO vacations (user_id, starts_on, ends_on, deputy_id, city, created_by) VALUES ($1, current_date + $2::int, current_date + $3::int, $4, $5, $6)`,
			uid[v[0].(int)], v[1], v[2], uid[v[3].(int)], v[4], uid[9])
		_ = i
	}

	// ---- «Есть идея»
	for i, it := range [][2]string{
		{"Мобильное приложение портала", "Хочется получать уведомления и писать в чат с телефона. Можно начать с PWA: иконка на рабочем столе и push-уведомления."},
		{"Единый график переговорных в календаре", "Показывать занятость переговорных комнат прямо в календаре подразделения, чтобы не писать в чат."},
		{"Кофе-точки: встречи случайных коллег", "Раз в две недели портал предлагает коллегам из разных подразделений выпить кофе вместе."},
	} {
		iid := d.id(`INSERT INTO ideas (title, body, author_id, created_at) VALUES ($1, $2, $3, now() - interval '1 day' * $4::int) RETURNING id`,
			it[0], it[1], uid[[]int{2, 10, 12}[i]], i+1)
		d.exec(`INSERT INTO reactions (entity_type, entity_id, user_id, emoji) SELECT 'idea', $1, id, '👍' FROM users WHERE (id + $1) % 3 = 0`, iid)
		d.exec(`INSERT INTO comments (entity_type, entity_id, user_id, body, root_id, depth) VALUES ('idea', $1, $2, 'Поддерживаю! Было бы очень удобно.', NULL, 0)`, iid, uid[(i*5+3)%len(uid)])
		d.exec(`UPDATE comments SET root_id = id WHERE entity_type = 'idea' AND root_id IS NULL`)
		d.exec(`UPDATE ideas i SET likes_count = (SELECT count(*) FROM reactions l WHERE l.entity_type = 'idea' AND l.entity_id = i.id AND l.emoji = '👍'),
			comments_count = (SELECT count(*) FROM comments c WHERE c.entity_type = 'idea' AND c.entity_id = i.id AND c.deleted_at IS NULL), views_count = 20 + i.id * 13 WHERE i.id = $1`, iid)
	}

	// ---- уведомления с переходом на событие (комментарий, группа, идея …)
	var cid int64
	d.tx.QueryRow(d.ctx, `SELECT id FROM comments WHERE entity_type = 'news' ORDER BY id LIMIT 1`).Scan(&cid)
	for i := 0; i < 24; i++ {
		d.exec(`INSERT INTO notifications (user_id, kind, title, body, link, created_at) VALUES ($1, 'comment', $2, $3, $4, now() - interval '1 hour' * $5::int)`,
			uid[0], fmt.Sprintf("Коллега %d прокомментировал(а): Программа развития", i+1), "Спасибо за информацию, очень полезно!", fmt.Sprintf("/news/%d#comment-%d", impNews, cid), 3+i)
	}
	d.exec(`INSERT INTO notifications (user_id, kind, title, body, link, created_at, read_at) VALUES ($1, 'group', 'Ваша заявка в группу одобрена', '', $2, now() - interval '2 days', now() - interval '1 day')`,
		uid[0], fmt.Sprintf("/groups/%d", grpID))
	d.exec(`INSERT INTO audit_log (user_id, action, entity, data) VALUES ($1, 'system.seed', 'system', '{"demo":true}')`, uid[0])
	s.seedLearning(d, uid, dep) // демо-данные раздела «Обучение» (seed_learning.go)
	s.seedRequests(d, uid, dep) // шаблоны раздела «Заявки» (seed_requests.go)
	s.seedLMS(d, uid, dep)      // демо-данные LMS: курсы, назначения, сертификаты (seed_lms.go)
	s.seedWiki(d, uid, dep)     // демо-базы знаний (seed_wiki.go)
	s.seedAnalytics(d)          // демо-данные аналитики (seed_analytics.go)
	s.seedSocial(d, uid)        // демо-реакции, закладки, упоминания (seed_social.go)
}

// demoPDF builds a tiny valid single-page PDF (ASCII text only).
func demoPDF(title string) []byte {
	text := "CorpNet demo document"
	stream := fmt.Sprintf("BT /F1 22 Tf 72 740 Td (%s) Tj ET\nBT /F1 12 Tf 72 700 Td (This is a placeholder file generated for the demo portal.) Tj ET", text)
	objs := []string{
		"<< /Type /Catalog /Pages 2 0 R >>",
		"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
		"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
		fmt.Sprintf("<< /Length %d >>\nstream\n%s\nendstream", len(stream), stream),
		"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
	}
	var b strings.Builder
	b.WriteString("%PDF-1.4\n")
	offs := make([]int, len(objs))
	for i, o := range objs {
		offs[i] = b.Len()
		fmt.Fprintf(&b, "%d 0 obj\n%s\nendobj\n", i+1, o)
	}
	x := b.Len()
	fmt.Fprintf(&b, "xref\n0 %d\n0000000000 65535 f \n", len(objs)+1)
	for _, o := range offs {
		fmt.Fprintf(&b, "%010d 00000 n \n", o)
	}
	fmt.Fprintf(&b, "trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n", len(objs)+1, x)
	_ = title
	return []byte(b.String())
}
