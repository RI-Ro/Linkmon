package server

import (
	"strconv"
	"strings"
	"time"
)

// График отпусков руководящего состава. Видят все сотрудники; вести (добавлять/менять) могут администраторы
// и пользователи с дополнительной ролью «ведёт график отпусков» (users.can_vacations).

func (c *Ctx) canVacations() bool { return c.U.IsAdmin() || c.U.Vac }

func (s *Server) listVacations(c *Ctx) error {
	from, to := c.Q("from"), c.Q("to")
	if _, err := time.Parse("2006-01-02", from); err != nil {
		from = time.Now().AddDate(0, 0, -30).Format("2006-01-02")
	}
	if _, err := time.Parse("2006-01-02", to); err != nil {
		to = time.Now().AddDate(1, 0, 0).Format("2006-01-02")
	}
	w := &whereBuilder{}
	w.add("v.ends_on >= ?::date AND v.starts_on <= ?::date", from, to)
	if q := strings.ToLower(c.Q("q")); q != "" {
		s.userSearch(c.Context(), w, q)
	}
	if d := c.QInt64("department"); d > 0 {
		w.add("u.department_id IN "+deptSubtree("?"), d)
	}
	b, err := s.arr2(c.Context(), `SELECT v.id, v.user_id, u.full_name AS name, u.job_title, u.avatar, d.name AS department,
		to_char(v.starts_on, 'YYYY-MM-DD') AS starts_on, to_char(v.ends_on, 'YYYY-MM-DD') AS ends_on,
		v.deputy_id, du.full_name AS deputy, du.job_title AS deputy_title, v.city, v.note,
		(v.starts_on <= current_date AND v.ends_on >= current_date) AS active_now
		FROM vacations v JOIN users u ON u.id = v.user_id LEFT JOIN departments d ON d.id = u.department_id LEFT JOIN users du ON du.id = v.deputy_id
		WHERE `+w.String()+` ORDER BY v.starts_on, `+userOrder+` LIMIT 1000`, w.args...)
	if err != nil {
		return err
	}
	s.logSearch(c, "vacations", c.Q("q"), anCount(b)) // аналитика поиска
	return c.JSON(200, map[string]any{"items": b, "can_manage": c.canVacations()})
}

func (s *Server) saveVacation(c *Ctx) error {
	if !c.canVacations() {
		return &apiError{403, "Вести график отпусков могут только назначенные сотрудники"}
	}
	var in struct {
		UserID   int64  `json:"user_id"`
		StartsOn string `json:"starts_on"`
		EndsOn   string `json:"ends_on"`
		DeputyID *int64 `json:"deputy_id"`
		City     string `json:"city"`
		Note     string `json:"note"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	st, e1 := time.Parse("2006-01-02", in.StartsOn)
	en, e2 := time.Parse("2006-01-02", in.EndsOn)
	if e1 != nil || e2 != nil || en.Before(st) {
		return badReq("Укажите корректные даты начала и окончания отпуска")
	}
	if len([]rune(in.City)) > 100 || len([]rune(in.Note)) > 500 {
		return badReq("Слишком длинный город или примечание")
	}
	ctx := c.Context()
	var head, blocked bool
	if err := s.db.QueryRow(ctx, `SELECT is_head, blocked FROM users WHERE id = $1`, in.UserID).Scan(&head, &blocked); err != nil {
		return badReq("Сотрудник не найден")
	}
	if !head {
		return badReq("График ведётся только для руководящего состава (отметка «руководитель подразделения»)")
	}
	if in.DeputyID != nil && *in.DeputyID == in.UserID {
		return badReq("Сотрудник не может замещать сам себя")
	}
	var id int64
	var err error
	if c.R.PathValue("id") != "" {
		if id, err = c.ID("id"); err != nil {
			return err
		}
		_, err = s.db.Exec(ctx, `UPDATE vacations SET user_id = $2, starts_on = $3, ends_on = $4, deputy_id = $5, city = $6, note = $7 WHERE id = $1`,
			id, in.UserID, in.StartsOn, in.EndsOn, in.DeputyID, strings.TrimSpace(in.City), strings.TrimSpace(in.Note))
	} else {
		err = s.db.QueryRow(ctx, `INSERT INTO vacations (user_id, starts_on, ends_on, deputy_id, city, note, created_by)
			VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
			in.UserID, in.StartsOn, in.EndsOn, in.DeputyID, strings.TrimSpace(in.City), strings.TrimSpace(in.Note), c.U.ID).Scan(&id)
	}
	if err != nil {
		return err
	}
	if in.DeputyID != nil {
		var name string
		s.db.QueryRow(ctx, `SELECT full_name FROM users WHERE id = $1`, in.UserID).Scan(&name)
		s.notify(ctx, []int64{*in.DeputyID}, "vacation", "Вы замещаете: "+name, st.Format("02.01.2006")+" — "+en.Format("02.01.2006"), "/vacations")
	}
	s.audit(c, "vacation.save", "vacation", id, map[string]string{"from": in.StartsOn, "to": in.EndsOn, "user": strconv.FormatInt(in.UserID, 10)})
	return c.JSON(200, map[string]int64{"id": id})
}

func (s *Server) deleteVacation(c *Ctx) error {
	if !c.canVacations() {
		return errForbidden
	}
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if _, err := s.db.Exec(c.Context(), `DELETE FROM vacations WHERE id = $1`, id); err != nil {
		return err
	}
	return c.OK()
}
