// Package web встраивает собранный фронтенд (frontend → `npm run build` пишет сюда, в internal/web/dist).
package web

import (
	"embed"
	"io/fs"
)

//go:embed all:dist
var embedded embed.FS

// Dist возвращает корень собранного фронтенда (index.html, assets/…).
func Dist() fs.FS {
	sub, err := fs.Sub(embedded, "dist")
	if err != nil {
		return embedded
	}
	return sub
}
