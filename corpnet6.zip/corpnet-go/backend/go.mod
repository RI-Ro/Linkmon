module corpnet

go 1.24

require (
	github.com/gorilla/websocket v1.5.3
	github.com/jackc/pgx/v5 v5.7.2
	github.com/redis/go-redis/v9 v9.7.0
	github.com/go-ldap/ldap/v3 v3.4.8
	golang.org/x/crypto v0.31.0
	github.com/jcmturner/gokrb5/v8 v8.4.4
)
