package main

import (
	"flag"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"path/filepath"
	"time"

	"gopkg.in/yaml.v3"

	"github.com/example/linkmon/internal/web"
)

var version = "dev"

func main() {
	cfgPath := flag.String("config", "web.conf.yaml", "path to web config")
	flag.Parse()
	log := slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: slog.LevelInfo}))

	cfg, err := loadConfig(*cfgPath)
	if err != nil {
		log.Error("config", "err", err)
		os.Exit(1)
	}
	app, err := web.New(*cfg)
	if err != nil {
		log.Error("web", "err", err)
		os.Exit(1)
	}
	srv := &http.Server{Addr: cfg.Listen, Handler: app.Handler(), ReadHeaderTimeout: 10 * time.Second}
	log.Info("linkmon-web started", "version", version, "listen", cfg.Listen, "servers", len(cfg.Servers))
	if err := srv.ListenAndServe(); err != nil {
		log.Error("listen", "err", err)
		os.Exit(1)
	}
}

func loadConfig(path string) (*web.Config, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var c web.Config
	if err := yaml.Unmarshal(b, &c); err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	if c.Listen == "" {
		c.Listen = ":8080"
	}
	// Относительные пути (web_dir, ca_file) считаем от каталога конфига.
	base, err := filepath.Abs(filepath.Dir(path))
	if err != nil {
		return nil, err
	}
	if c.WebDir != "" && !filepath.IsAbs(c.WebDir) {
		c.WebDir = filepath.Join(base, c.WebDir)
	}
	for i := range c.Servers {
		if c.Servers[i].CAFile != "" && !filepath.IsAbs(c.Servers[i].CAFile) {
			c.Servers[i].CAFile = filepath.Join(base, c.Servers[i].CAFile)
		}
	}
	return &c, nil
}
