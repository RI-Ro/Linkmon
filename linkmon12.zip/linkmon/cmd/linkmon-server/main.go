package main

import (
	"context"
	"crypto/tls"
	"errors"
	"flag"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/example/linkmon/internal/bwtest"
	"github.com/example/linkmon/internal/clock"
	"github.com/example/linkmon/internal/relay"
	"github.com/example/linkmon/internal/server"
)

var version = "dev"

func main() {
	cfgPath := flag.String("config", "conf.yaml", "path to server config (relative paths inside are resolved from its directory)")
	flag.Parse()
	log := slog.New(slog.NewJSONHandler(os.Stdout, nil))
	if err := run(*cfgPath, log); err != nil {
		log.Error("server stopped", "err", err)
		os.Exit(1)
	}
}

func run(path string, log *slog.Logger) error {
	cfg, err := server.LoadConfig(path)
	if err != nil {
		return err
	}
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	st, err := server.OpenStore(ctx, cfg.DatabaseURL)
	if err != nil {
		return fmt.Errorf("database: %w", err)
	}
	defer st.Close()
	if err := st.Migrate(ctx); err != nil {
		return fmt.Errorf("migrate: %w", err)
	}
	ca, err := server.LoadOrCreateCA(cfg.StateDir)
	if err != nil {
		return fmt.Errorf("CA: %w", err)
	}
	srvCert, err := ca.ServerTLS(cfg.TLSHosts)
	if err != nil {
		return fmt.Errorf("server certificate: %w", err)
	}
	if cfg.Dev.BootstrapToken != "" {
		if err := st.EnsureBootstrapToken(ctx, cfg.Dev.BootstrapToken); err != nil {
			return fmt.Errorf("bootstrap token: %w", err)
		}
		log.Warn("dev bootstrap token is active: agents with it are approved automatically")
	}
	log.Info("agents must trust this CA", "ca_file", cfg.StateDir+"/ca.crt")

	// Учётка администратора для входа в веб-интерфейс (bootstrap из конфига).
	if cfg.Web.BootstrapAdmin.Login != "" && cfg.Web.BootstrapAdmin.Password != "" {
		created, err := st.EnsureAdmin(ctx, cfg.Web.BootstrapAdmin.Login, cfg.Web.BootstrapAdmin.Password)
		if err != nil {
			return fmt.Errorf("bootstrap admin: %w", err)
		}
		if created {
			log.Info("bootstrap admin user created", "login", cfg.Web.BootstrapAdmin.Login)
			log.Warn("удалите web.bootstrap_admin.password из conf.yaml — пароль уже сохранён в БД")
		}
	}
	if err := st.PurgeExpiredSessions(ctx); err != nil {
		log.Warn("purge expired sessions", "err", err)
	}
	go func() {
		t := time.NewTicker(time.Hour)
		defer t.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-t.C:
				if err := st.PurgeExpiredSessions(ctx); err != nil {
					log.Warn("purge expired sessions", "err", err)
				}
			}
		}
	}()

	clk := clock.NewMonitor(cfg.MaxClockErrUS)
	go clk.Run(ctx)
	if !clk.OneWayOK() {
		log.Warn("server clock is not synchronized: one-way delays will be marked invalid")
	}
	hub := server.NewHub(log)
	go hub.Run(ctx, st.Pool())

	go server.NewAlertEngine(st, cfg, log).Run(ctx)

	// Авто-удаление данных старше retention_days (по умолчанию 7 суток) — без внешнего cron.
	go server.RunRetention(ctx, st, cfg.RetentionDays, log)

	errc := make(chan error, 3)
	refl := server.NewReflector(cfg.Reflector.Listen, cfg.Reflector.Readers, st, log)
	go func() { errc <- refl.Run(ctx) }()

	// Сервер сам может быть эндпоинтом нагрузочных тестов (топология «агент ↔ сервер»).
	if cfg.BWTestPort > 0 {
		bwsrv := bwtest.NewServer(fmt.Sprintf(":%d", cfg.BWTestPort))
		go func() {
			if err := bwsrv.Run(ctx); err != nil && ctx.Err() == nil {
				log.Error("bwtest server stopped", "err", err)
			}
		}()
		log.Info("bwtest server listening", "port", cfg.BWTestPort)
	}

	// Ретранслятор для измерений между агентами за NAT (оба подключаются исходящими соединениями).
	if cfg.RelayPort > 0 {
		rl := relay.New(fmt.Sprintf(":%d", cfg.RelayPort))
		go func() {
			if err := rl.Run(ctx); err != nil && ctx.Err() == nil {
				log.Error("relay stopped", "err", err)
			}
		}()
		log.Info("nat relay listening", "port", cfg.RelayPort)
	}

	srv := server.New(cfg, st, ca, hub, clk, log)
	agentsHTTP := &http.Server{
		Addr:    cfg.ListenAgents,
		Handler: srv.AgentHandler(),
		TLSConfig: &tls.Config{
			Certificates: []tls.Certificate{srvCert},
			ClientCAs:    ca.Pool(),
			ClientAuth:   tls.VerifyClientCertIfGiven, // /v1/enroll — без сертификата, остальное — mTLS
			MinVersion:   tls.VersionTLS12,
		},
		ReadHeaderTimeout: 10 * time.Second,
		IdleTimeout:       2 * time.Minute,
	}
	adminHTTP := &http.Server{Addr: cfg.ListenAdmin, Handler: srv.AdminHandler(), ReadHeaderTimeout: 10 * time.Second}
	go func() { errc <- agentsHTTP.ListenAndServeTLS("", "") }()
	go func() { errc <- adminHTTP.ListenAndServe() }()

	log.Info("linkmon server started", "version", version, "agents", cfg.ListenAgents,
		"admin", cfg.ListenAdmin, "reflector", cfg.Reflector.Listen, "web_dir", cfg.Web.Dir)

	var runErr error
	select {
	case <-ctx.Done():
	case runErr = <-errc:
	}
	stop()
	shCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	_ = agentsHTTP.Shutdown(shCtx)
	_ = adminHTTP.Shutdown(shCtx)
	if errors.Is(runErr, http.ErrServerClosed) {
		runErr = nil
	}
	return runErr
}
