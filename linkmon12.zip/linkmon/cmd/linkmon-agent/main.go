package main

import (
	"context"
	"errors"
	"flag"
	"log/slog"
	"os"
	"os/signal"
	"strings"
	"syscall"

	"github.com/example/linkmon/internal/agent"
)

var version = "dev"

func main() {
	cfgPath := flag.String("config", "conf.yaml", "path to agent config (relative paths inside are resolved from its directory)")
	debug := flag.Bool("debug", false, "debug logging")
	servers := flag.String("servers", "", "provision mode: comma-separated host:port of servers; downloads CA and writes a minimal config")
	token := flag.String("token", "", "provision: shared enrollment token (optional; without it the agent waits for admin approval)")
	name := flag.String("name", "", "provision: friendly agent name")
	noBind := flag.Bool("no-bind", false, "provision: do not bind sockets to interfaces (dev / server-authored config)")
	bwPort := flag.Int("bwtest-port", 0, "provision: listener port for bandwidth tests (0 = off)")
	flag.Parse()

	lvl := slog.LevelInfo
	if *debug {
		lvl = slog.LevelDebug
	}
	log := slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: lvl}))

	// Режим установки: `agent --servers host:port[,...]` скачивает CA и пишет минимальный конфиг,
	// после чего сразу запускается. Конфигурацию каналов дальше задают с сервера.
	if *servers != "" {
		ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
		defer stop()
		opts := agent.ProvisionOptions{
			Servers: splitCSV(*servers), Token: *token, Name: *name,
			NoBind: *noBind, BWTestPort: *bwPort, ConfigPath: *cfgPath,
		}
		if err := agent.Provision(ctx, opts); err != nil {
			log.Error("provision", "err", err)
			os.Exit(1)
		}
		log.Info("agent provisioned", "config", *cfgPath, "servers", len(opts.Servers))
	}

	cfg, err := agent.LoadConfig(*cfgPath)
	if err != nil {
		log.Error("config", "err", err)
		os.Exit(1)
	}
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	log.Info("linkmon agent starting", "version", version, "servers", len(cfg.Servers2()))
	if err := agent.Run(ctx, cfg, version, log); err != nil && !errors.Is(err, context.Canceled) {
		log.Error("agent stopped", "err", err)
		os.Exit(1)
	}
}

// splitCSV делит строку "a,b,c" на непустые элементы без пробелов по краям.
func splitCSV(s string) []string {
	var out []string
	for _, p := range strings.Split(s, ",") {
		if p = strings.TrimSpace(p); p != "" {
			out = append(out, p)
		}
	}
	return out
}
