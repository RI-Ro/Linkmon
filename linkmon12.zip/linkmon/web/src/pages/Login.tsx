import { useState, type FormEvent } from 'react';
import { Alert, Button, PasswordInput, Stack, Text, TextInput, Title } from '@mantine/core';
import { IconAlertTriangle } from '@tabler/icons-react';
import { api, ApiError, type Me } from '../api';

export function Login({ onLogin }: { onLogin: (me: Me) => void }) {
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const me = await api.login(login.trim(), password);
      onLogin(me);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Не удалось войти. Проверьте, что сервер доступен.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login">
      <form className="panel" onSubmit={submit}>
        <Stack gap="md">
          <div className="brand" style={{ color: 'var(--ink)', padding: 0 }}>
            <span className="brand-mark" aria-hidden><span /><span /></span>
            LinkMon
          </div>
          <div>
            <Title order={2}>Вход в систему</Title>
            <Text c="dimmed" size="sm" mt={4}>Мониторинг качества каналов связи по классам QoS, в обе стороны.</Text>
          </div>
          {error && <Alert color="red" variant="light" icon={<IconAlertTriangle size={16} />}>{error}</Alert>}
          <TextInput label="Логин" value={login} onChange={(e) => setLogin(e.currentTarget.value)}
            autoComplete="username" autoFocus required />
          <PasswordInput label="Пароль" value={password} onChange={(e) => setPassword(e.currentTarget.value)}
            autoComplete="current-password" required />
          <Button type="submit" loading={busy}>Войти</Button>
        </Stack>
      </form>
    </div>
  );
}
