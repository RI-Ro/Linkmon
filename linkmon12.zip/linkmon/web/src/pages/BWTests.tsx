import { useEffect, useMemo, useState } from 'react';
import {
  ActionIcon, Badge, Button, Group, Loader, Modal, NumberInput, Pagination, Select, Stack, Switch,
  Table, Text, TextInput, Title, Tooltip,
} from '@mantine/core';
import { IconPlayerPlay, IconArrowsLeftRight, IconTrash } from '@tabler/icons-react';
import { notifications } from '@mantine/notifications';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import {
  api, useAgents, useBWTests, useBWTest, useAgentBWEndpoint, useBWDefaults, type BWTestCreate, type Me,
} from '../api';
import { canManage, fmtTime, fmtBytes } from '../format';
import { MetricInfo } from '../components/MetricInfo';

const statusBadge: Record<string, { label: string; color: string }> = {
  scheduled: { label: 'запланирован', color: 'blue' },
  running: { label: 'идёт', color: 'yellow' },
  done: { label: 'готов', color: 'teal' },
  failed: { label: 'ошибка', color: 'red' },
};

const fmtMbps = (v: number | null | undefined) => (v == null ? '—' : `${v.toFixed(v < 100 ? 1 : 0)} Мбит/с`);

// Стандартные классы DSCP (значение — номер DSCP, метка — имя PHB).
const DSCP_OPTIONS = [
  { value: '0', label: 'BE (0)' },
  { value: '8', label: 'CS1 (8)' },
  { value: '10', label: 'AF11 (10)' },
  { value: '16', label: 'CS2 (16)' },
  { value: '18', label: 'AF21 (18)' },
  { value: '24', label: 'CS3 (24)' },
  { value: '26', label: 'AF31 (26)' },
  { value: '32', label: 'CS4 (32)' },
  { value: '34', label: 'AF41 (34)' },
  { value: '40', label: 'CS5 (40)' },
  { value: '46', label: 'EF (46)' },
  { value: '48', label: 'CS6 (48)' },
];

// Тесты пропускной способности между агентами (iperf-подобные): TCP/UDP, число потоков,
// длительность, размер блока, целевая полоса, направление. История и результаты — здесь же.
const PAGE = 20;

export function BWTestsPage({ me }: { me: Me }) {
  const manage = canManage(me.role);
  const tests = useBWTests(500);
  const qc = useQueryClient();
  const [openId, setOpenId] = useState<number | null>(null);
  const [launch, setLaunch] = useState(false);
  const [page, setPage] = useState(1);

  const all = tests.data ?? [];
  const pages = Math.max(1, Math.ceil(all.length / PAGE));
  const shown = useMemo(() => all.slice((page - 1) * PAGE, page * PAGE), [all, page]);

  const del = useMutation({
    mutationFn: (id: number) => api.del(`/v1/admin/bwtests/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['bwtests'] }),
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  return (
    <>
      <div className="page-head">
        <div>
          <Title order={1}>Пропускная способность</Title>
          <p>
            Нагрузочные тесты между агентами по TCP и UDP с параметрами в духе iperf: длительность,
            число параллельных потоков, размер блока, целевая полоса (UDP) и направление. Агент-приёмник
            должен слушать bwtest-порт (параметр <code>agent.bwtest_port</code> в его конфиге).
          </p>
        </div>
        {manage && (
          <Button leftSection={<IconPlayerPlay size={16} />} onClick={() => setLaunch(true)}>
            Запустить тест
          </Button>
        )}
      </div>

      <div className="panel">
        {tests.isLoading ? <Loader /> : all.length === 0 ? (
          <Text c="dimmed">Тестов ещё не было. Нажмите «Запустить тест».</Text>
        ) : (
          <>
            <Table highlightOnHover>
              <Table.Thead>
                <Table.Tr>
                  <Table.Th>Запущен</Table.Th><Table.Th>Клиент → Сервер</Table.Th>
                  <Table.Th>Режим</Table.Th><Table.Th>Скорость</Table.Th>
                  <Table.Th>Потери</Table.Th><Table.Th>Статус</Table.Th>
                  {manage && <Table.Th w={48}></Table.Th>}
                </Table.Tr>
              </Table.Thead>
              <Table.Tbody>
                {shown.map((t) => {
                  const sb = statusBadge[t.status] ?? { label: t.status, color: 'gray' };
                  return (
                    <Table.Tr key={t.id} className="clickable" onClick={() => setOpenId(t.id)}>
                      <Table.Td>{fmtTime(t.created_at)}</Table.Td>
                      <Table.Td>
                        {(t.client_name ?? '—')} → {(t.server_name ?? t.server_addr)}
                      </Table.Td>
                      <Table.Td>
                        {t.proto.toUpperCase()} · {t.streams}×
                        {t.reverse ? ' ↓ down' : ' ↑ up'}
                      </Table.Td>
                      <Table.Td>{t.result ? fmtMbps(t.result.mbps) : '—'}</Table.Td>
                      <Table.Td>{t.result && t.proto === 'udp' ? `${t.result.loss_pct.toFixed(1)}%` : '—'}</Table.Td>
                      <Table.Td><Badge variant="light" color={sb.color}>{sb.label}</Badge></Table.Td>
                      {manage && (
                        <Table.Td onClick={(e) => e.stopPropagation()}>
                          <Tooltip label="Удалить тест">
                            <ActionIcon variant="subtle" color="red" loading={del.isPending && del.variables === t.id}
                              onClick={() => { if (confirm('Удалить этот тест?')) del.mutate(t.id); }}>
                              <IconTrash size={16} />
                            </ActionIcon>
                          </Tooltip>
                        </Table.Td>
                      )}
                    </Table.Tr>
                  );
                })}
              </Table.Tbody>
            </Table>
            {pages > 1 && (
              <Group justify="space-between" mt="md">
                <Text size="sm" c="dimmed">Всего: {all.length}</Text>
                <Pagination total={pages} value={page} onChange={setPage} size="sm" />
              </Group>
            )}
          </>
        )}
      </div>

      <BWTestDetail id={openId} onClose={() => setOpenId(null)} />
      {manage && <LaunchModal opened={launch} onClose={() => setLaunch(false)} />}
    </>
  );
}

function metric(label: string, value: string, info?: string) {
  return (
    <div className="kv">
      <span className="k">
        {label}
        {info && <MetricInfo metric={info} />}
      </span>
      <span className="v">{value}</span>
    </div>
  );
}

function BWTestDetail({ id, onClose }: { id: number | null; onClose: () => void }) {
  const q = useBWTest(id);
  const test = q.data ?? null;
  return (
    <Modal opened={id !== null} onClose={onClose} title="Результат теста пропускной способности" size="lg">
      {test && (
        <Stack gap="sm">
          <Text size="sm" c="dimmed">
            {(test.client_name ?? 'клиент')} → {(test.server_name ?? test.server_addr)} ·{' '}
            {test.proto.toUpperCase()} · {test.streams} поток(ов) ·{' '}
            {test.reverse ? 'download (сервер → клиент)' : 'upload (клиент → сервер)'} ·{' '}
            DSCP {test.dscp} · {test.duration_sec} с
            {test.target_mbps ? ` · лимит ${test.target_mbps} Мбит/с` : ''}
          </Text>

          {test.status === 'failed' && (
            <Text c="red">Ошибка: {test.error ?? 'неизвестно'}</Text>
          )}

          {test.result ? (
            <div className="kv-grid">
              {metric('Пропускная способность', fmtMbps(test.result.mbps), 'throughput')}
              {metric('Передано данных', fmtBytes(test.result.bytes))}
              {test.proto === 'udp' && metric('Пакетов', String(test.result.packets))}
              {test.proto === 'udp' && metric('Потери', `${test.result.loss_pct.toFixed(2)}% (${test.result.lost_packets})`, 'bwloss')}
              {test.proto === 'udp' && metric('Джиттер', `${test.result.jitter_ms.toFixed(2)} мс`, 'bwjitter')}
              {test.proto === 'tcp' && test.result.retransmits > 0 &&
                metric('Ретрансмиссии', String(test.result.retransmits), 'retransmits')}
              {metric('Длительность', `${test.result.duration_sec.toFixed(1)} с`)}
            </div>
          ) : test.status !== 'failed' ? (
            <Group gap="xs"><Loader size="sm" /><Text size="sm" c="dimmed">Тест выполняется…</Text></Group>
          ) : null}
        </Stack>
      )}
    </Modal>
  );
}

function LaunchModal({ opened, onClose }: { opened: boolean; onClose: () => void }) {
  const agents = useAgents();
  const qc = useQueryClient();
  const approved = useMemo(
    () => (agents.data ?? []).filter((a) => a.status === 'approved'),
    [agents.data],
  );

  // client = '' означает «клиентом выступает сам сервер LinkMon» (топологии сервер↔сервер/агент↔сервер).
  const SERVER = '__server__';
  const [client, setClient] = useState<string | null>(null);
  const [server, setServer] = useState<string | null>(null);
  const [serverAddr, setServerAddr] = useState('');
  const [proto, setProto] = useState<'tcp' | 'udp'>('tcp');
  const [via, setVia] = useState<'direct' | 'relay'>('direct');
  const [reverse, setReverse] = useState(false);
  const [duration, setDuration] = useState<number>(10);
  const [streams, setStreams] = useState<number>(1);
  const [length, setLength] = useState<number>(1350);
  const [targetMbps, setTargetMbps] = useState<number>(0);
  const [dscp, setDscp] = useState<string>('0');

  const agentOptions = approved.map((a) => ({
    value: a.id,
    label: a.name || a.hostname || a.machine_id,
  }));
  // Клиентом и приёмником может быть агент или сам сервер LinkMon.
  const clientOptions = [{ value: SERVER, label: 'Сервер LinkMon (сам сервер)' }, ...agentOptions];
  const receiverOptions = [{ value: SERVER, label: 'Сервер LinkMon (сам сервер)' }, ...agentOptions];

  // Адрес bwtest подбирается сервером: из выбранного агента-приёмника или из умолчаний сервера.
  const defaults = useBWDefaults();
  const endpoint = useAgentBWEndpoint(via === 'direct' && server && server !== SERVER ? server : null);
  useEffect(() => {
    if (via !== 'direct') return;
    if (server && server !== SERVER && endpoint.data) {
      setServerAddr(endpoint.data.addr || ''); // приёмник — агент
    } else if ((server === SERVER || !server) && defaults.data) {
      setServerAddr(defaults.data.server_addr || ''); // приёмник — сам сервер LinkMon
    }
  }, [via, server, endpoint.data, defaults.data]);

  const run = useMutation({
    mutationFn: (body: BWTestCreate) => api.post('/v1/admin/bwtests', body),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['bwtests'] });
      notifications.show({ message: 'Тест запущен', color: 'teal' });
      onClose();
      reset();
    },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  function reset() {
    setClient(null); setServer(null); setServerAddr('');
    setProto('tcp'); setVia('direct'); setReverse(false); setDuration(10); setStreams(1);
    setLength(1350); setTargetMbps(0); setDscp('0');
  }

  function submit() {
    if (!client) {
      notifications.show({ message: 'Выберите клиента', color: 'red' });
      return;
    }
    if (via === 'relay') {
      if (client === SERVER || !server || server === SERVER) {
        notifications.show({ message: 'Релей — только между двумя агентами (выберите агента-клиента и агента-приёмника)', color: 'red' });
        return;
      }
    } else if (!serverAddr.trim()) {
      notifications.show({ message: 'Адрес приёмника не определён. Выберите приёмника или укажите host:port вручную.', color: 'red' });
      return;
    }
    const body: BWTestCreate = {
      client_agent: client === SERVER ? '' : client,
      server_agent: server && server !== SERVER ? server : undefined,
      server_addr: via === 'relay' ? '' : serverAddr.trim(),
      via,
      params: {
        proto, reverse, duration_sec: duration, streams,
        length_bytes: length, target_mbps: targetMbps, dscp: Number(dscp) || 0,
      },
    };
    run.mutate(body);
  }

  return (
    <Modal opened={opened} onClose={onClose} title="Запуск теста пропускной способности" size="lg">
      <Stack gap="sm">
        <Select
          label="Клиент (создаёт нагрузку)"
          placeholder="агент или сам сервер"
          data={clientOptions}
          value={client}
          onChange={setClient}
          searchable
          nothingFoundMessage="нет одобренных агентов"
        />
        <Select
          label="Сервер-приёмник"
          placeholder="агент или сам сервер LinkMon"
          data={receiverOptions}
          value={server}
          onChange={setServer}
          searchable
          clearable
        />
        <Select
          label="Способ соединения"
          description="direct — клиент подключается к приёмнику напрямую; через релей — оба агента подключаются к серверу-ретранслятору (нужно, когда оба за NAT)."
          data={[
            { value: 'direct', label: 'Прямое соединение' },
            { value: 'relay', label: 'Через релей сервера (оба за NAT)' },
          ]}
          value={via}
          onChange={(v) => setVia((v as 'direct' | 'relay') ?? 'direct')}
          allowDeselect={false}
        />
        {via === 'direct' && (
          <TextInput
            label="Адрес сервера bwtest (host:port)"
            description="Подставляется автоматически из выбранного приёмника (его адрес и bwtest_port). Можно переопределить вручную; для узлов за NAT используйте режим «через релей»."
            placeholder="подбирается автоматически…"
            value={serverAddr}
            onChange={(e) => setServerAddr(e.currentTarget.value)}
          />
        )}
        {via === 'relay' && (
          <Text size="xs" c="dimmed">
            В релейном режиме оба агента (клиент и сервер-агент) подключаются к ретранслятору сервера
            исходящими соединениями и не требуют белого IP. Используется один поток данных.
          </Text>
        )}
        <Group grow>
          <Select
            label="Протокол"
            data={[{ value: 'tcp', label: 'TCP' }, { value: 'udp', label: 'UDP' }]}
            value={proto}
            onChange={(v) => setProto((v as 'tcp' | 'udp') ?? 'tcp')}
            allowDeselect={false}
          />
          <NumberInput label="Длительность, с" min={1} max={600} value={duration} onChange={(v) => setDuration(Number(v) || 10)} />
          <NumberInput label="Потоков (-P)" min={1} max={128} value={streams} onChange={(v) => setStreams(Number(v) || 1)} />
        </Group>
        <Group grow>
          <NumberInput
            label="Размер блока, байт (-l)"
            description="по умолчанию 1350 (в MTU)"
            min={0} max={9000} value={length} onChange={(v) => setLength(Number(v) || 0)}
          />
          <NumberInput
            label="Целевая полоса, Мбит/с (-b)"
            description="0 — без ограничения; работает и для TCP, и для UDP"
            min={0} value={targetMbps} onChange={(v) => setTargetMbps(Number(v) || 0)}
          />
          <Select
            label="DSCP-метка"
            data={DSCP_OPTIONS}
            value={dscp}
            onChange={(v) => setDscp(v ?? '0')}
            allowDeselect={false}
          />
        </Group>
        <Switch
          label="Обратное направление (download: сервер → клиент)"
          checked={reverse}
          onChange={(e) => setReverse(e.currentTarget.checked)}
          thumbIcon={<IconArrowsLeftRight size={12} />}
        />
        <Group justify="flex-end" mt="sm">
          <Button variant="default" onClick={onClose}>Отмена</Button>
          <Button leftSection={<IconPlayerPlay size={16} />} loading={run.isPending} onClick={submit}>
            Запустить
          </Button>
        </Group>
      </Stack>
    </Modal>
  );
}
