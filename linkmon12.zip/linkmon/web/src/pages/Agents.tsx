import { useState } from 'react';
import {
  ActionIcon, Badge, Button, Checkbox, CopyButton, Group, Menu, Modal, NumberInput, Select,
  Stack, Table, Text, TextInput, Title, Code,
} from '@mantine/core';
import { IconDots, IconPencil, IconTrash, IconPlugConnectedX, IconPlugConnected, IconRefresh, IconFolders, IconRouteSquare, IconBell, IconBellRinging, IconBellOff } from '@tabler/icons-react';
import { notifications } from '@mantine/notifications';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Loader, MultiSelect, Switch } from '@mantine/core';
import { api, useAgents, useGroups, useAgentInterfaces, type Agent, type Me } from '../api';
import { canManage, fmtAgo } from '../format';

const DSCP_OPTIONS = [
  { value: '0', label: 'BE (0)' }, { value: '8', label: 'CS1 (8)' }, { value: '10', label: 'AF11 (10)' },
  { value: '16', label: 'CS2 (16)' }, { value: '18', label: 'AF21 (18)' }, { value: '24', label: 'CS3 (24)' },
  { value: '26', label: 'AF31 (26)' }, { value: '32', label: 'CS4 (32)' }, { value: '34', label: 'AF41 (34)' },
  { value: '40', label: 'CS5 (40)' }, { value: '46', label: 'EF (46)' }, { value: '48', label: 'CS6 (48)' },
];

const statusBadge: Record<Agent['status'], { label: string; color: string }> = {
  pending: { label: 'ждёт одобрения', color: 'yellow' },
  approved: { label: 'одобрен', color: 'teal' },
  rejected: { label: 'отклонён', color: 'gray' },
  disabled: { label: 'отключён', color: 'gray' },
};

export function AgentsPage({ me }: { me: Me }) {
  const agents = useAgents();
  const qc = useQueryClient();
  const manage = canManage(me.role);
  const [tokenOpen, setTokenOpen] = useState(false);
  const [rename, setRename] = useState<Agent | null>(null);
  const [groupsFor, setGroupsFor] = useState<Agent | null>(null);
  const [channelFor, setChannelFor] = useState<Agent | null>(null);

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ['agents'] });
    qc.invalidateQueries({ queryKey: ['channels'] });
    qc.invalidateQueries({ queryKey: ['overview'] });
  };

  const act = useMutation({
    mutationFn: ({ id, action }: { id: string; action: string }) => api.post(`/v1/admin/agents/${id}/${action}`),
    onSuccess: (_d, v) => {
      const msg: Record<string, string> = {
        approve: 'Агент одобрен, каналы созданы', reject: 'Агент отклонён',
        reload: 'Агент перечитает конфигурацию', disable: 'Агент выключен', enable: 'Агент включён',
      };
      notifications.show({ message: msg[v.action] ?? 'Готово', color: 'teal' });
      invalidate();
    },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  const del = useMutation({
    mutationFn: (id: string) => api.del(`/v1/admin/agents/${id}`),
    onSuccess: () => { notifications.show({ message: 'Агент удалён', color: 'teal' }); invalidate(); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  const alertMode = useMutation({
    mutationFn: ({ id, mode }: { id: string; mode: string }) => api.post(`/v1/admin/agents/${id}/alert-mode`, { mode }),
    onSuccess: () => { notifications.show({ message: 'Режим оповещений изменён', color: 'teal' }); invalidate(); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  return (
    <>
      <div className="page-head">
        <div>
          <Title order={1}>Агенты</Title>
          <p>Агенты регистрируются сами по токену. Задайте понятное имя — оно используется в поиске и на графиках вместо идентификатора. machine_id показан мелким шрифтом.</p>
        </div>
        {manage && <Button onClick={() => setTokenOpen(true)}>Создать токен регистрации</Button>}
      </div>

      <div className="panel">
        {agents.data?.length === 0 ? (
          <Text c="dimmed">Агентов пока нет. Создайте токен и укажите его в conf.yaml агента (enroll_token).</Text>
        ) : (
          <Table>
            <Table.Thead>
              <Table.Tr>
                <Table.Th>Агент</Table.Th><Table.Th>Статус</Table.Th><Table.Th>На связи</Table.Th>
                <Table.Th>Часы</Table.Th><Table.Th>Каналы</Table.Th><Table.Th>Версия</Table.Th><Table.Th />
              </Table.Tr>
            </Table.Thead>
            <Table.Tbody>
              {agents.data?.map((a) => (
                <Table.Tr key={a.id}>
                  <Table.Td>
                    {a.name}
                    <Text size="xs" c="dimmed">{a.hostname !== a.name ? `${a.hostname} · ` : ''}{a.machine_id}</Text>
                  </Table.Td>
                  <Table.Td>
                    <Group gap={6}>
                      <Badge variant="light" color={statusBadge[a.status].color}>{statusBadge[a.status].label}</Badge>
                      {a.alert_mode === 'critical' && <Badge variant="outline" color="orange" size="sm">только крит.</Badge>}
                      {a.alert_mode === 'off' && <Badge variant="outline" color="gray" size="sm">без оповещений</Badge>}
                    </Group>
                  </Table.Td>
                  <Table.Td>{fmtAgo(a.last_seen)}</Table.Td>
                  <Table.Td>
                    {a.clock_synced == null ? '—' : a.clock_synced
                      ? <Text size="sm">синхронны, ±{a.clock_err_us} мкс</Text>
                      : <Text size="sm" c="red">не синхронны</Text>}
                  </Table.Td>
                  <Table.Td>{a.channels}</Table.Td>
                  <Table.Td>{a.version ?? '—'}</Table.Td>
                  <Table.Td>
                    <Group gap="xs" justify="flex-end" wrap="nowrap">
                      {manage && a.status === 'pending' && (
                        <Button size="xs" onClick={() => act.mutate({ id: a.id, action: 'approve' })}>Одобрить</Button>
                      )}
                      {manage && a.status === 'pending' && (
                        <Button size="xs" variant="default" onClick={() => act.mutate({ id: a.id, action: 'reject' })}>Отклонить</Button>
                      )}
                      {manage && (
                        <Menu position="bottom-end" withinPortal>
                          <Menu.Target><ActionIcon variant="subtle" color="gray"><IconDots size={18} /></ActionIcon></Menu.Target>
                          <Menu.Dropdown>
                            <Menu.Item leftSection={<IconPencil size={14} />} onClick={() => setRename(a)}>Переименовать</Menu.Item>
                            {a.status === 'approved' && <Menu.Item leftSection={<IconRouteSquare size={14} />} onClick={() => setChannelFor(a)}>Добавить канал</Menu.Item>}
                            <Menu.Item leftSection={<IconFolders size={14} />} onClick={() => setGroupsFor(a)}>Группы доступа</Menu.Item>
                            <Menu.Label>Оповещения</Menu.Label>
                            <Menu.Item leftSection={<IconBellRinging size={14} />} disabled={a.alert_mode === 'all'}
                              onClick={() => alertMode.mutate({ id: a.id, mode: 'all' })}>Все алерты + звук</Menu.Item>
                            <Menu.Item leftSection={<IconBell size={14} />} disabled={a.alert_mode === 'critical'}
                              onClick={() => alertMode.mutate({ id: a.id, mode: 'critical' })}>Только критичные</Menu.Item>
                            <Menu.Item leftSection={<IconBellOff size={14} />} disabled={a.alert_mode === 'off'}
                              onClick={() => alertMode.mutate({ id: a.id, mode: 'off' })}>Без оповещений</Menu.Item>
                            {a.status === 'approved' && <Menu.Item leftSection={<IconRefresh size={14} />}
                              onClick={() => act.mutate({ id: a.id, action: 'reload' })}>Обновить конфигурацию</Menu.Item>}
                            {a.status === 'approved'
                              ? <Menu.Item leftSection={<IconPlugConnectedX size={14} />} onClick={() => act.mutate({ id: a.id, action: 'disable' })}>Выключить</Menu.Item>
                              : a.status === 'disabled' && <Menu.Item leftSection={<IconPlugConnected size={14} />} onClick={() => act.mutate({ id: a.id, action: 'enable' })}>Включить</Menu.Item>}
                            <Menu.Divider />
                            <Menu.Item color="red" leftSection={<IconTrash size={14} />}
                              onClick={() => { if (confirm(`Удалить агента «${a.name}»? Его каналы и история будут удалены.`)) del.mutate(a.id); }}>
                              Удалить
                            </Menu.Item>
                          </Menu.Dropdown>
                        </Menu>
                      )}
                    </Group>
                  </Table.Td>
                </Table.Tr>
              ))}
            </Table.Tbody>
          </Table>
        )}
      </div>
      {manage && <TokenModal opened={tokenOpen} onClose={() => setTokenOpen(false)} />}
      {rename && <RenameAgentModal agent={rename} onClose={() => setRename(null)}
        onDone={() => { setRename(null); invalidate(); }} />}
      {groupsFor && <AgentGroupsModal agent={groupsFor} onClose={() => setGroupsFor(null)}
        onDone={() => { setGroupsFor(null); invalidate(); }} />}
      {channelFor && <AddChannelModal agent={channelFor} onClose={() => setChannelFor(null)}
        onDone={() => { setChannelFor(null); invalidate(); }} />}
    </>
  );
}

// AddChannelModal — создание канала агента с сервера: выбор реального интерфейса (из тех, что
// агент сообщил), адрес рефлектора, класс DSCP, TWAMP и мониторинг загрузки.
function AddChannelModal({ agent, onClose, onDone }: { agent: Agent; onClose: () => void; onDone: () => void }) {
  const ifaces = useAgentInterfaces(agent.id);
  const groups = useGroups();
  const [iface, setIface] = useState<string | null>(null);
  const [addr, setAddr] = useState('');
  const [port, setPort] = useState<number>(8620);
  const [dscp, setDscp] = useState('0');
  const [twamp, setTwamp] = useState(false);
  const [monitor, setMonitor] = useState(false);
  const [speed, setSpeed] = useState<number>(0);
  const [grp, setGrp] = useState<string[]>([]);

  const create = useMutation({
    mutationFn: () => api.post(`/v1/admin/agents/${agent.id}/channels`, {
      interface: iface, reflector_addr: addr.trim(), reflector_port: port,
      dscp: Number(dscp) || 0, twamp, monitor, speed_mbit: monitor ? speed : 0,
      group_ids: grp.map(Number),
    }),
    onSuccess: () => { notifications.show({ message: 'Канал создан, агент перечитает конфигурацию', color: 'teal' }); onDone(); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  const ifOptions = (ifaces.data ?? []).map((i) => ({
    value: i.name,
    label: `${i.name}${i.addrs && i.addrs.length ? ' · ' + i.addrs[0] : ''}${i.up ? '' : ' (down)'}`,
  }));

  return (
    <Modal opened onClose={onClose} title={`Новый канал — ${agent.name}`} size="lg">
      <Stack>
        {ifaces.isLoading ? <Loader size="sm" /> : (ifaces.data?.length ?? 0) === 0 ? (
          <Text c="dimmed" size="sm">Агент ещё не сообщил список интерфейсов. Дождитесь ближайшего цикла (до 5 минут) и откройте снова.</Text>
        ) : (
          <Select label="Интерфейс агента" placeholder="выберите интерфейс" data={ifOptions}
            value={iface} onChange={setIface} searchable />
        )}
        <Group grow>
          <TextInput label="Адрес рефлектора / цели (IPv4)" placeholder="10.0.0.10" value={addr} onChange={(e) => setAddr(e.currentTarget.value)} />
          <NumberInput label="Порт" min={1} max={65535} value={port} onChange={(v) => setPort(Number(v) || 8620)} w={120} />
          <Select label="DSCP" data={DSCP_OPTIONS} value={dscp} onChange={(v) => setDscp(v ?? '0')} allowDeselect={false} w={140} />
        </Group>
        <MultiSelect label="Группы (доступ/область)" placeholder="необязательно" searchable
          data={(groups.data ?? []).map((g) => ({ value: String(g.id), label: g.name }))}
          value={grp} onChange={setGrp} />
        <Group>
          <Switch label="TWAMP-ответчик (аппаратный)" checked={twamp} onChange={(e) => setTwamp(e.currentTarget.checked)} />
          <Switch label="Снимать загрузку интерфейса" checked={monitor} onChange={(e) => setMonitor(e.currentTarget.checked)} />
          {monitor && <NumberInput label="Номинал, Мбит/с" min={0} value={speed} onChange={(v) => setSpeed(Number(v) || 0)} w={160} />}
        </Group>
        <Group justify="flex-end">
          <Button variant="default" onClick={onClose}>Отмена</Button>
          <Button loading={create.isPending} disabled={!iface || !addr.trim()} onClick={() => create.mutate()}>Создать канал</Button>
        </Group>
      </Stack>
    </Modal>
  );
}

// AgentGroupsModal — назначение агента в группы. Доступ к агенту получают пользователи,
// у которых эти группы есть в области видимости (как для каналов).
function AgentGroupsModal({ agent, onClose, onDone }: { agent: Agent; onClose: () => void; onDone: () => void }) {
  const groups = useGroups();
  const [sel, setSel] = useState<string[]>((agent.groups ?? []).map(String));
  const save = useMutation({
    mutationFn: () => api.post(`/v1/admin/agents/${agent.id}/groups`, { groups: sel.map(Number) }),
    onSuccess: () => { notifications.show({ message: 'Группы агента обновлены', color: 'teal' }); onDone(); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });
  return (
    <Modal opened onClose={onClose} title={`Группы доступа — ${agent.name}`}>
      <Stack>
        <MultiSelect
          label="Группы"
          placeholder="выберите группы"
          searchable
          data={(groups.data ?? []).map((g) => ({ value: String(g.id), label: g.name }))}
          value={sel}
          onChange={setSel}
        />
        <Text size="xs" c="dimmed">
          Пользователи-администраторы и наблюдатели видят агента и могут запускать тесты между ним и
          другими своими агентами, только если он в одной из назначенных им групп.
        </Text>
        <Group justify="flex-end">
          <Button variant="default" onClick={onClose}>Отмена</Button>
          <Button loading={save.isPending} onClick={() => save.mutate()}>Сохранить</Button>
        </Group>
      </Stack>
    </Modal>
  );
}

function RenameAgentModal({ agent, onClose, onDone }: { agent: Agent; onClose: () => void; onDone: () => void }) {
  const [name, setName] = useState(agent.name);
  const save = useMutation({
    mutationFn: () => api.post(`/v1/admin/agents/${agent.id}/name`, { name }),
    onSuccess: () => { notifications.show({ message: 'Имя изменено', color: 'teal' }); onDone(); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });
  return (
    <Modal opened onClose={onClose} title="Имя агента">
      <Stack>
        <TextInput label="Понятное имя" value={name} onChange={(e) => setName(e.currentTarget.value)}
          description={`machine_id: ${agent.machine_id}. Пусто — вернуть hostname/machine_id.`} autoFocus />
        <Group justify="flex-end">
          <Button variant="default" onClick={onClose}>Отмена</Button>
          <Button loading={save.isPending} onClick={() => save.mutate()}>Сохранить</Button>
        </Group>
      </Stack>
    </Modal>
  );
}

function TokenModal({ opened, onClose }: { opened: boolean; onClose: () => void }) {
  const groups = useGroups();
  const [description, setDescription] = useState('');
  const [groupId, setGroupId] = useState<string | null>(null);
  const [auto, setAuto] = useState(false);
  const [uses, setUses] = useState<number | string>(10);
  const [ttl, setTtl] = useState<number | string>(168);
  const [token, setToken] = useState('');

  const create = useMutation({
    mutationFn: () => api.post<{ token: string }>('/v1/admin/tokens', {
      description,
      group_id: groupId ? Number(groupId) : null,
      auto_approve: auto,
      uses: uses === '' ? null : Number(uses),
      ttl_hours: ttl === '' ? 0 : Number(ttl),
    }),
    onSuccess: (r) => setToken(r.token),
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  const close = () => { setToken(''); onClose(); };

  return (
    <Modal opened={opened} onClose={close} title="Токен регистрации агентов" size="md">
      {token ? (
        <Stack>
          <Text size="sm">Токен показывается один раз — на сервере хранится только его хэш.</Text>
          <Code block>{token}</Code>
          <Text size="sm" c="dimmed">В conf.yaml агента: <Code>enroll_token: "{token}"</Code></Text>
          <Group justify="flex-end">
            <CopyButton value={token}>{({ copied, copy }) => <Button onClick={copy}>{copied ? 'Скопировано' : 'Скопировать'}</Button>}</CopyButton>
          </Group>
        </Stack>
      ) : (
        <Stack>
          <TextInput label="Назначение" placeholder="Филиалы Северо-Запада" value={description} onChange={(e) => setDescription(e.currentTarget.value)} />
          <Select label="Группа для новых каналов" placeholder="без группы" clearable value={groupId} onChange={setGroupId}
            data={(groups.data ?? []).map((g) => ({ value: String(g.id), label: g.name }))} />
          <Checkbox label="Одобрять агентов автоматически" checked={auto} onChange={(e) => setAuto(e.currentTarget.checked)} />
          <Group grow>
            <NumberInput label="Сколько агентов" min={1} value={uses} onChange={setUses} placeholder="без ограничения" />
            <NumberInput label="Срок действия, ч" min={0} value={ttl} onChange={setTtl} placeholder="бессрочно" />
          </Group>
          <Group justify="flex-end">
            <Button onClick={() => create.mutate()} loading={create.isPending}>Создать токен</Button>
          </Group>
        </Stack>
      )}
    </Modal>
  );
}
