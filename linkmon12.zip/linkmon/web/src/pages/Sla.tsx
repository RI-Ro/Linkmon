import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Button, Checkbox, Group, Loader, Modal, NumberInput, Stack, Table, Text, TextInput, Title,
} from '@mantine/core';
import { IconPlus } from '@tabler/icons-react';
import { notifications } from '@mantine/notifications';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { api, useIfaceMonitors, useSLA, type SLAProfile } from '../api';
import { fmtBps, fmtPct } from '../format';

const empty: SLAProfile = {
  id: 0, name: '', max_rtt_ms: null, max_oneway_ms: null, max_jitter_ms: null,
  max_loss_pct: null, min_mos: null, max_util_pct: null, allow_remarking: false, breach_intervals: 3, channels: 0,
};

export function SlaPage() {
  const sla = useSLA();
  const [edit, setEdit] = useState<SLAProfile | null>(null);

  return (
    <>
      <div className="page-head">
        <div>
          <Title order={1}>Профили SLA</Title>
          <p>Профиль задаёт пороги качества и загрузки. Он назначается каналу на странице «Каналы», после чего работает движок алертов.</p>
        </div>
        <Button leftSection={<IconPlus size={16} />} onClick={() => setEdit(empty)}>Создать профиль</Button>
      </div>

      <div className="panel">
        {sla.isLoading ? <Loader /> : (
          <Table>
            <Table.Thead>
              <Table.Tr>
                <Table.Th>Профиль</Table.Th><Table.Th>RTT</Table.Th><Table.Th>Задержка</Table.Th>
                <Table.Th>Джиттер</Table.Th><Table.Th>Потери</Table.Th><Table.Th>MOS</Table.Th>
                <Table.Th>Загрузка</Table.Th><Table.Th>Перемарк.</Table.Th><Table.Th>Окно</Table.Th><Table.Th>Каналов</Table.Th>
              </Table.Tr>
            </Table.Thead>
            <Table.Tbody>
              {sla.data?.map((p) => (
                <Table.Tr key={p.id} className="clickable" onClick={() => setEdit(p)}>
                  <Table.Td fw={500}>{p.name}</Table.Td>
                  <Table.Td>{p.max_rtt_ms != null ? `≤ ${p.max_rtt_ms} мс` : '—'}</Table.Td>
                  <Table.Td>{p.max_oneway_ms != null ? `≤ ${p.max_oneway_ms} мс` : '—'}</Table.Td>
                  <Table.Td>{p.max_jitter_ms != null ? `≤ ${p.max_jitter_ms} мс` : '—'}</Table.Td>
                  <Table.Td>{p.max_loss_pct != null ? `≤ ${p.max_loss_pct}%` : '—'}</Table.Td>
                  <Table.Td>{p.min_mos != null ? `≥ ${p.min_mos}` : '—'}</Table.Td>
                  <Table.Td>{p.max_util_pct != null ? `≤ ${p.max_util_pct}%` : '—'}</Table.Td>
                  <Table.Td>{p.allow_remarking ? 'разрешена' : 'запрещена'}</Table.Td>
                  <Table.Td>{p.breach_intervals}</Table.Td>
                  <Table.Td>{p.channels}</Table.Td>
                </Table.Tr>
              ))}
            </Table.Tbody>
          </Table>
        )}
      </div>

      <LoadMonitors />

      {edit && <ProfileModal profile={edit} onClose={() => setEdit(null)} />}
    </>
  );
}

// Раздел с фактической загрузкой интерфейсов: сводка последних значений по всем мониторам.
function LoadMonitors() {
  const monitors = useIfaceMonitors();
  const navigate = useNavigate();

  return (
    <div className="panel" style={{ marginTop: 16 }}>
      <Title order={3} mb={4}>Загрузка интерфейсов</Title>
      <Text c="dimmed" size="sm" mb="sm">Фактическая нагрузка, снятая агентами со счётчиков ядра. Порог перегрузки задаётся полем «Загрузка» в профиле SLA.</Text>
      {monitors.isLoading ? <Loader size="sm" /> : (monitors.data?.length ?? 0) === 0 ? (
        <Text c="dimmed">Мониторинг загрузки не включён. В конфигурации агента добавьте интерфейсу monitor: true.</Text>
      ) : (
        <Table>
          <Table.Thead>
            <Table.Tr>
              <Table.Th>Агент / интерфейс</Table.Th><Table.Th>Номинал</Table.Th>
              <Table.Th>Приём</Table.Th><Table.Th>Отдача</Table.Th>
              <Table.Th>Утил. rx / tx</Table.Th><Table.Th>Отбросы</Table.Th>
            </Table.Tr>
          </Table.Thead>
          <Table.Tbody>
            {monitors.data?.map((m) => {
              const drops = (m.rx_drops ?? 0) + (m.tx_drops ?? 0);
              return (
                <Table.Tr key={m.id}>
                  <Table.Td>{m.agent} / {m.interface}</Table.Td>
                  <Table.Td>{m.speed_bits ? fmtBps(m.speed_bits) : '—'}</Table.Td>
                  <Table.Td className="dir-fwd">{fmtBps(m.rx_bps)}</Table.Td>
                  <Table.Td className="dir-bwd">{fmtBps(m.tx_bps)}</Table.Td>
                  <Table.Td>{fmtPct(m.rx_util_pct)} / {fmtPct(m.tx_util_pct)}</Table.Td>
                  <Table.Td c={drops > 0 ? 'red' : undefined}>{drops || '—'}</Table.Td>
                </Table.Tr>
              );
            })}
          </Table.Tbody>
        </Table>
      )}
      <Text size="xs" c="dimmed" mt="xs">Нажмите канал в списке каналов, чтобы увидеть график загрузки его интерфейса рядом с качеством.</Text>
      <Button variant="subtle" size="xs" mt={4} onClick={() => navigate('/channels')}>К каналам →</Button>
    </div>
  );
}

function ProfileModal({ profile, onClose }: { profile: SLAProfile; onClose: () => void }) {
  const [p, setP] = useState<SLAProfile>(profile);
  const qc = useQueryClient();
  const isNew = profile.id === 0;

  const save = useMutation({
    mutationFn: () => {
      const body = {
        name: p.name, max_rtt_ms: p.max_rtt_ms, max_oneway_ms: p.max_oneway_ms, max_jitter_ms: p.max_jitter_ms,
        max_loss_pct: p.max_loss_pct, min_mos: p.min_mos, max_util_pct: p.max_util_pct,
        allow_remarking: p.allow_remarking, breach_intervals: p.breach_intervals,
      };
      return isNew ? api.post('/v1/admin/sla-profiles', body) : api.put(`/v1/admin/sla-profiles/${p.id}`, body);
    },
    onSuccess: () => {
      notifications.show({ message: isNew ? 'Профиль создан' : 'Профиль сохранён', color: 'teal' });
      qc.invalidateQueries({ queryKey: ['sla'] });
      onClose();
    },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  // Ключи только числовых порогов — чтобы NumberInput не спорил с boolean/string-полями.
  type NumKey = 'max_rtt_ms' | 'max_oneway_ms' | 'max_jitter_ms' | 'max_loss_pct' | 'min_mos' | 'max_util_pct';
  const field = (key: NumKey, label: string, suffix: string) => (
    <NumberInput label={label} suffix={suffix} decimalScale={2} value={p[key] ?? ''} placeholder="не проверять"
      onChange={(v) => setP({ ...p, [key]: v === '' ? null : Number(v) })} />
  );

  return (
    <Modal opened onClose={onClose} title={isNew ? 'Новый профиль SLA' : `Профиль «${profile.name}»`} size="lg">
      <Stack>
        <TextInput label="Название" value={p.name} onChange={(e) => setP({ ...p, name: e.currentTarget.value })} required />
        <Text size="sm" fw={500}>Пороги качества (пусто — показатель не проверяется)</Text>
        <Group grow>
          {field('max_rtt_ms', 'RTT не более', ' мс')}
          {field('max_oneway_ms', 'Задержка в одну сторону', ' мс')}
        </Group>
        <Group grow>
          {field('max_jitter_ms', 'Джиттер не более', ' мс')}
          {field('max_loss_pct', 'Потери не более', ' %')}
        </Group>
        <Group grow>
          {field('min_mos', 'MOS не менее', '')}
          {field('max_util_pct', 'Загрузка интерфейса не более', ' %')}
        </Group>
        <Checkbox label="Перемаркировка DSCP допустима (не поднимать алерт)"
          checked={p.allow_remarking} onChange={(e) => setP({ ...p, allow_remarking: e.currentTarget.checked })} />
        <NumberInput label="Интервалов подряд для срабатывания" description="Защита от ложных всплесков"
          min={1} max={30} value={p.breach_intervals} onChange={(v) => setP({ ...p, breach_intervals: Number(v) || 3 })} />
        <Group justify="flex-end">
          <Button variant="default" onClick={onClose}>Отмена</Button>
          <Button onClick={() => save.mutate()} loading={save.isPending} disabled={!p.name.trim()}>Сохранить</Button>
        </Group>
      </Stack>
    </Modal>
  );
}
