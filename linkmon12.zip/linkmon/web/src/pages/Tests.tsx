import { useMemo, useState } from 'react';
import { ActionIcon, Badge, Group, Loader, Pagination, Table, Text, Title, Tooltip } from '@mantine/core';
import { IconTrash } from '@tabler/icons-react';
import { notifications } from '@mantine/notifications';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { api, useTestHistory, type Me } from '../api';
import { TestRunPanel } from '../components/TestRunPanel';
import { fmtTime, canManage } from '../format';

const PAGE = 20;

const statusBadge: Record<string, { label: string; color: string }> = {
  scheduled: { label: 'запланирован', color: 'blue' },
  running: { label: 'идёт', color: 'yellow' },
  done: { label: 'готов', color: 'teal' },
  failed: { label: 'ошибка', color: 'red' },
};

// История тестов: кто запустил, когда, что тестировали и результат. Пагинация по 20.
export function TestsPage({ me }: { me: Me }) {
  const runs = useTestHistory(500);
  const qc = useQueryClient();
  const manage = canManage(me.role);
  const [open, setOpen] = useState<number | null>(null);
  const [page, setPage] = useState(1);

  const all = runs.data ?? [];
  const pages = Math.max(1, Math.ceil(all.length / PAGE));
  const shown = useMemo(() => all.slice((page - 1) * PAGE, page * PAGE), [all, page]);

  const del = useMutation({
    mutationFn: (id: number) => api.del(`/v1/admin/tests/${id}`),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['test-history'] }); qc.invalidateQueries({ queryKey: ['tests'] }); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  return (
    <>
      <div className="page-head">
        <div>
          <Title order={1}>История тестов</Title>
          <p>Все запуски разовых тестов: кто и когда запустил, что тестировалось и с каким результатом. Нажмите строку, чтобы раскрыть подробности.</p>
        </div>
      </div>

      {open != null && (
        <div style={{ marginBottom: 16 }}>
          <TestRunPanel runId={open} onClose={() => setOpen(null)} />
        </div>
      )}

      <div className="panel">
        {runs.isLoading ? <Loader /> : all.length === 0 ? (
          <Text c="dimmed">Тестов ещё не было. Запустите тест канала или группы.</Text>
        ) : (
          <>
            <Table highlightOnHover>
              <Table.Thead>
                <Table.Tr>
                  <Table.Th>Запущен</Table.Th><Table.Th>Кто</Table.Th><Table.Th>Тип</Table.Th>
                  <Table.Th>Объект</Table.Th><Table.Th>Длит.</Table.Th><Table.Th>Готово</Table.Th><Table.Th>Статус</Table.Th>
                  {manage && <Table.Th w={48}></Table.Th>}
                </Table.Tr>
              </Table.Thead>
              <Table.Tbody>
                {shown.map((r) => {
                  const sb = statusBadge[r.status] ?? { label: r.status, color: 'gray' };
                  return (
                    <Table.Tr key={r.id} className="clickable" onClick={() => setOpen(r.id)}>
                      <Table.Td>{fmtTime(r.created_at)}</Table.Td>
                      <Table.Td>{r.created_by ?? '—'}</Table.Td>
                      <Table.Td>{r.kind === 'single' ? 'канал' : 'группа'}</Table.Td>
                      <Table.Td>{r.target}</Table.Td>
                      <Table.Td>{r.duration_sec} с</Table.Td>
                      <Table.Td>{r.received} / {r.expected}</Table.Td>
                      <Table.Td><Badge variant="light" color={sb.color}>{sb.label}</Badge></Table.Td>
                      {manage && (
                        <Table.Td onClick={(e) => e.stopPropagation()}>
                          <Tooltip label="Удалить прогон">
                            <ActionIcon variant="subtle" color="red" loading={del.isPending && del.variables === r.id}
                              onClick={() => { if (confirm('Удалить этот прогон и его результаты?')) del.mutate(r.id); }}>
                              <IconTrash size={16} />
                            </ActionIcon>
                          </Tooltip>
                        </Table.Td>
                      )}
                    </Table.Tr>
                  );
                })}
              </Table.Tbody>
            </Table>
            {pages > 1 && (
              <Group justify="space-between" mt="md">
                <Text size="sm" c="dimmed">Всего: {all.length}</Text>
                <Pagination total={pages} value={page} onChange={setPage} size="sm" />
              </Group>
            )}
          </>
        )}
      </div>
    </>
  );
}
