import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ActionIcon, Badge, Loader, SegmentedControl, Table, Text, Title, Tooltip } from '@mantine/core';
import { IconCheck } from '@tabler/icons-react';
import { notifications } from '@mantine/notifications';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { api, useAlerts, type Alert } from '../api';
import { alertKinds, fmtDuration, fmtTime } from '../format';

export function AlertsPage() {
  const [state, setState] = useState<'open' | 'all'>('open');
  const alerts = useAlerts(state);
  const navigate = useNavigate();
  const qc = useQueryClient();

  const ack = useMutation({
    mutationFn: (id: number) => api.post(`/v1/admin/alerts/${id}/ack`),
    onSuccess: () => {
      notifications.show({ message: 'Алерт подтверждён', color: 'teal' });
      qc.invalidateQueries({ queryKey: ['alerts'] });
      qc.invalidateQueries({ queryKey: ['overview'] });
    },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  return (
    <>
      <div className="page-head">
        <div>
          <Title order={1}>Алерты</Title>
          <p>Нарушение открывается, когда показатель выходит за порог SLA на нескольких интервалах подряд, и закрывается сам, когда всё снова в норме.</p>
        </div>
        <SegmentedControl value={state} onChange={(v) => setState(v as 'open' | 'all')}
          data={[{ value: 'open', label: 'Открытые' }, { value: 'all', label: 'Вся история' }]} />
      </div>

      <div className="panel">
        {alerts.isLoading ? <Loader /> : (alerts.data?.length ?? 0) === 0 ? (
          <Text c="dimmed">{state === 'open' ? 'Открытых алертов нет — все каналы в норме.' : 'История пуста.'}</Text>
        ) : (
          <Table>
            <Table.Thead>
              <Table.Tr>
                <Table.Th w={110}>Важность</Table.Th><Table.Th>Тип</Table.Th><Table.Th>Объект</Table.Th>
                <Table.Th>Подробности</Table.Th><Table.Th>Начало</Table.Th><Table.Th>Длительность</Table.Th>
                <Table.Th w={110}>Статус</Table.Th>
              </Table.Tr>
            </Table.Thead>
            <Table.Tbody>
              {alerts.data?.map((a) => (
                <Table.Tr key={a.id} className={a.channel_id ? 'clickable' : undefined}
                  onClick={() => a.channel_id && navigate(`/channels/${a.channel_id}`)}>
                  <Table.Td>
                    <Badge variant={a.ended_at ? 'outline' : 'light'} color={a.severity === 'critical' ? 'red' : 'yellow'}>
                      {a.severity === 'critical' ? 'критично' : 'внимание'}
                    </Badge>
                  </Table.Td>
                  <Table.Td>{alertKinds[a.kind] ?? a.kind}</Table.Td>
                  <Table.Td>
                    {a.channel ?? a.agent}
                    {a.dscp_name && <Text span size="xs" c="dimmed"> · {a.dscp_name}</Text>}
                  </Table.Td>
                  <Table.Td c="dimmed"><Details a={a} /></Table.Td>
                  <Table.Td>{fmtTime(a.started_at)}</Table.Td>
                  <Table.Td>{fmtDuration(a.started_at, a.ended_at)}{!a.ended_at && ' (идёт)'}</Table.Td>
                  <Table.Td onClick={(e) => e.stopPropagation()}>
                    {a.ended_at
                      ? <Badge size="sm" variant="outline" color="gray">закрыт</Badge>
                      : a.acked_at
                        ? <Badge size="sm" variant="light" color="teal">подтверждён</Badge>
                        : <Tooltip label="Подтвердить (снять звук)">
                            <ActionIcon variant="light" color="red" loading={ack.isPending}
                              onClick={() => ack.mutate(a.id)}><IconCheck size={16} /></ActionIcon>
                          </Tooltip>}
                  </Table.Td>
                </Table.Tr>
              ))}
            </Table.Tbody>
          </Table>
        )}
      </div>
    </>
  );
}

// Человекочитаемое описание алерта из его details (форма зависит от типа).
function Details({ a }: { a: Alert }) {
  const d = a.details ?? {};
  const num = (v: unknown) => (typeof v === 'number' ? v : null);
  switch (a.kind) {
    case 'rtt':
    case 'mos': {
      const v = num(d.value), lim = num(d.limit);
      return <>{v != null ? v.toFixed(1) : '—'} при пороге {lim ?? '—'}</>;
    }
    case 'loss': {
      const v = num(d.value);
      return <>{v != null ? `${v.toFixed(1)}%` : '—'} потерь</>;
    }
    case 'oneway':
    case 'jitter': {
      const f = num(d.fwd), b = num(d.bwd), lim = num(d.limit);
      return <>туда {f?.toFixed(1) ?? '—'}, обратно {b?.toFixed(1) ?? '—'} при пороге {lim ?? '—'} мс</>;
    }
    case 'util': {
      const f = num(d.rx), b = num(d.tx), lim = num(d.limit);
      return <>приём {f?.toFixed(0) ?? '—'}%, отдача {b?.toFixed(0) ?? '—'}% при пороге {lim ?? '—'}%</>;
    }
    case 'remarking':
      return <>перемаркировано пакетов: туда {String(d.fwd ?? 0)}, обратно {String(d.bwd ?? 0)}</>;
    case 'agent_down':
      return <>последний контакт: {d.last_seen ? fmtTime(String(d.last_seen)) : 'неизвестно'}</>;
    default:
      return <>—</>;
  }
}
