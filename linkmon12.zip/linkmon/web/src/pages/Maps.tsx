import { useEffect, useMemo, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import { Link } from 'react-router-dom';
import {
  ActionIcon, Badge, Button, Group, Loader, Modal, MultiSelect, Select, Stack, Text, TextInput, Title,
} from '@mantine/core';
import { IconPlus, IconTrash, IconDeviceFloppy, IconLock, IconServer2, IconRoute } from '@tabler/icons-react';
import { notifications } from '@mantine/notifications';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import {
  api, useMaps, useMap, useChannels, useAgents, useOverview, useUserNames,
  type DashVisibility, type MapGraph, type MapNode, type Channel, type LatestRow, type Alert, type Me,
} from '../api';
import { canManage, channelStatusFull, worstStatus, statusColor, statusLabel, fmtPct, fmtMs, type Status } from '../format';

const AGENT_DOWN_MS = 180_000; // агент не на связи дольше 3 мин — считаем недоступным

const W = 1000;
const H = 640;

const VIS: Record<DashVisibility, { label: string; color: string }> = {
  private: { label: 'личная', color: 'gray' },
  users: { label: 'по пользователям', color: 'grape' },
  shared: { label: 'общая', color: 'teal' },
};

export function MapsPage({ me }: { me: Me }) {
  const maps = useMaps();
  const qc = useQueryClient();
  const [selected, setSelected] = useState<number | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const active = selected ?? maps.data?.[0]?.id ?? null;
  const manage = canManage(me.role);

  const create = useMutation({
    mutationFn: (name: string) => api.post<{ id: number }>('/v1/admin/maps', { name }),
    onSuccess: (r) => { setSelected(r.id); qc.invalidateQueries({ queryKey: ['maps'] }); setCreateOpen(false); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  return (
    <>
      <div className="page-head">
        <div>
          <Title order={1}>Карты сети</Title>
          <p>Интерактивные карты: добавляйте агентов и выбирайте их каналы — ответное устройство и связь с состоянием добавляются автоматически. Элементы можно перетаскивать; карт может быть много, как дашбордов.</p>
        </div>
        <Group>
          <Select placeholder="Выберите карту" w={240}
            data={(maps.data ?? []).map((m) => ({ value: String(m.id), label: m.name + (m.own ? '' : ' (общая)') }))}
            value={active ? String(active) : null} onChange={(v) => setSelected(v ? Number(v) : null)} />
          {manage && <Button leftSection={<IconPlus size={16} />} onClick={() => setCreateOpen(true)}>Новая</Button>}
        </Group>
      </div>

      {maps.isLoading ? <Loader /> : active === null ? (
        <div className="panel"><Text c="dimmed">Карт пока нет. {manage ? 'Создайте первую.' : ''}</Text></div>
      ) : (
        <MapView key={active} id={active} onDeleted={() => { setSelected(null); qc.invalidateQueries({ queryKey: ['maps'] }); }} />
      )}

      {createOpen && (
        <Modal opened onClose={() => setCreateOpen(false)} title="Новая карта">
          <CreateForm loading={create.isPending} onCreate={(n) => create.mutate(n)} onCancel={() => setCreateOpen(false)} />
        </Modal>
      )}
    </>
  );
}

function CreateForm({ onCreate, onCancel, loading }: { onCreate: (n: string) => void; onCancel: () => void; loading: boolean }) {
  const [name, setName] = useState('');
  return (
    <Stack>
      <TextInput label="Название" value={name} onChange={(e) => setName(e.currentTarget.value)} autoFocus />
      <Group justify="flex-end">
        <Button variant="default" onClick={onCancel}>Отмена</Button>
        <Button loading={loading} disabled={!name.trim()} onClick={() => onCreate(name.trim())}>Создать</Button>
      </Group>
    </Stack>
  );
}

function MapView({ id, onDeleted }: { id: number; onDeleted: () => void }) {
  const map = useMap(id);
  const channels = useChannels();
  const overview = useOverview();
  const agents = useAgents();
  const qc = useQueryClient();

  const [graph, setGraph] = useState<MapGraph>({ nodes: [], edges: [] });
  const [dirty, setDirty] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [accessOpen, setAccessOpen] = useState(false);
  const [sel, setSel] = useState<string | null>(null); // выбранный узел (для панели деталей)

  // Загружаем граф в состояние при получении карты.
  useEffect(() => {
    if (map.data) setGraph(normalizeGraph(map.data.graph));
  }, [map.data]);

  const own = map.data?.own ?? false;

  const chById = useMemo(() => new Map((channels.data ?? []).map((c) => [c.id, c])), [channels.data]);
  const latestById = useMemo(
    () => new Map((overview.data?.latest ?? []).map((r) => [r.channel_id, r])),
    [overview.data],
  );
  // Открытые алерты по каналам (нарушение SLA = авария) и множество недоступных агентов.
  const alertsByChannel = useMemo(() => {
    const m = new Map<number, Alert[]>();
    for (const a of overview.data?.open_alerts ?? []) {
      if (a.channel_id == null || a.ended_at) continue;
      m.set(a.channel_id, [...(m.get(a.channel_id) ?? []), a]);
    }
    return m;
  }, [overview.data]);
  const downAgents = useMemo(() => {
    const down = new Set<string>();
    // Сигнал 1: открытый алерт agent_down (сервер посчитал недоступность).
    for (const a of overview.data?.open_alerts ?? []) {
      if (a.kind === 'agent_down' && a.agent_id && !a.ended_at) down.add(a.agent_id);
    }
    // Сигнал 2: по списку агентов (работает и для agent_mode=off, где алертов нет).
    const now = Date.now();
    for (const ag of agents.data ?? []) {
      if (ag.status !== 'approved') { down.add(ag.id); continue; }
      if (!ag.last_seen || now - new Date(ag.last_seen).getTime() > AGENT_DOWN_MS) down.add(ag.id);
    }
    return down;
  }, [overview.data, agents.data]);

  const save = useMutation({
    mutationFn: (g: MapGraph) => api.put(`/v1/admin/maps/${id}/graph`, g),
    onSuccess: () => { setDirty(false); qc.invalidateQueries({ queryKey: ['map', id] }); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });
  const del = useMutation({
    mutationFn: () => api.del(`/v1/admin/maps/${id}`),
    onSuccess: () => { notifications.show({ message: 'Карта удалена', color: 'teal' }); onDeleted(); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  // ---- добавление канала: гарантируем узлы агента и рефлектора + связь ----
  const addChannel = (ch: Channel) => {
    setGraph((g) => {
      const nodes = [...g.nodes];
      const aId = `a:${ch.agent_id}`;
      const rId = `r:${ch.reflector}`;
      if (!nodes.find((n) => n.id === aId)) {
        nodes.push({ id: aId, kind: 'agent', ref: ch.agent_id, label: ch.agent, x: 200 + rnd(80), y: 120 + rnd(60) });
      }
      if (!nodes.find((n) => n.id === rId)) {
        nodes.push({ id: rId, kind: 'reflector', ref: ch.reflector, label: ch.reflector, x: 640 + rnd(80), y: 300 + rnd(60) });
      }
      const edges = g.edges.find((e) => e.channel_id === ch.id) ? g.edges : [...g.edges, { channel_id: ch.id }];
      return { nodes, edges };
    });
    setDirty(true);
  };
  const addAgentNode = (agentId: string, label: string) => {
    setGraph((g) => {
      const aId = `a:${agentId}`;
      if (g.nodes.find((n) => n.id === aId)) return g;
      return { ...g, nodes: [...g.nodes, { id: aId, kind: 'agent', ref: agentId, label, x: 200 + rnd(120), y: 300 + rnd(120) }] };
    });
    setDirty(true);
  };
  const removeNode = (nodeId: string) => {
    setGraph((g) => {
      const nodes = g.nodes.filter((n) => n.id !== nodeId);
      // удаляем связи, чей агент- или рефлектор-узел исчез
      const edges = g.edges.filter((e) => {
        const ch = chById.get(e.channel_id);
        if (!ch) return false;
        return nodes.some((n) => n.id === `a:${ch.agent_id}`) && nodes.some((n) => n.id === `r:${ch.reflector}`);
      });
      return { nodes, edges };
    });
    setSel(null);
    setDirty(true);
  };
  const moveNode = (nodeId: string, x: number, y: number) => {
    setGraph((g) => ({ ...g, nodes: g.nodes.map((n) => (n.id === nodeId ? { ...n, x, y } : n)) }));
  };

  if (map.isLoading) return <Loader />;
  if (!map.data) return <Text c="dimmed">Карта недоступна.</Text>;

  return (
    <>
      <Group justify="space-between" mb="sm">
        <Group>
          <Title order={2}>{map.data.name}</Title>
          <Badge variant="light" color={VIS[map.data.visibility].color}>{VIS[map.data.visibility].label}</Badge>
          {!own && <Badge variant="outline" color="gray">только чтение</Badge>}
        </Group>
        {own && (
          <Group>
            <Button variant="light" leftSection={<IconServer2 size={16} />} onClick={() => setAddOpen(true)}>Добавить агента / канал</Button>
            <Button variant="subtle" leftSection={<IconLock size={16} />} onClick={() => setAccessOpen(true)}>Доступ</Button>
            <Button leftSection={<IconDeviceFloppy size={16} />} loading={save.isPending} disabled={!dirty} onClick={() => save.mutate(graph)}>Сохранить</Button>
            <ActionIcon variant="subtle" color="red" onClick={() => { if (confirm('Удалить карту?')) del.mutate(); }}><IconTrash size={18} /></ActionIcon>
          </Group>
        )}
      </Group>

      <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
        <div className="panel" style={{ flex: 1, padding: 0, overflow: 'hidden' }}>
          <MapCanvas graph={graph} chById={chById} latestById={latestById}
            alertsByChannel={alertsByChannel} downAgents={downAgents}
            editable={own} onMove={moveNode} onMoveEnd={() => setDirty(true)}
            selected={sel} onSelect={setSel} />
        </div>
        <MapSidePanel nodeId={sel} graph={graph} chById={chById} latestById={latestById}
          alertsByChannel={alertsByChannel} downAgents={downAgents}
          editable={own} onRemove={removeNode} />
      </div>

      {addOpen && own && (
        <AddModal onClose={() => setAddOpen(false)}
          onAddAgent={addAgentNode} onAddChannel={addChannel} />
      )}
      {accessOpen && own && (
        <MapAccessModal id={id} current={map.data.visibility} shares={map.data.shares} onClose={() => setAccessOpen(false)} />
      )}
    </>
  );
}

// ---- SVG-полотно с перетаскиванием ----
function MapCanvas({ graph, chById, latestById, alertsByChannel, downAgents, editable, onMove, onMoveEnd, selected, onSelect }: {
  graph: MapGraph;
  chById: Map<number, Channel>;
  latestById: Map<number, LatestRow>;
  alertsByChannel: Map<number, Alert[]>;
  downAgents: Set<string>;
  editable: boolean;
  onMove: (id: string, x: number, y: number) => void;
  onMoveEnd: () => void;
  selected: string | null;
  onSelect: (id: string | null) => void;
}) {
  // Состояние канала с учётом алертов (SLA) и недоступности агента.
  const edgeStatus = (channelID: number): Status => {
    const ch = chById.get(channelID);
    const agentDown = ch ? downAgents.has(ch.agent_id) : false;
    return channelStatusFull(latestById.get(channelID), alertsByChannel.get(channelID), agentDown);
  };
  const svgRef = useRef<SVGSVGElement | null>(null);
  const drag = useRef<{ id: string; dx: number; dy: number } | null>(null);
  const nodeById = useMemo(() => new Map(graph.nodes.map((n) => [n.id, n])), [graph.nodes]);

  const toSvg = (clientX: number, clientY: number) => {
    const svg = svgRef.current!;
    const rect = svg.getBoundingClientRect();
    return { x: ((clientX - rect.left) / rect.width) * W, y: ((clientY - rect.top) / rect.height) * H };
  };

  const onPointerMove = (e: ReactPointerEvent) => {
    if (!drag.current) return;
    const p = toSvg(e.clientX, e.clientY);
    const x = Math.max(30, Math.min(W - 30, p.x - drag.current.dx));
    const y = Math.max(30, Math.min(H - 30, p.y - drag.current.dy));
    onMove(drag.current.id, x, y);
  };
  const endDrag = () => {
    if (drag.current) { drag.current = null; onMoveEnd(); }
  };

  return (
    <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: H, background: 'var(--surface)', cursor: drag.current ? 'grabbing' : 'default' }}
      onPointerMove={onPointerMove} onPointerUp={endDrag} onPointerLeave={endDrag}
      onClick={(e) => { if (e.target === svgRef.current) onSelect(null); }}>
      {/* связи (каналы) */}
      {graph.edges.map((edge) => {
        const ch = chById.get(edge.channel_id);
        if (!ch) return null;
        const a = nodeById.get(`a:${ch.agent_id}`);
        const r = nodeById.get(`r:${ch.reflector}`);
        if (!a || !r) return null;
        const st = edgeStatus(edge.channel_id);
        const mx = (a.x + r.x) / 2, my = (a.y + r.y) / 2;
        return (
          <g key={edge.channel_id}>
            <line x1={a.x} y1={a.y} x2={r.x} y2={r.y} stroke={statusColor[st]} strokeWidth={3} opacity={0.85} />
            <circle cx={mx} cy={my} r={5} fill={statusColor[st]} />
            <title>{ch.label} · {ch.dscp_name} · {statusLabel[st]}</title>
          </g>
        );
      })}
      {/* узлы */}
      {graph.nodes.map((n) => {
        const st = nodeStatus(n, graph, chById, edgeStatus, downAgents);
        const isSel = selected === n.id;
        return (
          <g key={n.id} transform={`translate(${n.x},${n.y})`}
            style={{ cursor: editable ? 'grab' : 'pointer' }}
            onPointerDown={(e) => {
              onSelect(n.id);
              if (!editable) return;
              const p = toSvg(e.clientX, e.clientY);
              drag.current = { id: n.id, dx: p.x - n.x, dy: p.y - n.y };
              (e.target as Element).setPointerCapture?.(e.pointerId);
            }}>
            <circle r={22} fill={n.kind === 'agent' ? 'var(--cobalt, #1C7293)' : '#fff'}
              stroke={isSel ? '#111' : statusColor[st]} strokeWidth={isSel ? 3 : 2.5} />
            {n.kind === 'reflector' && <circle r={12} fill="none" stroke="#9AA7AE" strokeWidth={1.5} />}
            <circle cx={16} cy={-16} r={6} fill={statusColor[st]} stroke="#fff" strokeWidth={1.5} />
            <text y={40} textAnchor="middle" fontSize={12} fill="var(--ink, #1A2A33)">{trim(n.label, 22)}</text>
          </g>
        );
      })}
      {graph.nodes.length === 0 && (
        <text x={W / 2} y={H / 2} textAnchor="middle" fill="#9AA7AE" fontSize={15}>
          Пусто. Нажмите «Добавить агента / канал».
        </text>
      )}
    </svg>
  );
}

function MapSidePanel({ nodeId, graph, chById, latestById, alertsByChannel, downAgents, editable, onRemove }: {
  nodeId: string | null; graph: MapGraph; chById: Map<number, Channel>;
  latestById: Map<number, LatestRow>; alertsByChannel: Map<number, Alert[]>; downAgents: Set<string>;
  editable: boolean; onRemove: (id: string) => void;
}) {
  const node = graph.nodes.find((n) => n.id === nodeId);
  if (!node) {
    return <div className="panel" style={{ width: 300 }}><Text c="dimmed" size="sm">Выберите узел на карте, чтобы увидеть его каналы и состояние.</Text></div>;
  }
  const nodeDown = node.kind === 'agent' && downAgents.has(node.ref);
  // Каналы, инцидентные узлу.
  const edges = graph.edges.filter((e) => {
    const ch = chById.get(e.channel_id);
    if (!ch) return false;
    return `a:${ch.agent_id}` === node.id || `r:${ch.reflector}` === node.id;
  });
  return (
    <div className="panel" style={{ width: 300 }}>
      <Group justify="space-between" mb="xs">
        <Text fw={600}>{node.label}</Text>
        <Badge size="sm" variant="light" color={node.kind === 'agent' ? 'cyan' : 'gray'}>{node.kind === 'agent' ? 'агент' : 'узел-цель'}</Badge>
      </Group>
      {nodeDown && <Badge color="red" variant="filled" mb="xs">НЕДОСТУПЕН</Badge>}
      <Stack gap={6}>
        {edges.length === 0 ? <Text size="sm" c="dimmed">Нет связанных каналов.</Text> : edges.map((e) => {
          const ch = chById.get(e.channel_id)!;
          const row = latestById.get(e.channel_id);
          const st = channelStatusFull(row, alertsByChannel.get(e.channel_id), downAgents.has(ch.agent_id));
          return (
            <div key={e.channel_id} style={{ border: '1px solid var(--line)', borderRadius: 6, padding: '6px 8px' }}>
              <Group justify="space-between" gap={4}>
                <Text size="sm" component={Link} to={`/channels/${ch.id}`} style={{ textDecoration: 'none' }}>
                  {ch.dscp_name} → {ch.reflector}
                </Text>
                <Badge size="xs" variant="filled" style={{ background: statusColor[st] }}>{statusLabel[st]}</Badge>
              </Group>
              {row && (
                <Text size="xs" c="dimmed">
                  RTT {fmtMs(row.rtt_avg)} · потери {fmtPct(Math.max(row.fwd_loss_pct ?? 0, row.bwd_loss_pct ?? 0))}
                </Text>
              )}
            </div>
          );
        })}
        {editable && (
          <Button size="xs" variant="light" color="red" leftSection={<IconTrash size={14} />} mt="xs"
            onClick={() => onRemove(node.id)}>Убрать узел с карты</Button>
        )}
      </Stack>
    </div>
  );
}

function AddModal({ onClose, onAddAgent, onAddChannel }: {
  onClose: () => void; onAddAgent: (id: string, label: string) => void; onAddChannel: (ch: Channel) => void;
}) {
  const agents = useAgents();
  const channels = useChannels();
  const [agentId, setAgentId] = useState<string | null>(null);
  const approved = (agents.data ?? []).filter((a) => a.status === 'approved');
  const agentChannels = (channels.data ?? []).filter((c) => c.agent_id === agentId && !c.stale);

  return (
    <Modal opened onClose={onClose} title="Добавить на карту" size="lg">
      <Stack>
        <Select label="Агент / сервер" placeholder="выберите" searchable
          data={approved.map((a) => ({ value: a.id, label: a.name || a.hostname }))}
          value={agentId} onChange={setAgentId} />
        {agentId && (
          <>
            <Group justify="space-between">
              <Text size="sm" c="dimmed">Каналы агента — выберите, что мониторить (добавится цель и связь):</Text>
              <Button size="xs" variant="light" leftSection={<IconServer2 size={14} />}
                onClick={() => { const a = approved.find((x) => x.id === agentId)!; onAddAgent(a.id, a.name || a.hostname); }}>
                Только узел агента
              </Button>
            </Group>
            {agentChannels.length === 0 ? (
              <Text size="sm" c="dimmed">У агента нет активных каналов. Сначала создайте канал на странице «Агенты».</Text>
            ) : (
              <Stack gap={6}>
                {agentChannels.map((ch) => (
                  <Group key={ch.id} justify="space-between"
                    style={{ border: '1px solid var(--line)', borderRadius: 6, padding: '6px 10px' }}>
                    <div>
                      <Text size="sm">{ch.dscp_name} → {ch.reflector}</Text>
                      <Text size="xs" c="dimmed">{ch.interface}</Text>
                    </div>
                    <Button size="xs" leftSection={<IconRoute size={14} />}
                      onClick={() => onAddChannel(ch)}>Добавить канал</Button>
                  </Group>
                ))}
              </Stack>
            )}
          </>
        )}
        <Group justify="flex-end"><Button variant="default" onClick={onClose}>Готово</Button></Group>
      </Stack>
    </Modal>
  );
}

function MapAccessModal({ id, current, shares, onClose }: {
  id: number; current: DashVisibility; shares: number[]; onClose: () => void;
}) {
  const qc = useQueryClient();
  const users = useUserNames();
  const [vis, setVis] = useState<DashVisibility>(current);
  const [sel, setSel] = useState<string[]>(shares.map(String));
  const save = useMutation({
    mutationFn: () => api.patch(`/v1/admin/maps/${id}`, { visibility: vis, shares: vis === 'users' ? sel.map(Number) : [] }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['map', id] });
      qc.invalidateQueries({ queryKey: ['maps'] });
      notifications.show({ message: 'Доступ обновлён', color: 'teal' });
      onClose();
    },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });
  return (
    <Modal opened onClose={onClose} title="Доступ к карте">
      <Stack>
        <Select label="Кто видит карту" allowDeselect={false}
          data={[
            { value: 'private', label: 'Личная — только я' },
            { value: 'users', label: 'Выбранные пользователи' },
            { value: 'shared', label: 'Общая — все (чтение)' },
          ]}
          value={vis} onChange={(v) => setVis((v as DashVisibility) ?? 'private')} />
        {vis === 'users' && (
          <MultiSelect label="Пользователи" searchable
            data={(users.data ?? []).map((u) => ({ value: String(u.id), label: `${u.login} (${u.role})` }))}
            value={sel} onChange={setSel} />
        )}
        <Group justify="flex-end">
          <Button variant="default" onClick={onClose}>Отмена</Button>
          <Button loading={save.isPending} onClick={() => save.mutate()}>Сохранить</Button>
        </Group>
      </Stack>
    </Modal>
  );
}

// ---- helpers ----
function normalizeGraph(g: MapGraph | undefined): MapGraph {
  if (!g || !Array.isArray(g.nodes)) return { nodes: [], edges: [] };
  return { nodes: g.nodes, edges: Array.isArray(g.edges) ? g.edges : [] };
}
function nodeStatus(n: MapNode, g: MapGraph, chById: Map<number, Channel>, edgeStatus: (id: number) => Status, downAgents: Set<string>): Status {
  // Недоступный агент/сервер — красный узел.
  if (n.kind === 'agent' && downAgents.has(n.ref)) return 'crit';
  let worst: Status = 'nodata';
  for (const e of g.edges) {
    const ch = chById.get(e.channel_id);
    if (!ch) continue;
    if (`a:${ch.agent_id}` !== n.id && `r:${ch.reflector}` !== n.id) continue;
    worst = worstStatus(worst, edgeStatus(e.channel_id));
  }
  return worst;
}
function trim(s: string, n: number) { return s.length > n ? s.slice(0, n - 1) + '…' : s; }
function rnd(spread: number) { return Math.round((Math.random() - 0.5) * spread); }
