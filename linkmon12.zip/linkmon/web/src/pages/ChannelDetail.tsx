import { useMemo, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { Anchor, Badge, Breadcrumbs, Button, Group, Loader, Table, Text, Title } from '@mantine/core';
import { IconArrowLeft, IconPlayerPlay, IconFileText } from '@tabler/icons-react';
import {
  useAlerts, useChannelLoad, useChannels, useSeries, useSmoke, rangeWindow,
  type Me, type SeriesPoint,
} from '../api';
import { RangePicker, useStickyRange } from '../components/RangePicker';
import { SymmetricChart } from '../components/SymmetricChart';
import { SmokeChart } from '../components/SmokeChart';
import { LoadChart } from '../components/LoadChart';
import { LineChart } from '../components/LineChart';
import { TestRunPanel } from '../components/TestRunPanel';
import { ChannelTestModal } from './Channels';
import { tokens } from '../theme';
import { canManage, alertKinds, fmtMs, fmtPct, fmtTime, minuteGaps } from '../format';

export function ChannelDetailPage({ me }: { me: Me }) {
  const { id } = useParams();
  const channelId = Number(id);
  const [range, setRange] = useStickyRange('linkmon.range.channel', '6h');
  const [params, setParams] = useSearchParams();
  const [testOpen, setTestOpen] = useState(false);
  const runId = params.get('run') ? Number(params.get('run')) : null;

  const channels = useChannels();
  const series = useSeries(channelId, range);
  const smoke = useSmoke(channelId, range);
  const load = useChannelLoad(channelId, range);
  const alerts = useAlerts('all', channelId);

  const channel = channels.data?.find((c) => c.id === channelId);
  const pts = series.data?.points ?? [];
  const ts = useMemo(() => pts.map((p) => p.ts), [pts]);
  const col = (k: keyof SeriesPoint) => pts.map((p) => p[k] as number | null);
  const win = useMemo(() => rangeWindow(range), [range]);
  // Красные зоны-пропуски показываем только для поминутных диапазонов (не для часовых агрегатов 7 дн).
  const gaps = useMemo(() => (range === '7d' ? [] : minuteGaps(ts, win.max)), [ts, range, win.max]);

  if (channels.isLoading) return <Loader />;
  if (!channel) return <Text>Канал не найден. <Link to="/channels">К списку каналов</Link></Text>;

  const openAlerts = (alerts.data ?? []).filter((a) => !a.ended_at);

  return (
    <>
      <Breadcrumbs mb="sm" separator="›">
        <Anchor component={Link} to="/channels" c="dimmed"><Group gap={4}><IconArrowLeft size={14} />Каналы</Group></Anchor>
        <Text>{channel.label}</Text>
      </Breadcrumbs>

      <div className="page-head">
        <div>
          <Title order={1}>{channel.label}</Title>
          <p>
            {channel.agent} / {channel.interface}, класс <b>{channel.dscp_name}</b> до {channel.reflector}.
            {' '}Верх графиков — направление к серверу, низ — обратно.
          </p>
          {channel.tags.length > 0 && (
            <Group gap={4} mt={4}>{channel.tags.map((t) => <Badge key={t} size="sm" variant="light" color="cobalt">{t}</Badge>)}</Group>
          )}
        </div>
        <Group>
          {canManage(me.role) && <Button variant="light" leftSection={<IconPlayerPlay size={16} />} onClick={() => setTestOpen(true)}>Тест канала</Button>}
          <Button component={Link} to={`/report/channel/${channelId}`} variant="default" leftSection={<IconFileText size={16} />}>Отчёт / PDF</Button>
          <RangePicker value={range} onChange={setRange} />
        </Group>
      </div>

      {runId && <TestRunPanel runId={runId} onClose={() => { params.delete('run'); setParams(params, { replace: true }); }} />}

      {openAlerts.length > 0 && (
        <div className="panel" style={{ borderColor: 'var(--crit)' }}>
          <Group gap="xs">
            <Text fw={600}>Открытые нарушения:</Text>
            {openAlerts.map((a) => (
              <Badge key={a.id} color={a.severity === 'critical' ? 'red' : 'yellow'} variant="light">
                {alertKinds[a.kind] ?? a.kind}
              </Badge>
            ))}
          </Group>
        </div>
      )}

      {series.data?.source === 'v_measurements_1h' && (
        <Text size="sm" c="dimmed" mb="xs">Показаны часовые агрегаты (диапазон больше 48 часов).</Text>
      )}
      {gaps.length > 0 && (
        <Text size="sm" mb="xs" style={{ color: 'var(--crit)' }}>
          Красные зоны — минуты без данных: агент не присылал измерения (простой или сбой агента).
        </Text>
      )}

      <div className="chart-grid" key={range}>
        <SymmetricChart title="Задержка в одну сторону" info="oneway" ts={ts} fwd={col('fwd_delay_avg')} bwd={col('bwd_delay_avg')}
          fmt={fmtMs} xMin={win.min} xMax={win.max} gaps={gaps} note="Достоверна только при синхронных часах агента и сервера." />
        <SymmetricChart title="Потери пакетов" info="loss" ts={ts} fwd={col('fwd_loss_pct')} bwd={col('bwd_loss_pct')} fmt={fmtPct} kind="bar" xMin={win.min} xMax={win.max} gaps={gaps} />
        <SymmetricChart title="Джиттер" info="jitter" ts={ts} fwd={col('fwd_jitter')} bwd={col('bwd_jitter')} fmt={fmtMs} xMin={win.min} xMax={win.max} gaps={gaps} />
        <SmokeChart points={smoke.data?.points ?? []} xMin={win.min} xMax={win.max} />
        <LineChart title="RTT (среднее)" info="rtt" ts={ts} values={col('rtt_avg')} fmt={fmtMs} color={tokens.ink} xMin={win.min} xMax={win.max} gaps={gaps} />
        <LineChart title="MOS (качество речи)" info="mos" ts={ts} values={col('mos')} fmt={(v) => v.toFixed(2)}
          color={tokens.ok} min={1} max={5} xMin={win.min} xMax={win.max} gaps={gaps} note="Оценка по E-модели G.107: 5 — отлично, ниже 3.1 — плохо." />
      </div>

      <div className="panel" style={{ marginTop: 16 }}>
        {load.isLoading ? <Loader size="sm" /> : (load.data?.monitor_id ?? 0) === 0 ? (
          <Text c="dimmed">
            Загрузка этого интерфейса не отслеживается. Включите monitor в конфигурации агента для интерфейса {channel.interface}.
          </Text>
        ) : (
          <LoadChart points={load.data?.points ?? []} xMin={win.min} xMax={win.max} gaps={gaps} />
        )}
      </div>

      <div className="panel" style={{ marginTop: 16 }}>
        <Title order={3} mb="sm">История нарушений SLA</Title>
        {(alerts.data?.length ?? 0) === 0 ? <Text c="dimmed">Нарушений не было.</Text> : (
          <Table>
            <Table.Thead>
              <Table.Tr><Table.Th>Тип</Table.Th><Table.Th>Начало</Table.Th><Table.Th>Конец</Table.Th><Table.Th>Статус</Table.Th></Table.Tr>
            </Table.Thead>
            <Table.Tbody>
              {alerts.data?.map((a) => (
                <Table.Tr key={a.id}>
                  <Table.Td>{alertKinds[a.kind] ?? a.kind}</Table.Td>
                  <Table.Td>{fmtTime(a.started_at)}</Table.Td>
                  <Table.Td>{a.ended_at ? fmtTime(a.ended_at) : '—'}</Table.Td>
                  <Table.Td>
                    {a.ended_at
                      ? <Badge variant="light" color="gray">закрыт</Badge>
                      : <Badge variant="light" color={a.severity === 'critical' ? 'red' : 'yellow'}>открыт</Badge>}
                  </Table.Td>
                </Table.Tr>
              ))}
            </Table.Tbody>
          </Table>
        )}
      </div>

      {testOpen && <ChannelTestModal channel={channel} onClose={() => setTestOpen(false)}
        onStarted={(runId) => { setTestOpen(false); params.set('run', String(runId)); setParams(params, { replace: true }); }} />}
    </>
  );
}
