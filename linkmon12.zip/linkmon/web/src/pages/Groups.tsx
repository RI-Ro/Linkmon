import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Badge, Button, Group, Loader, Modal, NumberInput, Stack, Table, Text, TextInput, Title, ActionIcon, Tooltip,
} from '@mantine/core';
import { IconPlus, IconTrash, IconPlayerPlay, IconFileText } from '@tabler/icons-react';
import { notifications } from '@mantine/notifications';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { api, useChannels, useGroups, useTestRuns, type Group as Grp, type Me } from '../api';
import { canManage, fmtTime } from '../format';

export function GroupsPage({ me }: { me: Me }) {
  const groups = useGroups();
  const manage = canManage(me.role);
  const [selected, setSelected] = useState<number | null>(null);
  const [createOpen, setCreateOpen] = useState(false);

  const active = groups.data?.find((g) => g.id === selected) ?? null;

  return (
    <>
      <div className="page-head">
        <div>
          <Title order={1}>Группы и тесты</Title>
          <p>Каналы объединяются в группы (например, по филиалу или сервису). Тест группы запускает измерение на всех её каналах одновременно — удобно для приёмки канала.</p>
        </div>
        {manage && <Button leftSection={<IconPlus size={16} />} onClick={() => setCreateOpen(true)}>Создать группу</Button>}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', gap: 16, alignItems: 'start' }}>
        <div className="panel tree">
          {groups.isLoading ? <Loader size="sm" /> : (groups.data?.length ?? 0) === 0
            ? <Text c="dimmed" size="sm">Групп пока нет.</Text>
            : <GroupTree groups={groups.data!} selected={selected} onSelect={setSelected} />}
        </div>
        {active ? <GroupDetail group={active} manage={manage} /> : (
          <div className="panel"><Text c="dimmed">Выберите группу слева, чтобы увидеть её каналы и запустить тест.</Text></div>
        )}
      </div>

      {manage && <CreateGroupModal opened={createOpen} onClose={() => setCreateOpen(false)} groups={groups.data ?? []} />}
    </>
  );
}

// Дерево групп по parent_id, с отступами по уровню вложенности.
function GroupTree({ groups, selected, onSelect }: { groups: Grp[]; selected: number | null; onSelect: (id: number) => void }) {
  const children = useMemo(() => {
    const m = new Map<number | null, Grp[]>();
    for (const g of groups) {
      const key = g.parent_id;
      m.set(key, [...(m.get(key) ?? []), g]);
    }
    return m;
  }, [groups]);

  const render = (parent: number | null, depth: number): JSX.Element[] =>
    (children.get(parent) ?? []).flatMap((g) => [
      <button key={g.id} className={g.id === selected ? 'active' : ''} style={{ paddingLeft: 8 + depth * 16 }}
        onClick={() => onSelect(g.id)}>
        {g.name}<span className="n">{g.channels}</span>
      </button>,
      ...render(g.id, depth + 1),
    ]);

  return <>{render(null, 0)}</>;
}

function GroupDetail({ group, manage }: { group: Grp; manage: boolean }) {
  const channels = useChannels();
  const runs = useTestRuns(group.id);
  const qc = useQueryClient();
  const [testOpen, setTestOpen] = useState(false);

  const members = (channels.data ?? []).filter((c) => c.groups.includes(group.id));

  const removeMember = useMutation({
    mutationFn: (channelId: number) => api.del(`/v1/admin/groups/${group.id}/members/${channelId}`),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['channels'] });
      qc.invalidateQueries({ queryKey: ['groups'] });
    },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  const del = useMutation({
    mutationFn: () => api.del(`/v1/admin/groups/${group.id}`),
    onSuccess: () => {
      notifications.show({ message: 'Группа удалена', color: 'teal' });
      qc.invalidateQueries({ queryKey: ['groups'] });
    },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  return (
    <div>
      <div className="panel">
        <Group justify="space-between" mb="sm">
          <Title order={3}>{group.name}</Title>
          <Group gap="xs">
            <Button size="xs" variant="default" component={Link} to={`/report/group/${group.id}`}
              leftSection={<IconFileText size={14} />} disabled={members.length === 0}>Отчёт / PDF</Button>
            {manage && <Button size="xs" leftSection={<IconPlayerPlay size={14} />} disabled={members.length === 0}
              onClick={() => setTestOpen(true)}>Запустить тест</Button>}
            {manage && <Button size="xs" variant="default" color="red" leftSection={<IconTrash size={14} />}
              onClick={() => { if (confirm(`Удалить группу «${group.name}»?`)) del.mutate(); }}>Удалить</Button>}
          </Group>
        </Group>
        {members.length === 0 ? (
          <Text c="dimmed" size="sm">В группе нет каналов. Добавьте их со страницы «Каналы» — выделите нужные и выберите группу.</Text>
        ) : (
          <Table>
            <Table.Thead>
              <Table.Tr><Table.Th>Канал</Table.Th><Table.Th>Класс</Table.Th><Table.Th>Рефлектор</Table.Th><Table.Th /></Table.Tr>
            </Table.Thead>
            <Table.Tbody>
              {members.map((c) => (
                <Table.Tr key={c.id}>
                  <Table.Td>{c.label} <Text span size="xs" c="dimmed">({c.agent} / {c.interface})</Text></Table.Td>
                  <Table.Td><Badge variant="outline" color="dark">{c.dscp_name}</Badge></Table.Td>
                  <Table.Td>{c.reflector}</Table.Td>
                  <Table.Td>
                    {manage && <Tooltip label="Убрать из группы">
                      <ActionIcon variant="subtle" color="gray" onClick={() => removeMember.mutate(c.id)}><IconTrash size={16} /></ActionIcon>
                    </Tooltip>}
                  </Table.Td>
                </Table.Tr>
              ))}
            </Table.Tbody>
          </Table>
        )}
      </div>

      <div className="panel">
        <Title order={3} mb="sm">Недавние тесты</Title>
        {(runs.data?.length ?? 0) === 0 ? <Text c="dimmed" size="sm">Тестов ещё не было.</Text> : (
          <Table>
            <Table.Thead>
              <Table.Tr><Table.Th>Запуск</Table.Th><Table.Th>Длит.</Table.Th><Table.Th>Готово</Table.Th><Table.Th>Статус</Table.Th></Table.Tr>
            </Table.Thead>
            <Table.Tbody>
              {runs.data?.map((r) => (
                <Table.Tr key={r.id}>
                  <Table.Td>{fmtTime(r.start_at)}</Table.Td>
                  <Table.Td>{r.duration_sec} с</Table.Td>
                  <Table.Td>{r.received} / {r.expected}</Table.Td>
                  <Table.Td><TestStatus status={r.status} /></Table.Td>
                </Table.Tr>
              ))}
            </Table.Tbody>
          </Table>
        )}
      </div>

      <RunTestModal opened={testOpen} onClose={() => setTestOpen(false)} groupId={group.id} count={members.length} />
    </div>
  );
}

function TestStatus({ status }: { status: string }) {
  const map: Record<string, { label: string; color: string }> = {
    scheduled: { label: 'запланирован', color: 'blue' },
    running: { label: 'идёт', color: 'yellow' },
    done: { label: 'готов', color: 'teal' },
    failed: { label: 'ошибка', color: 'red' },
  };
  const s = map[status] ?? { label: status, color: 'gray' };
  return <Badge variant="light" color={s.color}>{s.label}</Badge>;
}

function RunTestModal({ opened, onClose, groupId, count }: { opened: boolean; onClose: () => void; groupId: number; count: number }) {
  const [pps, setPps] = useState<number | string>(100);
  const [size, setSize] = useState<number | string>(128);
  const [dur, setDur] = useState<number | string>(60);
  const qc = useQueryClient();

  const run = useMutation({
    mutationFn: () => api.post<{ run_id: number; channels: number }>(`/v1/admin/groups/${groupId}/tests`, {
      pps: Number(pps), packet_size: Number(size), duration_sec: Number(dur),
    }),
    onSuccess: (r) => {
      notifications.show({ message: `Тест запущен на ${r.channels} каналах`, color: 'teal' });
      qc.invalidateQueries({ queryKey: ['tests', groupId] });
      onClose();
    },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  return (
    <Modal opened={opened} onClose={onClose} title="Запуск теста группы">
      <Stack>
        <Text size="sm" c="dimmed">Тест пройдёт одновременно на {count} каналах группы и подгрупп. Тестовый трафик не влияет на постоянную статистику.</Text>
        <Group grow>
          <NumberInput label="Пакетов в секунду" min={1} max={1000} value={pps} onChange={setPps} />
          <NumberInput label="Размер пакета, Б" min={80} max={1472} value={size} onChange={setSize} />
          <NumberInput label="Длительность, с" min={1} max={600} value={dur} onChange={setDur} />
        </Group>
        <Group justify="flex-end">
          <Button onClick={() => run.mutate()} loading={run.isPending} leftSection={<IconPlayerPlay size={16} />}>Запустить</Button>
        </Group>
      </Stack>
    </Modal>
  );
}

function CreateGroupModal({ opened, onClose, groups }: { opened: boolean; onClose: () => void; groups: Grp[] }) {
  const [name, setName] = useState('');
  const [parentId, setParentId] = useState<number | null>(null);
  const qc = useQueryClient();

  const create = useMutation({
    mutationFn: () => api.post<{ id: number }>('/v1/admin/groups', { name, parent_id: parentId }),
    onSuccess: () => {
      notifications.show({ message: 'Группа создана', color: 'teal' });
      qc.invalidateQueries({ queryKey: ['groups'] });
      setName('');
      setParentId(null);
      onClose();
    },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  return (
    <Modal opened={opened} onClose={onClose} title="Новая группа">
      <Stack>
        <TextInput label="Название" value={name} onChange={(e) => setName(e.currentTarget.value)} autoFocus required />
        <div>
          <Text size="sm" fw={500} mb={4}>Родительская группа</Text>
          <select style={{ width: '100%', padding: '8px', borderRadius: 4, border: '1px solid var(--line)' }}
            value={parentId ?? ''} onChange={(e) => setParentId(e.target.value ? Number(e.target.value) : null)}>
            <option value="">— верхний уровень —</option>
            {groups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
          </select>
        </div>
        <Group justify="flex-end">
          <Button onClick={() => create.mutate()} loading={create.isPending} disabled={!name.trim()}>Создать</Button>
        </Group>
      </Stack>
    </Modal>
  );
}
