import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ActionIcon, Badge, Button, Checkbox, Group, Menu, Modal, Select, Stack, Switch,
  TagsInput, Table, Text, TextInput, Title,
} from '@mantine/core';
import { IconDots, IconPencil, IconTrash, IconPlayerPlay, IconTag } from '@tabler/icons-react';
import { notifications } from '@mantine/notifications';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { api, useChannels, useGroups, useSLA, useTags, type Channel, type ChannelPatch, type Me } from '../api';
import { canManage } from '../format';

export function ChannelsPage({ me }: { me: Me }) {
  const channels = useChannels();
  const groups = useGroups();
  const sla = useSLA();
  const tags = useTags();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const manage = canManage(me.role);
  const [q, setQ] = useState('');
  const [agent, setAgent] = useState<string | null>(null);
  const [tag, setTag] = useState<string | null>(null);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [target, setTarget] = useState<string | null>(null);
  const [edit, setEdit] = useState<Channel | null>(null);
  const [test, setTest] = useState<Channel | null>(null);

  const groupName = useMemo(() => new Map((groups.data ?? []).map((g) => [g.id, g.name])), [groups.data]);
  const agents = useMemo(() => [...new Set((channels.data ?? []).map((c) => c.agent))].sort(), [channels.data]);
  const list = (channels.data ?? []).filter((c) =>
    (!agent || c.agent === agent) &&
    (!tag || c.tags.includes(tag)) &&
    (!q || `${c.label} ${c.agent} ${c.interface} ${c.reflector} ${c.dscp_name} ${c.tags.join(' ')}`.toLowerCase().includes(q.toLowerCase())));

  const patch = useMutation({
    mutationFn: ({ id, p }: { id: number; p: ChannelPatch }) => api.patch(`/v1/admin/channels/${id}`, p),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['channels'] });
      qc.invalidateQueries({ queryKey: ['tags'] });
      qc.invalidateQueries({ queryKey: ['sla'] });
    },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  const del = useMutation({
    mutationFn: (id: number) => api.del(`/v1/admin/channels/${id}`),
    onSuccess: () => { notifications.show({ message: 'Канал удалён', color: 'teal' }); qc.invalidateQueries({ queryKey: ['channels'] }); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  const addToGroup = useMutation({
    mutationFn: () => api.post<{ added: number }>(`/v1/admin/groups/${target}/members`, { channel_ids: [...selected] }),
    onSuccess: (r) => {
      notifications.show({ message: `Добавлено в группу: ${r.added}`, color: 'teal' });
      setSelected(new Set());
      qc.invalidateQueries({ queryKey: ['channels'] });
      qc.invalidateQueries({ queryKey: ['groups'] });
    },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  const toggle = (id: number) => setSelected((s) => {
    const n = new Set(s);
    if (n.has(id)) n.delete(id); else n.add(id);
    return n;
  });
  const allSelected = list.length > 0 && list.every((c) => selected.has(c.id));

  return (
    <>
      <div className="page-head">
        <div>
          <Title order={1}>Каналы</Title>
          <p>Канал — это интерфейс агента, рефлектор и класс DSCP. Задайте своё имя и теги, чтобы удобнее искать и группировать. Каналы создаются автоматически из конфигурации агента.</p>
        </div>
        <Button variant="default" className="no-print" onClick={() => window.print()}>Экспорт PDF</Button>
      </div>

      <Group mb="md" align="flex-end" className="no-print">
        <TextInput placeholder="Поиск по имени, тегам, интерфейсу, классу" value={q} onChange={(e) => setQ(e.currentTarget.value)} w={320} />
        <Select placeholder="Все агенты" clearable data={agents} value={agent} onChange={setAgent} w={200} />
        <Select placeholder="Все теги" clearable data={tags.data ?? []} value={tag} onChange={setTag} w={180} />
        {manage && selected.size > 0 && (
          <>
            <Select placeholder="Выберите группу" data={(groups.data ?? []).map((g) => ({ value: String(g.id), label: g.name }))}
              value={target} onChange={setTarget} w={200} />
            <Button disabled={!target} loading={addToGroup.isPending} onClick={() => addToGroup.mutate()}>
              В группу ({selected.size})
            </Button>
          </>
        )}
      </Group>

      <div className="panel">
        {list.length === 0 ? <Text c="dimmed">Под фильтр ничего не попало.</Text> : (
          <Table>
            <Table.Thead>
              <Table.Tr>
                {manage && <Table.Th w={36}>
                  <Checkbox aria-label="Выбрать все" checked={allSelected}
                    onChange={() => setSelected(allSelected ? new Set() : new Set(list.map((c) => c.id)))} />
                </Table.Th>}
                <Table.Th>Канал</Table.Th><Table.Th>Класс</Table.Th><Table.Th>Теги</Table.Th>
                <Table.Th>Группы</Table.Th><Table.Th w={190}>SLA</Table.Th><Table.Th>Вкл.</Table.Th>
                {manage && <Table.Th w={44} />}
              </Table.Tr>
            </Table.Thead>
            <Table.Tbody>
              {list.map((c) => (
                <Table.Tr key={c.id} className="clickable" onClick={() => navigate(`/channels/${c.id}`)}>
                  {manage && <Table.Td onClick={(e) => e.stopPropagation()}>
                    <Checkbox aria-label={`Выбрать ${c.label}`} checked={selected.has(c.id)} onChange={() => toggle(c.id)} />
                  </Table.Td>}
                  <Table.Td>
                    <Group gap={6}>
                      {c.label}
                      {c.stale && <Badge size="xs" color="gray" variant="outline">нет в конфиге</Badge>}
                    </Group>
                    <Text size="xs" c="dimmed">{c.agent} / {c.interface}{c.source_ip ? ` · ${c.source_ip}` : ''}</Text>
                  </Table.Td>
                  <Table.Td><Badge variant="outline" color="dark">{c.dscp_name}</Badge></Table.Td>
                  <Table.Td>
                    <Group gap={4}>{c.tags.map((t) => <Badge key={t} size="sm" variant="light" color="cobalt">{t}</Badge>)}</Group>
                  </Table.Td>
                  <Table.Td>
                    <Group gap={4}>{c.groups.map((g) => <Badge key={g} variant="light" size="sm">{groupName.get(g) ?? g}</Badge>)}</Group>
                  </Table.Td>
                  <Table.Td onClick={(e) => e.stopPropagation()}>
                    <Select size="xs" placeholder="без SLA" clearable disabled={!manage} value={c.sla_id ? String(c.sla_id) : null}
                      data={(sla.data ?? []).map((s) => ({ value: String(s.id), label: s.name }))}
                      onChange={(v) => patch.mutate({ id: c.id, p: v ? { sla_id: Number(v) } : { clear_sla: true } })} />
                  </Table.Td>
                  <Table.Td onClick={(e) => e.stopPropagation()}>
                    <Switch aria-label="Канал включён" checked={c.enabled} disabled={!manage}
                      onChange={(e) => patch.mutate({ id: c.id, p: { enabled: e.currentTarget.checked } })} />
                  </Table.Td>
                  {manage && <Table.Td onClick={(e) => e.stopPropagation()}>
                    <Menu position="bottom-end" withinPortal>
                      <Menu.Target><ActionIcon variant="subtle" color="gray"><IconDots size={18} /></ActionIcon></Menu.Target>
                      <Menu.Dropdown>
                        <Menu.Item leftSection={<IconPencil size={14} />} onClick={() => setEdit(c)}>Имя и теги</Menu.Item>
                        <Menu.Item leftSection={<IconPlayerPlay size={14} />} onClick={() => setTest(c)}>Запустить тест</Menu.Item>
                        <Menu.Divider />
                        <Menu.Item color="red" leftSection={<IconTrash size={14} />}
                          onClick={() => { if (confirm(`Удалить канал «${c.label}»? История измерений будет удалена.`)) del.mutate(c.id); }}>
                          Удалить
                        </Menu.Item>
                      </Menu.Dropdown>
                    </Menu>
                  </Table.Td>}
                </Table.Tr>
              ))}
            </Table.Tbody>
          </Table>
        )}
      </div>

      {edit && <EditChannelModal channel={edit} suggestions={tags.data ?? []} onClose={() => setEdit(null)}
        onSave={(p) => { patch.mutate({ id: edit.id, p }); setEdit(null); }} />}
      {test && <ChannelTestModal channel={test} onClose={() => setTest(null)}
        onStarted={(runId) => { setTest(null); navigate(`/channels/${test.id}?run=${runId}`); }} />}
    </>
  );
}

function EditChannelModal({ channel, suggestions, onClose, onSave }:
  { channel: Channel; suggestions: string[]; onClose: () => void; onSave: (p: ChannelPatch) => void }) {
  const [name, setName] = useState(channel.display_name ?? '');
  const [tags, setTags] = useState<string[]>(channel.tags);
  return (
    <Modal opened onClose={onClose} title="Имя и теги канала">
      <Stack>
        <TextInput label="Своё имя канала" placeholder={channel.name} value={name}
          onChange={(e) => setName(e.currentTarget.value)}
          description="Пусто — показывать авто-имя" leftSection={<IconPencil size={14} />} />
        <TagsInput label="Теги" placeholder="добавьте тег и Enter" data={suggestions} value={tags} onChange={setTags}
          leftSection={<IconTag size={14} />} clearable />
        <Group justify="flex-end">
          <Button variant="default" onClick={onClose}>Отмена</Button>
          <Button onClick={() => onSave({ display_name: name, tags })}>Сохранить</Button>
        </Group>
      </Stack>
    </Modal>
  );
}

export function ChannelTestModal({ channel, onClose, onStarted }:
  { channel: Channel; onClose: () => void; onStarted: (runId: number) => void }) {
  const [pps, setPps] = useState(100);
  const [dur, setDur] = useState(30);
  const run = useMutation({
    mutationFn: () => api.post<{ run_id: number }>(`/v1/admin/channels/${channel.id}/test`, { pps, duration_sec: dur }),
    onSuccess: (r) => { notifications.show({ message: 'Тест запущен', color: 'teal' }); onStarted(r.run_id); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });
  return (
    <Modal opened onClose={onClose} title={`Тест канала «${channel.label}»`}>
      <Stack>
        <Text size="sm" c="dimmed">Разовый нагрузочный тест канала. Тестовый трафик не влияет на постоянную статистику.</Text>
        <Group grow>
          <TextInput label="Пакетов/с" type="number" value={pps} onChange={(e) => setPps(Number(e.currentTarget.value) || 100)} />
          <TextInput label="Длительность, с" type="number" value={dur} onChange={(e) => setDur(Number(e.currentTarget.value) || 30)} />
        </Group>
        <Group justify="flex-end">
          <Button variant="default" onClick={onClose}>Отмена</Button>
          <Button loading={run.isPending} leftSection={<IconPlayerPlay size={16} />} onClick={() => run.mutate()}>Запустить</Button>
        </Group>
      </Stack>
    </Modal>
  );
}
