import { useState, type ReactNode } from 'react';
import {
  ActionIcon, Badge, Button, Group, Loader, Menu, Modal, MultiSelect, NumberInput,
  Select, Stack, Table, Text, TextInput, Title,
} from '@mantine/core';
import {
  IconPlus, IconTrash, IconDeviceFloppy, IconPencil, IconArrowUp, IconArrowDown, IconChartLine, IconX, IconLock,
} from '@tabler/icons-react';
import ReactECharts from 'echarts-for-react';
import { notifications } from '@mantine/notifications';
import { useMutation, useQueries, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  api, ranges, useChannels, useDashboard, useDashboards, useIfaceMonitors, useOverview, useUserNames,
  type DashVisibility, type DashWidget, type LoadPoint, type RangeKey, type SeriesPoint, type WidgetConfig, type WidgetKind,
} from '../api';
import { tokens } from '../theme';
import { fmtBps, fmtMs, fmtPct } from '../format';

// Доступные метрики каналов для виджетов. Каждая — колонка v_measurements + формат.
const METRICS: { value: string; label: string; fmt: (v: number | null | undefined) => string }[] = [
  { value: 'rtt_avg', label: 'RTT средн.', fmt: fmtMs },
  { value: 'rtt_p95', label: 'RTT p95', fmt: fmtMs },
  { value: 'loss_pct', label: 'Потери', fmt: fmtPct },
  { value: 'fwd_loss_pct', label: 'Потери туда', fmt: fmtPct },
  { value: 'bwd_loss_pct', label: 'Потери обратно', fmt: fmtPct },
  { value: 'fwd_delay_avg', label: 'Задержка туда', fmt: fmtMs },
  { value: 'bwd_delay_avg', label: 'Задержка обратно', fmt: fmtMs },
  { value: 'fwd_jitter', label: 'Джиттер туда', fmt: fmtMs },
  { value: 'bwd_jitter', label: 'Джиттер обратно', fmt: fmtMs },
  { value: 'mos', label: 'MOS', fmt: (v) => (v == null ? '—' : v.toFixed(2)) },
];
const metricFmt = (m: string) => METRICS.find((x) => x.value === m)?.fmt ?? ((v: number | null | undefined) => String(v ?? '—'));

const KIND_LABEL: Record<WidgetKind, string> = {
  timeseries: 'График во времени', stat: 'Плитки значений', topN: 'Топ каналов', load: 'Загрузка интерфейсов', alerts: 'Алерты',
};

function rangeQuery(r: RangeKey) {
  const to = new Date();
  const from = new Date(to.getTime() - ranges[r]);
  return `from=${encodeURIComponent(from.toISOString())}&to=${encodeURIComponent(to.toISOString())}`;
}

export function DashboardsPage() {
  const dashboards = useDashboards();
  const [selected, setSelected] = useState<number | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const qc = useQueryClient();

  const active = selected ?? dashboards.data?.[0]?.id ?? null;

  const create = useMutation({
    mutationFn: (name: string) => api.post<{ id: number }>('/v1/admin/dashboards', { name }),
    onSuccess: (r) => { setSelected(r.id); qc.invalidateQueries({ queryKey: ['dashboards'] }); setCreateOpen(false); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  return (
    <>
      <div className="page-head">
        <div>
          <Title order={1}>Дашборды</Title>
          <p>Свои панели: выбирайте агенты, интерфейсы и метрики на каждый виджет, комбинируйте графики, плитки и топы. Дашборд можно сделать общим (только чтение) для других пользователей.</p>
        </div>
        <Group>
          <Select placeholder="Выберите дашборд" data={(dashboards.data ?? []).map((d) => ({ value: String(d.id), label: d.name + (d.own ? '' : ' (общий)') }))}
            value={active ? String(active) : null} onChange={(v) => setSelected(v ? Number(v) : null)} w={240} />
          <Button leftSection={<IconPlus size={16} />} onClick={() => setCreateOpen(true)}>Новый</Button>
        </Group>
      </div>

      {dashboards.isLoading ? <Loader /> : active === null ? (
        <div className="panel"><Text c="dimmed">Дашбордов пока нет. Создайте первый.</Text></div>
      ) : (
        <DashboardView key={active} id={active} onDeleted={() => { setSelected(null); qc.invalidateQueries({ queryKey: ['dashboards'] }); }} />
      )}

      {createOpen && <CreateDashboardModal onClose={() => setCreateOpen(false)} onCreate={(n) => create.mutate(n)} loading={create.isPending} />}
    </>
  );
}

function CreateDashboardModal({ onClose, onCreate, loading }: { onClose: () => void; onCreate: (n: string) => void; loading: boolean }) {
  const [name, setName] = useState('');
  return (
    <Modal opened onClose={onClose} title="Новый дашборд">
      <Stack>
        <TextInput label="Название" value={name} onChange={(e) => setName(e.currentTarget.value)} autoFocus />
        <Group justify="flex-end"><Button variant="default" onClick={onClose}>Отмена</Button>
          <Button loading={loading} disabled={!name.trim()} onClick={() => onCreate(name.trim())}>Создать</Button></Group>
      </Stack>
    </Modal>
  );
}

const VIS_LABEL: Record<DashVisibility, { label: string; color: string }> = {
  private: { label: 'личный', color: 'gray' },
  users: { label: 'по пользователям', color: 'grape' },
  shared: { label: 'общий', color: 'teal' },
};
function VisibilityBadge({ v }: { v: DashVisibility }) {
  const m = VIS_LABEL[v] ?? VIS_LABEL.private;
  return <Badge variant="light" color={m.color}>{m.label}</Badge>;
}

// AccessModal — управление доступом к дашборду: личный / по пользователям / общий.
function AccessModal({ id, current, shares, onClose }: {
  id: number; current: DashVisibility; shares: number[]; onClose: () => void;
}) {
  const qc = useQueryClient();
  const users = useUserNames();
  const [vis, setVis] = useState<DashVisibility>(current);
  const [sel, setSel] = useState<string[]>(shares.map(String));

  const save = useMutation({
    mutationFn: () => api.patch(`/v1/admin/dashboards/${id}`, {
      visibility: vis,
      shares: vis === 'users' ? sel.map(Number) : [],
    }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['dashboard', id] });
      qc.invalidateQueries({ queryKey: ['dashboards'] });
      notifications.show({ message: 'Доступ обновлён', color: 'teal' });
      onClose();
    },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });

  return (
    <Modal opened onClose={onClose} title="Доступ к дашборду" size="md">
      <Stack>
        <Select
          label="Кто видит дашборд"
          data={[
            { value: 'private', label: 'Личный — только я' },
            { value: 'users', label: 'Выбранные пользователи' },
            { value: 'shared', label: 'Общий — все пользователи (чтение)' },
          ]}
          value={vis}
          onChange={(v) => setVis((v as DashVisibility) ?? 'private')}
          allowDeselect={false}
        />
        {vis === 'users' && (
          <MultiSelect
            label="Пользователи с доступом (только чтение)"
            placeholder="выберите пользователей"
            searchable
            data={(users.data ?? []).map((u) => ({ value: String(u.id), label: `${u.login} (${u.role})` }))}
            value={sel}
            onChange={setSel}
          />
        )}
        <Text size="xs" c="dimmed">
          Данные виджетов у каждого зрителя фильтруются его областью видимости (RLS): пользователь увидит
          на дашборде только доступные ему каналы, даже если виджет настроен на другие.
        </Text>
        <Group justify="flex-end">
          <Button variant="default" onClick={onClose}>Отмена</Button>
          <Button loading={save.isPending} onClick={() => save.mutate()}>Сохранить</Button>
        </Group>
      </Stack>
    </Modal>
  );
}

function DashboardView({ id, onDeleted }: { id: number; onDeleted: () => void }) {
  const dash = useDashboard(id);
  const qc = useQueryClient();
  const [edit, setEdit] = useState(false);
  const [draft, setDraft] = useState<DashWidget[] | null>(null);
  const [widgetModal, setWidgetModal] = useState<{ index: number; widget: DashWidget } | null>(null);

  const widgets = draft ?? dash.data?.widgets ?? [];

  const save = useMutation({
    mutationFn: (ws: DashWidget[]) => api.put(`/v1/admin/dashboards/${id}/widgets`, { widgets: ws }),
    onSuccess: () => { notifications.show({ message: 'Дашборд сохранён', color: 'teal' }); qc.invalidateQueries({ queryKey: ['dashboard', id] }); setDraft(null); setEdit(false); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });
  const del = useMutation({
    mutationFn: () => api.del(`/v1/admin/dashboards/${id}`),
    onSuccess: () => { notifications.show({ message: 'Дашборд удалён', color: 'teal' }); onDeleted(); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });
  const [accessOpen, setAccessOpen] = useState(false);

  if (dash.isLoading) return <Loader />;
  if (!dash.data) return <Text c="dimmed">Дашборд недоступен.</Text>;
  const own = dash.data.own;

  const startEdit = () => { setDraft((dash.data!.widgets ?? []).map((w) => ({ ...w }))); setEdit(true); };
  const addWidget = (w: DashWidget) => setDraft((d) => [...(d ?? []), w]);
  const updateWidget = (i: number, w: DashWidget) => setDraft((d) => (d ?? []).map((x, j) => (j === i ? w : x)));
  const removeWidget = (i: number) => setDraft((d) => (d ?? []).filter((_, j) => j !== i));
  const move = (i: number, dir: -1 | 1) => setDraft((d) => {
    const arr = [...(d ?? [])];
    const j = i + dir;
    if (j < 0 || j >= arr.length) return arr;
    [arr[i], arr[j]] = [arr[j], arr[i]];
    return arr;
  });

  return (
    <>
      <Group justify="space-between" mb="md">
        <Group>
          <Title order={2}>{dash.data.name}</Title>
          <VisibilityBadge v={dash.data.visibility} />
          {!own && <Badge variant="outline" color="gray">только чтение</Badge>}
        </Group>
        {own && (
          <Group className="no-print">
            {edit ? (
              <>
                <Menu position="bottom-end" withinPortal>
                  <Menu.Target><Button variant="light" leftSection={<IconPlus size={16} />}>Добавить виджет</Button></Menu.Target>
                  <Menu.Dropdown>
                    {(Object.keys(KIND_LABEL) as WidgetKind[]).map((k) => (
                      <Menu.Item key={k} onClick={() => setWidgetModal({ index: -1, widget: defaultWidget(k) })}>{KIND_LABEL[k]}</Menu.Item>
                    ))}
                  </Menu.Dropdown>
                </Menu>
                <Button variant="default" onClick={() => { setDraft(null); setEdit(false); }}>Отмена</Button>
                <Button leftSection={<IconDeviceFloppy size={16} />} loading={save.isPending} onClick={() => save.mutate(widgets)}>Сохранить</Button>
              </>
            ) : (
              <>
                <Button variant="subtle" leftSection={<IconLock size={16} />} onClick={() => setAccessOpen(true)}>Доступ</Button>
                <Button variant="light" leftSection={<IconPencil size={16} />} onClick={startEdit}>Редактировать</Button>
                <Button variant="default" onClick={() => window.print()}>Экспорт PDF</Button>
                <ActionIcon variant="subtle" color="red" onClick={() => { if (confirm('Удалить дашборд?')) del.mutate(); }}><IconTrash size={18} /></ActionIcon>
              </>
            )}
          </Group>
        )}
      </Group>

      {own && accessOpen && (
        <AccessModal id={id} current={dash.data.visibility} shares={dash.data.shares}
          onClose={() => setAccessOpen(false)} />
      )}

      {widgets.length === 0 ? (
        <div className="panel">
          <Text c="dimmed" mb={own ? 'sm' : 0}>На дашборде пока нет виджетов.</Text>
          {own && !edit && (
            <Button leftSection={<IconPencil size={16} />} onClick={startEdit}>Добавить виджеты</Button>
          )}
          {own && edit && (
            <Menu position="bottom-start" withinPortal>
              <Menu.Target><Button leftSection={<IconPlus size={16} />}>Добавить виджет</Button></Menu.Target>
              <Menu.Dropdown>
                {(Object.keys(KIND_LABEL) as WidgetKind[]).map((k) => (
                  <Menu.Item key={k} onClick={() => setWidgetModal({ index: -1, widget: defaultWidget(k) })}>{KIND_LABEL[k]}</Menu.Item>
                ))}
              </Menu.Dropdown>
            </Menu>
          )}
        </div>
      ) : (
        <div className="dash-grid">
          {widgets.map((w, i) => (
            <div key={i} className={`widget w${widgetSpan(w)}`}>
              <div className="widget-head">
                <h3>{w.title || KIND_LABEL[w.kind]}</h3>
                {edit && (
                  <Group gap={2}>
                    <ActionIcon size="sm" variant="subtle" onClick={() => move(i, -1)}><IconArrowUp size={14} /></ActionIcon>
                    <ActionIcon size="sm" variant="subtle" onClick={() => move(i, 1)}><IconArrowDown size={14} /></ActionIcon>
                    <ActionIcon size="sm" variant="subtle" onClick={() => setWidgetModal({ index: i, widget: w })}><IconPencil size={14} /></ActionIcon>
                    <ActionIcon size="sm" variant="subtle" color="red" onClick={() => removeWidget(i)}><IconX size={14} /></ActionIcon>
                  </Group>
                )}
              </div>
              <WidgetView widget={w} />
            </div>
          ))}
        </div>
      )}

      {widgetModal && (
        <WidgetEditor init={widgetModal.widget}
          onClose={() => setWidgetModal(null)}
          onSave={(w) => {
            if (widgetModal.index === -1) addWidget(w); else updateWidget(widgetModal.index, w);
            setWidgetModal(null);
          }} />
      )}
    </>
  );
}

function defaultWidget(kind: WidgetKind): DashWidget {
  const wide = kind === 'timeseries' || kind === 'load' || kind === 'alerts';
  return {
    kind, title: '',
    config: {
      range: '6h', metric: 'rtt_avg', chart: 'line', topN: 10, channel_ids: [], monitor_ids: [],
      w: wide ? 2 : 1, h: 260, refresh_sec: 60,
    },
  };
}

// widgetSpan — ширина виджета в колонках (1..4), с дефолтом по типу.
function widgetSpan(w: DashWidget): number {
  if (w.config.w && w.config.w >= 1 && w.config.w <= 4) return w.config.w;
  return w.kind === 'timeseries' || w.kind === 'load' || w.kind === 'alerts' ? 2 : 1;
}

// widgetHeight — высота содержимого виджета (px) с дефолтом 260.
function widgetHeight(cfg: WidgetConfig): number {
  return cfg.h && cfg.h >= 120 && cfg.h <= 900 ? cfg.h : 260;
}

// widgetRefresh — период автообновления (мс) с дефолтом 60 с.
function widgetRefresh(cfg: WidgetConfig): number {
  const s = cfg.refresh_sec && cfg.refresh_sec >= 5 ? cfg.refresh_sec : 60;
  return s * 1000;
}

// ---------- Рендер виджета ----------

function WidgetView({ widget }: { widget: DashWidget }) {
  switch (widget.kind) {
    case 'timeseries': return <TimeseriesWidget cfg={widget.config} />;
    case 'stat': return <StatWidget cfg={widget.config} />;
    case 'topN': return <TopNWidget cfg={widget.config} />;
    case 'load': return <LoadWidget cfg={widget.config} />;
    case 'alerts': return <AlertsWidget cfg={widget.config} />;
    default: return <Text c="dimmed">Неизвестный виджет</Text>;
  }
}

function TimeseriesWidget({ cfg }: { cfg: WidgetConfig }) {
  const ids = cfg.channel_ids ?? [];
  const range = cfg.range ?? '6h';
  const metric = cfg.metric ?? 'rtt_avg';
  const channels = useChannels();
  const label = new Map((channels.data ?? []).map((c) => [c.id, c.label]));
  const q = useQueries({
    queries: ids.map((id) => ({
      queryKey: ['w-series', id, range],
      queryFn: () => api.get<{ points: SeriesPoint[] | null }>(`/v1/admin/channels/${id}/series?${rangeQuery(range)}`),
      refetchInterval: widgetRefresh(cfg),
    })),
  });
  if (ids.length === 0) return <Empty>Выберите каналы в настройках виджета</Empty>;
  if (q.some((x) => x.isLoading)) return <Loader size="sm" />;
  const fmt = metricFmt(metric);
  const series = ids.map((id, i) => ({
    name: label.get(id) ?? `#${id}`, type: cfg.chart === 'bar' ? 'bar' : 'line',
    showSymbol: false, smooth: false, sampling: 'lttb',
    areaStyle: cfg.chart === 'area' ? { opacity: 0.1 } : undefined,
    data: (q[i].data?.points ?? []).map((p) => [p.ts, (p as unknown as Record<string, number | null>)[metric]]),
  }));
  const option = {
    animation: false, grid: { left: 56, right: 12, top: 24, bottom: 28 },
    legend: { top: 0, textStyle: { color: tokens.muted, fontSize: 11 } },
    tooltip: { trigger: 'axis', valueFormatter: (v: number | null) => fmt(v) },
    xAxis: { type: 'time', axisLabel: { color: tokens.muted } },
    yAxis: { type: 'value', axisLabel: { color: tokens.muted, formatter: (v: number) => fmt(v) }, splitLine: { lineStyle: { color: '#E7ECEF' } } },
    dataZoom: [{ type: 'inside' }],
    series,
  };
  return <ReactECharts option={option} style={{ height: widgetHeight(cfg) }} notMerge />;
}

function StatWidget({ cfg }: { cfg: WidgetConfig }) {
  const ov = useOverview();
  const metric = cfg.metric ?? 'rtt_avg';
  const fmt = metricFmt(metric);
  const ids = new Set(cfg.channel_ids ?? []);
  const rows = (ov.data?.latest ?? []).filter((r) => ids.size === 0 || ids.has(r.channel_id));
  if (rows.length === 0) return <Empty>Нет данных за последние 10 минут</Empty>;
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: 10 }}>
      {rows.map((r) => (
        <div key={r.channel_id} style={{ border: '1px solid var(--line)', borderRadius: 6, padding: '8px 10px' }}>
          <Text size="xs" c="dimmed" lineClamp={1}>{r.channel}</Text>
          <Text fw={600} size="lg">{fmt((r as unknown as Record<string, number | null>)[metric])}</Text>
        </div>
      ))}
    </div>
  );
}

function TopNWidget({ cfg }: { cfg: WidgetConfig }) {
  const ov = useOverview();
  const metric = cfg.metric ?? 'loss_pct';
  const fmt = metricFmt(metric);
  const n = cfg.topN ?? 10;
  const ids = new Set(cfg.channel_ids ?? []);
  const rows = [...(ov.data?.latest ?? [])]
    .filter((r) => ids.size === 0 || ids.has(r.channel_id))
    .map((r) => ({ r, v: (r as unknown as Record<string, number | null>)[metric] }))
    .filter((x) => x.v != null)
    .sort((a, b) => (b.v as number) - (a.v as number))
    .slice(0, n);
  if (rows.length === 0) return <Empty>Нет данных</Empty>;
  return (
    <Table>
      <Table.Tbody>
        {rows.map(({ r, v }) => (
          <Table.Tr key={r.channel_id}>
            <Table.Td>{r.channel}<Text span size="xs" c="dimmed"> · {r.dscp_name}</Text></Table.Td>
            <Table.Td ta="right" fw={600}>{fmt(v)}</Table.Td>
          </Table.Tr>
        ))}
      </Table.Tbody>
    </Table>
  );
}

function LoadWidget({ cfg }: { cfg: WidgetConfig }) {
  const ids = cfg.monitor_ids ?? [];
  const range = cfg.range ?? '6h';
  const mons = useIfaceMonitors();
  const label = new Map((mons.data ?? []).map((m) => [m.id, `${m.agent}/${m.interface}`]));
  const q = useQueries({
    queries: ids.map((id) => ({
      queryKey: ['w-load', id, range],
      queryFn: () => api.get<{ points: LoadPoint[] | null }>(`/v1/admin/iface-monitors/${id}/series?${rangeQuery(range)}`),
      refetchInterval: widgetRefresh(cfg),
    })),
  });
  if (ids.length === 0) return <Empty>Выберите интерфейсы в настройках виджета</Empty>;
  if (q.some((x) => x.isLoading)) return <Loader size="sm" />;
  const series = ids.flatMap((id, i) => ([
    { name: `${label.get(id) ?? id} rx`, type: 'line', showSymbol: false, sampling: 'lttb',
      data: (q[i].data?.points ?? []).map((p) => [p.ts, p.rx_bps]) },
    { name: `${label.get(id) ?? id} tx`, type: 'line', showSymbol: false, sampling: 'lttb',
      data: (q[i].data?.points ?? []).map((p) => [p.ts, p.tx_bps]) },
  ]));
  const option = {
    animation: false, grid: { left: 64, right: 12, top: 24, bottom: 28 },
    legend: { top: 0, textStyle: { color: tokens.muted, fontSize: 11 } },
    tooltip: { trigger: 'axis', valueFormatter: (v: number | null) => fmtBps(v) },
    xAxis: { type: 'time', axisLabel: { color: tokens.muted } },
    yAxis: { type: 'value', axisLabel: { color: tokens.muted, formatter: (v: number) => fmtBps(v) }, splitLine: { lineStyle: { color: '#E7ECEF' } } },
    dataZoom: [{ type: 'inside' }],
    series,
  };
  return <ReactECharts option={option} style={{ height: widgetHeight(cfg) }} notMerge />;
}

function AlertsWidget({ cfg }: { cfg: WidgetConfig }) {
  const q = useQuery({ queryKey: ['w-alerts'], queryFn: () => api.get<import('../api').Alert[]>('/v1/admin/alerts?state=open'), refetchInterval: widgetRefresh(cfg) });
  const ids = new Set(cfg.channel_ids ?? []);
  const list = (q.data ?? []).filter((a) => ids.size === 0 || (a.channel_id != null && ids.has(a.channel_id)));
  if (list.length === 0) return <Empty>Открытых алертов нет</Empty>;
  return (
    <Table>
      <Table.Tbody>
        {list.map((a) => (
          <Table.Tr key={a.id}>
            <Table.Td w={90}><Badge size="sm" color={a.severity === 'critical' ? 'red' : 'yellow'} variant="light">{a.severity === 'critical' ? 'крит' : 'вним'}</Badge></Table.Td>
            <Table.Td>{a.channel ?? a.agent}</Table.Td>
            <Table.Td c="dimmed">{a.kind}</Table.Td>
          </Table.Tr>
        ))}
      </Table.Tbody>
    </Table>
  );
}

function Empty({ children }: { children: ReactNode }) {
  return <div style={{ height: 120, display: 'grid', placeItems: 'center' }}><Text c="dimmed" size="sm">{children}</Text></div>;
}

// ---------- Редактор виджета ----------

function WidgetEditor({ init, onClose, onSave }: { init: DashWidget; onClose: () => void; onSave: (w: DashWidget) => void }) {
  const [w, setW] = useState<DashWidget>(init);
  const channels = useChannels();
  const monitors = useIfaceMonitors();
  const cfg = w.config;
  const setCfg = (patch: Partial<WidgetConfig>) => setW({ ...w, config: { ...cfg, ...patch } });

  const needsChannels = w.kind !== 'load';
  const needsMonitors = w.kind === 'load';
  const needsMetric = w.kind === 'timeseries' || w.kind === 'stat' || w.kind === 'topN';
  const needsRange = w.kind === 'timeseries' || w.kind === 'load';

  return (
    <Modal opened onClose={onClose} title={`Виджет: ${KIND_LABEL[w.kind]}`} size="lg">
      <Stack>
        <TextInput label="Заголовок" placeholder={KIND_LABEL[w.kind]} value={w.title} onChange={(e) => setW({ ...w, title: e.currentTarget.value })} />
        {needsChannels && (
          <MultiSelect label="Каналы" placeholder="выберите каналы (пусто — все доступные)" searchable
            data={(channels.data ?? []).map((c) => ({ value: String(c.id), label: `${c.label} · ${c.dscp_name}` }))}
            value={(cfg.channel_ids ?? []).map(String)} onChange={(v) => setCfg({ channel_ids: v.map(Number) })} />
        )}
        {needsMonitors && (
          <MultiSelect label="Интерфейсы" placeholder="выберите интерфейсы" searchable
            data={(monitors.data ?? []).map((m) => ({ value: String(m.id), label: `${m.agent}/${m.interface}` }))}
            value={(cfg.monitor_ids ?? []).map(String)} onChange={(v) => setCfg({ monitor_ids: v.map(Number) })} />
        )}
        <Group grow>
          {needsMetric && (
            <Select label="Метрика" data={METRICS.map((m) => ({ value: m.value, label: m.label }))}
              value={cfg.metric ?? 'rtt_avg'} onChange={(v) => setCfg({ metric: v ?? 'rtt_avg' })} />
          )}
          {w.kind === 'timeseries' && (
            <Select label="Тип графика" data={[{ value: 'line', label: 'Линия' }, { value: 'area', label: 'Область' }, { value: 'bar', label: 'Столбцы' }]}
              value={cfg.chart ?? 'line'} onChange={(v) => setCfg({ chart: (v as WidgetConfig['chart']) ?? 'line' })} />
          )}
          {w.kind === 'topN' && (
            <NumberInput label="Сколько показывать" min={1} max={50} value={cfg.topN ?? 10} onChange={(v) => setCfg({ topN: Number(v) || 10 })} />
          )}
          {needsRange && (
            <Select label="Период" data={Object.keys(ranges).map((r) => ({ value: r, label: r }))}
              value={cfg.range ?? '6h'} onChange={(v) => setCfg({ range: (v as RangeKey) ?? '6h' })} />
          )}
        </Group>

        <Text size="sm" fw={600} mt="xs">Размер и обновление</Text>
        <Group grow>
          <Select
            label="Ширина"
            data={[
              { value: '1', label: '1 колонка (¼)' },
              { value: '2', label: '2 колонки (½)' },
              { value: '3', label: '3 колонки (¾)' },
              { value: '4', label: '4 колонки (вся ширина)' },
            ]}
            value={String(cfg.w ?? (w.kind === 'stat' || w.kind === 'topN' ? 1 : 2))}
            onChange={(v) => setCfg({ w: Number(v) || 2 })}
            allowDeselect={false}
          />
          <NumberInput label="Высота, px" min={120} max={900} step={20}
            value={cfg.h ?? 260} onChange={(v) => setCfg({ h: Number(v) || 260 })} />
          <NumberInput label="Обновление, с" min={5} max={3600} step={5}
            description="как часто перезапрашивать данные"
            value={cfg.refresh_sec ?? 60} onChange={(v) => setCfg({ refresh_sec: Number(v) || 60 })} />
        </Group>

        <Group justify="flex-end">
          <Button variant="default" onClick={onClose}>Отмена</Button>
          <Button leftSection={<IconChartLine size={16} />} onClick={() => onSave(w)}>Готово</Button>
        </Group>
      </Stack>
    </Modal>
  );
}
