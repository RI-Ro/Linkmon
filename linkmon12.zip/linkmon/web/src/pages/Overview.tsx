import { useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Badge, Loader, Table, Text, Title } from '@mantine/core';
import { useAgents, useChannels, useOverview, type Alert, type Channel, type LatestRow } from '../api';
import { alertKinds, directionStatus, fmtAgo, fmtMs, fmtPct, statusLabel, type Status } from '../format';

const AGENT_DOWN_MS = 180_000;

interface Row { key: string; agent: string; iface: string; reflector: string; byDscp: Map<number, Channel> }

function plural(n: number, one: string, few: string, many: string) {
  const m10 = n % 10, m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return one;
  if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return few;
  return many;
}

export function OverviewPage() {
  const ov = useOverview();
  const channels = useChannels();
  const agents = useAgents();
  const navigate = useNavigate();

  // Множество недоступных агентов: по agent_down-алертам и по last_seen (работает и для off-режима).
  const downAgents = useMemo(() => {
    const down = new Set<string>();
    for (const a of ov.data?.open_alerts ?? []) {
      if (a.kind === 'agent_down' && a.agent_id && !a.ended_at) down.add(a.agent_id);
    }
    const now = Date.now();
    for (const ag of agents.data ?? []) {
      if (ag.status !== 'approved') { down.add(ag.id); continue; }
      if (!ag.last_seen || now - new Date(ag.last_seen).getTime() > AGENT_DOWN_MS) down.add(ag.id);
    }
    return down;
  }, [ov.data, agents.data]);

  const { rows, dscps, latest, alertsByChannel } = useMemo(() => {
    const list = (channels.data ?? []).filter((c) => c.enabled);
    const rowsMap = new Map<string, Row>();
    const dscpSet = new Map<number, string>();
    for (const c of list) {
      const key = `${c.agent}|${c.interface}|${c.reflector}`;
      if (!rowsMap.has(key)) rowsMap.set(key, { key, agent: c.agent, iface: c.interface, reflector: c.reflector, byDscp: new Map() });
      rowsMap.get(key)!.byDscp.set(c.dscp, c);
      dscpSet.set(c.dscp, c.dscp_name);
    }
    const latestMap = new Map<number, LatestRow>((ov.data?.latest ?? []).map((l) => [l.channel_id, l]));
    const alertMap = new Map<number, Alert[]>();
    for (const a of ov.data?.open_alerts ?? []) {
      if (a.channel_id == null) continue;
      alertMap.set(a.channel_id, [...(alertMap.get(a.channel_id) ?? []), a]);
    }
    return {
      rows: [...rowsMap.values()].sort((a, b) => a.key.localeCompare(b.key, 'ru')),
      dscps: [...dscpSet.entries()].sort((a, b) => b[0] - a[0]), // EF и AF4x — слева
      latest: latestMap,
      alertsByChannel: alertMap,
    };
  }, [channels.data, ov.data]);

  if (ov.isLoading || channels.isLoading) return <Loader />;
  const o = ov.data;
  const openAlerts = o?.open_alerts ?? [];

  return (
    <>
      <div className="page-head">
        <div>
          <Title order={1}>Состояние каналов</Title>
          <p>Каждая ячейка — канал в одном классе QoS. Верхняя половина — направление к серверу, нижняя — обратно. Нажмите ячейку, чтобы открыть графики.</p>
        </div>
      </div>

      {o && (
        <div className="summary-line">
          <span><b>{o.agents_online}</b> из {o.agents_total} {plural(o.agents_total, 'агента', 'агентов', 'агентов')} на связи</span>
          <span><b>{o.channels}</b> {plural(o.channels, 'канал', 'канала', 'каналов')} под наблюдением</span>
          <Link to="/alerts"><b>{openAlerts.length}</b> {plural(openAlerts.length, 'открытый алерт', 'открытых алерта', 'открытых алертов')}</Link>
          {o.agents_pending > 0 && <Link to="/agents"><b>{o.agents_pending}</b> ждут одобрения</Link>}
        </div>
      )}

      <div className="panel matrix">
        {rows.length === 0 ? (
          <Text c="dimmed">
            Каналов пока нет. Запустите агент (make run-agent) — после регистрации каналы появятся здесь автоматически.
          </Text>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Агент и интерфейс</th>
                {dscps.map(([d, name]) => <th key={d}>{name}</th>)}
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.key}>
                  <td className="label">
                    {r.agent} / {r.iface}
                    <div className="sub">до {r.reflector}</div>
                  </td>
                  {dscps.map(([d, name]) => {
                    const c = r.byDscp.get(d);
                    if (!c) return <td key={d}><span className="cell empty" aria-hidden /></td>;
                    const l = latest.get(c.id);
                    const al = alertsByChannel.get(c.id) ?? [];
                    // Агент/сервер недоступен — обе половины в аварии (красные).
                    const agentDown = downAgents.has(c.agent_id);
                    const f: Status = agentDown ? 'crit' : directionStatus(l, al, 'fwd');
                    const b: Status = agentDown ? 'crit' : directionStatus(l, al, 'bwd');
                    const text =
                      `${c.label}\nТуда: ${statusLabel[f]}, потери ${fmtPct(l?.fwd_loss_pct)}, задержка ${fmtMs(l?.fwd_delay_avg)}` +
                      `\nОбратно: ${statusLabel[b]}, потери ${fmtPct(l?.bwd_loss_pct)}, задержка ${fmtMs(l?.bwd_delay_avg)}` +
                      `\nRTT ${fmtMs(l?.rtt_avg)}${l ? `, обновлено ${fmtAgo(l.ts)}` : ''}`;
                    return (
                      <td key={d}>
                        <button className="cell" title={text} aria-label={`${name}: ${text}`} onClick={() => navigate(`/channels/${c.id}`)}>
                          <span className={`s-${f}`}>{l?.fwd_loss_pct ? fmtPct(l.fwd_loss_pct) : ''}</span>
                          <span className={`s-${b}`}>{l?.bwd_loss_pct ? fmtPct(l.bwd_loss_pct) : ''}</span>
                        </button>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        )}
        <div className="legend">
          <span><i className="s-ok" />в норме</span>
          <span><i className="s-warn" />деградация: потери или перемаркировка</span>
          <span><i className="s-crit" />нарушение SLA</span>
          <span><i className="s-nodata" />нет свежих данных</span>
        </div>
      </div>

      {openAlerts.length > 0 && (
        <div className="panel">
          <Title order={3} mb="sm">Открытые алерты</Title>
          <Table>
            <Table.Tbody>
              {openAlerts.slice(0, 8).map((a) => (
                <Table.Tr key={a.id} className={a.channel_id ? 'clickable' : undefined}
                  onClick={() => a.channel_id && navigate(`/channels/${a.channel_id}`)}>
                  <Table.Td w={120}><Badge color={a.severity === 'critical' ? 'red' : 'yellow'} variant="light">{a.severity === 'critical' ? 'критично' : 'внимание'}</Badge></Table.Td>
                  <Table.Td>{alertKinds[a.kind] ?? a.kind}</Table.Td>
                  <Table.Td>{a.channel ?? a.agent}</Table.Td>
                  <Table.Td c="dimmed">с {new Date(a.started_at).toLocaleTimeString('ru-RU')}</Table.Td>
                </Table.Tr>
              ))}
            </Table.Tbody>
          </Table>
        </div>
      )}
    </>
  );
}
