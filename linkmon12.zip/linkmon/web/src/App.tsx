import { useEffect, useState } from 'react';
import { NavLink, Navigate, Route, Routes } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { Center, Loader } from '@mantine/core';
import {
  IconLayoutGrid, IconServer2, IconRoute, IconFolders, IconBellRinging, IconGauge,
  IconLogout, IconKey, IconChartDots, IconUsers, IconHistory, IconActivity, IconMap2,
} from '@tabler/icons-react';
import { api, useOverview, loadServers, currentServerId, setCurrentServer, type Me, type ServerRef } from './api';
import { Select } from '@mantine/core';
import { Login } from './pages/Login';
import { OverviewPage } from './pages/Overview';
import { AgentsPage } from './pages/Agents';
import { ChannelsPage } from './pages/Channels';
import { ChannelDetailPage } from './pages/ChannelDetail';
import { GroupsPage } from './pages/Groups';
import { AlertsPage } from './pages/Alerts';
import { SlaPage } from './pages/Sla';
import { DashboardsPage } from './pages/Dashboards';
import { UsersPage } from './pages/Users';
import { ChannelReportPage, GroupReportPage } from './pages/Report';
import { TestsPage } from './pages/Tests';
import { BWTestsPage } from './pages/BWTests';
import { MapsPage } from './pages/Maps';
import { ChangePasswordModal } from './pages/ChangePassword';
import { AlertCenter } from './components/AlertCenter';

const roleLabel: Record<Me['role'], string> = {
  big_admin: 'полный доступ', admin: 'администратор', viewer: 'наблюдатель',
};

export function App() {
  // undefined — ещё проверяем сессию; null — не авторизован; Me — вошли.
  const [me, setMe] = useState<Me | null | undefined>(undefined);
  const [servers, setServers] = useState<ServerRef[]>([]);
  const [booted, setBooted] = useState(false);
  const qc = useQueryClient();

  // Сначала определяем режим (один сервер или мультисервер через linkmon-web), затем сессию.
  useEffect(() => {
    let alive = true;
    (async () => {
      const list = await loadServers();
      if (!alive) return;
      setServers(list);
      setBooted(true);
      api.whoami().then(
        (u) => alive && setMe(u),
        () => alive && setMe(null),
      );
    })();
    const onLogout = () => { setMe(null); qc.clear(); };
    window.addEventListener('linkmon:logout', onLogout);
    return () => { alive = false; window.removeEventListener('linkmon:logout', onLogout); };
  }, [qc]);

  const switchServer = (id: string) => {
    setCurrentServer(id);
    window.location.reload(); // сбрасываем сессию/кэш — у каждого сервера свои данные и вход
  };

  const logout = async () => {
    try { await api.logout(); } catch { /* всё равно выходим локально */ }
    setMe(null);
    qc.clear();
  };

  if (!booted || me === undefined) {
    return <Center h="100vh"><Loader /></Center>;
  }
  if (me === null) {
    return <Login onLogin={(u) => setMe(u)} />;
  }

  return (
    <div className="shell">
      <Rail me={me} onLogout={logout} servers={servers} onSwitchServer={switchServer} />
      <main className="content">
        <Routes>
          <Route path="/" element={<OverviewPage />} />
          <Route path="/dashboards" element={<DashboardsPage />} />
          <Route path="/maps" element={<MapsPage me={me} />} />
          <Route path="/agents" element={<AgentsPage me={me} />} />
          <Route path="/channels" element={<ChannelsPage me={me} />} />
          <Route path="/channels/:id" element={<ChannelDetailPage me={me} />} />
          <Route path="/report/channel/:id" element={<ChannelReportPage />} />
          <Route path="/report/group/:id" element={<GroupReportPage />} />
          <Route path="/groups" element={<GroupsPage me={me} />} />
          <Route path="/tests" element={<TestsPage me={me} />} />
          <Route path="/bwtests" element={<BWTestsPage me={me} />} />
          <Route path="/alerts" element={<AlertsPage />} />
          <Route path="/sla" element={<SlaPage />} />
          {me.role === 'big_admin' && <Route path="/users" element={<UsersPage />} />}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <AlertCenter />
    </div>
  );
}

function Rail({ me, onLogout, servers, onSwitchServer }: {
  me: Me; onLogout: () => void; servers: ServerRef[]; onSwitchServer: (id: string) => void;
}) {
  const { data } = useOverview();
  const alerts = data?.open_alerts?.length ?? 0;
  const pending = data?.agents_pending ?? 0;
  const [pwdOpen, setPwdOpen] = useState(false);
  return (
    <nav className="rail" aria-label="Разделы">
      <div className="brand">
        <span className="brand-mark" aria-hidden><span /><span /></span>
        LinkMon
      </div>
      {servers.length > 0 && (
        <Select
          size="xs" mb="xs" aria-label="Сервер"
          data={servers.map((s) => ({ value: s.id, label: s.name }))}
          value={currentServerId() ?? servers[0].id}
          onChange={(v) => v && onSwitchServer(v)}
          allowDeselect={false}
          comboboxProps={{ withinPortal: true }}
        />
      )}
      <NavLink to="/" end><IconLayoutGrid size={18} />Обзор</NavLink>
      <NavLink to="/dashboards"><IconChartDots size={18} />Дашборды</NavLink>
      <NavLink to="/maps"><IconMap2 size={18} />Карты сети</NavLink>
      <NavLink to="/channels"><IconRoute size={18} />Каналы</NavLink>
      <NavLink to="/groups"><IconFolders size={18} />Группы и тесты</NavLink>
      <NavLink to="/tests"><IconHistory size={18} />История тестов</NavLink>
      <NavLink to="/bwtests"><IconActivity size={18} />Пропускная способность</NavLink>
      <NavLink to="/alerts"><IconBellRinging size={18} />Алерты{alerts > 0 && <span className="count">{alerts}</span>}</NavLink>
      <NavLink to="/agents"><IconServer2 size={18} />Агенты{pending > 0 && <span className="count">{pending}</span>}</NavLink>
      <NavLink to="/sla"><IconGauge size={18} />Профили SLA</NavLink>
      {me.role === 'big_admin' && <NavLink to="/users"><IconUsers size={18} />Пользователи</NavLink>}
      <div className="spacer" />
      <div className="rail-user">{me.login}</div>
      <div className="role">{roleLabel[me.role]}</div>
      <a href="#" onClick={(e) => { e.preventDefault(); setPwdOpen(true); }}><IconKey size={18} />Сменить пароль</a>
      <a href="#" onClick={(e) => { e.preventDefault(); onLogout(); }}><IconLogout size={18} />Выйти</a>
      <ChangePasswordModal opened={pwdOpen} onClose={() => setPwdOpen(false)} />
    </nav>
  );
}
