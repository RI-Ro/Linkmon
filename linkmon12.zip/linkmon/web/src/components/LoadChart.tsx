import ReactECharts from 'echarts-for-react';
import type { LoadPoint } from '../api';
import { tokens } from '../theme';
import { fmtBps } from '../format';
import { MetricInfo } from './MetricInfo';
import { gapMarkArea } from './SymmetricChart';

// Загрузка интерфейса: приём (rx) над осью, отдача (tx) под ней. Если известен номинал
// канала, рисуем его пунктиром сверху и снизу — сразу видно приближение к потолку.
export function LoadChart({ points, speedBits, height = 240, xMin, xMax, gaps }: { points: LoadPoint[]; speedBits?: number | null; height?: number; xMin?: number; xMax?: number; gaps?: [number, number][] }) {
  const empty = points.length === 0;
  const cap = speedBits && speedBits > 0 ? speedBits : null;

  const markLine = cap
    ? {
        silent: true, symbol: 'none',
        label: { formatter: 'номинал', color: tokens.muted, fontSize: 10 },
        lineStyle: { color: tokens.muted, type: 'dashed', width: 1 },
        data: [{ yAxis: cap }, { yAxis: -cap }],
      }
    : undefined;

  const option = {
    animation: false,
    legend: { data: ['Приём (rx)', 'Отдача (tx)'], top: 0, right: 8, textStyle: { color: tokens.muted }, icon: 'roundRect' },
    grid: { left: 72, right: 16, top: 34, bottom: 54 },
    xAxis: { type: 'time', min: xMin, max: xMax, axisLabel: { color: tokens.muted }, axisLine: { lineStyle: { color: tokens.line } } },
    yAxis: {
      type: 'value', splitNumber: 4,
      axisLabel: { color: tokens.muted, formatter: (v: number) => fmtBps(Math.abs(v)) },
      splitLine: { lineStyle: { color: '#E7ECEF' } },
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'cross', label: { backgroundColor: tokens.ink } },
      valueFormatter: (v: number | null) => (v == null ? '—' : fmtBps(Math.abs(v))),
    },
    toolbox: {
      right: 8, top: 26, itemSize: 13, feature: {
        dataZoom: { yAxisIndex: 'none', title: { zoom: 'Зум', back: 'Сброс' } },
        restore: { title: 'Сброс' },
        saveAsImage: { title: 'PNG', pixelRatio: 2 },
      },
      iconStyle: { borderColor: tokens.muted },
    },
    dataZoom: [
      { type: 'inside', throttle: 50 },
      { type: 'slider', height: 16, bottom: 24, borderColor: tokens.line, textStyle: { color: tokens.muted } },
    ],
    series: [
      {
        name: 'Приём (rx)', type: 'line', color: tokens.fwd, showSymbol: false, sampling: 'lttb',
        lineStyle: { width: 1.5 }, areaStyle: { opacity: 0.16 }, emphasis: { focus: 'series' },
        data: points.map((p) => [p.ts, p.rx_bps]),
        markLine,
        markArea: gapMarkArea(gaps),
      },
      {
        name: 'Отдача (tx)', type: 'line', color: tokens.bwd, showSymbol: false, sampling: 'lttb',
        lineStyle: { width: 1.5 }, areaStyle: { opacity: 0.16 }, emphasis: { focus: 'series' },
        data: points.map((p) => [p.ts, p.tx_bps == null ? null : -p.tx_bps]),
      },
    ],
  };

  return (
    <div className="panel">
      <div className="chart-title">
        <h3>Загрузка интерфейса<MetricInfo metric="load" /></h3>
        <span className="chart-keys"><span className="dir-fwd">приём</span><span className="dir-bwd">отдача</span></span>
      </div>
      {empty
        ? <div className="muted" style={{ height, display: 'grid', placeItems: 'center' }}>За выбранный период данных нет</div>
        : <ReactECharts option={option} style={{ height }} notMerge />}
    </div>
  );
}
