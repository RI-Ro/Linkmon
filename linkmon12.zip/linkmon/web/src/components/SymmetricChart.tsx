import ReactECharts from 'echarts-for-react';
import { tokens } from '../theme';
import { MetricInfo } from './MetricInfo';

interface Props {
  title: string;
  ts: string[];
  fwd: (number | null)[];
  bwd: (number | null)[];
  fmt: (v: number) => string;
  kind?: 'line' | 'bar';
  note?: string;
  info?: string;
  height?: number;
  xMin?: number;
  xMax?: number;
  gaps?: [number, number][];
}

// markArea красных зон-пропусков (данные агента отсутствовали за эти минуты).
export function gapMarkArea(gaps?: [number, number][]) {
  if (!gaps || gaps.length === 0) return undefined;
  return {
    silent: true,
    itemStyle: { color: 'rgba(214, 69, 69, 0.16)' },
    data: gaps.map(([a, b]) => [{ xAxis: a }, { xAxis: b }]),
  };
}

// Симметричный график: «туда» над осью, «обратно» под ней, шкала всегда центрирована на нуле,
// чтобы асимметрию канала было видно сразу, без чтения подписей.
export function SymmetricChart({ title, ts, fwd, bwd, fmt, kind = 'line', note, info, height = 240, xMin, xMax, gaps }: Props) {
  const peak = Math.max(1e-9, ...fwd.map((v) => Math.abs(v ?? 0)), ...bwd.map((v) => Math.abs(v ?? 0))) * 1.12;
  const empty = fwd.every((v) => v == null) && bwd.every((v) => v == null);

  const common = { type: kind, showSymbol: false, sampling: 'lttb', barMaxWidth: 6, lineStyle: { width: 1.5 }, emphasis: { focus: 'series' } };
  const option = {
    animation: false,
    legend: { data: ['Туда', 'Обратно'], top: 0, right: 8, textStyle: { color: tokens.muted }, icon: 'roundRect' },
    grid: { left: 64, right: 16, top: 34, bottom: 54 },
    xAxis: { type: 'time', min: xMin, max: xMax, axisLine: { lineStyle: { color: tokens.line } }, axisLabel: { color: tokens.muted } },
    yAxis: {
      type: 'value', min: -peak, max: peak, splitNumber: 4,
      axisLabel: { color: tokens.muted, formatter: (v: number) => fmt(Math.abs(v)) },
      splitLine: { lineStyle: { color: '#E7ECEF' } },
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'cross', label: { backgroundColor: tokens.ink } },
      valueFormatter: (v: number | null) => (v == null ? '—' : fmt(Math.abs(v))),
    },
    toolbox: {
      right: 8, top: 26, itemSize: 13, feature: {
        dataZoom: { yAxisIndex: 'none', title: { zoom: 'Зум', back: 'Сброс' } },
        restore: { title: 'Сброс' },
        saveAsImage: { title: 'PNG', pixelRatio: 2 },
      },
      iconStyle: { borderColor: tokens.muted },
    },
    dataZoom: [
      { type: 'inside', throttle: 50 },
      { type: 'slider', height: 16, bottom: 24, borderColor: tokens.line, textStyle: { color: tokens.muted } },
    ],
    series: [
      {
        ...common, name: 'Туда', color: tokens.fwd,
        areaStyle: kind === 'line' ? { opacity: 0.16 } : undefined,
        data: ts.map((t, i) => [t, fwd[i]]),
        markLine: {
          silent: true, symbol: 'none', label: { show: false },
          lineStyle: { color: tokens.ink, width: 1, type: 'solid' }, data: [{ yAxis: 0 }],
        },
        markArea: gapMarkArea(gaps),
      },
      {
        ...common, name: 'Обратно', color: tokens.bwd,
        areaStyle: kind === 'line' ? { opacity: 0.16 } : undefined,
        data: ts.map((t, i) => [t, bwd[i] == null ? null : -(bwd[i] as number)]),
      },
    ],
  };

  return (
    <div className="panel">
      <div className="chart-title">
        <h3>{title}{info && <MetricInfo metric={info} />}</h3>
        <span className="chart-keys"><span className="dir-fwd">туда, агент → сервер</span><span className="dir-bwd">обратно, сервер → агент</span></span>
      </div>
      {note && <div className="muted" style={{ fontSize: '0.82rem' }}>{note}</div>}
      {empty
        ? <div className="muted" style={{ height, display: 'grid', placeItems: 'center' }}>За выбранный период данных нет</div>
        : <ReactECharts option={option} style={{ height }} notMerge />}
    </div>
  );
}
