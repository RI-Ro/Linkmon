import ReactECharts from 'echarts-for-react';
import type { SmokePoint } from '../api';
import { tokens } from '../theme';
import { fmtMs } from '../format';
import { MetricInfo } from './MetricInfo';

// Индексы в массиве из 20 квантилей (5%, 10% … 100%).
const bands: [number, number, number][] = [
  [0, 18, 0.12], // 5–95%
  [1, 17, 0.2],  // 10–90%
  [4, 14, 0.32], // 25–75%
];
const MEDIAN = 9;

function lossColor(loss: number | null) {
  if (loss == null || loss === 0) return tokens.ok;
  if (loss < 1) return tokens.warn;
  return tokens.crit;
}

// Smoke-график в духе SmokePing: «дым» — распределение RTT внутри интервала, точка — медиана,
// цвет точки — потери за интервал.
export function SmokeChart({ points, height = 260, xMin, xMax }: { points: SmokePoint[]; height?: number; xMin?: number; xMax?: number }) {
  const series: object[] = [];
  bands.forEach(([lo, hi, op], i) => {
    series.push({
      type: 'line', stack: `b${i}`, symbol: 'none', lineStyle: { opacity: 0 }, silent: true,
      data: points.map((p) => [p.ts, p.rtt_q ? p.rtt_q[lo] : null]),
    });
    series.push({
      type: 'line', stack: `b${i}`, symbol: 'none', lineStyle: { opacity: 0 }, silent: true,
      areaStyle: { color: tokens.muted, opacity: op },
      data: points.map((p) => [p.ts, p.rtt_q ? p.rtt_q[hi] - p.rtt_q[lo] : null]),
    });
  });
  series.push({
    name: 'Медиана', type: 'scatter', symbolSize: 4,
    data: points.map((p) => ({
      value: [p.ts, p.rtt_q ? p.rtt_q[MEDIAN] : null],
      itemStyle: { color: lossColor(p.loss_pct) },
      loss: p.loss_pct,
    })),
  });

  const option = {
    animation: false,
    grid: { left: 64, right: 16, top: 16, bottom: 54 },
    xAxis: { type: 'time', min: xMin, max: xMax, axisLabel: { color: tokens.muted }, axisLine: { lineStyle: { color: tokens.line } } },
    yAxis: { type: 'value', min: 0, axisLabel: { color: tokens.muted, formatter: (v: number) => fmtMs(v) }, splitLine: { lineStyle: { color: '#E7ECEF' } } },
    tooltip: {
      trigger: 'item',
      axisPointer: { type: 'cross', label: { backgroundColor: tokens.ink } },
      formatter: (p: { value: [string, number | null]; data: { loss: number | null } }) =>
        `${new Date(p.value[0]).toLocaleString('ru-RU')}<br/>Медиана RTT ${fmtMs(p.value[1])}<br/>Потери ${p.data.loss ?? 0}%`,
    },
    toolbox: {
      right: 8, top: 4, itemSize: 13, feature: {
        dataZoom: { yAxisIndex: 'none', title: { zoom: 'Зум', back: 'Сброс' } },
        restore: { title: 'Сброс' },
        saveAsImage: { title: 'PNG', pixelRatio: 2 },
      },
      iconStyle: { borderColor: tokens.muted },
    },
    dataZoom: [
      { type: 'inside', throttle: 50 },
      { type: 'slider', height: 16, bottom: 24, borderColor: tokens.line, textStyle: { color: tokens.muted } },
    ],
    series,
  };

  return (
    <div className="panel">
      <div className="chart-title">
        <h3>Распределение RTT<MetricInfo metric="smoke" /></h3>
        <span className="chart-keys muted">тень — 5…95% замеров, точка — медиана, цвет точки — потери</span>
      </div>
      {points.length === 0
        ? <div className="muted" style={{ height, display: 'grid', placeItems: 'center' }}>За выбранный период данных нет</div>
        : <ReactECharts option={option} style={{ height }} notMerge />}
    </div>
  );
}
