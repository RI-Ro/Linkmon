import { useState, useCallback } from 'react';
import { SegmentedControl } from '@mantine/core';
import type { RangeKey } from '../api';

const data: { value: RangeKey; label: string }[] = [
  { value: '30m', label: '30 мин' }, { value: '1h', label: '1 ч' }, { value: '3h', label: '3 ч' },
  { value: '6h', label: '6 ч' }, { value: '24h', label: '24 ч' }, { value: '7d', label: '7 дн' },
];

const KEYS = new Set(data.map((d) => d.value));

// useStickyRange — выбранная шкала времени, сохраняемая в localStorage независимо от
// перезагрузки страницы. storageKey позволяет держать отдельный выбор для разных экранов.
export function useStickyRange(storageKey: string, def: RangeKey = '6h'): [RangeKey, (v: RangeKey) => void] {
  const [range, setRange] = useState<RangeKey>(() => {
    try {
      const v = localStorage.getItem(storageKey);
      if (v && KEYS.has(v as RangeKey)) return v as RangeKey;
    } catch { /* приватный режим */ }
    return def;
  });
  const set = useCallback((v: RangeKey) => {
    setRange(v);
    try { localStorage.setItem(storageKey, v); } catch { /* приватный режим */ }
  }, [storageKey]);
  return [range, set];
}

export function RangePicker({ value, onChange }: { value: RangeKey; onChange: (v: RangeKey) => void }) {
  return <SegmentedControl size="xs" data={data} value={value} onChange={(v) => onChange(v as RangeKey)} />;
}
