import { ActionIcon, Badge, Group, Loader, Progress, Table, Text } from '@mantine/core';
import { IconX } from '@tabler/icons-react';
import { useTestRun } from '../api';
import { fmtMs, fmtPct } from '../format';

const stateBadge: Record<string, { label: string; color: string }> = {
  ok: { label: 'ок', color: 'teal' },
  fail: { label: 'ошибка', color: 'red' },
  pending: { label: 'в процессе', color: 'yellow' },
};

// TestRunPanel показывает детальный ход и итог прогона теста: по каждому каналу —
// ок / ошибка / в процессе, плюс ключевые метрики результата. Пока прогон не завершён,
// панель обновляется каждые несколько секунд.
export function TestRunPanel({ runId, onClose }: { runId: number; onClose: () => void }) {
  const run = useTestRun(runId);
  const d = run.data;

  const results = d?.results ?? [];
  const done = results.filter((r) => r.state !== 'pending').length;
  const ok = results.filter((r) => r.state === 'ok').length;
  const fail = results.filter((r) => r.state === 'fail').length;
  const total = d?.expected ?? results.length;

  return (
    <div className="panel" style={{ marginTop: 16, borderColor: 'var(--fwd)' }}>
      <Group justify="space-between" mb="sm">
        <Group gap="sm">
          <Text fw={600}>Тест #{runId}</Text>
          {d && <Badge variant="light" color={d.status === 'done' ? 'teal' : 'blue'}>{d.status === 'done' ? 'завершён' : 'идёт'}</Badge>}
          {d && <Text size="sm" c="dimmed">ок {ok} · ошибок {fail} · всего {total}</Text>}
        </Group>
        <ActionIcon variant="subtle" color="gray" onClick={onClose}><IconX size={18} /></ActionIcon>
      </Group>

      {run.isLoading ? <Loader size="sm" /> : (
        <>
          <Progress.Root size="lg" mb="sm">
            <Progress.Section value={total ? (ok / total) * 100 : 0} color="teal" />
            <Progress.Section value={total ? (fail / total) * 100 : 0} color="red" />
          </Progress.Root>
          <Text size="xs" c="dimmed" mb="sm">Готово {done} из {total}</Text>
          <Table>
            <Table.Thead>
              <Table.Tr>
                <Table.Th>Канал</Table.Th><Table.Th>Статус</Table.Th>
                <Table.Th>Отпр/Получ</Table.Th><Table.Th>RTT</Table.Th><Table.Th>Потери</Table.Th><Table.Th>MOS</Table.Th>
                <Table.Th>Комментарий</Table.Th>
              </Table.Tr>
            </Table.Thead>
            <Table.Tbody>
              {results.map((r) => {
                const loss = r.result && r.result.sent > 0
                  ? (100 * (r.result.sent - r.result.received)) / r.result.sent : null;
                const sb = stateBadge[r.state] ?? stateBadge.pending;
                return (
                  <Table.Tr key={r.channel_id}>
                    <Table.Td>{r.channel}<Text size="xs" c="dimmed">{r.agent}</Text></Table.Td>
                    <Table.Td><Badge variant="light" color={sb.color}>{sb.label}</Badge></Table.Td>
                    <Table.Td>{r.result ? `${r.result.sent} / ${r.result.received}` : '—'}</Table.Td>
                    <Table.Td>{fmtMs(r.result?.rtt?.avg)}</Table.Td>
                    <Table.Td>{fmtPct(loss)}</Table.Td>
                    <Table.Td>{r.result?.mos != null ? r.result.mos.toFixed(2) : '—'}</Table.Td>
                    <Table.Td c={r.error ? 'red' : 'dimmed'}>{r.error ?? (r.state === 'ok' ? '' : '')}</Table.Td>
                  </Table.Tr>
                );
              })}
            </Table.Tbody>
          </Table>
        </>
      )}
    </div>
  );
}
