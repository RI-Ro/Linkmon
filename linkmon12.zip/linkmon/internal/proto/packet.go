// Package proto — формат измерительного пакета (по мотивам TWAMP-Light, RFC 5357).
//
//	offset size field
//	0      4    magic "LMP1"
//	4      1    version
//	5      1    flags (reply, test)
//	6      1    dscp_sent      — класс, в котором агент отправил пакет
//	7      1    dscp_received  — что фактически увидел рефлектор (0xFF — неизвестно)
//	8      8    session_id
//	16     4    seq_tx         — номер пакета агента
//	20     4    seq_refl       — номер ответа рефлектора
//	24     4    refl_rx_count  — накопительный счётчик принятых рефлектором пакетов
//	28     8    t1 (unix ns)   — отправка агентом
//	36     8    t2             — приём рефлектором (метка ядра)
//	44     8    t3             — отправка ответа рефлектором
//	52     12   reserved
//	64     16   HMAC-SHA256/128 по байтам [0:64]
//	80     N    padding до размера профиля
package proto

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/binary"
	"errors"
)

const (
	Magic       uint32 = 0x4C4D5031 // "LMP1"
	Version     uint8  = 1
	HeaderLen          = 80
	MaxPacket          = 1472 // 1500 - IP - UDP
	authOffset         = 64
	FlagReply   uint8  = 0x01
	FlagTest    uint8  = 0x02 // разовый тест: не учитывается в постоянной статистике рефлектора
	DSCPUnknown uint8  = 0xFF
)

var (
	ErrShort = errors.New("proto: packet too short")
	ErrMagic = errors.New("proto: bad magic or version")
	ErrAuth  = errors.New("proto: hmac mismatch")
)

type Packet struct {
	Flags       uint8
	DSCPSent    uint8
	DSCPRecv    uint8
	SessionID   uint64
	SeqTx       uint32
	SeqRefl     uint32
	ReflRxCount uint32
	T1, T2, T3  int64
}

func (p *Packet) IsReply() bool { return p.Flags&FlagReply != 0 }

// Marshal записывает заголовок в b и подписывает его. Байты после заголовка (padding) не трогаются.
func (p *Packet) Marshal(b []byte, key []byte) error {
	if len(b) < HeaderLen {
		return ErrShort
	}
	be := binary.BigEndian
	be.PutUint32(b[0:], Magic)
	b[4] = Version
	b[5] = p.Flags
	b[6] = p.DSCPSent
	b[7] = p.DSCPRecv
	be.PutUint64(b[8:], p.SessionID)
	be.PutUint32(b[16:], p.SeqTx)
	be.PutUint32(b[20:], p.SeqRefl)
	be.PutUint32(b[24:], p.ReflRxCount)
	be.PutUint64(b[28:], uint64(p.T1))
	be.PutUint64(b[36:], uint64(p.T2))
	be.PutUint64(b[44:], uint64(p.T3))
	clear(b[52:authOffset])
	sign(b, key)
	return nil
}

// PeekSession возвращает session_id без проверки подписи — чтобы найти ключ сессии.
func PeekSession(b []byte) (uint64, error) {
	if len(b) < HeaderLen {
		return 0, ErrShort
	}
	if binary.BigEndian.Uint32(b[0:]) != Magic || b[4] != Version {
		return 0, ErrMagic
	}
	return binary.BigEndian.Uint64(b[8:]), nil
}

func Unmarshal(b []byte, key []byte, p *Packet) error {
	if _, err := PeekSession(b); err != nil {
		return err
	}
	if !verify(b, key) {
		return ErrAuth
	}
	be := binary.BigEndian
	p.Flags = b[5]
	p.DSCPSent = b[6]
	p.DSCPRecv = b[7]
	p.SessionID = be.Uint64(b[8:])
	p.SeqTx = be.Uint32(b[16:])
	p.SeqRefl = be.Uint32(b[20:])
	p.ReflRxCount = be.Uint32(b[24:])
	p.T1 = int64(be.Uint64(b[28:]))
	p.T2 = int64(be.Uint64(b[36:]))
	p.T3 = int64(be.Uint64(b[44:]))
	return nil
}

func sign(b, key []byte) {
	m := hmac.New(sha256.New, key)
	m.Write(b[:authOffset])
	copy(b[authOffset:HeaderLen], m.Sum(nil)[:16])
}

func verify(b, key []byte) bool {
	m := hmac.New(sha256.New, key)
	m.Write(b[:authOffset])
	return hmac.Equal(m.Sum(nil)[:16], b[authOffset:HeaderLen])
}
