package proto

import (
	"encoding/binary"
	"errors"
	"time"
)

// TWAMP-Light (RFC 5357), unauthenticated mode — совместимость с аппаратными TWAMP-ответчиками.
//
// Sender Test Packet (unauth), RFC 4656 §4.1.2 — 14 значащих байт + добивка нулями до размера:
//   0  4  Sequence Number
//   4  8  Timestamp (NTP 64-bit)
//   12 2  Error Estimate
//   14 .. Packet Padding
//
// Reflected Test Packet (unauth), RFC 5357 §4.2.1 — 41 байт:
//   0  4  Sequence Number (рефлектора)
//   4  8  Timestamp (T3, отправка рефлектором)
//   12 2  Error Estimate
//   14 2  MBZ
//   16 8  Receive Timestamp (T2, приём рефлектором)
//   24 4  Sender Sequence Number
//   28 8  Sender Timestamp (T1, из пришедшего пакета)
//   36 2  Sender Error Estimate
//   38 2  MBZ
//   40 1  Sender TTL
//
// Времена — 64-битный формат NTP (секунды с 1900 + доля). Наш агент играет роль Session-Sender.

const (
	twampSenderMinLen = 14
	twampReflLen      = 41
	// Смещение эпохи NTP (1900) относительно Unix (1970) в секундах.
	ntpUnixOffset = 2208988800
)

var ErrTWAMPShort = errors.New("proto: twamp packet too short")

// TWAMPReply — распакованный отражённый пакет с четырьмя метками времени в наносекундах Unix.
type TWAMPReply struct {
	SenderSeq uint32
	ReflSeq   uint32
	T1        int64 // отправка агентом (из sender timestamp, эхо)
	T2        int64 // приём рефлектором
	T3        int64 // отправка рефлектором
}

// ntpToUnixNano переводит 64-битную NTP-метку в Unix-наносекунды.
func ntpToUnixNano(b []byte) int64 {
	sec := binary.BigEndian.Uint32(b[0:4])
	frac := binary.BigEndian.Uint32(b[4:8])
	// доля секунды: frac / 2^32
	ns := (int64(frac) * 1_000_000_000) >> 32
	return (int64(sec)-ntpUnixOffset)*1_000_000_000 + ns
}

// unixNanoToNTP записывает Unix-наносекунды в 64-битную NTP-метку.
func unixNanoToNTP(t int64, b []byte) {
	sec := t/1_000_000_000 + ntpUnixOffset
	ns := t % 1_000_000_000
	frac := (uint64(ns) << 32) / 1_000_000_000
	binary.BigEndian.PutUint32(b[0:4], uint32(sec))
	binary.BigEndian.PutUint32(b[4:8], uint32(frac))
}

// MarshalTWAMPSender формирует sender test packet в буфер размера size (>= 14).
// Возвращает T1 (момент отправки), проставленный в пакет.
func MarshalTWAMPSender(b []byte, seq uint32, size int) (int64, error) {
	if len(b) < twampSenderMinLen || size < twampSenderMinLen {
		return 0, ErrTWAMPShort
	}
	if size > len(b) {
		size = len(b)
	}
	clear(b[:size])
	binary.BigEndian.PutUint32(b[0:4], seq)
	t1 := time.Now().UnixNano()
	unixNanoToNTP(t1, b[4:12])
	// Error Estimate: S=0, Z=0, Scale=0, Multiplier=1 → 0x0001 (RFC 4656 §4.1.2).
	binary.BigEndian.PutUint16(b[12:14], 0x0001)
	return t1, nil
}

// UnmarshalTWAMPReply разбирает отражённый пакет TWAMP-ответчика.
func UnmarshalTWAMPReply(b []byte) (TWAMPReply, error) {
	if len(b) < twampReflLen {
		return TWAMPReply{}, ErrTWAMPShort
	}
	return TWAMPReply{
		ReflSeq:   binary.BigEndian.Uint32(b[0:4]),
		T3:        ntpToUnixNano(b[4:12]),
		T2:        ntpToUnixNano(b[16:24]),
		SenderSeq: binary.BigEndian.Uint32(b[24:28]),
		T1:        ntpToUnixNano(b[28:36]),
	}, nil
}
