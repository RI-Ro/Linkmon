package server

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/example/linkmon/internal/api"
)

// AdminHandler — REST для веб-интерфейса и автоматизации. Слушает localhost, наружу — через nginx.
func (s *Server) AdminHandler() http.Handler {
	m := http.NewServeMux()
	m.HandleFunc("GET /v1/admin/agents", s.adminListAgents)
	m.HandleFunc("POST /v1/admin/agents/{id}/approve", s.adminApprove)
	m.HandleFunc("POST /v1/admin/agents/{id}/reject", s.adminReject)
	m.HandleFunc("POST /v1/admin/agents/{id}/reload", s.adminReload)
	m.HandleFunc("POST /v1/admin/tokens", s.adminCreateToken)
	m.HandleFunc("GET /v1/admin/channels", s.adminListChannels)
	m.HandleFunc("PATCH /v1/admin/channels/{id}", s.adminUpdateChannel)
	m.HandleFunc("GET /v1/admin/channels/{id}/series", s.adminSeries)
	m.HandleFunc("GET /v1/admin/groups", s.adminListGroups)
	m.HandleFunc("POST /v1/admin/groups", s.adminCreateGroup)
	m.HandleFunc("POST /v1/admin/groups/{id}/members", s.adminAddMembers)
	m.HandleFunc("POST /v1/admin/groups/{id}/tests", s.adminRunGroupTest)
	m.HandleFunc("GET /v1/admin/tests/{id}", s.adminGetTest)
	m.HandleFunc("GET /v1/admin/tests", s.adminListTests)
	m.HandleFunc("DELETE /v1/admin/tests/{id}", s.adminDeleteTest)
	m.HandleFunc("POST /v1/admin/bwtests", s.adminCreateBWTest)
	m.HandleFunc("GET /v1/admin/bwtests/{id}", s.adminGetBWTest)
	m.HandleFunc("GET /v1/admin/bwtests", s.adminListBWTests)
	m.HandleFunc("DELETE /v1/admin/bwtests/{id}", s.adminDeleteBWTest)
	m.HandleFunc("GET /v1/admin/overview", s.adminOverview)
	m.HandleFunc("GET /v1/admin/channels/{id}/smoke", s.adminSmoke)
	m.HandleFunc("GET /v1/admin/alerts", s.adminListAlerts)
	m.HandleFunc("GET /v1/admin/sla-profiles", s.adminListSLA)
	m.HandleFunc("POST /v1/admin/sla-profiles", s.adminSaveSLA)
	m.HandleFunc("PUT /v1/admin/sla-profiles/{id}", s.adminSaveSLA)
	m.HandleFunc("GET /v1/admin/test-profiles", s.adminListTestProfiles)
	m.HandleFunc("GET /v1/admin/iface-load", s.adminListIfaceLoad)
	m.HandleFunc("GET /v1/admin/iface-monitors/{id}/series", s.adminLoadSeries)
	m.HandleFunc("GET /v1/admin/channels/{id}/load", s.adminChannelLoad)
	m.HandleFunc("DELETE /v1/admin/groups/{id}", s.adminDeleteGroup)
	m.HandleFunc("DELETE /v1/admin/groups/{id}/members/{channel}", s.adminRemoveMember)
	m.HandleFunc("GET /v1/admin/whoami", s.adminWhoami)
	m.HandleFunc("POST /v1/admin/change-password", s.adminChangePassword)

	// Управление каналами и агентами.
	m.HandleFunc("DELETE /v1/admin/channels/{id}", s.adminDeleteChannel)
	m.HandleFunc("POST /v1/admin/channels/{id}/test", s.adminRunChannelTest)
	m.HandleFunc("GET /v1/admin/tags", s.adminListTags)
	m.HandleFunc("POST /v1/admin/agents/{id}/name", s.adminRenameAgent)
	m.HandleFunc("POST /v1/admin/agents/{id}/groups", s.adminSetAgentGroups)
	m.HandleFunc("POST /v1/admin/agents/{id}/alert-mode", s.adminSetAgentAlertMode)
	m.HandleFunc("GET /v1/admin/agents/{id}/interfaces", s.adminAgentInterfaces)
	m.HandleFunc("POST /v1/admin/agents/{id}/channels", s.adminCreateAgentChannel)
	m.HandleFunc("GET /v1/admin/agents/{id}/bwtest-endpoint", s.adminAgentBWTestEndpoint)
	m.HandleFunc("GET /v1/admin/bwtest-defaults", s.adminBWTestDefaults)
	m.HandleFunc("POST /v1/admin/agents/{id}/disable", s.adminDisableAgent)
	m.HandleFunc("POST /v1/admin/agents/{id}/enable", s.adminEnableAgent)
	m.HandleFunc("DELETE /v1/admin/agents/{id}", s.adminDeleteAgent)

	// Алерты: подтверждение (снимает звук).
	m.HandleFunc("POST /v1/admin/alerts/{id}/ack", s.adminAckAlert)

	// Дашборды.
	m.HandleFunc("GET /v1/admin/dashboards", s.adminListDashboards)
	m.HandleFunc("POST /v1/admin/dashboards", s.adminCreateDashboard)
	m.HandleFunc("GET /v1/admin/dashboards/{id}", s.adminGetDashboard)
	m.HandleFunc("PATCH /v1/admin/dashboards/{id}", s.adminUpdateDashboard)
	m.HandleFunc("DELETE /v1/admin/dashboards/{id}", s.adminDeleteDashboard)
	m.HandleFunc("PUT /v1/admin/dashboards/{id}/widgets", s.adminSaveWidgets)

	// Интерактивные карты сети.
	m.HandleFunc("GET /v1/admin/maps", s.adminListMaps)
	m.HandleFunc("POST /v1/admin/maps", s.adminCreateMap)
	m.HandleFunc("GET /v1/admin/maps/{id}", s.adminGetMap)
	m.HandleFunc("PATCH /v1/admin/maps/{id}", s.adminUpdateMap)
	m.HandleFunc("PUT /v1/admin/maps/{id}/graph", s.adminSaveMapGraph)
	m.HandleFunc("DELETE /v1/admin/maps/{id}", s.adminDeleteMap)

	// Пользователи и области видимости (только big_admin).
	m.HandleFunc("GET /v1/admin/users", s.adminListUsers)
	m.HandleFunc("POST /v1/admin/users", s.adminCreateUser)
	m.HandleFunc("POST /v1/admin/users/{id}/scopes", s.adminSetUserScopes)
	m.HandleFunc("POST /v1/admin/users/{id}/role", s.adminSetUserRole)
	m.HandleFunc("POST /v1/admin/users/{id}/password", s.adminResetUserPassword)
	m.HandleFunc("POST /v1/admin/users/{id}/disable", s.adminSetUserDisabled)
	m.HandleFunc("DELETE /v1/admin/users/{id}", s.adminDeleteUser)
	m.HandleFunc("GET /v1/admin/all-groups", s.adminAllGroups)
	m.HandleFunc("GET /v1/admin/user-names", s.adminListUserNames)

	root := http.NewServeMux()
	// CA агентам нужен до входа — это публичный сертификат, не секрет.
	root.HandleFunc("GET /v1/admin/ca.crt", func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "application/x-pem-file")
		_, _ = w.Write(s.ca.CertPEM())
	})
	// Логин и выход не требуют активной сессии.
	root.HandleFunc("POST /v1/admin/login", s.adminLogin)
	root.HandleFunc("POST /v1/admin/logout", s.adminLogout)
	root.Handle("/v1/admin/", s.adminAuth(m))
	root.HandleFunc("GET /metrics", s.metrics)
	root.HandleFunc("GET /healthz", func(w http.ResponseWriter, _ *http.Request) { _, _ = w.Write([]byte("ok\n")) })
	if s.cfg.Web.Dir != "" {
		root.Handle("/", s.spaHandler(s.cfg.Web.Dir))
	}
	return root
}

const sessionCookie = "linkmon_session"

type ctxKey int

const userCtxKey ctxKey = 0

func userFrom(r *http.Request) *AdminUser {
	u, _ := r.Context().Value(userCtxKey).(*AdminUser)
	return u
}

// adminAuth пропускает запрос только при действующей сессионной cookie и кладёт
// пользователя в контекст. Для UI это невидимо: браузер сам шлёт HttpOnly-cookie.
func (s *Server) adminAuth(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		c, err := r.Cookie(sessionCookie)
		if err != nil {
			httpError(w, http.StatusUnauthorized, "not authenticated")
			return
		}
		u, err := s.store.SessionUser(r.Context(), c.Value)
		if err != nil {
			// Протухшая или неизвестная сессия — гасим cookie, чтобы клиент это увидел.
			s.clearSessionCookie(w)
			httpError(w, http.StatusUnauthorized, "session expired")
			return
		}
		ctx := context.WithValue(r.Context(), userCtxKey, u)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func (s *Server) setSessionCookie(w http.ResponseWriter, token string) {
	http.SetCookie(w, &http.Cookie{
		Name:     sessionCookie,
		Value:    token,
		Path:     "/",
		HttpOnly: true,
		Secure:   s.cfg.Web.Secure(),
		SameSite: http.SameSiteLaxMode,
		MaxAge:   int(s.cfg.Web.SessionTTL().Seconds()),
	})
}

func (s *Server) clearSessionCookie(w http.ResponseWriter) {
	http.SetCookie(w, &http.Cookie{
		Name:     sessionCookie,
		Value:    "",
		Path:     "/",
		HttpOnly: true,
		Secure:   s.cfg.Web.Secure(),
		SameSite: http.SameSiteLaxMode,
		MaxAge:   -1,
	})
}

func clientIP(r *http.Request) string {
	// За обратным прокси (nginx) реальный адрес приходит в X-Forwarded-For.
	if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
		if i := strings.IndexByte(xff, ','); i > 0 {
			return strings.TrimSpace(xff[:i])
		}
		return strings.TrimSpace(xff)
	}
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}

func (s *Server) adminLogin(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Login    string `json:"login"`
		Password string `json:"password"`
	}
	if err := decodeJSON(r, &req, 64<<10); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	u, err := s.store.Authenticate(r.Context(), strings.TrimSpace(req.Login), req.Password)
	if err != nil {
		if errors.Is(err, ErrAuth) {
			httpError(w, http.StatusUnauthorized, "неверный логин или пароль")
			return
		}
		s.storeErr(w, err)
		return
	}
	token, err := s.store.CreateSession(r.Context(), u.ID, s.cfg.Web.SessionTTL(), r.UserAgent(), clientIP(r))
	if err != nil {
		s.storeErr(w, err)
		return
	}
	s.setSessionCookie(w, token)
	writeJSON(w, http.StatusOK, map[string]string{"login": u.Login, "role": u.Role})
}

func (s *Server) adminLogout(w http.ResponseWriter, r *http.Request) {
	if c, err := r.Cookie(sessionCookie); err == nil {
		_ = s.store.DeleteSession(r.Context(), c.Value)
	}
	s.clearSessionCookie(w)
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) adminWhoami(w http.ResponseWriter, r *http.Request) {
	u := userFrom(r)
	writeJSON(w, http.StatusOK, map[string]string{"login": u.Login, "role": u.Role})
}

func (s *Server) adminChangePassword(w http.ResponseWriter, r *http.Request) {
	u := userFrom(r)
	var req struct {
		OldPassword string `json:"old_password"`
		NewPassword string `json:"new_password"`
	}
	if err := decodeJSON(r, &req, 64<<10); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if len(req.NewPassword) < 8 {
		httpError(w, http.StatusBadRequest, "пароль должен быть не короче 8 символов")
		return
	}
	if err := s.store.ChangePassword(r.Context(), u.ID, req.OldPassword, req.NewPassword); err != nil {
		if errors.Is(err, ErrAuth) {
			httpError(w, http.StatusForbidden, "старый пароль неверен")
			return
		}
		s.storeErr(w, err)
		return
	}
	// Пароль сменён — прежние сессии сброшены; выдаём новую, чтобы текущий пользователь не разлогинился.
	token, err := s.store.CreateSession(r.Context(), u.ID, s.cfg.Web.SessionTTL(), r.UserAgent(), clientIP(r))
	if err != nil {
		s.storeErr(w, err)
		return
	}
	s.setSessionCookie(w, token)
	w.WriteHeader(http.StatusNoContent)
}

func pathInt(r *http.Request) (int64, error) { return strconv.ParseInt(r.PathValue("id"), 10, 64) }

func (s *Server) storeErr(w http.ResponseWriter, err error) {
	if errors.Is(err, ErrNotFound) {
		httpError(w, http.StatusNotFound, "not found")
		return
	}
	if errors.Is(err, ErrBadRequest) {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	s.log.Error("admin api", "err", err)
	httpError(w, http.StatusInternalServerError, "internal error")
}

func (s *Server) adminListAgents(w http.ResponseWriter, r *http.Request) {
	list, err := s.store.ListAgents(r.Context(), userFrom(r))
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) adminApprove(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	if err := s.store.SetAgentStatus(r.Context(), id, api.StatusApproved); err != nil {
		s.storeErr(w, err)
		return
	}
	n, err := s.store.ProvisionChannels(r.Context(), id)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	// Сертификат агент получит при следующем опросе /v1/enroll (не позже чем через 30 с).
	writeJSON(w, http.StatusOK, map[string]any{"status": api.StatusApproved, "channels_created": n})
}

func (s *Server) adminReject(w http.ResponseWriter, r *http.Request) {
	if err := s.store.SetAgentStatus(r.Context(), r.PathValue("id"), api.StatusRejected); err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"status": api.StatusRejected})
}

func (s *Server) adminReload(w http.ResponseWriter, r *http.Request) {
	if err := s.store.EnqueueCommand(r.Context(), r.PathValue("id"), api.CmdReloadConfig, struct{}{}); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusAccepted)
}

func (s *Server) adminCreateToken(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Description string `json:"description"`
		GroupID     *int   `json:"group_id"`
		AutoApprove bool   `json:"auto_approve"`
		Uses        *int   `json:"uses"`
		TTLHours    int    `json:"ttl_hours"`
	}
	if err := decodeJSON(r, &req, 64<<10); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	tok, err := s.store.CreateToken(r.Context(), req.Description, req.GroupID, req.AutoApprove, req.Uses,
		time.Duration(req.TTLHours)*time.Hour)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusCreated, map[string]string{"token": tok})
}

func (s *Server) adminListChannels(w http.ResponseWriter, r *http.Request) {
	var agent *string
	if v := r.URL.Query().Get("agent_id"); v != "" {
		agent = &v
	}
	list, err := s.store.ListChannels(r.Context(), userFrom(r), agent)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) adminUpdateChannel(w http.ResponseWriter, r *http.Request) {
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	var p ChannelPatch
	if err := decodeJSON(r, &p, 64<<10); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	agentID, err := s.store.UpdateChannel(r.Context(), id, p)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	if err := s.store.EnqueueCommand(r.Context(), agentID, api.CmdReloadConfig, struct{}{}); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) adminSeries(w http.ResponseWriter, r *http.Request) {
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	from, to, err := parseRange(r, 6*time.Hour)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad time range")
		return
	}
	pts, view, err := s.store.Series(r.Context(), userFrom(r), id, from, to)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"channel_id": id, "source": view, "points": pts})
}

func (s *Server) adminListGroups(w http.ResponseWriter, r *http.Request) {
	list, err := s.store.ListGroups(r.Context(), userFrom(r))
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) adminCreateGroup(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Name     string   `json:"name"`
		ParentID *int     `json:"parent_id"`
		Tags     []string `json:"tags"`
	}
	if err := decodeJSON(r, &req, 64<<10); err != nil || req.Name == "" {
		httpError(w, http.StatusBadRequest, "name required")
		return
	}
	id, err := s.store.CreateGroup(r.Context(), req.Name, req.ParentID, req.Tags)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusCreated, map[string]int{"id": id})
}

func (s *Server) adminAddMembers(w http.ResponseWriter, r *http.Request) {
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	var req struct {
		ChannelIDs []int64 `json:"channel_ids"`
	}
	if err := decodeJSON(r, &req, 1<<20); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	n, err := s.store.AddGroupMembers(r.Context(), int(id), req.ChannelIDs)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]int64{"added": n})
}

// adminRunGroupTest — разовый синхронный тест всех каналов группы (включая подгруппы).
func (s *Server) adminRunGroupTest(w http.ResponseWriter, r *http.Request) {
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	var req struct {
		PPS         int        `json:"pps"`
		PacketSize  int        `json:"packet_size"`
		DurationSec int        `json:"duration_sec"`
		StartAt     *time.Time `json:"start_at"`
	}
	if err := decodeJSON(r, &req, 64<<10); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	p := api.RunTestPayload{PPS: req.PPS, PacketSize: req.PacketSize, DurationSec: req.DurationSec}
	if p.PPS <= 0 {
		p.PPS = 100
	}
	if p.DurationSec <= 0 {
		p.DurationSec = 60
	}
	if p.PPS > 1000 || p.DurationSec > 600 {
		httpError(w, http.StatusBadRequest, "pps <= 1000, duration_sec <= 600")
		return
	}
	// Запас в 5 секунд, чтобы команда успела дойти до всех агентов и они стартовали одновременно.
	p.StartAt = time.Now().Add(5 * time.Second).UTC()
	if req.StartAt != nil && req.StartAt.After(p.StartAt) {
		p.StartAt = req.StartAt.UTC()
	}
	runID, n, err := s.store.CreateTestRun(r.Context(), userFrom(r), int(id), p, testCreator(r))
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusAccepted, map[string]any{"run_id": runID, "channels": n, "start_at": p.StartAt})
}

func (s *Server) adminGetTest(w http.ResponseWriter, r *http.Request) {
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	run, err := s.store.GetTestRun(r.Context(), id)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, run)
}

// ---------- Prometheus ----------

var labelEscaper = strings.NewReplacer(`\`, `\\`, `"`, `\"`, "\n", `\n`)

type metricDef struct {
	name, help string
	get        func(*LatestRow) *float64
}

func i2f(v *int64) *float64 {
	if v == nil {
		return nil
	}
	f := float64(*v)
	return &f
}

var metricDefs = []metricDef{
	{"linkmon_rtt_ms", "Average round-trip time over the last interval", func(r *LatestRow) *float64 { return r.RTTAvg }},
	{"linkmon_fwd_delay_ms", "Average one-way delay agent->server", func(r *LatestRow) *float64 { return r.FwdDelayAvg }},
	{"linkmon_bwd_delay_ms", "Average one-way delay server->agent", func(r *LatestRow) *float64 { return r.BwdDelayAvg }},
	{"linkmon_fwd_jitter_ms", "RFC 3550 jitter agent->server", func(r *LatestRow) *float64 { return r.FwdJitter }},
	{"linkmon_bwd_jitter_ms", "RFC 3550 jitter server->agent", func(r *LatestRow) *float64 { return r.BwdJitter }},
	{"linkmon_loss_percent", "Round-trip packet loss", func(r *LatestRow) *float64 { return r.LossPct }},
	{"linkmon_fwd_loss_percent", "Packet loss agent->server", func(r *LatestRow) *float64 { return r.FwdLossPct }},
	{"linkmon_bwd_loss_percent", "Packet loss server->agent", func(r *LatestRow) *float64 { return r.BwdLossPct }},
	{"linkmon_mos", "Estimated MOS (simplified E-model)", func(r *LatestRow) *float64 { return r.MOS }},
	{"linkmon_fwd_remarked_packets", "Packets remarked agent->server", func(r *LatestRow) *float64 { return i2f(r.FwdRemarked) }},
	{"linkmon_bwd_remarked_packets", "Packets remarked server->agent", func(r *LatestRow) *float64 { return i2f(r.BwdRemarked) }},
}

func (s *Server) metrics(w http.ResponseWriter, r *http.Request) {
	rows, err := s.store.LatestMetrics(r.Context(), nil)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/plain; version=0.0.4")
	for _, d := range metricDefs {
		fmt.Fprintf(w, "# HELP %s %s\n# TYPE %s gauge\n", d.name, d.help, d.name)
		for i := range rows {
			row := &rows[i]
			v := d.get(row)
			if v == nil {
				continue
			}
			fmt.Fprintf(w, "%s{channel_id=\"%d\",channel=\"%s\",agent=\"%s\",interface=\"%s\",dscp=\"%s\"} %g\n",
				d.name, row.ChannelID, labelEscaper.Replace(row.Channel), labelEscaper.Replace(row.Agent),
				labelEscaper.Replace(row.Interface), labelEscaper.Replace(row.DSCPName), *v)
		}
	}
}

// ---------- UI, обзор, алерты, профили ----------

// spaHandler раздаёт собранный веб-интерфейс из cfg.Web.Dir. Файлы с хэшем в имени
// (обычно /assets/*) кэшируются надолго; index.html и прочее — без кэша, а любой
// неизвестный путь отдаёт index.html для клиентского роутинга (кроме /v1/ и /assets/).
func (s *Server) spaHandler(dir string) http.Handler {
	fsrv := http.FileServer(http.Dir(dir))
	index := filepath.Join(dir, "index.html")
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		clean := filepath.Clean("/" + r.URL.Path)
		p := filepath.Join(dir, clean)
		fi, err := os.Stat(p)
		if err != nil || fi.IsDir() {
			// Ассеты, которых нет, — это 404, а не подмена на index.html.
			if strings.HasPrefix(r.URL.Path, "/assets/") {
				http.NotFound(w, r)
				return
			}
			w.Header().Set("Cache-Control", "no-store")
			http.ServeFile(w, r, index)
			return
		}
		if strings.HasPrefix(r.URL.Path, "/assets/") {
			w.Header().Set("Cache-Control", "public, max-age=31536000, immutable")
		} else {
			w.Header().Set("Cache-Control", "no-store")
		}
		fsrv.ServeHTTP(w, r)
	})
}

func parseRange(r *http.Request, def time.Duration) (time.Time, time.Time, error) {
	to := time.Now()
	from := to.Add(-def)
	var err error
	if v := r.URL.Query().Get("from"); v != "" {
		if from, err = time.Parse(time.RFC3339, v); err != nil {
			return from, to, err
		}
	}
	if v := r.URL.Query().Get("to"); v != "" {
		if to, err = time.Parse(time.RFC3339, v); err != nil {
			return from, to, err
		}
	}
	return from, to, nil
}

func queryInt(r *http.Request, name string, def int) int {
	if v, err := strconv.Atoi(r.URL.Query().Get(name)); err == nil && v > 0 {
		return v
	}
	return def
}

func (s *Server) adminOverview(w http.ResponseWriter, r *http.Request) {
	o, err := s.store.Overview(r.Context(), userFrom(r), time.Duration(s.cfg.Alerts.AgentDownAfterSec)*time.Second)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, o)
}

func (s *Server) adminSmoke(w http.ResponseWriter, r *http.Request) {
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	from, to, err := parseRange(r, 6*time.Hour)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad time range")
		return
	}
	pts, err := s.store.Smoke(r.Context(), userFrom(r), id, from, to)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"channel_id": id, "points": pts})
}

func (s *Server) adminListIfaceLoad(w http.ResponseWriter, r *http.Request) {
	var agent *string
	if v := r.URL.Query().Get("agent_id"); v != "" {
		agent = &v
	}
	list, err := s.store.ListIfaceMonitors(r.Context(), userFrom(r), agent)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) adminLoadSeries(w http.ResponseWriter, r *http.Request) {
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	from, to, err := parseRange(r, 6*time.Hour)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad time range")
		return
	}
	pts, view, err := s.store.LoadSeries(r.Context(), userFrom(r), id, from, to)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"monitor_id": id, "source": view, "points": pts})
}

// adminChannelLoad — загрузка интерфейса того же канала (для страницы канала).
func (s *Server) adminChannelLoad(w http.ResponseWriter, r *http.Request) {
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	mid, err := s.store.MonitorForChannel(r.Context(), id)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	if mid == 0 {
		writeJSON(w, http.StatusOK, map[string]any{"monitor_id": 0, "points": []any{}})
		return
	}
	from, to, err := parseRange(r, 6*time.Hour)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad time range")
		return
	}
	pts, view, err := s.store.LoadSeries(r.Context(), userFrom(r), mid, from, to)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"monitor_id": mid, "source": view, "points": pts})
}

func (s *Server) adminListAlerts(w http.ResponseWriter, r *http.Request) {
	var ch *int64
	if v, err := strconv.ParseInt(r.URL.Query().Get("channel_id"), 10, 64); err == nil {
		ch = &v
	}
	list, err := s.store.ListAlerts(r.Context(), userFrom(r), r.URL.Query().Get("state") == "open", ch, min(queryInt(r, "limit", 200), 1000))
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) adminListSLA(w http.ResponseWriter, r *http.Request) {
	list, err := s.store.ListSLAProfiles(r.Context())
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) adminSaveSLA(w http.ResponseWriter, r *http.Request) {
	var p SLAProfile
	if err := decodeJSON(r, &p, 64<<10); err != nil || strings.TrimSpace(p.Name) == "" {
		httpError(w, http.StatusBadRequest, "name required")
		return
	}
	p.ID = 0
	if r.PathValue("id") != "" {
		id, err := pathInt(r)
		if err != nil {
			httpError(w, http.StatusBadRequest, "bad id")
			return
		}
		p.ID = int(id)
	}
	id, err := s.store.SaveSLAProfile(r.Context(), p)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]int{"id": id})
}

func (s *Server) adminListTestProfiles(w http.ResponseWriter, r *http.Request) {
	list, err := s.store.ListTestProfiles(r.Context())
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) adminListTests(w http.ResponseWriter, r *http.Request) {
	var g *int
	if v, err := strconv.Atoi(r.URL.Query().Get("group_id")); err == nil {
		g = &v
	}
	list, err := s.store.ListTestRuns(r.Context(), userFrom(r), g, min(queryInt(r, "limit", 50), 500))
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) adminDeleteGroup(w http.ResponseWriter, r *http.Request) {
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	if err := s.store.DeleteGroup(r.Context(), int(id)); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) adminRemoveMember(w http.ResponseWriter, r *http.Request) {
	id, err1 := pathInt(r)
	ch, err2 := strconv.ParseInt(r.PathValue("channel"), 10, 64)
	if err1 != nil || err2 != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	if err := s.store.RemoveGroupMember(r.Context(), int(id), ch); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
