package server

import (
	"bytes"
	"context"
	"encoding/json"
	"log/slog"
	"net/http"
	"time"
)

// AlertEngine раз в interval проверяет последние N интервалов каждого канала против его SLA.
// Алерт открывается, когда нарушены все N интервалов подряд, и закрывается, когда N подряд в норме:
// это гистерезис, который не даёт алерту «мигать» на единичных всплесках.
type AlertEngine struct {
	store     *Store
	interval  time.Duration
	agentDown time.Duration
	webhook   string
	hc        *http.Client
	log       *slog.Logger
}

func NewAlertEngine(st *Store, cfg *Config, log *slog.Logger) *AlertEngine {
	return &AlertEngine{
		store:     st,
		interval:  time.Duration(cfg.Alerts.IntervalSec) * time.Second,
		agentDown: time.Duration(cfg.Alerts.AgentDownAfterSec) * time.Second,
		webhook:   cfg.Alerts.WebhookURL,
		hc:        &http.Client{Timeout: 10 * time.Second},
		log:       log.With("component", "alerts"),
	}
}

func (e *AlertEngine) Run(ctx context.Context) {
	t := time.NewTicker(e.interval)
	defer t.Stop()
	for {
		if err := e.evaluate(ctx); err != nil && ctx.Err() == nil {
			e.log.Error("evaluation failed", "err", err)
		}
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
	}
}

type slaCheck struct {
	kind     string
	severity string
	// eval: применимо ли правило и нарушено ли оно в интервале; details — для последнего интервала.
	eval func(r *SLARow) (applicable, breach bool, details map[string]any)
}

func gt(v, lim *float64) bool { return v != nil && lim != nil && *v > *lim }

var slaChecks = []slaCheck{
	{"rtt", "warning", func(r *SLARow) (bool, bool, map[string]any) {
		if r.MaxRTT == nil || r.RTTAvg == nil {
			return false, false, nil
		}
		return true, *r.RTTAvg > *r.MaxRTT, map[string]any{"value": *r.RTTAvg, "limit": *r.MaxRTT}
	}},
	{"oneway", "warning", func(r *SLARow) (bool, bool, map[string]any) {
		if r.MaxOneway == nil || (r.FwdDelayAvg == nil && r.BwdDelayAvg == nil) {
			return false, false, nil
		}
		f, b := gt(r.FwdDelayAvg, r.MaxOneway), gt(r.BwdDelayAvg, r.MaxOneway)
		return true, f || b, map[string]any{"fwd": r.FwdDelayAvg, "bwd": r.BwdDelayAvg, "limit": *r.MaxOneway, "fwd_breach": f, "bwd_breach": b}
	}},
	{"jitter", "warning", func(r *SLARow) (bool, bool, map[string]any) {
		if r.MaxJitter == nil || (r.FwdJitter == nil && r.BwdJitter == nil) {
			return false, false, nil
		}
		f, b := gt(r.FwdJitter, r.MaxJitter), gt(r.BwdJitter, r.MaxJitter)
		return true, f || b, map[string]any{"fwd": r.FwdJitter, "bwd": r.BwdJitter, "limit": *r.MaxJitter, "fwd_breach": f, "bwd_breach": b}
	}},
	{"loss", "critical", func(r *SLARow) (bool, bool, map[string]any) {
		if r.MaxLoss == nil || r.LossPct == nil {
			return false, false, nil
		}
		return true, *r.LossPct > *r.MaxLoss, map[string]any{"value": *r.LossPct, "fwd": r.FwdLossPct, "bwd": r.BwdLossPct, "limit": *r.MaxLoss}
	}},
	{"mos", "critical", func(r *SLARow) (bool, bool, map[string]any) {
		if r.MinMOS == nil || r.MOS == nil {
			return false, false, nil
		}
		return true, *r.MOS < *r.MinMOS, map[string]any{"value": *r.MOS, "limit": *r.MinMOS}
	}},
	{"remarking", "warning", func(r *SLARow) (bool, bool, map[string]any) {
		if r.AllowRemarking || (r.FwdRemarked == nil && r.BwdRemarked == nil) {
			return false, false, nil
		}
		var f, b int64
		if r.FwdRemarked != nil {
			f = *r.FwdRemarked
		}
		if r.BwdRemarked != nil {
			b = *r.BwdRemarked
		}
		return true, f+b > 0, map[string]any{"fwd": f, "bwd": b}
	}},
}

func (e *AlertEngine) evaluate(ctx context.Context) error {
	rows, err := e.store.SLAWindows(ctx)
	if err != nil {
		return err
	}
	open, err := e.store.OpenAlertKeys(ctx)
	if err != nil {
		return err
	}

	// Окна по каналам: строки уже отсортированы по channel_id, ts DESC.
	windows := map[int64][]*SLARow{}
	for i := range rows {
		windows[rows[i].ChannelID] = append(windows[rows[i].ChannelID], &rows[i])
	}
	for chID, win := range windows {
		if len(win) < win[0].BreachIntervals {
			continue // данных меньше окна — состояние не меняем
		}
		// Режим агента 'critical' подавляет предупреждения (warning): следим только за критичным.
		criticalOnly := win[0].AlertMode == "critical"
		for _, c := range slaChecks {
			if criticalOnly && c.severity != "critical" {
				continue
			}
			breached, ok := 0, 0
			var details map[string]any
			for i, r := range win {
				applicable, breach, d := c.eval(r)
				if i == 0 {
					details = d
				}
				switch {
				case applicable && breach:
					breached++
				case applicable:
					ok++
				}
			}
			key := alertKey{ChannelID: chID, Kind: c.kind}
			id, isOpen := open[key]
			switch {
			case breached == len(win):
				details["intervals"] = len(win)
				if _, inserted, err := e.store.UpsertAlert(ctx, key, c.severity, details); err != nil {
					return err
				} else if inserted {
					e.notify("opened", key, c.severity, details)
				}
			case isOpen && ok == len(win):
				if err := e.store.CloseAlert(ctx, id); err != nil {
					return err
				}
				e.notify("resolved", key, c.severity, nil)
			}
		}
	}
	// Каналы без SLA или отключённые: их открытые SLA-алерты закрываем.
	for k, id := range open {
		if k.ChannelID != 0 && windows[k.ChannelID] == nil && k.Kind != "agent_down" && k.Kind != "util" {
			if err := e.store.CloseAlert(ctx, id); err != nil {
				return err
			}
		}
	}
	if err := e.evaluateUtil(ctx, open); err != nil {
		return err
	}
	return e.evaluateAgents(ctx, open)
}

// evaluateUtil открывает алерт «канал перегружен», когда утилизация интерфейса (в любую
// сторону) превышает порог max_util_pct профиля SLA на протяжении всего окна breach_intervals.
func (e *AlertEngine) evaluateUtil(ctx context.Context, open map[alertKey]int64) error {
	rows, err := e.store.UtilWindows(ctx)
	if err != nil {
		return err
	}
	windows := map[int64][]*UtilRow{}
	for i := range rows {
		windows[rows[i].ChannelID] = append(windows[rows[i].ChannelID], &rows[i])
	}
	seen := map[int64]bool{}
	for chID, win := range windows {
		seen[chID] = true
		if len(win) < win[0].BreachIntervals {
			continue
		}
		breached, ok := 0, 0
		var details map[string]any
		for i, r := range win {
			limit := r.MaxUtil
			rx, tx := r.RxUtilPct, r.TxUtilPct
			over := (rx != nil && limit != nil && *rx > *limit) || (tx != nil && limit != nil && *tx > *limit)
			if i == 0 {
				details = map[string]any{"rx": rx, "tx": tx, "limit": limit,
					"rx_breach": rx != nil && limit != nil && *rx > *limit,
					"tx_breach": tx != nil && limit != nil && *tx > *limit}
			}
			if rx != nil || tx != nil {
				if over {
					breached++
				} else {
					ok++
				}
			}
		}
		key := alertKey{ChannelID: chID, Kind: "util"}
		id, isOpen := open[key]
		switch {
		case breached == len(win):
			details["intervals"] = len(win)
			if _, inserted, err := e.store.UpsertAlert(ctx, key, "warning", details); err != nil {
				return err
			} else if inserted {
				e.notify("opened", key, "warning", details)
			}
		case isOpen && ok == len(win):
			if err := e.store.CloseAlert(ctx, id); err != nil {
				return err
			}
			e.notify("resolved", key, "warning", nil)
		}
	}
	// Канал больше не в выборке (снят SLA-порог или нет данных) — закрываем его util-алерт.
	for k, id := range open {
		if k.Kind == "util" && !seen[k.ChannelID] {
			if err := e.store.CloseAlert(ctx, id); err != nil {
				return err
			}
		}
	}
	return nil
}

func (e *AlertEngine) evaluateAgents(ctx context.Context, open map[alertKey]int64) error {
	silent, err := e.store.SilentAgents(ctx, e.agentDown)
	if err != nil {
		return err
	}
	down := map[string]bool{}
	for _, a := range silent {
		down[a.ID] = true
		key := alertKey{AgentID: a.ID, Kind: "agent_down"}
		details := map[string]any{"hostname": a.Hostname, "last_seen": a.LastSeen}
		if _, inserted, err := e.store.UpsertAlert(ctx, key, "critical", details); err != nil {
			return err
		} else if inserted {
			e.notify("opened", key, "critical", details)
		}
	}
	for k, id := range open {
		if k.Kind == "agent_down" && !down[k.AgentID] {
			if err := e.store.CloseAlert(ctx, id); err != nil {
				return err
			}
			e.notify("resolved", k, "critical", nil)
		}
	}
	return nil
}

func (e *AlertEngine) notify(event string, k alertKey, severity string, details map[string]any) {
	e.log.Info("alert "+event, "kind", k.Kind, "channel_id", k.ChannelID, "agent_id", k.AgentID, "severity", severity)
	if e.webhook == "" {
		return
	}
	body, _ := json.Marshal(map[string]any{
		"event": event, "kind": k.Kind, "severity": severity, "channel_id": k.ChannelID,
		"agent_id": k.AgentID, "details": details, "at": time.Now().UTC(),
	})
	go func() {
		resp, err := e.hc.Post(e.webhook, "application/json", bytes.NewReader(body))
		if err != nil {
			e.log.Warn("webhook failed", "err", err)
			return
		}
		resp.Body.Close()
	}()
}
