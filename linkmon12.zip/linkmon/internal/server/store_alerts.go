package server

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"time"

	"github.com/jackc/pgx/v5"
)

// EnsureBootstrapToken создаёт (или «оживляет») токен разработчика с автоодобрением.
func (s *Store) EnsureBootstrapToken(ctx context.Context, tok string) error {
	h := sha256.Sum256([]byte(tok))
	_, err := s.pool.Exec(ctx, `INSERT INTO enroll_tokens (token_hash, description, auto_approve)
		VALUES ($1, 'dev bootstrap', true)
		ON CONFLICT (token_hash) DO UPDATE SET auto_approve = true, uses_left = NULL, expires_at = NULL`, h[:])
	return err
}

// ---------- SLA-движок ----------

type SLARow struct {
	ChannelID       int64     `db:"channel_id"`
	TS              time.Time `db:"ts"`
	RTTAvg          *float64  `db:"rtt_avg"`
	FwdDelayAvg     *float64  `db:"fwd_delay_avg"`
	BwdDelayAvg     *float64  `db:"bwd_delay_avg"`
	FwdJitter       *float64  `db:"fwd_jitter"`
	BwdJitter       *float64  `db:"bwd_jitter"`
	LossPct         *float64  `db:"loss_pct"`
	FwdLossPct      *float64  `db:"fwd_loss_pct"`
	BwdLossPct      *float64  `db:"bwd_loss_pct"`
	MOS             *float64  `db:"mos"`
	FwdRemarked     *int64    `db:"fwd_remarked"`
	BwdRemarked     *int64    `db:"bwd_remarked"`
	MaxRTT          *float64  `db:"max_rtt_ms"`
	MaxOneway       *float64  `db:"max_oneway_ms"`
	MaxJitter       *float64  `db:"max_jitter_ms"`
	MaxLoss         *float64  `db:"max_loss_pct"`
	MinMOS          *float64  `db:"min_mos"`
	AllowRemarking  bool      `db:"allow_remarking"`
	BreachIntervals int       `db:"breach_intervals"`
	AlertMode       string    `db:"alert_mode"` // all | critical | off (режим оповещений агента)
}

// SLAWindows — последние breach_intervals интервалов каждого канала с назначенным SLA.
func (s *Store) SLAWindows(ctx context.Context) ([]SLARow, error) {
	rows, err := s.pool.Query(ctx, `SELECT m.channel_id, m.ts, m.rtt_avg, m.fwd_delay_avg, m.bwd_delay_avg,
			m.fwd_jitter, m.bwd_jitter, m.loss_pct, m.fwd_loss_pct, m.bwd_loss_pct, m.mos,
			m.fwd_remarked::bigint AS fwd_remarked, m.bwd_remarked::bigint AS bwd_remarked,
			s.max_rtt_ms, s.max_oneway_ms, s.max_jitter_ms, s.max_loss_pct, s.min_mos,
			s.allow_remarking, s.breach_intervals, a.alert_mode
		FROM (
			SELECT v.*, row_number() OVER (PARTITION BY v.channel_id ORDER BY v.ts DESC) AS rn
			FROM v_measurements v
			WHERE v.ts > now() - interval '2 hours' AND v.sent IS NOT NULL
		) m
		JOIN channels c     ON c.id = m.channel_id
		JOIN agents a       ON a.id = c.agent_id
		JOIN sla_profiles s ON s.id = c.sla_id
		WHERE m.rn <= s.breach_intervals AND c.enabled AND a.status = 'approved' AND a.alert_mode <> 'off'
		ORDER BY m.channel_id, m.ts DESC`)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[SLARow])
}

type alertKey struct {
	ChannelID int64
	AgentID   string
	Kind      string
}

func (s *Store) OpenAlertKeys(ctx context.Context) (map[alertKey]int64, error) {
	rows, err := s.pool.Query(ctx, `SELECT id, COALESCE(channel_id, 0), COALESCE(agent_id::text, ''), kind
		FROM alerts WHERE ended_at IS NULL`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := map[alertKey]int64{}
	for rows.Next() {
		var id int64
		var k alertKey
		if err := rows.Scan(&id, &k.ChannelID, &k.AgentID, &k.Kind); err != nil {
			return nil, err
		}
		out[k] = id
	}
	return out, rows.Err()
}

// UpsertAlert открывает алерт или обновляет уже открытый. inserted — алерт новый.
func (s *Store) UpsertAlert(ctx context.Context, k alertKey, severity string, details map[string]any) (int64, bool, error) {
	b, _ := json.Marshal(details)
	var ch *int64
	var ag *string
	if k.ChannelID != 0 {
		ch = &k.ChannelID
	}
	if k.AgentID != "" {
		ag = &k.AgentID
	}
	var id int64
	var inserted bool
	err := s.pool.QueryRow(ctx, `INSERT INTO alerts (channel_id, agent_id, kind, severity, started_at, last_seen_at, details)
		VALUES ($1, $2::uuid, $3, $4, now(), now(), $5)
		ON CONFLICT (COALESCE(channel_id, 0), COALESCE(agent_id, '00000000-0000-0000-0000-000000000000'::uuid), kind)
			WHERE ended_at IS NULL
		DO UPDATE SET last_seen_at = now(), details = EXCLUDED.details, severity = EXCLUDED.severity
		RETURNING id, (xmax = 0) AS inserted`, ch, ag, k.Kind, severity, b).Scan(&id, &inserted)
	return id, inserted, err
}

func (s *Store) CloseAlert(ctx context.Context, id int64) error {
	_, err := s.pool.Exec(ctx, `UPDATE alerts SET ended_at = now() WHERE id = $1 AND ended_at IS NULL`, id)
	return err
}

type SilentAgent struct {
	ID       string     `db:"id"`
	Hostname string     `db:"hostname"`
	LastSeen *time.Time `db:"last_seen"`
}

func (s *Store) SilentAgents(ctx context.Context, after time.Duration) ([]SilentAgent, error) {
	rows, err := s.pool.Query(ctx, `SELECT id::text AS id, hostname, last_seen FROM agents
		WHERE status = 'approved' AND alert_mode <> 'off'
		  AND (last_seen IS NULL OR last_seen < now() - $1::interval)`, after)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[SilentAgent])
}

// ---------- Алерты для UI ----------

type AlertView struct {
	ID         int64          `db:"id" json:"id"`
	Kind       string         `db:"kind" json:"kind"`
	Severity   string         `db:"severity" json:"severity"`
	StartedAt  time.Time      `db:"started_at" json:"started_at"`
	EndedAt    *time.Time     `db:"ended_at" json:"ended_at"`
	LastSeenAt *time.Time     `db:"last_seen_at" json:"last_seen_at"`
	AckedAt    *time.Time     `db:"acked_at" json:"acked_at"`
	Details    map[string]any `db:"details" json:"details"`
	ChannelID  *int64         `db:"channel_id" json:"channel_id"`
	Channel    *string        `db:"channel" json:"channel"`
	DSCPName   *string        `db:"dscp_name" json:"dscp_name"`
	AgentID    *string        `db:"agent_id" json:"agent_id"`
	Agent      *string        `db:"agent" json:"agent"`
}

// ListAlerts отдаёт алерты в области видимости пользователя (RLS через asUser).
// Алерты по агентам (agent_down) виден всем, у кого есть каналы этого агента, а также big_admin.
func (s *Store) ListAlerts(ctx context.Context, u *AdminUser, openOnly bool, channelID *int64, limit int) ([]AlertView, error) {
	c, err := s.asUser(ctx, u)
	if err != nil {
		return nil, err
	}
	defer c.Release()
	rows, err := c.Query(ctx, `SELECT id, kind, severity, started_at, ended_at, last_seen_at, acked_at, details,
			channel_id, channel, dscp_name, agent_id::text AS agent_id, agent
		FROM v_alerts
		WHERE (NOT $1 OR ended_at IS NULL) AND ($2::bigint IS NULL OR channel_id = $2)
		  AND (channel_id IS NULL OR linkmon_can_see_channel(channel_id))
		ORDER BY ended_at IS NOT NULL, started_at DESC
		LIMIT $3`, openOnly, channelID, limit)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[AlertView])
}

// AckAlert подтверждает алерт — звук в интерфейсе прекращается. Возвращает ErrNotFound,
// если алерта нет или он уже закрыт.
func (s *Store) AckAlert(ctx context.Context, id, userID int64) error {
	tag, err := s.pool.Exec(ctx, `UPDATE alerts SET acked_at = now(), acked_by = $2
		WHERE id = $1 AND ended_at IS NULL AND acked_at IS NULL`, id, userID)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

// ---------- SLA- и тест-профили ----------

type SLAProfile struct {
	ID              int      `db:"id" json:"id"`
	Name            string   `db:"name" json:"name"`
	MaxRTT          *float64 `db:"max_rtt_ms" json:"max_rtt_ms"`
	MaxOneway       *float64 `db:"max_oneway_ms" json:"max_oneway_ms"`
	MaxJitter       *float64 `db:"max_jitter_ms" json:"max_jitter_ms"`
	MaxLoss         *float64 `db:"max_loss_pct" json:"max_loss_pct"`
	MinMOS          *float64 `db:"min_mos" json:"min_mos"`
	MaxUtil         *float64 `db:"max_util_pct" json:"max_util_pct"`
	AllowRemarking  bool     `db:"allow_remarking" json:"allow_remarking"`
	BreachIntervals int      `db:"breach_intervals" json:"breach_intervals"`
	Channels        int64    `db:"channels" json:"channels"`
}

func (s *Store) ListSLAProfiles(ctx context.Context) ([]SLAProfile, error) {
	rows, err := s.pool.Query(ctx, `SELECT p.id, p.name, p.max_rtt_ms::float8 AS max_rtt_ms,
			p.max_oneway_ms::float8 AS max_oneway_ms, p.max_jitter_ms::float8 AS max_jitter_ms,
			p.max_loss_pct::float8 AS max_loss_pct, p.min_mos::float8 AS min_mos,
			p.max_util_pct::float8 AS max_util_pct, p.allow_remarking, p.breach_intervals,
			(SELECT count(*) FROM channels c WHERE c.sla_id = p.id) AS channels
		FROM sla_profiles p ORDER BY p.name`)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[SLAProfile])
}

// SaveSLAProfile создаёт профиль (id == 0) или полностью перезаписывает существующий.
func (s *Store) SaveSLAProfile(ctx context.Context, p SLAProfile) (int, error) {
	if p.BreachIntervals <= 0 {
		p.BreachIntervals = 3
	}
	if p.ID == 0 {
		err := s.pool.QueryRow(ctx, `INSERT INTO sla_profiles
			(name, max_rtt_ms, max_oneway_ms, max_jitter_ms, max_loss_pct, min_mos, max_util_pct, allow_remarking, breach_intervals)
			VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING id`,
			p.Name, p.MaxRTT, p.MaxOneway, p.MaxJitter, p.MaxLoss, p.MinMOS, p.MaxUtil, p.AllowRemarking, p.BreachIntervals).Scan(&p.ID)
		return p.ID, err
	}
	tag, err := s.pool.Exec(ctx, `UPDATE sla_profiles SET name = $2, max_rtt_ms = $3, max_oneway_ms = $4,
			max_jitter_ms = $5, max_loss_pct = $6, min_mos = $7, max_util_pct = $8, allow_remarking = $9, breach_intervals = $10
		WHERE id = $1`, p.ID, p.Name, p.MaxRTT, p.MaxOneway, p.MaxJitter, p.MaxLoss, p.MinMOS, p.MaxUtil, p.AllowRemarking, p.BreachIntervals)
	if err == nil && tag.RowsAffected() == 0 {
		err = ErrNotFound
	}
	return p.ID, err
}

type TestProfile struct {
	ID          int    `db:"id" json:"id"`
	Name        string `db:"name" json:"name"`
	PPS         int    `db:"pps" json:"pps"`
	PacketSize  int    `db:"packet_size" json:"packet_size"`
	Poisson     bool   `db:"poisson" json:"poisson"`
	IntervalSec int    `db:"interval_sec" json:"interval_sec"`
}

func (s *Store) ListTestProfiles(ctx context.Context) ([]TestProfile, error) {
	rows, err := s.pool.Query(ctx, `SELECT id, name, pps, packet_size, poisson, interval_sec FROM test_profiles ORDER BY id`)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[TestProfile])
}

// ---------- Обзор, smoke, тесты, группы ----------

type Overview struct {
	AgentsTotal   int64       `json:"agents_total"`
	AgentsOnline  int64       `json:"agents_online"`
	AgentsPending int64       `json:"agents_pending"`
	Channels      int64       `json:"channels"`
	Latest        []LatestRow `json:"latest"`
	OpenAlerts    []AlertView `json:"open_alerts"`
}

func (s *Store) Overview(ctx context.Context, u *AdminUser, onlineWithin time.Duration) (*Overview, error) {
	var o Overview
	// Счётчики каналов/агентов считаем на scoped-соединении, чтобы обзор соответствовал области видимости.
	c, err := s.asUser(ctx, u)
	if err != nil {
		return nil, err
	}
	if err := c.QueryRow(ctx, `SELECT
			(SELECT count(*) FROM agents WHERE status <> 'rejected'
			   AND (linkmon_role() IN ('', 'big_admin') OR linkmon_can_see_agent(agents.id)
			        OR EXISTS (SELECT 1 FROM channels ch WHERE ch.agent_id = agents.id AND linkmon_can_see_channel(ch.id)))),
			(SELECT count(*) FROM agents WHERE status = 'approved' AND last_seen > now() - $1::interval
			   AND (linkmon_role() IN ('', 'big_admin') OR linkmon_can_see_agent(agents.id)
			        OR EXISTS (SELECT 1 FROM channels ch WHERE ch.agent_id = agents.id AND linkmon_can_see_channel(ch.id)))),
			(SELECT count(*) FROM agents WHERE status = 'pending'
			   AND linkmon_role() IN ('', 'big_admin')),
			(SELECT count(*) FROM channels WHERE enabled AND NOT stale AND linkmon_can_see_channel(id))`, onlineWithin).
		Scan(&o.AgentsTotal, &o.AgentsOnline, &o.AgentsPending, &o.Channels); err != nil {
		c.Release()
		return nil, err
	}
	c.Release()
	if o.Latest, err = s.LatestMetrics(ctx, u); err != nil {
		return nil, err
	}
	if o.OpenAlerts, err = s.ListAlerts(ctx, u, true, nil, 500); err != nil {
		return nil, err
	}
	return &o, nil
}

type SmokePoint struct {
	TS      time.Time `db:"ts" json:"ts"`
	RTTQ    []float64 `db:"rtt_q" json:"rtt_q"`
	RTTP50  *float64  `db:"rtt_p50" json:"rtt_p50"`
	LossPct *float64  `db:"loss_pct" json:"loss_pct"`
}

// Smoke — данные для smoke-графика в духе SmokePing (только сырые минуты, не больше 7 суток).
func (s *Store) Smoke(ctx context.Context, u *AdminUser, channelID int64, from, to time.Time) ([]SmokePoint, error) {
	if to.Sub(from) > 7*24*time.Hour {
		from = to.Add(-7 * 24 * time.Hour)
	}
	c, err := s.asUser(ctx, u)
	if err != nil {
		return nil, err
	}
	defer c.Release()
	rows, err := c.Query(ctx, `SELECT ts, rtt_q::float8[] AS rtt_q, rtt_p50::float8 AS rtt_p50, loss_pct::float8 AS loss_pct
		FROM v_measurements WHERE channel_id = $1 AND ts >= $2 AND ts < $3 AND sent IS NOT NULL
		  AND linkmon_can_see_channel(channel_id)
		ORDER BY ts`, channelID, from, to)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[SmokePoint])
}

type TestRunListItem struct {
	ID          int64     `db:"id" json:"id"`
	Kind        string    `db:"kind" json:"kind"`
	GroupID     *int      `db:"group_id" json:"group_id"`
	GroupName   *string   `db:"group_name" json:"group_name"`
	ChannelID   *int64    `db:"channel_id" json:"channel_id"`
	Target      string    `db:"target" json:"target"` // что тестировали: группа или канал
	StartAt     time.Time `db:"start_at" json:"start_at"`
	DurationSec int       `db:"duration_sec" json:"duration_sec"`
	Expected    int       `db:"expected" json:"expected"`
	Received    int64     `db:"received" json:"received"`
	Status      string    `db:"status" json:"status"`
	CreatedBy   *string   `db:"created_by" json:"created_by"` // кто запустил
	CreatedAt   time.Time `db:"created_at" json:"created_at"` // когда запустил
}

// ListTestRuns — история прогонов. groupID != nil — только по группе; иначе все последние.
// ListTestRuns — история прогонов в области видимости пользователя. Прогон виден, если это
// тест видимого канала, тест группы из области пользователя, или среди целей есть видимый канал.
func (s *Store) ListTestRuns(ctx context.Context, u *AdminUser, groupID *int, limit int) ([]TestRunListItem, error) {
	c, err := s.asUser(ctx, u)
	if err != nil {
		return nil, err
	}
	defer c.Release()
	rows, err := c.Query(ctx, `SELECT t.id, t.kind, t.group_id, g.name AS group_name, t.channel_id,
			COALESCE(g.name, NULLIF(ch.display_name, ''), ch.name, '—') AS target,
			t.start_at, t.duration_sec, t.expected,
			(SELECT count(*) FROM test_run_results r WHERE r.run_id = t.id) AS received,
			t.status, t.created_by, t.created_at
		FROM test_runs t
		LEFT JOIN channel_groups g ON g.id = t.group_id
		LEFT JOIN channels ch      ON ch.id = t.channel_id
		WHERE ($1::int IS NULL OR t.group_id = $1)
		  AND (linkmon_role() IN ('', 'big_admin')
		       OR (t.channel_id IS NOT NULL AND linkmon_can_see_channel(t.channel_id))
		       OR (t.group_id IN (SELECT group_id FROM user_scopes WHERE user_id = linkmon_user_id()))
		       OR EXISTS (SELECT 1 FROM unnest(t.target_ids) tid WHERE linkmon_can_see_channel(tid)))
		ORDER BY t.created_at DESC LIMIT $2`, groupID, limit)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[TestRunListItem])
}

func (s *Store) RemoveGroupMember(ctx context.Context, groupID int, channelID int64) error {
	_, err := s.pool.Exec(ctx, `DELETE FROM channel_group_members WHERE group_id = $1 AND channel_id = $2`, groupID, channelID)
	return err
}

func (s *Store) DeleteGroup(ctx context.Context, id int) error {
	tag, err := s.pool.Exec(ctx, `DELETE FROM channel_groups WHERE id = $1`, id)
	if err == nil && tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return err
}
