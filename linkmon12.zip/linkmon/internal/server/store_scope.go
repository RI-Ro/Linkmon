package server

import (
	"context"
	"strconv"

	"github.com/jackc/pgx/v5/pgxpool"
)

// Роли администраторов веб-интерфейса.
const (
	RoleBigAdmin = "big_admin" // видит всё, управляет пользователями и областями видимости
	RoleAdmin    = "admin"     // управляет каналами/группами в пределах своей области
	RoleViewer   = "viewer"    // только просмотр в пределах своей области
)

// scopedConn — соединение из пула с выставленной идентичностью запроса. Пока оно занято,
// RLS-политики и функция linkmon_can_see_channel() видят роль и id текущего пользователя.
// Обязательно освобождать через Release() — переменные сессии сбрасываются перед возвратом в пул.
type scopedConn struct {
	*pgxpool.Conn
}

// asUser берёт соединение и выставляет параметры сессии для RLS. Для nil-пользователя
// (служебный доступ: приём данных, движок алертов) параметры не ставятся — политики
// трактуют пустую роль как служебную и разрешают всё.
func (s *Store) asUser(ctx context.Context, u *AdminUser) (*scopedConn, error) {
	c, err := s.pool.Acquire(ctx)
	if err != nil {
		return nil, err
	}
	if u != nil {
		// set_config принимает text-аргументы, поэтому id передаём строкой (иначе pgx
		// не может закодировать int64 в text-параметр). false — на время сессии соединения.
		if _, err := c.Exec(ctx, `SELECT set_config('linkmon.role', $1, false),
			set_config('linkmon.user_id', $2, false)`, u.Role, strconv.FormatInt(u.ID, 10)); err != nil {
			c.Release()
			return nil, err
		}
	}
	return &scopedConn{c}, nil
}

// Release сбрасывает идентичность и возвращает соединение в пул.
func (c *scopedConn) Release() {
	// RESET гарантирует, что следующий пользователь этого соединения не унаследует область.
	_, _ = c.Conn.Exec(context.Background(), `SELECT set_config('linkmon.role', '', false),
		set_config('linkmon.user_id', '', false)`)
	c.Conn.Release()
}

// canManage — может ли пользователь менять объекты (не viewer).
func canManage(u *AdminUser) bool { return u != nil && (u.Role == RoleBigAdmin || u.Role == RoleAdmin) }

// CanSeeChannel — виден ли канал пользователю (с учётом области видимости RLS).
func (s *Store) CanSeeChannel(ctx context.Context, u *AdminUser, id int64) (bool, error) {
	c, err := s.asUser(ctx, u)
	if err != nil {
		return false, err
	}
	defer c.Release()
	var ok bool
	if err := c.QueryRow(ctx, `SELECT linkmon_can_see_channel($1)`, id).Scan(&ok); err != nil {
		return false, err
	}
	return ok, nil
}

// CanSeeAgent — виден ли агент пользователю (по группам агентов или через видимый канал).
func (s *Store) CanSeeAgent(ctx context.Context, u *AdminUser, id string) (bool, error) {
	c, err := s.asUser(ctx, u)
	if err != nil {
		return false, err
	}
	defer c.Release()
	var ok bool
	if err := c.QueryRow(ctx,
		`SELECT linkmon_can_see_agent($1) OR EXISTS (
			SELECT 1 FROM channels ch WHERE ch.agent_id = $1 AND linkmon_can_see_channel(ch.id))`, id).Scan(&ok); err != nil {
		return false, err
	}
	return ok, nil
}
