package server

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"

	"github.com/example/linkmon/internal/api"
)

// BWTestCreate — запрос на запуск теста пропускной способности между двумя агентами.
type BWTestCreate struct {
	ClientAgent string           `json:"client_agent"` // агент-инициатор нагрузки
	ServerAgent string           `json:"server_agent"` // агент-приёмник
	ServerAddr  string           `json:"server_addr"`  // прямой режим: host:port сервера bwtest
	Via         string           `json:"via"`          // "" | direct | relay — способ соединения
	StartAt     *time.Time       `json:"start_at"`     // отложенный запуск; nil — сразу
	Params      api.BWTestParams `json:"params"`
}

// BWTestView — строка истории тестов пропускной способности для UI.
type BWTestView struct {
	ID          int64          `db:"id" json:"id"`
	Proto       string         `db:"proto" json:"proto"`
	Reverse     bool           `db:"reverse" json:"reverse"`
	Bidir       bool           `db:"bidir" json:"bidir"`
	DurationSec int            `db:"duration_sec" json:"duration_sec"`
	Streams     int            `db:"streams" json:"streams"`
	LengthBytes int            `db:"length_bytes" json:"length_bytes"`
	TargetMbps  *float64       `db:"target_mbps" json:"target_mbps"`
	DSCP        int            `db:"dscp" json:"dscp"`
	ServerAddr  string         `db:"server_addr" json:"server_addr"`
	Status      string         `db:"status" json:"status"`
	Result      map[string]any `db:"result" json:"result"`
	Error       *string        `db:"error" json:"error"`
	CreatedBy   *string        `db:"created_by" json:"created_by"`
	CreatedAt   time.Time      `db:"created_at" json:"created_at"`
	FinishedAt  *time.Time     `db:"finished_at" json:"finished_at"`
	ClientName  *string        `db:"client_name" json:"client_name"`
	ServerName  *string        `db:"server_name" json:"server_name"`
	ClientAgent *string        `db:"client_agent" json:"client_agent"`
	ServerAgent *string        `db:"server_agent" json:"server_agent"`
}

const bwTestSelect = `SELECT id, proto, reverse, bidir, duration_sec, streams, length_bytes, target_mbps,
		dscp, server_addr, status, result, error, created_by, created_at, finished_at,
		client_name, server_name, client_agent, server_agent
	FROM v_bw_tests`

// CreateBWTest сохраняет прогон и запускает его.
// Роль клиента: если ClientAgent задан — команда ставится в очередь этому агенту;
// если пуст — клиентом выступает сам сервер LinkMon (возвращается serverIsClient=true,
// и вызывающий сам прогоняет bwtest.RunClient). Это даёт все топологии:
// агент↔агент, агент↔сервер и сервер↔сервер.
func (s *Store) CreateBWTest(ctx context.Context, c BWTestCreate, relayAddr, createdBy string) (id int64, serverIsClient bool, err error) {
	relayMode := c.Via == "relay"
	if relayMode {
		if c.ClientAgent == "" || c.ServerAgent == "" {
			return 0, false, ErrBadRequest // релей — только между двумя агентами
		}
		if relayAddr == "" {
			return 0, false, ErrBadRequest // ретранслятор не настроен (relay_port/relay_host)
		}
	} else if c.ServerAddr == "" {
		return 0, false, ErrNotFound
	}
	p := c.Params
	if p.Proto != "udp" {
		p.Proto = "tcp"
	}
	if p.DurationSec <= 0 || p.DurationSec > 600 {
		p.DurationSec = 10
	}
	if p.Streams <= 0 || p.Streams > 128 {
		p.Streams = 1
	}
	if p.DSCP < 0 || p.DSCP > 63 {
		p.DSCP = 0
	}
	serverIsClient = c.ClientAgent == ""

	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return 0, false, err
	}
	defer tx.Rollback(ctx)

	var clientAgent any
	if !serverIsClient {
		// Клиент-агент должен быть известным одобренным агентом.
		var ok bool
		err = tx.QueryRow(ctx, `SELECT true FROM agents WHERE id = $1 AND status = 'approved'`, c.ClientAgent).Scan(&ok)
		if errors.Is(err, pgx.ErrNoRows) {
			return 0, false, ErrNotFound
		}
		if err != nil {
			return 0, false, err
		}
		clientAgent = c.ClientAgent
	}

	var serverAgent any
	if c.ServerAgent != "" {
		serverAgent = c.ServerAgent
	}
	var targetMbps any
	if p.TargetMbps > 0 {
		targetMbps = p.TargetMbps
	}
	paramsJSON, _ := json.Marshal(p)
	serverAddrCol := c.ServerAddr
	if relayMode {
		serverAddrCol = "relay:" + relayAddr
		serverIsClient = false // клиентом всегда выступает client_agent
	}

	if err = tx.QueryRow(ctx, `INSERT INTO bw_tests
			(client_agent, server_agent, server_addr, proto, reverse, bidir, duration_sec, streams, length_bytes, target_mbps, params, status, created_by)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 'scheduled', $12)
		RETURNING id`,
		clientAgent, serverAgent, serverAddrCol, p.Proto, p.Reverse, false,
		p.DurationSec, p.Streams, p.LengthBytes, targetMbps, paramsJSON, createdBy).Scan(&id); err != nil {
		return 0, false, err
	}

	start := time.Now()
	if c.StartAt != nil {
		start = *c.StartAt
	}

	if relayMode {
		// Оба агента подключаются к ретранслятору с общим токеном; клиент создаёт нагрузку.
		token, err := relayToken()
		if err != nil {
			return 0, false, err
		}
		cliPayload := api.RunBWTestPayload{RunID: id, StartAt: start, RelayAddr: relayAddr, RelayToken: token, Role: "client", Params: p}
		srvPayload := api.RunBWTestPayload{RunID: id, StartAt: start, RelayAddr: relayAddr, RelayToken: token, Role: "server", Params: p}
		if err = enqueue(ctx, tx, c.ClientAgent, api.CmdRunBWTest, cliPayload); err != nil {
			return 0, false, err
		}
		if err = enqueue(ctx, tx, c.ServerAgent, api.CmdRunBWTest, srvPayload); err != nil {
			return 0, false, err
		}
		return id, false, tx.Commit(ctx)
	}

	if !serverIsClient {
		payload := api.RunBWTestPayload{RunID: id, StartAt: start, ServerAddr: c.ServerAddr, Params: p}
		if err = enqueue(ctx, tx, c.ClientAgent, api.CmdRunBWTest, payload); err != nil {
			return 0, false, err
		}
	}
	return id, serverIsClient, tx.Commit(ctx)
}

// relayToken генерирует 16-байтный токен пары для ретранслятора (hex).
func relayToken() (string, error) {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}

// ListBWTests возвращает историю тестов пропускной способности в области видимости пользователя.
// admin/viewer видят только прогоны, где клиент или сервер — доступный им агент.
func (s *Store) ListBWTests(ctx context.Context, u *AdminUser, limit int) ([]BWTestView, error) {
	if limit <= 0 || limit > 500 {
		limit = 100
	}
	c, err := s.asUser(ctx, u)
	if err != nil {
		return nil, err
	}
	defer c.Release()
	rows, err := c.Query(ctx, bwTestSelect+`
		WHERE linkmon_role() IN ('', 'big_admin')
		   OR (client_agent IS NOT NULL AND linkmon_can_see_agent(client_agent::uuid))
		   OR (server_agent IS NOT NULL AND linkmon_can_see_agent(server_agent::uuid))
		ORDER BY created_at DESC LIMIT $1`, limit)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[BWTestView])
}

// GetBWTest возвращает один прогон.
func (s *Store) GetBWTest(ctx context.Context, id int64) (*BWTestView, error) {
	rows, err := s.pool.Query(ctx, bwTestSelect+` WHERE id = $1`, id)
	if err != nil {
		return nil, err
	}
	v, err := pgx.CollectOneRow(rows, pgx.RowToStructByName[BWTestView])
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, err
	}
	return &v, nil
}

// SaveBWTestResult фиксирует итог теста от клиентского агента.
func (s *Store) SaveBWTestResult(ctx context.Context, agentID string, res api.BWTestResult) error {
	status := "done"
	var resultJSON []byte
	var errMsg any
	if res.Error != "" || res.Result == nil {
		status = "failed"
		if res.Error != "" {
			errMsg = res.Error
		} else {
			errMsg = "нет результата"
		}
	} else {
		resultJSON, _ = json.Marshal(res.Result)
	}
	// Обновляем только свой прогон (client_agent совпадает), чтобы агент не мог править чужие.
	ct, err := s.pool.Exec(ctx, `UPDATE bw_tests
		SET status = $2, result = $3, error = $4, finished_at = now()
		WHERE id = $1 AND client_agent = $5`,
		res.RunID, status, resultJSON, errMsg, agentID)
	if err != nil {
		return err
	}
	if ct.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

// SaveServerBWTestResult фиксирует итог теста, где клиентом выступал сам сервер LinkMon
// (client_agent IS NULL). Обновляет строго такой прогон по id.
func (s *Store) SaveServerBWTestResult(ctx context.Context, id int64, res *api.BWTestResultData, errMsg string) error {
	status := "done"
	var resultJSON []byte
	var errVal any
	if errMsg != "" || res == nil {
		status = "failed"
		if errMsg == "" {
			errMsg = "нет результата"
		}
		errVal = errMsg
	} else {
		resultJSON, _ = json.Marshal(res)
	}
	ct, err := s.pool.Exec(ctx, `UPDATE bw_tests
		SET status = $2, result = $3, error = $4, finished_at = now()
		WHERE id = $1 AND client_agent IS NULL`,
		id, status, resultJSON, errVal)
	if err != nil {
		return err
	}
	if ct.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

// SetBWTestRunning помечает серверный прогон как выполняющийся.
func (s *Store) SetBWTestRunning(ctx context.Context, id int64) {
	_, _ = s.pool.Exec(ctx, `UPDATE bw_tests SET status = 'running' WHERE id = $1 AND status = 'scheduled'`, id)
}

// DeleteBWTest удаляет прогон теста пропускной способности.
func (s *Store) DeleteBWTest(ctx context.Context, id int64) error {
	ct, err := s.pool.Exec(ctx, `DELETE FROM bw_tests WHERE id = $1`, id)
	if err != nil {
		return err
	}
	if ct.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}
