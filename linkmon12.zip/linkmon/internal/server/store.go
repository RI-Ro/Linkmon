package server

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"sort"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/example/linkmon/internal/api"
	"github.com/example/linkmon/migrations"
)

var (
	ErrNotFound   = errors.New("not found")
	ErrBadToken   = errors.New("invalid or expired enrollment token")
	ErrBadRequest = errors.New("bad request")
)

type Store struct{ pool *pgxpool.Pool }

type execer interface {
	Exec(ctx context.Context, sql string, args ...any) (pgconn.CommandTag, error)
}

type queryer interface {
	Query(ctx context.Context, sql string, args ...any) (pgx.Rows, error)
}

func OpenStore(ctx context.Context, url string) (*Store, error) {
	pool, err := pgxpool.New(ctx, url)
	if err != nil {
		return nil, err
	}
	if err := pool.Ping(ctx); err != nil {
		pool.Close()
		return nil, err
	}
	return &Store{pool: pool}, nil
}

func (s *Store) Close()              { s.pool.Close() }
func (s *Store) Pool() *pgxpool.Pool { return s.pool }

// Migrate применяет встроенные SQL-миграции по порядку, каждую в своей транзакции.
func (s *Store) Migrate(ctx context.Context) error {
	if _, err := s.pool.Exec(ctx, `CREATE TABLE IF NOT EXISTS schema_migrations (
		version text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())`); err != nil {
		return err
	}
	entries, err := fs.ReadDir(migrations.FS, ".")
	if err != nil {
		return err
	}
	for _, e := range entries {
		if e.IsDir() || !strings.HasSuffix(e.Name(), ".sql") {
			continue
		}
		var done bool
		if err := s.pool.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM schema_migrations WHERE version = $1)`, e.Name()).Scan(&done); err != nil {
			return err
		}
		if done {
			continue
		}
		body, err := fs.ReadFile(migrations.FS, e.Name())
		if err != nil {
			return err
		}
		tx, err := s.pool.Begin(ctx)
		if err != nil {
			return err
		}
		// Exec без аргументов идёт по simple protocol — можно несколько операторов сразу.
		if _, err := tx.Exec(ctx, string(body)); err != nil {
			_ = tx.Rollback(ctx)
			return fmt.Errorf("migration %s: %w", e.Name(), err)
		}
		if _, err := tx.Exec(ctx, `INSERT INTO schema_migrations (version) VALUES ($1)`, e.Name()); err != nil {
			_ = tx.Rollback(ctx)
			return err
		}
		if err := tx.Commit(ctx); err != nil {
			return err
		}
	}
	return nil
}

// ---------- Агенты ----------

type Agent struct {
	ID, MachineID, Hostname, Status string
	PubKeySHA                       []byte
	CertSerial                      *string
}

const agentCols = `id::text, machine_id, hostname, status, pubkey_sha256, cert_serial`

func scanAgent(row pgx.Row) (*Agent, error) {
	var a Agent
	if err := row.Scan(&a.ID, &a.MachineID, &a.Hostname, &a.Status, &a.PubKeySHA, &a.CertSerial); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, err
	}
	return &a, nil
}

func (s *Store) AgentByID(ctx context.Context, id string) (*Agent, error) {
	return scanAgent(s.pool.QueryRow(ctx, `SELECT `+agentCols+` FROM agents WHERE id = $1`, id))
}

func (s *Store) AgentByMachineID(ctx context.Context, mid string) (*Agent, error) {
	return scanAgent(s.pool.QueryRow(ctx, `SELECT `+agentCols+` FROM agents WHERE machine_id = $1`, mid))
}

func consumeToken(ctx context.Context, tx pgx.Tx, token string) (int, bool, error) {
	if token == "" {
		return 0, false, ErrBadToken
	}
	h := sha256.Sum256([]byte(token))
	var id int
	var auto bool
	err := tx.QueryRow(ctx, `UPDATE enroll_tokens SET uses_left = uses_left - 1
		WHERE token_hash = $1
		  AND (expires_at IS NULL OR expires_at > now())
		  AND (uses_left IS NULL OR uses_left > 0)
		RETURNING id, auto_approve`, h[:]).Scan(&id, &auto)
	if errors.Is(err, pgx.ErrNoRows) {
		return 0, false, ErrBadToken
	}
	return id, auto, err
}

func (s *Store) RegisterAgent(ctx context.Context, r api.EnrollRequest, pubSHA []byte) (*Agent, error) {
	caps, err := json.Marshal(r.Capabilities)
	if err != nil {
		return nil, err
	}
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback(ctx)
	tokID, auto, err := consumeToken(ctx, tx, r.Token)
	if err != nil {
		return nil, err
	}
	status := api.StatusPending
	if auto {
		status = api.StatusApproved
	}
	ifaces, err := json.Marshal(r.Interfaces)
	if err != nil {
		return nil, err
	}
	if len(r.Interfaces) == 0 {
		ifaces = []byte("[]")
	}
	// name: имя из конфига агента, иначе hostname, иначе machine_id. Дальше администратор
	// может переопределить его в интерфейсе — повторная регистрация имя не трогает.
	a, err := scanAgent(tx.QueryRow(ctx, `INSERT INTO agents (machine_id, hostname, name, status, pubkey_sha256, token_id, capabilities, version, interfaces)
		VALUES ($1, $2, COALESCE(NULLIF($8, ''), NULLIF($2, ''), $1), $3, $4, $5, $6, $7, $9) RETURNING `+agentCols,
		r.MachineID, r.Hostname, status, pubSHA, tokID, caps, r.Version, r.Name, ifaces))
	if err != nil {
		return nil, err
	}
	return a, tx.Commit(ctx)
}

// SetAgentAlertMode задаёт режим оповещений агента: all | critical | off.
func (s *Store) SetAgentAlertMode(ctx context.Context, id, mode string) error {
	switch mode {
	case "all", "critical", "off":
	default:
		return ErrBadRequest
	}
	ct, err := s.pool.Exec(ctx, `UPDATE agents SET alert_mode = $2 WHERE id = $1`, id, mode)
	if err != nil {
		return err
	}
	if ct.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

// UpdateInterfaces сохраняет обнаруженные агентом интерфейсы (для настройки каналов с сервера).
func (s *Store) UpdateInterfaces(ctx context.Context, id string, ifaces []api.HostInterface) error {
	b, err := json.Marshal(ifaces)
	if err != nil {
		return err
	}
	if len(ifaces) == 0 {
		b = []byte("[]")
	}
	_, err = s.pool.Exec(ctx, `UPDATE agents SET interfaces = $2, last_seen = now() WHERE id = $1`, id, b)
	return err
}

// AgentBWTestEndpoint подбирает адрес bwtest агента: первый не-loopback IPv4 из его интерфейсов
// плюс порт из capabilities (agent.bwtest_port). Так адрес не вписывается вручную, а берётся с сервера.
// Возвращает "ip:port" или "" если данных недостаточно (тогда стоит использовать релейный режим).
func (s *Store) AgentBWTestEndpoint(ctx context.Context, u *AdminUser, id string) (string, error) {
	c, err := s.asUser(ctx, u)
	if err != nil {
		return "", err
	}
	defer c.Release()
	var ifacesRaw, capsRaw []byte
	err = c.QueryRow(ctx, `SELECT interfaces, capabilities FROM agents
		WHERE id = $1 AND (linkmon_role() IN ('', 'big_admin') OR linkmon_can_see_agent(id)
			OR EXISTS (SELECT 1 FROM channels ch WHERE ch.agent_id = agents.id AND linkmon_can_see_channel(ch.id)))`, id).
		Scan(&ifacesRaw, &capsRaw)
	if errors.Is(err, pgx.ErrNoRows) {
		return "", ErrNotFound
	}
	if err != nil {
		return "", err
	}
	var ifaces []api.HostInterface
	_ = json.Unmarshal(ifacesRaw, &ifaces)
	var caps api.Capabilities
	_ = json.Unmarshal(capsRaw, &caps)
	port := caps.BWTestPort
	if port == 0 {
		port = 5202 // порт слушателя агента по умолчанию
	}
	ip := firstRoutableIPv4(ifaces)
	if ip == "" {
		return "", nil
	}
	return fmt.Sprintf("%s:%d", ip, port), nil
}

// firstRoutableIPv4 выбирает первый не-loopback IPv4 из интерфейсов агента.
func firstRoutableIPv4(ifaces []api.HostInterface) string {
	for _, if_ := range ifaces {
		if if_.Loopback || !if_.Up {
			continue
		}
		for _, a := range if_.Addrs {
			ip := a
			if i := indexByte(ip, '/'); i >= 0 {
				ip = ip[:i]
			}
			if isIPv4(ip) && !isLoopbackIP(ip) {
				return ip
			}
		}
	}
	return ""
}

func indexByte(s string, b byte) int {
	for i := 0; i < len(s); i++ {
		if s[i] == b {
			return i
		}
	}
	return -1
}
func isIPv4(s string) bool {
	dots := 0
	for i := 0; i < len(s); i++ {
		switch {
		case s[i] == '.':
			dots++
		case s[i] >= '0' && s[i] <= '9':
		default:
			return false
		}
	}
	return dots == 3
}
func isLoopbackIP(s string) bool { return len(s) >= 4 && s[:4] == "127." }

// AgentInterfaces возвращает обнаруженные агентом интерфейсы (для UI создания каналов).
func (s *Store) AgentInterfaces(ctx context.Context, u *AdminUser, id string) ([]api.HostInterface, error) {
	c, err := s.asUser(ctx, u)
	if err != nil {
		return nil, err
	}
	defer c.Release()
	var b []byte
	err = c.QueryRow(ctx, `SELECT interfaces FROM agents
		WHERE id = $1 AND (linkmon_role() IN ('', 'big_admin') OR linkmon_can_see_agent(id)
			OR EXISTS (SELECT 1 FROM channels ch WHERE ch.agent_id = agents.id AND linkmon_can_see_channel(ch.id)))`, id).Scan(&b)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, err
	}
	var out []api.HostInterface
	if len(b) > 0 {
		_ = json.Unmarshal(b, &out)
	}
	return out, nil
}

// RegisterAgentOpen регистрирует агента без токена (открытая регистрация): статус pending,
// администратор одобряет вручную. Используется при `agent --servers host:port` без --token.
func (s *Store) RegisterAgentOpen(ctx context.Context, r api.EnrollRequest, pubSHA []byte) (*Agent, error) {
	caps, err := json.Marshal(r.Capabilities)
	if err != nil {
		return nil, err
	}
	ifaces, err := json.Marshal(r.Interfaces)
	if err != nil {
		return nil, err
	}
	if len(r.Interfaces) == 0 {
		ifaces = []byte("[]")
	}
	a, err := scanAgent(s.pool.QueryRow(ctx, `INSERT INTO agents (machine_id, hostname, name, status, pubkey_sha256, capabilities, version, interfaces)
		VALUES ($1, $2, COALESCE(NULLIF($7, ''), NULLIF($2, ''), $1), 'pending', $3, $4, $5, $6) RETURNING `+agentCols,
		r.MachineID, r.Hostname, pubSHA, caps, r.Version, ifaces, r.Name))
	if err != nil {
		return nil, err
	}
	return a, nil
}

// ReKeyAgent — известная машина пришла с новым ключом (переустановка). Требуется валидный токен.
func (s *Store) ReKeyAgent(ctx context.Context, agentID, token string, pubSHA []byte) (*Agent, error) {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback(ctx)
	tokID, auto, err := consumeToken(ctx, tx, token)
	if err != nil {
		return nil, err
	}
	status := api.StatusPending
	if auto {
		status = api.StatusApproved
	}
	a, err := scanAgent(tx.QueryRow(ctx, `UPDATE agents
		SET pubkey_sha256 = $2, token_id = $3, status = $4, cert_serial = NULL, cert_not_after = NULL
		WHERE id = $1 AND status <> 'disabled' RETURNING `+agentCols, agentID, pubSHA, tokID, status))
	if err != nil {
		return nil, err
	}
	return a, tx.Commit(ctx)
}

func (s *Store) UpdateAgentInfo(ctx context.Context, id, hostname, version string, caps api.Capabilities) error {
	b, err := json.Marshal(caps)
	if err != nil {
		return err
	}
	_, err = s.pool.Exec(ctx, `UPDATE agents SET hostname = $2, version = $3, capabilities = $4, last_seen = now() WHERE id = $1`,
		id, hostname, version, b)
	return err
}

// UpdateCapabilities обновляет только capabilities и время последней активности,
// не трогая имя/hostname/версию (их агент присылает при регистрации и heartbeat).
func (s *Store) UpdateCapabilities(ctx context.Context, id string, caps api.Capabilities) error {
	b, err := json.Marshal(caps)
	if err != nil {
		return err
	}
	_, err = s.pool.Exec(ctx, `UPDATE agents SET capabilities = $2, last_seen = now() WHERE id = $1`, id, b)
	return err
}

func (s *Store) SetAgentCert(ctx context.Context, id, serial string, notAfter time.Time, pubSHA []byte) error {
	_, err := s.pool.Exec(ctx, `UPDATE agents SET cert_serial = $2, cert_not_after = $3, pubkey_sha256 = $4 WHERE id = $1`,
		id, serial, notAfter, pubSHA)
	return err
}

func (s *Store) Heartbeat(ctx context.Context, id string, hb api.Heartbeat) error {
	_, err := s.pool.Exec(ctx, `UPDATE agents SET last_seen = now(), version = $2, clock_synced = $3, clock_err_us = $4 WHERE id = $1`,
		id, hb.Version, hb.ClockSynced, hb.ClockErrUS)
	return err
}

func (s *Store) SetAgentStatus(ctx context.Context, id, status string) error {
	tag, err := s.pool.Exec(ctx, `UPDATE agents SET status = $2 WHERE id = $1`, id, status)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

// SetAgentName задаёт понятное имя агента (пустое — сбрасывает на hostname/machine_id).
func (s *Store) SetAgentName(ctx context.Context, id, name string) error {
	tag, err := s.pool.Exec(ctx, `UPDATE agents SET
		name = COALESCE(NULLIF($2, ''), NULLIF(hostname, ''), machine_id) WHERE id = $1`, id, name)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

// SetAgentDisabled выключает/включает агента. Выключенный агент не считается «на связи»
// и его каналы не переопрашиваются; данные и история сохраняются.
func (s *Store) SetAgentDisabled(ctx context.Context, id string, disabled bool) error {
	status := api.StatusApproved
	if disabled {
		status = "disabled"
	}
	return s.SetAgentStatus(ctx, id, status)
}

// DeleteAgent полностью удаляет агента вместе с его каналами и измерениями (каскадом).
func (s *Store) DeleteAgent(ctx context.Context, id string) error {
	tag, err := s.pool.Exec(ctx, `DELETE FROM agents WHERE id = $1`, id)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

// ---------- Каналы ----------

var dscpNames = map[int]string{0: "BE", 8: "CS1", 10: "AF11", 12: "AF12", 14: "AF13", 16: "CS2", 18: "AF21",
	20: "AF22", 22: "AF23", 24: "CS3", 26: "AF31", 28: "AF32", 30: "AF33", 32: "CS4", 34: "AF41", 36: "AF42",
	38: "AF43", 40: "CS5", 44: "VA", 46: "EF", 48: "CS6", 56: "CS7"}

func dscpName(d int) string {
	if n, ok := dscpNames[d]; ok {
		return n
	}
	return fmt.Sprintf("DSCP%d", d)
}

func newSessionCredentials() (int64, []byte, error) {
	b := make([]byte, 8+32)
	if _, err := rand.Read(b); err != nil {
		return 0, nil, err
	}
	id := int64(binary.BigEndian.Uint64(b[:8]) & 0x7fffffffffffffff)
	if id == 0 {
		id = 1
	}
	return id, b[8:], nil
}

// ProvisionChannels создаёт каналы (интерфейс × цель × DSCP) из capabilities агента.
// Идемпотентна: существующие каналы не трогает. Новые каналы попадают в группу из токена.
func (s *Store) ProvisionChannels(ctx context.Context, agentID string) (int, error) {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return 0, err
	}
	defer tx.Rollback(ctx)

	var hostname string
	var capsRaw []byte
	var groupID *int
	if err := tx.QueryRow(ctx, `SELECT a.hostname, a.capabilities, t.group_id
		FROM agents a LEFT JOIN enroll_tokens t ON t.id = a.token_id WHERE a.id = $1`, agentID).
		Scan(&hostname, &capsRaw, &groupID); err != nil {
		return 0, err
	}
	var caps api.Capabilities
	if err := json.Unmarshal(capsRaw, &caps); err != nil {
		return 0, err
	}
	created := 0
	var seen []int64        // id всех каналов, присутствующих в текущих capabilities
	monitored := []string{} // интерфейсы с включённым мониторингом загрузки
	for _, ifc := range caps.Interfaces {
		// Мониторинг загрузки интерфейса заводится один раз на (agent, interface),
		// независимо от числа целей и классов DSCP на нём. Скорость/интервал обновляются,
		// если администратор поменял их в конфиге агента.
		if ifc.Monitor {
			monitored = append(monitored, ifc.Name)
			var speed *int64
			if ifc.SpeedBits > 0 {
				speed = &ifc.SpeedBits
			}
			interval := ifc.IntervalSec
			if interval == 0 {
				interval = 60
			}
			if _, err := tx.Exec(ctx, `INSERT INTO iface_monitors (agent_id, interface, speed_bits, interval_sec)
				VALUES ($1, $2, $3, $4)
				ON CONFLICT (agent_id, interface)
				DO UPDATE SET speed_bits = EXCLUDED.speed_bits, interval_sec = EXCLUDED.interval_sec, enabled = true`,
				agentID, ifc.Name, speed, interval); err != nil {
				return 0, err
			}
		}
		for _, t := range ifc.Targets {
			port := t.Port
			if port == 0 {
				port = api.DefaultReflectorPort
			}
			var rid int
			if err := tx.QueryRow(ctx, `INSERT INTO reflectors (name, address, port) VALUES ($1, $2::inet, $3)
				ON CONFLICT (address, port) DO UPDATE SET port = EXCLUDED.port RETURNING id`,
				t.Name, t.Address, port).Scan(&rid); err != nil {
				return 0, err
			}
			for _, d := range ifc.DSCP {
				sid, key, err := newSessionCredentials()
				if err != nil {
					return 0, err
				}
				name := fmt.Sprintf("%s/%s → %s [%s]", hostname, ifc.Name, t.Name, dscpName(d))
				// Канал есть → обновляем авто-имя, source_ip, снимаем stale и отмечаем время
				// синхронизации конфигурации. Канал новый → создаём. inserted различает случаи.
				var chID int64
				var inserted bool
				err = tx.QueryRow(ctx, `INSERT INTO channels
					(agent_id, interface, source_ip, reflector_id, dscp, name, session_id, session_key, twamp)
					VALUES ($1, $2, NULLIF($3, '')::inet, $4, $5, $6, $7, $8, $9)
					ON CONFLICT (agent_id, interface, reflector_id, dscp) DO UPDATE
						SET name = EXCLUDED.name,
						    source_ip = EXCLUDED.source_ip,
						    twamp = EXCLUDED.twamp,
						    stale = false,
						    config_updated_at = now()
					RETURNING id, (xmax = 0)`,
					agentID, ifc.Name, ifc.Source, rid, d, name, sid, key, ifc.TWAMP).Scan(&chID, &inserted)
				if err != nil {
					return 0, err
				}
				seen = append(seen, chID)
				if inserted {
					created++
					if groupID != nil {
						if _, err := tx.Exec(ctx, `INSERT INTO channel_group_members (group_id, channel_id)
							VALUES ($1, $2) ON CONFLICT DO NOTHING`, *groupID, chID); err != nil {
							return 0, err
						}
					}
				}
			}
		}
	}
	// Каналы, которых больше нет в capabilities, помечаем как stale (историю не теряем).
	// Server-authored каналы (заведённые с сервера) не трогаем — они не приходят из capabilities.
	if _, err := tx.Exec(ctx, `UPDATE channels SET stale = true
		WHERE agent_id = $1 AND NOT (id = ANY($2::bigint[])) AND NOT stale AND NOT server_authored`, agentID, seen); err != nil {
		return 0, err
	}
	// Мониторы, которых больше нет в capabilities, отключаем — но только capabilities-managed,
	// не server-authored (иначе монитор скорости для --servers агента гас бы после reconcile).
	if _, err := tx.Exec(ctx, `UPDATE iface_monitors SET enabled = false
		WHERE agent_id = $1 AND NOT (interface = ANY($2::text[])) AND enabled AND NOT server_authored`, agentID, monitored); err != nil {
		return 0, err
	}
	return created, tx.Commit(ctx)
}

func (s *Store) AgentConfig(ctx context.Context, agentID string) (api.AgentConfig, error) {
	var cfg api.AgentConfig
	rows, err := s.pool.Query(ctx, `SELECT c.id, c.session_id, c.session_key, c.interface,
			COALESCE(host(c.source_ip), ''), host(r.address), r.port, c.dscp,
			p.pps, p.packet_size, p.poisson, p.interval_sec, c.twamp
		FROM channels c
		JOIN reflectors r ON r.id = c.reflector_id
		JOIN test_profiles p ON p.id = c.profile_id
		WHERE c.agent_id = $1 AND c.enabled
		ORDER BY c.id`, agentID)
	if err != nil {
		return cfg, err
	}
	defer rows.Close()
	for rows.Next() {
		var c api.ChannelConfig
		var sid int64
		if err := rows.Scan(&c.ChannelID, &sid, &c.SessionKey, &c.Interface, &c.SourceIP, &c.ReflectorAddr,
			&c.ReflectorPort, &c.DSCP, &c.PPS, &c.PacketSize, &c.Poisson, &c.IntervalSec, &c.TWAMP); err != nil {
			return cfg, err
		}
		c.SessionID = uint64(sid)
		cfg.Channels = append(cfg.Channels, c)
	}
	if err := rows.Err(); err != nil {
		return cfg, err
	}

	mrows, err := s.pool.Query(ctx, `SELECT interface, COALESCE(speed_bits, 0), interval_sec
		FROM iface_monitors WHERE agent_id = $1 AND enabled ORDER BY interface`, agentID)
	if err != nil {
		return cfg, err
	}
	defer mrows.Close()
	for mrows.Next() {
		var m api.IfaceMonitor
		if err := mrows.Scan(&m.Interface, &m.SpeedBits, &m.IntervalSec); err != nil {
			return cfg, err
		}
		cfg.Monitors = append(cfg.Monitors, m)
	}
	if err := mrows.Err(); err != nil {
		return cfg, err
	}

	// Ревизия покрывает и каналы, и мониторы: любое изменение заставит агент перечитать конфиг.
	b, _ := json.Marshal(struct {
		C []api.ChannelConfig
		M []api.IfaceMonitor
	}{cfg.Channels, cfg.Monitors})
	h := sha256.Sum256(b)
	cfg.Revision = fmt.Sprintf("%x", h[:8])
	return cfg, nil
}

func channelSet(ctx context.Context, q queryer, agentID string) (map[int64]bool, error) {
	rows, err := q.Query(ctx, `SELECT id FROM channels WHERE agent_id = $1`, agentID)
	if err != nil {
		return nil, err
	}
	ids, err := pgx.CollectRows(rows, pgx.RowTo[int64])
	if err != nil {
		return nil, err
	}
	set := make(map[int64]bool, len(ids))
	for _, id := range ids {
		set[id] = true
	}
	return set, nil
}

// ---------- Приём результатов ----------

const upsertAgentSQL = `INSERT INTO measurements (ts, channel_id, interval_sec, sent, received, dup, reordered,
	rtt_min, rtt_avg, rtt_p50, rtt_p95, rtt_p99, rtt_max,
	fwd_delay_min, fwd_delay_avg, fwd_delay_p95, fwd_delay_max, fwd_jitter,
	bwd_delay_min, bwd_delay_avg, bwd_delay_p95, bwd_delay_max, bwd_jitter,
	fwd_dscp_seen, bwd_dscp_seen, fwd_remarked, bwd_remarked, mos, oneway_valid, rtt_q)
VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30)
ON CONFLICT (channel_id, ts) DO UPDATE SET
	interval_sec = EXCLUDED.interval_sec, sent = EXCLUDED.sent, received = EXCLUDED.received,
	dup = EXCLUDED.dup, reordered = EXCLUDED.reordered,
	rtt_min = EXCLUDED.rtt_min, rtt_avg = EXCLUDED.rtt_avg, rtt_p50 = EXCLUDED.rtt_p50,
	rtt_p95 = EXCLUDED.rtt_p95, rtt_p99 = EXCLUDED.rtt_p99, rtt_max = EXCLUDED.rtt_max,
	fwd_delay_min = EXCLUDED.fwd_delay_min, fwd_delay_avg = EXCLUDED.fwd_delay_avg,
	fwd_delay_p95 = EXCLUDED.fwd_delay_p95, fwd_delay_max = EXCLUDED.fwd_delay_max, fwd_jitter = EXCLUDED.fwd_jitter,
	bwd_delay_min = EXCLUDED.bwd_delay_min, bwd_delay_avg = EXCLUDED.bwd_delay_avg,
	bwd_delay_p95 = EXCLUDED.bwd_delay_p95, bwd_delay_max = EXCLUDED.bwd_delay_max, bwd_jitter = EXCLUDED.bwd_jitter,
	fwd_dscp_seen = EXCLUDED.fwd_dscp_seen, bwd_dscp_seen = EXCLUDED.bwd_dscp_seen,
	fwd_remarked = EXCLUDED.fwd_remarked, bwd_remarked = EXCLUDED.bwd_remarked,
	mos = EXCLUDED.mos, oneway_valid = EXCLUDED.oneway_valid, rtt_q = EXCLUDED.rtt_q`

func sumVals(s *api.Summary) (mn, avg, p50, p95, p99, mx any) {
	if s == nil {
		return nil, nil, nil, nil, nil, nil
	}
	return s.Min, s.Avg, s.P50, s.P95, s.P99, s.Max
}

func nullNeg(v int) any {
	if v < 0 {
		return nil
	}
	return v
}

func agentRowArgs(iv api.Interval, oneWay bool) []any {
	rMin, rAvg, rP50, rP95, rP99, rMax := sumVals(iv.RTT)
	fMin, fAvg, _, fP95, _, fMax := sumVals(iv.Fwd)
	bMin, bAvg, _, bP95, _, bMax := sumVals(iv.Bwd)
	var fj, bj, mos, q any
	if iv.Received >= 2 {
		fj, bj = iv.FwdJitter, iv.BwdJitter
	}
	if iv.Received > 0 {
		mos = iv.MOS
	}
	if len(iv.RTTQuantiles) > 0 {
		q = iv.RTTQuantiles
	}
	return []any{iv.TS, iv.ChannelID, iv.Seconds, iv.Sent, iv.Received, iv.Duplicates, iv.Reordered,
		rMin, rAvg, rP50, rP95, rP99, rMax,
		fMin, fAvg, fP95, fMax, fj,
		bMin, bAvg, bP95, bMax, bj,
		nullNeg(iv.FwdDSCPSeen), nullNeg(iv.BwdDSCPSeen), iv.FwdRemarked, iv.BwdRemarked, mos,
		iv.OneWayValid && oneWay, q}
}

// IngestBatch идемпотентно сохраняет батч агента. Ack отправляется только после COMMIT.
func (s *Store) IngestBatch(ctx context.Context, agentID string, b api.ResultBatch, serverClockOK bool) (bool, error) {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return false, err
	}
	defer tx.Rollback(ctx)

	tag, err := tx.Exec(ctx, `INSERT INTO ingested_batches (agent_id, batch_seq, intervals) VALUES ($1, $2, $3)
		ON CONFLICT DO NOTHING`, agentID, int64(b.Seq), len(b.Intervals))
	if err != nil {
		return false, err
	}
	if tag.RowsAffected() == 0 {
		return true, tx.Commit(ctx) // уже принят ранее, ack потерялся по дороге
	}
	owned, err := channelSet(ctx, tx, agentID)
	if err != nil {
		return false, err
	}
	batch := &pgx.Batch{}
	for _, iv := range b.Intervals {
		if owned[iv.ChannelID] {
			batch.Queue(upsertAgentSQL, agentRowArgs(iv, serverClockOK)...)
		}
	}

	if len(b.IfaceLoads) > 0 {
		monitors, err := monitorSet(ctx, tx, agentID)
		if err != nil {
			return false, err
		}
		for _, ld := range b.IfaceLoads {
			mid, ok := monitors[ld.Interface]
			if !ok {
				continue // интерфейс не под мониторингом на сервере — игнорируем
			}
			batch.Queue(upsertLoadSQL, loadRowArgs(mid, ld)...)
		}
	}

	if batch.Len() > 0 {
		if err := tx.SendBatch(ctx, batch).Close(); err != nil {
			return false, err
		}
	}
	return false, tx.Commit(ctx)
}

// monitorSet — карта «интерфейс → monitor_id» для агента.
func monitorSet(ctx context.Context, q queryer, agentID string) (map[string]int64, error) {
	rows, err := q.Query(ctx, `SELECT interface, id FROM iface_monitors WHERE agent_id = $1`, agentID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := map[string]int64{}
	for rows.Next() {
		var iface string
		var id int64
		if err := rows.Scan(&iface, &id); err != nil {
			return nil, err
		}
		out[iface] = id
	}
	return out, rows.Err()
}

const upsertLoadSQL = `INSERT INTO iface_load (ts, monitor_id, interval_sec, speed_bits,
	rx_bytes, tx_bytes, rx_packets, tx_packets, rx_bps, tx_bps, rx_pps, tx_pps,
	rx_util_pct, tx_util_pct, rx_errors, tx_errors, rx_drops, tx_drops)
VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18)
ON CONFLICT (monitor_id, ts) DO UPDATE SET
	interval_sec = EXCLUDED.interval_sec, speed_bits = EXCLUDED.speed_bits,
	rx_bytes = EXCLUDED.rx_bytes, tx_bytes = EXCLUDED.tx_bytes,
	rx_packets = EXCLUDED.rx_packets, tx_packets = EXCLUDED.tx_packets,
	rx_bps = EXCLUDED.rx_bps, tx_bps = EXCLUDED.tx_bps,
	rx_pps = EXCLUDED.rx_pps, tx_pps = EXCLUDED.tx_pps,
	rx_util_pct = EXCLUDED.rx_util_pct, tx_util_pct = EXCLUDED.tx_util_pct,
	rx_errors = EXCLUDED.rx_errors, tx_errors = EXCLUDED.tx_errors,
	rx_drops = EXCLUDED.rx_drops, tx_drops = EXCLUDED.tx_drops`

func loadRowArgs(mid int64, ld api.IfaceLoad) []any {
	var speed any
	if ld.SpeedBits > 0 {
		speed = ld.SpeedBits
	}
	return []any{ld.TS, mid, ld.Seconds, speed,
		ld.RxBytes, ld.TxBytes, ld.RxPackets, ld.TxPackets, ld.RxBps, ld.TxBps, ld.RxPps, ld.TxPps,
		ld.RxUtilPct, ld.TxUtilPct, ld.RxErrors, ld.TxErrors, ld.RxDrops, ld.TxDrops}
}

// ---------- Рефлектор ----------

type ReflectorSession struct {
	SessionID uint64
	Key       []byte
	ChannelID int64
	DSCP      int
	Width     time.Duration
}

func (s *Store) ReflectorSessions(ctx context.Context) ([]ReflectorSession, error) {
	rows, err := s.pool.Query(ctx, `SELECT c.session_id, c.session_key, c.id, c.dscp, p.interval_sec
		FROM channels c
		JOIN agents a ON a.id = c.agent_id
		JOIN test_profiles p ON p.id = c.profile_id
		WHERE c.enabled AND a.status = 'approved'`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []ReflectorSession
	for rows.Next() {
		var r ReflectorSession
		var sid int64
		var sec int
		if err := rows.Scan(&sid, &r.Key, &r.ChannelID, &r.DSCP, &sec); err != nil {
			return nil, err
		}
		r.SessionID, r.Width = uint64(sid), time.Duration(sec)*time.Second
		out = append(out, r)
	}
	return out, rows.Err()
}

type ServerStat struct {
	ChannelID   int64
	TS          time.Time
	IntervalSec int
	Rx, Dup     int
	DSCPSeen    int
	Remarked    int
}

// UpsertServerStats пишет «серверную половину» строки measurements: сколько пакетов
// дошло до рефлектора. Из неё и данных агента view вычисляет потери по направлениям.
func (s *Store) UpsertServerStats(ctx context.Context, stats []ServerStat) error {
	b := &pgx.Batch{}
	for _, st := range stats {
		b.Queue(`INSERT INTO measurements (ts, channel_id, interval_sec, srv_rx, srv_dup, srv_dscp_seen, srv_remarked)
			VALUES ($1, $2, $3, $4, $5, $6, $7)
			ON CONFLICT (channel_id, ts) DO UPDATE SET srv_rx = EXCLUDED.srv_rx, srv_dup = EXCLUDED.srv_dup,
				srv_dscp_seen = EXCLUDED.srv_dscp_seen, srv_remarked = EXCLUDED.srv_remarked`,
			st.TS, st.ChannelID, st.IntervalSec, st.Rx, st.Dup, nullNeg(st.DSCPSeen), st.Remarked)
	}
	return s.pool.SendBatch(ctx, b).Close()
}

// ---------- Команды ----------

// enqueue кладёт команду в очередь и будит long-poll агента через NOTIFY (доставится при COMMIT).
func enqueue(ctx context.Context, q execer, agentID, kind string, payload any) error {
	b, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	_, err = q.Exec(ctx, `WITH ins AS (
			INSERT INTO agent_commands (agent_id, kind, payload) VALUES ($1, $2, $3) RETURNING agent_id)
		SELECT pg_notify('agent_commands', agent_id::text) FROM ins`, agentID, kind, b)
	return err
}

func (s *Store) EnqueueCommand(ctx context.Context, agentID, kind string, payload any) error {
	return enqueue(ctx, s.pool, agentID, kind, payload)
}

func (s *Store) FetchCommands(ctx context.Context, agentID string) ([]api.Command, error) {
	rows, err := s.pool.Query(ctx, `UPDATE agent_commands SET delivered_at = now()
		WHERE id IN (SELECT id FROM agent_commands
			WHERE agent_id = $1 AND delivered_at IS NULL
			ORDER BY id LIMIT 50 FOR UPDATE SKIP LOCKED)
		RETURNING id, kind, payload`, agentID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []api.Command
	for rows.Next() {
		var c api.Command
		var p []byte
		if err := rows.Scan(&c.ID, &c.Kind, &p); err != nil {
			return nil, err
		}
		c.Payload = p
		out = append(out, c)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out, rows.Err()
}

func (s *Store) SaveTestResult(ctx context.Context, agentID string, res api.TestResult) error {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	owned, err := channelSet(ctx, tx, agentID)
	if err != nil {
		return err
	}
	for _, iv := range res.Results {
		if !owned[iv.ChannelID] {
			continue
		}
		b, _ := json.Marshal(iv)
		if _, err := tx.Exec(ctx, `INSERT INTO test_run_results (run_id, channel_id, result) VALUES ($1, $2, $3)
			ON CONFLICT (run_id, channel_id) DO UPDATE SET result = EXCLUDED.result, error = NULL, received_at = now()`,
			res.RunID, iv.ChannelID, b); err != nil {
			return err
		}
	}
	for id, msg := range res.Errors {
		if !owned[id] {
			continue
		}
		if _, err := tx.Exec(ctx, `INSERT INTO test_run_results (run_id, channel_id, error) VALUES ($1, $2, $3)
			ON CONFLICT (run_id, channel_id) DO UPDATE SET error = EXCLUDED.error, received_at = now()`,
			res.RunID, id, msg); err != nil {
			return err
		}
	}
	if _, err := tx.Exec(ctx, `UPDATE test_runs SET status = CASE
			WHEN (SELECT count(*) FROM test_run_results WHERE run_id = $1) >= expected THEN 'done' ELSE 'running' END
		WHERE id = $1`, res.RunID); err != nil {
		return err
	}
	return tx.Commit(ctx)
}
