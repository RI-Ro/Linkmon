package server

import (
	"bytes"
	"crypto/sha256"
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"strconv"
	"time"

	"github.com/example/linkmon/internal/api"
	"github.com/example/linkmon/internal/clock"
)

const agentCertValidity = 365 * 24 * time.Hour

type Server struct {
	cfg   *Config
	store *Store
	ca    *CA
	hub   *Hub
	clock *clock.Monitor
	log   *slog.Logger
}

func New(cfg *Config, st *Store, ca *CA, hub *Hub, clk *clock.Monitor, log *slog.Logger) *Server {
	return &Server{cfg: cfg, store: st, ca: ca, hub: hub, clock: clk, log: log}
}

type agentHandler func(http.ResponseWriter, *http.Request, *Agent)

func (s *Server) AgentHandler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /v1/enroll", s.handleEnroll)
	mux.Handle("POST /v1/agent/renew", s.agentAuth(s.handleRenew))
	mux.Handle("GET /v1/agent/config", s.agentAuth(s.handleConfig))
	mux.Handle("POST /v1/agent/results", s.agentAuth(s.handleResults))
	mux.Handle("GET /v1/agent/commands", s.agentAuth(s.handleCommands))
	mux.Handle("POST /v1/agent/heartbeat", s.agentAuth(s.handleHeartbeat))
	mux.Handle("POST /v1/agent/test-results", s.agentAuth(s.handleTestResults))
	mux.Handle("POST /v1/agent/bwtest-results", s.agentAuth(s.handleBWTestResults))
	mux.Handle("POST /v1/agent/capabilities", s.agentAuth(s.handleCapabilities))
	mux.Handle("POST /v1/agent/interfaces", s.agentAuth(s.handleInterfaces))
	// Публичный CA этого сервера — для провижининга агента по `--servers host:port`.
	mux.HandleFunc("GET /v1/ca", s.handleCA)
	return mux
}

func (s *Server) handleCA(w http.ResponseWriter, _ *http.Request) {
	w.Header().Set("Content-Type", "application/x-pem-file")
	_, _ = w.Write(s.ca.CertPEM())
}

func (s *Server) handleInterfaces(w http.ResponseWriter, r *http.Request, a *Agent) {
	var rep api.InterfacesReport
	if err := decodeJSON(r, &rep, 1<<20); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := s.store.UpdateInterfaces(r.Context(), a.ID, rep.Interfaces); err != nil {
		httpError(w, http.StatusInternalServerError, "save failed")
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// agentAuth: цепочку сертификата уже проверил TLS (ClientCAs), здесь — статус агента и отзыв по серийнику.
func (s *Server) agentAuth(h agentHandler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.TLS == nil || len(r.TLS.PeerCertificates) == 0 {
			httpError(w, http.StatusUnauthorized, "client certificate required")
			return
		}
		cert := r.TLS.PeerCertificates[0]
		a, err := s.store.AgentByID(r.Context(), cert.Subject.CommonName)
		if err != nil {
			httpError(w, http.StatusUnauthorized, "unknown agent")
			return
		}
		if a.Status != api.StatusApproved || a.CertSerial == nil || *a.CertSerial != cert.SerialNumber.Text(16) {
			httpError(w, http.StatusForbidden, "agent is not approved or certificate revoked")
			return
		}
		h(w, r, a)
	})
}

func parseCSR(p string) (*x509.CertificateRequest, []byte, error) {
	blk, _ := pem.Decode([]byte(p))
	if blk == nil || blk.Type != "CERTIFICATE REQUEST" {
		return nil, nil, errors.New("invalid CSR PEM")
	}
	csr, err := x509.ParseCertificateRequest(blk.Bytes)
	if err != nil {
		return nil, nil, err
	}
	if err := csr.CheckSignature(); err != nil { // доказательство владения ключом
		return nil, nil, fmt.Errorf("CSR signature: %w", err)
	}
	der, err := x509.MarshalPKIXPublicKey(csr.PublicKey)
	if err != nil {
		return nil, nil, err
	}
	sum := sha256.Sum256(der)
	return csr, sum[:], nil
}

func (s *Server) handleEnroll(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	var req api.EnrollRequest
	if err := decodeJSON(r, &req, 1<<20); err != nil || req.MachineID == "" {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	csr, pubSHA, err := parseCSR(req.CSRPEM)
	if err != nil {
		httpError(w, http.StatusBadRequest, err.Error())
		return
	}
	a, err := s.store.AgentByMachineID(ctx, req.MachineID)
	switch {
	case errors.Is(err, ErrNotFound):
		a, err = s.store.RegisterAgent(ctx, req, pubSHA)
		if errors.Is(err, ErrBadToken) && req.Token == "" && s.cfg.AllowOpenEnroll {
			// Открытая регистрация без токена: агент уходит в pending, одобрит администратор.
			a, err = s.store.RegisterAgentOpen(ctx, req, pubSHA)
			if err == nil {
				s.log.Info("agent registered (open enroll, pending)", "agent_id", a.ID, "hostname", req.Hostname)
			}
		} else if errors.Is(err, ErrBadToken) {
			httpError(w, http.StatusForbidden, err.Error())
			return
		}
		if err == nil {
			s.log.Info("agent registered", "agent_id", a.ID, "hostname", req.Hostname, "status", a.Status)
		}
	case err == nil:
		if !bytes.Equal(a.PubKeySHA, pubSHA) {
			a, err = s.store.ReKeyAgent(ctx, a.ID, req.Token, pubSHA)
			if errors.Is(err, ErrBadToken) || errors.Is(err, ErrNotFound) {
				httpError(w, http.StatusForbidden, "known machine with a new key: valid token required")
				return
			}
		}
		if err == nil {
			err = s.store.UpdateAgentInfo(ctx, a.ID, req.Hostname, req.Version, req.Capabilities)
		}
	}
	if err != nil {
		s.log.Error("enroll", "err", err)
		httpError(w, http.StatusInternalServerError, "enroll failed")
		return
	}

	switch a.Status {
	case api.StatusApproved:
		if _, err := s.store.ProvisionChannels(ctx, a.ID); err != nil {
			s.log.Error("provision channels", "agent_id", a.ID, "err", err)
			httpError(w, http.StatusInternalServerError, "provision failed")
			return
		}
		certPEM, serial, notAfter, err := s.ca.SignAgent(csr, a.ID, agentCertValidity)
		if err == nil {
			err = s.store.SetAgentCert(ctx, a.ID, serial, notAfter, pubSHA)
		}
		if err != nil {
			s.log.Error("sign agent cert", "err", err)
			httpError(w, http.StatusInternalServerError, "sign failed")
			return
		}
		writeJSON(w, http.StatusOK, api.EnrollResponse{AgentID: a.ID, Status: api.StatusApproved, CertPEM: string(certPEM)})
	case api.StatusPending:
		writeJSON(w, http.StatusAccepted, api.EnrollResponse{AgentID: a.ID, Status: api.StatusPending, RetryAfterSec: 30})
	default:
		writeJSON(w, http.StatusForbidden, api.EnrollResponse{Status: a.Status})
	}
}

func (s *Server) handleRenew(w http.ResponseWriter, r *http.Request, a *Agent) {
	var req api.EnrollRequest
	if err := decodeJSON(r, &req, 1<<20); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	csr, pubSHA, err := parseCSR(req.CSRPEM)
	if err != nil {
		httpError(w, http.StatusBadRequest, err.Error())
		return
	}
	certPEM, serial, notAfter, err := s.ca.SignAgent(csr, a.ID, agentCertValidity)
	if err == nil {
		err = s.store.SetAgentCert(r.Context(), a.ID, serial, notAfter, pubSHA)
	}
	if err != nil {
		httpError(w, http.StatusInternalServerError, "renew failed")
		return
	}
	writeJSON(w, http.StatusOK, api.EnrollResponse{AgentID: a.ID, Status: api.StatusApproved, CertPEM: string(certPEM)})
}

func (s *Server) handleConfig(w http.ResponseWriter, r *http.Request, a *Agent) {
	cfg, err := s.store.AgentConfig(r.Context(), a.ID)
	if err != nil {
		httpError(w, http.StatusInternalServerError, "config failed")
		return
	}
	writeJSON(w, http.StatusOK, cfg)
}

// handleCapabilities принимает актуальные capabilities агента и синхронизирует каналы:
// заводит новые (интерфейс/DSCP/цель), обновляет параметры мониторов (скорость/интервал),
// помечает исчезнувшие каналы как stale. Так правки конфига агента доходят без переустановки.
func (s *Server) handleCapabilities(w http.ResponseWriter, r *http.Request, a *Agent) {
	var caps api.Capabilities
	if err := decodeJSON(r, &caps, 1<<20); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := s.store.UpdateCapabilities(r.Context(), a.ID, caps); err != nil {
		s.log.Error("update capabilities", "agent_id", a.ID, "err", err)
		httpError(w, http.StatusInternalServerError, "update failed")
		return
	}
	if _, err := s.store.ProvisionChannels(r.Context(), a.ID); err != nil {
		s.log.Error("reconcile channels", "agent_id", a.ID, "err", err)
		httpError(w, http.StatusInternalServerError, "reconcile failed")
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) handleResults(w http.ResponseWriter, r *http.Request, a *Agent) {
	var b api.ResultBatch
	if err := decodeJSON(r, &b, 32<<20); err != nil {
		httpError(w, http.StatusBadRequest, err.Error())
		return
	}
	dup, err := s.store.IngestBatch(r.Context(), a.ID, b, s.clock.OneWayOK())
	if err != nil {
		s.log.Error("ingest", "agent_id", a.ID, "batch", b.Seq, "err", err)
		httpError(w, http.StatusInternalServerError, "ingest failed")
		return
	}
	writeJSON(w, http.StatusOK, api.Ack{Seq: b.Seq, Duplicate: dup})
}

// handleCommands — long-poll: отвечает сразу, если есть команды, иначе ждёт NOTIFY или таймаута.
func (s *Server) handleCommands(w http.ResponseWriter, r *http.Request, a *Agent) {
	wait := 30 * time.Second
	if v, err := strconv.Atoi(r.URL.Query().Get("wait")); err == nil && v >= 0 && v <= 60 {
		wait = time.Duration(v) * time.Second
	}
	sig, unsub := s.hub.Subscribe(a.ID) // подписка до выборки — чтобы не потерять NOTIFY между ними
	defer unsub()
	deadline := time.NewTimer(wait)
	defer deadline.Stop()
	for {
		cmds, err := s.store.FetchCommands(r.Context(), a.ID)
		if err != nil {
			httpError(w, http.StatusInternalServerError, "commands failed")
			return
		}
		if len(cmds) > 0 {
			writeJSON(w, http.StatusOK, cmds)
			return
		}
		select {
		case <-sig:
		case <-deadline.C:
			writeJSON(w, http.StatusOK, []api.Command{})
			return
		case <-r.Context().Done():
			return
		}
	}
}

func (s *Server) handleHeartbeat(w http.ResponseWriter, r *http.Request, a *Agent) {
	var hb api.Heartbeat
	if err := decodeJSON(r, &hb, 64<<10); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := s.store.Heartbeat(r.Context(), a.ID, hb); err != nil {
		httpError(w, http.StatusInternalServerError, "heartbeat failed")
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) handleTestResults(w http.ResponseWriter, r *http.Request, a *Agent) {
	var res api.TestResult
	if err := decodeJSON(r, &res, 8<<20); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := s.store.SaveTestResult(r.Context(), a.ID, res); err != nil {
		s.log.Error("test result", "agent_id", a.ID, "run_id", res.RunID, "err", err)
		httpError(w, http.StatusInternalServerError, "save failed")
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) handleBWTestResults(w http.ResponseWriter, r *http.Request, a *Agent) {
	var res api.BWTestResult
	if err := decodeJSON(r, &res, 1<<20); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := s.store.SaveBWTestResult(r.Context(), a.ID, res); err != nil {
		s.log.Error("bwtest result", "agent_id", a.ID, "run_id", res.RunID, "err", err)
		httpError(w, http.StatusInternalServerError, "save failed")
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// ---------- helpers ----------

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func httpError(w http.ResponseWriter, code int, msg string) {
	writeJSON(w, code, map[string]string{"error": msg})
}

func decodeJSON(r *http.Request, v any, limit int64) error {
	return json.NewDecoder(io.LimitReader(r.Body, limit)).Decode(v)
}
