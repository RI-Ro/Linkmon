package server

import (
	"encoding/json"
	"net/http"
)

func (s *Server) adminListMaps(w http.ResponseWriter, r *http.Request) {
	list, err := s.store.ListMaps(r.Context(), userFrom(r).ID)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) adminGetMap(w http.ResponseWriter, r *http.Request) {
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	m, err := s.store.GetMap(r.Context(), id, userFrom(r).ID)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, m)
}

func (s *Server) adminCreateMap(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	var req struct {
		Name string `json:"name"`
	}
	if err := decodeJSON(r, &req, 64<<10); err != nil || req.Name == "" {
		httpError(w, http.StatusBadRequest, "name required")
		return
	}
	id, err := s.store.CreateMap(r.Context(), userFrom(r).ID, req.Name)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusCreated, map[string]int64{"id": id})
}

func (s *Server) adminUpdateMap(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	var p MapPatch
	if err := decodeJSON(r, &p, 64<<10); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := s.store.UpdateMap(r.Context(), id, userFrom(r).ID, p); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) adminSaveMapGraph(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	var graph json.RawMessage
	if err := decodeJSON(r, &graph, 4<<20); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := s.store.UpdateMapGraph(r.Context(), id, userFrom(r).ID, graph); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) adminDeleteMap(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	if err := s.store.DeleteMap(r.Context(), id, userFrom(r).ID); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
