package server

import (
	"context"
	"encoding/json"
	"errors"

	"github.com/jackc/pgx/v5"
)

// Map — интерактивная карта сети. Граф (узлы с координатами + связи по каналам) хранится в jsonb
// целиком: фронтенд шлёт актуальный граф при перетаскивании/добавлении. Доступ — как у дашбордов.
type Map struct {
	ID         int64           `db:"id" json:"id"`
	OwnerID    *int64          `db:"owner_id" json:"owner_id"`
	Name       string          `db:"name" json:"name"`
	Visibility string          `db:"visibility" json:"visibility"`
	Graph      json.RawMessage `db:"graph" json:"graph"`
	Own        bool            `db:"own" json:"own"`
	Shares     []int64         `db:"-" json:"shares"`
}

const mapVisible = `(owner_id = $1 OR visibility = 'shared'
	OR (visibility = 'users' AND EXISTS (SELECT 1 FROM map_shares ms WHERE ms.map_id = maps.id AND ms.user_id = $1)))`

func (s *Store) ListMaps(ctx context.Context, userID int64) ([]Map, error) {
	rows, err := s.pool.Query(ctx, `SELECT id, owner_id, name, visibility, graph, (owner_id = $1) AS own
		FROM maps WHERE `+mapVisible+` ORDER BY name`, userID)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[Map])
}

func (s *Store) GetMap(ctx context.Context, id, userID int64) (*Map, error) {
	rows, err := s.pool.Query(ctx, `SELECT id, owner_id, name, visibility, graph, (owner_id = $1) AS own
		FROM maps WHERE id = $2 AND `+mapVisible, userID, id)
	if err != nil {
		return nil, err
	}
	m, err := pgx.CollectOneRow(rows, pgx.RowToStructByName[Map])
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, err
	}
	srows, err := s.pool.Query(ctx, `SELECT user_id FROM map_shares WHERE map_id = $1 ORDER BY user_id`, id)
	if err != nil {
		return nil, err
	}
	m.Shares, err = pgx.CollectRows(srows, pgx.RowTo[int64])
	if err != nil {
		return nil, err
	}
	if m.Shares == nil {
		m.Shares = []int64{}
	}
	if len(m.Graph) == 0 {
		m.Graph = json.RawMessage(`{"nodes":[],"edges":[]}`)
	}
	return &m, nil
}

func (s *Store) CreateMap(ctx context.Context, ownerID int64, name string) (int64, error) {
	var id int64
	err := s.pool.QueryRow(ctx, `INSERT INTO maps (owner_id, name) VALUES ($1, $2) RETURNING id`, ownerID, name).Scan(&id)
	return id, err
}

// UpdateMapGraph сохраняет граф карты (позиции узлов, связи) — только владелец.
func (s *Store) UpdateMapGraph(ctx context.Context, id, userID int64, graph json.RawMessage) error {
	if len(graph) == 0 {
		graph = json.RawMessage(`{"nodes":[],"edges":[]}`)
	}
	ct, err := s.pool.Exec(ctx, `UPDATE maps SET graph = $3, updated_at = now()
		WHERE id = $1 AND owner_id = $2`, id, userID, graph)
	if err != nil {
		return err
	}
	if ct.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

// MapPatch — переименование и доступ к карте (только владелец).
type MapPatch struct {
	Name       *string  `json:"name"`
	Visibility *string  `json:"visibility"`
	Shares     *[]int64 `json:"shares"`
}

func (s *Store) UpdateMap(ctx context.Context, id, userID int64, p MapPatch) error {
	if p.Visibility != nil {
		switch *p.Visibility {
		case "private", "users", "shared":
		default:
			return ErrBadRequest
		}
	}
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	ct, err := tx.Exec(ctx, `UPDATE maps SET name = COALESCE($3, name),
			visibility = COALESCE($4, visibility), updated_at = now()
		WHERE id = $1 AND owner_id = $2`, id, userID, p.Name, p.Visibility)
	if err != nil {
		return err
	}
	if ct.RowsAffected() == 0 {
		return ErrNotFound
	}
	if p.Shares != nil {
		if _, err := tx.Exec(ctx, `DELETE FROM map_shares WHERE map_id = $1`, id); err != nil {
			return err
		}
		if len(*p.Shares) > 0 {
			if _, err := tx.Exec(ctx, `INSERT INTO map_shares (map_id, user_id)
				SELECT $1, unnest($2::bigint[]) ON CONFLICT DO NOTHING`, id, *p.Shares); err != nil {
				return err
			}
		}
	}
	return tx.Commit(ctx)
}

func (s *Store) DeleteMap(ctx context.Context, id, userID int64) error {
	ct, err := s.pool.Exec(ctx, `DELETE FROM maps WHERE id = $1 AND owner_id = $2`, id, userID)
	if err != nil {
		return err
	}
	if ct.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}
