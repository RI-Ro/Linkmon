package server

import (
	"context"
	"log/slog"
	"sync"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

// Hub слушает NOTIFY agent_commands и будит long-poll соответствующего агента.
// Так команда (например, тест группы) доходит до агентов за миллисекунды,
// и это работает при нескольких экземплярах сервера за балансировщиком.
type Hub struct {
	mu      sync.Mutex
	waiters map[string]map[chan struct{}]struct{}
	log     *slog.Logger
}

func NewHub(log *slog.Logger) *Hub {
	return &Hub{waiters: make(map[string]map[chan struct{}]struct{}), log: log.With("component", "hub")}
}

func (h *Hub) Subscribe(agentID string) (<-chan struct{}, func()) {
	ch := make(chan struct{}, 1)
	h.mu.Lock()
	if h.waiters[agentID] == nil {
		h.waiters[agentID] = make(map[chan struct{}]struct{})
	}
	h.waiters[agentID][ch] = struct{}{}
	h.mu.Unlock()
	return ch, func() {
		h.mu.Lock()
		delete(h.waiters[agentID], ch)
		if len(h.waiters[agentID]) == 0 {
			delete(h.waiters, agentID)
		}
		h.mu.Unlock()
	}
}

func (h *Hub) wake(agentID string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	for ch := range h.waiters[agentID] {
		select {
		case ch <- struct{}{}:
		default:
		}
	}
}

func (h *Hub) Run(ctx context.Context, pool *pgxpool.Pool) {
	for ctx.Err() == nil {
		if err := h.listen(ctx, pool); err != nil && ctx.Err() == nil {
			h.log.Warn("listen connection lost", "err", err)
			select {
			case <-ctx.Done():
			case <-time.After(2 * time.Second):
			}
		}
	}
}

func (h *Hub) listen(ctx context.Context, pool *pgxpool.Pool) error {
	pc, err := pool.Acquire(ctx)
	if err != nil {
		return err
	}
	conn := pc.Hijack() // выделенное соединение под LISTEN, в пул не возвращается
	defer conn.Close(context.Background())
	if _, err := conn.Exec(ctx, "LISTEN agent_commands"); err != nil {
		return err
	}
	for {
		n, err := conn.WaitForNotification(ctx)
		if err != nil {
			return err
		}
		h.wake(n.Payload)
	}
}
