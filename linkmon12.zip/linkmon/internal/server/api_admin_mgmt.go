package server

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"time"

	"github.com/example/linkmon/internal/api"
	"github.com/example/linkmon/internal/bwtest"
)

var (
	errBadRequest = errors.New("bad request")
	errTestLimits = errors.New("pps <= 1000, duration_sec <= 600")
)

// ---------- Гейты по ролям ----------

// requireBigAdmin пропускает только big_admin (управление пользователями/областями).
func (s *Server) requireBigAdmin(w http.ResponseWriter, r *http.Request) bool {
	if u := userFrom(r); u != nil && u.Role == RoleBigAdmin {
		return true
	}
	httpError(w, http.StatusForbidden, "требуется роль big_admin")
	return false
}

// requireManage пропускает admin и big_admin (изменение каналов/агентов/групп).
func (s *Server) requireManage(w http.ResponseWriter, r *http.Request) bool {
	if canManage(userFrom(r)) {
		return true
	}
	httpError(w, http.StatusForbidden, "недостаточно прав")
	return false
}

// ---------- Каналы: удаление, теги, одиночный тест ----------

func (s *Server) adminDeleteChannel(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	agentID, err := s.store.DeleteChannel(r.Context(), id)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	_ = s.store.EnqueueCommand(r.Context(), agentID, api.CmdReloadConfig, struct{}{})
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) adminListTags(w http.ResponseWriter, r *http.Request) {
	tags, err := s.store.AllTags(r.Context())
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, tags)
}

// adminRunChannelTest запускает разовый тест одного канала.
func (s *Server) adminRunChannelTest(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	p, err := parseTestPayload(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, err.Error())
		return
	}
	runID, err := s.store.CreateChannelTest(r.Context(), userFrom(r), id, p, testCreator(r))
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusAccepted, map[string]any{"run_id": runID, "channels": 1, "start_at": p.StartAt})
}

// parseTestPayload разбирает общие параметры теста (pps/размер/длительность/старт).
func parseTestPayload(r *http.Request) (api.RunTestPayload, error) {
	var req struct {
		PPS         int        `json:"pps"`
		PacketSize  int        `json:"packet_size"`
		DurationSec int        `json:"duration_sec"`
		StartAt     *time.Time `json:"start_at"`
	}
	if err := decodeJSON(r, &req, 64<<10); err != nil {
		return api.RunTestPayload{}, errBadRequest
	}
	p := api.RunTestPayload{PPS: req.PPS, PacketSize: req.PacketSize, DurationSec: req.DurationSec}
	if p.PPS <= 0 {
		p.PPS = 100
	}
	if p.DurationSec <= 0 {
		p.DurationSec = 60
	}
	if p.PPS > 1000 || p.DurationSec > 600 {
		return api.RunTestPayload{}, errTestLimits
	}
	p.StartAt = time.Now().Add(5 * time.Second).UTC()
	if req.StartAt != nil && req.StartAt.After(p.StartAt) {
		p.StartAt = req.StartAt.UTC()
	}
	return p, nil
}

func testCreator(r *http.Request) string {
	if u := userFrom(r); u != nil {
		return u.Login
	}
	return "admin"
}

// adminListUserNames — логины пользователей для пикера «поделиться дашбордом» (любой менеджер).
func (s *Server) adminListUserNames(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	list, err := s.store.ListUserNames(r.Context())
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, list)
}

// adminAgentInterfaces — интерфейсы, обнаруженные агентом (для выбора при создании каналов).
func (s *Server) adminAgentInterfaces(w http.ResponseWriter, r *http.Request) {
	list, err := s.store.AgentInterfaces(r.Context(), userFrom(r), r.PathValue("id"))
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, list)
}

// adminCreateAgentChannel заводит канал агента по данным из веб-интерфейса (конфиг с сервера).
func (s *Server) adminCreateAgentChannel(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	id := r.PathValue("id")
	// admin может настраивать только доступных ему агентов.
	if u := userFrom(r); u != nil && u.Role != RoleBigAdmin {
		ok, err := s.store.CanSeeAgent(r.Context(), u, id)
		if err != nil {
			s.storeErr(w, err)
			return
		}
		if !ok {
			httpError(w, http.StatusForbidden, "агент вне вашей области видимости")
			return
		}
	}
	var c ChannelCreate
	if err := decodeJSON(r, &c, 64<<10); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	chID, err := s.store.CreateServerChannel(r.Context(), id, c)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusCreated, map[string]any{"id": chID})
}

// adminAgentBWTestEndpoint — подобранный сервером адрес bwtest агента (не вписывается вручную).
func (s *Server) adminAgentBWTestEndpoint(w http.ResponseWriter, r *http.Request) {
	addr, err := s.store.AgentBWTestEndpoint(r.Context(), userFrom(r), r.PathValue("id"))
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"addr": addr})
}

// adminBWTestDefaults — умолчания для формы теста: адрес bwtest самого сервера LinkMon и
// доступность релея (когда оба агента за NAT).
func (s *Server) adminBWTestDefaults(w http.ResponseWriter, r *http.Request) {
	server := ""
	if s.cfg.BWTestPort > 0 {
		host := ""
		if len(s.cfg.TLSHosts) > 0 {
			host = s.cfg.TLSHosts[len(s.cfg.TLSHosts)-1]
		}
		if host != "" {
			server = fmt.Sprintf("%s:%d", host, s.cfg.BWTestPort)
		}
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"server_addr":     server,
		"relay_available": s.cfg.RelayPort > 0,
	})
}

// adminSetAgentAlertMode задаёт режим оповещений агента (all | critical | off).
func (s *Server) adminSetAgentAlertMode(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	var body struct {
		Mode string `json:"mode"`
	}
	if err := decodeJSON(r, &body, 4<<10); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := s.store.SetAgentAlertMode(r.Context(), r.PathValue("id"), body.Mode); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// adminSetAgentGroups назначает агента в группы (доступ к агенту даётся пользователям по группам).
func (s *Server) adminSetAgentGroups(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	id := r.PathValue("id")
	var body struct {
		Groups []int32 `json:"groups"`
	}
	if err := decodeJSON(r, &body, 64<<10); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := s.store.SetAgentGroups(r.Context(), id, body.Groups); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// ---------- Агенты: имя, включение/выключение, удаление ----------

func (s *Server) adminRenameAgent(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	var req struct {
		Name string `json:"name"`
	}
	if err := decodeJSON(r, &req, 64<<10); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := s.store.SetAgentName(r.Context(), r.PathValue("id"), req.Name); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) adminDisableAgent(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	if err := s.store.SetAgentDisabled(r.Context(), r.PathValue("id"), true); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) adminEnableAgent(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	if err := s.store.SetAgentDisabled(r.Context(), r.PathValue("id"), false); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) adminDeleteAgent(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	if err := s.store.DeleteAgent(r.Context(), r.PathValue("id")); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// ---------- Алерты: ack ----------

func (s *Server) adminAckAlert(w http.ResponseWriter, r *http.Request) {
	u := userFrom(r)
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	if err := s.store.AckAlert(r.Context(), id, u.ID); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// ---------- Дашборды ----------

func (s *Server) adminListDashboards(w http.ResponseWriter, r *http.Request) {
	list, err := s.store.ListDashboards(r.Context(), userFrom(r).ID)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) adminGetDashboard(w http.ResponseWriter, r *http.Request) {
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	d, err := s.store.GetDashboard(r.Context(), id, userFrom(r).ID)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, d)
}

func (s *Server) adminCreateDashboard(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Name string `json:"name"`
	}
	if err := decodeJSON(r, &req, 64<<10); err != nil || req.Name == "" {
		httpError(w, http.StatusBadRequest, "name required")
		return
	}
	id, err := s.store.CreateDashboard(r.Context(), userFrom(r).ID, req.Name)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusCreated, map[string]int64{"id": id})
}

func (s *Server) adminUpdateDashboard(w http.ResponseWriter, r *http.Request) {
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	var p DashboardPatch
	if err := decodeJSON(r, &p, 1<<20); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := s.store.UpdateDashboard(r.Context(), id, userFrom(r).ID, p); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) adminDeleteDashboard(w http.ResponseWriter, r *http.Request) {
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	if err := s.store.DeleteDashboard(r.Context(), id, userFrom(r).ID); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) adminSaveWidgets(w http.ResponseWriter, r *http.Request) {
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	var req struct {
		Widgets []Widget `json:"widgets"`
	}
	if err := decodeJSON(r, &req, 4<<20); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := s.store.SaveWidgets(r.Context(), id, userFrom(r).ID, req.Widgets); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// ---------- Пользователи и области видимости (big_admin) ----------

func (s *Server) adminListUsers(w http.ResponseWriter, r *http.Request) {
	if !s.requireBigAdmin(w, r) {
		return
	}
	list, err := s.store.ListUsers(r.Context())
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) adminAllGroups(w http.ResponseWriter, r *http.Request) {
	if !s.requireBigAdmin(w, r) {
		return
	}
	list, err := s.store.AllGroups(r.Context())
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) adminCreateUser(w http.ResponseWriter, r *http.Request) {
	if !s.requireBigAdmin(w, r) {
		return
	}
	var req struct {
		Login    string  `json:"login"`
		Password string  `json:"password"`
		Role     string  `json:"role"`
		Groups   []int64 `json:"groups"`
	}
	if err := decodeJSON(r, &req, 64<<10); err != nil || req.Login == "" || len(req.Password) < 8 {
		httpError(w, http.StatusBadRequest, "логин и пароль (от 8 символов) обязательны")
		return
	}
	id, err := s.store.CreateUser(r.Context(), req.Login, req.Password, req.Role, req.Groups)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusCreated, map[string]int64{"id": id})
}

func (s *Server) adminSetUserScopes(w http.ResponseWriter, r *http.Request) {
	if !s.requireBigAdmin(w, r) {
		return
	}
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	var req struct {
		Groups []int64 `json:"groups"`
	}
	if err := decodeJSON(r, &req, 1<<20); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := s.store.SetUserScopes(r.Context(), id, req.Groups); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) adminSetUserRole(w http.ResponseWriter, r *http.Request) {
	if !s.requireBigAdmin(w, r) {
		return
	}
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	var req struct {
		Role string `json:"role"`
	}
	if err := decodeJSON(r, &req, 64<<10); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := s.store.SetUserRole(r.Context(), id, req.Role); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) adminResetUserPassword(w http.ResponseWriter, r *http.Request) {
	if !s.requireBigAdmin(w, r) {
		return
	}
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	var req struct {
		Password string `json:"password"`
	}
	if err := decodeJSON(r, &req, 64<<10); err != nil || len(req.Password) < 8 {
		httpError(w, http.StatusBadRequest, "пароль от 8 символов")
		return
	}
	if err := s.store.ResetPassword(r.Context(), id, req.Password); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) adminSetUserDisabled(w http.ResponseWriter, r *http.Request) {
	if !s.requireBigAdmin(w, r) {
		return
	}
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	var req struct {
		Disabled bool `json:"disabled"`
	}
	if err := decodeJSON(r, &req, 64<<10); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := s.store.SetUserDisabled(r.Context(), id, req.Disabled); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) adminDeleteUser(w http.ResponseWriter, r *http.Request) {
	if !s.requireBigAdmin(w, r) {
		return
	}
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	// Нельзя удалить самого себя, чтобы случайно не потерять доступ.
	if u := userFrom(r); u != nil && u.ID == id {
		httpError(w, http.StatusBadRequest, "нельзя удалить свою учётную запись")
		return
	}
	if err := s.store.DeleteUser(r.Context(), id); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// ---------- Тесты пропускной способности (iperf-подобные) ----------

// adminCreateBWTest запускает тест пропускной способности между двумя агентами.
func (s *Server) adminCreateBWTest(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	var c BWTestCreate
	if err := decodeJSON(r, &c, 64<<10); err != nil {
		httpError(w, http.StatusBadRequest, "bad request")
		return
	}
	if c.ServerAddr == "" {
		httpError(w, http.StatusBadRequest, "нужен server_addr (host:port). client_agent пуст — клиентом будет сам сервер")
		return
	}
	u := userFrom(r)
	// admin запускает тест только между своими агентами. Клиентом «сам сервер LinkMon»
	// (client_agent пуст) может выступать только big_admin — это глобальный ресурс.
	if u != nil && u.Role != RoleBigAdmin {
		if c.ClientAgent == "" {
			httpError(w, http.StatusForbidden, "клиентом «Сервер LinkMon» может назначить только big_admin")
			return
		}
		for _, aid := range []string{c.ClientAgent, c.ServerAgent} {
			if aid == "" {
				continue
			}
			ok, err := s.store.CanSeeAgent(r.Context(), u, aid)
			if err != nil {
				s.storeErr(w, err)
				return
			}
			if !ok {
				httpError(w, http.StatusForbidden, "тест возможен только между доступными вам агентами")
				return
			}
		}
	}
	relayAddr := ""
	if s.cfg.RelayPort > 0 {
		host := s.cfg.RelayHost
		if host == "" && len(s.cfg.TLSHosts) > 0 {
			host = s.cfg.TLSHosts[len(s.cfg.TLSHosts)-1] // обычно публичное имя сервера
		}
		if host != "" {
			relayAddr = fmt.Sprintf("%s:%d", host, s.cfg.RelayPort)
		}
	}
	id, serverIsClient, err := s.store.CreateBWTest(r.Context(), c, relayAddr, testCreator(r))
	if err != nil {
		s.storeErr(w, err)
		return
	}
	if serverIsClient {
		// Клиент — сам сервер LinkMon (топологии сервер↔сервер и агент↔сервер по инициативе сервера).
		go s.runServerBWTest(id, c.ServerAddr, c.Params)
	}
	writeJSON(w, http.StatusAccepted, map[string]any{"id": id})
}

// runServerBWTest прогоняет тест пропускной способности, когда клиентом выступает сам сервер.
func (s *Server) runServerBWTest(id int64, serverAddr string, ps api.BWTestParams) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(ps.DurationSec+90)*time.Second)
	defer cancel()
	s.store.SetBWTestRunning(ctx, id)
	bp := bwtest.Params{
		Proto: ps.Proto, DurationSec: ps.DurationSec, Streams: ps.Streams,
		LengthBytes: ps.LengthBytes, TargetMbps: ps.TargetMbps, Reverse: ps.Reverse, DSCP: ps.DSCP,
	}
	r, err := bwtest.RunClient(ctx, serverAddr, bp)
	if err != nil {
		_ = s.store.SaveServerBWTestResult(ctx, id, nil, err.Error())
		s.log.Warn("server bwtest failed", "id", id, "err", err)
		return
	}
	res := &api.BWTestResultData{
		Proto: r.Proto, DurationSec: r.DurationSec, Bytes: r.Bytes, Mbps: r.Mbps,
		Packets: r.Packets, LostPackets: r.LostPackets, LossPct: r.LossPct,
		JitterMs: r.JitterMs, Retransmits: r.Retransmits, Streams: r.Streams, Reverse: r.Reverse,
	}
	_ = s.store.SaveServerBWTestResult(ctx, id, res, "")
}

func (s *Server) adminListBWTests(w http.ResponseWriter, r *http.Request) {
	list, err := s.store.ListBWTests(r.Context(), userFrom(r), queryInt(r, "limit", 100))
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) adminGetBWTest(w http.ResponseWriter, r *http.Request) {
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	v, err := s.store.GetBWTest(r.Context(), id)
	if err != nil {
		s.storeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, v)
}

func (s *Server) adminDeleteBWTest(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	if err := s.store.DeleteBWTest(r.Context(), id); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) adminDeleteTest(w http.ResponseWriter, r *http.Request) {
	if !s.requireManage(w, r) {
		return
	}
	id, err := pathInt(r)
	if err != nil {
		httpError(w, http.StatusBadRequest, "bad id")
		return
	}
	if err := s.store.DeleteTestRun(r.Context(), id); err != nil {
		s.storeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
