package server

import (
	"context"
	"encoding/json"
	"errors"

	"github.com/jackc/pgx/v5"
)

type Dashboard struct {
	ID         int64           `db:"id" json:"id"`
	OwnerID    *int64          `db:"owner_id" json:"owner_id"`
	Name       string          `db:"name" json:"name"`
	Shared     bool            `db:"shared" json:"shared"`         // совместимость: visibility='shared'
	Visibility string          `db:"visibility" json:"visibility"` // private | users | shared
	Layout     json.RawMessage `db:"layout" json:"layout"`
	Own        bool            `db:"own" json:"own"`
	Shares     []int64         `db:"-" json:"shares"` // id пользователей при visibility='users'
	Widgets    []Widget        `db:"-" json:"widgets"`
}

// dashVisible — условие доступа к дашборду для пользователя $1 (владелец, общий или в списке users).
const dashVisible = `(owner_id = $1 OR visibility = 'shared'
	OR (visibility = 'users' AND EXISTS (SELECT 1 FROM dashboard_shares ds WHERE ds.dashboard_id = dashboards.id AND ds.user_id = $1)))`

type Widget struct {
	ID          int64           `db:"id" json:"id"`
	DashboardID int64           `db:"dashboard_id" json:"dashboard_id"`
	Kind        string          `db:"kind" json:"kind"`
	Title       string          `db:"title" json:"title"`
	Config      json.RawMessage `db:"config" json:"config"`
	Pos         int             `db:"pos" json:"pos"`
}

// ListDashboards отдаёт дашборды пользователя и доступные ему (общие или расшаренные лично).
func (s *Store) ListDashboards(ctx context.Context, userID int64) ([]Dashboard, error) {
	rows, err := s.pool.Query(ctx, `SELECT id, owner_id, name, shared, visibility, layout, (owner_id = $1) AS own
		FROM dashboards WHERE `+dashVisible+` ORDER BY name`, userID)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[Dashboard])
}

// GetDashboard возвращает дашборд с виджетами. Доступ: владелец, общий или в списке users.
func (s *Store) GetDashboard(ctx context.Context, id, userID int64) (*Dashboard, error) {
	rows, err := s.pool.Query(ctx, `SELECT id, owner_id, name, shared, visibility, layout, (owner_id = $1) AS own
		FROM dashboards WHERE id = $2 AND `+dashVisible, userID, id)
	if err != nil {
		return nil, err
	}
	d, err := pgx.CollectOneRow(rows, pgx.RowToStructByName[Dashboard])
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, err
	}
	// Список пользователей-получателей (нужен владельцу для редактирования доступа).
	srows, err := s.pool.Query(ctx, `SELECT user_id FROM dashboard_shares WHERE dashboard_id = $1 ORDER BY user_id`, id)
	if err != nil {
		return nil, err
	}
	d.Shares, err = pgx.CollectRows(srows, pgx.RowTo[int64])
	if err != nil {
		return nil, err
	}
	if d.Shares == nil {
		d.Shares = []int64{}
	}
	wrows, err := s.pool.Query(ctx, `SELECT id, dashboard_id, kind, title, config, pos
		FROM dashboard_widgets WHERE dashboard_id = $1 ORDER BY pos, id`, id)
	if err != nil {
		return nil, err
	}
	d.Widgets, err = pgx.CollectRows(wrows, pgx.RowToStructByName[Widget])
	if d.Widgets == nil {
		d.Widgets = []Widget{} // всегда массив, чтобы фронт не падал на d.widgets.map
	}
	return &d, err
}

// UserName — краткая запись пользователя для пикеров (например, «поделиться дашбордом»).
type UserName struct {
	ID    int64  `db:"id" json:"id"`
	Login string `db:"login" json:"login"`
	Role  string `db:"role" json:"role"`
}

// ListUserNames — логины активных пользователей (доступно любому менеджеру для выбора получателей).
func (s *Store) ListUserNames(ctx context.Context) ([]UserName, error) {
	rows, err := s.pool.Query(ctx, `SELECT id, login, role FROM admin_users WHERE NOT disabled ORDER BY login`)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[UserName])
}

func (s *Store) CreateDashboard(ctx context.Context, ownerID int64, name string) (int64, error) {
	var id int64
	err := s.pool.QueryRow(ctx, `INSERT INTO dashboards (owner_id, name) VALUES ($1, $2) RETURNING id`,
		ownerID, name).Scan(&id)
	return id, err
}

// ownsDashboard проверяет, что дашборд принадлежит пользователю (для изменений).
func (s *Store) ownsDashboard(ctx context.Context, q queryer, id, userID int64) (bool, error) {
	rows, err := q.Query(ctx, `SELECT 1 FROM dashboards WHERE id = $1 AND owner_id = $2`, id, userID)
	if err != nil {
		return false, err
	}
	defer rows.Close()
	return rows.Next(), rows.Err()
}

type DashboardPatch struct {
	Name       *string         `json:"name"`
	Shared     *bool           `json:"shared"`     // совместимость
	Visibility *string         `json:"visibility"` // private | users | shared
	Shares     *[]int64        `json:"shares"`     // список пользователей при visibility='users'
	Layout     json.RawMessage `json:"layout"`
}

func (s *Store) UpdateDashboard(ctx context.Context, id, userID int64, p DashboardPatch) error {
	vis := p.Visibility
	if vis == nil && p.Shared != nil { // старый клиент шлёт shared
		v := "private"
		if *p.Shared {
			v = "shared"
		}
		vis = &v
	}
	if vis != nil && *vis != "private" && *vis != "users" && *vis != "shared" {
		return ErrNotFound
	}

	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)

	tag, err := tx.Exec(ctx, `UPDATE dashboards SET
			name = COALESCE($3, name),
			visibility = COALESCE($4, visibility),
			shared = (COALESCE($4, visibility) = 'shared'),
			layout = COALESCE($5, layout), updated_at = now()
		WHERE id = $1 AND owner_id = $2`, id, userID, p.Name, vis, p.Layout)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	// Обновляем список получателей, если он передан (только для владельца — проверено выше).
	if p.Shares != nil {
		if _, err := tx.Exec(ctx, `DELETE FROM dashboard_shares WHERE dashboard_id = $1`, id); err != nil {
			return err
		}
		if len(*p.Shares) > 0 {
			if _, err := tx.Exec(ctx, `INSERT INTO dashboard_shares (dashboard_id, user_id)
				SELECT $1, unnest($2::bigint[]) ON CONFLICT DO NOTHING`, id, *p.Shares); err != nil {
				return err
			}
		}
	}
	return tx.Commit(ctx)
}

func (s *Store) DeleteDashboard(ctx context.Context, id, userID int64) error {
	tag, err := s.pool.Exec(ctx, `DELETE FROM dashboards WHERE id = $1 AND owner_id = $2`, id, userID)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

// SaveWidgets заменяет весь набор виджетов дашборда (фронтенд шлёт актуальный список).
func (s *Store) SaveWidgets(ctx context.Context, dashID, userID int64, widgets []Widget) error {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	owned, err := s.ownsDashboard(ctx, tx, dashID, userID)
	if err != nil {
		return err
	}
	if !owned {
		return ErrNotFound
	}
	if _, err := tx.Exec(ctx, `DELETE FROM dashboard_widgets WHERE dashboard_id = $1`, dashID); err != nil {
		return err
	}
	for i, w := range widgets {
		cfg := w.Config
		if len(cfg) == 0 {
			cfg = json.RawMessage("{}")
		}
		if _, err := tx.Exec(ctx, `INSERT INTO dashboard_widgets (dashboard_id, kind, title, config, pos)
			VALUES ($1, $2, $3, $4, $5)`, dashID, w.Kind, w.Title, cfg, i); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}
