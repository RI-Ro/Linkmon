package server

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"

	"github.com/example/linkmon/internal/api"
)

type AgentView struct {
	ID          string     `db:"id" json:"id"`
	MachineID   string     `db:"machine_id" json:"machine_id"`
	Hostname    string     `db:"hostname" json:"hostname"`
	Name        string     `db:"name" json:"name"` // понятное имя (что показывать в UI и поиске)
	Status      string     `db:"status" json:"status"`
	Version     *string    `db:"version" json:"version"`
	LastSeen    *time.Time `db:"last_seen" json:"last_seen"`
	ClockSynced *bool      `db:"clock_synced" json:"clock_synced"`
	ClockErrUS  *int64     `db:"clock_err_us" json:"clock_err_us"`
	Channels    int64      `db:"channels" json:"channels"`
	Groups      []int32    `db:"groups" json:"groups"`
	AlertMode   string     `db:"alert_mode" json:"alert_mode"` // all | critical | off
	CreatedAt   time.Time  `db:"created_at" json:"created_at"`
}

// ListAgents: big_admin видит всех; admin/viewer — только агентов, у которых есть каналы
// в их области видимости (проверяется через ту же RLS-функцию на scoped-соединении).
func (s *Store) ListAgents(ctx context.Context, u *AdminUser) ([]AgentView, error) {
	c, err := s.asUser(ctx, u)
	if err != nil {
		return nil, err
	}
	defer c.Release()
	rows, err := c.Query(ctx, `SELECT a.id::text AS id, a.machine_id, a.hostname,
			COALESCE(NULLIF(a.name, ''), a.hostname, a.machine_id) AS name,
			a.status, a.version, a.last_seen, a.clock_synced, a.clock_err_us,
			(SELECT count(*) FROM channels c WHERE c.agent_id = a.id) AS channels,
			COALESCE((SELECT array_agg(am.group_id ORDER BY am.group_id)
			          FROM agent_group_members am WHERE am.agent_id = a.id), '{}') AS groups,
			a.alert_mode,
			a.created_at
		FROM agents a
		WHERE linkmon_role() IN ('', 'big_admin')
		   OR linkmon_can_see_agent(a.id)
		   OR EXISTS (SELECT 1 FROM channels c WHERE c.agent_id = a.id AND linkmon_can_see_channel(c.id))
		ORDER BY a.status, name`)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[AgentView])
}

type ChannelView struct {
	ID          int64    `db:"id" json:"id"`
	AgentID     string   `db:"agent_id" json:"agent_id"`
	Agent       string   `db:"agent" json:"agent"`
	Name        string   `db:"name" json:"name"`                 // авто-имя (agent/iface → target)
	DisplayName *string  `db:"display_name" json:"display_name"` // пользовательское имя
	Label       string   `db:"label" json:"label"`               // что показывать: display_name или name
	Tags        []string `db:"tags" json:"tags"`
	Stale       bool     `db:"stale" json:"stale"`
	Interface   string   `db:"interface" json:"interface"`
	SourceIP    *string  `db:"source_ip" json:"source_ip"`
	Reflector   string   `db:"reflector" json:"reflector"`
	DSCP        int      `db:"dscp" json:"dscp"`
	DSCPName    string   `db:"dscp_name" json:"dscp_name"`
	ProfileID   int      `db:"profile_id" json:"profile_id"`
	SLAID       *int     `db:"sla_id" json:"sla_id"`
	Enabled     bool     `db:"enabled" json:"enabled"`
	Groups      []int32  `db:"groups" json:"groups"`
}

// ListChannels отдаёт каналы в области видимости пользователя (RLS через asUser).
func (s *Store) ListChannels(ctx context.Context, u *AdminUser, agentID *string) ([]ChannelView, error) {
	c, err := s.asUser(ctx, u)
	if err != nil {
		return nil, err
	}
	defer c.Release()
	rows, err := c.Query(ctx, `SELECT c.id, c.agent_id::text AS agent_id,
			COALESCE(NULLIF(a.name, ''), a.hostname, a.machine_id) AS agent,
			c.name, c.display_name, COALESCE(NULLIF(c.display_name, ''), c.name) AS label,
			c.tags, c.stale, c.interface, host(c.source_ip) AS source_ip,
			r.name || ' (' || host(r.address) || ':' || r.port || ')' AS reflector,
			c.dscp, COALESCE(d.name, 'DSCP' || c.dscp) AS dscp_name, c.profile_id, c.sla_id, c.enabled,
			COALESCE((SELECT array_agg(m.group_id ORDER BY m.group_id)
			          FROM channel_group_members m WHERE m.channel_id = c.id), '{}') AS groups
		FROM channels c
		JOIN agents a ON a.id = c.agent_id
		JOIN reflectors r ON r.id = c.reflector_id
		LEFT JOIN dscp_names d ON d.dscp = c.dscp
		WHERE ($1::uuid IS NULL OR c.agent_id = $1)
		  AND linkmon_can_see_channel(c.id)
		ORDER BY agent, c.interface, r.name, c.dscp`, agentID)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[ChannelView])
}

type ChannelPatch struct {
	DisplayName *string   `json:"display_name"` // "" очищает пользовательское имя
	Tags        *[]string `json:"tags"`
	Enabled     *bool     `json:"enabled"`
	ProfileID   *int      `json:"profile_id"`
	SLAID       *int      `json:"sla_id"`
	ClearSLA    bool      `json:"clear_sla"`
}

// UpdateChannel возвращает agent_id, чтобы отправить агенту команду перечитать конфигурацию.
func (s *Store) UpdateChannel(ctx context.Context, id int64, p ChannelPatch) (string, error) {
	var tags any
	if p.Tags != nil {
		tags = *p.Tags
	}
	var agentID string
	err := s.pool.QueryRow(ctx, `UPDATE channels SET
			display_name = COALESCE($2, display_name),
			tags = COALESCE($3::text[], tags),
			enabled = COALESCE($4, enabled),
			profile_id = COALESCE($5, profile_id),
			sla_id = CASE WHEN $7 THEN NULL ELSE COALESCE($6, sla_id) END
		WHERE id = $1 RETURNING agent_id::text`,
		id, p.DisplayName, tags, p.Enabled, p.ProfileID, p.SLAID, p.ClearSLA).Scan(&agentID)
	if errors.Is(err, pgx.ErrNoRows) {
		return "", ErrNotFound
	}
	return agentID, err
}

// DeleteChannel удаляет канал (вместе с его измерениями и членством в группах — каскадом).
// Возвращает agent_id для команды reload.
func (s *Store) DeleteChannel(ctx context.Context, id int64) (string, error) {
	var agentID string
	err := s.pool.QueryRow(ctx, `DELETE FROM channels WHERE id = $1 RETURNING agent_id::text`, id).Scan(&agentID)
	if errors.Is(err, pgx.ErrNoRows) {
		return "", ErrNotFound
	}
	return agentID, err
}

// SetChannelTags заменяет теги канала.
func (s *Store) SetChannelTags(ctx context.Context, id int64, tags []string) error {
	if tags == nil {
		tags = []string{}
	}
	tag, err := s.pool.Exec(ctx, `UPDATE channels SET tags = $2 WHERE id = $1`, id, tags)
	if err == nil && tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return err
}

// AllTags возвращает все уникальные теги каналов — для автодополнения в интерфейсе.
func (s *Store) AllTags(ctx context.Context) ([]string, error) {
	rows, err := s.pool.Query(ctx, `SELECT DISTINCT unnest(tags) AS t FROM channels ORDER BY t`)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowTo[string])
}

// ---------- Токены и группы ----------

func (s *Store) CreateToken(ctx context.Context, desc string, groupID *int, auto bool, uses *int, ttl time.Duration) (string, error) {
	raw := make([]byte, 24)
	if _, err := rand.Read(raw); err != nil {
		return "", err
	}
	tok := base64.RawURLEncoding.EncodeToString(raw)
	h := sha256.Sum256([]byte(tok))
	var exp *time.Time
	if ttl > 0 {
		t := time.Now().Add(ttl)
		exp = &t
	}
	_, err := s.pool.Exec(ctx, `INSERT INTO enroll_tokens (token_hash, description, group_id, auto_approve, uses_left, expires_at)
		VALUES ($1, $2, $3, $4, $5, $6)`, h[:], desc, groupID, auto, uses, exp)
	return tok, err // в БД хранится только хэш
}

type GroupView struct {
	ID       int      `db:"id" json:"id"`
	ParentID *int     `db:"parent_id" json:"parent_id"`
	Name     string   `db:"name" json:"name"`
	Tags     []string `db:"tags" json:"tags"`
	Channels int64    `db:"channels" json:"channels"`
}

// ListGroups: big_admin видит все группы; admin/viewer — только группы своей области.
func (s *Store) ListGroups(ctx context.Context, u *AdminUser) ([]GroupView, error) {
	c, err := s.asUser(ctx, u)
	if err != nil {
		return nil, err
	}
	defer c.Release()
	rows, err := c.Query(ctx, `SELECT g.id, g.parent_id, g.name, g.tags,
			(SELECT count(*) FROM channel_group_members m WHERE m.group_id = g.id) AS channels
		FROM channel_groups g
		WHERE linkmon_role() IN ('', 'big_admin')
		   OR g.id IN (SELECT group_id FROM user_scopes WHERE user_id = linkmon_user_id())
		ORDER BY g.parent_id NULLS FIRST, g.name`)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[GroupView])
}

// AllGroups — все группы без учёта области (для big_admin при назначении областей пользователям).
func (s *Store) AllGroups(ctx context.Context) ([]GroupView, error) {
	rows, err := s.pool.Query(ctx, `SELECT g.id, g.parent_id, g.name, g.tags,
			(SELECT count(*) FROM channel_group_members m WHERE m.group_id = g.id) AS channels
		FROM channel_groups g ORDER BY g.parent_id NULLS FIRST, g.name`)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[GroupView])
}

func (s *Store) CreateGroup(ctx context.Context, name string, parentID *int, tags []string) (int, error) {
	if tags == nil {
		tags = []string{}
	}
	var id int
	err := s.pool.QueryRow(ctx, `INSERT INTO channel_groups (name, parent_id, tags) VALUES ($1, $2, $3) RETURNING id`,
		name, parentID, tags).Scan(&id)
	return id, err
}

func (s *Store) AddGroupMembers(ctx context.Context, groupID int, channelIDs []int64) (int64, error) {
	tag, err := s.pool.Exec(ctx, `INSERT INTO channel_group_members (group_id, channel_id)
		SELECT $1, unnest($2::bigint[]) ON CONFLICT DO NOTHING`, groupID, channelIDs)
	return tag.RowsAffected(), err
}

// SetAgentGroups заменяет полный набор групп агента (используется на странице агентов).
func (s *Store) SetAgentGroups(ctx context.Context, agentID string, groupIDs []int32) error {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	if _, err := tx.Exec(ctx, `DELETE FROM agent_group_members WHERE agent_id = $1`, agentID); err != nil {
		return err
	}
	if len(groupIDs) > 0 {
		if _, err := tx.Exec(ctx, `INSERT INTO agent_group_members (group_id, agent_id)
			SELECT unnest($1::int[]), $2 ON CONFLICT DO NOTHING`, groupIDs, agentID); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

// ---------- Тесты по группе ----------

// CreateTestRun раскладывает тест по агентам: каждому — одна команда со списком его каналов
// из группы и всех её подгрупп. Все агенты стартуют в один и тот же момент StartAt.
func (s *Store) CreateTestRun(ctx context.Context, u *AdminUser, groupID int, p api.RunTestPayload, createdBy string) (int64, int, error) {
	// Собираем целевые каналы на scoped-соединении: admin получит только каналы своей области
	// (linkmon_can_see_channel), поэтому тест можно запустить лишь на своих каналах.
	sc, err := s.asUser(ctx, u)
	if err != nil {
		return 0, 0, err
	}
	crows, err := sc.Query(ctx, `WITH RECURSIVE g AS (
			SELECT id FROM channel_groups WHERE id = $1
			UNION ALL
			SELECT cg.id FROM channel_groups cg JOIN g ON cg.parent_id = g.id)
		SELECT DISTINCT c.agent_id::text, c.id
		FROM channel_group_members m
		JOIN g ON g.id = m.group_id
		JOIN channels c ON c.id = m.channel_id
		JOIN agents a ON a.id = c.agent_id
		WHERE c.enabled AND a.status = 'approved' AND linkmon_can_see_channel(c.id)
		ORDER BY 1, 2`, groupID)
	if err != nil {
		sc.Release()
		return 0, 0, err
	}
	byAgent := map[string][]int64{}
	total := 0
	for crows.Next() {
		var agentID string
		var chID int64
		if err := crows.Scan(&agentID, &chID); err != nil {
			crows.Close()
			sc.Release()
			return 0, 0, err
		}
		byAgent[agentID] = append(byAgent[agentID], chID)
		total++
	}
	crows.Close()
	sc.Release()
	if err := crows.Err(); err != nil {
		return 0, 0, err
	}
	if total == 0 {
		return 0, 0, ErrNotFound
	}

	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return 0, 0, err
	}
	defer tx.Rollback(ctx)

	var targets []int64
	for _, ids := range byAgent {
		targets = append(targets, ids...)
	}
	params, _ := json.Marshal(p)
	var runID int64
	if err := tx.QueryRow(ctx, `INSERT INTO test_runs (kind, group_id, start_at, duration_sec, params, expected, target_ids, status, created_by)
		VALUES ('burst', $1, $2, $3, $4, $5, $6, 'scheduled', $7) RETURNING id`,
		groupID, p.StartAt, p.DurationSec, params, total, targets, createdBy).Scan(&runID); err != nil {
		return 0, 0, err
	}
	for agentID, ids := range byAgent {
		pp := p
		pp.RunID, pp.ChannelIDs = runID, ids
		if err := enqueue(ctx, tx, agentID, api.CmdRunTest, pp); err != nil {
			return 0, 0, err
		}
	}
	return runID, total, tx.Commit(ctx)
}

// CreateChannelTest запускает разовый тест одного канала (кнопка «тест» в карточке канала).
// Тест допускается только на канале из области видимости пользователя.
func (s *Store) CreateChannelTest(ctx context.Context, u *AdminUser, channelID int64, p api.RunTestPayload, createdBy string) (int64, error) {
	if ok, err := s.CanSeeChannel(ctx, u, channelID); err != nil {
		return 0, err
	} else if !ok {
		return 0, ErrNotFound
	}

	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return 0, err
	}
	defer tx.Rollback(ctx)

	var agentID string
	err = tx.QueryRow(ctx, `SELECT c.agent_id::text FROM channels c
		JOIN agents a ON a.id = c.agent_id
		WHERE c.id = $1 AND c.enabled AND a.status = 'approved'`, channelID).Scan(&agentID)
	if errors.Is(err, pgx.ErrNoRows) {
		return 0, ErrNotFound
	}
	if err != nil {
		return 0, err
	}
	params, _ := json.Marshal(p)
	var runID int64
	if err := tx.QueryRow(ctx, `INSERT INTO test_runs (kind, channel_id, start_at, duration_sec, params, expected, target_ids, status, created_by)
		VALUES ('single', $1, $2, $3, $4, 1, $5, 'scheduled', $6) RETURNING id`,
		channelID, p.StartAt, p.DurationSec, params, []int64{channelID}, createdBy).Scan(&runID); err != nil {
		return 0, err
	}
	p.RunID, p.ChannelIDs = runID, []int64{channelID}
	if err := enqueue(ctx, tx, agentID, api.CmdRunTest, p); err != nil {
		return 0, err
	}
	return runID, tx.Commit(ctx)
}

type TestRunView struct {
	ID          int64           `db:"id" json:"id"`
	Kind        string          `db:"kind" json:"kind"`
	GroupID     *int            `db:"group_id" json:"group_id"`
	ChannelID   *int64          `db:"channel_id" json:"channel_id"`
	StartAt     time.Time       `db:"start_at" json:"start_at"`
	DurationSec int             `db:"duration_sec" json:"duration_sec"`
	Expected    int             `db:"expected" json:"expected"`
	Status      string          `db:"status" json:"status"`
	CreatedAt   time.Time       `db:"created_at" json:"created_at"`
	TargetIDs   []int64         `db:"target_ids" json:"-"`
	Results     []TestResultRow `db:"-" json:"results"`
}

// TestResultRow — детальный статус по каждому целевому каналу прогона.
// State: ok (есть результат), fail (ошибка), pending (ещё не прислал результат).
type TestResultRow struct {
	ChannelID int64          `db:"channel_id" json:"channel_id"`
	Channel   string         `db:"channel" json:"channel"`
	Agent     string         `db:"agent" json:"agent"`
	State     string         `db:"state" json:"state"`
	Result    map[string]any `db:"result" json:"result"`
	Error     *string        `db:"error" json:"error"`
}

func (s *Store) GetTestRun(ctx context.Context, id int64) (*TestRunView, error) {
	rows, err := s.pool.Query(ctx, `SELECT id, kind, group_id, channel_id, start_at, duration_sec, expected, status, created_at, target_ids
		FROM test_runs WHERE id = $1`, id)
	if err != nil {
		return nil, err
	}
	run, err := pgx.CollectOneRow(rows, pgx.RowToStructByName[TestRunView])
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, err
	}
	// Детально по каждому целевому каналу: разворачиваем target_ids и подтягиваем результат.
	// Так видно и тех, кто ещё «в процессе» (state=pending), а не только приславших ответ.
	rows, err = s.pool.Query(ctx, `SELECT t.channel_id,
			COALESCE(NULLIF(c.display_name, ''), c.name, '#' || t.channel_id) AS channel,
			COALESCE(NULLIF(a.name, ''), a.hostname, a.machine_id, '') AS agent,
			CASE WHEN r.result IS NOT NULL THEN 'ok'
			     WHEN r.error IS NOT NULL THEN 'fail'
			     ELSE 'pending' END AS state,
			r.result, r.error
		FROM unnest($1::bigint[]) AS t(channel_id)
		LEFT JOIN channels c ON c.id = t.channel_id
		LEFT JOIN agents a   ON a.id = c.agent_id
		LEFT JOIN test_run_results r ON r.run_id = $2 AND r.channel_id = t.channel_id
		ORDER BY state, channel`, run.TargetIDs, id)
	if err != nil {
		return nil, err
	}
	run.Results, err = pgx.CollectRows(rows, pgx.RowToStructByName[TestResultRow])
	return &run, err
}

// DeleteTestRun удаляет прогон и его результаты (каскадом).
func (s *Store) DeleteTestRun(ctx context.Context, id int64) error {
	ct, err := s.pool.Exec(ctx, `DELETE FROM test_runs WHERE id = $1`, id)
	if err != nil {
		return err
	}
	if ct.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

// ---------- Ряды для UI и метрики ----------

type SeriesPoint struct {
	TS          time.Time `db:"ts" json:"ts"`
	Sent        *int64    `db:"sent" json:"sent"`
	Received    *int64    `db:"received" json:"received"`
	LossPct     *float64  `db:"loss_pct" json:"loss_pct"`
	FwdLossPct  *float64  `db:"fwd_loss_pct" json:"fwd_loss_pct"`
	BwdLossPct  *float64  `db:"bwd_loss_pct" json:"bwd_loss_pct"`
	RTTAvg      *float64  `db:"rtt_avg" json:"rtt_avg"`
	RTTP95      *float64  `db:"rtt_p95" json:"rtt_p95"`
	RTTMax      *float64  `db:"rtt_max" json:"rtt_max"`
	FwdDelayAvg *float64  `db:"fwd_delay_avg" json:"fwd_delay_avg"`
	BwdDelayAvg *float64  `db:"bwd_delay_avg" json:"bwd_delay_avg"`
	FwdJitter   *float64  `db:"fwd_jitter" json:"fwd_jitter"`
	BwdJitter   *float64  `db:"bwd_jitter" json:"bwd_jitter"`
	FwdRemarked *int64    `db:"fwd_remarked" json:"fwd_remarked"`
	BwdRemarked *int64    `db:"bwd_remarked" json:"bwd_remarked"`
	MOS         *float64  `db:"mos" json:"mos"`
}

const seriesCols = `ts, sent, received, loss_pct, fwd_loss_pct, bwd_loss_pct, rtt_avg, rtt_p95, rtt_max,
	fwd_delay_avg, bwd_delay_avg, fwd_jitter, bwd_jitter, fwd_remarked, bwd_remarked, mos`

// Series выбирает сырые минуты или часовой агрегат в зависимости от диапазона.
// Доступ ограничен областью видимости: явный linkmon_can_see_channel на scoped-соединении
// (представления могут не наследовать RLS на PG14, поэтому проверяем явно).
func (s *Store) Series(ctx context.Context, u *AdminUser, channelID int64, from, to time.Time) ([]SeriesPoint, string, error) {
	view := "v_measurements"
	if to.Sub(from) > 48*time.Hour {
		view = "v_measurements_1h"
	}
	c, err := s.asUser(ctx, u)
	if err != nil {
		return nil, view, err
	}
	defer c.Release()
	rows, err := c.Query(ctx, `SELECT `+seriesCols+` FROM `+view+`
		WHERE channel_id = $1 AND ts >= $2 AND ts < $3 AND linkmon_can_see_channel(channel_id)
		ORDER BY ts`, channelID, from, to)
	if err != nil {
		return nil, view, err
	}
	pts, err := pgx.CollectRows(rows, pgx.RowToStructByName[SeriesPoint])
	return pts, view, err
}

type LatestRow struct {
	ChannelID   int64     `db:"channel_id" json:"channel_id"`
	Channel     string    `db:"channel" json:"channel"`
	AgentID     string    `db:"agent_id" json:"agent_id"`
	Agent       string    `db:"agent" json:"agent"`
	Interface   string    `db:"interface" json:"interface"`
	Reflector   string    `db:"reflector" json:"reflector"`
	DSCP        int       `db:"dscp" json:"dscp"`
	DSCPName    string    `db:"dscp_name" json:"dscp_name"`
	TS          time.Time `db:"ts" json:"ts"`
	RTTAvg      *float64  `db:"rtt_avg" json:"rtt_avg"`
	FwdDelayAvg *float64  `db:"fwd_delay_avg" json:"fwd_delay_avg"`
	BwdDelayAvg *float64  `db:"bwd_delay_avg" json:"bwd_delay_avg"`
	FwdJitter   *float64  `db:"fwd_jitter" json:"fwd_jitter"`
	BwdJitter   *float64  `db:"bwd_jitter" json:"bwd_jitter"`
	LossPct     *float64  `db:"loss_pct" json:"loss_pct"`
	FwdLossPct  *float64  `db:"fwd_loss_pct" json:"fwd_loss_pct"`
	BwdLossPct  *float64  `db:"bwd_loss_pct" json:"bwd_loss_pct"`
	MOS         *float64  `db:"mos" json:"mos"`
	FwdRemarked *int64    `db:"fwd_remarked" json:"fwd_remarked"`
	BwdRemarked *int64    `db:"bwd_remarked" json:"bwd_remarked"`
}

func (s *Store) LatestMetrics(ctx context.Context, u *AdminUser) ([]LatestRow, error) {
	c, err := s.asUser(ctx, u)
	if err != nil {
		return nil, err
	}
	defer c.Release()
	rows, err := c.Query(ctx, `SELECT DISTINCT ON (channel_id)
			channel_id, channel, agent_id::text AS agent_id, agent, interface, reflector, dscp, dscp_name, ts, rtt_avg, fwd_delay_avg, bwd_delay_avg,
			fwd_jitter, bwd_jitter, loss_pct, fwd_loss_pct, bwd_loss_pct, mos, fwd_remarked, bwd_remarked
		FROM v_measurements
		WHERE ts > now() - interval '10 minutes' AND sent IS NOT NULL AND linkmon_can_see_channel(channel_id)
		  AND NOT stale AND enabled
		ORDER BY channel_id, ts DESC`)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[LatestRow])
}
