package server

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"

	"github.com/example/linkmon/internal/api"
)

// ChannelCreate — параметры создания канала с сервера (конфигурация задаётся в веб-интерфейсе,
// а не в conf.yaml агента). Интерфейс выбирается из тех, что агент реально сообщил.
type ChannelCreate struct {
	Interface     string  `json:"interface"`
	SourceIP      string  `json:"source_ip,omitempty"`
	ReflectorName string  `json:"reflector_name,omitempty"`
	ReflectorAddr string  `json:"reflector_addr"` // IPv4 цели (рефлектор-сервер или другой узел)
	ReflectorPort int     `json:"reflector_port"`
	DSCP          int     `json:"dscp"`
	TWAMP         bool    `json:"twamp,omitempty"`
	DisplayName   string  `json:"display_name,omitempty"`
	GroupIDs      []int32 `json:"group_ids,omitempty"`
	Monitor       bool    `json:"monitor,omitempty"`    // снимать загрузку интерфейса
	SpeedMbit     int64   `json:"speed_mbit,omitempty"` // номинал для утилизации
}

// CreateServerChannel заводит канал (agent × interface × reflector × dscp) по данным из UI,
// создаёт/переиспользует рефлектор, при необходимости включает мониторинг загрузки и просит
// агента перечитать конфигурацию. Возвращает id канала.
func (s *Store) CreateServerChannel(ctx context.Context, agentID string, c ChannelCreate) (int64, error) {
	if c.Interface == "" || c.ReflectorAddr == "" {
		return 0, ErrBadRequest
	}
	if c.DSCP < 0 || c.DSCP > 63 {
		return 0, ErrBadRequest
	}
	port := c.ReflectorPort
	if port == 0 {
		port = api.DefaultReflectorPort
	}
	rname := c.ReflectorName
	if rname == "" {
		rname = c.ReflectorAddr
	}

	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return 0, err
	}
	defer tx.Rollback(ctx)

	// Агент должен существовать и быть одобрен.
	var hostname string
	if err := tx.QueryRow(ctx, `SELECT hostname FROM agents WHERE id = $1 AND status = 'approved'`, agentID).Scan(&hostname); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return 0, ErrNotFound
		}
		return 0, err
	}

	var rid int
	if err := tx.QueryRow(ctx, `INSERT INTO reflectors (name, address, port) VALUES ($1, $2::inet, $3)
		ON CONFLICT (address, port) DO UPDATE SET name = EXCLUDED.name RETURNING id`,
		rname, c.ReflectorAddr, port).Scan(&rid); err != nil {
		return 0, err
	}

	sid, key, err := newSessionCredentials()
	if err != nil {
		return 0, err
	}
	name := fmt.Sprintf("%s/%s → %s [%s]", hostname, c.Interface, rname, dscpName(c.DSCP))

	var chID int64
	err = tx.QueryRow(ctx, `INSERT INTO channels
		(agent_id, interface, source_ip, reflector_id, dscp, name, display_name, session_id, session_key, twamp, server_authored)
		VALUES ($1, $2, NULLIF($3, '')::inet, $4, $5, $6, NULLIF($7, ''), $8, $9, $10, true)
		ON CONFLICT (agent_id, interface, reflector_id, dscp) DO UPDATE
			SET twamp = EXCLUDED.twamp, display_name = COALESCE(EXCLUDED.display_name, channels.display_name),
			    stale = false, server_authored = true, config_updated_at = now()
		RETURNING id`,
		agentID, c.Interface, c.SourceIP, rid, c.DSCP, name, c.DisplayName, sid, key, c.TWAMP).Scan(&chID)
	if err != nil {
		return 0, err
	}

	for _, gid := range c.GroupIDs {
		if _, err := tx.Exec(ctx, `INSERT INTO channel_group_members (group_id, channel_id)
			VALUES ($1, $2) ON CONFLICT DO NOTHING`, gid, chID); err != nil {
			return 0, err
		}
	}

	if c.Monitor {
		var speed *int64
		if c.SpeedMbit > 0 {
			v := c.SpeedMbit * 1_000_000
			speed = &v
		}
		if _, err := tx.Exec(ctx, `INSERT INTO iface_monitors (agent_id, interface, speed_bits, interval_sec, server_authored)
			VALUES ($1, $2, $3, 60, true)
			ON CONFLICT (agent_id, interface)
			DO UPDATE SET speed_bits = EXCLUDED.speed_bits, enabled = true, server_authored = true`,
			agentID, c.Interface, speed); err != nil {
			return 0, err
		}
	}

	// Просим агента перечитать конфигурацию — новый канал стартует без рестарта агента.
	if err := enqueue(ctx, tx, agentID, api.CmdReloadConfig, struct{}{}); err != nil {
		return 0, err
	}
	return chID, tx.Commit(ctx)
}
