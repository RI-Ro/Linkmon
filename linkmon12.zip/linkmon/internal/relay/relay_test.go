package relay

import (
	"context"
	"crypto/rand"
	"fmt"
	"net"
	"testing"
	"time"
)

func freePort(t *testing.T) int {
	t.Helper()
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	defer l.Close()
	return l.Addr().(*net.TCPAddr).Port
}

func startRelay(t *testing.T) (string, context.CancelFunc) {
	t.Helper()
	addr := fmt.Sprintf("127.0.0.1:%d", freePort(t))
	r := New(addr)
	ctx, cancel := context.WithCancel(context.Background())
	go func() { _ = r.Run(ctx) }()
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		if c, err := net.DialTimeout("tcp", addr, 100*time.Millisecond); err == nil {
			c.Close()
			break
		}
		time.Sleep(20 * time.Millisecond)
	}
	return addr, cancel
}

func TestTCPRendezvous(t *testing.T) {
	addr, cancel := startRelay(t)
	defer cancel()
	token := make([]byte, tokenLen)
	_, _ = rand.Read(token)

	// Сторона B (условный «сервер») дозванивается первой и ждёт.
	bConn, err := net.Dial("tcp", addr)
	if err != nil {
		t.Fatalf("dial B: %v", err)
	}
	defer bConn.Close()
	if _, err := bConn.Write(TCPHello(RoleB, token)); err != nil {
		t.Fatalf("hello B: %v", err)
	}

	time.Sleep(100 * time.Millisecond)

	aConn, err := net.Dial("tcp", addr)
	if err != nil {
		t.Fatalf("dial A: %v", err)
	}
	defer aConn.Close()
	if _, err := aConn.Write(TCPHello(RoleA, token)); err != nil {
		t.Fatalf("hello A: %v", err)
	}

	// A → B
	msg := []byte("hello-through-relay")
	if _, err := aConn.Write(msg); err != nil {
		t.Fatalf("write A: %v", err)
	}
	got := make([]byte, len(msg))
	bConn.SetReadDeadline(time.Now().Add(2 * time.Second))
	if _, err := readFull(bConn, got); err != nil {
		t.Fatalf("read B: %v", err)
	}
	if string(got) != string(msg) {
		t.Fatalf("A→B: got %q want %q", got, msg)
	}

	// B → A
	msg2 := []byte("reply-back")
	if _, err := bConn.Write(msg2); err != nil {
		t.Fatalf("write B: %v", err)
	}
	got2 := make([]byte, len(msg2))
	aConn.SetReadDeadline(time.Now().Add(2 * time.Second))
	if _, err := readFull(aConn, got2); err != nil {
		t.Fatalf("read A: %v", err)
	}
	if string(got2) != string(msg2) {
		t.Fatalf("B→A: got %q want %q", got2, msg2)
	}
	t.Logf("relay TCP rendezvous OK")
}

func TestUDPRelay(t *testing.T) {
	addr, cancel := startRelay(t)
	defer cancel()
	token := make([]byte, tokenLen)
	_, _ = rand.Read(token)

	ua, err := net.Dial("udp", addr)
	if err != nil {
		t.Fatalf("dial A: %v", err)
	}
	defer ua.Close()
	ub, err := net.Dial("udp", addr)
	if err != nil {
		t.Fatalf("dial B: %v", err)
	}
	defer ub.Close()

	// Регистрируем обе стороны.
	_, _ = ua.Write(UDPReg(RoleA, token))
	_, _ = ub.Write(UDPReg(RoleB, token))
	time.Sleep(150 * time.Millisecond)

	// A → B через ретранслятор.
	payload := []byte("udp-datagram-payload")
	if _, err := ua.Write(payload); err != nil {
		t.Fatalf("write A: %v", err)
	}
	buf := make([]byte, 1500)
	ub.SetReadDeadline(time.Now().Add(2 * time.Second))
	n, err := ub.Read(buf)
	if err != nil {
		t.Fatalf("read B: %v", err)
	}
	if string(buf[:n]) != string(payload) {
		t.Fatalf("A→B udp: got %q want %q", buf[:n], payload)
	}
	t.Logf("relay UDP forward OK")
}

func readFull(c net.Conn, b []byte) (int, error) {
	got := 0
	for got < len(b) {
		n, err := c.Read(b[got:])
		got += n
		if err != nil {
			return got, err
		}
	}
	return got, nil
}
