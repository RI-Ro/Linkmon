// Package relay — рандеву-ретранслятор для измерений между двумя агентами за NAT.
//
// Оба агента находятся за NAT и не могут принять входящее соединение, но оба могут установить
// ИСХОДЯЩЕЕ соединение к серверу. Ретранслятор на сервере сводит две стороны одной сессии по
// общему токену и «сшивает» их трафик:
//
//   - TCP: каждая сторона дозванивается и шлёт hello = magic | role('A'|'B') | token(16);
//     как только пришли обе стороны одного токена — байты копируются в обе стороны (io.Copy).
//   - UDP: каждая сторона регистрируется датаграммой REG | role | token(16); дальше датаграммы
//     от одной стороны пересылаются другой как есть (сохраняются seq/timestamp bwtest → потери
//     и джиттер считаются корректно).
//
// Прямой путь (hole punching) агенты пробуют сами; ретранслятор — надёжный запасной путь.
package relay

import (
	"context"
	"encoding/hex"
	"errors"
	"io"
	"net"
	"sync"
	"time"
)

const (
	magic      = 'L' // TCP hello[0]
	roleA      = 'A'
	roleB      = 'B'
	tokenLen   = 16
	pairWait   = 60 * time.Second // сколько ждём вторую сторону
	udpIdle    = 5 * time.Minute
	tcpHelloTO = 30 * time.Second
)

// Relay слушает TCP и UDP на одном порту и сшивает пары сессий по токену.
type Relay struct {
	addr string

	mu      sync.Mutex
	tcpWait map[string]chan net.Conn // токен+роль → канал ожидающего партнёра
	udpSess map[string]*udpPair      // токен → пара UDP-адресов
}

type udpPair struct {
	a, b *net.UDPAddr
	seen time.Time
}

func New(addr string) *Relay {
	return &Relay{addr: addr, tcpWait: map[string]chan net.Conn{}, udpSess: map[string]*udpPair{}}
}

// Run слушает до отмены контекста.
func (r *Relay) Run(ctx context.Context) error {
	lc := net.ListenConfig{}
	ln, err := lc.Listen(ctx, "tcp", r.addr)
	if err != nil {
		return err
	}
	pc, err := lc.ListenPacket(ctx, "udp", r.addr)
	if err != nil {
		ln.Close()
		return err
	}
	udp := pc.(*net.UDPConn)
	go func() { <-ctx.Done(); ln.Close(); udp.Close() }()
	go r.udpLoop(udp)
	for {
		c, err := ln.Accept()
		if err != nil {
			return nil
		}
		go r.handleTCP(c)
	}
}

func (r *Relay) handleTCP(conn net.Conn) {
	hdr := make([]byte, 2+tokenLen)
	conn.SetReadDeadline(time.Now().Add(tcpHelloTO))
	if _, err := io.ReadFull(conn, hdr); err != nil || hdr[0] != magic {
		conn.Close()
		return
	}
	conn.SetReadDeadline(time.Time{})
	role := hdr[1]
	token := hex.EncodeToString(hdr[2 : 2+tokenLen])
	if role != roleA && role != roleB {
		conn.Close()
		return
	}
	// Ключи ожидания: сторона A ждёт B и наоборот.
	myKey := token + string(rune(role))
	other := roleA
	if role == roleA {
		other = roleB
	}
	otherKey := token + string(rune(other))

	r.mu.Lock()
	if peerCh, ok := r.tcpWait[otherKey]; ok {
		// Партнёр уже ждёт — сшиваем.
		delete(r.tcpWait, otherKey)
		r.mu.Unlock()
		peerCh <- conn
		return
	}
	// Партнёра ещё нет — ждём его сами.
	ch := make(chan net.Conn, 1)
	r.tcpWait[myKey] = ch
	r.mu.Unlock()

	select {
	case peer := <-ch:
		pipe(conn, peer)
	case <-time.After(pairWait):
		r.mu.Lock()
		if r.tcpWait[myKey] == ch {
			delete(r.tcpWait, myKey)
		}
		r.mu.Unlock()
		conn.Close()
	}
}

// pipe копирует байты в обе стороны и закрывает оба соединения по завершении.
func pipe(a, b net.Conn) {
	done := make(chan struct{}, 2)
	cp := func(dst, src net.Conn) {
		_, _ = io.Copy(dst, src)
		done <- struct{}{}
	}
	go cp(a, b)
	go cp(b, a)
	<-done
	a.Close()
	b.Close()
	<-done
}

// udpLoop регистрирует стороны и пересылает датаграммы между ними.
// Управляющая датаграмма: "REG" | role(1) | token(16). Остальные — форвардятся партнёру.
func (r *Relay) udpLoop(udp *net.UDPConn) {
	buf := make([]byte, 65535)
	ticker := time.NewTicker(time.Minute)
	defer ticker.Stop()
	go func() {
		for range ticker.C {
			r.gcUDP()
		}
	}()
	for {
		n, from, err := udp.ReadFromUDP(buf)
		if err != nil {
			return
		}
		if n == 4+tokenLen && string(buf[:3]) == "REG" {
			role := buf[3]
			token := hex.EncodeToString(buf[4 : 4+tokenLen])
			r.registerUDP(token, role, from)
			continue
		}
		// Данные: находим партнёра по адресу отправителя и пересылаем.
		if to := r.udpPeer(from); to != nil {
			_, _ = udp.WriteToUDP(buf[:n], to)
		}
	}
}

func (r *Relay) registerUDP(token string, role byte, addr *net.UDPAddr) {
	r.mu.Lock()
	defer r.mu.Unlock()
	p := r.udpSess[token]
	if p == nil {
		p = &udpPair{}
		r.udpSess[token] = p
	}
	if role == roleA {
		p.a = addr
	} else {
		p.b = addr
	}
	p.seen = time.Now()
}

func (r *Relay) udpPeer(from *net.UDPAddr) *net.UDPAddr {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, p := range r.udpSess {
		if p.a != nil && sameAddr(p.a, from) {
			p.seen = time.Now()
			return p.b
		}
		if p.b != nil && sameAddr(p.b, from) {
			p.seen = time.Now()
			return p.a
		}
	}
	return nil
}

func (r *Relay) gcUDP() {
	r.mu.Lock()
	defer r.mu.Unlock()
	for k, p := range r.udpSess {
		if time.Since(p.seen) > udpIdle {
			delete(r.udpSess, k)
		}
	}
}

func sameAddr(a, b *net.UDPAddr) bool {
	return a.Port == b.Port && a.IP.Equal(b.IP)
}

// ---------- Клиентская сторона (агент) ----------

// TCPHello формирует hello для TCP-стороны.
func TCPHello(role byte, token []byte) []byte {
	h := make([]byte, 2+tokenLen)
	h[0] = magic
	h[1] = role
	copy(h[2:], token)
	return h
}

// UDPReg формирует регистрационную датаграмму для UDP-стороны.
func UDPReg(role byte, token []byte) []byte {
	b := make([]byte, 4+tokenLen)
	copy(b, "REG")
	b[3] = role
	copy(b[4:], token)
	return b
}

// RoleA/RoleB — роли сторон (клиент/сервер измерения; для ретранслятора важна лишь парность).
const (
	RoleA = roleA
	RoleB = roleB
)

// ErrNoPeer возвращается, когда партнёр не подключился вовремя.
var ErrNoPeer = errors.New("relay: peer did not arrive")
