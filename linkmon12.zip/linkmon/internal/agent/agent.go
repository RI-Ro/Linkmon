// Package agent — измерительный агент: регистрируется на сервере, получает каналы,
// измеряет их, буферизует результаты до подтверждения и выполняет команды сервера.
package agent

import (
	"context"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/example/linkmon/internal/api"
	"github.com/example/linkmon/internal/bwtest"
	"github.com/example/linkmon/internal/clock"
	"github.com/example/linkmon/internal/proto"
)

type Agent struct {
	cfg      *Config
	server   ServerConn
	version  string
	log      *slog.Logger
	id       *Identity
	client   *Client
	spool    *Spool
	mgr      *Manager
	clock    *clock.Monitor
	results  chan api.Interval
	loads    chan api.IfaceLoad
	notify   chan struct{}
	reload   chan struct{}
	revision string
}

// Run поднимает по одному независимому аплинку на каждый сервер из конфигурации
// и работает, пока не отменят контекст. Часы (adjtimex) общие на процесс.
func Run(ctx context.Context, cfg *Config, version string, log *slog.Logger) error {
	clk := clock.NewMonitor(cfg.Agent.MaxClockErrUS)
	go clk.Run(ctx)

	// Сервер тестов пропускной способности — один на процесс (peer-to-peer между агентами),
	// не зависит от аплинков. Слушает TCP+UDP на заданном порту.
	if port := cfg.Agent.BWTestPort; port > 0 {
		srv := bwtest.NewServer(fmt.Sprintf(":%d", port))
		go func() {
			if err := srv.Run(ctx); err != nil && ctx.Err() == nil {
				log.Error("bwtest server stopped", "err", err)
			}
		}()
		log.Info("bwtest server listening", "port", port)
	}

	servers := cfg.Servers2()
	var wg sync.WaitGroup
	for _, sv := range servers {
		sv := sv
		wg.Add(1)
		go func() {
			defer wg.Done()
			ulog := log.With("server", sv.Name, "url", sv.URL)
			// Каждый аплинк переживает временную недоступность сервера: при фатальной
			// ошибке (например, не читается CA) логируем и не роняем остальные аплинки.
			if err := runUplink(ctx, cfg, sv, clk, version, ulog); err != nil && ctx.Err() == nil {
				ulog.Error("uplink stopped", "err", err)
			}
		}()
	}
	log.Info("agent started", "servers", len(servers))
	wg.Wait()
	return ctx.Err()
}

// runUplink — весь жизненный цикл работы с одним сервером.
func runUplink(ctx context.Context, cfg *Config, sv ServerConn, clk *clock.Monitor, version string, log *slog.Logger) error {
	id, err := LoadOrEnroll(ctx, cfg, sv, version, log)
	if err != nil {
		return err
	}
	log = log.With("agent_id", id.AgentID)
	sp, err := OpenSpool(filepath.Join(sv.StateDir(), "spool"), cfg.Agent.SpoolMaxMB, log)
	if err != nil {
		return err
	}
	a := &Agent{
		cfg: cfg, server: sv, version: version, log: log, id: id, spool: sp, clock: clk,
		client:  NewClient(sv.URL, id.TLSConfig()),
		results: make(chan api.Interval, 4096),
		loads:   make(chan api.IfaceLoad, 256),
		notify:  make(chan struct{}, 1),
		reload:  make(chan struct{}, 1),
	}
	a.mgr = NewManager(a.results, a.loads, clk, cfg.Allow, cfg.Device, cfg.SysDevice, log)

	// Измерения стартуют сразу из кэша, даже если сервер сейчас недоступен:
	// именно в такие моменты данные нужнее всего, а spool их сохранит.
	if cached, err := a.loadCachedConfig(); err == nil {
		a.mgr.Apply(ctx, cached.Channels)
		a.mgr.ApplyMonitors(ctx, cached.Monitors, cfg.AllowIface)
		a.revision = cached.Revision
		log.Info("cached configuration applied", "channels", len(cached.Channels), "monitors", len(cached.Monitors))
	}
	// Сообщаем серверу актуальные capabilities: он заведёт новые каналы и обновит
	// параметры существующих (скорость/интервал/метки), если конфиг агента поменялся.
	a.reportCapabilities(ctx)

	var wg sync.WaitGroup
	spawn := func(f func(context.Context)) {
		wg.Add(1)
		go func() { defer wg.Done(); f(ctx) }()
	}
	spawn(func(ctx context.Context) { collect(ctx, a.results, a.loads, sp, a.notify, log) })
	spawn((&uploader{spool: sp, client: a.client, notify: a.notify, log: log}).Run)
	spawn(a.configLoop)
	spawn(a.heartbeatLoop)
	spawn(a.retentionLoop)
	spawn(func(ctx context.Context) { id.RenewLoop(ctx, a.client, log) })

	a.commandLoop(ctx)
	a.mgr.StopAll()
	wg.Wait()
	return ctx.Err()
}

// reportCapabilities отправляет серверу текущие capabilities агента, чтобы он
// синхронизировал набор и параметры каналов. Ошибки не фатальны — повторим позже.
func (a *Agent) reportCapabilities(ctx context.Context) {
	if err := a.client.Do(ctx, http.MethodPost, "/v1/agent/capabilities", a.cfg.Capabilities(), nil, 30*time.Second); err != nil {
		a.log.Debug("capabilities report failed", "err", err)
	}
	a.reportInterfaces(ctx)
}

// reportInterfaces отправляет серверу список интерфейсов хоста, чтобы каналы можно было
// настраивать с сервера (выбор интерфейса из реально существующих).
func (a *Agent) reportInterfaces(ctx context.Context) {
	rep := api.InterfacesReport{Interfaces: discoverInterfaces()}
	if err := a.client.Do(ctx, http.MethodPost, "/v1/agent/interfaces", rep, nil, 30*time.Second); err != nil {
		a.log.Debug("interfaces report failed", "err", err)
	}
}

// retentionLoop удаляет неотправленные данные старше срока хранения (по умолчанию 48 ч),
// чтобы при долгой недоступности сервера агент не копил устаревшую историю бесконечно.
func (a *Agent) retentionLoop(ctx context.Context) {
	t := time.NewTicker(time.Hour)
	defer t.Stop()
	for {
		if dropped := a.spool.PruneOlderThan(a.cfg.RetentionDur()); dropped > 0 {
			a.log.Info("spool retention: dropped stale batches", "count", dropped, "older_than", a.cfg.RetentionDur())
		}
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
	}
}

func (a *Agent) configLoop(ctx context.Context) {
	t := time.NewTicker(5 * time.Minute)
	defer t.Stop()
	first := true
	for {
		// Периодически повторяем отчёт о capabilities (кроме самого первого прохода —
		// его уже сделали при старте), чтобы правки конфига агента доходили без перезапуска.
		if !first {
			a.reportCapabilities(ctx)
		}
		first = false
		if err := a.syncConfig(ctx); err != nil && ctx.Err() == nil {
			a.log.Warn("config sync failed", "err", err)
		}
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		case <-a.reload:
		}
	}
}

func (a *Agent) syncConfig(ctx context.Context) error {
	var c api.AgentConfig
	if err := a.client.Do(ctx, http.MethodGet, "/v1/agent/config", nil, &c, 30*time.Second); err != nil {
		return err
	}
	if c.Revision == a.revision {
		return nil
	}
	a.mgr.Apply(ctx, c.Channels)
	a.mgr.ApplyMonitors(ctx, c.Monitors, a.cfg.AllowIface)
	a.revision = c.Revision
	if err := a.saveCachedConfig(c); err != nil {
		a.log.Warn("config cache write failed", "err", err)
	}
	a.log.Info("configuration applied", "revision", c.Revision,
		"channels", a.mgr.Count(), "monitors", a.mgr.MonitorCount())
	return nil
}

func (a *Agent) cachePath() string { return filepath.Join(a.server.StateDir(), "config.json") }

func (a *Agent) saveCachedConfig(c api.AgentConfig) error {
	b, err := json.Marshal(c)
	if err != nil {
		return err
	}
	return writeFileAtomic(a.cachePath(), b, 0o600)
}

func (a *Agent) loadCachedConfig() (api.AgentConfig, error) {
	var c api.AgentConfig
	b, err := os.ReadFile(a.cachePath())
	if err != nil {
		return c, err
	}
	return c, json.Unmarshal(b, &c)
}

func (a *Agent) heartbeatLoop(ctx context.Context) {
	t := time.NewTicker(30 * time.Second)
	defer t.Stop()
	for {
		st := a.clock.State()
		hb := api.Heartbeat{Version: a.version, ClockSynced: st.Synced, ClockErrUS: st.ErrUS,
			Sessions: a.mgr.Count(), SpoolBatches: a.spool.Count()}
		if err := a.client.Do(ctx, http.MethodPost, "/v1/agent/heartbeat", hb, nil, 15*time.Second); err != nil && ctx.Err() == nil {
			a.log.Debug("heartbeat failed", "err", err)
		}
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
	}
}

// commandLoop — long-poll команд сервера. Соединение открывает агент, поэтому он может стоять за NAT.
func (a *Agent) commandLoop(ctx context.Context) {
	for ctx.Err() == nil {
		var cmds []api.Command
		if err := a.client.Do(ctx, http.MethodGet, "/v1/agent/commands?wait=30", nil, &cmds, 45*time.Second); err != nil {
			if ctx.Err() != nil {
				return
			}
			a.log.Debug("command poll failed", "err", err)
			select {
			case <-ctx.Done():
				return
			case <-time.After(5 * time.Second):
			}
			continue
		}
		for _, c := range cmds {
			switch c.Kind {
			case api.CmdReloadConfig:
				select {
				case a.reload <- struct{}{}:
				default:
				}
			case api.CmdRunTest:
				var p api.RunTestPayload
				if err := json.Unmarshal(c.Payload, &p); err != nil {
					a.log.Warn("bad run_test payload", "id", c.ID, "err", err)
					continue
				}
				go a.runTest(ctx, p)
			case api.CmdRunBWTest:
				var p api.RunBWTestPayload
				if err := json.Unmarshal(c.Payload, &p); err != nil {
					a.log.Warn("bad run_bwtest payload", "id", c.ID, "err", err)
					continue
				}
				go a.runBWTest(ctx, p)
			default:
				a.log.Warn("unknown command", "kind", c.Kind)
			}
		}
	}
}

// runTest — разовый тест по команде сервера (например, по группе каналов) в момент StartAt.
func (a *Agent) runTest(ctx context.Context, p api.RunTestPayload) {
	log := a.log.With("run_id", p.RunID)
	if d := time.Until(p.StartAt); d > 0 {
		select {
		case <-ctx.Done():
			return
		case <-time.After(d):
		}
	}
	dur := time.Duration(min(max(p.DurationSec, 1), 600)) * time.Second
	start := time.Now()
	res := api.TestResult{RunID: p.RunID, Errors: map[int64]string{}}
	out := make(chan api.Interval, len(p.ChannelIDs)*2+1)
	var mu sync.Mutex
	var wg sync.WaitGroup
	for _, id := range p.ChannelIDs {
		c, ok := a.mgr.Channel(id)
		if !ok {
			res.Errors[id] = "channel is not active on agent"
			continue
		}
		if p.PPS > 0 {
			c.PPS = min(p.PPS, 1000)
		}
		if p.PacketSize > 0 {
			c.PacketSize = p.PacketSize
		}
		s := newSession(c, sessionOpts{device: a.cfg.Device(c.Interface), width: dur, origin: start.UnixNano(), flags: proto.FlagTest, duration: dur, forceFinal: true},
			a.clock.OneWayOK, log.With("channel_id", id))
		wg.Add(1)
		go func() {
			defer wg.Done()
			if err := s.Run(ctx, out); err != nil {
				mu.Lock()
				res.Errors[id] = err.Error()
				mu.Unlock()
			}
		}()
	}
	wg.Wait()
	close(out)
	for iv := range out {
		res.Results = append(res.Results, iv)
	}
	log.Info("test finished", "results", len(res.Results), "errors", len(res.Errors))

	for attempt := 1; attempt <= 5; attempt++ {
		err := a.client.Do(ctx, http.MethodPost, "/v1/agent/test-results", res, nil, 30*time.Second)
		if err == nil || ctx.Err() != nil {
			return
		}
		log.Warn("test result upload failed", "attempt", attempt, "err", err)
		time.Sleep(10 * time.Second)
	}
}

// runBWTest — тест пропускной способности против другого агента (роль клиента).
// Агент-сервер уже слушает bwtest-порт; здесь мы подключаемся к нему как клиент,
// прогоняем нагрузку с заданными параметрами и возвращаем итог серверу LinkMon.
func (a *Agent) runBWTest(ctx context.Context, p api.RunBWTestPayload) {
	log := a.log.With("bw_run_id", p.RunID)
	if d := time.Until(p.StartAt); d > 0 {
		select {
		case <-ctx.Done():
			return
		case <-time.After(d):
		}
	}
	res := api.BWTestResult{RunID: p.RunID}
	bp := bwtest.Params{
		Proto:       p.Params.Proto,
		DurationSec: p.Params.DurationSec,
		Streams:     p.Params.Streams,
		LengthBytes: p.Params.LengthBytes,
		TargetMbps:  p.Params.TargetMbps,
		Reverse:     p.Params.Reverse,
		DSCP:        p.Params.DSCP,
	}
	// Ограничим общее время выполнения на случай, если партнёр недоступен.
	rctx, cancel := context.WithTimeout(ctx, time.Duration(bp.DurationSec+60)*time.Second)
	var r bwtest.Result
	var err error
	if p.RelayAddr != "" {
		// Релейный режим (оба агента за NAT): подключаемся к ретранслятору с общим токеном.
		token, terr := hex.DecodeString(p.RelayToken)
		if terr != nil {
			cancel()
			log.Warn("bad relay token", "err", terr)
			return
		}
		role := p.Role
		if role == "" {
			role = "client"
		}
		r, err = bwtest.RunRelay(rctx, p.RelayAddr, token, role, bp)
		cancel()
		// Итог серверу LinkMon отправляет только клиентская сторона (как и в прямом режиме).
		if role != "client" {
			if err != nil {
				log.Warn("bwtest relay (server role) failed", "err", err)
			}
			return
		}
	} else {
		r, err = bwtest.RunClient(rctx, p.ServerAddr, bp)
		cancel()
	}
	if err != nil {
		res.Error = err.Error()
		log.Warn("bwtest failed", "err", err)
	} else {
		res.Result = &api.BWTestResultData{
			Proto: r.Proto, DurationSec: r.DurationSec, Bytes: r.Bytes, Mbps: r.Mbps,
			Packets: r.Packets, LostPackets: r.LostPackets, LossPct: r.LossPct,
			JitterMs: r.JitterMs, Retransmits: r.Retransmits, Streams: r.Streams, Reverse: r.Reverse,
		}
		log.Info("bwtest finished", "mbps", r.Mbps, "loss_pct", r.LossPct)
	}

	for attempt := 1; attempt <= 5; attempt++ {
		if err := a.client.Do(ctx, http.MethodPost, "/v1/agent/bwtest-results", res, nil, 30*time.Second); err == nil || ctx.Err() != nil {
			return
		}
		log.Warn("bwtest result upload failed", "attempt", attempt)
		time.Sleep(10 * time.Second)
	}
}
