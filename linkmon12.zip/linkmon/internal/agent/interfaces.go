package agent

import (
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/example/linkmon/internal/api"
)

// discoverInterfaces перечисляет сетевые интерфейсы хоста для отправки серверу: имя, MAC,
// адреса, номинальную скорость (из /sys/class/net/<if>/speed, если ядро её отдаёт) и статус.
// Так конфигурацию каналов можно задавать с сервера, а не перечислять интерфейсы в conf.yaml.
func discoverInterfaces() []api.HostInterface {
	ifaces, err := net.Interfaces()
	if err != nil {
		return nil
	}
	out := make([]api.HostInterface, 0, len(ifaces))
	for _, ifc := range ifaces {
		hi := api.HostInterface{
			Name:     ifc.Name,
			MAC:      ifc.HardwareAddr.String(),
			Up:       ifc.Flags&net.FlagUp != 0,
			Loopback: ifc.Flags&net.FlagLoopback != 0,
		}
		if addrs, err := ifc.Addrs(); err == nil {
			for _, a := range addrs {
				hi.Addrs = append(hi.Addrs, a.String())
			}
		}
		hi.SpeedMbit = readSpeedMbit(ifc.Name)
		out = append(out, hi)
	}
	return out
}

// readSpeedMbit читает /sys/class/net/<name>/speed (Мбит/с). Для VLAN/виртуальных обычно
// недоступно (-1 или ошибка) — тогда 0.
func readSpeedMbit(name string) int64 {
	b, err := os.ReadFile(filepath.Join("/sys/class/net", name, "speed"))
	if err != nil {
		return 0
	}
	v, err := strconv.ParseInt(strings.TrimSpace(string(b)), 10, 64)
	if err != nil || v < 0 {
		return 0
	}
	return v
}
