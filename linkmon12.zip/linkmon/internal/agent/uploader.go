package agent

import (
	"context"
	"fmt"
	"log/slog"
	"net/http"
	"time"

	"github.com/example/linkmon/internal/api"
)

// collect собирает интервалы качества и записи загрузки интерфейсов от всех горутин
// и пачками пишет их в spool одним батчом с общим batch_seq.
func collect(ctx context.Context, in <-chan api.Interval, loadIn <-chan api.IfaceLoad,
	sp *Spool, notify chan<- struct{}, log *slog.Logger) {
	const maxBuffered = 20000
	var buf []api.Interval
	var loadBuf []api.IfaceLoad
	flush := func() {
		if len(buf) == 0 && len(loadBuf) == 0 {
			return
		}
		if err := sp.Put(buf, loadBuf); err != nil {
			log.Error("spool write failed", "err", err, "intervals", len(buf), "loads", len(loadBuf))
			if len(buf) > maxBuffered {
				buf = buf[len(buf)-maxBuffered:]
			}
			if len(loadBuf) > maxBuffered {
				loadBuf = loadBuf[len(loadBuf)-maxBuffered:]
			}
			return
		}
		buf, loadBuf = nil, nil
		select {
		case notify <- struct{}{}:
		default:
		}
	}
	t := time.NewTicker(2 * time.Second)
	defer t.Stop()
	for {
		select {
		case iv := <-in:
			buf = append(buf, iv)
			if len(buf)+len(loadBuf) >= 500 {
				flush()
			}
		case ld := <-loadIn:
			loadBuf = append(loadBuf, ld)
			if len(buf)+len(loadBuf) >= 500 {
				flush()
			}
		case <-t.C:
			flush()
		case <-ctx.Done():
			flush()
			return
		}
	}
}

type uploader struct {
	spool  *Spool
	client *Client
	notify <-chan struct{}
	log    *slog.Logger
}

func (u *uploader) Run(ctx context.Context) {
	backoff := time.Second
	for {
		err := u.drain(ctx)
		wait := 10 * time.Second
		notify := u.notify
		if err != nil {
			if ctx.Err() != nil {
				return
			}
			u.log.Warn("upload failed, will retry", "err", err, "backoff", backoff)
			wait, notify = backoff, nil // при ошибке не долбим сервер по каждому новому батчу
			backoff = min(backoff*2, time.Minute)
		} else {
			backoff = time.Second
		}
		select {
		case <-ctx.Done():
			return
		case <-notify:
		case <-time.After(wait):
		}
	}
}

func (u *uploader) drain(ctx context.Context) error {
	seqs, err := u.spool.Pending()
	if err != nil {
		return err
	}
	for _, seq := range seqs {
		b, err := u.spool.Load(seq)
		if err != nil {
			u.log.Error("corrupted spool batch dropped", "seq", seq, "err", err)
			_ = u.spool.Remove(seq)
			continue
		}
		var ack api.Ack
		if err := u.client.Do(ctx, http.MethodPost, "/v1/agent/results", b, &ack, 60*time.Second); err != nil {
			return err
		}
		if ack.Seq != seq {
			return fmt.Errorf("server acked batch %d, expected %d", ack.Seq, seq)
		}
		if err := u.spool.Remove(seq); err != nil {
			return err
		}
	}
	return nil
}
