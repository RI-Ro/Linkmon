package agent

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"math/rand/v2"
	"net"
	"sync"
	"time"

	"github.com/example/linkmon/internal/api"
	"github.com/example/linkmon/internal/probe"
	"github.com/example/linkmon/internal/proto"
	"github.com/example/linkmon/internal/stats"
)

const (
	flushGrace = 3 * time.Second // ожидание опоздавших ответов перед закрытием интервала
	testGrace  = 2 * time.Second
)

type sessionOpts struct {
	device     string // устройство для SO_BINDTODEVICE; "" — без привязки
	width      time.Duration
	origin     int64 // начало отсчёта интервалов (0 — выравнивание по UTC)
	flags      uint8
	duration   time.Duration // 0 — бессрочно (постоянный мониторинг)
	forceFinal bool          // выдать незакрытый интервал при остановке (для разовых тестов)
}

// session — измерение одного канала: интерфейс × рефлектор × DSCP.
// Внутри три горутины: отправка, приём, закрытие интервалов.
type session struct {
	cfg  api.ChannelConfig
	opts sessionOpts
	agg  *stats.Aggregator
	log  *slog.Logger
}

func newSession(cfg api.ChannelConfig, o sessionOpts, oneWayOK func() bool, log *slog.Logger) *session {
	if o.width <= 0 {
		o.width = time.Minute
	}
	return &session{
		cfg: cfg, opts: o, log: log,
		agg: stats.NewAggregator(cfg.ChannelID, cfg.DSCP, o.width, o.origin, oneWayOK),
	}
}

func (s *session) Run(parent context.Context, out chan<- api.Interval) error {
	ip := net.ParseIP(s.cfg.ReflectorAddr).To4()
	if ip == nil {
		return fmt.Errorf("reflector address %q is not IPv4", s.cfg.ReflectorAddr)
	}
	port := s.cfg.ReflectorPort
	if port == 0 {
		port = api.DefaultReflectorPort
	}
	dst := &net.UDPAddr{IP: ip, Port: port}

	conn, err := probe.Listen(probe.Options{Device: s.opts.device, Source: s.cfg.SourceIP, TOS: s.cfg.DSCP << 2})
	if err != nil {
		return err
	}
	ctx, cancel := context.WithCancel(parent)
	var wg sync.WaitGroup
	wg.Add(2)
	go func() { defer wg.Done(); s.recvLoop(ctx, conn) }()
	go func() { defer wg.Done(); s.flushLoop(ctx, out) }()

	err = s.sendLoop(ctx, conn, dst)
	if err == nil && s.opts.duration > 0 {
		select { // разовый тест: даём дойти последним ответам
		case <-time.After(testGrace):
		case <-parent.Done():
		}
	}
	cancel()
	conn.Close()
	wg.Wait()

	if s.opts.forceFinal {
		for _, iv := range s.agg.Flush(time.Now(), 0, true) {
			select {
			case out <- iv:
			case <-time.After(5 * time.Second):
			}
		}
	}
	if errors.Is(err, context.Canceled) {
		return nil
	}
	return err
}

func (s *session) sendLoop(ctx context.Context, conn *probe.Conn, dst *net.UDPAddr) error {
	size := min(max(s.cfg.PacketSize, proto.HeaderLen), proto.MaxPacket)
	buf := make([]byte, size)
	pps := max(s.cfg.PPS, 1)
	period := time.Second / time.Duration(pps)
	rnd := rand.New(rand.NewPCG(uint64(time.Now().UnixNano()), s.cfg.SessionID))

	var deadline <-chan time.Time
	if s.opts.duration > 0 {
		t := time.NewTimer(s.opts.duration)
		defer t.Stop()
		deadline = t.C
	}
	timer := time.NewTimer(0)
	defer timer.Stop()

	var seq uint32
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-deadline:
			return nil
		case <-timer.C:
		}
		seq++
		var t1 int64
		if s.cfg.TWAMP {
			// TWAMP-Light: пробу отражает внешний аппаратный TWAMP-ответчик.
			t1, _ = proto.MarshalTWAMPSender(buf, seq, size)
		} else {
			p := proto.Packet{Flags: s.opts.flags, DSCPSent: uint8(s.cfg.DSCP), SessionID: s.cfg.SessionID, SeqTx: seq}
			p.T1 = time.Now().UnixNano()
			_ = p.Marshal(buf, s.cfg.SessionKey)
			t1 = p.T1
		}
		if _, err := conn.WriteToUDP(buf, dst); err != nil {
			// Пакет всё равно считаем отправленным: упавший линк должен быть виден как 100% потерь.
			s.log.Debug("send failed", "err", err)
		}
		s.agg.OnSent(t1)

		next := period
		if s.cfg.Poisson { // RFC 2330: пуассоновский поток не синхронизируется с периодическими процессами сети
			next = time.Duration(rnd.ExpFloat64() * float64(period))
		}
		timer.Reset(next)
	}
}

func (s *session) recvLoop(ctx context.Context, conn *probe.Conn) {
	buf := make([]byte, 2048)
	var p proto.Packet
	for {
		m, err := conn.Recv(buf)
		if err != nil {
			if ctx.Err() != nil || errors.Is(err, net.ErrClosed) {
				return
			}
			continue
		}
		if s.cfg.TWAMP {
			// Отражённый пакет от аппаратного TWAMP-ответчика. DSCP обратного направления
			// берём из TOS ядра; «прямой» DSCP ответчик не сообщает (перемаркировку туда не видим).
			r, perr := proto.UnmarshalTWAMPReply(buf[:m.N])
			if perr != nil {
				continue
			}
			bwd := -1
			if m.TOS >= 0 {
				bwd = m.TOS >> 2
			}
			s.agg.OnReply(stats.Sample{
				Seq: r.SenderSeq, T1: r.T1, T2: r.T2, T3: r.T3, T4: m.KernelTime.UnixNano(),
				FwdDSCP: -1, BwdDSCP: bwd,
			})
			continue
		}
		if proto.Unmarshal(buf[:m.N], s.cfg.SessionKey, &p) != nil || !p.IsReply() || p.SessionID != s.cfg.SessionID {
			continue
		}
		fwd, bwd := -1, -1
		if p.DSCPRecv != proto.DSCPUnknown {
			fwd = int(p.DSCPRecv)
		}
		if m.TOS >= 0 {
			bwd = m.TOS >> 2
		}
		s.agg.OnReply(stats.Sample{
			Seq: p.SeqTx, T1: p.T1, T2: p.T2, T3: p.T3, T4: m.KernelTime.UnixNano(),
			FwdDSCP: fwd, BwdDSCP: bwd,
		})
	}
}

func (s *session) flushLoop(ctx context.Context, out chan<- api.Interval) {
	t := time.NewTicker(time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case now := <-t.C:
			for _, iv := range s.agg.Flush(now, flushGrace, false) {
				select {
				case out <- iv:
				case <-ctx.Done():
					return
				}
			}
		}
	}
}
