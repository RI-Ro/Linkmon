package agent

import (
	"context"
	"crypto/tls"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// ProvisionOptions — параметры установки агента одной командой (минимум ручной правки конфига).
type ProvisionOptions struct {
	Servers    []string // host:port через запятую (агентский порт mTLS, обычно :8443)
	Token      string   // общий токен регистрации (необязателен: без него агент уйдёт в pending)
	Name       string   // понятное имя агента
	StateDir   string   // каталог состояния (по умолчанию рядом с конфигом)
	NoBind     bool     // не привязывать сокеты к интерфейсу (dev / конфиг с сервера)
	BWTestPort int      // порт слушателя нагрузочных тестов (0 — выключено)
	ConfigPath string   // куда записать conf.yaml
}

// Provision скачивает CA с каждого сервера и пишет минимальный conf.yaml, чтобы агент был готов
// к запуску без ручной правки. Конфигурация каналов далее задаётся с сервера.
//
// Пример:
//
//	agent --servers host:8443
//	agent --servers host1:8443,host2:8443 --token <tok> --name spb-gw
func Provision(ctx context.Context, o ProvisionOptions) error {
	if len(o.Servers) == 0 {
		return fmt.Errorf("provision: не задан ни один сервер (--servers host:port)")
	}
	cfgPath := o.ConfigPath
	if cfgPath == "" {
		cfgPath = "conf.yaml"
	}
	base, err := filepath.Abs(filepath.Dir(cfgPath))
	if err != nil {
		return err
	}
	stateDir := o.StateDir
	if stateDir == "" {
		stateDir = "state"
	}
	stateAbs := stateDir
	if !filepath.IsAbs(stateAbs) {
		stateAbs = filepath.Join(base, stateDir)
	}

	var b strings.Builder
	b.WriteString("# Сгенерировано `agent --servers ...`. Конфигурация каналов задаётся с сервера.\n")
	b.WriteString("agent:\n")
	if o.Name != "" {
		fmt.Fprintf(&b, "  name: %q\n", o.Name)
	}
	fmt.Fprintf(&b, "  state_dir: %q\n", stateDir)
	if o.NoBind {
		b.WriteString("  no_bind: true\n")
	}
	if o.BWTestPort > 0 {
		fmt.Fprintf(&b, "  bwtest_port: %d\n", o.BWTestPort)
	}
	b.WriteString("servers:\n")

	for i, hp := range o.Servers {
		hp = strings.TrimSpace(hp)
		if hp == "" {
			continue
		}
		name := serverName(hp, i)
		srvDir := filepath.Join(stateAbs, sanitizeName(name))
		if err := os.MkdirAll(srvDir, 0o700); err != nil {
			return err
		}
		caPath := filepath.Join(srvDir, "ca.crt")
		caPEM, err := fetchCA(ctx, hp)
		if err != nil {
			return fmt.Errorf("provision %s: %w", hp, err)
		}
		if err := writeFileAtomic(caPath, caPEM, 0o644); err != nil {
			return err
		}
		fmt.Fprintf(&b, "  - name: %q\n", name)
		fmt.Fprintf(&b, "    url: %q\n", "https://"+hp)
		fmt.Fprintf(&b, "    ca_file: %q\n", filepath.Join(srvDir, "ca.crt"))
		if o.Token != "" {
			fmt.Fprintf(&b, "    enroll_token: %q\n", o.Token)
		}
	}

	if err := writeFileAtomic(cfgPath, []byte(b.String()), 0o644); err != nil {
		return err
	}
	return nil
}

// fetchCA скачивает публичный CA сервера с GET /v1/ca. Проверку сертификата на этом шаге
// пропускаем (CA как раз и загружаем), дальше всё общение идёт с проверкой по этому CA.
func fetchCA(ctx context.Context, hostport string) ([]byte, error) {
	cli := &http.Client{
		Timeout: 15 * time.Second,
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{InsecureSkipVerify: true}, // bootstrap: CA ещё нет
		},
	}
	url := "https://" + hostport + "/v1/ca"
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}
	resp, err := cli.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("GET /v1/ca: статус %d", resp.StatusCode)
	}
	pem, err := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if err != nil {
		return nil, err
	}
	if !strings.Contains(string(pem), "BEGIN CERTIFICATE") {
		return nil, fmt.Errorf("сервер вернул не сертификат")
	}
	return pem, nil
}

func serverName(hostport string, i int) string {
	h := hostport
	if idx := strings.LastIndex(h, ":"); idx > 0 {
		h = h[:idx]
	}
	h = strings.Trim(h, "[]")
	if h == "" {
		return fmt.Sprintf("srv%d", i+1)
	}
	return h
}
