package bwtest

import (
	"context"
	"fmt"
	"net"
	"testing"
	"time"
)

// freePort подбирает свободный TCP-порт; тот же номер почти наверняка свободен и для UDP.
func freePort(t *testing.T) int {
	t.Helper()
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	defer l.Close()
	return l.Addr().(*net.TCPAddr).Port
}

func startServer(t *testing.T) (string, context.CancelFunc) {
	t.Helper()
	port := freePort(t)
	addr := fmt.Sprintf("127.0.0.1:%d", port)
	srv := NewServer(addr)
	ctx, cancel := context.WithCancel(context.Background())
	go func() { _ = srv.Run(ctx) }()
	// Дадим слушателям подняться.
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		c, err := net.DialTimeout("tcp", addr, 100*time.Millisecond)
		if err == nil {
			c.Close()
			break
		}
		time.Sleep(20 * time.Millisecond)
	}
	return addr, cancel
}

func TestTCPForward(t *testing.T) {
	addr, cancel := startServer(t)
	defer cancel()

	res, err := RunClient(context.Background(), addr, Params{Proto: "tcp", DurationSec: 1, Streams: 2})
	if err != nil {
		t.Fatalf("RunClient: %v", err)
	}
	if res.Bytes <= 0 || res.Mbps <= 0 {
		t.Fatalf("ожидали ненулевой upload, получили bytes=%d mbps=%.3f", res.Bytes, res.Mbps)
	}
	if res.Streams != 2 {
		t.Fatalf("streams=%d, ожидали 2", res.Streams)
	}
	t.Logf("TCP upload: %.1f Мбит/с, %d байт", res.Mbps, res.Bytes)
}

func TestTCPReverse(t *testing.T) {
	addr, cancel := startServer(t)
	defer cancel()

	res, err := RunClient(context.Background(), addr, Params{Proto: "tcp", DurationSec: 1, Streams: 1, Reverse: true})
	if err != nil {
		t.Fatalf("RunClient: %v", err)
	}
	if res.Bytes <= 0 || res.Mbps <= 0 {
		t.Fatalf("ожидали ненулевой download, получили bytes=%d mbps=%.3f", res.Bytes, res.Mbps)
	}
	if !res.Reverse {
		t.Fatalf("reverse-флаг потерян")
	}
	t.Logf("TCP download: %.1f Мбит/с, %d байт", res.Mbps, res.Bytes)
}

func TestUDPForward(t *testing.T) {
	addr, cancel := startServer(t)
	defer cancel()

	// Ограниченная полоса, чтобы тест был предсказуем и не залил CI.
	res, err := RunClient(context.Background(), addr, Params{
		Proto: "udp", DurationSec: 1, Streams: 1, LengthBytes: 1200, TargetMbps: 10,
	})
	if err != nil {
		t.Fatalf("RunClient: %v", err)
	}
	if res.Packets <= 0 {
		t.Fatalf("ожидали принятые пакеты, получили %d", res.Packets)
	}
	if res.LossPct < 0 || res.LossPct > 100 {
		t.Fatalf("некорректные потери: %.2f%%", res.LossPct)
	}
	t.Logf("UDP: %.1f Мбит/с, пакетов=%d, потери=%.2f%%, джиттер=%.3f мс",
		res.Mbps, res.Packets, res.LossPct, res.JitterMs)
}

func TestTCPRateLimited(t *testing.T) {
	addr, cancel := startServer(t)
	defer cancel()

	// Ограничим TCP до 50 Мбит/с — проверяем, что лимит работает не только для UDP.
	res, err := RunClient(context.Background(), addr, Params{
		Proto: "tcp", DurationSec: 2, Streams: 1, TargetMbps: 50, DSCP: 46,
	})
	if err != nil {
		t.Fatalf("RunClient: %v", err)
	}
	if res.Mbps <= 0 {
		t.Fatalf("нулевая скорость")
	}
	// Допускаем большой разброс на loopback, но лимит должен явно срезать скорость
	// значительно ниже нелимитированных десятков Гбит/с.
	if res.Mbps > 200 {
		t.Fatalf("лимит TCP не сработал: %.1f Мбит/с (ожидали ~50)", res.Mbps)
	}
	t.Logf("TCP лимит 50 Мбит/с → факт %.1f Мбит/с", res.Mbps)
}

func TestParamsNorm(t *testing.T) {
	p := Params{Proto: "udp", LengthBytes: 4}
	p.norm()
	if p.LengthBytes < udpHdrLen {
		t.Fatalf("UDP-длина не поднята до заголовка: %d", p.LengthBytes)
	}
	if p.DurationSec != 10 || p.Streams != 1 {
		t.Fatalf("дефолты не применились: dur=%d streams=%d", p.DurationSec, p.Streams)
	}
	tcp := Params{Proto: "tcp"}
	tcp.norm()
	if tcp.LengthBytes != defLen {
		t.Fatalf("дефолтный размер блока = %d, ожидали %d", tcp.LengthBytes, defLen)
	}
	q := Params{Proto: "sctp", DurationSec: 999, Streams: 999, DSCP: 99}
	q.norm()
	if q.Proto != "tcp" || q.DurationSec != 10 || q.Streams != 1 || q.DSCP != 0 {
		t.Fatalf("нормализация границ не сработала: %+v", q)
	}
}
