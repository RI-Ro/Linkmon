package bwtest

import (
	"context"
	"encoding/binary"
	"fmt"
	"net"
	"sync"
	"sync/atomic"
	"time"
)

// RunClient проводит тест против сервера bwtest на addr ("host:port") с параметрами p.
// Возвращает объединённый результат: направление передачи данных считается на принимающей
// стороне, поэтому для upload (Reverse=false) берём статистику сервера, для download —
// свою. Управляющее соединение живёт всё время теста и переносит cookie/параметры/итог.
func RunClient(ctx context.Context, addr string, p Params) (Result, error) {
	p.norm()
	cookie := newCookie()

	ctl, err := dial(ctx, "tcp", addr)
	if err != nil {
		return Result{}, fmt.Errorf("bwtest: подключение к серверу: %w", err)
	}
	defer ctl.Close()

	if _, err := ctl.Write(append([]byte{roleCtl}, cookie...)); err != nil {
		return Result{}, err
	}
	if err := writeMsg(ctl, p); err != nil {
		return Result{}, err
	}
	var ack map[string]any
	ctl.SetReadDeadline(time.Now().Add(ctlTimeout))
	if err := readMsg(ctl, &ack); err != nil {
		return Result{}, fmt.Errorf("bwtest: сервер не подтвердил тест: %w", err)
	}
	if ok, _ := ack["ok"].(bool); !ok {
		return Result{}, fmt.Errorf("bwtest: сервер отклонил тест")
	}
	ctl.SetReadDeadline(time.Time{})

	local := &counters{}
	runCtx, cancel := context.WithTimeout(ctx, time.Duration(p.DurationSec)*time.Second)
	defer cancel()

	var wg sync.WaitGroup
	for i := 0; i < p.Streams; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if p.Proto == "udp" {
				clientUDP(runCtx, addr, cookie, p, local)
			} else {
				clientTCP(runCtx, addr, cookie, p, local)
			}
		}()
	}
	wg.Wait()

	// Сообщаем серверу о завершении и забираем его статистику.
	_ = writeMsg(ctl, map[string]any{"done": true})
	var srv Result
	ctl.SetReadDeadline(time.Now().Add(ctlTimeout))
	if err := readMsg(ctl, &srv); err != nil {
		return Result{}, fmt.Errorf("bwtest: не получен итог от сервера: %w", err)
	}

	res := Result{Proto: p.Proto, Streams: p.Streams, Reverse: p.Reverse, DurationSec: float64(p.DurationSec)}
	if p.Reverse {
		// download: данные принимал клиент — считаем по локальным счётчикам.
		res.Bytes = local.bytes.Load()
		res.Packets = local.pkts.Load()
		res.JitterMs = local.jitter.value()
		if p.Proto == "udp" {
			expected := local.maxSeq.Load() + 1
			if expected > res.Packets {
				res.LostPackets = expected - res.Packets
			}
			if expected > 0 {
				res.LossPct = 100 * float64(res.LostPackets) / float64(expected)
			}
		}
	} else {
		// upload: данные принимал сервер — берём его цифры как достоверные для приёма.
		res.Bytes = srv.Bytes
		res.Packets = srv.Packets
		res.LostPackets = srv.LostPackets
		res.LossPct = srv.LossPct
		res.JitterMs = srv.JitterMs
	}
	if res.DurationSec > 0 {
		res.Mbps = float64(res.Bytes) * 8 / 1e6 / res.DurationSec
	}
	return res, nil
}

// counters — потокобезопасные счётчики клиента (для download-направления и общей статистики).
type counters struct {
	bytes  atomic.Int64
	pkts   atomic.Int64
	maxSeq atomic.Int64
	jitter jitterCalc
}

func dial(ctx context.Context, network, addr string) (net.Conn, error) {
	var d net.Dialer
	dctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	return d.DialContext(dctx, network, addr)
}

func clientTCP(ctx context.Context, addr string, cookie []byte, p Params, c *counters) {
	conn, err := dial(ctx, "tcp", addr)
	if err != nil {
		return
	}
	defer conn.Close()
	setConnTOS(conn, p.DSCP)
	if _, err := conn.Write(append([]byte{roleData}, cookie...)); err != nil {
		return
	}
	go func() { <-ctx.Done(); conn.Close() }()

	if p.Reverse {
		// download: клиент читает поток от сервера.
		buf := make([]byte, 128*1024)
		for {
			n, err := conn.Read(buf)
			if n > 0 {
				c.bytes.Add(int64(n))
			}
			if err != nil {
				return
			}
		}
	}
	// upload: клиент льёт данные до отмены контекста, при необходимости ограничивая полосу.
	buf := make([]byte, p.LengthBytes)
	gap := pktGap(p.TargetMbps, p.Streams, p.LengthBytes)
	next := time.Now()
	for {
		select {
		case <-ctx.Done():
			return
		default:
		}
		n, err := conn.Write(buf)
		if n > 0 {
			c.bytes.Add(int64(n))
		}
		if err != nil {
			return
		}
		if gap > 0 {
			next = next.Add(gap)
			if d := time.Until(next); d > 0 {
				t := time.NewTimer(d)
				select {
				case <-ctx.Done():
					t.Stop()
					return
				case <-t.C:
				}
			}
		}
	}
}

func clientUDP(ctx context.Context, addr string, cookie []byte, p Params, c *counters) {
	conn, err := dial(ctx, "udp", addr)
	if err != nil {
		return
	}
	defer conn.Close()
	setConnTOS(conn, p.DSCP)
	go func() { <-ctx.Done(); conn.Close() }()

	// Для reverse-UDP клиент сперва «регистрирует» себя на сервере, отправив пустую
	// датаграмму с cookie, чтобы сервер узнал адрес; затем читает поток.
	pkt := make([]byte, p.LengthBytes)
	copy(pkt, cookie)

	if p.Reverse {
		hello := make([]byte, cookieLen+16)
		copy(hello, cookie)
		_, _ = conn.Write(hello)
		buf := make([]byte, 65535)
		for {
			n, err := conn.Read(buf)
			if err != nil {
				return
			}
			if n < cookieLen+16 {
				continue
			}
			c.bytes.Add(int64(n))
			c.pkts.Add(1)
			seq := int64(binary.BigEndian.Uint64(buf[cookieLen : cookieLen+8]))
			if seq > c.maxSeq.Load() {
				c.maxSeq.Store(seq)
			}
			sendNs := int64(binary.BigEndian.Uint64(buf[cookieLen+8 : cookieLen+16]))
			c.jitter.add(sendNs, time.Now().UnixNano())
		}
	}

	// forward-UDP: клиент шлёт с ограничением полосы (target_mbps на поток, если задан).
	gap := pktGap(p.TargetMbps, p.Streams, p.LengthBytes)
	var seq int64
	next := time.Now()
	for {
		select {
		case <-ctx.Done():
			return
		default:
		}
		binary.BigEndian.PutUint64(pkt[cookieLen:cookieLen+8], uint64(seq))
		binary.BigEndian.PutUint64(pkt[cookieLen+8:cookieLen+16], uint64(time.Now().UnixNano()))
		n, err := conn.Write(pkt)
		if n > 0 {
			c.bytes.Add(int64(n))
			c.pkts.Add(1)
		}
		if err != nil {
			return
		}
		seq++
		if gap > 0 {
			next = next.Add(gap)
			d := time.Until(next)
			if d > 0 {
				t := time.NewTimer(d)
				select {
				case <-ctx.Done():
					t.Stop()
					return
				case <-t.C:
				}
			}
		}
	}
}
