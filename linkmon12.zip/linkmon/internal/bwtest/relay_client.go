package bwtest

import (
	"context"
	"encoding/binary"
	"fmt"
	"net"
	"time"

	"github.com/example/linkmon/internal/relay"
)

// RunRelay проводит тест пропускной способности между двумя агентами за NAT через ретранслятор
// на сервере. Обе стороны устанавливают ИСХОДЯЩИЕ соединения к ретранслятору (что проходит через
// NAT), а он сшивает их по общему токену. role: "client" (создаёт нагрузку) или "server" (принимает).
//
// Каналы (по токену): управляющий (control) — надёжный TCP через ретранслятор для обмена
// параметрами и итогом; данные (data) — отдельная пара по токену data (TCP для proto=tcp,
// UDP для proto=udp). Релейный режим использует один поток данных (streams=1).
//
// Значимый результат возвращает клиентская сторона; серверная сторона участвует и возвращает
// свою половину. Джиттер/потери для UDP считаются на принимающей стороне (seq/timestamp
// сохраняются ретранслятором без изменений).
func RunRelay(ctx context.Context, relayAddr string, token []byte, role string, p Params) (Result, error) {
	p.norm()
	p.Streams = 1 // через ретранслятор — один поток данных
	ctlRole, dataRole := byte(relay.RoleA), byte(relay.RoleB)
	if role == "server" {
		ctlRole, dataRole = relay.RoleB, relay.RoleA
	}
	dataToken := make([]byte, len(token))
	copy(dataToken, token)
	if len(dataToken) > 0 {
		dataToken[0] ^= 0xff // отдельный токен для канала данных
	}

	ctl, err := dialRelayTCP(ctx, relayAddr, ctlRole, token)
	if err != nil {
		return Result{}, fmt.Errorf("bwtest relay: control: %w", err)
	}
	defer ctl.Close()

	if role == "client" {
		return runRelayClient(ctx, relayAddr, dataToken, dataRole, ctl, p)
	}
	return runRelayServer(ctx, relayAddr, dataToken, dataRole, ctl, p)
}

func runRelayClient(ctx context.Context, relayAddr string, dataToken []byte, dataRole byte, ctl net.Conn, p Params) (Result, error) {
	if err := writeMsg(ctl, p); err != nil {
		return Result{}, err
	}
	var ack map[string]any
	ctl.SetReadDeadline(time.Now().Add(ctlTimeout))
	if err := readMsg(ctl, &ack); err != nil {
		return Result{}, fmt.Errorf("bwtest relay: сервер не подтвердил: %w", err)
	}
	ctl.SetReadDeadline(time.Time{})

	local := &counters{}
	runCtx, cancel := context.WithTimeout(ctx, time.Duration(p.DurationSec)*time.Second)
	defer cancel()
	if p.Proto == "udp" {
		relayDataUDP(runCtx, relayAddr, dataToken, dataRole, p, !p.Reverse /*send*/, local)
	} else {
		relayDataTCP(runCtx, relayAddr, dataToken, dataRole, p, !p.Reverse /*send*/, local)
	}

	_ = writeMsg(ctl, map[string]any{"done": true})
	var srv Result
	ctl.SetReadDeadline(time.Now().Add(ctlTimeout))
	if err := readMsg(ctl, &srv); err != nil {
		return Result{}, fmt.Errorf("bwtest relay: нет итога от сервера: %w", err)
	}
	return mergeRelayResult(p, local, srv), nil
}

func runRelayServer(ctx context.Context, relayAddr string, dataToken []byte, dataRole byte, ctl net.Conn, p Params) (Result, error) {
	var params Params
	if err := readMsg(ctl, &params); err != nil {
		return Result{}, err
	}
	params.norm()
	params.Streams = 1
	if err := writeMsg(ctl, map[string]any{"ok": true}); err != nil {
		return Result{}, err
	}
	local := &counters{}
	runCtx, cancel := context.WithTimeout(ctx, time.Duration(params.DurationSec+5)*time.Second)
	defer cancel()
	// Сервер принимает при upload и отдаёт при reverse.
	if params.Proto == "udp" {
		relayDataUDP(runCtx, relayAddr, dataToken, dataRole, params, params.Reverse /*send when reverse*/, local)
	} else {
		relayDataTCP(runCtx, relayAddr, dataToken, dataRole, params, params.Reverse, local)
	}
	// Ждём done и отдаём свою статистику клиенту.
	var done map[string]any
	ctl.SetReadDeadline(time.Now().Add(time.Duration(params.DurationSec+30) * time.Second))
	_ = readMsg(ctl, &done)
	res := buildResult(params, local)
	_ = writeMsg(ctl, res)
	return res, nil
}

// relayDataTCP: если send — заливаем данные в data-пайп; иначе читаем (считаем принятое).
func relayDataTCP(ctx context.Context, relayAddr string, token []byte, role byte, p Params, send bool, c *counters) {
	conn, err := dialRelayTCP(ctx, relayAddr, role, token)
	if err != nil {
		return
	}
	defer conn.Close()
	go func() { <-ctx.Done(); conn.Close() }()
	if !send {
		buf := make([]byte, 128*1024)
		for {
			n, err := conn.Read(buf)
			if n > 0 {
				c.bytes.Add(int64(n))
			}
			if err != nil {
				return
			}
		}
	}
	buf := make([]byte, p.LengthBytes)
	gap := pktGap(p.TargetMbps, 1, p.LengthBytes)
	next := time.Now()
	for {
		select {
		case <-ctx.Done():
			return
		default:
		}
		n, err := conn.Write(buf)
		if n > 0 {
			c.bytes.Add(int64(n))
		}
		if err != nil {
			return
		}
		if gap > 0 {
			next = next.Add(gap)
			if d := time.Until(next); d > 0 {
				t := time.NewTimer(d)
				select {
				case <-ctx.Done():
					t.Stop()
					return
				case <-t.C:
				}
			}
		}
	}
}

// relayDataUDP: регистрируется в UDP-ретрансляторе и шлёт/принимает датаграммы seq|sendNanos.
func relayDataUDP(ctx context.Context, relayAddr string, token []byte, role byte, p Params, send bool, c *counters) {
	conn, err := dialContextUDP(ctx, relayAddr)
	if err != nil {
		return
	}
	defer conn.Close()
	go func() { <-ctx.Done(); conn.Close() }()
	_, _ = conn.Write(relay.UDPReg(role, token))
	time.Sleep(200 * time.Millisecond) // дать партнёру зарегистрироваться

	if !send {
		buf := make([]byte, 65535)
		for {
			select {
			case <-ctx.Done():
				return
			default:
			}
			n, err := conn.Read(buf)
			if err != nil {
				return
			}
			if n < 16 {
				continue
			}
			c.bytes.Add(int64(n))
			c.pkts.Add(1)
			seq := int64(binary.BigEndian.Uint64(buf[0:8]))
			if seq > c.maxSeq.Load() {
				c.maxSeq.Store(seq)
			}
			sendNs := int64(binary.BigEndian.Uint64(buf[8:16]))
			c.jitter.add(sendNs, time.Now().UnixNano())
		}
	}
	size := p.LengthBytes
	if size < 16 {
		size = 16
	}
	pkt := make([]byte, size)
	gap := pktGap(p.TargetMbps, 1, size)
	var seq int64
	next := time.Now()
	for {
		select {
		case <-ctx.Done():
			return
		default:
		}
		binary.BigEndian.PutUint64(pkt[0:8], uint64(seq))
		binary.BigEndian.PutUint64(pkt[8:16], uint64(time.Now().UnixNano()))
		n, err := conn.Write(pkt)
		if n > 0 {
			c.bytes.Add(int64(n))
			c.pkts.Add(1)
		}
		if err != nil {
			return
		}
		seq++
		if gap > 0 {
			next = next.Add(gap)
			if d := time.Until(next); d > 0 {
				time.Sleep(d)
			}
		}
	}
}

func buildResult(p Params, c *counters) Result {
	res := Result{Proto: p.Proto, Streams: 1, Reverse: p.Reverse, DurationSec: float64(p.DurationSec)}
	res.Bytes = c.bytes.Load()
	res.Packets = c.pkts.Load()
	if res.DurationSec > 0 {
		res.Mbps = float64(res.Bytes) * 8 / 1e6 / res.DurationSec
	}
	if p.Proto == "udp" {
		res.JitterMs = c.jitter.value()
		expected := c.maxSeq.Load() + 1
		if expected > res.Packets {
			res.LostPackets = expected - res.Packets
		}
		if expected > 0 {
			res.LossPct = 100 * float64(res.LostPackets) / float64(expected)
		}
	}
	return res
}

// mergeRelayResult: для upload берём цифры принявшей стороны (сервера), для download — свои.
func mergeRelayResult(p Params, local *counters, srv Result) Result {
	if p.Reverse {
		return buildResult(p, local)
	}
	srv.Proto, srv.Reverse, srv.Streams = p.Proto, p.Reverse, 1
	if srv.DurationSec <= 0 {
		srv.DurationSec = float64(p.DurationSec)
	}
	return srv
}

func dialRelayTCP(ctx context.Context, addr string, role byte, token []byte) (net.Conn, error) {
	conn, err := dial(ctx, "tcp", addr)
	if err != nil {
		return nil, err
	}
	if _, err := conn.Write(relay.TCPHello(role, token)); err != nil {
		conn.Close()
		return nil, err
	}
	return conn, nil
}

func dialContextUDP(ctx context.Context, addr string) (net.Conn, error) {
	return dial(ctx, "udp", addr)
}
