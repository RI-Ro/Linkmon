package bwtest

import (
	"context"
	"crypto/rand"
	"fmt"
	"net"
	"sync"
	"testing"
	"time"

	"github.com/example/linkmon/internal/relay"
)

func startRelay(t *testing.T) (string, context.CancelFunc) {
	t.Helper()
	l, _ := net.Listen("tcp", "127.0.0.1:0")
	addr := fmt.Sprintf("127.0.0.1:%d", l.Addr().(*net.TCPAddr).Port)
	l.Close()
	r := relay.New(addr)
	ctx, cancel := context.WithCancel(context.Background())
	go func() { _ = r.Run(ctx) }()
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		if c, err := net.DialTimeout("tcp", addr, 100*time.Millisecond); err == nil {
			c.Close()
			break
		}
		time.Sleep(20 * time.Millisecond)
	}
	return addr, cancel
}

// runPair запускает обе стороны релейного теста и возвращает результат клиента.
func runPair(t *testing.T, relayAddr string, p Params) Result {
	t.Helper()
	token := make([]byte, 16)
	_, _ = rand.Read(token)
	var wg sync.WaitGroup
	wg.Add(1)
	go func() { defer wg.Done(); _, _ = RunRelay(context.Background(), relayAddr, token, "server", p) }()
	time.Sleep(150 * time.Millisecond) // сервер дозванивается первым
	res, err := RunRelay(context.Background(), relayAddr, token, "client", p)
	if err != nil {
		t.Fatalf("client: %v", err)
	}
	wg.Wait()
	return res
}

func TestRelayTCPUpload(t *testing.T) {
	addr, cancel := startRelay(t)
	defer cancel()
	res := runPair(t, addr, Params{Proto: "tcp", DurationSec: 1})
	if res.Bytes <= 0 || res.Mbps <= 0 {
		t.Fatalf("нулевой upload через релей: %+v", res)
	}
	t.Logf("relay TCP upload: %.1f Мбит/с, %d байт", res.Mbps, res.Bytes)
}

func TestRelayUDP(t *testing.T) {
	addr, cancel := startRelay(t)
	defer cancel()
	res := runPair(t, addr, Params{Proto: "udp", DurationSec: 1, LengthBytes: 1200, TargetMbps: 10})
	if res.Packets <= 0 {
		t.Fatalf("нет принятых пакетов через релей: %+v", res)
	}
	if res.LossPct < 0 || res.LossPct > 100 {
		t.Fatalf("некорректные потери: %.2f", res.LossPct)
	}
	t.Logf("relay UDP: %.1f Мбит/с, пакетов=%d, потери=%.2f%%, джиттер=%.3f мс",
		res.Mbps, res.Packets, res.LossPct, res.JitterMs)
}
