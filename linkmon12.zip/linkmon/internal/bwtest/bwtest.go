// Package bwtest — двунаправленное тестирование пропускной способности между двумя точками
// (client ↔ server) по TCP и UDP с параметрами в духе iperf: длительность, число потоков,
// размер блока, целевая полоса (UDP), прямое/обратное/двунаправленное направление.
//
// Модель (упрощённый iperf3): клиент открывает управляющее TCP-соединение, передаёт cookie и
// параметры; затем поднимает потоки данных (TCP-соединения или UDP-потоки), помеченные тем же
// cookie, чтобы сервер сгруппировал их в одну сессию. По завершении сервер возвращает свою
// половину статистики (принятые байты/пакеты, для UDP — потери и джиттер), клиент считает свою.
//
// Пакет самодостаточен (только стандартная библиотека) и не зависит от остального кода.
package bwtest

import (
	"crypto/rand"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"time"
)

const (
	cookieLen  = 16
	udpHdrLen  = cookieLen + 16 // cookie(16) | seq(8) | sendNanos(8)
	roleCtl    = 'C'
	roleData   = 'D'
	defLen     = 1350 // размер блока по умолчанию (TCP и UDP), помещается в типовой MTU
	ctlTimeout = 30 * time.Second
)

// Params — параметры теста (задаются перед запуском, как в iperf).
type Params struct {
	Proto       string  `json:"proto"`        // tcp | udp
	DurationSec int     `json:"duration_sec"` // длительность нагрузки
	Streams     int     `json:"streams"`      // число параллельных потоков
	LengthBytes int     `json:"length_bytes"` // размер блока (0 — по умолчанию 1350)
	TargetMbps  float64 `json:"target_mbps"`  // целевая полоса, Мбит/с (0 — без ограничения); работает и для TCP, и для UDP
	Reverse     bool    `json:"reverse"`      // сервер шлёт клиенту (скачивание)
	DSCP        int     `json:"dscp"`         // метка DSCP (0..63) для пакетов теста; 0 — BE
}

func (p *Params) norm() {
	if p.Proto != "udp" {
		p.Proto = "tcp"
	}
	if p.DurationSec <= 0 || p.DurationSec > 600 {
		p.DurationSec = 10
	}
	if p.Streams <= 0 || p.Streams > 128 {
		p.Streams = 1
	}
	if p.LengthBytes <= 0 {
		p.LengthBytes = defLen
	}
	// UDP-датаграмма обязана вместить служебный заголовок cookie|seq|sendNanos.
	if p.Proto == "udp" && p.LengthBytes < udpHdrLen {
		p.LengthBytes = udpHdrLen
	}
	if p.DSCP < 0 || p.DSCP > 63 {
		p.DSCP = 0
	}
}

// Result — итог теста. Значения по обеим сторонам объединяются вызывающим.
type Result struct {
	Proto       string  `json:"proto"`
	DurationSec float64 `json:"duration_sec"`
	Bytes       int64   `json:"bytes"`        // переданный объём (полезная нагрузка)
	Mbps        float64 `json:"mbps"`         // средняя скорость
	Packets     int64   `json:"packets"`      // для UDP
	LostPackets int64   `json:"lost_packets"` // для UDP
	LossPct     float64 `json:"loss_pct"`     // для UDP
	JitterMs    float64 `json:"jitter_ms"`    // для UDP (RFC 1889)
	Retransmits int64   `json:"retransmits"`  // для TCP (оценка, если доступно)
	Streams     int     `json:"streams"`
	Reverse     bool    `json:"reverse"`
}

// ---------- Служебное ----------

// pktGap — пауза между отправками одного потока для удержания целевой полосы
// (targetMbps на все потоки суммарно). 0 — без ограничения. Работает и для TCP, и для UDP.
func pktGap(targetMbps float64, streams, lengthBytes int) time.Duration {
	if targetMbps <= 0 || streams <= 0 || lengthBytes <= 0 {
		return 0
	}
	perStream := targetMbps / float64(streams)
	if perStream <= 0 {
		return 0
	}
	bitsPerPkt := float64(lengthBytes) * 8
	return time.Duration(bitsPerPkt / (perStream * 1e6) * float64(time.Second))
}

func newCookie() []byte {
	c := make([]byte, cookieLen)
	_, _ = rand.Read(c)
	return c
}

func writeMsg(conn net.Conn, v any) error {
	b, err := json.Marshal(v)
	if err != nil {
		return err
	}
	var hdr [4]byte
	binary.BigEndian.PutUint32(hdr[:], uint32(len(b)))
	if _, err := conn.Write(hdr[:]); err != nil {
		return err
	}
	_, err = conn.Write(b)
	return err
}

func readMsg(conn net.Conn, v any) error {
	var hdr [4]byte
	if _, err := io.ReadFull(conn, hdr[:]); err != nil {
		return err
	}
	n := binary.BigEndian.Uint32(hdr[:])
	if n > 1<<20 {
		return fmt.Errorf("bwtest: control message too large")
	}
	b := make([]byte, n)
	if _, err := io.ReadFull(conn, b); err != nil {
		return err
	}
	return json.Unmarshal(b, v)
}
