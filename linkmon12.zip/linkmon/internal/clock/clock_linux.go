//go:build linux

// Package clock следит за синхронизацией системных часов (chrony/ntpd/ptp4l+phc2sys)
// через adjtimex. Однонаправленные задержки достоверны только при синхронных часах
// на обеих сторонах; RTT и джиттер от синхронизации не зависят.
package clock

import (
	"context"
	"sync/atomic"
	"time"

	"golang.org/x/sys/unix"
)

const (
	timeError = 5      // TIME_ERROR
	staUnsync = 0x0040 // STA_UNSYNC
)

type State struct {
	Synced bool  `json:"synced"`
	ErrUS  int64 `json:"err_us"` // оценка ошибки часов ядром, мкс
}

func Read() State {
	var tx unix.Timex // Modes == 0: только чтение, привилегии не нужны
	st, err := unix.Adjtimex(&tx)
	if err != nil {
		return State{ErrUS: -1}
	}
	return State{Synced: st != timeError && tx.Status&staUnsync == 0, ErrUS: int64(tx.Esterror)}
}

type Monitor struct {
	maxErrUS int64
	synced   atomic.Bool
	errUS    atomic.Int64
}

func NewMonitor(maxErrUS int64) *Monitor {
	if maxErrUS <= 0 {
		maxErrUS = 1000
	}
	m := &Monitor{maxErrUS: maxErrUS}
	m.update()
	return m
}

func (m *Monitor) update() {
	s := Read()
	m.synced.Store(s.Synced)
	m.errUS.Store(s.ErrUS)
}

func (m *Monitor) Run(ctx context.Context) {
	t := time.NewTicker(10 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			m.update()
		}
	}
}

func (m *Monitor) State() State { return State{Synced: m.synced.Load(), ErrUS: m.errUS.Load()} }

// OneWayOK — можно ли доверять однонаправленным задержкам, измеренным этим хостом.
func (m *Monitor) OneWayOK() bool {
	s := m.State()
	return s.Synced && s.ErrUS >= 0 && s.ErrUS <= m.maxErrUS
}
