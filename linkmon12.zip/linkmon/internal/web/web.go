// Package web — отдельное веб-приложение LinkMon: раздаёт SPA и проксирует admin-API к одному
// из нескольких измерительных серверов (linkmon-server). Список серверов и их адреса заданы в
// конфиге веб-приложения; в интерфейсе можно переключаться между ними, у каждого своя история.
//
// Маршрутизация:
//
//	GET  /api/servers      → список серверов {id,name} для переключателя в UI
//	ANY  /s/{id}/...        → реверс-прокси на <server.url>/... (admin API конкретного сервера)
//	*                       → SPA (index.html) из web_dir
//
// Идентификация/сессии остаются на стороне каждого linkmon-server: cookie сессии проксируется,
// а её Path переписывается в /s/{id}/, чтобы сессии разных серверов не конфликтовали в браузере.
package web

import (
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"path/filepath"
	"strings"
)

type ServerRef struct {
	ID                 string `yaml:"id" json:"id"`
	Name               string `yaml:"name" json:"name"`
	URL                string `yaml:"url" json:"-"` // admin API базовый URL (напр. https://host:8080)
	CAFile             string `yaml:"ca_file" json:"-"`
	InsecureSkipVerify bool   `yaml:"insecure_skip_verify" json:"-"`
}

type Config struct {
	Listen  string      `yaml:"listen"`
	WebDir  string      `yaml:"web_dir"`
	Servers []ServerRef `yaml:"servers"`
}

type Web struct {
	cfg     Config
	proxies map[string]*httputil.ReverseProxy
}

func New(cfg Config) (*Web, error) {
	if len(cfg.Servers) == 0 {
		return nil, fmt.Errorf("web: нужно задать хотя бы один сервер в servers")
	}
	w := &Web{cfg: cfg, proxies: map[string]*httputil.ReverseProxy{}}
	seen := map[string]bool{}
	for i := range cfg.Servers {
		s := &cfg.Servers[i]
		if s.ID == "" {
			s.ID = fmt.Sprintf("srv%d", i+1)
		}
		if s.Name == "" {
			s.Name = s.ID
		}
		if seen[s.ID] {
			return nil, fmt.Errorf("web: дублирующийся id сервера %q", s.ID)
		}
		seen[s.ID] = true
		p, err := w.buildProxy(*s)
		if err != nil {
			return nil, fmt.Errorf("web: сервер %s: %w", s.ID, err)
		}
		w.proxies[s.ID] = p
	}
	return w, nil
}

func (w *Web) buildProxy(s ServerRef) (*httputil.ReverseProxy, error) {
	target, err := url.Parse(s.URL)
	if err != nil {
		return nil, fmt.Errorf("некорректный url %q: %w", s.URL, err)
	}
	tr := &http.Transport{}
	if target.Scheme == "https" {
		tlsCfg := &tls.Config{MinVersion: tls.VersionTLS12, InsecureSkipVerify: s.InsecureSkipVerify}
		if s.CAFile != "" {
			pem, err := os.ReadFile(s.CAFile)
			if err != nil {
				return nil, fmt.Errorf("ca_file: %w", err)
			}
			pool := x509.NewCertPool()
			if !pool.AppendCertsFromPEM(pem) {
				return nil, fmt.Errorf("ca_file %q: нет сертификатов", s.CAFile)
			}
			tlsCfg.RootCAs = pool
		}
		tr.TLSClientConfig = tlsCfg
	}
	prefix := "/s/" + s.ID
	proxy := &httputil.ReverseProxy{
		Transport: tr,
		Director: func(r *http.Request) {
			r.URL.Scheme = target.Scheme
			r.URL.Host = target.Host
			r.Host = target.Host
			// Убираем префикс /s/{id}; остаток — путь на сервере.
			r.URL.Path = strings.TrimPrefix(r.URL.Path, prefix)
			if r.URL.Path == "" {
				r.URL.Path = "/"
			}
		},
		ModifyResponse: func(resp *http.Response) error {
			// Изолируем cookie сессии по серверу: Path → /s/{id}/.
			if cookies := resp.Header.Values("Set-Cookie"); len(cookies) > 0 {
				resp.Header.Del("Set-Cookie")
				for _, c := range cookies {
					resp.Header.Add("Set-Cookie", rewriteCookiePath(c, prefix+"/"))
				}
			}
			return nil
		},
	}
	return proxy, nil
}

// rewriteCookiePath заменяет (или добавляет) атрибут Path у Set-Cookie на нужный префикс.
func rewriteCookiePath(cookie, path string) string {
	parts := strings.Split(cookie, ";")
	found := false
	for i, p := range parts {
		if strings.HasPrefix(strings.ToLower(strings.TrimSpace(p)), "path=") {
			parts[i] = " Path=" + path
			found = true
		}
	}
	if !found {
		parts = append(parts, " Path="+path)
	}
	return strings.Join(parts, ";")
}

func (w *Web) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /api/servers", func(rw http.ResponseWriter, _ *http.Request) {
		rw.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(rw).Encode(w.cfg.Servers) // только id+name (URL/CA помечены json:"-")
	})
	mux.HandleFunc("/s/", func(rw http.ResponseWriter, r *http.Request) {
		// /s/{id}/...  → нужный прокси
		rest := strings.TrimPrefix(r.URL.Path, "/s/")
		id, _, _ := strings.Cut(rest, "/")
		p, ok := w.proxies[id]
		if !ok {
			http.Error(rw, "unknown server", http.StatusNotFound)
			return
		}
		p.ServeHTTP(rw, r)
	})
	if w.cfg.WebDir != "" {
		mux.Handle("/", spa(w.cfg.WebDir))
	}
	return mux
}

// spa раздаёт статику и отдаёт index.html для неизвестных путей (клиентская маршрутизация).
func spa(dir string) http.Handler {
	fs := http.FileServer(http.Dir(dir))
	index := filepath.Join(dir, "index.html")
	return http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		p := filepath.Join(dir, filepath.Clean(r.URL.Path))
		if st, err := os.Stat(p); err == nil && !st.IsDir() {
			fs.ServeHTTP(rw, r)
			return
		}
		http.ServeFile(rw, r, index)
	})
}
