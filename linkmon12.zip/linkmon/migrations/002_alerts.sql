-- 002_alerts.sql — алерты по каналам и агентам, стартовые SLA-профили

ALTER TABLE alerts ALTER COLUMN channel_id DROP NOT NULL;
ALTER TABLE alerts ADD COLUMN agent_id uuid REFERENCES agents(id) ON DELETE CASCADE;
ALTER TABLE alerts ADD COLUMN last_seen_at timestamptz;
ALTER TABLE alerts ADD CONSTRAINT alerts_subject_chk CHECK (channel_id IS NOT NULL OR agent_id IS NOT NULL);

-- Не больше одного открытого алерта одного вида на объект.
DROP INDEX IF EXISTS alerts_open;
CREATE UNIQUE INDEX alerts_open_uq ON alerts (
    COALESCE(channel_id, 0),
    COALESCE(agent_id, '00000000-0000-0000-0000-000000000000'::uuid),
    kind
) WHERE ended_at IS NULL;
CREATE INDEX alerts_started ON alerts (started_at DESC);

CREATE INDEX test_runs_created ON test_runs (created_at DESC);

INSERT INTO sla_profiles (name, max_rtt_ms, max_oneway_ms, max_jitter_ms, max_loss_pct, min_mos, allow_remarking, breach_intervals)
VALUES
    ('Голос (EF)',        150, 80,  10,  0.5, 4.0, false, 2),
    ('Видео (AF41)',      200, 120, 20,  1.0, NULL, false, 3),
    ('Бизнес-данные',     300, NULL, NULL, 2.0, NULL, true, 5)
ON CONFLICT (name) DO NOTHING;

CREATE VIEW v_alerts AS
SELECT al.id, al.kind, al.severity, al.started_at, al.ended_at, al.last_seen_at, al.details,
       al.channel_id, vc.channel, vc.dscp_name,
       COALESCE(al.agent_id, vc.agent_id) AS agent_id,
       COALESCE(a.hostname, vc.agent)     AS agent
FROM alerts al
LEFT JOIN v_channels vc ON vc.channel_id = al.channel_id
LEFT JOIN agents a      ON a.id = al.agent_id;
