-- 009_iface_monitor_authored.sql — защита server-authored мониторов от capabilities-реконсиляции.
-- Монитор загрузки, заведённый с сервера (для агента через --servers), не должен отключаться
-- периодическим reconcile из (пустых) capabilities такого агента.
ALTER TABLE iface_monitors ADD COLUMN server_authored boolean NOT NULL DEFAULT false;
