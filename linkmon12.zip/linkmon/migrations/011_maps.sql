-- 011_maps.sql — интерактивные карты сети (как в icinga2): узлы (агенты/рефлекторы) и связи
-- по каналам с отображением состояния. Много именованных карт (как дашборды), доступ как у
-- дашбордов (личный/по пользователям/общий). Граф (узлы с координатами + связи) хранится в jsonb.
CREATE TABLE maps (
    id          bigserial PRIMARY KEY,
    owner_id    bigint REFERENCES admin_users(id) ON DELETE SET NULL,
    name        text NOT NULL,
    visibility  text NOT NULL DEFAULT 'private' CHECK (visibility IN ('private', 'users', 'shared')),
    graph       jsonb NOT NULL DEFAULT '{"nodes":[],"edges":[]}',
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE map_shares (
    map_id  bigint NOT NULL REFERENCES maps(id) ON DELETE CASCADE,
    user_id bigint NOT NULL REFERENCES admin_users(id) ON DELETE CASCADE,
    PRIMARY KEY (map_id, user_id)
);
CREATE INDEX map_shares_user ON map_shares (user_id);
