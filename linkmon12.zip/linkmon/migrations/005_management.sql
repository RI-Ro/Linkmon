-- 005_management.sql — управление каналами/агентами/пользователями, дашборды, RLS.
--
-- Основные направления:
--   * понятные имена и теги каналов, авто-reconcile при смене конфигурации агента;
--   * понятное имя агента (на основе machine_id), выключение/удаление;
--   * пользователи с ролями (big_admin/admin/viewer) и областью видимости по группам,
--     проверяемой через RLS;
--   * кастомные дашборды с виджетами;
--   * подтверждение (ack) алертов для звуковой эскалации;
--   * тест одного канала и детальный статус прогона.

-- ---------- Агенты: понятное имя ----------

ALTER TABLE agents ADD COLUMN name text;
-- По умолчанию имя = hostname, а если он пуст — machine_id. Дальше администратор может задать своё.
UPDATE agents SET name = NULLIF(hostname, '') WHERE name IS NULL;
UPDATE agents SET name = machine_id WHERE name IS NULL OR name = '';

-- ---------- Каналы: понятное имя, теги, признак устаревания ----------

ALTER TABLE channels ADD COLUMN display_name text;          -- пользовательское имя, важнее авто-имени
ALTER TABLE channels ADD COLUMN tags text[] NOT NULL DEFAULT '{}';
-- stale = true: канал есть в БД, но в текущих capabilities агента его больше нет
-- (например, из конфига агента убрали DSCP или интерфейс). Не удаляем автоматически,
-- чтобы сохранить историю; администратор решает — удалить или оставить.
ALTER TABLE channels ADD COLUMN stale boolean NOT NULL DEFAULT false;
ALTER TABLE channels ADD COLUMN config_updated_at timestamptz NOT NULL DEFAULT now();
CREATE INDEX channels_tags ON channels USING gin (tags);

-- ---------- Пользователи: роли и область видимости ----------

-- Роль big_admin видит всё и управляет пользователями; admin/viewer ограничены областью видимости.
ALTER TABLE admin_users DROP CONSTRAINT IF EXISTS admin_users_role_check;
ALTER TABLE admin_users ADD CONSTRAINT admin_users_role_check
    CHECK (role IN ('big_admin', 'admin', 'viewer'));

-- Область видимости: какие группы каналов доступны пользователю. Пусто для big_admin — он видит всё.
CREATE TABLE user_scopes (
    user_id  bigint NOT NULL REFERENCES admin_users(id) ON DELETE CASCADE,
    group_id int    NOT NULL REFERENCES channel_groups(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, group_id)
);
CREATE INDEX user_scopes_group ON user_scopes (group_id);

-- ---------- Дашборды ----------

CREATE TABLE dashboards (
    id          bigserial PRIMARY KEY,
    owner_id    bigint REFERENCES admin_users(id) ON DELETE SET NULL,
    name        text NOT NULL,
    shared      boolean NOT NULL DEFAULT false,  -- виден другим пользователям (только чтение)
    layout      jsonb NOT NULL DEFAULT '[]',     -- позиции/размеры виджетов (grid)
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);

-- Виджет дашборда. Гибкость даёт jsonb-конфиг: тип панели, выбранные агенты/интерфейсы/
-- каналы/группы, метрика, тип графика, пороги. Схему валидирует сервер и фронтенд.
CREATE TABLE dashboard_widgets (
    id           bigserial PRIMARY KEY,
    dashboard_id bigint NOT NULL REFERENCES dashboards(id) ON DELETE CASCADE,
    kind         text NOT NULL,      -- timeseries | topN | stat | heatmap | table | load | alerts
    title        text NOT NULL DEFAULT '',
    config       jsonb NOT NULL DEFAULT '{}',
    pos          int NOT NULL DEFAULT 0
);
CREATE INDEX dashboard_widgets_dash ON dashboard_widgets (dashboard_id, pos);

-- ---------- Алерты: подтверждение и эскалация ----------

ALTER TABLE alerts ADD COLUMN acked_at timestamptz;
ALTER TABLE alerts ADD COLUMN acked_by bigint REFERENCES admin_users(id) ON DELETE SET NULL;
-- Звук в интерфейсе повторяется, пока алерт открыт и не подтверждён (acked_at IS NULL).

-- ---------- Тест одного канала и детальный статус ----------
-- test_runs.group_id уже NULLable. Добавляем целевой канал для одиночного теста,
-- а также полный список целевых каналов — чтобы показывать, кто ещё «в процессе».
ALTER TABLE test_runs ADD COLUMN channel_id bigint REFERENCES channels(id) ON DELETE SET NULL;
ALTER TABLE test_runs ADD COLUMN target_ids bigint[] NOT NULL DEFAULT '{}';

-- ---------- Обновлённые представления с понятными именами и тегами ----------
--
-- CREATE OR REPLACE VIEW не умеет менять состав/порядок колонок, поэтому пересоздаём
-- цепочку через DROP ... CASCADE (снесёт зависимые v_measurements, v_measurements_1h,
-- v_alerts) и создаём заново — уже с новыми колонками (display_name, tags, stale, acked_at).

DROP VIEW IF EXISTS v_channels CASCADE;

CREATE VIEW v_channels AS
SELECT c.id AS channel_id,
       COALESCE(NULLIF(c.display_name, ''), c.name) AS channel,   -- понятное имя приоритетно
       c.name AS auto_name,
       c.display_name,
       c.tags,
       c.stale,
       COALESCE(NULLIF(a.name, ''), a.hostname, a.machine_id) AS agent,
       a.id AS agent_id,
       c.interface, c.dscp, COALESCE(d.name, 'DSCP' || c.dscp) AS dscp_name,
       r.name AS reflector, host(r.address) AS reflector_addr, c.enabled
FROM channels c
JOIN agents a     ON a.id = c.agent_id
JOIN reflectors r ON r.id = c.reflector_id
LEFT JOIN dscp_names d ON d.dscp = c.dscp;

-- v_measurements (пересоздаём как в 001, join к новому v_channels)
CREATE VIEW v_measurements AS
SELECT m.ts, m.interval_sec, vc.*,
       m.sent, m.received, m.srv_rx,
       m.sent - m.received AS lost_total,
       CASE WHEN m.sent IS NOT NULL AND m.srv_rx IS NOT NULL
            THEN GREATEST(m.sent - m.srv_rx, 0) END     AS fwd_lost,
       CASE WHEN m.srv_rx IS NOT NULL AND m.received IS NOT NULL
            THEN GREATEST(m.srv_rx - m.received, 0) END AS bwd_lost,
       (100.0 * (m.sent - m.received) / NULLIF(m.sent, 0))::real AS loss_pct,
       CASE WHEN m.sent IS NOT NULL AND m.srv_rx IS NOT NULL
            THEN (100.0 * GREATEST(m.sent - m.srv_rx, 0) / NULLIF(m.sent, 0))::real END       AS fwd_loss_pct,
       CASE WHEN m.srv_rx IS NOT NULL AND m.received IS NOT NULL
            THEN (100.0 * GREATEST(m.srv_rx - m.received, 0) / NULLIF(m.srv_rx, 0))::real END AS bwd_loss_pct,
       m.rtt_min, m.rtt_avg, m.rtt_p50, m.rtt_p95, m.rtt_p99, m.rtt_max, m.rtt_q,
       CASE WHEN m.oneway_valid THEN m.fwd_delay_min END AS fwd_delay_min,
       CASE WHEN m.oneway_valid THEN m.fwd_delay_avg END AS fwd_delay_avg,
       CASE WHEN m.oneway_valid THEN m.fwd_delay_p95 END AS fwd_delay_p95,
       CASE WHEN m.oneway_valid THEN m.fwd_delay_max END AS fwd_delay_max,
       CASE WHEN m.oneway_valid THEN m.bwd_delay_min END AS bwd_delay_min,
       CASE WHEN m.oneway_valid THEN m.bwd_delay_avg END AS bwd_delay_avg,
       CASE WHEN m.oneway_valid THEN m.bwd_delay_p95 END AS bwd_delay_p95,
       CASE WHEN m.oneway_valid THEN m.bwd_delay_max END AS bwd_delay_max,
       m.fwd_jitter, m.bwd_jitter,
       m.fwd_dscp_seen, m.bwd_dscp_seen, m.srv_dscp_seen,
       m.fwd_remarked, m.bwd_remarked, m.dup, m.reordered,
       m.mos, m.oneway_valid
FROM measurements m
JOIN v_channels vc ON vc.channel_id = m.channel_id;

-- v_measurements_1h (measurements_1h — обычная вьюха, не зависит от v_channels, уцелела)
CREATE VIEW v_measurements_1h AS
SELECT h.ts, 3600 AS interval_sec, vc.*,
       h.sent, h.received, h.srv_rx,
       h.sent - h.received AS lost_total,
       CASE WHEN h.sent_srv IS NOT NULL AND h.srv_rx IS NOT NULL
            THEN GREATEST(h.sent_srv - h.srv_rx, 0) END     AS fwd_lost,
       CASE WHEN h.srv_rx IS NOT NULL AND h.received_srv IS NOT NULL
            THEN GREATEST(h.srv_rx - h.received_srv, 0) END AS bwd_lost,
       (100.0 * (h.sent - h.received) / NULLIF(h.sent, 0))::real AS loss_pct,
       CASE WHEN h.sent_srv IS NOT NULL AND h.srv_rx IS NOT NULL
            THEN (100.0 * GREATEST(h.sent_srv - h.srv_rx, 0) / NULLIF(h.sent_srv, 0))::real END   AS fwd_loss_pct,
       CASE WHEN h.srv_rx IS NOT NULL AND h.received_srv IS NOT NULL
            THEN (100.0 * GREATEST(h.srv_rx - h.received_srv, 0) / NULLIF(h.srv_rx, 0))::real END AS bwd_loss_pct,
       h.rtt_min, h.rtt_avg, h.rtt_p95, h.rtt_max,
       h.fwd_delay_avg, h.bwd_delay_avg, h.fwd_jitter, h.bwd_jitter,
       h.fwd_remarked, h.bwd_remarked, h.mos_min, h.mos
FROM measurements_1h h
JOIN v_channels vc ON vc.channel_id = h.channel_id;

-- v_alerts с acked_at и понятными именами
CREATE VIEW v_alerts AS
SELECT al.id, al.kind, al.severity, al.started_at, al.ended_at, al.last_seen_at,
       al.acked_at, al.details,
       al.channel_id, vc.channel, vc.dscp_name,
       COALESCE(al.agent_id, vc.agent_id) AS agent_id,
       COALESCE(NULLIF(a.name, ''), a.hostname, a.machine_id, vc.agent) AS agent
FROM alerts al
LEFT JOIN v_channels vc ON vc.channel_id = al.channel_id
LEFT JOIN agents a      ON a.id = al.agent_id;

-- ---------- RLS: ограничение видимости каналов по области пользователя ----------
--
-- Идентичность запроса передаётся через параметры сессии linkmon.role / linkmon.user_id
-- (сервер выставляет их в scoped-соединении, см. Store.asUser). big_admin и служебный
-- доступ (пустая роль: приём данных от агентов, движок алертов, миграции) видят всё;
-- admin/viewer — только каналы из групп своей области.
--
-- ВАЖНО: функции объявлены SECURITY DEFINER — они читают служебные таблицы user_scopes и
-- channel_group_members с правами ВЛАДЕЛЬЦА функции, поэтому работают даже когда вызываются
-- под ролью без прямых прав на эти таблицы (в т.ч. в RLS-политике на пути приёма данных
-- от агента). Без этого агентский ingest падал бы с "permission denied for table user_scopes".

CREATE OR REPLACE FUNCTION linkmon_role() RETURNS text
LANGUAGE sql STABLE AS $$ SELECT current_setting('linkmon.role', true) $$;

CREATE OR REPLACE FUNCTION linkmon_user_id() RETURNS bigint
LANGUAGE sql STABLE AS $$
    SELECT NULLIF(current_setting('linkmon.user_id', true), '')::bigint
$$;

CREATE OR REPLACE FUNCTION linkmon_can_see_channel(cid bigint) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER AS $$
    SELECT CASE
        WHEN COALESCE(linkmon_role(), '') IN ('', 'big_admin') THEN true
        ELSE EXISTS (
            SELECT 1
            FROM channel_group_members m
            JOIN user_scopes us ON us.group_id = m.group_id
            WHERE m.channel_id = cid AND us.user_id = linkmon_user_id()
        )
    END
$$;

CREATE OR REPLACE FUNCTION linkmon_can_see_monitor(mid bigint) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER AS $$
    SELECT CASE
        WHEN COALESCE(linkmon_role(), '') IN ('', 'big_admin') THEN true
        ELSE EXISTS (
            SELECT 1 FROM iface_monitors im
            JOIN channels c ON c.agent_id = im.agent_id AND c.interface = im.interface
            WHERE im.id = mid AND linkmon_can_see_channel(c.id)
        )
    END
$$;

-- RLS-политики на базовых таблицах — как «страховка» на случай прямого доступа к таблицам.
-- Основную фильтрацию по области приложение делает явно (linkmon_can_see_channel в WHERE
-- scoped-запросов), поэтому FORCE ROW LEVEL SECURITY НЕ включаем: иначе политики
-- распространились бы и на владельца/служебные операции (ingest, reconcile, движок алертов),
-- а функции при этом должны быть SECURITY DEFINER. Владелец таблиц RLS обходит — служебный
-- путь работает без ограничений, а прикладная роль (не владелец, без BYPASSRLS) — под политиками.

ALTER TABLE channels ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS channels_scope ON channels;
CREATE POLICY channels_scope ON channels
    USING (linkmon_can_see_channel(id))
    WITH CHECK (COALESCE(linkmon_role(), '') IN ('', 'big_admin', 'admin'));

ALTER TABLE measurements ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS measurements_scope ON measurements;
CREATE POLICY measurements_scope ON measurements
    USING (linkmon_can_see_channel(channel_id));

ALTER TABLE channel_group_members ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS cgm_scope ON channel_group_members;
CREATE POLICY cgm_scope ON channel_group_members
    USING (linkmon_can_see_channel(channel_id));

ALTER TABLE iface_load ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS iface_load_scope ON iface_load;
CREATE POLICY iface_load_scope ON iface_load USING (linkmon_can_see_monitor(monitor_id));
