-- 004_admin_auth.sql — авторизация администраторов веб-интерфейса по логину и паролю.
-- Пароли хранятся как argon2id-хэши (в формате PHC-строки), сессии — в БД.

CREATE TABLE admin_users (
    id            bigserial PRIMARY KEY,
    login         text NOT NULL UNIQUE,
    password_hash text NOT NULL,            -- argon2id PHC: $argon2id$v=19$m=...,t=...,p=...$salt$hash
    role          text NOT NULL DEFAULT 'admin' CHECK (role IN ('admin', 'viewer')),
    disabled      boolean NOT NULL DEFAULT false,
    created_at    timestamptz NOT NULL DEFAULT now(),
    last_login_at timestamptz
);

-- Сессии веб-интерфейса. token_hash — sha256 от случайного токена из cookie;
-- сам токен в БД не хранится, поэтому дамп базы не даёт доступа к активным сессиям.
CREATE TABLE admin_sessions (
    token_hash  bytea PRIMARY KEY,
    user_id     bigint NOT NULL REFERENCES admin_users(id) ON DELETE CASCADE,
    created_at  timestamptz NOT NULL DEFAULT now(),
    expires_at  timestamptz NOT NULL,
    last_seen_at timestamptz NOT NULL DEFAULT now(),
    user_agent  text,
    ip          inet
);
CREATE INDEX admin_sessions_user ON admin_sessions (user_id);
CREATE INDEX admin_sessions_expires ON admin_sessions (expires_at);
