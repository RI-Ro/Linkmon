-- 007_agent_scope_dashacl.sql — группировка агентов и область видимости по агентам,
-- строгая проверка доступа, модель доступа к дашбордам (личный / по пользователям / общий).

-- ---------- Группировка агентов (как каналов) ----------
-- Агент может входить в несколько групп; пользователю область видимости даётся по группам
-- (та же таблица user_scopes). Так admin/viewer видят только агентов своих групп.
CREATE TABLE agent_group_members (
    group_id int  NOT NULL REFERENCES channel_groups(id) ON DELETE CASCADE,
    agent_id uuid NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    PRIMARY KEY (group_id, agent_id)
);
CREATE INDEX agent_group_members_agent ON agent_group_members (agent_id);

-- Видимость агента: big_admin и служебный доступ — все; admin/viewer — только агенты из
-- групп своей области. SECURITY DEFINER — читает служебные таблицы независимо от прав роли.
CREATE OR REPLACE FUNCTION linkmon_can_see_agent(aid uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER AS $$
    SELECT CASE
        WHEN COALESCE(linkmon_role(), '') IN ('', 'big_admin') THEN true
        ELSE EXISTS (
            SELECT 1
            FROM agent_group_members am
            JOIN user_scopes us ON us.group_id = am.group_id
            WHERE am.agent_id = aid AND us.user_id = linkmon_user_id()
        )
    END
$$;

-- RLS-страховка на agents (основная фильтрация — явными предикатами в запросах приложения,
-- т.к. владелец таблиц RLS обходит; FORCE не включаем — служебный путь должен работать).
ALTER TABLE agents ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS agents_scope ON agents;
CREATE POLICY agents_scope ON agents
    USING (linkmon_can_see_agent(id)
           OR EXISTS (SELECT 1 FROM channels c WHERE c.agent_id = agents.id AND linkmon_can_see_channel(c.id)));

ALTER TABLE agent_group_members ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS agm_scope ON agent_group_members;
CREATE POLICY agm_scope ON agent_group_members USING (linkmon_can_see_agent(agent_id));

-- ---------- Модель доступа к дашбордам ----------
-- visibility: private — только владелец; users — владелец и явно перечисленные пользователи;
-- shared — все пользователи (только чтение). Совместимость: старый shared=true → 'shared'.
ALTER TABLE dashboards ADD COLUMN visibility text NOT NULL DEFAULT 'private'
    CHECK (visibility IN ('private', 'users', 'shared'));
UPDATE dashboards SET visibility = 'shared' WHERE shared;

-- Явный список пользователей, которым виден дашборд при visibility='users'.
CREATE TABLE dashboard_shares (
    dashboard_id bigint NOT NULL REFERENCES dashboards(id) ON DELETE CASCADE,
    user_id      bigint NOT NULL REFERENCES admin_users(id) ON DELETE CASCADE,
    PRIMARY KEY (dashboard_id, user_id)
);
CREATE INDEX dashboard_shares_user ON dashboard_shares (user_id);
