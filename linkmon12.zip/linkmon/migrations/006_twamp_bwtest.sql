-- 006_twamp_bwtest.sql — совместимость с TWAMP и двунаправленные тесты пропускной способности.

-- ---------- TWAMP ----------
-- Флаг «канал измеряется через TWAMP-Light»: агент шлёт пробы в формате RFC 5357 (unauthenticated),
-- совместимом с аппаратными TWAMP-ответчиками (сетевое оборудование). Для таких каналов
-- рефлектором выступает внешний TWAMP-responder, а не наш сервер.
ALTER TABLE channels ADD COLUMN twamp boolean NOT NULL DEFAULT false;

-- ---------- iperf-подобные тесты пропускной способности ----------
-- Прогон между двумя точками (клиент = агент, сервер = агент/сервер) с параметрами как в iperf:
-- протокол, длительность, число потоков, размер, целевая полоса (для UDP).
CREATE TABLE bw_tests (
    id           bigserial PRIMARY KEY,
    client_agent uuid REFERENCES agents(id) ON DELETE SET NULL,   -- кто инициирует нагрузку
    server_agent uuid REFERENCES agents(id) ON DELETE SET NULL,   -- принимающая сторона (NULL — сам сервер)
    server_addr  text NOT NULL,                                    -- host:port сервера bwtest, достижимый для клиента
    proto        text NOT NULL CHECK (proto IN ('tcp', 'udp')),
    reverse      boolean NOT NULL DEFAULT false,   -- обратное направление (сервер шлёт клиенту)
    bidir        boolean NOT NULL DEFAULT false,   -- двунаправленно одновременно
    duration_sec int NOT NULL DEFAULT 10,
    streams      int NOT NULL DEFAULT 1,
    length_bytes int NOT NULL DEFAULT 0,           -- размер блока (0 — по умолчанию: 128К TCP / 1400 UDP)
    target_mbps  double precision,                 -- целевая полоса для UDP; NULL/0 — без ограничения
    params       jsonb NOT NULL DEFAULT '{}',
    status       text NOT NULL CHECK (status IN ('scheduled','running','done','failed')) DEFAULT 'scheduled',
    result       jsonb,                            -- итог: throughput, retransmits, jitter, loss, по потокам
    error        text,
    created_by   text,
    created_at   timestamptz NOT NULL DEFAULT now(),
    finished_at  timestamptz
);
CREATE INDEX bw_tests_created ON bw_tests (created_at DESC);

CREATE OR REPLACE VIEW v_bw_tests AS
SELECT b.id, b.proto, b.reverse, b.bidir, b.duration_sec, b.streams, b.length_bytes, b.target_mbps,
       COALESCE((b.params->>'dscp')::int, 0) AS dscp,
       b.server_addr, b.status, b.result, b.error, b.created_by, b.created_at, b.finished_at,
       COALESCE(NULLIF(ca.name, ''), ca.hostname, ca.machine_id) AS client_name,
       COALESCE(NULLIF(sa.name, ''), sa.hostname, sa.machine_id) AS server_name,
       b.client_agent::text AS client_agent, b.server_agent::text AS server_agent
FROM bw_tests b
LEFT JOIN agents ca ON ca.id = b.client_agent
LEFT JOIN agents sa ON sa.id = b.server_agent;
