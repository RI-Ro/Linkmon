-- 001_init.sql — базовая схема LinkMon (чистый PostgreSQL 14+, без TimescaleDB)
--
-- Вариант без TimescaleDB: measurements/iface_load — обычные таблицы, часовые
-- агрегаты (measurements_1h, iface_load_1h) — обычные представления, считающие
-- агрегат на лету. Имена и колонки совпадают с Timescale-версией, поэтому серверный
-- код (v_measurements_1h и т.п.) работает без изменений.
--
-- Хранение старых данных: см. функцию linkmon_prune() ниже — вызывайте её по cron
-- (или pg_cron), она удаляет строки старше заданного срока. Партиционирование можно
-- добавить позже, не трогая приложение.

CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- gen_random_uuid() на PostgreSQL < 13

-- ---------- Справочники ----------

CREATE TABLE dscp_names (
    dscp smallint PRIMARY KEY,
    name text NOT NULL
);
INSERT INTO dscp_names (dscp, name) VALUES
    (0,'BE'),(8,'CS1'),(10,'AF11'),(12,'AF12'),(14,'AF13'),(16,'CS2'),(18,'AF21'),(20,'AF22'),(22,'AF23'),
    (24,'CS3'),(26,'AF31'),(28,'AF32'),(30,'AF33'),(32,'CS4'),(34,'AF41'),(36,'AF42'),(38,'AF43'),
    (40,'CS5'),(44,'VA'),(46,'EF'),(48,'CS6'),(56,'CS7');

CREATE TABLE channel_groups (
    id         serial PRIMARY KEY,
    parent_id  int REFERENCES channel_groups(id) ON DELETE CASCADE,
    name       text NOT NULL,
    tags       text[] NOT NULL DEFAULT '{}',
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX channel_groups_name_uq ON channel_groups (COALESCE(parent_id, 0), name);

CREATE TABLE enroll_tokens (
    id           serial PRIMARY KEY,
    token_hash   bytea NOT NULL UNIQUE,          -- sha256(token), сам токен не хранится
    description  text,
    group_id     int REFERENCES channel_groups(id) ON DELETE SET NULL,
    auto_approve boolean NOT NULL DEFAULT false,
    uses_left    int,                            -- NULL — без ограничений
    expires_at   timestamptz,
    created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE agents (
    id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    machine_id     text NOT NULL UNIQUE,
    hostname       text NOT NULL,
    status         text NOT NULL CHECK (status IN ('pending','approved','rejected','disabled')),
    pubkey_sha256  bytea NOT NULL,
    token_id       int REFERENCES enroll_tokens(id) ON DELETE SET NULL,
    cert_serial    text,
    cert_not_after timestamptz,
    capabilities   jsonb NOT NULL DEFAULT '{}',
    version        text,
    last_seen      timestamptz,
    clock_synced   boolean,
    clock_err_us   bigint,
    created_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE reflectors (
    id      serial PRIMARY KEY,
    name    text NOT NULL,
    address inet NOT NULL,
    port    int  NOT NULL DEFAULT 8620,
    UNIQUE (address, port)
);

CREATE TABLE test_profiles (
    id           serial PRIMARY KEY,
    name         text NOT NULL UNIQUE,
    pps          int NOT NULL DEFAULT 10   CHECK (pps BETWEEN 1 AND 1000),
    packet_size  int NOT NULL DEFAULT 128  CHECK (packet_size BETWEEN 80 AND 1472),
    poisson      boolean NOT NULL DEFAULT false,
    interval_sec int NOT NULL DEFAULT 60   CHECK (interval_sec IN (10, 30, 60, 300))
);
INSERT INTO test_profiles (name) VALUES ('default');

CREATE TABLE sla_profiles (
    id               serial PRIMARY KEY,
    name             text NOT NULL UNIQUE,
    max_rtt_ms       real,
    max_oneway_ms    real,
    max_jitter_ms    real,
    max_loss_pct     real,
    min_mos          real,
    allow_remarking  boolean NOT NULL DEFAULT false,
    breach_intervals int NOT NULL DEFAULT 3   -- сколько интервалов подряд до алерта
);

CREATE TABLE channels (
    id           bigserial PRIMARY KEY,
    agent_id     uuid NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    interface    text NOT NULL,
    source_ip    inet,
    reflector_id int  NOT NULL REFERENCES reflectors(id),
    dscp         smallint NOT NULL CHECK (dscp BETWEEN 0 AND 63),
    profile_id   int NOT NULL DEFAULT 1 REFERENCES test_profiles(id),
    sla_id       int REFERENCES sla_profiles(id) ON DELETE SET NULL,
    name         text NOT NULL,
    enabled      boolean NOT NULL DEFAULT true,
    session_id   bigint NOT NULL UNIQUE,
    session_key  bytea  NOT NULL,
    created_at   timestamptz NOT NULL DEFAULT now(),
    UNIQUE (agent_id, interface, reflector_id, dscp)
);

CREATE TABLE channel_group_members (
    group_id   int    NOT NULL REFERENCES channel_groups(id) ON DELETE CASCADE,
    channel_id bigint NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
    PRIMARY KEY (group_id, channel_id)
);
CREATE INDEX channel_group_members_channel ON channel_group_members (channel_id);

-- ---------- Измерения ----------
-- Одна строка = канал × интервал. Агентская половина (отправлено/получено, RTT, задержки)
-- и серверная половина (сколько дошло до рефлектора) приходят независимо и сливаются upsert'ом.

CREATE TABLE measurements (
    ts            timestamptz NOT NULL,
    channel_id    bigint      NOT NULL,
    interval_sec  int         NOT NULL DEFAULT 60,
    -- агент
    sent int, received int, dup int, reordered int,
    rtt_min real, rtt_avg real, rtt_p50 real, rtt_p95 real, rtt_p99 real, rtt_max real,
    fwd_delay_min real, fwd_delay_avg real, fwd_delay_p95 real, fwd_delay_max real, fwd_jitter real,
    bwd_delay_min real, bwd_delay_avg real, bwd_delay_p95 real, bwd_delay_max real, bwd_jitter real,
    fwd_dscp_seen smallint, bwd_dscp_seen smallint,
    fwd_remarked int, bwd_remarked int,
    mos real,
    oneway_valid boolean,
    rtt_q real[],                     -- 20 квантилей RTT для smoke-графика
    -- сессионная горутина рефлектора
    srv_rx int, srv_dup int, srv_dscp_seen smallint, srv_remarked int,
    PRIMARY KEY (channel_id, ts)
);

-- Индекс под выборки по времени (Grafana, обзор, серии). PK уже покрывает (channel_id, ts).
CREATE INDEX measurements_ts ON measurements (ts DESC);

CREATE TABLE ingested_batches (
    agent_id    uuid   NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    batch_seq   bigint NOT NULL,
    intervals   int    NOT NULL,
    received_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (agent_id, batch_seq)
);

-- ---------- Команды и тесты ----------

CREATE TABLE agent_commands (
    id           bigserial PRIMARY KEY,
    agent_id     uuid NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    kind         text NOT NULL,
    payload      jsonb NOT NULL DEFAULT '{}',
    created_at   timestamptz NOT NULL DEFAULT now(),
    delivered_at timestamptz
);
CREATE INDEX agent_commands_pending ON agent_commands (agent_id, id) WHERE delivered_at IS NULL;

CREATE TABLE test_runs (
    id           bigserial PRIMARY KEY,
    kind         text NOT NULL,
    group_id     int REFERENCES channel_groups(id) ON DELETE SET NULL,
    start_at     timestamptz NOT NULL,
    duration_sec int NOT NULL,
    params       jsonb NOT NULL DEFAULT '{}',
    expected     int NOT NULL,
    status       text NOT NULL CHECK (status IN ('scheduled','running','done','failed')),
    created_by   text,
    created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE test_run_results (
    run_id      bigint NOT NULL REFERENCES test_runs(id) ON DELETE CASCADE,
    channel_id  bigint NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
    result      jsonb,
    error       text,
    received_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (run_id, channel_id)
);

CREATE TABLE alerts (
    id         bigserial PRIMARY KEY,
    channel_id bigint NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
    kind       text NOT NULL,           -- rtt, loss, jitter, mos, remarking, agent_down
    severity   text NOT NULL DEFAULT 'warning',
    started_at timestamptz NOT NULL,
    ended_at   timestamptz,
    details    jsonb NOT NULL DEFAULT '{}'
);
CREATE INDEX alerts_open ON alerts (channel_id) WHERE ended_at IS NULL;

-- ---------- Представления (для API и Grafana) ----------

CREATE VIEW v_channels AS
SELECT c.id AS channel_id, c.name AS channel, a.hostname AS agent, a.id AS agent_id,
       c.interface, c.dscp, COALESCE(d.name, 'DSCP' || c.dscp) AS dscp_name,
       r.name AS reflector, host(r.address) AS reflector_addr, c.enabled
FROM channels c
JOIN agents a     ON a.id = c.agent_id
JOIN reflectors r ON r.id = c.reflector_id
LEFT JOIN dscp_names d ON d.dscp = c.dscp;

-- Потери по направлениям:
--   fwd_lost = sent − srv_rx      (не дошли до рефлектора)
--   bwd_lost = srv_rx − received  (рефлектор ответил, но ответ не дошёл до агента)
-- Однонаправленные задержки показываются только при синхронных часах на обеих сторонах.
CREATE VIEW v_measurements AS
SELECT m.ts, m.interval_sec, vc.*,
       m.sent, m.received, m.srv_rx,
       m.sent - m.received AS lost_total,
       -- GREATEST игнорирует NULL, поэтому явно проверяем наличие обеих половин
       CASE WHEN m.sent IS NOT NULL AND m.srv_rx IS NOT NULL
            THEN GREATEST(m.sent - m.srv_rx, 0) END     AS fwd_lost,
       CASE WHEN m.srv_rx IS NOT NULL AND m.received IS NOT NULL
            THEN GREATEST(m.srv_rx - m.received, 0) END AS bwd_lost,
       (100.0 * (m.sent - m.received) / NULLIF(m.sent, 0))::real AS loss_pct,
       CASE WHEN m.sent IS NOT NULL AND m.srv_rx IS NOT NULL
            THEN (100.0 * GREATEST(m.sent - m.srv_rx, 0) / NULLIF(m.sent, 0))::real END       AS fwd_loss_pct,
       CASE WHEN m.srv_rx IS NOT NULL AND m.received IS NOT NULL
            THEN (100.0 * GREATEST(m.srv_rx - m.received, 0) / NULLIF(m.srv_rx, 0))::real END AS bwd_loss_pct,
       m.rtt_min, m.rtt_avg, m.rtt_p50, m.rtt_p95, m.rtt_p99, m.rtt_max, m.rtt_q,
       CASE WHEN m.oneway_valid THEN m.fwd_delay_min END AS fwd_delay_min,
       CASE WHEN m.oneway_valid THEN m.fwd_delay_avg END AS fwd_delay_avg,
       CASE WHEN m.oneway_valid THEN m.fwd_delay_p95 END AS fwd_delay_p95,
       CASE WHEN m.oneway_valid THEN m.fwd_delay_max END AS fwd_delay_max,
       CASE WHEN m.oneway_valid THEN m.bwd_delay_min END AS bwd_delay_min,
       CASE WHEN m.oneway_valid THEN m.bwd_delay_avg END AS bwd_delay_avg,
       CASE WHEN m.oneway_valid THEN m.bwd_delay_p95 END AS bwd_delay_p95,
       CASE WHEN m.oneway_valid THEN m.bwd_delay_max END AS bwd_delay_max,
       m.fwd_jitter, m.bwd_jitter,
       m.fwd_dscp_seen, m.bwd_dscp_seen, m.srv_dscp_seen,
       m.fwd_remarked, m.bwd_remarked, m.dup, m.reordered,
       m.mos, m.oneway_valid
FROM measurements m
JOIN v_channels vc ON vc.channel_id = m.channel_id;

-- Часовой агрегат для длинных диапазонов. Без TimescaleDB это обычное представление,
-- считающее агрегат на лету. Для больших объёмов его можно позже заменить на
-- MATERIALIZED VIEW с периодическим REFRESH MATERIALIZED VIEW CONCURRENTLY по cron
-- (тогда добавьте уникальный индекс по (channel_id, ts)).
CREATE VIEW measurements_1h AS
SELECT date_trunc('hour', ts) AS ts,
       channel_id,
       sum(sent)     AS sent,
       sum(received) AS received,
       sum(srv_rx)   AS srv_rx,
       sum(CASE WHEN srv_rx IS NOT NULL THEN sent END)     AS sent_srv,
       sum(CASE WHEN srv_rx IS NOT NULL THEN received END) AS received_srv,
       min(rtt_min) AS rtt_min,
       avg(rtt_avg) AS rtt_avg,
       max(rtt_p95) AS rtt_p95,
       max(rtt_max) AS rtt_max,
       avg(CASE WHEN oneway_valid THEN fwd_delay_avg END) AS fwd_delay_avg,
       avg(CASE WHEN oneway_valid THEN bwd_delay_avg END) AS bwd_delay_avg,
       avg(fwd_jitter) AS fwd_jitter,
       avg(bwd_jitter) AS bwd_jitter,
       sum(fwd_remarked) AS fwd_remarked,
       sum(bwd_remarked) AS bwd_remarked,
       min(mos) AS mos_min,
       avg(mos) AS mos
FROM measurements
GROUP BY 1, 2;

CREATE VIEW v_measurements_1h AS
SELECT h.ts, 3600 AS interval_sec, vc.*,
       h.sent, h.received, h.srv_rx,
       h.sent - h.received AS lost_total,
       CASE WHEN h.sent_srv IS NOT NULL AND h.srv_rx IS NOT NULL
            THEN GREATEST(h.sent_srv - h.srv_rx, 0) END     AS fwd_lost,
       CASE WHEN h.srv_rx IS NOT NULL AND h.received_srv IS NOT NULL
            THEN GREATEST(h.srv_rx - h.received_srv, 0) END AS bwd_lost,
       (100.0 * (h.sent - h.received) / NULLIF(h.sent, 0))::real AS loss_pct,
       CASE WHEN h.sent_srv IS NOT NULL AND h.srv_rx IS NOT NULL
            THEN (100.0 * GREATEST(h.sent_srv - h.srv_rx, 0) / NULLIF(h.sent_srv, 0))::real END   AS fwd_loss_pct,
       CASE WHEN h.srv_rx IS NOT NULL AND h.received_srv IS NOT NULL
            THEN (100.0 * GREATEST(h.srv_rx - h.received_srv, 0) / NULLIF(h.srv_rx, 0))::real END AS bwd_loss_pct,
       h.rtt_min, h.rtt_avg, h.rtt_p95, h.rtt_max,
       h.fwd_delay_avg, h.bwd_delay_avg, h.fwd_jitter, h.bwd_jitter,
       h.fwd_remarked, h.bwd_remarked, h.mos_min, h.mos
FROM measurements_1h h
JOIN v_channels vc ON vc.channel_id = h.channel_id;

CREATE VIEW v_group_channels AS
SELECT g.id AS group_id, g.name AS group_name, g.parent_id, m.channel_id
FROM channel_groups g
JOIN channel_group_members m ON m.group_id = g.id;

-- ---------- Хранение данных (замена retention-политик TimescaleDB) ----------
-- Удаляет сырые метрики старше measurements_days и загрузку старше load_days.
-- Вызывать по расписанию, например из pg_cron:
--   SELECT cron.schedule('linkmon-prune', '17 3 * * *', $$SELECT linkmon_prune()$$);
-- или системным cron:
--   17 3 * * *  psql -d linkmon -c "SELECT linkmon_prune()"
CREATE OR REPLACE FUNCTION linkmon_prune(measurements_days int DEFAULT 180, load_days int DEFAULT 180)
RETURNS void LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM measurements WHERE ts < now() - make_interval(days => measurements_days);
    -- Дедуп-журнал батчей чистим следом за метриками, чтобы не рос бесконечно.
    DELETE FROM ingested_batches WHERE received_at < now() - make_interval(days => measurements_days);
    -- iface_load создаётся в миграции 003; удаляем только если таблица уже есть.
    IF to_regclass('public.iface_load') IS NOT NULL THEN
        DELETE FROM iface_load WHERE ts < now() - make_interval(days => load_days);
    END IF;
END;
$$;

