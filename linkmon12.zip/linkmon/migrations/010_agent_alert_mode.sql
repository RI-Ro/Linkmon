-- 010_agent_alert_mode.sql — режим оповещений на агента: чтобы при большом числе клиентов
-- следить только за критичными точками, а не тонуть в предупреждениях.
--   all      — все алерты и звук (по умолчанию);
--   critical — только критичные алерты и звук; предупреждения (warning) подавляются;
--   off      — алерты и оповещения для этого агента не создаются вовсе.
ALTER TABLE agents ADD COLUMN alert_mode text NOT NULL DEFAULT 'all'
    CHECK (alert_mode IN ('all', 'critical', 'off'));
