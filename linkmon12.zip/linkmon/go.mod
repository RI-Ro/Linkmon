module github.com/example/linkmon

go 1.22

require (
	github.com/jackc/pgx/v5 v5.6.0
	golang.org/x/crypto v0.25.0
	golang.org/x/sys v0.22.0
	gopkg.in/yaml.v3 v3.0.1
)
